"""Separate, offline validator for calibration_experiment_v2 archives.

No extension of the baseline four-arm parser; no model/tokenizer load or CUDA.
NPZ is opened with allow_pickle=False. Labels enter only after archive validation.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

from data_prep import metrics
from kv_harness.manifest import RunManifest
from .analysis import _data, _local, _number, _read, _rows, cluster_bootstrap
from .contracts import canonical_hash, exact_keys, require, sha256_file, tokens, validate_config
from .calibration_experiment import (ARMS, ORACLES, POLICY, POLICIES, RATIO, SCHEMA, SEED,
    ROOT, MANIFEST, MANIFEST_SHA256, _write, anchor_plans, check_config, check_execution_record,
    diagnostic_masks, source_hashes, verify_plan, operation_sequence)


def completed(run, *, allow_fixture=False):
    require(run.is_dir() and not run.is_symlink(), "Missing completed run directory")
    require(not (run / "FAILED.json").exists(), "A failed/partial run cannot be analyzed")
    marker = _read(_local(run, "COMPLETE.json"))
    exact_keys(marker, {"schema", "status", "manifest_sha256"}, set(), "completion marker")
    require(marker["schema"] == SCHEMA and marker["status"] == "completed", "Wrong/unfinished archive schema")
    require(sha256_file(_local(run, "manifest.json")) == marker["manifest_sha256"], "Manifest digest mismatch")
    manifest = _read(run / "manifest.json")
    exact_keys(manifest, {"schema", "status", "evidence_kind", "backend_commit", "plan_sha256", "source_sha256", "artifact_sha256"}, set(), "manifest")
    from . import BACKEND_COMMIT
    require(manifest["schema"] == SCHEMA and manifest["status"] == "completed" and manifest["backend_commit"] == BACKEND_COMMIT, "Wrong runtime schema/source")
    hashes = manifest["artifact_sha256"]
    require(isinstance(hashes, dict) and hashes, "Missing artifact inventory")
    actual = set()
    for path in run.rglob("*"):
        require(not path.is_symlink(), "Symlink artifacts unsupported")
        if path.is_file(): actual.add(path.relative_to(run).as_posix())
    require(actual == set(hashes) | {"manifest.json", "COMPLETE.json"}, "Artifact inventory missing/extra files")
    require(not ({"manifest.json", "COMPLETE.json", "FAILED.json"} & set(hashes)), "Invalid marker inventory")
    for name, digest in hashes.items():
        require(sha256_file(_local(run, name)) == digest, f"Artifact digest mismatch: {name}")
    require(manifest["source_sha256"] == source_hashes(), "Unsupported screen/runtime/analysis source version")
    config = _read(_local(run, "baseline_config.json"))
    validate_config(config)
    evidence = RunManifest.load(_local(run, "evidence_manifest.json"))
    kind = evidence.payload["evidence_kind"]
    require(kind == manifest["evidence_kind"] and (kind == "real_model" or (kind == "cpu_fixture" and allow_fixture)),
            "Only real-model evidence, or explicitly opted-in CPU fixture evidence, is supported")
    plan = _read(_local(run, "plan.json"))
    record = _read(_local(run, "execution_record.json"))
    baseline = _read(_local(run, "baseline_evidence.json"))
    require(evidence.payload["config"] == {"schema": SCHEMA, "plan": plan, "baseline_config": config, "execution_record": record}, "Evidence configuration mismatch")
    require(evidence.payload["seed"] == SEED and manifest["plan_sha256"] == plan["plan_sha256"], "Evidence seed/plan mismatch")
    require(evidence.payload["artifacts"] == {
        "model": {"identifier": config["model"]["id"], "revision_kind": "git_commit", "revision": config["model"]["revision"]},
        "dataset": {"identifier": config["dataset"]["source_id"], "revision_kind": "git_commit", "revision": config["dataset"]["source_revision"]},
        "screen_plan": {"identifier": SCHEMA, "revision_kind": "sha256", "revision": plan["plan_sha256"]}}, "Evidence pins mismatch")
    check_execution_record(record, plan, baseline)
    lock = _read(_local(run, "packages.lock.json"))
    require(sha256_file(run / "packages.lock.json") == config["runtime"]["packages_lock_sha256"], "Package lock digest mismatch")
    environment = _read(_local(run, "environment.json"))
    for key in ("python_version", "packages", "backend_commit"):
        require(key in lock and environment.get(key) == lock[key], "Environment differs from frozen lock")
    require(lock["backend_commit"] == BACKEND_COMMIT and isinstance(lock["packages"], dict) and
            {"torch", "transformers", "kvpress", "numpy", "peft"} <= set(lock["packages"]), "Incomplete environment lock")
    if kind == "real_model":
        settings = environment.get("deterministic_settings", {})
        require(settings.get("deterministic_algorithms") is True and settings.get("tf32_allowed") is False and
                settings.get("CUBLAS_WORKSPACE_CONFIG") in (":4096:8", ":16:8"), "Missing deterministic environment verification")
        source = _read(ROOT / "research/sources/echopress_39748e9/provenance.json")
        pinned = {r["path"]: r["local_sha256"] for r in source["files"] if r["path"].startswith("kvpress/")}
        for name in ("kvpress/presses/base_press.py", "kvpress/attention_patch.py", "kvpress/__init__.py", "kvpress/utils.py"):
            pinned[name] = sha256_file(ROOT / "echo_pilot/vendor_audit" / name.replace("/", "__"))
        require(environment.get("verified_source_sha256") == pinned, "Missing pinned author-source verification")
    required = {"plan.json", "baseline_config.json", "baseline_evidence.json", "execution_record.json", "packages.lock.json",
                "evidence_manifest.json", "environment.json", "resolved_model_config.json", "model_load.json", "events.jsonl",
                "results.jsonl", "runtime.log", "run_timing.json"}
    for i in range(len(plan["ordered_contexts"])):
        required.update(f"c{i:05d}/{name}" for name in ("build.json", "scores_masks.npz", "context_timing.json"))
    require(set(hashes) == required, "Missing/extra screen archive artifacts")
    return config, manifest, evidence, plan


def timing(value):
    exact_keys(value, {"synchronized_wall_seconds", "host_wall_seconds", "memory"}, set(), "measured timing")
    for name in ("synchronized_wall_seconds", "host_wall_seconds"):
        _number(value[name], name)
    memory = value["memory"]
    keys = {"allocated_bytes", "reserved_bytes", "peak_allocated_bytes", "peak_reserved_bytes", "device_free_bytes", "device_total_bytes"}
    exact_keys(memory, keys, set(), "device memory")
    require(all(type(v) is int and v >= 0 for v in memory.values()), "Invalid device memory measurement")


def _cache(value, model, n, dtype):
    layers, heads, head_dim = model["num_hidden_layers"], model["num_key_value_heads"], model["head_dim"]
    shape = [1, heads, n, head_dim]
    require(value.get("compacted") is False and value.get("kv_shapes") == [[shape, shape] for _ in range(layers)], "Wrong dense cache shape")
    size = 2 * layers * heads * n * head_dim * {"bfloat16": 2, "float16": 2, "float32": 4}[dtype]
    require(value.get("kv_tensor_payload_bytes") == size and type(value.get("kv_unique_storage_bytes")) is int and
            value["kv_unique_storage_bytes"] >= size, "Wrong physical cache bytes")


def ledger(value, replay, ids, *, diagnostic):
    require(value.get("status") == "completed" and value.get("diagnostic_only") is diagnostic and
            value.get("deployable_cost") is (not diagnostic), "Wrong score-build status/cost category")
    require(value.get("replay_plan_sha256") == replay.fingerprint and value.get("partition_sha256") == replay.partition.fingerprint and
            value.get("context_sha256") == replay.partition.context_sha256, "Build replay/partition identity mismatch")
    from .calibration_runtime import PROMPT_POLICY
    from . import BACKEND_COMMIT
    require(value.get("backend_commit") == BACKEND_COMMIT and value.get("prompt_policy_adaptation") == PROMPT_POLICY,
            "Build source/prompt policy mismatch")
    expected = [replay.context_token_ids] + [replay.replay_token_ids[i] for i in ids]
    lengths = list(map(len, expected))
    events = [{"input_tokens": len(tokens_), "input_ids_sha256": canonical_hash(tokens_),
               "phase": "prefill" if i == 0 else "exact_replay"} for i, tokens_ in enumerate(expected)]
    for name in ("exact_chunk_ids", "planned_exact_chunk_ids", "completed_exact_chunk_ids"):
        require(value.get(name) == list(ids), "Exact replay schedule mismatch")
    for name in ("planned_exact_replay_passes", "completed_exact_replay_passes", "exact_replay_passes"):
        require(value.get(name) == len(ids), "Exact replay count mismatch")
    require(value.get("planned_forward_input_lengths") == lengths and value.get("observed_forward_input_lengths") == lengths and
            value.get("observed_forwards") == events, "Observed forward IDs/lengths differ from context-only plan")
    require(value.get("exact_replay_input_tokens") == sum(lengths[1:]) == value.get("observed_replay_input_tokens"), "Replay input charge mismatch")
    require(value.get("exact_replay_context_tokens") == sum(replay.partition.chunks[i].end - replay.partition.chunks[i].start for i in ids) and
            value.get("exact_replay_prompt_tokens") == sum(replay.partition.chunks[i].prompt_tokens for i in ids), "Replay prompt/body charge mismatch")
    require(value.get("replay_dense_causal_attention_pairs_proxy") == sum(lengths[0] * t + t * (t + 1) // 2 for t in lengths[1:]), "Replay work proxy mismatch")
    require(value.get("physical_memory_savings_demonstrated") is False and value.get("cache_compacted") is False, "Unsupported physical-memory claim")
    require(value.get("chunks") == [replay.chunk_metadata(i) for i in range(len(replay.partition.chunks))], "Chunk metadata mismatch")
    for name in ("scoring_host_wall_seconds", "total_builder_host_wall_seconds"):
        _number(value.get(name), name)


def validate_captures(run, config, contexts, replays):
    import numpy as np
    from research.calibration_methods.contracts import VirtualScores, AnchorObservations
    from research.calibration_methods.diagnostics import FullExactDiagnostic
    from research.calibration_methods.methods import calibrate
    from research.calibration_methods.selection import select_logical
    model = _read(run / "resolved_model_config.json")
    for field in ("num_hidden_layers", "num_key_value_heads", "head_dim"):
        require(type(model.get(field)) is int and model[field] > 0, "Missing resolved model dimension")
    require(model.get("_name_or_path") == config["model"]["id"] and model.get("_commit_hash") == config["model"]["revision"], "Resolved model identity/revision mismatch")
    expected_masks, builds = {}, {}
    for ci, (context, replay) in enumerate(zip(contexts, replays, strict=True)):
        folder = run / f"c{ci:05d}"
        build = _read(folder / "build.json")
        require(build.get("schema") == SCHEMA and build.get("context_id") == context.context_id and
                build.get("replay_sha256") == replay.fingerprint, "Build identity mismatch")
        require(build.get("physical_memory_savings_demonstrated") is False and build.get("cache_compacted") is False, "Unsupported memory claim")
        require(set(build["accounting"]) == {*POLICIES, "full_exact_diagnostic"} and set(build["selection"]) == set(ARMS), "Missing/extra method cells")
        shape = (model["num_hidden_layers"], model["num_key_value_heads"], len(context.token_ids))
        with np.load(folder / "scores_masks.npz", allow_pickle=False) as archive:
            expected = {prefix + name for prefix in ("score__", "keep__") for name in ARMS}
            expected |= {prefix + name for prefix in ("virtual__", "anchors__") for name in POLICIES}
            expected |= {"full_exact", "diagnostic_virtual"}
            require(set(archive.files) == expected and len(archive.files) == len(expected), "Missing/extra/duplicate score arrays")
            arrays = {k: archive[k] for k in archive.files}
        require(build.get("capture_cpu_bytes") == sum(a.nbytes for a in arrays.values()), "Capture overhead bytes mismatch")
        for key, array in arrays.items():
            require(array.dtype == (np.bool_ if key.startswith("keep__") else np.float32) and
                    (key.startswith("anchors__") or array.shape == shape) and bool(np.isfinite(array).all()), "Invalid score/mask dtype/shape/value")
        full = FullExactDiagnostic(replay.partition, arrays["full_exact"])
        diagnostic = SimpleNamespace(virtual=VirtualScores(replay.partition, arrays["diagnostic_virtual"]), full_exact=full)
        first = None
        for anchors in anchor_plans(replay):
            policy = anchors.policy
            virtual = VirtualScores(replay.partition, arrays["virtual__" + policy])
            obs = AnchorObservations(anchors, arrays["anchors__" + policy])
            require(np.array_equal(virtual.values, diagnostic.virtual.values) and
                    np.array_equal(obs.values, full.values[..., anchors.token_indices]), "Independent sparse/full score observations disagree")
            result = calibrate(virtual, obs)
            keep, selected = select_logical(result.scores, replay.partition, RATIO, seed=SEED)
            require(np.array_equal(arrays["score__" + policy], result.scores) and np.array_equal(arrays["keep__" + policy], keep), "Recorded candidate differs from anchor-only recomputation")
            require(build["selection"][policy] == selected and build["calibration"][policy] == result.diagnostics, "Candidate diagnostics mismatch")
            acct = build["accounting"][policy]
            ledger(acct["runtime"], replay, anchors.chunk_ids, diagnostic=False)
            require(acct["runtime"].get("anchor_plan_sha256") == anchors.fingerprint, "Anchor plan hash mismatch")
            timing(acct["measured"])
            _cache(acct["cache"], model, len(context.token_ids), config["model"]["dtype"])
            if policy == "first": first = SimpleNamespace(virtual=virtual, anchors=obs, calibration=result, keep_mask=keep)
        acct = build["accounting"]["full_exact_diagnostic"]
        ledger(acct["runtime"], replay, tuple(range(len(replay.partition.chunks))), diagnostic=True)
        timing(acct["measured"])
        scores, masks, selections, report = diagnostic_masks(first, diagnostic, replay)
        for name in scores:
            require(np.array_equal(arrays["score__" + name], scores[name]) and np.array_equal(arrays["keep__" + name], masks[name]), "Recorded diagnostic/control mask differs from recomputation")
            require(build["selection"][name] == selections[name], "Diagnostic selection mismatch")
        require(build["diagnostics"] == report, "Diagnostic provenance/allocation mismatch")
        timing(build["transform_measured"])
        _number(build["capture_serialization_host_seconds"], "serialization overhead")
        ct = _read(folder / "context_timing.json")
        _number(ct.get("synchronized_wall_seconds"), "context wall seconds")
        require(ct.get("speedup_claim") is False, "Unsupported timing claim")
        for name in ARMS: expected_masks[(context.context_id, name)] = canonical_hash(arrays["keep__" + name].tolist())
        builds[context.context_id] = build
    return model, expected_masks, builds


def validate_results(run, config, contexts, grouped, queries, masks, model):
    expected = {(c.context_id, q["question_id"], arm) for c in contexts for q in grouped[c.context_id] for arm in ARMS}
    seen, cells = set(), defaultdict(list)
    for row in _rows(run / "results.jsonl"):
        exact_keys(row, {"schema", "context_id", "question_id", "arm", "eviction_ratio", "diagnostic_only", "query_token_ids_sha256",
                        "mask_sha256", "generated_token_ids", "text", "text_with_special_tokens", "stopped_on_eos", "generated_token_count",
                        "clone_install", "generation", "query_cache"}, set(), "result")
        key = (row["context_id"], row["question_id"], row["arm"])
        require(row["schema"] == SCHEMA and key in expected and key not in seen, "Unknown/duplicate result cell")
        seen.add(key)
        c, qid, arm = key
        q = queries[qid]
        require(type(row["eviction_ratio"]) in (float, int) and row["eviction_ratio"] == (0.0 if arm == "fullkv" else RATIO) and
                row["diagnostic_only"] is (arm in ORACLES), "Result ratio/diagnostic status changed")
        require(row["query_token_ids_sha256"] == canonical_hash(q["question_token_ids"]) and
                row["mask_sha256"] == masks[(c, arm)], "Result query/mask binding mismatch")
        tokens(row["generated_token_ids"], "generated token IDs")
        count = row["generated_token_count"]
        require(type(count) is int and count == len(row["generated_token_ids"]) and 1 <= count <= POLICY["max_new_tokens"], "Generated length mismatch")
        require(type(row["stopped_on_eos"]) is bool and (row["stopped_on_eos"] or count == POLICY["max_new_tokens"]), "Premature generation stop")
        require(isinstance(row["text"], str) and isinstance(row["text_with_special_tokens"], str), "Generated text required")
        timing(row["clone_install"]); timing(row["generation"])
        n = next(len(x.token_ids) for x in contexts if x.context_id == c)
        _cache(row["query_cache"], model, n + len(q["question_token_ids"]) + count - 1, config["model"]["dtype"])
        cells[arm].append({"question_id": qid, "prediction": row["text"]})
    require(seen == expected, "Missing required result cells; denominator cannot shrink")
    return cells


def validate_events(run, plan, builds, rows):
    """Raw log must witness every charged operation, including clones/transforms."""
    expected = {"model_load": _read(run / "model_load.json")}
    for ci, context in enumerate(plan["ordered_contexts"]):
        cid = context["context_id"]
        build = builds[cid]
        for arm in POLICIES:
            expected[f"c{ci:05d}:{arm}:build"] = build["accounting"][arm]["measured"]
        expected[f"c{ci:05d}:full_exact:build"] = build["accounting"]["full_exact_diagnostic"]["measured"]
        expected[f"c{ci:05d}:diagnostic_mask_transforms"] = build["transform_measured"]
        for row in rows:
            if row["context_id"] == cid:
                prefix = f"c{ci:05d}:{row['arm']}:{row['question_id']}"
                expected[prefix + ":clone_install"] = row["clone_install"]
                expected[prefix + ":generate"] = row["generation"]
    observed, started = set(), None
    sequence = operation_sequence(plan)
    require(set(sequence) == set(expected) and len(sequence) == len(expected), "Operation plan differs from result cells")
    for event in _rows(run / "events.jsonl"):
        name = event.get("operation")
        require(name in expected and name not in observed and isinstance(event.get("utc"), str), "Unknown/repeated event")
        require(len(observed) < len(sequence) and name == sequence[len(observed)], "Operation order contradicts frozen execution/causal sequence")
        if event.get("event") == "started":
            require(started is None and set(event) == {"operation", "utc", "event"}, "Overlapping/invalid operation start")
            started = name
        else:
            require(event.get("event") == "completed" and started == name, "Failed/unpaired operation cannot complete an archive")
            data = {k: v for k, v in event.items() if k not in ("operation", "utc", "event")}
            timing(data)
            require(data == expected[name], "Event timing differs from operation artifact")
            observed.add(name); started = None
    require(started is None and observed == set(expected), "Missing operation cost events")
    wall = _read(run / "run_timing.json")
    _number(wall.get("host_wall_seconds"), "run wall seconds")
    require(wall.get("charged_work") == plan["counts"] and wall.get("no_speedup_claim") is True and
            wall.get("provider_cost_cny") is None, "Work/cost claims differ; provider money is unobserved")


def analyze_run(run, output, data_root=ROOT, *, bootstrap_samples=2000, allow_fixture=False):
    run, output = run.resolve(), output.resolve()
    require(not output.exists() and not output.is_relative_to(run) and not run.is_relative_to(output), "Analysis needs a fresh directory outside run")
    config, manifest, evidence, _ = completed(run, allow_fixture=allow_fixture)
    plan = verify_plan(run / "plan.json", data_root)
    contexts, grouped, queries, labels, artifacts = _data(config, data_root / MANIFEST, MANIFEST_SHA256,
                                                        data_root, plan["task"], "smoke8k", "development")
    replays = check_config(config, contexts, grouped, plan)
    model, masks, builds = validate_captures(run, config, contexts, replays)
    cells = validate_results(run, config, contexts, grouped, queries, masks, model)
    validate_events(run, plan, builds, _rows(run / "results.jsonl"))
    score_rows, values, summaries = [], {}, []
    for arm in ARMS:
        evaluated = metrics.evaluate(cells[arm], labels)
        for item in evaluated["per_example"]:
            qid = item["question_id"]
            row = {"context_id": queries[qid]["context_id"], "question_id": qid,
                   "arm": arm, "diagnostic_only": arm in ORACLES, "score": item["score"]}
            score_rows.append(row); values[(qid, arm)] = item["score"]
        stats = cluster_bootstrap([{**r, "value": r["score"]} for r in score_rows if r["arm"] == arm], samples=bootstrap_samples, seed=SEED)
        summaries.append({"arm": arm, "diagnostic_only": arm in ORACLES, "quality": stats, "mean_score_percent": 100 * stats["mean"]})
    paired = [{**r, "delta_vs_first": r["score"] - values[(r["question_id"], "first")],
               "delta_vs_fullkv": r["score"] - values[(r["question_id"], "fullkv")],
               "delta_vs_pooled_full_map_oracle": r["score"] - values[(r["question_id"], "pooled_full_map_oracle")]} for r in score_rows]
    for summary in summaries:
        for comparison in ("delta_vs_first", "delta_vs_fullkv", "delta_vs_pooled_full_map_oracle"):
            stats = cluster_bootstrap([{**r, "value": r[comparison]} for r in paired if r["arm"] == summary["arm"]],
                                      samples=bootstrap_samples, seed=SEED)
            summary[comparison] = {**stats, "mean_percentage_points": 100 * stats["mean"]}
    # Confounded contexts remain in every raw quality denominator. Never select
    # only the cells with favorable outcomes or clean arithmetic after observing
    # results. These flags license an allocation interpretation, not a benefit.
    contrasts = {context.context_id: builds[context.context_id]["diagnostics"]
                 ["allocation_diagnostic"]["regional_contrast"] for context in contexts}
    for row in paired:
        row["pure_regional_contrast_interpretable"] = contrasts[row["context_id"]]["pure_regional_contrast_interpretable"]
    all_interpretable = all(c["pure_regional_contrast_interpretable"] for c in contrasts.values())
    regional_summary = next(s for s in summaries if s["arm"] == "scale_map_oracle")
    regional_contrast = {
        "regional_arm": "scale_map_oracle", "pooled_arm": "pooled_full_map_oracle",
        "raw_paired_quality_delta": regional_summary["delta_vs_pooled_full_map_oracle"],
        "context_audits": contrasts,
        "all_contexts_pure_regional_contrast_interpretable": all_interpretable,
        "confounded_context_ids": sorted(cid for cid, c in contrasts.items() if not c["pure_regional_contrast_interpretable"]),
        "cohort_selection": "All frozen contexts/questions retained; no post-hoc clean-cell subset or extra generation",
        "interpretation": ("Histogram/order/budget/untied-cutoff checks pass; oracle regional-allocation contrast only, without a benefit or causal-content claim"
                           if all_interpretable else
                           "Pure regional attribution is confounded; raw quality delta is descriptive only, not evidence of a clean regional mechanism"),
        "model_quality_benefit_established": False,
    }
    result = {"schema": SCHEMA, "status": "validated_quality_only", "run_id": evidence.run_id,
              "evidence_kind": evidence.payload["evidence_kind"], "fixture_only": evidence.payload["evidence_kind"] == "cpu_fixture",
              "task": plan["task"], "preset": "smoke8k", "split": "development", "metric": metrics.METRIC,
              "denominators": {"contexts": len(contexts), "questions": len(queries), "arms": len(ARMS), "result_cells": len(score_rows)},
              "bootstrap": {"unit": "actual context_id", "samples": bootstrap_samples, "seed": SEED,
                            "estimand": "question-weighted mean", "interpretation": "exploratory paired context-cluster percentile; one cluster has no interval"},
              "arms": summaries, "regional_contrast": regional_contrast,
              "performance_export": "none; recorded costs are instrumented measurements, provider money is unobserved",
              "limitations": ["Tiny development-only mechanism screen; no power/equivalence/generalization claim",
                  "First/uniform/random are common-microchunk adaptations, not unchanged author EchoPress",
                  "Full-exact labels are expensive diagnostic references, never downstream importance gold",
                  "Pooled/regional full-label contrast is flagged when actual multiset equality fails or either cutoff has ambiguous membership, including within-head token swaps; ties are never split using exact ranks",
                  "Even a clean positive oracle contrast does not establish content causality, sparse-map estimability, novelty or deployable benefit; scale/rank deltas are not additive",
                  "Oracles preserve anchor/prefix/protection and use independent dense query clones; no rescoring",
                  "FullKV/control/oracle masks share paid builds; no independent deployable timing attribution",
                  "Masked dense caches demonstrate no physical-memory savings or serving speedup",
                  "Hash integrity is not source authenticity or proof of real model execution"]}
    provenance = {"manifest_sha256": sha256_file(run / "manifest.json"), "plan_sha256": plan["plan_sha256"],
                  "data_manifest_sha256": MANIFEST_SHA256, "metric_source_sha256": sha256_file(Path(metrics.__file__)),
                  "analysis_source_sha256": sha256_file(Path(__file__)), "input_artifacts": artifacts,
                  "source_sha256": manifest["source_sha256"], "run_artifact_sha256": manifest["artifact_sha256"]}
    output.mkdir(parents=True)
    _write(output / "summary.json", result); _write(output / "provenance.json", provenance)
    import json
    for name, rows in (("question_scores.jsonl", score_rows), ("paired_questions.jsonl", paired)):
        (output / name).write_text("".join(json.dumps(r, sort_keys=True, allow_nan=False) + "\n" for r in rows))
    _write(output / "ANALYSIS_COMPLETE.json", {"schema": SCHEMA, "status": "validated_quality_only", "run_id": evidence.run_id,
             "artifact_sha256": {p.name: sha256_file(p) for p in sorted(output.iterdir())}})
    return result
