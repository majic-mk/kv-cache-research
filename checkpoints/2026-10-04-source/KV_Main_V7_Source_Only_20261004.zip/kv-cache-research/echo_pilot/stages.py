"""CPU-only frozen workload preparation and read-only cost-scenario admission.

No provider client, subprocess, model dependency, execution flag, or controller is
imported or called here. A planning admission is never authority to rent or run.
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from pathlib import Path

from . import BACKEND_COMMIT
from .configure import MODEL_REVISION, make_config
from .contracts import (ContractError, canonical_hash, exact_keys,
                        positive_int, prepare_context, read_jsonl, require,
                        sha256_file, validate_config, validate_inputs, validate_questions,
                        verified_path)

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = "configs/data/longbench_pilot.manifest.json"
MANIFEST_SHA256 = "b65d04dd86d433141cc24e749caba860c5fece976130795337b1388b1b915dbf"
DEFAULT_PLAN = "configs/stages/frozen_stages.json"
PROJECT_ID = "kv-research-20261003"
FIRST_PROMPT = "\n\nRepeat the previous context exactly."
LATER_PROMPT = "\n\nRepeat the part of the previous context exactly, starting with"
# Encoded once with the byte-pinned tokenizer and tokenizers==0.21.4. The
# optional verify --retokenize command independently checks these without weights.
FIRST_IDS = [271, 38718, 279, 3681, 2266, 6896, 13]
LATER_IDS = [271, 38718, 279, 949, 315, 279, 3681, 2266, 6896, 11, 5916, 448]
ARMS = ["fullkv", "echo", "kvzip", "kvzip_echo_partition"]
STAGES = (("smoke", "smoke8k", 0.5), ("development75", "pilot16k", 0.75))
SOURCE_HASHES = {
    "research/sources/echopress_39748e9/kvpress/presses/echo_press.py":
        "c1165408abec363b17201d56c4105873555b384b674819c7901df5d5c5c06b0b",
    "research/sources/echopress_39748e9/kvpress/presses/kvzip_press.py":
        "41b7cbbef0f670136b53ad946d7b939daa16dda4d7974e329a26691d096d4598",
}
COUNT_FIELDS = ("contexts", "questions", "cache_builds", "exact_replay_passes",
                "prefill_input_tokens", "exact_replay_input_tokens",
                "query_input_tokens", "max_generated_tokens", "model_loads")


def load_json(path: Path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ContractError("Nonfinite JSON: " + value)))


def publish(path: Path, value: dict):
    """Exclusive creation; never edit a frozen recipe or runtime config in place."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def replay_lengths(context_tokens: int, prefix_tokens: int, suffix_tokens: int,
                   echo_partition: bool, chunk_size: int = 2048) -> list[int]:
    """Mirror audited prepare(): prompt + suffix + previous postfix + chunk."""
    for value, name in ((context_tokens, "context_tokens"), (prefix_tokens, "prefix_tokens"),
                        (suffix_tokens, "suffix_tokens"), (chunk_size, "chunk_size")):
        positive_int(value, name, 0 if name == "prefix_tokens" else 1)
    remaining = context_tokens - prefix_tokens
    require(remaining > 0, "Empty context body")
    first_size = chunk_size - len(FIRST_IDS) - suffix_tokens if echo_partition else chunk_size
    require(first_size > 0, "Replay prompt consumes the entire first chunk")
    sizes = []
    while remaining:
        size = min(remaining, first_size if not sizes else chunk_size)
        sizes.append(size)
        remaining -= size
    return [size + suffix_tokens + (len(FIRST_IDS) if i == 0 else len(LATER_IDS) + min(8, sizes[i - 1]))
            for i, size in enumerate(sizes)]


def sum_counts(items):
    return {field: sum(item[field] for item in items) for field in COUNT_FIELDS}


def make_plan(repo: Path = ROOT) -> dict:
    """Derive the only two predeclared stages, without reading labels/results."""
    manifest_path = verified_path(repo, MANIFEST, MANIFEST_SHA256)
    manifest = load_json(manifest_path)
    verified_path(repo, "data_prep/prepare_longbench.py", manifest["preprocessor_sha256"])
    source_lock_path = verified_path(repo, "configs/data/longbench_sources.lock.json", manifest["source_lock_sha256"])
    source_lock = load_json(source_lock_path)
    require(manifest["tokenizer_revision"] == MODEL_REVISION, "Tokenizer revision mismatch")
    for path, digest in SOURCE_HASHES.items():
        verified_path(repo, path, digest)
    tokenizer_artifacts = {}
    for name, entry in source_lock["tokenizer"]["files"].items():
        path = "data_prep/local/tokenizer/" + name
        verified_path(repo, path, entry["sha256"])
        tokenizer_artifacts[path] = entry["sha256"]
    stages = []
    for stage_id, preset, ratio in STAGES:
        invocations = []
        for task in ("lcc", "repobench-p"):
            artifacts = manifest["presets"][preset]["artifacts"][task + ".development"]
            paths = {kind: verified_path(repo, artifacts[kind]["path"], artifacts[kind]["sha256"])
                     for kind in ("contexts", "questions")}
            partial = {"template": manifest["template"],
                       "truncation": {"policy": "reject", "max_context_tokens": 8192 if preset == "smoke8k" else 16384}}
            contexts = [prepare_context(row, partial) for row in read_jsonl(paths["contexts"])]
            require(len({c.context_id for c in contexts}) == len(contexts), "Duplicate context")
            question_rows = read_jsonl(paths["questions"])
            require(all("reference_texts" not in row for row in question_rows), "Runtime question input must remain gold-free")
            questions = validate_questions(question_rows, {c.context_id for c in contexts}, manifest["template"]["suffix_token_ids"])
            rows, builds = [], []
            for ci, context in enumerate(contexts):
                n = len(context.token_ids)
                qs = questions[context.context_id]
                rows.append({"context_id": context.context_id, "context_fingerprint": context.fingerprint(),
                             "context_tokens": n, "context_token_ids_sha256": canonical_hash(list(context.token_ids)),
                             "questions": [{"question_id": q["question_id"], "question_tokens": len(q["question_token_ids"]),
                                            "question_token_ids_sha256": canonical_hash(q["question_token_ids"])} for q in qs]})
                author = replay_lengths(n, context.prefix_length, len(manifest["template"]["suffix_token_ids"]), False)
                matched = replay_lengths(n, context.prefix_length, len(manifest["template"]["suffix_token_ids"]), True)
                for arm in ARMS:
                    replays = [] if arm == "fullkv" else matched[:1] if arm == "echo" else author if arm == "kvzip" else matched
                    builds.append({"build_id": f"c{ci:05d}-{arm}-r00", "context_id": context.context_id,
                                   "arm": arm, "eviction_ratio": 0.0 if arm == "fullkv" else ratio,
                                   "prefill_input_tokens": n, "exact_replay_input_lengths": replays,
                                   "query_input_tokens": sum(len(q["question_token_ids"]) for q in qs),
                                   "max_generated_tokens": 64 * len(qs)})
            counts = {"contexts": len(contexts), "questions": len(question_rows), "cache_builds": len(builds),
                      "exact_replay_passes": sum(len(b["exact_replay_input_lengths"]) for b in builds),
                      "prefill_input_tokens": sum(b["prefill_input_tokens"] for b in builds),
                      "exact_replay_input_tokens": sum(sum(b["exact_replay_input_lengths"]) for b in builds),
                      "query_input_tokens": sum(b["query_input_tokens"] for b in builds),
                      "max_generated_tokens": sum(b["max_generated_tokens"] for b in builds), "model_loads": 1}
            invocations.append({"task": task, "split": "development", "preset": preset,
                                "eviction_ratios": [ratio], "artifacts": artifacts,
                                "ordered_contexts": rows, "ordered_builds": builds, "counts": counts})
        stages.append({"stage_id": stage_id, "release": "manual_review_required_not_released",
                       "requires": "CPU_and_resource_readiness_gate" if stage_id == "smoke" else "validated_all_arm_smoke_and_cost_review",
                       "invocations": invocations, "counts": sum_counts([i["counts"] for i in invocations])})
    payload = {"schema_version": 1, "status": "frozen_recipe_not_execution_config", "project_id": PROJECT_ID,
               "backend_commit": BACKEND_COMMIT, "model_revision": MODEL_REVISION,
               "data_manifest": {"path": MANIFEST, "sha256": MANIFEST_SHA256},
               "source_lock_sha256": manifest["source_lock_sha256"], "audited_sources": SOURCE_HASHES,
               "tokenizer_artifacts": tokenizer_artifacts,
               "replay_protocol": {"first_prompt_token_ids": FIRST_IDS, "later_prompt_token_ids": LATER_IDS,
                                   "prefix_tokens": len(manifest["template"]["prefix_token_ids"]),
                                   "suffix_tokens": len(manifest["template"]["suffix_token_ids"]),
                                   "previous_postfix_tokens": 8, "chunk_size": 2048},
               "common_policy": {"arms": ARMS, "max_new_tokens": 64, "warmup_builds": 0,
                                 "additional_repeat_builds": 0, "n_sink": 4, "recent_tokens": 0,
                                 "scoring_backend": "torch_eager", "attention_backend": "sdpa",
                                 "decoding": "greedy", "capture_scores": True},
               "selection_policy": "Existing frozen development artifacts in original order; no outcomes or labels used for selection; no heldout stage",
               "heldout_policy": "All 25 pilot16k heldout contexts remain locked; separate future protocol and release required",
               "budget_policy": {"currency": "CNY", "project_cap": "100", "first_gate_all_in_cap": "20",
                                 "first_gate_billable_seconds_cap": 14400, "provider_deadline_seconds": 14100,
                                 "soft_stop_fraction": "0.95", "useful_inference_deadline_seconds": 2700,
                                 "maximum_diagnosed_retries": 1, "accounting_basis": "resource_id_specific",
                                 "existing_autodl_resources": "entirely_off_limits"},
               "stages": stages, "counts": sum_counts([stage["counts"] for stage in stages]),
               "distinct_contexts": len({c["context_id"] for stage in stages for i in stage["invocations"] for c in i["ordered_contexts"]}),
               "distinct_questions": len({q["question_id"] for stage in stages for i in stage["invocations"] for c in i["ordered_contexts"] for q in c["questions"]}),
               "overlap_note": "Smoke contexts recur in development; summed context/question invocations are not independent sample counts",
               "interpretation": "Deterministic work counts, not measured latency, FLOPs, cost, quality, memory savings or statistical power"}
    return {**payload, "plan_sha256": canonical_hash(payload)}


def verify_plan(path: Path, repo: Path = ROOT, retokenize: bool = False) -> dict:
    plan = load_json(path)
    require(plan == make_plan(repo), "Frozen stage plan differs from pinned data/protocol; do not mutate a used recipe")
    if retokenize:
        from data_prep.prepare_longbench import load_tokenizer
        *_, encode = load_tokenizer(load_json(repo / "configs/data/longbench_sources.lock.json"), repo / "data_prep/local")
        require(encode(FIRST_PROMPT) == FIRST_IDS and encode(LATER_PROMPT) == LATER_IDS,
                "Reconstruction prompt tokenization mismatch")
    return plan


def find_invocation(plan, stage_id, task):
    found = [invocation for stage in plan["stages"] if stage["stage_id"] == stage_id
             for invocation in stage["invocations"] if invocation["task"] == task]
    require(len(found) == 1, "Choose one frozen development stage/task; heldout and arbitrary subsets are unavailable")
    return found[0]


def make_stage_config(plan_path: Path, stage_id: str, task: str, packages_lock: Path,
                      preprocessing_revision: str, output: Path, repo: Path = ROOT) -> dict:
    plan = verify_plan(plan_path, repo)
    invocation = find_invocation(plan, stage_id, task)
    require(not output.exists(), "Refusing to overwrite frozen config")
    lock = load_json(packages_lock)
    # Structural screening only. Actual complete installed inventory and CUDA
    # compatibility are verified by the execution preflight, never fabricated here.
    require(all(isinstance(v, str) and not any(term in v.lower() for term in ("fixture", "placeholder", "do-not-execute"))
                for v in lock.get("packages", {}).values()), "A fixture/placeholder lock cannot freeze an execution config")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="stage-config-", dir=output.parent) as tmp:
        temporary = Path(tmp) / "base.json"
        make_config(repo, repo / MANIFEST, packages_lock, preprocessing_revision, task,
                    "development", invocation["preset"], temporary)
        config = load_json(temporary)
        for obj, key in ((config["dataset"], "contexts_file"), (config["dataset"], "questions_file"),
                         (config["runtime"], "packages_lock_file")):
            obj[key] = os.path.relpath((temporary.parent / obj[key]).resolve(), output.parent.resolve())
        config["selection"]["eviction_ratios"] = invocation["eviction_ratios"]
        validate_config(config)
        require(config["arms"] == ARMS, "Frozen arm order changed")
        require(config["selection"] == {"eviction_ratios": invocation["eviction_ratios"], "n_sink": 4,
                "recent_tokens": 0, "chunk_size": 2048, "scoring_backend": "torch_eager"}, "Frozen selection policy changed")
        require(config["generation"] == {"max_new_tokens": 64, "decoding": "greedy"}, "Frozen generation policy changed")
        require(config["runtime"]["attention_backend"] == "sdpa" and config["runtime"]["capture_scores"]
                and config["runtime"]["deterministic_algorithms"] and config["runtime"]["seed"] == 20261003,
                "Frozen runtime policy changed")
        contexts, questions, _ = validate_inputs(config, output.parent)
        require([c.context_id for c in contexts] == [c["context_id"] for c in invocation["ordered_contexts"]], "Context order changed")
        require(config["model"]["id"] == "Qwen/Qwen3-8B" and config["model"]["tokenizer_id"] == "Qwen/Qwen3-8B"
                and config["model"]["revision"] == MODEL_REVISION and config["model"]["tokenizer_revision"] == MODEL_REVISION
                and config["model"]["dtype"] == "bfloat16", "Frozen model policy changed")
        for kind in ("contexts", "questions"):
            require(config["dataset"][kind + "_sha256"] == invocation["artifacts"][kind]["sha256"], "Frozen artifact digest changed")
        for context, expected in zip(contexts, invocation["ordered_contexts"], strict=True):
            require(context.fingerprint() == expected["context_fingerprint"], "Frozen context fingerprint changed")
            actual_questions = [{"question_id": q["question_id"], "question_tokens": len(q["question_token_ids"]),
                                 "question_token_ids_sha256": canonical_hash(q["question_token_ids"])} for q in questions[context.context_id]]
            require(actual_questions == expected["questions"], "Frozen questions changed")
        publish(output, config)
    return {"status": "config_frozen_not_executed", "stage_id": stage_id, "task": task,
            "plan_sha256": plan["plan_sha256"], "config_sha256": sha256_file(output), "counts": invocation["counts"],
            "runtime_inventory_verified": False, "execution_authorized": False}


def decimal_value(value, where, *, positive=False):
    require(isinstance(value, str), where + " must be a decimal string, not binary float/bool")
    try:
        result = Decimal(value)
    except InvalidOperation as exc:
        raise ContractError(where + " must be a finite decimal") from exc
    require(result.is_finite() and (result > 0 if positive else result >= 0), where + " must be finite and nonnegative (positive for rates)")
    return result


def decimal_text(value):
    return format(value, "f")


def estimate_admission(plan: dict, request: dict) -> dict:
    """Arithmetic on an already verified plan and explicit cost assumptions; no I/O/action."""
    require(isinstance(plan, dict) and plan.get("plan_sha256") == canonical_hash({k: v for k, v in plan.items() if k != "plan_sha256"}), "Plan digest mismatch")
    exact_keys(request, {"schema_version", "evidence", "project_id", "resource_id", "resource_origin",
                         "off_limits_resource_ids", "project_resource_ids", "accounting_basis", "billing_events",
                         "useful_inference_record",
                         "invocations", "proposed_resource_all_in_budget_cny", "quote_scenario", "runtime_scenario"}, set(), "scenario")
    require(type(request["schema_version"]) is int and request["schema_version"] == 1, "Unknown scenario schema")
    require(request["evidence"] == "scenario_not_measurement", "All rate/runtime assumptions must be labeled scenario_not_measurement")
    require(request["project_id"] == PROJECT_ID, "Project ID mismatch")
    require(request["resource_origin"] == "new_project_resource_only", "Existing resources are entirely off limits")
    resource = request["resource_id"]
    require(isinstance(resource, str) and bool(resource.strip()), "A specific proposed resource ID is required")
    for field in ("off_limits_resource_ids", "project_resource_ids"):
        ids = request[field]
        require(isinstance(ids, list) and all(isinstance(x, str) and x.strip() for x in ids) and len(ids) == len(set(ids)), field + " must contain unique resource IDs")
    allowed = set(request["project_resource_ids"])
    require(resource in allowed, "Target must be an explicitly identified project resource")
    require(not allowed.intersection(request["off_limits_resource_ids"]), "Project resources overlap off-limits resources")
    require(request["accounting_basis"] == "resource_id_specific", "Account balance deltas are not project accounting")
    budget = decimal_value(request["proposed_resource_all_in_budget_cny"], "proposed resource budget", positive=True)
    require(budget <= Decimal("20"), "First-gate resource proposal cannot exceed CNY20 all-in")
    project_cost = gate_cost = target_cost = Decimal(0)
    elapsed = target_elapsed = 0
    seen = set()
    require(isinstance(request["billing_events"], list), "billing_events must be a list")
    for event in request["billing_events"]:
        exact_keys(event, {"resource_id", "event_id", "gate_id", "status", "all_in_cny", "billable_seconds"}, set(), "billing event")
        require(event["resource_id"] in allowed, "Unattributed or off-limits resource bill")
        require(isinstance(event["event_id"], str) and bool(event["event_id"]) and event["event_id"] not in seen, "Billing event IDs must be unique; replace reconciled reserve instead of double counting")
        seen.add(event["event_id"])
        require(isinstance(event["gate_id"], str) and bool(event["gate_id"]), "Billing gate ID required")
        require(event["status"] in ("settled", "unsettled_reserve"), "Unknown bill status")
        positive_int(event["billable_seconds"], "billable_seconds", 0)
        amount = decimal_value(event["all_in_cny"], "all_in_cny")
        project_cost += amount
        if event["resource_id"] == resource:
            target_cost += amount
        if event["gate_id"] == "first_gate":
            gate_cost += amount
            elapsed += event["billable_seconds"]
            if event["resource_id"] == resource:
                target_elapsed += event["billable_seconds"]
    inference = request["useful_inference_record"]
    if inference is not None:
        exact_keys(inference, {"resource_id", "evidence_id", "first_success_billable_seconds",
                               "first_success_gate_billable_seconds"}, set(), "useful inference record")
        require(inference["resource_id"] == resource, "Useful inference evidence must belong to this target resource")
        require(isinstance(inference["evidence_id"], str) and bool(inference["evidence_id"]), "Useful inference evidence ID required")
        positive_int(inference["first_success_billable_seconds"], "first_success_billable_seconds")
        require(inference["first_success_billable_seconds"] < 2700, "Useful inference was not established within its 45-minute gate")
        require(inference["first_success_billable_seconds"] <= target_elapsed,
                "Useful inference timestamp exceeds this target resource's accounted first-gate runtime")
        positive_int(inference["first_success_gate_billable_seconds"], "first_success_gate_billable_seconds")
        local_success = inference["first_success_billable_seconds"]
        gate_success = inference["first_success_gate_billable_seconds"]
        require(local_success <= gate_success < 2700,
                "Useful inference shared first-gate timestamp must include target time and remain below 45 minutes")
        require(gate_success <= elapsed, "Useful inference shared timestamp exceeds accounted first-gate runtime")
        require(gate_success - local_success <= elapsed - target_elapsed,
                "Useful inference shared/local timestamp difference exceeds other-resource accounted first-gate runtime")
    quote = request["quote_scenario"]
    exact_keys(quote, {"compute_cny_per_hour", "ancillary_cny_per_hour", "one_time_cny",
                       "unbilled_reserve_cny", "billing_quantum_seconds"}, set(), "quote scenario")
    q = {k: decimal_value(v, k, positive=(k == "compute_cny_per_hour")) for k, v in quote.items() if k != "billing_quantum_seconds"}
    positive_int(quote["billing_quantum_seconds"], "billing_quantum_seconds")
    runtime = request["runtime_scenario"]
    rates = {"prefill_tokens_per_second": "prefill_input_tokens", "replay_tokens_per_second": "exact_replay_input_tokens",
             "query_tokens_per_second": "query_input_tokens", "generated_tokens_per_second": "max_generated_tokens"}
    exact_keys(runtime, set(rates) | {"setup_seconds", "model_load_seconds_per_invocation", "overhead_seconds_per_build", "shutdown_reserve_seconds"}, set(), "runtime scenario")
    r = {k: decimal_value(v, k, positive=(k in rates)) for k, v in runtime.items()}
    require(r["shutdown_reserve_seconds"] >= 300, "Reserve at least five minutes for shutdown/billing lag")
    requested = request["invocations"]
    require(isinstance(requested, list) and requested, "At least one frozen invocation required")
    selected, seen = [], set()
    for item in requested:
        exact_keys(item, {"stage_id", "task"}, set(), "invocation")
        identity = (item["stage_id"], item["task"])
        require(identity not in seen, "Duplicate invocation; extra repeats require a separately frozen plan")
        seen.add(identity)
        selected.append(find_invocation(plan, *identity))
    counts = sum_counts([item["counts"] for item in selected])
    # Admission for an unproven resource must budget through a useful answer, not
    # just model loading. Use the first requested invocation's frozen first build
    # and first question, at its worst-case output cap. This conservatively
    # includes all first-build overhead and one decode-rate charge per output,
    # although its first output is already produced by the query forward.
    first_build = selected[0]["ordered_builds"][0]
    first_question = selected[0]["ordered_contexts"][0]["questions"][0]
    first_answer_components = {
        "setup": r["setup_seconds"],
        "model_load": r["model_load_seconds_per_invocation"],
        "build_overhead": r["overhead_seconds_per_build"],
        "prefill": Decimal(first_build["prefill_input_tokens"]) / r["prefill_tokens_per_second"],
        "exact_replay": Decimal(sum(first_build["exact_replay_input_lengths"])) / r["replay_tokens_per_second"],
        "query": Decimal(first_question["question_tokens"]) / r["query_tokens_per_second"],
        "generation_cap": Decimal(plan["common_policy"]["max_new_tokens"]) / r["generated_tokens_per_second"],
    }
    first_answer_seconds = sum(first_answer_components.values())
    components = {key: Decimal(counts[field]) / r[key] for key, field in rates.items()}
    components["setup"] = r["setup_seconds"]
    components["model_loads"] = Decimal(counts["model_loads"]) * r["model_load_seconds_per_invocation"]
    components["build_overhead"] = Decimal(counts["cache_builds"]) * r["overhead_seconds_per_build"]
    seconds = sum(components.values())
    inclusive_seconds = seconds + r["shutdown_reserve_seconds"]
    quantum = Decimal(quote["billing_quantum_seconds"])
    billed_seconds = (inclusive_seconds / quantum).to_integral_value(rounding=ROUND_CEILING) * quantum
    hourly = q["compute_cny_per_hour"] + q["ancillary_cny_per_hour"]
    cost = billed_seconds * hourly / 3600 + q["one_time_cny"] + q["unbilled_reserve_cny"]
    available = min(Decimal("19") - gate_cost, budget * Decimal("0.95") - target_cost,
                    Decimal("100") - project_cost)
    money_seconds = max(Decimal(0), (available - q["one_time_cny"] - q["unbilled_reserve_cny"]) * 3600 / hourly)
    remaining_seconds = min(Decimal(max(0, 14100 - elapsed)), (money_seconds // quantum) * quantum)
    reasons = []
    if elapsed + billed_seconds > 14100:
        reasons.append("would exceed 3h55m conservative first-gate provider deadline (4h hard cap)")
    if gate_cost + cost > Decimal("19"):
        reasons.append("would exceed 95% of the CNY20 first-gate all-in cap")
    if target_cost + cost > budget * Decimal("0.95"):
        reasons.append("would exceed 95% of this resource-ID-specific proposal")
    if project_cost + cost > Decimal("100"):
        reasons.append("would exceed cumulative CNY100 project ceiling")
    # Counts/rates are assumptions, never evidence that inference has succeeded.
    # Account for all prior first-gate resource time without resetting the gate.
    if inference is None and Decimal(elapsed) + first_answer_seconds >= 2700:
        reasons.append("first complete answer scenario cannot fit the 45 minutes useful-inference gate")
    return {"schema_version": 1, "evidence": "scenario_not_measurement", "status": "planning_admitted" if not reasons else "planning_rejected",
            "execution_authorized": False, "paid_resource_action_performed": False,
            "resource_identity_and_quotes_externally_verified": False, "provider_stop_control_verified": False,
            "project_id": PROJECT_ID, "resource_id": resource, "plan_sha256": plan["plan_sha256"],
            "scenario_sha256": canonical_hash(request), "counts": counts,
            "scenario_runtime_components_seconds": {k: decimal_text(v) for k, v in components.items()},
            "scenario_first_answer_components_seconds": {k: decimal_text(v) for k, v in first_answer_components.items()},
            "scenario_first_answer_seconds_from_now": decimal_text(first_answer_seconds),
            "scenario_first_answer_gate_billable_seconds": decimal_text(Decimal(elapsed) + first_answer_seconds),
            "scenario_first_answer_identity": {"stage_id": requested[0]["stage_id"], "task": requested[0]["task"],
                                               "build_id": first_build["build_id"], "question_id": first_question["question_id"]},
            "useful_inference_evidence_externally_verified": False,
            "scenario_workload_seconds": decimal_text(seconds), "scenario_billable_seconds_including_reserve": decimal_text(billed_seconds),
            "scenario_incremental_all_in_cny": decimal_text(cost), "existing_project_accounted_cny": decimal_text(project_cost),
            "existing_first_gate_accounted_cny": decimal_text(gate_cost), "existing_first_gate_billable_seconds": elapsed,
            "existing_target_first_gate_billable_seconds": target_elapsed,
            "remaining_conservative_billable_seconds": decimal_text(remaining_seconds),
            "projected_project_all_in_cny": decimal_text(project_cost + cost), "rejection_reasons": reasons,
            "required_before_any_paid_action": ["Actual new project resource ID and current quote verified; all existing AutoDL resources excluded",
                "Provider-specific shutdown and external control verified before workload; Python timeout is insufficient",
                "Resource-specific settled/unsettled accounting reconciled; no account balance deltas",
                "All CPU/environment/assets/source gates and prior stage evidence manually reviewed",
                "Stop after 45 paid minutes without useful inference; at most one diagnosed retry within unchanged caps"],
            "limitations": ["Linear throughput assumptions are scenarios, not measured runtime guarantees or FLOPs",
                            "Generation uses the worst-case token cap; per-build overhead must cover cloning, masking, capture and serialization",
                            "Setup/download and every independent model load are charged; stop and verify resource status before prolonged analysis",
                            "Planning multiple stages does not release or automatically advance any stage"]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=ROOT)
    sub = parser.add_subparsers(dest="command", required=True)
    freeze = sub.add_parser("freeze", help="create a new frozen two-stage recipe without model execution")
    freeze.add_argument("--output", type=Path, required=True)
    verify = sub.add_parser("verify", help="read-only recomputation against pinned inputs")
    verify.add_argument("--plan", type=Path, default=ROOT / DEFAULT_PLAN)
    verify.add_argument("--retokenize", action="store_true")
    config = sub.add_parser("make-config", help="freeze one task config using an independently prepared real environment lock")
    config.add_argument("--plan", type=Path, default=ROOT / DEFAULT_PLAN)
    config.add_argument("--stage", choices=[x[0] for x in STAGES], required=True)
    config.add_argument("--task", choices=["lcc", "repobench-p"], required=True)
    config.add_argument("--packages-lock", type=Path, required=True)
    config.add_argument("--preprocessing-revision", required=True)
    config.add_argument("--output", type=Path, required=True)
    estimate = sub.add_parser("estimate", help="read-only scenario admission; never provisions or controls resources")
    estimate.add_argument("--plan", type=Path, default=ROOT / DEFAULT_PLAN)
    estimate.add_argument("--scenario", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "freeze":
            plan = make_plan(args.repo)
            publish(args.output, plan)
            result = {"status": "frozen_not_executed", "plan_sha256": plan["plan_sha256"], "counts": plan["counts"]}
        elif args.command == "verify":
            plan = verify_plan(args.plan, args.repo, args.retokenize)
            result = {"status": "verified_not_executed", "plan_sha256": plan["plan_sha256"], "counts": plan["counts"],
                      "stages": [{"stage_id": s["stage_id"], "counts": s["counts"]} for s in plan["stages"]]}
        elif args.command == "make-config":
            result = make_stage_config(args.plan, args.stage, args.task, args.packages_lock,
                                       args.preprocessing_revision, args.output, args.repo)
        else:
            result = estimate_admission(verify_plan(args.plan, args.repo), load_json(args.scenario))
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 2 if result["status"] == "planning_rejected" else 0
    except (ContractError, ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(2, f"stage preparation rejected: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
