# EchoPress baseline diagnostic pilot

**State: CPU contract/mock tests only. GPU adapter, weights, model inference, CUDA numerical parity, baseline quality and speed have not been run.** This package is a prepared experiment, not evidence for the regional score-transfer hypothesis.

## Scope and immutable backend

- Author repository: https://github.com/ljwljwljwljw/kvpress
- Exact commit: `39748e9c8301944128eb2e681bfb074e9a2de860`
- The tree reports 0.5.5 but includes post-release fixes. Installing only `kvpress==0.5.5` is rejected.
- Model/tokenizer first pilot: `Qwen/Qwen3-8B` at `b968826d9c46dd6066d109eabc6255188de91218`, BF16, a single visible CUDA device, one loaded model, batch size one.
- `torch_eager` virtual scoring, SDPA attention, author score storage precision, head-scoped virtual-to-exact calibration, no boundary guards, ordinary KVzip rather than KVzip+.
- The experiment reuses the author-KVPress chat pathway across every arm. LongBench LCC/RepoBench-P originally uses raw code completion; this is explicitly a **LongBench prompt adaptation**, not reproduction of its original raw-completion protocol. Exact replication of paper quality remains unverified.

Four mandatory arms:

1. `fullkv`: reference without eviction
2. `echo`: author EchoPress scoring, first exact replay and calibration
3. `kvzip`: author KVzip context-token partition
4. `kvzip_echo_partition`: exact KVzip reconstruction using EchoPress's first/later chunk boundaries and prompts, an explicitly named diagnostic adaptation

Full KV runs once per context; compressed methods rebuild independently for each eviction ratio. This favors clarity over minimizing pilot compute. No regional map, learned scorer, anchor policy, no-calibration ablation or float32-storage intervention is implemented yet. Full-reconstruction score tensors are diagnostic reference data, never deployable oracle inputs.

## Honest systems accounting

The pinned attention patch replaces evicted keys with fake keys during attention. It retains the original number of KV tensors and can raise if a nullifying hyperplane is not found. **It does not implement physical compaction, real KV-byte savings or a speedup.** A failure is recorded, not silently replaced by another masking implementation.

The runner records both the tensor view's KV payload and distinct backing-storage bytes. Sliced replay caches can retain a larger allocation than their visible shape, so storage can grow rather than stay equal. Logical retained pairs are never relabeled physical bytes. CUDA allocated/reserved and stage peaks are reported, plus per-query cache cloning and model-loading footprints. CPU RAM is not fully measured; captured diagnostic tensor bytes are a partial CPU-memory account.

Timing fields separately cover input/H2D setup, press/prefill/scoring, post-score capture/report, total builder excluding disk I/O, tensor serialization and the full arm including query/result I/O. GPU-stage boundaries are CUDA-synchronized; the full arm excludes its own timing-summary write and no fsync time is claimed. Hooks and CPU score copies are included in their corresponding measured interval. They are cold-run diagnostic timings without warmup or isolated-kernel claims. Replay pass count, complete replay input tokens (including prompts/suffix/postfix), and a dense causal attention-pair proxy are captured. The proxy is not measured FLOPs or compute matching.

## Correctness boundaries

- Compression receives only a `PreparedContext`; questions and labels are rejected in its schema. Questions are separate local inputs. The scoring API cannot inspect them.
- A fresh full context prefill is made for every build. Before each question the frozen context cache is deep-copied with disjoint storage and the build's mask is reinstalled. This is necessary because the author attention patch changes cached keys in-place. Separate clones also isolate metadata.
- All arms share exact token IDs, greedy generation, sink count and recent-token protection. `recent_tokens=0` preserves author defaults; a nonzero value is explicitly a common-policy adaptation, and its protected pairs consume the same total budget.
- Eviction is the author's floor-truncated global pair budget and two-stage torch top-k. Impossible protected budgets fail. Actual mask counts and protection are asserted. Global/layer cutoff ties, layer/head and layer/head/region retention are recorded; no stable tie-breaking equivalence is assumed.
- Context truncation is either `reject` or explicit right truncation. The default real-data generator uses reject. Removed ranges, original/retained lengths and token hashes are recorded; regions are clipped to exactly the retained span. Questions and generated lengths are never silently truncated.
- The author reconstructs with its own tokenizer loading that lacks a revision. A scoped adapter replaces only the two press modules' tokenizer factories with the already immutable-revision tokenizer. Prefix/suffix IDs and the canonical chat-template hash must match the frozen tokenized input contract.
- Empty bodies, singleton first anchors when mapping is required, insufficient first-replay budget, nonfinite scores, invalid masks and positional overflows fail. Scaled/dynamic RoPE, sliding-window caches, remote model code, quantized caches, multiple devices and other architectures are outside this first pilot.
- Greedy decoding stops if the first predicted token is EOS. This corrects a small upstream pipeline behavior consistently for all arms and is documented rather than called bit-identical pipeline generation.

## Inputs and strict schema

`python -m echo_pilot run --config CONFIG.json` validates without importing torch, Transformers or KVPress. Paths in CONFIG are relative to that file. Unknown fields are rejected to catch accidental configuration drift. Inputs are local JSONL; no dataset loader scripts are executed.

Context record fields:

- `context_id`, `source_id`: nonempty identifiers
- `context_token_ids`: complete frozen context segment, including the model's chat prefix
- `regions`: contiguous, nonoverlapping half-open token spans covering the post-prefix body; each has `region_id`, `label`, `start`, `end`

Question record fields:

- `context_id`, globally unique `question_id`
- `question_token_ids`: the future query segment including the exact frozen assistant/chat suffix; explicit answer prefixes are currently unsupported
- Optional `reference_texts` enables only raw string exact match after generation. Official benchmark scoring belongs in `data_prep.metrics`; the prepared LongBench inputs keep labels in a separate file

Dataset/model/tokenizer revisions and the local-origin preprocessing revision must be exact 40-character commits. Preprocessing content SHA-256 is authoritative across different source-transfer histories. Dataset files, full runtime package inventory and chat template are SHA-256 frozen. Fake IDs/tokens used in tests are labeled `fixture_only`; the inference entry point refuses fixture data.

## Future smoke workflow (not executed)

Read `INSTALL.md` first. After an actual environment has been installed and preprocessing code has an actual local Git commit:

```bash
python -m echo_pilot freeze-environment --output packages.lock.json
python -m echo_pilot make-config --packages-lock packages.lock.json \
  --preprocessing-revision ACTUAL_COMMIT_SHA --task lcc \
  --preset smoke8k --split development --output configs/pilot-lcc-smoke.json
python -m echo_pilot run --config configs/pilot-lcc-smoke.json
CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m echo_pilot preflight --config configs/pilot-lcc-smoke.json
```

`make-config` verifies preprocessing source bytes against the data manifest and records the original local-history commit as provenance. The commit value is operator-supplied local-origin provenance; its syntax is checked, while preprocessing content SHA-256 is verified. It does not require that commit to be an ancestor of a source-only transferred repository. Actual inference separately requires a clean committed checkout and records its actual HEAD through the shared evidence manifest. It defaults to **development only** and cannot combine development with heldout. `smoke8k` produces 2 LCC development contexts or 1 RepoBench-P development context, four arms at 50% eviction. It is a small compatibility smoke, not a statistically adequate research result. Use `--task repobench-p` for the separate 1-context smoke.

Only on an approved/provisioned GPU, after successful preflight:

```bash
CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m echo_pilot run --config configs/pilot-lcc-smoke.json \
  --output outputs/pilot-lcc-smoke --execute
```

No weights/tokenizers are downloaded by any runner command. They must have been separately staged at the exact revisions. Use `--preset pilot16k --split development` next only if smoke compatibility is established. Heldout requires an explicit `--split heldout`; don't inspect it for adaptive tuning. The prepared data manifest remains the authority for selected IDs and exclusion rules.

## Outputs

Fresh output directory required; no overwrite/resume or hidden retries.

- Frozen configuration, input plan, full package inventory, verified source hashes and resolved model/RoPE configuration
- `model_load.json`: parameter bytes and model-load device memory/time
- Per-build JSON: context fingerprint, truncation, chunks and replay token IDs, actual forward lengths, instrumentation-inclusive time/memory, allocation/tie counts
- Per-build `scores_masks.pt`: native-dtype score arrays before/after protection; Echo virtual author-storage arrays and pre-storage float32 chunk scores; first virtual/exact anchors where calibration occurs; exact masks and keep tensors. These are own-produced tensor containers; use `torch.load(..., weights_only=True)` to inspect
- `results.jsonl`: every raw generated token sequence, decoded/special-token text, context/question/build IDs, query clone and generation time/memory
- SHA-256 artifact manifest plus `COMPLETE.json` only after success; `FAILED.json` marks incomplete experiments

The outputs may contain dataset code/text and tokenized source. Preserve the source's research-use and redistribution restrictions; they are not intended for Git publication.

## Validation and remaining gates

```bash
python -m unittest discover -s echo_pilot/tests -v
python -m compileall -q echo_pilot
```

Synthetic/fixture tests check strict pins, hashes, query separation, exact truncation, budgets, clone disjointness, storage accounting, missing-dependency errors, dry-run isolation and explicit execution gating. They do **not** validate real CUDA hooks, numerical parity, exact tokenization/model behavior, real physical allocation, downstream quality or runtime compatibility. No model result is claimed.

Source files needed beyond the earlier audit are preserved with Apache-2.0 SPDX headers under `vendor_audit/`; each has verified Git blob and SHA-256 provenance. See the original license in `research/sources/echopress_39748e9/LICENSE`.

## Offline quality analysis bridge (CPU)

After a completed run has been copied back and the paid instance is stopped, run:

```bash
python -m echo_pilot analyze \
  --run outputs/pilot-lcc-smoke \
  --data-manifest configs/data/longbench_pilot.manifest.json \
  --data-manifest-sha256 b65d04dd86d433141cc24e749caba860c5fece976130795337b1388b1b915dbf \
  --data-root . --task lcc --preset smoke8k --split development \
  --output outputs/analysis-pilot-lcc-smoke \
  --bootstrap-samples 2000 --bootstrap-seed 20261003 --confidence 0.95
```

Use the **previously frozen** manifest digest, not a newly accepted digest after
changing data or seeing outcomes. The command needs no GPU, model weights,
Transformers, KVPress import or network. Reading actual `scores_masks.pt` archives
requires a CPU-capable installed PyTorch: it always uses
`torch.load(map_location="cpu", weights_only=True)`. Missing torch blocks real
archive analysis; it never silently falls back to trusting JSON mask counts.
This checkout's dependency-free tests use explicitly synthetic JSON mask
archives with `--allow-fixture`, `cpu_fixture` execution evidence and
`fixture_only` workload evidence. That test path cannot mark a result real-model.
The real PyTorch serialization path has now been exercised by 20 native CPU
tensor tests, with a separate 12-test tiny random-Qwen integration diagnostic.
See [current aggregate verification](../research/diagnostics/checkpoint_v2_20261003/README.md);
these remain CPU/synthetic evidence, not a completed real-model archive.

Inputs are one immutable completed run plus an explicit task, preset and split.
The data root resolves manifest-relative artifacts; copied frozen-config input
paths do not have to remain accessible. Labels are resolved and hash-checked
from the separate data manifest only during this offline analysis. No heldout
split is read implicitly, and no arm or ratio can be selected after inspecting
its score. The staged 75% development configuration uses the existing `pilot16k`
preset without changing the prepared-data artifacts.

Validation rejects a failed/incomplete run, tampered or unlisted artifacts,
symlink/path escapes, changed config/evidence/package/source pins, missing build
or result cells, duplicate questions/repeats within a cell, incorrect
context/query associations or fingerprints, query cache/generation lengths,
full-KV masks, wrong mask counts, duplicate/out-of-range coordinates, disagreement
between saved keep tensors and mask coordinates, protection violations, or
drift between Echo and partition-matched KVzip reconstruction boundaries/prompts.
The accepted identity is `(run, context_id, question_id, arm, eviction_ratio)`.
The format is tied to the recorded current runtime/contracts sources; analyzing
a changed runtime requires a separately reviewed reader, not relaxed validation.
Replay checks reconstruct the entire expected token sequence from pinned prompt
IDs, the previous chunk's last eight tokens, the chat suffix and current frozen
context slice, including native-KVzip versus Echo chunk-boundary differences.
Matching corruption in both comparison arms therefore still fails. New runs
archive the original package-lock bytes, preserving its configured digest even
when the input JSON uses noncanonical whitespace or key order.
Hashes establish internal integrity, **not** authenticity or proof of execution.

The fresh output directory, outside the original run, contains:

- `summary.json`: all arm/ratio means in percent, official pinned LongBench
  difflib code-similarity scores, paired differences, denominator and protocol
  records, exploratory context-cluster intervals and bootstrap configuration
- `question_scores.jsonl`: original per-question scores in [0,1], without an
  additional reporting-rounding step; the pinned metric itself has 1% resolution
- `paired_questions.jsonl`: every compressed question paired with its one full-KV
  measurement and same-ratio partition-matched KVzip measurement, plus build IDs
- `provenance.json`: frozen label/input hashes, data/run/config/evidence pins,
  original source/artifact hashes, metric and analyzer source hashes
- `ANALYSIS_COMPLETE.json`: output file digests and the separate execution
  (`real_model` or `cpu_fixture`) and workload (`natural`, etc.) evidence dimensions

The estimand is question-weighted task mean. Each bootstrap draw samples exactly
C whole contexts with replacement, carrying **all** questions in each sampled
context. Sorted context IDs and the same seed give shared paired draws across
cells. Full KV is measured once per context and reused as a reference; ratios,
questions and repeated references do not become additional independent contexts.
Repeats/duplicates are rejected rather than pooled. A single context receives
no confidence interval. Small-sample intervals are exploratory, have no
multiple-comparison adjustment, and cannot establish equivalence from a
nonsignificant gap. LCC and RepoBench-P stay separate. Empty decoded output from
an observed EOS is scored as zero, rather than dropped from the denominator.

This release is **quality-only**. It does not emit `kv_harness` performance
results, fabricate missing phase timings/memory/cost fields, relabel instrumented
cold timings as serving latency, or claim physical KV savings. Runtime timing
artifacts remain available for a separately specified measured-cost exporter.
