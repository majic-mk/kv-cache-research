"""Frozen development-only calibration screen; dry-run is the default.

This has a separate archive schema. It does not alter the four baseline arms,
provision a resource, download assets, or accept labels during model execution.
"""
from __future__ import annotations

import argparse
import copy
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import asdict
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import platform
import sys
import time
from datetime import datetime, timezone

from . import BACKEND_COMMIT
from .contracts import (ContractError, canonical_hash, exact_keys, hex_pin,
                        load_config, prepare_context, require, sha256_file,
                        validate_inputs)
from .stages import (FIRST_IDS, MANIFEST, MANIFEST_SHA256, MODEL_REVISION,
                     ROOT, find_invocation, load_json, make_plan as baseline_plan,
                     publish)

SCHEMA = "echo_calibration_experiment_v2"
LEGACY_SCHEMA = "echo_calibration_experiment_v1"
LEGACY_SOURCE_COMMIT = "c96b250f40fb484077a7761c338e49300189f529"
LEGACY_PLAN_SHA256 = {
    "lcc": "24e7eb3b775bd1818dda9691aa58708652b2cbf3185f280cb655244baa7214d5",
    "repobench-p": "428fde5ddeb49be1cb1fb558bc4cdf3c3d02e3971f282205cd58356e638ec7ee",
}
POLICIES = ("first", "uniform", "random")
ARMS = ("fullkv", "first", "uniform", "random", "no_calibration",
        "pooled_full_map_oracle", "scale_map_oracle", "rank_only_oracle", "full_exact_reference")
ORACLES = ("pooled_full_map_oracle", "scale_map_oracle", "rank_only_oracle", "full_exact_reference")
SEED = 20261003
RATIO = 0.5
ANCHOR_COUNT = 4
REPLAY_CAP = 2048
POLICY = {"eviction_ratio": RATIO, "seed": SEED, "anchor_count": ANCHOR_COUNT,
          "anchor_replay_token_cap": REPLAY_CAP, "n_sink": 4, "recent_tokens": 0,
          "precision": {"anchor_virtual": "float32", "nonanchor_virtual": "float32",
                        "exact_anchor": "float32", "output": "float32"},
          "tie_policy": "author_left", "clipping": "clip", "tie_break": "stable",
          "max_new_tokens": 64, "warmup_builds": 0, "repeat_builds": 0}
DIAGNOSTIC_PROTOCOL = {
    "version": "pooled_full_vs_regional_v1",
    "comparison": {"regional": "scale_map_oracle", "pooled": "pooled_full_map_oracle"},
    "score_inputs": "Identical captured virtual/full-exact vectors and first-anchor baseline; same original microchunk scoring/denominators/prompts/RoPE/backend",
    "fixed_set": "prefix union first-anchor positions union sink/recent protection, excluded before both map fits",
    "mutable_set": "All positions outside the fixed set; positional microchunk regions, not semantic classes",
    "mapper": "Independent sorted marginals; author_left float32 interpolation with 1e-12 denominator floor and endpoint clipping; shared declared storage/output casts",
    "pure_contrast_gate": "Nonempty mutable set, actual per-layer/head sorted pooled == regional == output-cast exact mutable multiset, preserved fixed scores/within-region weak order, identical head allocations, and no ambiguous pooled/regional cutoff membership (including within-head token swaps)",
    "failure_policy": "Fail implementation invariants; flag numerical/tie/multiset confounds, never split equal virtual knots using exact ranks or suppress failed contrast cells",
    "tie_sensitivities": {"selection_policies": ["stable", "reverse", "random"], "random_seed": SEED,
                          "scope": "Score/mask allocation only; no additional downstream generations"},
    "downstream_estimand": "Paired quality(scale_map_oracle) minus quality(pooled_full_map_oracle), all frozen questions/context clusters; raw delta retained even when confounded",
    "reuse": "One already charged full exact capture; zero additional prefills/reconstruction passes; one additional independent query-cache clone/generation per question",
    "claim_scope": "Diagnostic oracle intervention only; no novelty, deployable benefit, content-causality, additive scale/rank decomposition, generalization or physical-memory claim",
}
SOURCES = ("echo_pilot/calibration_experiment.py", "echo_pilot/calibration_experiment_analysis.py",
           "echo_pilot/calibration_runtime.py", "echo_pilot/runtime.py", "echo_pilot/contracts.py",
           "echo_pilot/stages.py", "echo_pilot/configure.py", "echo_pilot/analysis.py",
           "research/calibration_methods/contracts.py", "research/calibration_methods/methods.py",
           "research/calibration_methods/selection.py", "research/calibration_methods/diagnostics.py",
           "research/diagnostics/echo_calibration/reference.py", "data_prep/metrics.py")


def _write(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def _jsonable(value):
    return json.loads(json.dumps(value, sort_keys=True, allow_nan=False))


def frozen_replay(context, template, model):
    """Pure IDs from the pinned tokenizer artifacts; no tokenizer/model import.

    The real local tokenizer must independently reproduce this plan before any
    model weight is loaded. This constructor sees only PreparedContext/template.
    """
    from .calibration_runtime import FrozenReplayPlan
    from research.calibration_methods.contracts import Microchunk, Partition
    overhead = len(FIRST_IDS) + len(template["suffix_token_ids"])
    size = REPLAY_CAP // ANCHOR_COUNT - overhead
    require(size >= 2, "Prompt overhead leaves insufficient anchor knots")
    chunks = tuple(Microchunk(i, min(i + size, len(context.token_ids)), overhead)
                   for i in range(context.prefix_length, len(context.token_ids), size))
    regions = tuple([-1] * context.prefix_length +
                    [i for i, c in enumerate(chunks) for _ in range(c.end - c.start)])
    p = Partition(canonical_hash(context.token_ids), len(context.token_ids), context.prefix_length,
                  chunks, regions, "fixed_position", POLICY["n_sink"])
    replay_ids = tuple(tuple(FIRST_IDS) + tuple(template["suffix_token_ids"]) +
                       context.token_ids[c.start:c.end] for c in chunks)
    return FrozenReplayPlan(p, context.token_ids, tuple(FIRST_IDS), tuple(template["suffix_token_ids"]),
                            replay_ids, model["tokenizer_id"], model["tokenizer_revision"],
                            template["chat_template_sha256"])


def anchor_plans(replay):
    from research.calibration_methods.methods import plan_anchor_matrix
    return plan_anchor_matrix(replay.partition, ANCHOR_COUNT, REPLAY_CAP, random_seeds=(SEED,))


def _check_oracle_regions(replay, first):
    from research.calibration_methods.selection import protection_mask
    fixed = protection_mask(replay.partition, POLICY["recent_tokens"])
    fixed[:replay.partition.prefix_length] = True
    fixed[list(first.token_indices)] = True
    for i, c in enumerate(replay.partition.chunks):
        mutable = int((~fixed[c.start:c.end]).sum())
        require(mutable != 1, f"Frozen region {i} has a singleton oracle set; stop rather than retune partition")


def make_plan(task, repo=ROOT):
    """Exactly the existing smoke subset, no labels or outcome-based selection."""
    require(task in ("lcc", "repobench-p"), "Unknown screen task")
    bplan = baseline_plan(repo)
    invocation = find_invocation(bplan, "smoke", task)
    data = load_json(repo / MANIFEST)
    # Offline metric provenance must also be satisfiable before paying for GPU
    # work. Importing the metric implementation does not read any labels.
    from data_prep import metrics
    from .analysis import BENCHMARK_REVISION
    require(data["metric_implementation_sha256"] == sha256_file(repo / "data_prep/metrics.py") and
            data["benchmark_code_revision"] == BENCHMARK_REVISION and
            data["settings"]["metric"] == metrics.METRIC and
            data["settings"]["evidence_kind"] == "natural", "Pinned offline metric/data provenance differs")
    template = {**data["template"], "prompt_mode": "chat_adapted"}
    model = {"id": "Qwen/Qwen3-8B", "revision": MODEL_REVISION, "tokenizer_id": "Qwen/Qwen3-8B",
             "tokenizer_revision": MODEL_REVISION, "dtype": "bfloat16"}
    partial = {"template": template, "truncation": {"policy": "reject", "max_context_tokens": 8192}}
    from .contracts import read_jsonl
    contexts = [prepare_context(c, partial) for c in read_jsonl(repo / invocation["artifacts"]["contexts"]["path"])]
    rows = []
    for context, observed in zip(contexts, invocation["ordered_contexts"], strict=True):
        require(context.fingerprint() == observed["context_fingerprint"], "Stage/context mismatch")
        replay = frozen_replay(context, template, model)
        plans = anchor_plans(replay)
        _check_oracle_regions(replay, plans[0])
        rows.append({"context_id": context.context_id, "context_fingerprint": context.fingerprint(),
                     "replay": _jsonable(asdict(replay)), "replay_sha256": replay.fingerprint,
                     "anchors": [{"policy": p.policy, "seed": p.seed, "chunk_ids": list(p.chunk_ids),
                                  "sha256": p.fingerprint, "cost_proxy": p.cost()} for p in plans],
                     "questions": observed["questions"]})
    all_lengths = [[len(ids) for ids in r["replay"]["replay_token_ids"]] for r in rows]
    sparse_lengths = [[sum(len(r["replay"]["replay_token_ids"][i]) for i in p["chunk_ids"])
                       for p in r["anchors"]] for r in rows]
    counts = {"contexts": len(rows), "questions": invocation["counts"]["questions"],
              "independent_scoring_builds": 4 * len(rows), "model_loads": 1,
              "prefill_input_tokens": 4 * sum(r["replay"]["partition"]["token_count"] for r in rows),
              "sparse_exact_replay_passes": 3 * ANCHOR_COUNT * len(rows),
              "sparse_exact_replay_input_tokens": sum(map(sum, sparse_lengths)),
              "diagnostic_exact_replay_passes": sum(map(len, all_lengths)),
              "diagnostic_exact_replay_input_tokens": sum(map(sum, all_lengths)),
              "query_cache_clones": len(ARMS) * invocation["counts"]["questions"],
              "query_input_tokens": len(ARMS) * sum(q["question_tokens"] for r in rows for q in r["questions"]),
              "max_generated_tokens": len(ARMS) * POLICY["max_new_tokens"] * invocation["counts"]["questions"]}
    payload = {"schema": SCHEMA, "status": "frozen_not_executed", "task": task,
               "preset": "smoke8k", "split": "development", "backend_commit": BACKEND_COMMIT,
               "model": model, "template": template, "policy": POLICY, "arms": list(ARMS),
               "diagnostic_protocol": DIAGNOSTIC_PROTOCOL,
               "supersedes": {"schema": LEGACY_SCHEMA, "source_commit": LEGACY_SOURCE_COMMIT,
                              "plan_sha256": LEGACY_PLAN_SHA256[task]},
               "dataset_protocol": {"source_id": "zai-org/LongBench/" + task,
                                    "source_revision": data["source_revision"],
                                    "preprocessing_sha256": data["preprocessor_sha256"],
                                    "split": "development", "evidence_kind": "natural"},
               "data_manifest": {"path": MANIFEST, "sha256": MANIFEST_SHA256},
               "baseline_stage_plan_sha256": bplan["plan_sha256"],
               "artifacts": {k: v for k, v in invocation["artifacts"].items() if k != "labels"},
               "ordered_contexts": rows, "counts": counts,
               "cost_scope": "All three sparse builds and full exact diagnostic independently charged; reused masks never acquire deployable build timing",
               "claim_scope": "Tiny development-only mechanism screen; no significance, heldout, physical-memory or speedup claim",
               "release_gate": "Validated baseline plus resource-specific accounting evidence under existing approval; no resource is launched by this entrypoint"}
    payload = _jsonable(payload)  # Do not return aliases to module-level frozen controls.
    return {**payload, "plan_sha256": canonical_hash(payload)}


def verify_plan(path, repo=ROOT):
    plan = load_json(path)
    require(plan.get("schema") == SCHEMA,
            "Expected v2 screen plan; historical v1 plans are preserved and must not be relabeled or silently migrated")
    require(plan == make_plan(plan.get("task"), repo), "Frozen screen changed; arbitrary ratios/seeds/subsets/arms are unavailable")
    return plan


def check_protocol(config, plan):
    require(config["model"] == plan["model"] and config["template"] == plan["template"], "Model/tokenizer/template differs from screen")
    require(config["dataset"]["split"] == "development" and config["dataset"]["source_id"] == "zai-org/LongBench/" + plan["task"], "Wrong task/split")
    require(config["dataset"]["evidence_kind"] == "natural", "Only frozen natural development data may execute")
    require(all(config["dataset"][key] == value for key, value in plan["dataset_protocol"].items()),
            "Dataset source/preprocessor metadata differs from frozen screen")
    for kind in ("contexts", "questions"):
        require(config["dataset"][kind + "_sha256"] == plan["artifacts"][kind]["sha256"], "Wrong frozen input digest")
    require(config["selection"] == {"eviction_ratios": [RATIO], "n_sink": 4, "recent_tokens": 0,
            "chunk_size": 2048, "scoring_backend": "torch_eager"}, "Baseline config must be the unchanged smoke stage")
    require(config["generation"] == {"max_new_tokens": 64, "decoding": "greedy"} and
            config["truncation"] == {"policy": "reject", "max_context_tokens": 8192}, "Screen generation/truncation differs")
    require(config["runtime"]["seed"] == SEED and config["runtime"]["deterministic_algorithms"] is True, "Fixed deterministic seed required")


def check_config(config, contexts, questions, plan):
    check_protocol(config, plan)
    require(len(contexts) == len(plan["ordered_contexts"]), "Context count changed")
    replays = []
    for context, row in zip(contexts, plan["ordered_contexts"], strict=True):
        require(context.context_id == row["context_id"] and context.fingerprint() == row["context_fingerprint"], "Context ordering/content changed")
        qs = questions[context.context_id]
        require(all(set(q) == {"context_id", "question_id", "question_token_ids"} for q in qs), "Runtime labels are forbidden")
        require([{"question_id": q["question_id"], "question_tokens": len(q["question_token_ids"]),
                  "question_token_ids_sha256": canonical_hash(q["question_token_ids"])} for q in qs] == row["questions"], "Question order/content changed")
        replay = frozen_replay(context, plan["template"], plan["model"])
        require(_jsonable(asdict(replay)) == row["replay"], "Frozen replay differs")
        replays.append(replay)
    return replays


def check_baseline(run, analysis, plan):
    """Verify previously completed evidence without reading gold labels here."""
    from .analysis import _completed, _local, _read, _rows, _number
    config, manifest, evidence = _completed(run.resolve())
    require(evidence.payload["evidence_kind"] == "real_model", "Baseline must have actual model execution")
    check_protocol(config, plan)
    complete = _read(_local(analysis, "ANALYSIS_COMPLETE.json"))
    require(complete.get("status") == "validated_quality_only" and complete.get("run_id") == evidence.run_id, "Baseline analysis is not complete for this run")
    hashes = complete.get("artifact_sha256", {})
    require(set(hashes) == {"summary.json", "provenance.json", "question_scores.jsonl", "paired_questions.jsonl"}, "Unexpected baseline analysis artifacts")
    require({p.name for p in analysis.iterdir()} == set(hashes) | {"ANALYSIS_COMPLETE.json"}, "Incomplete/extra baseline analysis files")
    for name, digest in hashes.items():
        require(sha256_file(_local(analysis, name)) == digest, "Baseline analysis digest mismatch")
    provenance = _read(analysis / "provenance.json")
    summary = _read(analysis / "summary.json")
    require(provenance.get("run_manifest_sha256") == sha256_file(run / "manifest.json") and
            provenance.get("data_manifest_sha256") == MANIFEST_SHA256 and
            provenance.get("analysis_source_sha256") == sha256_file(ROOT / "echo_pilot/analysis.py"), "Baseline analysis provenance differs")
    require((summary.get("task"), summary.get("preset"), summary.get("split")) == (plan["task"], "smoke8k", "development"), "Baseline covers another stage/task")
    require(summary.get("status") == "validated_quality_only" and
            summary.get("evidence", {}).get("execution") == "real_model" and
            summary.get("evidence", {}).get("fixture_only") is False, "Baseline fixture cannot release model screen")
    require(config["model"] == plan["model"] and config["selection"]["eviction_ratios"] == [RATIO], "Baseline model/ratio mismatch")
    require({(row.get("arm"), row.get("eviction_ratio")) for row in summary.get("arms", [])} ==
            {("fullkv", 0.0), ("echo", RATIO), ("kvzip", RATIO), ("kvzip_echo_partition", RATIO)} and
            len(summary.get("arms", [])) == 4, "Baseline analysis omits a required arm")
    require(provenance.get("run_artifact_sha256") == manifest["artifact_sha256"] and
            provenance.get("config_canonical_sha256") == canonical_hash(config), "Baseline analysis input binding differs")
    require(all(config["dataset"][k + "_sha256"] == plan["artifacts"][k]["sha256"] for k in ("contexts", "questions")), "Baseline data differs")
    require(summary.get("run_id") == evidence.run_id and
            provenance.get("evidence_manifest_sha256") == evidence.sha256, "Baseline analysis run identity differs")
    expected = {}
    for ci, context in enumerate(plan["ordered_contexts"]):
        for q in context["questions"]:
            for arm in ("fullkv", "echo", "kvzip", "kvzip_echo_partition"):
                expected[(context["context_id"], q["question_id"], arm)] = f"c{ci:05d}-{arm}-r00"
    denominator = {"contexts": len(plan["ordered_contexts"]), "questions": plan["counts"]["questions"],
                   "builds": 4 * len(plan["ordered_contexts"]), "observed_result_cells": len(expected),
                   "fullkv_observations": plan["counts"]["questions"]}
    require(summary.get("denominators") == denominator, "Baseline analysis denominators differ")
    scored = {}
    for row in _rows(analysis / "question_scores.jsonl"):
        exact_keys(row, {"run_id", "task", "preset", "split", "context_id", "question_id", "arm", "eviction_ratio", "build_id", "score"}, set(), "baseline score")
        key = (row["context_id"], row["question_id"], row["arm"])
        require(key in expected and key not in scored and row["build_id"] == expected[key], "Missing/duplicate/wrong baseline score identity")
        require((row["run_id"], row["task"], row["preset"], row["split"]) ==
                (evidence.run_id, plan["task"], "smoke8k", "development"), "Baseline score scope differs")
        require(type(row["eviction_ratio"]) in (float, int) and row["eviction_ratio"] == (0. if row["arm"] == "fullkv" else RATIO), "Baseline score ratio differs")
        _number(row["score"], "baseline metric score")
        require(row["score"] <= 1, "Baseline score exceeds metric range")
        scored[key] = row
    require(set(scored) == set(expected), "Missing baseline score cells")
    paired = set()
    for row in _rows(analysis / "paired_questions.jsonl"):
        key = (row.get("context_id"), row.get("question_id"), row.get("arm"))
        require(key in scored and key not in paired and key[2] != "fullkv", "Unexpected/duplicate baseline paired cell")
        full_key, matched_key = (*key[:2], "fullkv"), (*key[:2], "kvzip_echo_partition")
        full, matched = scored[full_key]["score"], scored[matched_key]["score"]
        require(row == {**scored[key], "fullkv_score": full, "partition_matched_kvzip_score": matched,
            "delta_vs_fullkv": scored[key]["score"] - full,
            "delta_vs_partition_matched_kvzip": scored[key]["score"] - matched,
            "fullkv_reference_build_id": expected[full_key], "partition_matched_reference_build_id": expected[matched_key]},
            "Baseline paired score/reference differs")
        paired.add(key)
    require(paired == {k for k in expected if k[2] != "fullkv"}, "Missing baseline paired cells")
    return {"run_id": evidence.run_id, "manifest_sha256": sha256_file(run / "manifest.json"),
            "analysis_complete_sha256": sha256_file(analysis / "ANALYSIS_COMPLETE.json")}


def check_execution_record(record, plan, baseline):
    """Accounting declaration, not new approval or a provider spending controller."""
    exact_keys(record, {"schema", "plan_sha256", "baseline_manifest_sha256", "resource_id",
                       "resource_origin", "accounting_basis", "external_stop_verified",
                       "project_spent_cny", "remaining_project_cny", "screen_all_in_cap_cny",
                       "max_wall_seconds", "no_automatic_retry"}, set(), "execution record")
    require(record["schema"] == SCHEMA and record["plan_sha256"] == plan["plan_sha256"] and
            record["baseline_manifest_sha256"] == baseline["manifest_sha256"], "Execution accounting is for another plan/baseline")
    require(isinstance(record["resource_id"], str) and record["resource_id"].strip() and
            record["resource_origin"] == "new_project_resource_only" and
            record["accounting_basis"] == "resource_id_specific", "Existing AutoDL resources are off limits")
    require(record["external_stop_verified"] is True and record["no_automatic_retry"] is True, "External stop and no automatic retry required")
    vals = []
    for key in ("project_spent_cny", "remaining_project_cny", "screen_all_in_cap_cny"):
        require(isinstance(record[key], str), "CNY accounting must use decimal strings")
        try:
            v = Decimal(record[key])
        except InvalidOperation as exc:
            raise ContractError("Invalid CNY decimal") from exc
        require(v.is_finite() and v >= 0, "Invalid CNY accounting")
        vals.append(v)
    spent, remaining, cap = vals
    require(spent + remaining <= 100 and 0 < cap <= min(remaining, Decimal("20")), "Screen exceeds existing remaining approval/cap")
    require(type(record["max_wall_seconds"]) is int and 0 < record["max_wall_seconds"] <= 2700,
            "Screen wall limit exceeds useful-inference window")
    return record


def operation_sequence(plan):
    """The exact single-worker sequence, independent of observed result order."""
    sequence = ["model_load"]
    for ci, context in enumerate(plan["ordered_contexts"]):
        def queries(arm):
            return [f"c{ci:05d}:{arm}:{q['question_id']}:{phase}"
                    for q in context["questions"] for phase in ("clone_install", "generate")]
        for arm in POLICIES:
            sequence.append(f"c{ci:05d}:{arm}:build")
            sequence.extend(queries(arm))
        sequence.extend((f"c{ci:05d}:full_exact:build", f"c{ci:05d}:diagnostic_mask_transforms"))
        for arm in ("fullkv", "no_calibration", *ORACLES):
            sequence.extend(queries(arm))
    return sequence


def source_hashes():
    return {name: sha256_file(ROOT / name) for name in SOURCES}


def _event(stream, event, **fields):
    stream.write(json.dumps({"event": event, "utc": datetime.now(timezone.utc).isoformat(), **fields},
                            sort_keys=True, allow_nan=False) + "\n")
    stream.flush()


def timed_call(torch, events, operation, call, deadline):
    """Measured synchronized envelope; failure retains host elapsed and ledger."""
    from .runtime import synchronized_time, memory_snapshot
    require(time.monotonic() < deadline, "Local inference deadline reached; stop, no retry")
    torch.cuda.reset_peak_memory_stats(0)
    _event(events, "started", operation=operation)
    host_start = time.perf_counter()
    value = None  # The envelope owns successful results until all checks pass.
    try:
        started = synchronized_time(torch)
        value = call()
        ended = synchronized_time(torch)
        stats = {"synchronized_wall_seconds": ended - started,
                 "host_wall_seconds": time.perf_counter() - host_start,
                 "memory": memory_snapshot(torch)}
        require(time.monotonic() < deadline, "Operation crossed local inference deadline; stop, no retry")
        _event(events, "completed", operation=operation, **stats)
        return value, stats
    except BaseException as exc:
        accounting = getattr(exc, "accounting", None)
        if accounting is None and getattr(value, "accounting", None) is not None:
            accounting = copy.deepcopy(value.accounting)
            accounting["operation_envelope_status"] = "failed_after_scoring"
            accounting["operation_envelope_error_type"] = type(exc).__name__
            exc.accounting = accounting
        # The caller never acquired this successful build if a synchronization,
        # memory snapshot, deadline check or completion-log write failed.
        owned_cache = getattr(value, "cache", None)
        if owned_cache is not None:
            owned_cache.layers.clear()
        value = None  # Do not retain a model/build in this failure traceback frame.
        owned_cache = None
        try:
            _event(events, "failed", operation=operation, error_type=type(exc).__name__,
                   host_wall_seconds=time.perf_counter() - host_start,
                   attempted_forward_accounting=accounting)
        except Exception as log_error:
            exc.event_logging_error_type = type(log_error).__name__
        raise


def evaluate_mask(deps, model, tokenizer, base_cache, keep, query, context_length,
                  max_new_tokens, events, operation, deadline):
    """Every query, including dense/oracles, starts from an independent clone.

    This explicitly installs an existing mask. No builder, scorer, compress_post,
    candidate-label API or re-selection is invoked during downstream evaluation.
    """
    from .calibration_runtime import install_keep_mask
    from .runtime import independent_cache, clear_masks, greedy_answer, cache_bytes
    cache = None
    try:
        def clone():
            nonlocal cache
            cache = independent_cache(base_cache)
            # Empty coordinate triples still trigger upstream fake-key search.
            # Full KV must genuinely disable that mutation/search path.
            if bool(keep.all()):
                clear_masks(model)
            else:
                install_keep_mask(deps.torch, model, keep, cache)
            return cache
        _, clone_stats = timed_call(deps.torch, events, operation + ":clone_install", clone, deadline)
        answer, generation = timed_call(deps.torch, events, operation + ":generate",
            lambda: greedy_answer(deps.torch, model, tokenizer, query["question_token_ids"], cache,
                                  context_length, max_new_tokens), deadline)
        require(all(base_cache.get_seq_length(i) == context_length for i in range(len(base_cache.layers))), "Frozen base cache grew")
        return {**answer, "clone_install": clone_stats, "generation": generation,
                "query_cache": cache_bytes(cache)}
    finally:
        clear_masks(model)
        if cache is not None:
            cache.layers.clear()


def diagnostic_masks(first, diagnostic, replay):
    """Full labels flow only here, after all sparse candidates have been built."""
    import numpy as np
    from research.calibration_methods.diagnostics import make_oracles, compare_oracles
    from research.calibration_methods.methods import calibrate
    from research.calibration_methods.selection import select_logical
    require(np.array_equal(first.virtual.values, diagnostic.virtual.values),
            "Independent diagnostic virtual scores differ; no approximate oracle reuse is permitted")
    scores, provenance = make_oracles(first.virtual, first.calibration, diagnostic.full_exact, recent_tokens=0)
    no_cal = calibrate(first.virtual, first.anchors, precision=first.calibration.precision, enabled=False)
    scores["no_calibration"] = no_cal.scores
    masks, selections = {}, {}
    for name, values in scores.items():
        masks[name], selections[name] = select_logical(values, replay.partition, RATIO, seed=SEED)
    scores["fullkv"] = np.zeros_like(first.virtual.values)
    masks["fullkv"] = np.ones_like(first.keep_mask, dtype=bool)
    _, selections["fullkv"] = select_logical(scores["fullkv"], replay.partition, 0.0, seed=SEED)
    report = compare_oracles(first.virtual, first.calibration, diagnostic.full_exact, RATIO, seed=SEED)
    return scores, masks, selections, {"provenance": provenance, "allocation_diagnostic": report,
                                      "no_calibration": no_cal.diagnostics}


def execute(config, contexts, questions, lock, plan, replays, record, output):
    """Called only behind all clean-source/baseline/resource checks in run()."""
    import numpy as np
    from . import runtime as rt
    from .calibration_runtime import build_candidate, build_full_exact_diagnostic, prepare_common_replay
    deadline = time.monotonic() + record["max_wall_seconds"]
    deterministic = rt.deterministic_environment(config)
    deps = rt.load_dependencies()
    torch, hf = deps.torch, deps.transformers
    environment = rt.verify_environment(deps, lock)
    environment["deterministic_settings"] = deterministic
    _write(output / "environment.json", environment)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True)
    spec = config["model"]
    tokenizer = hf.AutoTokenizer.from_pretrained(spec["tokenizer_id"], revision=spec["tokenizer_revision"],
                                                 local_files_only=True, trust_remote_code=False)
    rt.validate_template(tokenizer, config)
    mc = hf.AutoConfig.from_pretrained(spec["id"], revision=spec["revision"], local_files_only=True, trust_remote_code=False)
    rt.validate_model_config(mc, contexts, questions, config, tokenizer)
    for context, replay in zip(contexts, replays, strict=True):
        actual = prepare_common_replay(context, tokenizer, microchunk_tokens=replay.partition.chunks[0].end - replay.partition.chunks[0].start,
                    sink_tokens=4, tokenizer_id=spec["tokenizer_id"], tokenizer_revision=spec["tokenizer_revision"])
        require(actual.fingerprint == replay.fingerprint, "Actual tokenizer differs from frozen screen; no weights loaded")
    resolved = mc.to_dict()
    resolved["_name_or_path"] = spec["id"]
    resolved["_commit_hash"] = mc._commit_hash  # HF to_dict may omit this verified transient attribute.
    _write(output / "resolved_model_config.json", resolved)
    model = None
    with (output / "events.jsonl").open("x") as events, (output / "results.jsonl").open("x") as results:
        def load_model():
            nonlocal model
            # Acquire ownership before device placement/eval or envelope checks
            # can fail; the outer finally always clears masks/drops this reference.
            model = hf.AutoModelForCausalLM.from_pretrained(spec["id"], revision=spec["revision"], config=mc,
                torch_dtype=getattr(torch, spec["dtype"]), attn_implementation="sdpa", local_files_only=True, trust_remote_code=False)
            model.to(config["runtime"]["device"])
            return model.eval()
        try:
            model, load_stats = timed_call(torch, events, "model_load", load_model, deadline)
            _write(output / "model_load.json", load_stats)
            require(model.config._attn_implementation == "sdpa", "Loaded model is not SDPA")
            with torch.inference_mode():
                for ci, (context, replay) in enumerate(zip(contexts, replays, strict=True)):
                    folder = output / f"c{ci:05d}"
                    folder.mkdir()
                    first = candidate = None
                    built, scores, masks, selections, accounting = {}, {}, {}, {}, {}
                    context_started = rt.synchronized_time(torch)
                    def evaluate_arm(arm, cache, keep):
                        for query in questions[context.context_id]:
                            answer = evaluate_mask(deps, model, tokenizer, cache, keep, query, len(context.token_ids),
                                      64, events, f"c{ci:05d}:{arm}:{query['question_id']}", deadline)
                            row = {"schema": SCHEMA, "context_id": context.context_id, "question_id": query["question_id"],
                                   "arm": arm, "eviction_ratio": 0.0 if arm == "fullkv" else RATIO,
                                   "diagnostic_only": arm in ORACLES, "query_token_ids_sha256": canonical_hash(query["question_token_ids"]),
                                   "mask_sha256": canonical_hash(keep.tolist()), **answer}
                            results.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")
                            results.flush()
                    try:
                        # All paid sparse builds precede access to full-exact labels.
                        for anchors in anchor_plans(replay):
                            candidate, stats = timed_call(torch, events, f"c{ci:05d}:{anchors.policy}:build",
                                lambda a=anchors: build_candidate(deps, model, tokenizer, replay, a,
                                                                  eviction_ratio=RATIO, seed=SEED), deadline)
                            accounting[anchors.policy] = {"runtime": candidate.accounting, "measured": stats,
                                                         "cache": rt.cache_bytes(candidate.cache)}
                            scores[anchors.policy] = candidate.calibration.scores
                            masks[anchors.policy] = candidate.keep_mask
                            selections[anchors.policy] = candidate.selection
                            built[anchors.policy] = {"anchor_values": candidate.anchors.values,
                                                     "virtual": candidate.virtual.values,
                                                     "calibration": candidate.calibration.diagnostics}
                            if anchors.policy == "first":
                                first = candidate
                            evaluate_arm(anchors.policy, candidate.cache, candidate.keep_mask)
                            if anchors.policy != "first":
                                candidate.cache.layers.clear()
                            candidate = None
                        diagnostic, stats = timed_call(torch, events, f"c{ci:05d}:full_exact:build",
                            lambda: build_full_exact_diagnostic(deps, model, tokenizer, replay, diagnostic_only=True), deadline)
                        accounting["full_exact_diagnostic"] = {"runtime": diagnostic.accounting, "measured": stats}
                        for anchors in anchor_plans(replay):
                            captured = built[anchors.policy]
                            require(np.array_equal(captured["virtual"], diagnostic.virtual.values) and
                                    np.array_equal(captured["anchor_values"], diagnostic.full_exact.values[..., anchors.token_indices]),
                                    "Independent sparse/full score observations disagree; stop rather than rescore")
                        (derived_scores, derived_masks, derived_selection, report), transform_stats = timed_call(
                            torch, events, f"c{ci:05d}:diagnostic_mask_transforms",
                            lambda: diagnostic_masks(first, diagnostic, replay), deadline)
                        scores.update(derived_scores); masks.update(derived_masks); selections.update(derived_selection)
                        for arm in ("fullkv", "no_calibration", *ORACLES):
                            evaluate_arm(arm, first.cache, masks[arm])
                        capture = {**{"score__" + k: v for k, v in scores.items()},
                                   **{"keep__" + k: v for k, v in masks.items()},
                                   **{"virtual__" + k: v["virtual"] for k, v in built.items()},
                                   **{"anchors__" + k: v["anchor_values"] for k, v in built.items()},
                                   "full_exact": diagnostic.full_exact.values,
                                   "diagnostic_virtual": diagnostic.virtual.values}
                        before_write = time.perf_counter()
                        with (folder / "scores_masks.npz").open("xb") as stream:
                            np.savez(stream, **capture)
                        serialization = time.perf_counter() - before_write
                        _write(folder / "build.json", {"schema": SCHEMA, "context_id": context.context_id,
                            "replay_sha256": replay.fingerprint, "accounting": accounting, "selection": selections,
                            "calibration": {k: v["calibration"] for k, v in built.items()}, "diagnostics": report,
                            "transform_measured": transform_stats, "capture_cpu_bytes": sum(v.nbytes for v in capture.values()),
                            "capture_serialization_host_seconds": serialization,
                            "physical_memory_savings_demonstrated": False, "cache_compacted": False,
                            "derived_cache_source": "first_pristine_dense_cache; independent clone per query",
                            "cost_attribution": "Derived masks share first and full-exact diagnostic build costs; never interpreted as independent deployable build costs"})
                        _write(folder / "context_timing.json", {"synchronized_wall_seconds": rt.synchronized_time(torch) - context_started,
                              "scope": "All builds, score capture/transfers, transformations, query clones/generation, result writes, capture serialization and build JSON; excludes this summary write; OS buffered",
                              "speedup_claim": False})
                        require(time.monotonic() < deadline, "Serialization crossed local deadline; stop, no retry")
                    finally:
                        rt.clear_masks(model)
                        if candidate is not None:
                            candidate.cache.layers.clear()
                        if first is not None:
                            first.cache.layers.clear()
        finally:
            if model is not None:
                rt.clear_masks(model)
                del model


def run(plan_path, output=None, *, execute_flag=False, config_path=None, baseline_run=None,
        baseline_analysis=None, execution_record=None, repo=ROOT):
    plan = verify_plan(plan_path, repo)
    if not execute_flag:
        if output is not None:
            output.mkdir(parents=True, exist_ok=False)
            _write(output / "plan.json", plan)
        return {"status": "validated_not_executed", "schema": SCHEMA, "plan_sha256": plan["plan_sha256"],
                "counts": plan["counts"], "no_models_loaded": True, "additional_authority": "none"}
    require(output is not None, "--output is required for execution")
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    stage = "prerequisites"
    try:
        require(all(x is not None for x in (config_path, baseline_run, baseline_analysis, execution_record)),
                "Execution needs config, completed baseline/analysis, and resource accounting record")
        config = load_json(config_path)
        from .contracts import validate_config
        validate_config(config)
        contexts, questions, lock = validate_inputs(config, config_path.parent)
        replays = check_config(config, contexts, questions, plan)
        baseline = check_baseline(baseline_run, baseline_analysis, plan)
        record = check_execution_record(load_json(execution_record), plan, baseline)
        require(sha256_file(repo / "data_prep/prepare_longbench.py") == config["dataset"]["preprocessing_sha256"], "Preprocessing source changed")
        from kv_harness.manifest import RunManifest
        evidence = RunManifest.create(repo=repo, evidence_kind="real_model", seed=SEED,
            config={"schema": SCHEMA, "plan": plan, "baseline_config": config, "execution_record": record},
            artifacts={"model": {"identifier": config["model"]["id"], "revision_kind": "git_commit", "revision": config["model"]["revision"]},
                       "dataset": {"identifier": config["dataset"]["source_id"], "revision_kind": "git_commit", "revision": config["dataset"]["source_revision"]},
                       "screen_plan": {"identifier": SCHEMA, "revision_kind": "sha256", "revision": plan["plan_sha256"]}})
        evidence.save(output / "evidence_manifest.json")
        for name, value in (("plan.json", plan), ("baseline_config.json", config),
                            ("baseline_evidence.json", baseline), ("execution_record.json", record)):
            _write(output / name, value)
        (output / "packages.lock.json").write_bytes((config_path.parent / config["runtime"]["packages_lock_file"]).read_bytes())
        require(sha256_file(output / "packages.lock.json") == config["runtime"]["packages_lock_sha256"], "Archived lock changed")
        before_sources = source_hashes()
        stage = "runtime"
        with (output / "runtime.log").open("x") as log, redirect_stdout(log), redirect_stderr(log):
            execute(config, contexts, questions, lock, plan, replays, record, output)
        require(source_hashes() == before_sources, "Source files changed during experiment")
        # Detect committed-source/index changes, not just source file edits.
        after = RunManifest.create(repo=repo, evidence_kind="real_model", seed=SEED,
                                   config=evidence.payload["config"], artifacts=evidence.payload["artifacts"])
        require(after.payload["source"] == evidence.payload["source"], "Checkout changed during experiment")
        _write(output / "run_timing.json", {"host_wall_seconds": time.perf_counter() - started,
                "scope": "Prerequisites, model setup/load, all context work and runtime log writes; excludes final manifest hashing",
                "provider_cost_cny": None, "provider_cost_status": "Unobserved; resource-specific provider ledger must be reconciled separately",
                "charged_work": plan["counts"], "no_speedup_claim": True})
        manifest = {"schema": SCHEMA, "status": "completed", "evidence_kind": "real_model", "backend_commit": BACKEND_COMMIT,
                    "plan_sha256": plan["plan_sha256"], "source_sha256": before_sources,
                    "artifact_sha256": {p.relative_to(output).as_posix(): sha256_file(p) for p in sorted(output.rglob("*")) if p.is_file()}}
        _write(output / "manifest.json", manifest)
        _write(output / "COMPLETE.json", {"schema": SCHEMA, "status": "completed", "manifest_sha256": sha256_file(output / "manifest.json")})
        return {"status": "completed", "schema": SCHEMA, "output": str(output), "run_id": evidence.run_id}
    except BaseException as exc:
        _write(output / "FAILED.json", {"schema": SCHEMA, "status": "failed", "stage": stage,
                "error_type": type(exc).__name__, "host_elapsed_seconds": time.perf_counter() - started,
                "attempted_forward_accounting": getattr(exc, "accounting", None),
                "interpretation": "Partial outputs are not a complete experiment; no automatic retry"})
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    freeze = sub.add_parser("freeze", help="freeze one tiny development screen without weights or inference")
    freeze.add_argument("--task", choices=("lcc", "repobench-p"), required=True)
    freeze.add_argument("--output", type=Path, required=True)
    runner = sub.add_parser("run", help="default is validation only")
    runner.add_argument("--plan", type=Path, required=True)
    runner.add_argument("--output", type=Path)
    runner.add_argument("--execute", action="store_true")
    for name in ("config", "baseline-run", "baseline-analysis", "execution-record"):
        runner.add_argument("--" + name, type=Path)
    analyze = sub.add_parser("analyze", help="offline, fail-closed analysis; this is the only label-reading command")
    analyze.add_argument("--run", type=Path, required=True)
    analyze.add_argument("--output", type=Path, required=True)
    analyze.add_argument("--data-root", type=Path, default=ROOT)
    analyze.add_argument("--bootstrap-samples", type=int, default=2000)
    analyze.add_argument("--allow-fixture", action="store_true", help="Explicit synthetic archive tests only; never upgrades evidence")
    try:
        args = parser.parse_args(argv)
        if args.command == "freeze":
            plan = make_plan(args.task)
            publish(args.output, plan)
            result = {"status": "frozen_not_executed", "plan_sha256": plan["plan_sha256"], "counts": plan["counts"]}
        elif args.command == "run":
            result = run(args.plan, args.output, execute_flag=args.execute, config_path=args.config,
                         baseline_run=args.baseline_run, baseline_analysis=args.baseline_analysis,
                         execution_record=args.execution_record)
        else:
            from .calibration_experiment_analysis import analyze_run
            result = analyze_run(args.run, args.output, args.data_root, bootstrap_samples=args.bootstrap_samples, allow_fixture=args.allow_fixture)
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except (ValueError, RuntimeError, OSError, KeyError, TypeError) as exc:
        print(f"calibration screen rejected: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
