"""Fail-closed, OFFLINE quality analysis for one frozen pilot task/preset/split.

Labels are read only here, never passed to runtime/scoring. Real tensor archives
are opened on CPU with torch.load(weights_only=True); no model, tokenizer, CUDA,
network, timing exporter or harness-result fabrication is involved.
"""
from __future__ import annotations

from collections import defaultdict
import json
import math
from pathlib import Path
import platform
import random

from data_prep import metrics
from kv_harness.manifest import RunManifest
from . import BACKEND_COMMIT
from .contracts import (ContractError, canonical_hash, exact_keys, hex_pin,
                        positive_int, prepare_context, require, selection_budget,
                        sha256_file, summarize_plan, tokens, validate_questions)

BENCHMARK_REVISION = "2e00731f8d0bff23dc4325161044d0ed8af94c1e"
QUALITY_BACKEND = "author-kvpress-sdpa-fake-key-masking"
ARMS = ("fullkv", "echo", "kvzip", "kvzip_echo_partition")
# Reconstruction strings encoded with the frozen Qwen3 tokenizer, also checked
# independently by `echo_pilot.stages verify --retokenize`. No tokenizer/model
# import is needed to verify the complete recorded replay input token sequence.
QWEN_TOKENIZER_REVISION = "b968826d9c46dd6066d109eabc6255188de91218"
FIRST_PROMPT_IDS = [271, 38718, 279, 3681, 2266, 6896, 13]
LATER_PROMPT_IDS = [271, 38718, 279, 949, 315, 279, 3681, 2266, 6896, 11, 5916, 448]


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _json(text):
    def bad(value):
        raise ContractError(f"Nonfinite JSON number: {value}")
    return json.loads(text, object_pairs_hook=_pairs, parse_constant=bad)


def _read(path):
    return _json(path.read_text())


def _rows(path):
    rows = [_json(line) for line in path.read_text().splitlines()]
    require(bool(rows) and all(isinstance(row, dict) for row in rows), f"Empty/non-object JSONL: {path}")
    return rows


def _local(root, name):
    require(isinstance(name, str) and name and not Path(name).is_absolute(), "Artifact path must be relative")
    path = root / name
    require(".." not in Path(name).parts and path.resolve().is_relative_to(root.resolve()), "Artifact path escapes root")
    require(not any(p.is_symlink() for p in (path, *path.parents) if p != root.parent), "Symlink artifacts are unsupported")
    require(path.is_file(), f"Missing artifact: {name}")
    return path


def _number(value, where, minimum=0):
    require(type(value) in (int, float) and math.isfinite(value) and value >= minimum, f"Invalid {where}")


def _completed(run):
    require(run.is_dir() and not run.is_symlink(), "Run must be a real completed directory")
    require(not (run / "FAILED.json").exists(), "FAILED.json rejects a partial/failed run")
    complete = _read(_local(run, "COMPLETE.json"))
    exact_keys(complete, {"status", "manifest_sha256"}, set(), "COMPLETE")
    require(complete["status"] == "completed", "Run is incomplete")
    manifest_path = _local(run, "manifest.json")
    require(sha256_file(manifest_path) == complete["manifest_sha256"], "Run manifest digest mismatch")
    manifest = _read(manifest_path)
    require(manifest.get("schema_version") == 1 and manifest.get("status") == "completed"
            and manifest.get("runtime_stage") == "executed", "Run did not complete execution")
    require(manifest.get("backend_commit") == BACKEND_COMMIT, "Run backend pin mismatch")
    hashes = manifest.get("artifact_sha256")
    require(isinstance(hashes, dict) and hashes, "Missing artifact digest inventory")
    actual = set()
    for path in run.rglob("*"):
        require(not path.is_symlink(), "Symlink artifacts are unsupported")
        if path.is_file():
            actual.add(path.relative_to(run).as_posix())
    require(actual == set(hashes) | {"manifest.json", "COMPLETE.json"}, "Artifact inventory has missing/extra files")
    require(not ({"manifest.json", "COMPLETE.json", "FAILED.json"} & set(hashes)), "Invalid marker in artifact inventory")
    for name, digest in hashes.items():
        hex_pin(digest, 64, "artifact digest")
        require(sha256_file(_local(run, name)) == digest, f"Artifact digest mismatch: {name}")
    required = {"frozen_config.json", "input_plan.json", "packages.lock.json", "evidence_manifest.json",
                "environment.json", "resolved_model_config.json", "model_load.json", "results.jsonl"}
    require(required <= set(hashes), "Missing required runtime artifacts")
    code = manifest.get("code_sha256", {})
    require(isinstance(code, dict) and {"runtime.py", "contracts.py", "cli.py"} <= set(code), "Missing source digest inventory")
    for name, digest in code.items():
        hex_pin(digest, 64, "source digest")
    # These sources define the run format and mask/generation contracts audited here.
    for name in ("runtime.py", "contracts.py"):
        require(code[name] == sha256_file(Path(__file__).parent / name), f"Unsupported runtime source: {name}")
    config = _read(run / "frozen_config.json")
    from .contracts import validate_config
    validate_config(config)
    require(canonical_hash(config) == manifest.get("config_sha256"), "Frozen config digest mismatch")
    evidence = RunManifest.load(run / "evidence_manifest.json")
    require(evidence.payload["config"] == config, "Evidence manifest config differs from frozen config")
    require(evidence.payload["seed"] == config["runtime"]["seed"], "Evidence seed mismatch")
    pins = evidence.payload["artifacts"]
    ds, model = config["dataset"], config["model"]
    expected = {"model": (model["id"], "git_commit", model["revision"]),
                "dataset": (ds["source_id"], "git_commit", ds["source_revision"]),
                "tokenized_contexts": ("frozen-context-jsonl", "sha256", ds["contexts_sha256"]),
                "tokenized_questions": ("frozen-question-jsonl", "sha256", ds["questions_sha256"])}
    for key, (identifier, kind, revision) in expected.items():
        require(pins.get(key) == {"identifier": identifier, "revision_kind": kind, "revision": revision}, f"Evidence artifact pin mismatch: {key}")
    lock = _read(run / "packages.lock.json")
    exact_keys(lock, {"python_version", "packages", "backend_commit"}, set(), "archived package lock")
    require(isinstance(lock["packages"], dict) and {"torch", "transformers", "kvpress", "numpy", "peft"} <= set(lock["packages"]), "Incomplete runtime package inventory")
    require(sha256_file(run / "packages.lock.json") == config["runtime"]["packages_lock_sha256"], "Archived package lock digest mismatch")
    environment = _read(run / "environment.json")
    for key in ("python_version", "packages", "backend_commit"):
        require(environment.get(key) == lock.get(key) and key in lock, f"Environment lock mismatch: {key}")
    require(lock["backend_commit"] == BACKEND_COMMIT, "Environment backend mismatch")
    if ds["evidence_kind"] != "fixture_only":
        deterministic = environment.get("deterministic_settings", {})
        require(deterministic.get("deterministic_algorithms") is config["runtime"]["deterministic_algorithms"]
                and deterministic.get("tf32_allowed") is False, "Runtime deterministic settings mismatch")
        if config["runtime"]["deterministic_algorithms"]:
            require(deterministic.get("CUBLAS_WORKSPACE_CONFIG") in (":4096:8", ":16:8"), "Missing deterministic CUDA configuration record")
        repo = Path(__file__).resolve().parents[1]
        author = _read(repo / "research/sources/echopress_39748e9/provenance.json")
        pinned_sources = {r["path"]: r["local_sha256"] for r in author["files"] if r["path"].startswith("kvpress/")}
        for name in ("kvpress/presses/base_press.py", "kvpress/attention_patch.py", "kvpress/__init__.py", "kvpress/utils.py"):
            pinned_sources[name] = sha256_file(Path(__file__).parent / "vendor_audit" / name.replace("/", "__"))
        require(environment.get("verified_source_sha256") == pinned_sources, "Runtime verified author-source inventory mismatch")
    return config, manifest, evidence


def _data(config, manifest_path, manifest_hash, root, task, preset, split):
    hex_pin(manifest_hash, 64, "data manifest SHA-256")
    require(sha256_file(manifest_path) == manifest_hash, "Data manifest digest mismatch")
    manifest = _read(manifest_path)
    require(manifest.get("schema_version") == 1, "Unsupported data manifest")
    require(manifest.get("benchmark_code_revision") == BENCHMARK_REVISION, "Unexpected benchmark metric revision")
    require(manifest.get("metric_implementation_sha256") == sha256_file(Path(metrics.__file__)), "Pinned metric source digest mismatch")
    require(manifest["settings"]["metric"] == metrics.METRIC, "Unexpected data metric")
    ds = config["dataset"]
    require(task in ("lcc", "repobench-p") and split in ("development", "heldout"), "Explicit task/split required")
    require(ds["split"] == split and ds["source_id"] == "zai-org/LongBench/" + task, "Config task/split mismatch")
    require(ds["evidence_kind"] == manifest["settings"]["evidence_kind"], "Dataset evidence dimension mismatch")
    require(ds["source_revision"] == manifest["source_revision"] and ds["preprocessing_sha256"] == manifest["preprocessor_sha256"], "Dataset source/preprocessor pin mismatch")
    require(config["model"]["tokenizer_revision"] == manifest["tokenizer_revision"], "Tokenizer revision mismatch")
    require(config["template"] == {**manifest["template"], "prompt_mode": "chat_adapted"}, "Frozen template mismatch")
    require(preset in manifest["presets"], "Unknown frozen preset")
    spec = manifest["presets"][preset]
    require(task + "." + split in spec["artifacts"], "No frozen task/split artifacts")
    require(config["generation"]["max_new_tokens"] == spec["max_new_tokens"], "Generation limit differs from frozen preset")
    require(config["truncation"] == {"policy": "reject", "max_context_tokens": spec["limits"]["max_context_tokens"]}, "Truncation differs from frozen preset")
    artifacts = spec["artifacts"][task + "." + split]
    loaded = {}
    for kind in ("contexts", "questions", "labels"):
        entry = artifacts[kind]
        path = _local(root, entry["path"])
        require(sha256_file(path) == entry["sha256"], f"Frozen {kind} digest mismatch")
        require(path.stat().st_size == entry["bytes"], f"Frozen {kind} size mismatch")
        loaded[kind] = _rows(path)
        require(len(loaded[kind]) == entry["rows"], f"Frozen {kind} row count mismatch")
        if kind != "labels":
            require(ds[kind + "_sha256"] == entry["sha256"], f"Config {kind} pin differs from selected preset")
    require(all("reference_texts" not in row for row in loaded["questions"]), "Labels must stay outside runtime query inputs")
    contexts = [prepare_context(row, config) for row in loaded["contexts"]]
    context_map = {c.context_id: c for c in contexts}
    require(len(context_map) == len(contexts), "Duplicate context IDs")
    grouped = validate_questions(loaded["questions"], set(context_map), config["template"]["suffix_token_ids"])
    queries = {q["question_id"]: q for values in grouped.values() for q in values}
    selected = [r for r in spec["datasets"][task]["selected"] if r["split"] == split]
    require(len(selected) == len(queries) and {r["question_id"] for r in selected} == set(queries), "Frozen selected question IDs mismatch")
    for row in selected:
        q = queries[row["question_id"]]
        require(row["context_id"] == q["context_id"], "Selected question/context association mismatch")
        c = context_map[q["context_id"]]
        require(row["context_token_ids_sha256"] == canonical_hash(c.token_ids), "Selected context token fingerprint mismatch")
        require(row["question_token_ids_sha256"] == canonical_hash(q["question_token_ids"]), "Selected query token fingerprint mismatch")
    labels = loaded["labels"]
    require(len(labels) == len(queries) and {r["question_id"] for r in labels} == set(queries), "Label IDs must match frozen questions exactly")
    selected_by_id = {r["question_id"]: r for r in selected}
    for label in labels:
        exact_keys(label, {"context_id", "question_id", "dataset", "metric", "reference_texts"}, set(), "label")
        require(label["dataset"] == task and label["metric"] == metrics.METRIC, "Label task/metric mismatch")
        require(label["context_id"] == queries[label["question_id"]]["context_id"], "Wrong label context association")
        require(canonical_hash(label["reference_texts"]) == selected_by_id[label["question_id"]]["references_sha256"], "Reference fingerprint mismatch")
    return contexts, grouped, queries, labels, artifacts


def _allocation_from_layers(layers, context):
    retained = [row["heads"] for row in layers]
    regions = {r["region_id"]: {"retained_pairs": sum(sum(row["regions"][r["region_id"]]) for row in layers),
                "retained_per_layer_head": [row["regions"][r["region_id"]] for row in layers]} for r in context.regions}
    return {"retained_per_layer_head": retained, "retained_per_region": regions,
            "retained_prefix_pairs": sum(row["prefix"] for row in layers),
            "actual_retained_pairs": sum(map(sum, retained))}


def _fixture_masks(path, context, n_layers, n_heads, selection, full):
    """JSON fixtures are opt-in and impossible to label real_model."""
    payload = _read(path)
    exact_keys(payload, {"fixture_only", "masked_key_indices", "logical_keep_mask"}, set(), "fixture tensor archive")
    require(payload["fixture_only"] is True, "Fixture tensor marker required")
    masks, keeps = payload["masked_key_indices"], payload["logical_keep_mask"]
    require(len(masks) == n_layers, "Mask layer count mismatch")
    if full:
        require(all(mask is None for mask in masks) and keeps is None, "Full KV has a mask")
        return None
    require(isinstance(keeps, list) and len(keeps) == n_layers, "Keep tensor layer shape mismatch")
    layers = []
    n = len(context.token_ids)
    for mask, keep in zip(masks, keeps):
        expected = [[True] * n for _ in range(n_heads)]
        if mask is not None:
            require(isinstance(mask, list) and len(mask) == 3 and len({len(v) for v in mask}) == 1, "Mask coordinate shape mismatch")
            coords = list(zip(*mask))
            require(len(set(coords)) == len(coords), "Duplicate masked coordinate")
            for b, h, s in coords:
                require(type(b) is int and b == 0 and type(h) is int and 0 <= h < n_heads and type(s) is int and 0 <= s < n, "Mask coordinate outside context")
                expected[h][s] = False
        require(isinstance(keep, list) and len(keep) == 1 and keep[0] == expected
                and all(type(v) is bool for row in keep[0] for v in row), "Logical keep mask mismatch")
        protected = set(range(min(selection["n_sink"], n))) | set(range(max(0, n-selection["recent_tokens"]), n))
        require(all(row[i] for row in expected for i in protected), "Protected token was evicted")
        layers.append({"heads": [sum(row) for row in expected], "prefix": sum(sum(row[:context.prefix_length]) for row in expected),
                       "regions": {r["region_id"]: [sum(row[r["start"]:r["end"]]) for row in expected] for r in context.regions}})
    return _allocation_from_layers(layers, context)


def _torch_masks(path, context, n_layers, n_heads, selection, full):
    try:
        import torch
    except (ImportError, OSError) as exc:
        raise ContractError("Offline tensor integrity needs an installed CPU-capable torch; no GPU/model is needed. Never skip mask checks.") from exc
    capture = torch.load(path, map_location="cpu", weights_only=True)
    require(isinstance(capture, dict), "Tensor archive must be a dictionary")
    masks = capture.get("masked_key_indices")
    require(isinstance(masks, list) and len(masks) == n_layers, "Mask layer count mismatch")
    if full:
        require(all(mask is None for mask in masks) and "logical_keep_mask" not in capture, "Full KV has a mask")
        require(set(capture) == {"masked_key_indices"}, "Full KV has unexpected score/mask tensors")
        return None
    n = len(context.token_ids)
    shape = (n_layers, 1, n_heads, n)
    keep = capture.get("logical_keep_mask")
    require(isinstance(keep, torch.Tensor) and keep.dtype == torch.bool and tuple(keep.shape) == shape, "Logical keep tensor shape/dtype mismatch")
    for key in ("scores_before_protection", "scores_used_for_selection"):
        tensor = capture.get(key)
        require(isinstance(tensor, torch.Tensor) and tuple(tensor.shape) == shape and tensor.is_floating_point()
                and bool(torch.isfinite(tensor).all()), "Missing/invalid/nonfinite score tensor: " + key)
    layers = []
    for i, mask in enumerate(masks):
        expected = torch.ones((1, n_heads, n), dtype=torch.bool)
        if mask is not None:
            require(isinstance(mask, tuple) and len(mask) == 3, "Mask coordinate tuple mismatch")
            require(all(isinstance(v, torch.Tensor) and v.ndim == 1 and v.dtype == torch.int64 for v in mask), "Mask coordinates must be 1D int64")
            b, h, s = mask
            require(b.numel() == h.numel() == s.numel(), "Mask coordinate lengths mismatch")
            require(bool((b == 0).all()) and bool(((h >= 0) & (h < n_heads)).all()) and bool(((s >= 0) & (s < n)).all()), "Mask coordinate outside context")
            require(torch.unique(h * n + s).numel() == s.numel(), "Duplicate masked coordinate")
            expected[b, h, s] = False
        require(torch.equal(keep[i], expected), "Logical keep mask mismatch")
        require(bool(expected[..., :selection["n_sink"]].all()), "Protected sink token was evicted")
        recent = selection["recent_tokens"]
        require(not recent or bool(expected[..., -recent:].all()), "Protected recent token was evicted")
        layers.append({"heads": expected[0].sum(-1).tolist(), "prefix": int(expected[..., :context.prefix_length].sum()),
                       "regions": {r["region_id"]: expected[0, :, r["start"]:r["end"]].sum(-1).tolist() for r in context.regions}})
    return _allocation_from_layers(layers, context)


def _expected_chunks(context, config, arm, fixture):
    if arm == "fullkv":
        return []
    if fixture:
        first, later = [99], [98]
    else:
        require(config["model"]["tokenizer_id"] == "Qwen/Qwen3-8B"
                and config["model"]["tokenizer_revision"] == QWEN_TOKENIZER_REVISION,
                "Replay token validation supports only the pinned Qwen3 tokenizer")
        first, later = FIRST_PROMPT_IDS, LATER_PROMPT_IDS
    suffix, size = config["template"]["suffix_token_ids"], config["selection"]["chunk_size"]
    first_size = max(1, size - len(first) - len(suffix)) if arm != "kvzip" else size
    cursor, prior, chunks = context.prefix_length, [], []
    while cursor < len(context.token_ids):
        end = min(len(context.token_ids), cursor + (first_size if not chunks else size))
        body = list(context.token_ids[cursor:end])
        ids = (first if not chunks else later + prior[-8:]) + suffix + body
        exact = arm != "echo" or not chunks
        chunks.append({"start": cursor, "end": end, "context_tokens": len(body),
                       "replay_input_tokens": len(ids), "prompt_suffix_postfix_tokens": len(ids)-len(body),
                       "replay_input_token_ids": ids, "executed_exact_replay": exact})
        cursor, prior = end, body
    if arm != "kvzip":
        require(chunks[0]["replay_input_tokens"] <= size, "First replay exceeds frozen chunk budget")
    return chunks


def _builds(run, config, contexts, manifest, fixture):
    model = _read(run / "resolved_model_config.json")
    n_layers, n_heads, head_dim = (model.get(k) for k in ("num_hidden_layers", "num_key_value_heads", "head_dim"))
    if head_dim is None:
        positive_int(model.get("num_attention_heads"), "model attention heads")
        head_dim = model.get("hidden_size", 0) // model["num_attention_heads"]
    for k, v in (("layers", n_layers), ("heads", n_heads), ("head dimension", head_dim)):
        positive_int(v, k)
    require(model.get("_name_or_path") == config["model"]["id"], "Resolved model ID mismatch")
    if model.get("_commit_hash") is not None:
        require(model["_commit_hash"] == config["model"]["revision"], "Resolved model revision mismatch")
    expected, build_paths, partitions = {}, set(), {}
    for ci, context in enumerate(contexts):
        n = len(context.token_ids)
        total = n_layers * n_heads * n
        for arm in config["arms"]:
            ratios = [0.0] if arm == "fullkv" else config["selection"]["eviction_ratios"]
            for ri, ratio in enumerate(ratios):
                build_id = f"c{ci:05d}-{arm}-r{ri:02d}"
                folder = run / build_id
                build_paths.update(f"{build_id}/{name}" for name in ("build.json", "scores_masks.pt", "arm_timing.json"))
                build = _read(_local(run, f"{build_id}/build.json"))
                require(type(build.get("eviction_ratio")) in (int, float) and math.isfinite(build["eviction_ratio"]), "Invalid build ratio")
                require((build.get("context_id"), build.get("arm"), build.get("eviction_ratio")) == (context.context_id, arm, ratio), "Build identity mismatch")
                require(build.get("context_fingerprint") == context.fingerprint(), "Build context fingerprint mismatch")
                require(build.get("truncation") == context.truncation and build.get("regions") == list(context.regions), "Build truncation/regions mismatch")
                require(build.get("common_recent_tokens") == config["selection"]["recent_tokens"] and build.get("quality_backend") == QUALITY_BACKEND, "Build policy/backend mismatch")
                require(build.get("compacted") is False and build.get("physical_memory_savings_demonstrated") is False
                        and build.get("physical_kv_payload_reduction_bytes") == 0, "Unsupported physical-memory claim")
                shape = [1, n_heads, n, head_dim]
                require(build.get("kv_shapes") == [[shape, shape] for _ in range(n_layers)], "Build cache shape mismatch")
                payload = 2 * total * head_dim * {"bfloat16": 2, "float16": 2, "float32": 4}[config["model"]["dtype"]]
                require(build.get("kv_tensor_payload_bytes") == payload and build.get("kv_unique_storage_bytes", -1) >= payload, "Build cache bytes mismatch")
                allocation = build.get("allocation", {})
                budget = selection_budget(n_layers, n_heads, n, ratio, config["selection"]["n_sink"], config["selection"]["recent_tokens"])
                require(all(type(allocation.get(k)) is int for k in ("actual_pruned_pairs", "actual_retained_pairs")), "Mask budget counts must be integers")
                require(allocation["actual_pruned_pairs"] == budget["pruned_pairs"] and allocation["actual_retained_pairs"] == budget["retained_pairs"], "Inconsistent mask budget")
                if arm != "fullkv":
                    require(build.get("metadata", {}).get("budget") == budget, "Declared mask budget mismatch")
                chunks = build.get("metadata", {}).get("chunks", [])
                require(isinstance(chunks, list) and (bool(chunks) if arm != "fullkv" else not chunks), "Missing/unexpected reconstruction chunks")
                require(chunks == _expected_chunks(context, config, arm, fixture), "Replay tokens/partition differ from frozen context, prompts, suffix or previous-chunk postfix")
                cursor, replays, partition = context.prefix_length, [], []
                for chunk_index, chunk in enumerate(chunks):
                    require(chunk.get("start") == cursor and type(chunk.get("end")) is int and cursor < chunk["end"] <= n, "Noncontiguous reconstruction partition")
                    require(chunk.get("context_tokens") == chunk["end"] - cursor, "Reconstruction chunk size mismatch")
                    tokens(chunk.get("replay_input_token_ids"), "replay input tokens")
                    replay_length = len(chunk["replay_input_token_ids"])
                    require(chunk.get("replay_input_tokens") == replay_length and chunk.get("prompt_suffix_postfix_tokens") == replay_length - chunk["context_tokens"] >= 0, "Replay length metadata mismatch")
                    exact = arm != "echo" or chunk_index == 0
                    require(chunk.get("executed_exact_replay") is exact, "Unexpected exact replay schedule")
                    if exact:
                        replays.append(replay_length)
                    partition.append({k: v for k, v in chunk.items() if k != "executed_exact_replay"})
                    cursor = chunk["end"]
                require(arm == "fullkv" or cursor == n, "Reconstruction partition omits context tokens")
                require(build.get("forward_input_lengths") == [n] + replays and build.get("exact_replay_passes") == len(replays)
                        and build.get("exact_replay_input_tokens") == sum(replays), "Observed build forward/replay plan mismatch")
                if arm in ("echo", "kvzip_echo_partition"):
                    partitions[(context.context_id, arm, ratio)] = partition
                mask_path = _local(run, f"{build_id}/scores_masks.pt")
                checked = (_fixture_masks if fixture else _torch_masks)(mask_path, context, n_layers, n_heads, config["selection"], arm == "fullkv")
                if checked is not None:
                    require(checked["actual_retained_pairs"] == budget["retained_pairs"], "Tensor mask retained count differs from budget")
                    for key, value in checked.items():
                        require(allocation.get(key) == value, f"Tensor mask allocation mismatch: {key}")
                timing = _read(_local(run, f"{build_id}/arm_timing.json"))
                _number(timing.get("arm_wall_seconds"), "arm wall time")
                require(timing.get("speedup_or_amortized_cost_claim") is False, "Unsupported timing claim")
                expected[(context.context_id, arm, float(ratio))] = build_id
    declared_build_paths = {p for p in manifest["artifact_sha256"] if "/" in p}
    require(declared_build_paths == build_paths, "Unexpected/missing build artifact cells")
    for context in contexts:
        for ratio in config["selection"]["eviction_ratios"]:
            require(partitions[(context.context_id, "echo", ratio)] == partitions[(context.context_id, "kvzip_echo_partition", ratio)], "Partition-matched KVzip differs from Echo reconstruction partition/prompts")
    return expected


def cluster_bootstrap(rows, *, samples=2000, seed=20261003, confidence=0.95):
    """Question-weighted mean; draw whole contexts, carrying all paired queries.

    Call separately for each arm/ratio. Identical sorted clusters + seed give
    shared draws across comparisons; ratios and reused full-KV are never units.
    """
    positive_int(samples, "bootstrap samples")
    positive_int(seed, "bootstrap seed", 0)
    require(type(confidence) in (float, int) and 0 < confidence < 1, "Invalid bootstrap confidence")
    clusters = defaultdict(list)
    ids = set()
    for row in rows:
        identity = (row["context_id"], row["question_id"])
        require(identity not in ids, "Duplicate question/repeat in bootstrap cell")
        ids.add(identity)
        _number(abs(row["value"]), "bootstrap value")
        clusters[row["context_id"]].append(row["value"])
    require(bool(clusters), "Cannot bootstrap empty observations")
    keys = sorted(clusters)
    # Stable sums make shuffled result order immaterial.
    grouped = [(math.fsum(sorted(clusters[key])), len(clusters[key])) for key in keys]
    point = math.fsum(v for v, n in grouped) / sum(n for v, n in grouped)
    rng = random.Random(seed)
    draws, estimates = [], []
    for _ in range(samples):
        draw = [rng.randrange(len(keys)) for _ in keys]
        draws.append(draw)
        estimates.append(math.fsum(grouped[i][0] for i in draw) / sum(grouped[i][1] for i in draw))
    estimates.sort()
    def quantile(p):
        index = (len(estimates) - 1) * p
        lo, hi = math.floor(index), math.ceil(index)
        return estimates[lo] + (estimates[hi] - estimates[lo]) * (index - lo)
    alpha = (1 - confidence) / 2
    return {"mean": point, "interval": [quantile(alpha), quantile(1-alpha)] if len(keys) >= 2 else None,
            "context_count": len(keys), "question_count": len(ids), "draws_sha256": canonical_hash(draws),
            "uncertainty_status": "exploratory_context_cluster_percentile" if len(keys) >= 2 else "insufficient_context_clusters"}


def analyze_run(run: Path, data_manifest: Path, data_root: Path, task: str, preset: str, split: str,
                *, data_manifest_sha256: str, output: Path, bootstrap_samples=2000, bootstrap_seed=20261003,
                confidence=0.95, allow_fixture=False):
    """Validate everything before publishing a fresh quality-only output directory."""
    run, output = run.resolve(), output.resolve()
    require(not output.exists() and not output.is_relative_to(run) and not run.is_relative_to(output), "Analysis output must be a new directory outside the immutable run")
    config, manifest, evidence = _completed(run)
    fixture = config["dataset"]["evidence_kind"] == "fixture_only"
    require((fixture and allow_fixture and evidence.payload["evidence_kind"] == "cpu_fixture")
            or (not fixture and evidence.payload["evidence_kind"] == "real_model"), "Evidence mismatch or fixture analysis not explicitly enabled")
    contexts, grouped, queries, labels, artifacts = _data(config, data_manifest, data_manifest_sha256, data_root,
                                                         task, preset, split)
    require(_read(run / "input_plan.json") == summarize_plan(config, contexts, grouped), "Input plan differs from frozen exact context/query plan")
    builds = _builds(run, config, contexts, manifest, fixture)
    expected = {(c, q["question_id"], arm, ratio): build_id for (c, arm, ratio), build_id in builds.items() for q in grouped[c]}
    seen, cells = set(), defaultdict(list)
    for row in _rows(run / "results.jsonl"):
        exact_keys(row, {"build_id", "context_id", "question_id", "arm", "eviction_ratio", "evidence_kind",
                        "query_token_ids_sha256", "cache_clone_seconds", "query_generation_seconds", "query_peak_memory",
                        "query_cache", "generated_token_ids", "text", "text_with_special_tokens", "stopped_on_eos",
                        "generated_token_count"}, set(), "runtime result")
        require(type(row.get("eviction_ratio")) in (int, float) and math.isfinite(row["eviction_ratio"]), "Invalid result ratio")
        key = (row.get("context_id"), row.get("question_id"), row.get("arm"), float(row["eviction_ratio"]))
        require(key in expected, "Unexpected result cell or wrong question/context association")
        require(key not in seen, "Duplicate result cell/repeat")
        seen.add(key)
        require(row.get("build_id") == expected[key], "Result build identity mismatch")
        require(row.get("evidence_kind") == config["dataset"]["evidence_kind"], "Result dataset evidence mismatch")
        require(row.get("query_token_ids_sha256") == canonical_hash(queries[key[1]]["question_token_ids"]), "Result query fingerprint mismatch")
        require(isinstance(row.get("text"), str) and isinstance(row.get("text_with_special_tokens"), str), "Missing decoded result text")
        tokens(row.get("generated_token_ids"), "generated tokens", allow_empty=True)
        count = row.get("generated_token_count")
        require(type(count) is int and count == len(row["generated_token_ids"]) and 1 <= count <= config["generation"]["max_new_tokens"], "Generated token count mismatch")
        require(type(row.get("stopped_on_eos")) is bool and (row["stopped_on_eos"] or count == config["generation"]["max_new_tokens"]), "Generation ended without EOS or max-token limit")
        _number(row["cache_clone_seconds"], "cache clone time")
        _number(row["query_generation_seconds"], "query generation time")
        require(isinstance(row["query_peak_memory"], dict) and isinstance(row["query_cache"], dict), "Missing query memory/cache metadata")
        cache = row["query_cache"]
        build = _read(run / row["build_id"] / "build.json")
        context_length = build["truncation"]["retained_tokens"]
        grown_length = context_length + len(queries[key[1]]["question_token_ids"]) + count - 1
        expected_shapes = [[[shape[0], shape[1], grown_length, shape[3]] for shape in pair] for pair in build["kv_shapes"]]
        expected_payload = build["kv_tensor_payload_bytes"] // context_length * grown_length
        require(cache.get("compacted") is False and cache.get("kv_shapes") == expected_shapes
                and cache.get("kv_tensor_payload_bytes") == expected_payload
                and cache.get("kv_unique_storage_bytes", -1) >= expected_payload, "Query cache shape/generation-length mismatch")
        cells[(key[2], key[3])].append({"question_id": key[1], "prediction": row["text"]})
    require(seen == set(expected), "Missing required result cells")
    scope = {"run_id": evidence.run_id, "task": task, "preset": preset, "split": split}
    scores, score_lookup, summaries = [], {}, []
    for (arm, ratio), predictions in sorted(cells.items()):
        evaluated = metrics.evaluate(predictions, labels)
        rows = []
        for item in evaluated["per_example"]:
            score = item["score"]
            require(type(score) in (float, int) and math.isfinite(score) and 0 <= score <= 1, "Invalid official metric score")
            qid = item["question_id"]
            scored = {**scope, "context_id": queries[qid]["context_id"], "question_id": qid,
                      "arm": arm, "eviction_ratio": ratio, "build_id": expected[(queries[qid]["context_id"], qid, arm, ratio)], "score": score}
            scores.append(scored)
            score_lookup[(qid, arm, ratio)] = score
            rows.append({**scored, "value": score})
        stat = cluster_bootstrap(rows, samples=bootstrap_samples, seed=bootstrap_seed, confidence=confidence)
        summaries.append({"arm": arm, "eviction_ratio": ratio, "mean_score_percent": 100 * stat["mean"],
                          "quality": stat})
    paired = []
    for scored in scores:
        if scored["arm"] == "fullkv":
            continue
        qid, ratio = scored["question_id"], scored["eviction_ratio"]
        full, matched = score_lookup[(qid, "fullkv", 0.0)], score_lookup[(qid, "kvzip_echo_partition", ratio)]
        paired.append({**scored, "fullkv_score": full, "partition_matched_kvzip_score": matched,
                       "delta_vs_fullkv": scored["score"] - full,
                       "delta_vs_partition_matched_kvzip": scored["score"] - matched,
                       "fullkv_reference_build_id": builds[(scored["context_id"], "fullkv", 0.0)],
                       "partition_matched_reference_build_id": builds[(scored["context_id"], "kvzip_echo_partition", ratio)]})
    for summary in summaries:
        if summary["arm"] == "fullkv":
            continue
        cell = [r for r in paired if (r["arm"], r["eviction_ratio"]) == (summary["arm"], summary["eviction_ratio"])]
        for delta in ("delta_vs_fullkv", "delta_vs_partition_matched_kvzip"):
            stat = cluster_bootstrap([{**r, "value": r[delta]} for r in cell], samples=bootstrap_samples, seed=bootstrap_seed, confidence=confidence)
            summary[delta] = {**stat, "mean_percentage_points": 100 * stat["mean"]}
    report = {"schema_version": 1, "status": "validated_quality_only", **scope,
              "evidence": {"execution": evidence.payload["evidence_kind"], "workload": config["dataset"]["evidence_kind"], "fixture_only": fixture},
              "metric": metrics.METRIC, "score_units": "per-question [0,1]; task means percent; deltas [−1,1] and percentage points",
              "protocol": {"model": config["model"], "template": config["template"], "generation": config["generation"],
                           "selection": config["selection"], "attention_backend": config["runtime"]["attention_backend"]},
              "mask_validation": "synthetic JSON fixture only" if fixture else "actual tensor masks loaded CPU-only with weights_only=True",
              "denominators": {"contexts": len(contexts), "questions": len(queries), "builds": len(builds), "observed_result_cells": len(seen), "fullkv_observations": len(queries)},
              "bootstrap": {"unit": "context_id", "estimand": "question-weighted mean", "samples": bootstrap_samples,
                            "seed": bootstrap_seed, "confidence": confidence, "method": "paired context-cluster percentile; shared context draws across cells",
                            "draw_size": len(contexts), "interval_units": "score fraction", "multiple_comparison_correction": "none; exploratory all-cell reporting"},
              "arms": summaries, "performance_export": "not_exported; no harness timing/memory/cost fields synthesized",
              "limitations": ["Full KV is measured once per context and reused only as a paired reference", "Questions/ratios are not independent contexts; repeats and duplicate cells are rejected",
                              "Bootstrap intervals from small context sets can be unstable; lack of significance is not equivalence", "Chat-adapted LongBench protocol, not published raw-completion score reproduction",
                              "Hash integrity is not source authenticity or proof of actual GPU execution", "Synthetic fixtures are plumbing tests, never model-quality evidence"]}
    provenance = {"run_manifest_sha256": sha256_file(run / "manifest.json"), "evidence_manifest_sha256": evidence.sha256,
                  "data_manifest_sha256": data_manifest_sha256, "config_canonical_sha256": canonical_hash(config),
                  "input_artifacts": artifacts, "runtime_code_sha256": manifest["code_sha256"],
                  "analysis_source_sha256": sha256_file(Path(__file__)), "metric_source_sha256": sha256_file(Path(metrics.__file__)),
                  "analysis_environment": {"python_version": platform.python_version(), "python_implementation": platform.python_implementation()},
                  "run_artifact_sha256": manifest["artifact_sha256"]}
    output.mkdir(parents=True, exist_ok=False)
    def write(name, value):
        (output / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write("summary.json", report)
    write("provenance.json", provenance)
    for name, rows in (("question_scores.jsonl", scores), ("paired_questions.jsonl", paired)):
        (output / name).write_text("".join(json.dumps(row, sort_keys=True, allow_nan=False) + "\n" for row in rows))
    output_hashes = {p.name: sha256_file(p) for p in sorted(output.iterdir())}
    write("ANALYSIS_COMPLETE.json", {"status": "validated_quality_only", "artifact_sha256": output_hashes,
                                     "run_id": evidence.run_id, "evidence": report["evidence"]})
    return report
