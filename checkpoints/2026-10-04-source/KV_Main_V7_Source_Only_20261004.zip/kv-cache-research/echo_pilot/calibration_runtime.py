"""Isolated common-microchunk adapter for the pinned EchoPress/KVzip source.

Importing and preparing a plan never imports torch/transformers or loads a model.
Native execution needs the already source/revision-verified dependencies and model
from ``echo_pilot.runtime``. Dependency injection also permits CPU contract mocks;
those tests do not establish Torch/CUDA or tokenizer/model numerical parity.

This is a policy adaptation: every contiguous chunk uses the same author-first
instruction. It is not the unchanged author first-chunk baseline. Stable logical
selection is installed directly; the author's ``compress_post`` is never called.
"""
from __future__ import annotations

import copy
from contextlib import ExitStack
from dataclasses import asdict, dataclass
from functools import partial
import re
import time

import numpy as np

from . import BACKEND_COMMIT
from .contracts import PreparedContext, canonical_hash, require
from research.calibration_methods.contracts import (
    AnchorObservations, AnchorPlan, Microchunk, Partition, VirtualScores,
)
from research.calibration_methods.methods import Precision, calibrate
from research.calibration_methods.selection import select_logical

COMMON_PROMPT = "\n\nRepeat the previous context exactly."
PROMPT_POLICY = "same_author_first_instruction_every_contiguous_microchunk_v1"


def _ids(value, name, *, empty=False):
    require(type(value) is tuple and (empty or bool(value)) and
            all(type(t) is int and t >= 0 for t in value),
            f"{name} must be immutable nonnegative token IDs")
    return value


def _encoded(tokenizer, text):
    # Deliberately no return_tensors, AutoTokenizer, model load, or remote access.
    return _ids(tuple(tokenizer.encode(text, add_special_tokens=False)), "encoded IDs", empty=True)


def _template_ids(tokenizer):
    if tokenizer.chat_template is None:
        prefix, suffix = "", "\n"
    else:
        dummy = "dummy context"
        separator = "\n" + "#" * len(dummy)
        rendered = tokenizer.apply_chat_template(
            [{"role": "user", "content": dummy + separator}],
            add_generation_prompt=True, tokenize=False, enable_thinking=False)
        pieces = rendered.split(separator)
        require(len(pieces) == 2 and pieces[0].count(dummy) == 1,
                "Chat-template extraction is ambiguous")
        prefix, suffix = pieces[0].split(dummy)[0], pieces[1]
    return _encoded(tokenizer, prefix), _encoded(tokenizer, suffix)


@dataclass(frozen=True)
class FrozenReplayPlan:
    """Actual immutable inputs, with context-only provenance and absolute offsets."""
    partition: Partition
    context_token_ids: tuple[int, ...]
    instruction_token_ids: tuple[int, ...]
    suffix_token_ids: tuple[int, ...]
    replay_token_ids: tuple[tuple[int, ...], ...]
    tokenizer_id: str
    tokenizer_revision: str
    chat_template_sha256: str
    prompt_policy: str = PROMPT_POLICY
    backend_commit: str = BACKEND_COMMIT

    def __post_init__(self):
        require(type(self.partition) is Partition, "Explicit Partition required")
        _ids(self.context_token_ids, "context IDs")
        _ids(self.instruction_token_ids, "instruction IDs")
        _ids(self.suffix_token_ids, "suffix IDs", empty=True)
        require(len(self.context_token_ids) == self.partition.token_count and
                canonical_hash(self.context_token_ids) == self.partition.context_sha256,
                "Frozen context IDs/hash differ from partition")
        require(isinstance(self.tokenizer_id, str) and bool(self.tokenizer_id), "Tokenizer identity required")
        require(isinstance(self.tokenizer_revision, str) and
                bool(re.fullmatch(r"[0-9a-f]{40}", self.tokenizer_revision)), "Immutable tokenizer revision required")
        require(isinstance(self.chat_template_sha256, str) and
                bool(re.fullmatch(r"[0-9a-f]{64}", self.chat_template_sha256)), "Template SHA-256 required")
        require(self.prompt_policy == PROMPT_POLICY and self.backend_commit == BACKEND_COMMIT,
                "Unsupported replay policy/source pin")
        require(type(self.replay_token_ids) is tuple and
                len(self.replay_token_ids) == len(self.partition.chunks), "One replay per complete microchunk required")
        for chunk, replay in zip(self.partition.chunks, self.replay_token_ids, strict=True):
            _ids(replay, "replay IDs")
            require(chunk.prompt_tokens == len(self.instruction_token_ids) + len(self.suffix_token_ids),
                    "Measured prompt overhead differs from microchunk")
            require(replay == self.instruction_token_ids + self.suffix_token_ids +
                    self.context_token_ids[chunk.start:chunk.end], "Replay IDs differ from frozen contiguous chunk")

    @property
    def fingerprint(self):
        return canonical_hash(asdict(self))

    def chunk_metadata(self, chunk_id):
        c = self.partition.chunks[chunk_id]
        return {"chunk_id": chunk_id, "start": c.start, "end": c.end,
                "prompt_tokens": c.prompt_tokens, "replay_input_tokens": len(self.replay_token_ids[chunk_id]),
                "replay_input_ids_sha256": canonical_hash(self.replay_token_ids[chunk_id]),
                "rope_delta": self.partition.token_count + c.prompt_tokens - c.start,
                "original_denominator_indices": list(self.partition.denominator_original_keys(chunk_id))}


def prepare_common_replay(context: PreparedContext, tokenizer, *, microchunk_tokens: int,
                          sink_tokens: int, tokenizer_id: str, tokenizer_revision: str):
    """Freeze complete fixed-position chunks from ONLY the prepared context.

    Tokenizer is supplied already pinned/local by the caller. The revision is a
    declared provenance pin; matching token IDs are independently rechecked before
    execution. No query/gold/config dictionary is accepted. Short tails are scored
    but the method-side AnchorPlan excludes unequal shapes from equal-cost arms.
    """
    require(type(context) is PreparedContext, "Only PreparedContext is accepted, without query/gold fields")
    _ids(context.token_ids, "context IDs")
    require(type(microchunk_tokens) is int and microchunk_tokens > 0, "Positive microchunk size required")
    prefix, suffix = _template_ids(tokenizer)
    require(context.prefix_length == len(prefix) and context.token_ids[:len(prefix)] == prefix,
            "Context prefix differs from pinned tokenizer template")
    instruction = _encoded(tokenizer, COMMON_PROMPT)
    chunks = tuple(Microchunk(start, min(start + microchunk_tokens, len(context.token_ids)),
                             len(instruction) + len(suffix))
                   for start in range(context.prefix_length, len(context.token_ids), microchunk_tokens))
    regions = tuple([-1] * context.prefix_length +
                    [i for i, c in enumerate(chunks) for _ in range(c.end - c.start)])
    partition = Partition(canonical_hash(context.token_ids), len(context.token_ids), context.prefix_length,
                          chunks, regions, "fixed_position", sink_tokens)
    replays = tuple(instruction + suffix + context.token_ids[c.start:c.end] for c in chunks)
    return FrozenReplayPlan(partition, context.token_ids, instruction, suffix, replays,
                            tokenizer_id, tokenizer_revision, canonical_hash(tokenizer.chat_template))


def _validate_tokenizer(replay, tokenizer):
    require(type(replay) is FrozenReplayPlan, "Explicit FrozenReplayPlan required")
    replay.__post_init__()
    prefix, suffix = _template_ids(tokenizer)
    require(canonical_hash(tokenizer.chat_template) == replay.chat_template_sha256 and
            _encoded(tokenizer, COMMON_PROMPT) == replay.instruction_token_ids and
            suffix == replay.suffix_token_ids and len(prefix) == replay.partition.prefix_length and
            replay.context_token_ids[:len(prefix)] == prefix, "Tokenizer/template no longer matches frozen replay IDs")


def _numpy(value, *, float32=False):
    if hasattr(value, "detach"):
        value = value.detach().cpu()
        if float32:
            value = value.float()  # BF16 cannot be passed to numpy directly.
        value = value.numpy()
    return np.array(value, dtype=np.float32 if float32 else None, copy=True)


def _score(value, shape, label):
    result = _numpy(value, float32=True)
    require(result.shape == shape and bool(np.isfinite(result).all()),
            f"{label} has invalid shape or nonfinite scalar values")
    return result


def logical_to_mask_indices(keep):
    """[L,H,N] bool keep -> per-layer (batch=0, head, token) pruned indices."""
    keep = _numpy(keep)
    require(keep.dtype == np.bool_ and keep.ndim == 3 and min(keep.shape) > 0,
            "keep mask must be nonempty boolean [layers, heads, tokens]")
    masks = []
    for layer in keep:
        head, token = np.nonzero(~layer)
        coordinates = (np.zeros(len(head), dtype=np.int64), head.astype(np.int64), token.astype(np.int64))
        for part in coordinates:
            part.setflags(write=False)
        masks.append(coordinates)
    return tuple(masks)


def mask_indices_to_keep(masks, shape):
    require(len(shape) == 3 and all(type(x) is int and x > 0 for x in shape), "Invalid logical mask shape")
    require(len(masks) == shape[0], "Mask layer count differs")
    keep = np.ones(shape, dtype=bool)
    for layer, mask in enumerate(masks):
        require(type(mask) in (tuple, list) and len(mask) == 3, "A coordinate triple is required per layer")
        b, h, t = (_numpy(part) for part in mask)
        require(all(x.ndim == 1 and x.dtype.kind in "iu" for x in (b, h, t)) and
                len(b) == len(h) == len(t), "Mask coordinates must be equal-length integer vectors")
        require(bool((b == 0).all()) and bool(((h >= 0) & (h < shape[1])).all()) and
                bool(((t >= 0) & (t < shape[2])).all()), "Mask coordinates outside batch/head/context bounds")
        require(len(set(zip(b.tolist(), h.tolist(), t.tolist()))) == len(b), "Duplicate mask coordinates")
        keep[layer, h, t] = False
    keep.setflags(write=False)
    return keep


def _cache_matches(cache, model, length):
    require(len(cache.layers) == len(model.model.layers), "Cache layer count differs")
    heads = model.config.num_key_value_heads
    for i, layer in enumerate(cache.layers):
        require(cache.get_seq_length(i) == length and
                tuple(layer.keys.shape[:3]) == (1, heads, length) and
                tuple(layer.values.shape) == tuple(layer.keys.shape) and
                layer.keys.shape[-1] == model.model.layers[i].self_attn.head_dim,
                "Scoring did not restore every layer to original cache length/layout")


def install_keep_mask(torch, model, keep, cache):
    """Install existing selection exactly, on each cache layer's device.

    No topk, rescoring, cache compaction or compress_post. The existing in-place
    attention patch is why every downstream query requires an independent clone.
    """
    masks = logical_to_mask_indices(keep)
    keep_array = _numpy(keep)
    shape = keep_array.shape
    require(shape[:2] == (len(model.model.layers), model.config.num_key_value_heads), "Model/mask shape differs")
    _cache_matches(cache, model, shape[-1])
    tensors = tuple(tuple(torch.tensor(part.copy(), dtype=torch.long, device=cache.layers[i].keys.device)
                          for part in coordinates) for i, coordinates in enumerate(masks))
    require(np.array_equal(mask_indices_to_keep(tensors, shape), keep_array), "Mask conversion changed selection")
    # Allocation/clone failure must not leave half of the model on a new mask.
    assigned = tuple(tuple(t.clone() for t in mask) for mask in tensors)
    previous = [(hasattr(layer.self_attn, "masked_key_indices"), getattr(layer.self_attn, "masked_key_indices", None))
                for layer in model.model.layers]
    try:
        for layer, mask in zip(model.model.layers, assigned, strict=True):
            layer.self_attn.masked_key_indices = mask
    except BaseException:
        for layer, (existed, old) in zip(model.model.layers, previous, strict=True):
            if existed:
                layer.self_attn.masked_key_indices = old
            elif hasattr(layer.self_attn, "masked_key_indices"):
                del layer.self_attn.masked_key_indices
        raise
    return tensors


def _snapshot_cache(cache):
    """Rollback dense DynamicCache references/metadata; no copies of KV payload."""
    return (cache.__dict__.copy(), [(layer, layer.__dict__.copy()) for layer in cache.layers])


def _restore_cache(cache, snapshot):
    state, layers = snapshot
    # The original list may have been appended to by a partially failed prefill.
    state = dict(state)
    state["layers"] = [layer for layer, _ in layers]
    cache.__dict__.clear()
    cache.__dict__.update(state)
    for layer, saved in layers:
        layer.__dict__.clear()
        layer.__dict__.update(saved)


def _ledger(replay, chunk_ids, events, *, diagnostic, completed=()):
    lengths = [len(replay.replay_token_ids[i]) for i in chunk_ids]
    attempted_ids = chunk_ids[:max(0, len(events) - 1)]
    attempted_lengths = [event["input_tokens"] for event in events[1:]]
    n = replay.partition.token_count
    return {"evidence_class": "diagnostic_only_full_reconstruction" if diagnostic else "independent_sparse_anchor_build",
            "deployable_cost": not diagnostic, "diagnostic_only": diagnostic,
            "replay_plan_sha256": replay.fingerprint, "partition_sha256": replay.partition.fingerprint,
            "context_sha256": replay.partition.context_sha256, "backend_commit": BACKEND_COMMIT,
            "prompt_policy_adaptation": PROMPT_POLICY, "exact_chunk_ids": list(attempted_ids),
            "planned_exact_chunk_ids": list(chunk_ids), "completed_exact_chunk_ids": list(completed),
            "planned_exact_replay_passes": len(chunk_ids), "completed_exact_replay_passes": len(completed),
            "planned_forward_input_lengths": [n] + lengths,
            "observed_forward_input_lengths": [e["input_tokens"] for e in events],
            "observed_forwards": copy.deepcopy(events), "exact_replay_passes": len(attempted_lengths),
            "replay_pass_count_scope": "Attempted forwards observed before model execution; completed passes reported separately",
            "exact_replay_input_tokens": sum(attempted_lengths),
            "exact_replay_context_tokens": sum(replay.partition.chunks[i].end - replay.partition.chunks[i].start for i in attempted_ids),
            "exact_replay_prompt_tokens": sum(replay.partition.chunks[i].prompt_tokens for i in attempted_ids),
            "replay_dense_causal_attention_pairs_proxy": sum(n * t + t * (t + 1) // 2 for t in attempted_lengths),
            "observed_replay_input_tokens": sum(e["input_tokens"] for e in events[1:]),
            "physical_memory_savings_demonstrated": False, "cache_compacted": False}


class CalibrationBuildError(RuntimeError):
    """A failed build retains attempted-forward accounting, never a success result."""
    def __init__(self, message, accounting):
        super().__init__(message)
        self.accounting = accounting


def _make_press(deps, model, replay, chunk_ids, captures):
    """Subclass pinned scoring hooks, leaving author policies completely untouched."""
    torch = deps.torch
    n = replay.partition.token_count
    layers, heads = model.config.num_hidden_layers, model.config.num_key_value_heads

    class CommonMicrochunkPress(deps.kvpress.EchoPress):
        def prepare(self, model, tokenizer, prev_postfix_size=8):
            self.score_val = torch.zeros((layers, 1, heads, n), dtype=model.dtype, device=model.device)
            self.score_val[..., :self.n_sink] = 1.0
            return [(torch.tensor([replay.context_token_ids[c.start:c.end]], dtype=torch.long),
                     torch.tensor([ids], dtype=torch.long))
                    for c, ids in zip(replay.partition.chunks, replay.replay_token_ids, strict=True)]

        def _chunk_scores(self, module, q, keys, start, end, n_prompt):
            candidates = [i for i, c in enumerate(replay.partition.chunks)
                          if (c.start, c.end, c.prompt_tokens) == (start, end, n_prompt)]
            require(len(candidates) == 1, "Virtual scorer changed frozen bounds/prompt length")
            chunk_id = candidates[0]
            require(tuple(keys.shape[:3]) == (1, heads, n) and q.shape[0] == 1 and
                    q.shape[2] == n and q.shape[1] == module.config.num_attention_heads and
                    q.shape[1] % heads == 0, "Virtual source-token/head-group layout differs")
            expected = tuple(range(min(self.n_sink, start))) + tuple(range(start, end))
            require(expected == replay.partition.denominator_original_keys(chunk_id), "Virtual denominator changed")
            scores = super()._chunk_scores(module, q, keys, start, end, n_prompt)
            key = (int(module.layer_idx), chunk_id)
            require(key not in captures["virtual"], "Duplicate virtual scoring hook")
            captures["virtual"][key] = _score(scores, (heads, end - start), "virtual pre-storage scores")
            captures["virtual_dtypes"].add(str(scores.dtype))
            return scores

        def _compute_cross_attention(self, module, hidden_states, keys, kwargs):
            chunk_id = self._active_chunk
            c = replay.partition.chunks[chunk_id]
            require((self.start_idx, self.end_idx) == (c.start, c.end), "Sparse replay lost absolute offsets")
            q_len = len(replay.replay_token_ids[chunk_id])
            require(tuple(keys.shape[:3]) == (1, heads, n + q_len) and hidden_states.shape[:2] == (1, q_len),
                    "Exact replay cache/input shape differs from frozen plan")
            expected = tuple(range(min(self.n_sink, c.start))) + tuple(range(c.start, c.end))
            require(expected == replay.partition.denominator_original_keys(chunk_id), "Exact denominator changed")
            weights = super()._compute_cross_attention(module, hidden_states, keys, kwargs)
            sink = min(self.n_sink, c.start)
            require(tuple(weights.shape) == (1, heads, module.config.num_attention_heads // heads,
                                            q_len, sink + c.end - c.start + q_len),
                    "Exact attention denominator shape differs")
            scores = weights[..., sink:sink + c.end - c.start].amax(dim=(-3, -2))
            key = (int(module.layer_idx), chunk_id)
            require(key not in captures["exact"], "Duplicate exact scoring hook")
            captures["exact"][key] = _score(scores, (1, heads, c.end - c.start), "exact pre-storage scores")[0]
            captures["exact_dtypes"].add(str(scores.dtype))
            return weights  # inherited score_kvzip assigns only after capture

        def _finalize(self, model):
            # All _pairs/_chunks survive; the sparse list never changes partition.
            with ExitStack() as hooks:
                for layer in model.model.layers:
                    handle = layer.self_attn.register_forward_hook(self.forward_hook, with_kwargs=True)
                    hooks.callback(handle.remove)
                for chunk_id in chunk_ids:
                    c = replay.partition.chunks[chunk_id]
                    self._active_chunk = chunk_id
                    self.start_idx, self.end_idx = c.start, c.end
                    snapshot = _snapshot_cache(self._cache)
                    try:
                        ids = self._pairs[chunk_id][1].to(model.device)
                        positions = torch.arange(n, n + ids.shape[1], device=model.device).unsqueeze(0)
                        model(input_ids=ids, past_key_values=self._cache, position_ids=positions,
                              use_cache=True, logits_to_keep=1)
                        _cache_matches(self._cache, model, n)
                        captures["completed"].append(chunk_id)
                    except BaseException:
                        _restore_cache(self._cache, snapshot)
                        raise

        def compress_post(self, model):
            raise RuntimeError("Common-microchunk adapter must install its existing logical mask, never reselect")

    return CommonMicrochunkPress(compression_ratio=0.0, layerwise=False,
        n_sink=replay.partition.sink_tokens, chunk_size=max(c.end - c.start for c in replay.partition.chunks),
        kvzip_plus_normalization=False, exact_first_chunk=False, score_calibration=False,
        guard_tokens=0, scoring_backend="torch_eager")


def _collect(deps, model, tokenizer, replay, chunk_ids, *, diagnostic):
    _validate_tokenizer(replay, tokenizer)
    require(bool(chunk_ids) and tuple(sorted(set(chunk_ids))) == chunk_ids and
            all(type(i) is int and 0 <= i < len(replay.partition.chunks) for i in chunk_ids), "Invalid exact chunk IDs")
    require(model.config.num_hidden_layers == len(model.model.layers) and model.config.num_key_value_heads > 0 and
            model.config.num_attention_heads % model.config.num_key_value_heads == 0, "Unsupported layer/head layout")
    require(model.config._attn_implementation == "sdpa", "Common adapter requires the existing SDPA attention patch")
    require(model.config.model_type in ("qwen3", "llama") and
            not getattr(model.config, "sliding_window", None) and not getattr(model.config, "use_sliding_window", False),
            "Only dense full-attention Qwen3/Llama caches are supported")
    for rope in (getattr(model.config, "rope_scaling", None), getattr(model.config, "rope_parameters", None)):
        require(not rope or rope.get("rope_type", rope.get("type", "default")) == "default",
                "Scaled/dynamic RoPE needs separate numerical validation")
    require(not getattr(model, "training", False), "Evaluation mode is required for repeatable calibration builds")
    device_map = getattr(model, "hf_device_map", None)
    require(not device_map or len({str(device) for device in device_map.values()}) == 1,
            "Sharded/offloaded models require a separate adapter validation")
    require(all(hasattr(layer.self_attn, "q_proj") for layer in model.model.layers), "Projected-query hooks required")
    n = replay.partition.token_count
    require(n + max(len(replay.replay_token_ids[i]) for i in chunk_ids) <= model.config.max_position_embeddings,
            "Replay exceeds model positional capacity")
    cache = deps.transformers.DynamicCache()
    empty_cache = _snapshot_cache(cache)
    torch = deps.torch
    captures = {"virtual": {}, "exact": {}, "virtual_dtypes": set(), "exact_dtypes": set(), "completed": []}
    events = []
    expected_ids = (replay.context_token_ids,) + tuple(replay.replay_token_ids[i] for i in chunk_ids)
    press = _make_press(deps, model, replay, chunk_ids, captures)
    previous_masks = [(hasattr(layer.self_attn, "masked_key_indices"), getattr(layer.self_attn, "masked_key_indices", None))
                      for layer in model.model.layers]
    started = time.perf_counter()

    def observe(module, args, kwargs):
        ids = _numpy(kwargs["input_ids"])
        event = {"input_tokens": int(ids.shape[-1]), "input_ids_sha256": canonical_hash(ids[0].tolist()) if ids.ndim == 2 and ids.shape[0] == 1 else canonical_hash(ids.tolist()),
                 "phase": "prefill" if not events else "exact_replay"}
        events.append(event)  # Record attempted forwards even if validation/scoring fails.
        index = len(events) - 1
        require(index < len(expected_ids) and ids.shape == (1, len(expected_ids[index])) and
                tuple(ids[0].tolist()) == expected_ids[index], "Observed forward IDs/order differ from frozen plan")
        start = 0 if index == 0 else n
        positions = _numpy(kwargs["position_ids"])
        require(np.array_equal(positions, np.arange(start, start + ids.shape[1])[None, :]),
                "Observed RoPE positions differ from frozen replay plan")

    try:
        for layer in model.model.layers:
            layer.self_attn.masked_key_indices = None
        press.post_init_from_model(model)
        press._context_ids = torch.tensor([replay.context_token_ids], dtype=torch.long, device=model.device)
        press._cache = cache
        press.context_length, press.prefix_length = n, replay.partition.prefix_length
        press._suffix_ids = torch.tensor([replay.suffix_token_ids], dtype=torch.long)
        press._inv_freq = model.model.rotary_emb.inv_freq
        press._pairs = press.prepare(model, tokenizer)
        press._chunks = [(c.start, c.end, c.prompt_tokens) for c in replay.partition.chunks]
        with ExitStack() as tracking:
            tracking.enter_context(torch.no_grad())
            tracking.callback(model.model.register_forward_pre_hook(observe, with_kwargs=True).remove)
            with ExitStack() as prefill_hooks:
                for i, layer in enumerate(model.model.layers):
                    prefill_hooks.callback(layer.self_attn.q_proj.register_forward_hook(partial(press._q_hook, layer_idx=i)).remove)
                    prefill_hooks.callback(layer.self_attn.register_forward_hook(press._prefill_hook, with_kwargs=True).remove)
                model.model(input_ids=press._context_ids, past_key_values=cache, use_cache=True,
                            position_ids=torch.arange(n, device=model.device).unsqueeze(0))
            _cache_matches(cache, model, n)
            press._finalize(model)
        require(len(events) == len(expected_ids), "Observed forward count differs from replay plan")
        virtual = np.zeros((model.config.num_hidden_layers, 1, model.config.num_key_value_heads, n), dtype=np.float32)
        virtual[..., :replay.partition.sink_tokens] = 1.0
        expected_virtual = {(layer, i) for layer in range(virtual.shape[0]) for i in range(len(replay.partition.chunks))}
        expected_exact = {(layer, i) for layer in range(virtual.shape[0]) for i in chunk_ids}
        require(set(captures["virtual"]) == expected_virtual and set(captures["exact"]) == expected_exact,
                "Missing/extra layer/chunk scalar observations")
        for (layer, i), values in captures["virtual"].items():
            c = replay.partition.chunks[i]
            virtual[layer, 0, :, c.start:c.end] = values
        # The batch axis is explicit; never flatten it together with heads.
        virtual = VirtualScores(replay.partition, virtual[:, 0, :, :])
        exact = np.stack([np.concatenate([captures["exact"][(layer, i)] for i in chunk_ids], axis=-1)
                          for layer in range(model.config.num_hidden_layers)])
        ledger = _ledger(replay, chunk_ids, events, diagnostic=diagnostic, completed=captures["completed"])
        ledger.update({"status": "scoring_completed", "scoring_host_wall_seconds": time.perf_counter() - started,
                       "timing_scope": "Host wall including CPU capture; NOT CUDA-synchronized deployable latency",
                       "virtual_pre_storage_scalar_dtypes": sorted(captures["virtual_dtypes"]),
                       "exact_pre_storage_scalar_dtypes": sorted(captures["exact_dtypes"]),
                       "precision_note": "float32 container preserves captured native scalar values, never recovers prior rounding",
                       "chunks": [replay.chunk_metadata(i) for i in range(len(replay.partition.chunks))]})
        return cache, virtual, exact, ledger
    except BaseException as exc:
        _restore_cache(cache, empty_cache)
        ledger = _ledger(replay, chunk_ids, events, diagnostic=diagnostic, completed=captures["completed"])
        ledger.update({"status": "failed", "scoring_host_wall_seconds": time.perf_counter() - started,
                       "error_type": type(exc).__name__})
        if isinstance(exc, Exception):
            raise CalibrationBuildError(str(exc), ledger) from exc
        raise
    finally:
        press._q.clear()
        press._v0.clear()
        press._chunks, press._pairs = [], []
        press._reset_internal_parameters()
        for layer, (existed, old) in zip(model.model.layers, previous_masks, strict=True):
            if existed:
                layer.self_attn.masked_key_indices = old
            elif hasattr(layer.self_attn, "masked_key_indices"):
                del layer.self_attn.masked_key_indices


@dataclass(frozen=True)
class CandidateBuild:
    cache: object
    virtual: VirtualScores
    anchors: AnchorObservations
    calibration: object
    keep_mask: np.ndarray
    masks: tuple
    accounting: dict
    selection: dict


@dataclass(frozen=True)
class DiagnosticBuild:
    """Full exact labels and their full charged build; never a deployable candidate."""
    virtual: VirtualScores
    full_exact: object
    accounting: dict


def build_candidate(deps, model, tokenizer, replay: FrozenReplayPlan, anchors: AnchorPlan, *,
                    eviction_ratio, recent_tokens=0, precision=Precision(), calibration_enabled=True,
                    tie_policy="author_left", clipping="clip", tie_break="stable", seed=0):
    started = time.perf_counter()
    require(type(replay) is FrozenReplayPlan and type(anchors) is AnchorPlan,
            "Deployable builder accepts only frozen replay and anchor plans; no diagnostic labels")
    require(anchors.partition.fingerprint == replay.partition.fingerprint, "Anchor/replay partitions differ")
    require(type(precision) is Precision and type(calibration_enabled) is bool and
            tie_policy in ("author_left", "collapse_mean") and clipping in ("clip", "reject"),
            "Invalid calibration controls")
    require(not calibration_enabled or len(anchors.token_indices) >= 2 or
            len(anchors.token_indices) == replay.partition.token_count - replay.partition.prefix_length,
            "Enabled calibration requires at least two anchor knots when unanchored body tokens remain")
    # Reject impossible budgets before paying for any forwards.
    select_logical(np.zeros((model.config.num_hidden_layers, model.config.num_key_value_heads,
                             replay.partition.token_count), np.float32), replay.partition, eviction_ratio,
                   recent_tokens=recent_tokens, tie_break=tie_break, seed=seed)
    cache, virtual, exact, accounting = _collect(deps, model, tokenizer, replay, anchors.chunk_ids, diagnostic=False)
    try:
        observations = AnchorObservations(anchors, exact)
        calibrated = calibrate(virtual, observations, precision=precision, enabled=calibration_enabled,
                               tie_policy=tie_policy, clipping=clipping)
        keep, selection = select_logical(calibrated.scores, replay.partition, eviction_ratio,
                                        recent_tokens=recent_tokens, tie_break=tie_break, seed=seed)
        masks = install_keep_mask(deps.torch, model, keep, cache)
        accounting["anchor_plan_sha256"] = anchors.fingerprint
        accounting["selection_adaptation"] = "fixed_total_logical_mask_installed_without_author_topk"
        accounting["status"] = "completed"
        accounting["total_builder_host_wall_seconds"] = time.perf_counter() - started
        return CandidateBuild(cache, virtual, observations, calibrated, keep, masks, accounting, selection)
    except BaseException as exc:
        cache.layers.clear()  # Private unsuccessful build: release owned KV references.
        accounting.update(status="failed_after_scoring", error_type=type(exc).__name__,
                          total_builder_host_wall_seconds=time.perf_counter() - started)
        if isinstance(exc, Exception):
            raise CalibrationBuildError(str(exc), accounting) from exc
        raise


def build_full_exact_diagnostic(deps, model, tokenizer, replay: FrozenReplayPlan, *, diagnostic_only):
    """Explicit expensive path: independently replays ALL chunks, including tail."""
    started = time.perf_counter()
    require(type(replay) is FrozenReplayPlan, "Explicit FrozenReplayPlan required")
    require(diagnostic_only is True, "Full reconstruction requires explicit diagnostic_only=True")
    from research.calibration_methods.diagnostics import FullExactDiagnostic
    chunk_ids = tuple(range(len(replay.partition.chunks)))
    cache, virtual, exact, accounting = _collect(deps, model, tokenizer, replay, chunk_ids, diagnostic=True)
    full = np.zeros_like(virtual.values)
    full[..., :replay.partition.sink_tokens] = 1.0
    full[..., replay.partition.prefix_length:] = exact
    del cache
    accounting.update(status="completed", total_builder_host_wall_seconds=time.perf_counter() - started)
    return DiagnosticBuild(virtual, FullExactDiagnostic(replay.partition, full), accounting)


def clone_query_cache(deps, model, candidate: CandidateBuild):
    require(type(candidate) is CandidateBuild, "Queries require a selected CandidateBuild, not diagnostic labels")
    from .runtime import independent_cache
    cache = independent_cache(candidate.cache)
    try:
        install_keep_mask(deps.torch, model, candidate.keep_mask, cache)
        return cache
    except BaseException:
        cache.layers.clear()
        raise


def answer_candidate(deps, model, tokenizer, candidate: CandidateBuild, query_ids, *, max_new_tokens):
    """Query use is a separate phase, sharing the existing common greedy decoder."""
    from .runtime import greedy_answer, clear_masks
    cache = None
    try:
        cache = clone_query_cache(deps, model, candidate)
        with deps.torch.no_grad():
            answer = greedy_answer(deps.torch, model, tokenizer, query_ids, cache,
                                   candidate.virtual.partition.token_count, max_new_tokens)
        _cache_matches(candidate.cache, model, candidate.virtual.partition.token_count)
        return answer
    finally:
        clear_masks(model)
        if cache is not None:
            cache.layers.clear()
