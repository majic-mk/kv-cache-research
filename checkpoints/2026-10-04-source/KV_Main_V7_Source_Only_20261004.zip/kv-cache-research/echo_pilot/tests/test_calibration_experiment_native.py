"""Optional native tiny-Qwen CPU entrypoint tests, no pretrained weights/CUDA.

Run in /tmp/kv_tiny_qwen_cpu_20261003. Default dependency-light tests skip these.
Synchronized GPU timing/loader verification are deliberately patched in these
fixtures; the real architecture, masks, clones and greedy decoder execute.
"""
from contextlib import ExitStack
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np

from echo_pilot import calibration_experiment as ex
from echo_pilot.calibration_runtime import build_candidate, build_full_exact_diagnostic, prepare_common_replay
from echo_pilot.contracts import PreparedContext
from research.calibration_methods.methods import plan_anchors

AVAILABLE = importlib.util.find_spec("torch") is not None and importlib.util.find_spec("transformers") is not None


@unittest.skipUnless(AVAILABLE, "Optional real Torch/Transformers CPU environment absent")
class NativeScreenTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        helper_dir = ex.ROOT / "research/diagnostics/tiny_qwen_cpu"
        sys.path.insert(0, str(helper_dir))
        import test_tiny_qwen_cpu as native
        cls.native = native
        native.torch.set_num_threads(1)

    @classmethod
    def tearDownClass(cls):
        for name, func in cls.native.ORIGINAL_ATTENTION.items():
            cls.native.ALL_ATTENTION_FUNCTIONS[name] = func

    def setUp(self):
        native = self.native
        native.ALL_ATTENTION_FUNCTIONS["sdpa"] = native.PATCHED_SDPA
        self.model, self.tokenizer, _ = native.fixture()
        self.context = PreparedContext("tiny-context", "synthetic", (1, 3) + tuple(range(10, 34)), 2, (), 26, {})
        self.replay = prepare_common_replay(self.context, self.tokenizer, microchunk_tokens=4, sink_tokens=4,
                    tokenizer_id="synthetic/tokenizer-shim-not-pretrained", tokenizer_revision="a" * 40)

    def test_native_oracle_query_clones_are_isolated_without_rescoring(self):
        deps = self.native.DEPS
        first = build_candidate(deps, self.model, self.tokenizer, self.replay,
                                plan_anchors(self.replay.partition, 4, "first"), eviction_ratio=.5, seed=ex.SEED)
        diagnostic = build_full_exact_diagnostic(deps, self.model, self.tokenizer, self.replay, diagnostic_only=True)
        before = self.native.payload(first.cache)
        _, masks, _, _ = ex.diagnostic_masks(first, diagnostic, self.replay)
        forwards = []
        handle = self.model.model.register_forward_pre_hook(lambda m, a, kw: forwards.append(kw["input_ids"].shape[1]), with_kwargs=True)
        def cpu_call(torch, events, operation, call, deadline):
            started = time.perf_counter(); value = call()
            return value, {"cpu_host_seconds": time.perf_counter() - started, "gpu_timing": "not_measured"}
        try:
            with deps.torch.inference_mode(), patch.object(ex, "timed_call", cpu_call), \
                 patch("echo_pilot.calibration_runtime.build_candidate", side_effect=AssertionError("No rescoring")), \
                 patch("echo_pilot.calibration_runtime.build_full_exact_diagnostic", side_effect=AssertionError("No rescoring")):
                outputs = [ex.evaluate_mask(deps, self.model, self.tokenizer, first.cache, masks[arm],
                            {"question_token_ids": [40, 41]}, 26, 3, io.StringIO(), arm, time.monotonic() + 100)
                           for arm in ("fullkv", "no_calibration", *ex.ORACLES)]
        finally:
            handle.remove()
        self.assertTrue(all(1 <= r["generated_token_count"] <= 3 for r in outputs))
        self.assertTrue(all(n in (1, 2) for n in forwards))
        for (keys, vals), layer in zip(before, first.cache.layers, strict=True):
            self.assertTrue(deps.torch.equal(keys, layer.keys))
            self.assertTrue(deps.torch.equal(vals, layer.values))
        self.assertTrue(all(l.self_attn.masked_key_indices is None for l in self.model.model.layers))
        self.assertTrue(all(r["query_cache"]["compacted"] is False for r in outputs))

    def test_fullkv_skips_fake_key_search_and_search_failure_cleans_compressed_clone(self):
        n = self.native
        first = build_candidate(n.DEPS, self.model, self.tokenizer, self.replay,
                                plan_anchors(self.replay.partition, 4, "first"), eviction_ratio=.5)
        source = n.payload(first.cache)
        def cpu_call(torch, events, operation, call, deadline):
            return call(), {"cpu_fixture": True}
        with n.torch.inference_mode(), patch.object(ex, "timed_call", cpu_call), \
             patch.object(n.ATTENTION, "search_hyperplane", side_effect=ValueError("injected fake-key failure")) as search:
            ex.evaluate_mask(n.DEPS, self.model, self.tokenizer, first.cache, np.ones_like(first.keep_mask),
                             {"question_token_ids": [40, 41]}, 26, 1, io.StringIO(), "fullkv", time.monotonic() + 10)
            search.assert_not_called()
            with self.assertRaisesRegex(ValueError, "fake-key failure"):
                ex.evaluate_mask(n.DEPS, self.model, self.tokenizer, first.cache, first.keep_mask,
                                 {"question_token_ids": [40, 41]}, 26, 1, io.StringIO(), "compressed", time.monotonic() + 10)
        self.assertTrue(all(l.self_attn.masked_key_indices is None for l in self.model.model.layers))
        for (keys, values), layer in zip(source, first.cache.layers, strict=True):
            self.assertTrue(n.torch.equal(keys, layer.keys))
            self.assertTrue(n.torch.equal(values, layer.values))

    def test_native_build_crossing_envelope_deadline_releases_owned_cache_and_cost(self):
        from types import SimpleNamespace
        from echo_pilot.contracts import ContractError
        returned = []
        def build():
            candidate = build_candidate(self.native.DEPS, self.model, self.tokenizer, self.replay,
                                        plan_anchors(self.replay.partition, 4, "first"), eviction_ratio=.5)
            returned.append(candidate)
            return candidate
        fake_clock_torch = SimpleNamespace(cuda=SimpleNamespace(reset_peak_memory_stats=lambda _: None))
        events = io.StringIO()
        with patch("echo_pilot.runtime.synchronized_time", side_effect=[1., 2.]), \
             patch("echo_pilot.runtime.memory_snapshot", return_value={"cpu_fixture": True}), \
             patch.object(ex.time, "monotonic", side_effect=[1., 20.]):
            with self.assertRaises(ContractError) as error:
                ex.timed_call(fake_clock_torch, events, "native-build", build, deadline=10.)
        self.assertFalse(returned[0].cache.layers)
        self.assertEqual(error.exception.accounting["completed_exact_replay_passes"], 4)
        self.assertEqual(error.exception.accounting["operation_envelope_status"], "failed_after_scoring")
        self.assertEqual([json.loads(x)["event"] for x in events.getvalue().splitlines()], ["started", "failed"])
        self.native.clear_masks(self.model)

    def test_model_placement_failure_clears_outer_owned_model_reference_and_masks(self):
        n = self.native
        self.model.config._commit_hash = "a" * 40
        config = {"runtime": {"device": "cpu", "deterministic_algorithms": True},
                  "model": {"id": "fixture/model", "tokenizer_id": "synthetic/tokenizer-shim-not-pretrained",
                            "tokenizer_revision": "a" * 40, "revision": "a" * 40, "dtype": "float32"}}
        for layer in self.model.model.layers:
            layer.self_attn.masked_key_indices = (n.torch.tensor([0]), n.torch.tensor([0]), n.torch.tensor([4]))
        def cpu_call(torch, events, operation, call, deadline): return call(), {"cpu_fixture": True}
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            stack.enter_context(patch("echo_pilot.runtime.load_dependencies", return_value=n.DEPS))
            stack.enter_context(patch("echo_pilot.runtime.verify_environment", return_value={"fixture_only": True}))
            stack.enter_context(patch("echo_pilot.runtime.deterministic_environment", return_value={"fixture_only": True}))
            stack.enter_context(patch("echo_pilot.runtime.validate_template"))
            stack.enter_context(patch("echo_pilot.runtime.validate_model_config"))
            stack.enter_context(patch.object(ex, "timed_call", cpu_call))
            stack.enter_context(patch.object(n.transformers.AutoTokenizer, "from_pretrained", return_value=self.tokenizer))
            stack.enter_context(patch.object(n.transformers.AutoConfig, "from_pretrained", return_value=self.model.config))
            stack.enter_context(patch.object(n.transformers.AutoModelForCausalLM, "from_pretrained", return_value=self.model))
            stack.enter_context(patch.object(self.model, "to", side_effect=RuntimeError("injected placement failure")))
            try:
                ex.execute(config, [self.context], {}, {}, {}, [self.replay], {"max_wall_seconds": 100}, Path(temp))
            except RuntimeError as error:
                tb = error.__traceback__; frames = []
                while tb:
                    if tb.tb_frame.f_code.co_filename == ex.__file__: frames.append(tb.tb_frame)
                    tb = tb.tb_next
                self.assertTrue(frames)
                self.assertTrue(all("model" not in frame.f_locals for frame in frames))
            else:
                self.fail("Expected injected placement failure")
        self.assertTrue(all(l.self_attn.masked_key_indices is None for l in self.model.model.layers))

    def test_native_internal_execute_emits_all_nine_arms_and_four_builds(self):
        """Exercise runtime orchestration; loader/security gates are separately tested.

        The resulting partial directory has no COMPLETE marker or real-model
        provenance. It is solely CPU synthetic integration evidence.
        """
        n = self.native
        self.model.config._commit_hash = "a" * 40
        self.model.generation_config.eos_token_id = list(range(64))  # One token keeps this fixture bounded.
        config = {"runtime": {"device": "cpu", "deterministic_algorithms": True},
                  "model": {"id": "fixture/model", "tokenizer_id": "synthetic/tokenizer-shim-not-pretrained",
                            "tokenizer_revision": "a" * 40, "revision": "a" * 40, "dtype": "float32"}}
        # Actual CPU times are explicitly confined to this synthetic test helper;
        # no GPU timing value is fabricated and no archive is marked completed.
        def cpu_call(torch, events, operation, call, deadline):
            started = time.perf_counter(); value = call()
            result = {"cpu_host_seconds": time.perf_counter() - started, "gpu_timing": "not_measured"}
            ex._event(events, "cpu_fixture_operation", operation=operation, **result)
            return value, result
        queries = {self.context.context_id: [{"context_id": self.context.context_id, "question_id": "tiny-q", "question_token_ids": [40, 41]}]}
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            out = Path(temp)
            stack.enter_context(patch("socket.create_connection", side_effect=AssertionError("No network")))
            stack.enter_context(patch("echo_pilot.runtime.load_dependencies", return_value=n.DEPS))
            stack.enter_context(patch("echo_pilot.runtime.verify_environment", return_value={"fixture_only": True}))
            stack.enter_context(patch("echo_pilot.runtime.deterministic_environment", return_value={"fixture_only": True}))
            stack.enter_context(patch("echo_pilot.runtime.validate_template"))
            stack.enter_context(patch("echo_pilot.runtime.validate_model_config"))
            stack.enter_context(patch("echo_pilot.runtime.synchronized_time", side_effect=lambda _: time.perf_counter()))
            stack.enter_context(patch.object(ex, "timed_call", cpu_call))
            stack.enter_context(patch.object(n.transformers.AutoTokenizer, "from_pretrained", return_value=self.tokenizer))
            stack.enter_context(patch.object(n.transformers.AutoConfig, "from_pretrained", return_value=self.model.config))
            stack.enter_context(patch.object(n.transformers.AutoModelForCausalLM, "from_pretrained", return_value=self.model))
            ex.execute(config, [self.context], queries, {}, {}, [self.replay], {"max_wall_seconds": 100}, out)
            rows = [json.loads(line) for line in (out / "results.jsonl").read_text().splitlines()]
            build = json.loads((out / "c00000/build.json").read_text())
            self.assertEqual({r["arm"] for r in rows}, set(ex.ARMS))
            self.assertEqual(len(rows), 9)
            self.assertEqual(set(build["accounting"]), {*ex.POLICIES, "full_exact_diagnostic"})
            self.assertEqual([build["accounting"][a]["runtime"]["exact_replay_passes"] for a in ex.POLICIES], [4, 4, 4])
            self.assertEqual(build["accounting"]["full_exact_diagnostic"]["runtime"]["exact_replay_passes"], 6)
            self.assertFalse((out / "COMPLETE.json").exists())
            self.assertFalse(build["physical_memory_savings_demonstrated"])
            for arm in ex.POLICIES:
                physical = build["accounting"][arm]["cache"]
                self.assertGreaterEqual(physical["kv_unique_storage_bytes"], physical["kv_tensor_payload_bytes"])
            with np.load(out / "c00000/scores_masks.npz", allow_pickle=False) as captures:
                self.assertEqual(len(captures.files), 26)
                self.assertIn("score__pooled_full_map_oracle", captures.files)
                self.assertIn("keep__pooled_full_map_oracle", captures.files)


if __name__ == "__main__":
    unittest.main()
