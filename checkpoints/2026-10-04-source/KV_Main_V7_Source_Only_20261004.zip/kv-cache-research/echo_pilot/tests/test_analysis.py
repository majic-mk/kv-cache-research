"""Synthetic fixture-only output archives. NEVER model, GPU or quality evidence."""
import copy
import io
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

from data_prep import metrics
from echo_pilot import BACKEND_COMMIT
from echo_pilot.analysis import (BENCHMARK_REVISION, QUALITY_BACKEND, _fixture_masks,
                                  _torch_masks, analyze_run, cluster_bootstrap)
from echo_pilot.cli import main, run as run_cli, write_json
from echo_pilot.contracts import ContractError, canonical_hash, prepare_context, selection_budget, sha256_file, summarize_plan
from echo_pilot.tests.test_contracts import fixture_config, fixture_context
from kv_harness.manifest import RunManifest

REPO = Path(__file__).resolve().parents[2]


def jsonl(path, rows):
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def fixture_archive(root):
    """2 contexts, 3 questions (2 in one cluster), 4 arms, 2 ratios = 21 rows."""
    run = root / "run"
    run.mkdir()
    config = fixture_config()
    config["dataset"].update(source_id="zai-org/LongBench/lcc", split="development")
    config["selection"]["eviction_ratios"] = [0.5, 0.75]
    config["selection"]["chunk_size"] = 7
    config["generation"]["max_new_tokens"] = 3
    contexts = [fixture_context(), {**fixture_context(), "context_id": "fixture-context-2", "source_id": "fixture-source-2"}]
    contexts[1]["context_token_ids"] = [1, 2] + list(range(20, 30))
    queries = [{"context_id": contexts[0]["context_id"], "question_id": "fixture-q1", "question_token_ids": [8, 9]},
               {"context_id": contexts[0]["context_id"], "question_id": "fixture-q2", "question_token_ids": [7, 9]},
               {"context_id": contexts[1]["context_id"], "question_id": "fixture-q3", "question_token_ids": [6, 9]}]
    labels = [{"context_id": q["context_id"], "question_id": q["question_id"], "dataset": "lcc", "metric": metrics.METRIC,
               "reference_texts": ["return 1"]} for q in queries]
    artifacts = {}
    for kind, rows in (("contexts", contexts), ("questions", queries), ("labels", labels)):
        path = root / (kind + ".jsonl")
        jsonl(path, rows)
        artifacts[kind] = {"path": path.name, "rows": len(rows), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
        if kind != "labels":
            config["dataset"][kind + "_sha256"] = artifacts[kind]["sha256"]
    selected = []
    for q in queries:
        c = next(c for c in contexts if c["context_id"] == q["context_id"])
        selected.append({"context_id": c["context_id"], "question_id": q["question_id"], "split": "development",
                         "context_token_ids_sha256": canonical_hash(c["context_token_ids"]),
                         "question_token_ids_sha256": canonical_hash(q["question_token_ids"]),
                         "references_sha256": canonical_hash(["return 1"])})
    data = {"schema_version": 1, "benchmark_code_revision": BENCHMARK_REVISION,
            "metric_implementation_sha256": sha256_file(Path(metrics.__file__)),
            "source_revision": config["dataset"]["source_revision"], "preprocessor_sha256": config["dataset"]["preprocessing_sha256"],
            "tokenizer_revision": config["model"]["tokenizer_revision"],
            "template": {k: v for k, v in config["template"].items() if k != "prompt_mode"},
            "settings": {"metric": metrics.METRIC, "evidence_kind": "fixture_only"},
            "presets": {"fixture": {"artifacts": {"lcc.development": artifacts},
                        "max_new_tokens": 3, "limits": {"max_context_tokens": 16}, "datasets": {"lcc": {"selected": selected}}}}}
    write_json(root / "data_manifest.json", data)
    lock = {"python_version": "3.12.14", "backend_commit": BACKEND_COMMIT,
            "packages": {name: "fixture" for name in ("torch", "transformers", "kvpress", "numpy", "peft")}}
    write_json(run / "packages.lock.json", lock)
    config["runtime"]["packages_lock_sha256"] = sha256_file(run / "packages.lock.json")
    write_json(run / "frozen_config.json", config)
    prepared = [prepare_context(c, config) for c in contexts]
    grouped = {c.context_id: [q for q in queries if q["context_id"] == c.context_id] for c in prepared}
    write_json(run / "input_plan.json", summarize_plan(config, prepared, grouped))
    pins = {"model": {"identifier": config["model"]["id"], "revision_kind": "git_commit", "revision": config["model"]["revision"]},
            "dataset": {"identifier": config["dataset"]["source_id"], "revision_kind": "git_commit", "revision": config["dataset"]["source_revision"]},
            "tokenized_contexts": {"identifier": "frozen-context-jsonl", "revision_kind": "sha256", "revision": artifacts["contexts"]["sha256"]},
            "tokenized_questions": {"identifier": "frozen-question-jsonl", "revision_kind": "sha256", "revision": artifacts["questions"]["sha256"]}}
    evidence = RunManifest.create(repo=REPO, evidence_kind="cpu_fixture", artifacts=pins, config=config, seed=config["runtime"]["seed"])
    evidence.save(run / "evidence_manifest.json")
    write_json(run / "environment.json", lock)
    write_json(run / "resolved_model_config.json", {"num_hidden_layers": 2, "num_key_value_heads": 1, "head_dim": 2, "_name_or_path": config["model"]["id"]})
    write_json(run / "model_load.json", {"wall_seconds": 0, "model_parameter_bytes": 0, "fixture_only": True})
    rows = []
    for ci, context in enumerate(prepared):
        for arm in config["arms"]:
            for ri, ratio in enumerate([0.0] if arm == "fullkv" else config["selection"]["eviction_ratios"]):
                bid = f"c{ci:05d}-{arm}-r{ri:02d}"
                folder = run / bid
                folder.mkdir()
                budget = selection_budget(2, 1, 12, ratio, 1, 0)
                masks, keep = [None, None], None
                if arm != "fullkv":
                    # Even per-layer synthetic allocation preserves protected position zero.
                    count = budget["pruned_pairs"] // 2
                    masks = [[[0] * count, [0] * count, list(range(12-count, 12))] for _ in range(2)]
                    # Shape [layers, batch=1, heads=1, tokens].
                    one_layer = [[[s < 12-count for s in range(12)]]]
                    keep = [copy.deepcopy(one_layer) for _ in range(2)]
                write_json(folder / "scores_masks.pt", {"fixture_only": True, "masked_key_indices": masks, "logical_keep_mask": keep})
                allocation = {"actual_pruned_pairs": budget["pruned_pairs"], "actual_retained_pairs": budget["retained_pairs"]}
                if arm != "fullkv":
                    allocation.update(_fixture_masks(folder / "scores_masks.pt", context, 2, 1, config["selection"], False))
                chunks = []
                if arm != "fullkv":
                    # Authored ordering: prompt, previous-chunk postfix, suffix,
                    # then current context body. Native KVzip has a 7/3 split;
                    # Echo/matched have 5/5 after first-prompt overhead.
                    bounds = ((2, 9), (9, 12)) if arm == "kvzip" else ((2, 7), (7, 12))
                    previous = []
                    for i, (start, end) in enumerate(bounds):
                        body = list(context.token_ids[start:end])
                        ids = ([99] if i == 0 else [98] + previous[-8:]) + [9] + body
                        chunks.append({"start": start, "end": end, "context_tokens": end-start,
                                       "replay_input_tokens": len(ids), "prompt_suffix_postfix_tokens": len(ids)-len(body),
                                       "replay_input_token_ids": ids, "executed_exact_replay": arm != "echo" or i == 0})
                        previous = body
                replays = [len(c["replay_input_token_ids"]) for c in chunks if c["executed_exact_replay"]]
                build = {"context_id": context.context_id, "context_fingerprint": context.fingerprint(), "arm": arm, "eviction_ratio": ratio,
                         "common_recent_tokens": 0, "quality_backend": QUALITY_BACKEND, "truncation": context.truncation, "regions": context.regions,
                         "compacted": False, "physical_memory_savings_demonstrated": False, "physical_kv_payload_reduction_bytes": 0,
                         "kv_shapes": [[[1, 1, 12, 2], [1, 1, 12, 2]]] * 2, "kv_tensor_payload_bytes": 192, "kv_unique_storage_bytes": 192,
                         "allocation": allocation, "metadata": {} if arm == "fullkv" else {"budget": budget, "chunks": chunks},
                         "forward_input_lengths": [12] + replays, "exact_replay_passes": len(replays), "exact_replay_input_tokens": sum(replays)}
                write_json(folder / "build.json", build)
                write_json(folder / "arm_timing.json", {"arm_wall_seconds": 0, "speedup_or_amortized_cost_claim": False})
                for q in grouped[context.context_id]:
                    prediction = "return 1" if arm == "fullkv" else "return 2" if arm == "echo" else "return 3"
                    rows.append({"build_id": bid, "context_id": context.context_id, "question_id": q["question_id"], "arm": arm,
                                 "eviction_ratio": ratio, "evidence_kind": "fixture_only", "query_token_ids_sha256": canonical_hash(q["question_token_ids"]),
                                 "text": prediction, "text_with_special_tokens": prediction, "generated_token_ids": [1, 2, 3],
                                 "cache_clone_seconds": 0, "query_generation_seconds": 0, "query_peak_memory": {},
                                 "query_cache": {"compacted": False, "kv_shapes": [[[1, 1, 16, 2], [1, 1, 16, 2]]] * 2,
                                                 "kv_tensor_payload_bytes": 256, "kv_unique_storage_bytes": 256},
                                 "generated_token_count": 3, "stopped_on_eos": False})
    random.Random(17).shuffle(rows)
    jsonl(run / "results.jsonl", rows)
    write_json(run / "manifest.json", {"schema_version": 1, "status": "completed", "runtime_stage": "executed", "backend_commit": BACKEND_COMMIT,
               "config_sha256": canonical_hash(config), "code_sha256": {name: sha256_file(REPO / "echo_pilot" / name) for name in ("runtime.py", "contracts.py", "cli.py")}})
    reseal(run)
    return run


def reseal(run):
    manifest = json.loads((run / "manifest.json").read_text())
    manifest["artifact_sha256"] = {p.relative_to(run).as_posix(): sha256_file(p) for p in sorted(run.rglob("*"))
                                   if p.is_file() and p.name not in ("manifest.json", "COMPLETE.json")}
    write_json(run / "manifest.json", manifest)
    write_json(run / "COMPLETE.json", {"status": "completed", "manifest_sha256": sha256_file(run / "manifest.json")})


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run = fixture_archive(self.root)

    def analyze(self, output="analysis", **kwargs):
        return analyze_run(self.run, self.root / "data_manifest.json", self.root, "lcc", "fixture", "development",
                           data_manifest_sha256=sha256_file(self.root / "data_manifest.json"), output=self.root / output,
                           bootstrap_samples=100, allow_fixture=True, **kwargs)

    def rows(self):
        return [json.loads(line) for line in (self.run / "results.jsonl").read_text().splitlines()]

    def mutate_rows(self, mutate):
        rows = self.rows()
        mutate(rows)
        jsonl(self.run / "results.jsonl", rows)
        reseal(self.run)

    def mutate_build(self, field, value, arm="echo"):
        path = self.run / f"c00000-{arm}-r00/build.json"
        row = json.loads(path.read_text())
        row[field] = value
        write_json(path, row)
        reseal(self.run)

    def test_happy_path_counts_pins_percent_and_official_similarity(self):
        result = self.analyze()
        self.assertEqual(result["evidence"], {"execution": "cpu_fixture", "workload": "fixture_only", "fixture_only": True})
        self.assertEqual(result["denominators"], {"contexts": 2, "questions": 3, "builds": 14, "observed_result_cells": 21, "fullkv_observations": 3})
        echo = next(a for a in result["arms"] if a["arm"] == "echo")
        self.assertEqual(echo["mean_score_percent"], 88)
        self.assertGreater(echo["quality"]["mean"], 0)  # Similar code is NOT raw exact match.
        self.assertEqual(echo["quality"]["context_count"], 2)
        scores = (self.root / "analysis/question_scores.jsonl").read_text().splitlines()
        paired = (self.root / "analysis/paired_questions.jsonl").read_text().splitlines()
        self.assertEqual(len(scores), 21)
        self.assertEqual(len(paired), 18)
        for line in paired:
            row = json.loads(line)
            self.assertEqual(row["fullkv_score"], 1)
            self.assertIn("partition_matched_kvzip_score", row)
        marker = json.loads((self.root / "analysis/ANALYSIS_COMPLETE.json").read_text())
        for name, digest in marker["artifact_sha256"].items():
            self.assertEqual(sha256_file(self.root / "analysis" / name), digest)

    def test_shuffle_invariant_outputs(self):
        first = self.analyze("first")
        self.mutate_rows(lambda rows: rows.reverse())
        second = self.analyze("second")
        self.assertEqual(first, second)
        for name in ("question_scores.jsonl", "paired_questions.jsonl"):
            self.assertEqual((self.root / "first" / name).read_bytes(), (self.root / "second" / name).read_bytes())

    def test_duplicate_cell_fails(self):
        self.mutate_rows(lambda rows: rows.append(rows[0].copy()))
        with self.assertRaisesRegex(ContractError, "Duplicate result"): self.analyze()

    def test_missing_cell_fails(self):
        self.mutate_rows(lambda rows: rows.pop())
        with self.assertRaisesRegex(ContractError, "Missing required result"): self.analyze()
        self.assertFalse((self.root / "analysis").exists())

    def test_extra_arm_or_ratio_fails(self):
        for key, value in (("arm", "oracle"), ("eviction_ratio", .6)):
            old = self.rows()
            self.mutate_rows(lambda rows: rows[0].update({key: value}))
            with self.assertRaisesRegex(ContractError, "Unexpected result cell"): self.analyze()
            jsonl(self.run / "results.jsonl", old); reseal(self.run)

    def test_wrong_context_association_fails(self):
        self.mutate_rows(lambda rows: rows[0].update(context_id="fixture-context-2" if rows[0]["context_id"] == "fixture-context" else "fixture-context"))
        with self.assertRaisesRegex(ContractError, "wrong question/context"): self.analyze()

    def test_wrong_query_fingerprint_fails(self):
        self.mutate_rows(lambda rows: rows[0].update(query_token_ids_sha256="0"*64))
        with self.assertRaisesRegex(ContractError, "query fingerprint"): self.analyze()

    def test_wrong_context_fingerprint_fails(self):
        self.mutate_build("context_fingerprint", "0"*64)
        with self.assertRaisesRegex(ContractError, "context fingerprint"): self.analyze()

    def test_wrong_build_reference_fails(self):
        self.mutate_rows(lambda rows: rows[0].update(build_id="wrong"))
        with self.assertRaisesRegex(ContractError, "build identity"): self.analyze()

    def test_wrong_label_hash_fails(self):
        (self.root / "labels.jsonl").write_text((self.root / "labels.jsonl").read_text().replace("return 1", "return 9"))
        with self.assertRaisesRegex(ContractError, "labels digest"): self.analyze()

    def test_wrong_label_context_fails_even_after_digest_refresh(self):
        labels = [json.loads(s) for s in (self.root / "labels.jsonl").read_text().splitlines()]
        labels[0]["context_id"] = "fixture-context-2"
        jsonl(self.root / "labels.jsonl", labels)
        data = json.loads((self.root / "data_manifest.json").read_text())
        entry = data["presets"]["fixture"]["artifacts"]["lcc.development"]["labels"]
        entry.update(sha256=sha256_file(self.root / "labels.jsonl"), bytes=(self.root / "labels.jsonl").stat().st_size)
        write_json(self.root / "data_manifest.json", data)
        with self.assertRaisesRegex(ContractError, "Wrong label context"): self.analyze()

    def test_tampered_artifact_fails_before_scoring(self):
        with (self.run / "results.jsonl").open("a") as f: f.write("{}\n")
        with self.assertRaisesRegex(ContractError, "Artifact digest"): self.analyze()

    def test_manifest_tampering_fails(self):
        with (self.run / "manifest.json").open("a") as f: f.write(" ")
        with self.assertRaisesRegex(ContractError, "manifest digest"): self.analyze()

    def test_incomplete_and_failed_runs_fail(self):
        (self.run / "COMPLETE.json").unlink()
        with self.assertRaisesRegex(ContractError, "Missing artifact"): self.analyze()
        reseal(self.run)
        write_json(self.run / "FAILED.json", {"status": "failed"})
        with self.assertRaisesRegex(ContractError, "FAILED.json"): self.analyze()

    def test_unlisted_artifact_fails(self):
        (self.run / "surprise.txt").write_text("extra")
        with self.assertRaisesRegex(ContractError, "inventory"): self.analyze()

    def test_inconsistent_mask_budget_fails(self):
        self.mutate_build("allocation", {"actual_pruned_pairs": 12, "actual_retained_pairs": 13})
        with self.assertRaisesRegex(ContractError, "mask budget"): self.analyze()

    def test_fullkv_stale_mask_fails(self):
        path = self.run / "c00000-fullkv-r00/scores_masks.pt"
        write_json(path, {"fixture_only": True, "masked_key_indices": [[[0], [0], [11]], None], "logical_keep_mask": None})
        reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Full KV has a mask"): self.analyze()

    def test_tensor_mask_wrong_retained_count_fails(self):
        path = self.run / "c00000-echo-r00/scores_masks.pt"
        value = json.loads(path.read_text())
        for part in value["masked_key_indices"][0]: part.pop()
        value["logical_keep_mask"][0][0][0][-1] = True
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "retained count"): self.analyze()

    def test_tensor_keep_mismatch_fails(self):
        path = self.run / "c00000-echo-r00/scores_masks.pt"
        value = json.loads(path.read_text()); value["logical_keep_mask"][0][0][0][-1] = True
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "keep mask mismatch"): self.analyze()

    def test_duplicate_mask_coordinates_fails(self):
        path = self.run / "c00000-echo-r00/scores_masks.pt"
        value = json.loads(path.read_text()); value["masked_key_indices"][0][2][-1] = value["masked_key_indices"][0][2][-2]
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Duplicate masked"): self.analyze()

    def test_protected_mask_fails(self):
        path = self.run / "c00000-echo-r00/scores_masks.pt"
        value = json.loads(path.read_text()); value["masked_key_indices"][0][2][-1] = 0
        value["logical_keep_mask"][0][0][0][-1] = True; value["logical_keep_mask"][0][0][0][0] = False
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Protected token"): self.analyze()

    def test_empty_eos_is_included_as_zero_score(self):
        self.mutate_rows(lambda rows: rows[0].update(text="", text_with_special_tokens="<eos>", generated_token_ids=[99], generated_token_count=1, stopped_on_eos=True,
            query_cache={"compacted": False, "kv_shapes": [[[1, 1, 14, 2], [1, 1, 14, 2]]] * 2, "kv_tensor_payload_bytes": 224, "kv_unique_storage_bytes": 224}))
        result = self.analyze()
        scores = [json.loads(s) for s in (self.root / "analysis/question_scores.jsonl").read_text().splitlines()]
        self.assertEqual(sum(row["score"] == 0 for row in scores), 1)
        self.assertEqual(result["denominators"]["observed_result_cells"], 21)

    def test_early_stop_without_eos_fails(self):
        self.mutate_rows(lambda rows: rows[0].update(generated_token_ids=[1], generated_token_count=1, stopped_on_eos=False))
        with self.assertRaisesRegex(ContractError, "without EOS"): self.analyze()

    def test_evidence_cannot_promote_fixtures(self):
        with self.assertRaisesRegex(ContractError, "fixture analysis"):
            analyze_run(self.run, self.root / "data_manifest.json", self.root, "lcc", "fixture", "development",
                        data_manifest_sha256=sha256_file(self.root / "data_manifest.json"), output=self.root / "out")

    def test_wrong_split_rejected(self):
        with self.assertRaisesRegex(ContractError, "task/split"):
            analyze_run(self.run, self.root / "data_manifest.json", self.root, "lcc", "fixture", "heldout",
                        data_manifest_sha256=sha256_file(self.root / "data_manifest.json"), output=self.root / "out", allow_fixture=True)

    def test_output_cannot_mutate_run(self):
        with self.assertRaisesRegex(ContractError, "outside the immutable run"): self.analyze(output="run/analysis")

    def test_duplicate_json_key_rejected(self):
        path = self.run / "c00000-fullkv-r00/arm_timing.json"
        path.write_text('{"arm_wall_seconds":0,"arm_wall_seconds":1,"speedup_or_amortized_cost_claim":false}')
        reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Duplicate JSON key"): self.analyze()

    def test_nan_rejected(self):
        self.mutate_rows(lambda rows: rows[0].update(eviction_ratio=float("nan")))
        with self.assertRaisesRegex(ContractError, "Nonfinite JSON"): self.analyze()

    def test_cli_runs_without_importing_runtime_or_torch(self):
        with patch.dict(sys.modules, {"torch": None}), patch("echo_pilot.runtime.execute", side_effect=AssertionError("inference forbidden")), patch("sys.stdout", new_callable=io.StringIO):
            code = main(["analyze", "--run", str(self.run), "--data-manifest", str(self.root / "data_manifest.json"),
                         "--data-manifest-sha256", sha256_file(self.root / "data_manifest.json"), "--data-root", str(self.root),
                         "--task", "lcc", "--preset", "fixture", "--split", "development", "--output", str(self.root / "cli-output"),
                         "--bootstrap-samples", "100", "--allow-fixture"])
        self.assertEqual(code, 0)

    def test_real_tensor_loader_fails_closed_without_torch(self):
        with patch.dict(sys.modules, {"torch": None}):
            with self.assertRaisesRegex(ContractError, "Never skip mask checks"):
                _torch_masks(self.run / "c00000-fullkv-r00/scores_masks.pt", None, 2, 1, {}, True)

    def test_real_loader_requires_cpu_and_weights_only(self):
        calls = []
        def load(path, **kwargs):
            calls.append(kwargs)
            return {"masked_key_indices": [None, None]}
        with patch.dict(sys.modules, {"torch": SimpleNamespace(load=load)}):
            self.assertIsNone(_torch_masks(Path("fixture-unused.pt"), None, 2, 1, {}, True))
        self.assertEqual(calls, [{"map_location": "cpu", "weights_only": True}])

    def test_tensor_shape_drift_in_query_fails(self):
        self.mutate_rows(lambda rows: rows[0]["query_cache"]["kv_shapes"][0][0].__setitem__(2, 999))
        with self.assertRaisesRegex(ContractError, "cache shape/generation"): self.analyze()

    def test_unknown_result_repeat_field_rejected(self):
        self.mutate_rows(lambda rows: rows[0].update(repeat=1))
        with self.assertRaisesRegex(ContractError, "unknown fields"): self.analyze()

    def test_missing_build_artifact_fails_after_reseal(self):
        (self.run / "c00000-echo-r00/scores_masks.pt").unlink()
        reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Missing artifact"): self.analyze()

    def test_metric_implementation_pin_fails(self):
        path = self.root / "data_manifest.json"
        value = json.loads(path.read_text()); value["metric_implementation_sha256"] = "0"*64
        write_json(path, value)
        with self.assertRaisesRegex(ContractError, "metric source digest"): self.analyze()

    def test_explicit_data_manifest_digest_fails(self):
        with self.assertRaisesRegex(ContractError, "Data manifest digest"):
            analyze_run(self.run, self.root / "data_manifest.json", self.root, "lcc", "fixture", "development",
                        data_manifest_sha256="0"*64, output=self.root / "out", allow_fixture=True)

    def test_frozen_config_tampering_fails_after_reseal(self):
        path = self.run / "frozen_config.json"
        config = json.loads(path.read_text()); config["selection"]["recent_tokens"] = 1
        write_json(path, config); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Frozen config digest"): self.analyze()

    def test_noncanonical_archived_lock_analyzes_when_pinned_bytes_preserved(self):
        path = self.run / "packages.lock.json"
        lock = json.loads(path.read_text())
        path.write_text(json.dumps(lock, separators=(",", ":")))
        config_path = self.run / "frozen_config.json"
        config = json.loads(config_path.read_text())
        config["runtime"]["packages_lock_sha256"] = sha256_file(path)
        write_json(config_path, config)
        config_hash = canonical_hash(config)
        for name in ("input_plan.json", "manifest.json"):
            value = json.loads((self.run / name).read_text()); value["config_sha256"] = config_hash
            write_json(self.run / name, value)
        evidence_path = self.run / "evidence_manifest.json"
        evidence = RunManifest.load(evidence_path).payload
        evidence["config"] = config
        evidence_path.unlink()
        RunManifest(json.dumps(evidence)).save(evidence_path)
        reseal(self.run)
        self.assertEqual(self.analyze()["status"], "validated_quality_only")

    def test_cli_preserves_noncanonical_source_lock_bytes(self):
        # Mocked execution only, used to exercise the actual archive-writing path.
        # The mock's incomplete model artifacts cannot pass the real analyzer.
        config = json.loads((self.run / "frozen_config.json").read_text())
        lock = json.loads((self.run / "packages.lock.json").read_text())
        original = json.dumps(lock, separators=(",", ":")).encode()
        (self.root / "packages.json").write_bytes(original)
        config["runtime"]["packages_lock_sha256"] = sha256_file(self.root / "packages.json")
        config["dataset"]["evidence_kind"] = "natural"
        config["dataset"]["preprocessing_sha256"] = sha256_file(REPO / "data_prep/prepare_longbench.py")
        path = self.root / "mock-execution-config.json"
        write_json(path, config)
        evidence = RunManifest.load(self.run / "evidence_manifest.json")
        with patch("kv_harness.manifest.RunManifest.create", return_value=evidence), patch("echo_pilot.runtime.execute", return_value={}):
            result = run_cli(path, self.root / "mock-executed", True)
        self.assertEqual(result["status"], "completed")
        archived = self.root / "mock-executed/packages.lock.json"
        self.assertEqual(archived.read_bytes(), original)
        self.assertEqual(sha256_file(archived), config["runtime"]["packages_lock_sha256"])

    def test_symlink_artifact_rejected(self):
        (self.run / "unexpected-link").symlink_to(self.root / "data_manifest.json")
        with self.assertRaisesRegex(ContractError, "Symlink"): self.analyze()

    def test_partition_matched_prompt_drift_fails(self):
        path = self.run / "c00000-kvzip_echo_partition-r00/build.json"
        value = json.loads(path.read_text()); value["metadata"]["chunks"][1]["replay_input_token_ids"][0] = 97
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Replay tokens/partition"): self.analyze()

    def test_shared_echo_matched_replay_corruption_fails(self):
        for arm in ("echo", "kvzip_echo_partition"):
            path = self.run / f"c00000-{arm}-r00/build.json"
            value = json.loads(path.read_text())
            value["metadata"]["chunks"][0]["replay_input_token_ids"][-1] = 123456
            write_json(path, value)
        reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Replay tokens/partition"): self.analyze()

    def test_native_kvzip_partition_cannot_silently_match_echo(self):
        path = self.run / "c00000-kvzip-r00/build.json"
        value = json.loads(path.read_text())
        echo = json.loads((self.run / "c00000-kvzip_echo_partition-r00/build.json").read_text())
        value["metadata"]["chunks"] = echo["metadata"]["chunks"]
        write_json(path, value); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Replay tokens/partition"): self.analyze()


class BootstrapTests(unittest.TestCase):
    def test_cluster_count_not_questions_ratios_or_repeats(self):
        rows = [{"context_id": "a", "question_id": "q1", "value": 0},
                {"context_id": "a", "question_id": "q2", "value": 0},
                {"context_id": "b", "question_id": "q3", "value": 1}]
        result = cluster_bootstrap(rows, samples=100, seed=1)
        self.assertEqual(result["context_count"], 2)
        self.assertEqual(result["question_count"], 3)
        self.assertAlmostEqual(result["mean"], 1/3)
        self.assertEqual(result["interval"], [0, 1])
        with self.assertRaisesRegex(ContractError, "Duplicate question/repeat"):
            cluster_bootstrap(rows + rows, samples=100)
        # A second ratio references the same 2 contexts and receives identical draws.
        second = cluster_bootstrap([{**r, "value": r["value"]-1} for r in rows], samples=100, seed=1)
        self.assertEqual(second["context_count"], 2)
        self.assertEqual(result["draws_sha256"], second["draws_sha256"])

    def test_one_context_has_no_identifiable_interval(self):
        result = cluster_bootstrap([{"context_id": "a", "question_id": "q", "value": .5}], samples=10)
        self.assertIsNone(result["interval"])
        self.assertEqual(result["context_count"], 1)


if __name__ == "__main__":
    unittest.main()
