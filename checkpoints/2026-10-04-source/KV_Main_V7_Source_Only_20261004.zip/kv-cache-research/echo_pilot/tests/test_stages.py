"""CPU contracts and cost scenarios, never model/provider evidence."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from echo_pilot import BACKEND_COMMIT
from echo_pilot.contracts import ContractError, sha256_file, validate_config, validate_inputs
from echo_pilot.stages import (ROOT, DEFAULT_PLAN, estimate_admission, find_invocation,
                              load_json, make_plan, make_stage_config, publish,
                              replay_lengths, verify_plan)


class StageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan = verify_plan(ROOT / DEFAULT_PLAN)
        cls.example = load_json(ROOT / "configs/stages/admission.example.json")

    def scenario(self):
        return copy.deepcopy(self.example)

    def estimate(self, scenario=None):
        return estimate_admission(self.plan, self.scenario() if scenario is None else scenario)

    def event(self, resource=None, amount="0", seconds=0, gate="first_gate", status="settled", event_id="bill-1"):
        return {"resource_id": resource or self.example["resource_id"], "event_id": event_id,
                "gate_id": gate, "status": status, "all_in_cny": amount, "billable_seconds": seconds}

    def test_frozen_replay_work_matches_independent_readiness_audit(self):
        smoke, dev = self.plan["stages"]
        fields = ("contexts", "questions", "cache_builds", "exact_replay_passes", "prefill_input_tokens", "exact_replay_input_tokens", "max_generated_tokens")
        self.assertEqual(tuple(smoke["counts"][k] for k in fields), (3, 3, 12, 23, 65292, 39274, 768))
        self.assertEqual(tuple(dev["counts"][k] for k in fields), (13, 13, 52, 131, 425660, 242460, 3328))
        self.assertEqual(self.plan["counts"]["cache_builds"], 64)
        self.assertEqual(self.plan["counts"]["contexts"], 16)
        self.assertEqual(self.plan["distinct_contexts"], 13)
        self.assertEqual(self.plan["distinct_questions"], 13)
        self.assertEqual(self.plan["counts"]["model_loads"], 4)

    def test_repo_smoke_preserves_long_query(self):
        repo = find_invocation(self.plan, "smoke", "repobench-p")
        self.assertEqual(repo["ordered_contexts"][0]["questions"][0]["question_tokens"], 448)
        self.assertEqual(repo["eviction_ratios"], [0.5])

    def test_all_stages_are_development_and_no_extra_builds(self):
        for stage in self.plan["stages"]:
            for invocation in stage["invocations"]:
                self.assertEqual(invocation["split"], "development")
                builds = invocation["ordered_builds"]
                self.assertEqual(len(builds), invocation["counts"]["contexts"] * 4)
                self.assertEqual(len({b["build_id"] for b in builds}), len(builds))
                for build in builds:
                    if build["arm"] == "fullkv":
                        self.assertEqual(build["eviction_ratio"], 0)
                        self.assertEqual(build["exact_replay_input_lengths"], [])
                    elif build["arm"] == "echo":
                        self.assertEqual(build["exact_replay_input_lengths"], [2048])
        self.assertEqual(self.plan["common_policy"]["warmup_builds"], 0)
        self.assertEqual(self.plan["common_policy"]["additional_repeat_builds"], 0)

    def test_frozen_stage_is_byte_deterministic_and_exclusive(self):
        self.assertEqual(make_plan(), self.plan)
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "plan.json"
            publish(target, make_plan())
            self.assertEqual(target.read_bytes(), (ROOT / DEFAULT_PLAN).read_bytes())
            with self.assertRaises(FileExistsError):
                publish(target, self.plan)

    def test_no_labels_or_heldout_files_read(self):
        original_open = Path.open
        def guarded_open(path, *args, **kwargs):
            self.assertNotIn("labels.jsonl", str(path))
            self.assertNotIn("heldout.", str(path))
            return original_open(path, *args, **kwargs)
        with patch.object(Path, "open", guarded_open):
            make_plan()

    def test_tampered_recipe_rejected_even_with_unmodified_data(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "plan.json"
            bad = copy.deepcopy(self.plan)
            bad["stages"][1]["invocations"][0]["eviction_ratios"] = [0.9]
            publish(path, bad)
            with self.assertRaisesRegex(ContractError, "differs"):
                verify_plan(path)
            with self.assertRaisesRegex(ContractError, "digest"):
                estimate_admission(bad, self.scenario())

    def test_replay_partition_boundaries_and_short_previous_postfix(self):
        self.assertEqual(replay_lengths(2035, 3, 9, True), [2048])
        self.assertEqual(replay_lengths(2036, 3, 9, True), [2048, 30])
        self.assertEqual(replay_lengths(2051, 3, 9, False), [2064])
        self.assertEqual(replay_lengths(23, 3, 9, True, chunk_size=20), [20, 41])
        with self.assertRaises(ContractError):
            replay_lengths(3, 3, 9, True)
        with self.assertRaises(ContractError):
            replay_lengths(20, 3, 9, True, chunk_size=16)

    def test_no_heldout_or_arbitrary_subset(self):
        for stage, task in (("heldout", "lcc"), ("pilot16k", "lcc"), ("smoke", "other")):
            with self.subTest(stage=stage, task=task), self.assertRaises(ContractError):
                find_invocation(self.plan, stage, task)

    def test_scenario_admission_is_not_execution_authority(self):
        result = self.estimate()
        self.assertEqual(result["status"], "planning_admitted")
        self.assertEqual(result["scenario_workload_seconds"], "4429.192")
        self.assertEqual(result["scenario_billable_seconds_including_reserve"], "4740")
        self.assertEqual(result["scenario_incremental_all_in_cny"], "8.4125")
        self.assertFalse(result["execution_authorized"])
        self.assertFalse(result["provider_stop_control_verified"])
        self.assertFalse(result["paid_resource_action_performed"])
        self.assertEqual(result["evidence"], "scenario_not_measurement")

    def test_input_is_not_mutated(self):
        scenario = self.scenario()
        before = copy.deepcopy(scenario)
        self.estimate(scenario)
        self.assertEqual(scenario, before)

    def test_multiple_ratios_or_repeats_not_silently_admitted(self):
        scenario = self.scenario()
        scenario["invocations"].append(scenario["invocations"][0])
        with self.assertRaisesRegex(ContractError, "Duplicate invocation"):
            self.estimate(scenario)

    def test_remaining_task_has_one_model_load(self):
        scenario = self.scenario()
        scenario["invocations"] = [{"stage_id": "development75", "task": "repobench-p"}]
        result = self.estimate(scenario)
        self.assertEqual(result["counts"]["cache_builds"], 24)
        self.assertEqual(result["counts"]["model_loads"], 1)

    def test_existing_or_off_limits_resource_rejected(self):
        for key, value in (("resource_origin", "existing_instance"),
                           ("off_limits_resource_ids", [self.example["resource_id"]]),
                           ("resource_id", ""), ("resource_id", "different-unlisted-resource")):
            scenario = self.scenario(); scenario[key] = value
            with self.subTest(key=key), self.assertRaises(ContractError):
                self.estimate(scenario)

    def test_unattributed_and_duplicate_billing_rejected(self):
        for events in ([self.event(resource="other-user-job")], [self.event(), self.event()]):
            scenario = self.scenario(); scenario["billing_events"] = events
            with self.assertRaises(ContractError):
                self.estimate(scenario)

    def test_account_balance_delta_or_unknown_fields_rejected(self):
        scenario = self.scenario(); scenario["accounting_basis"] = "account_balance_delta"
        with self.assertRaisesRegex(ContractError, "balance"):
            self.estimate(scenario)
        scenario = self.scenario(); scenario["account_balance_delta"] = "10"
        with self.assertRaisesRegex(ContractError, "unknown"):
            self.estimate(scenario)

    def test_invalid_budget_and_numeric_inputs(self):
        for value in ("20.01", "NaN", "Infinity", "-1", "0", 20, True):
            scenario = self.scenario(); scenario["proposed_resource_all_in_budget_cny"] = value
            with self.subTest(value=value), self.assertRaises(ContractError):
                self.estimate(scenario)
        for value in ("0", "-1", "NaN", 10):
            scenario = self.scenario(); scenario["runtime_scenario"]["replay_tokens_per_second"] = value
            with self.subTest(value=value), self.assertRaises(ContractError):
                self.estimate(scenario)

    def test_shutdown_reserve_and_billing_quantum(self):
        scenario = self.scenario(); scenario["runtime_scenario"]["shutdown_reserve_seconds"] = "299"
        with self.assertRaises(ContractError):
            self.estimate(scenario)
        scenario = self.scenario(); scenario["quote_scenario"]["billing_quantum_seconds"] = 3600
        self.assertEqual(self.estimate(scenario)["scenario_billable_seconds_including_reserve"], "7200")

    def test_time_budget_rejects_without_extending_first_gate(self):
        scenario = self.scenario(); scenario["runtime_scenario"]["overhead_seconds_per_build"] = "220"
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertTrue(any("3h55m" in x for x in result["rejection_reasons"]))

    def test_rate_budget_rejects_at_nineteen_not_twenty(self):
        scenario = self.scenario(); scenario["quote_scenario"]["compute_cny_per_hour"] = "13.1"
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertTrue(any("CNY20" in x for x in result["rejection_reasons"]))
        self.assertLess(float(result["scenario_incremental_all_in_cny"]), 20)

    def test_cumulative_project_cap_across_resources(self):
        scenario = self.scenario(); scenario["project_resource_ids"].append("prior-new-project-resource")
        scenario["billing_events"] = [self.event(resource="prior-new-project-resource", gate="previous_gate", amount="92")]
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertIn("would exceed cumulative CNY100 project ceiling", result["rejection_reasons"])

    def test_prior_spend_and_unsettled_reserve_count_inside_shared_gate(self):
        scenario = self.scenario()
        scenario["billing_events"] = [self.event(amount="7"), self.event(amount="5", status="unsettled_reserve", event_id="unsettled-2")]
        result = self.estimate(scenario)
        self.assertEqual(result["existing_first_gate_accounted_cny"], "12")
        self.assertEqual(result["status"], "planning_rejected")

    def test_resource_proposal_counts_target_costs_from_all_gates(self):
        scenario = self.scenario()
        scenario["billing_events"] = [self.event(amount="12", gate="previous_gate")]
        result = self.estimate(scenario)
        self.assertEqual(result["existing_first_gate_accounted_cny"], "0")
        self.assertTrue(any("resource-ID-specific" in reason for reason in result["rejection_reasons"]))

    def test_scenario_boolean_schema_rejected(self):
        scenario = self.scenario(); scenario["schema_version"] = True
        with self.assertRaises(ContractError):
            self.estimate(scenario)

    def test_no_gpu_or_runtime_import_for_planning(self):
        code = "import sys; from echo_pilot.stages import make_plan; make_plan(); assert all(k not in sys.modules for k in ['echo_pilot.runtime', 'torch', 'transformers', 'kvpress'])"
        result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_small_resource_specific_proposal_is_enforced(self):
        scenario = self.scenario(); scenario["proposed_resource_all_in_budget_cny"] = "8"
        self.assertEqual(self.estimate(scenario)["status"], "planning_rejected")

    def test_forty_five_minute_gate_and_prior_success_evidence(self):
        scenario = self.scenario(); scenario["billing_events"] = [self.event(seconds=2800, amount="4")]
        result = self.estimate(scenario)
        self.assertTrue(any("45 minutes" in x for x in result["rejection_reasons"]))
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "verified-inference-log", "first_success_billable_seconds": 900, "first_success_gate_billable_seconds": 900}
        self.assertEqual(self.estimate(scenario)["status"], "planning_admitted")
        scenario["useful_inference_record"]["resource_id"] = "other-resource"
        with self.assertRaises(ContractError):
            self.estimate(scenario)

    def test_first_inference_gate_includes_prefill_query_generation_and_overhead(self):
        scenario = self.scenario()
        scenario["invocations"] = [{"stage_id": "smoke", "task": "repobench-p"}]
        scenario["billing_events"] = [self.event(seconds=2600, amount="1")]
        scenario["runtime_scenario"].update(setup_seconds="0", model_load_seconds_per_invocation="0",
                                              prefill_tokens_per_second="30")
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertTrue(any("45 minutes" in x for x in result["rejection_reasons"]))
        self.assertGreater(float(result["scenario_first_answer_gate_billable_seconds"]), 2792)
        components = result["scenario_first_answer_components_seconds"]
        self.assertGreater(float(components["prefill"]), 192)
        self.assertEqual(components["query"], "1.12")
        self.assertEqual(components["generation_cap"], "2.56")
        self.assertEqual(components["build_overhead"], "15")
        self.assertEqual(result["scenario_first_answer_identity"]["task"], "repobench-p")
        self.assertFalse(result["execution_authorized"])

    def test_first_inference_gate_queries_alone_can_exceed_allowance(self):
        scenario = self.scenario()
        scenario["invocations"] = [{"stage_id": "smoke", "task": "repobench-p"}]
        scenario["billing_events"] = [self.event(seconds=2600, amount="1")]
        scenario["runtime_scenario"].update(setup_seconds="0", model_load_seconds_per_invocation="0",
                                              query_tokens_per_second="4")
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertTrue(any("45 minutes" in x for x in result["rejection_reasons"]))

    def test_first_inference_gate_generation_cap_alone_can_exceed_allowance(self):
        scenario = self.scenario()
        scenario["invocations"] = [{"stage_id": "smoke", "task": "lcc"}]
        scenario["billing_events"] = [self.event(seconds=2600, amount="1")]
        scenario["runtime_scenario"].update(setup_seconds="0", model_load_seconds_per_invocation="0",
                                              generated_tokens_per_second="0.5")
        result = self.estimate(scenario)
        self.assertEqual(result["status"], "planning_rejected")
        self.assertTrue(any("45 minutes" in x for x in result["rejection_reasons"]))

    def test_other_resources_time_cannot_support_target_inference_record(self):
        scenario = self.scenario()
        scenario["project_resource_ids"].append("prior-project-resource")
        scenario["billing_events"] = [self.event(resource="prior-project-resource", seconds=1000, amount="1")]
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "claimed-success", "first_success_billable_seconds": 900, "first_success_gate_billable_seconds": 900}
        with self.assertRaisesRegex(ContractError, "target resource"):
            self.estimate(scenario)
        scenario["billing_events"].append(self.event(seconds=899, amount="1", event_id="target-too-short"))
        with self.assertRaisesRegex(ContractError, "target resource"):
            self.estimate(scenario)
        scenario["billing_events"].append(self.event(seconds=1, amount="0", event_id="target-final-second"))
        result = self.estimate(scenario)
        self.assertEqual(result["existing_target_first_gate_billable_seconds"], 900)
        self.assertEqual(result["existing_first_gate_billable_seconds"], 1900)
        self.assertFalse(result["useful_inference_evidence_externally_verified"])

    def test_other_gate_time_cannot_support_target_inference_record(self):
        scenario = self.scenario()
        scenario["billing_events"] = [self.event(seconds=1000, amount="1", gate="other-gate")]
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "claimed-success", "first_success_billable_seconds": 900, "first_success_gate_billable_seconds": 900}
        with self.assertRaisesRegex(ContractError, "target resource"):
            self.estimate(scenario)

    def test_zero_elapsed_inference_record_is_not_accepted(self):
        scenario = self.scenario()
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "claimed-success", "first_success_billable_seconds": 0, "first_success_gate_billable_seconds": 0}
        with self.assertRaises(ContractError):
            self.estimate(scenario)

    def test_replacement_resource_does_not_reset_shared_success_deadline(self):
        scenario = self.scenario()
        scenario["project_resource_ids"].append("prior-project-resource")
        scenario["billing_events"] = [self.event(resource="prior-project-resource", seconds=2600, amount="1"),
                                      self.event(seconds=900, amount="1", event_id="target-time")]
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "replacement-success",
                                                "first_success_billable_seconds": 900, "first_success_gate_billable_seconds": 3500}
        with self.assertRaisesRegex(ContractError, "shared first-gate timestamp"):
            self.estimate(scenario)
        # Explicit evidence that target success preceded subsequent other-resource
        # spending is different from resetting the gate after a failed resource.
        scenario["useful_inference_record"]["first_success_gate_billable_seconds"] = 900
        self.assertEqual(self.estimate(scenario)["status"], "planning_admitted")

    def test_success_evidence_requires_shared_timestamp(self):
        scenario = self.scenario()
        scenario["billing_events"] = [self.event(seconds=1000, amount="1")]
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "ambiguous-success", "first_success_billable_seconds": 900}
        with self.assertRaisesRegex(ContractError, "missing fields"):
            self.estimate(scenario)

    def test_success_evidence_shared_local_timestamps_must_be_consistent(self):
        scenario = self.scenario()
        scenario["billing_events"] = [self.event(seconds=1000, amount="1")]
        scenario["useful_inference_record"] = {"resource_id": scenario["resource_id"], "evidence_id": "claimed-success", "first_success_billable_seconds": 900, "first_success_gate_billable_seconds": 900}
        for shared in (899, 950, 1001, 2700):
            scenario["useful_inference_record"]["first_success_gate_billable_seconds"] = shared
            with self.subTest(shared=shared), self.assertRaises(ContractError):
                self.estimate(scenario)
        scenario["project_resource_ids"].append("prior-project-resource")
        scenario["billing_events"].append(self.event(resource="prior-project-resource", seconds=500, amount="1", event_id="prior-time"))
        scenario["useful_inference_record"]["first_success_gate_billable_seconds"] = 1400
        self.assertEqual(self.estimate(scenario)["status"], "planning_admitted")
        scenario["useful_inference_record"]["first_success_gate_billable_seconds"] = 1401
        with self.assertRaisesRegex(ContractError, "difference"):
            self.estimate(scenario)

    def test_make_config_single_ratio_and_preserved_original_inputs(self):
        manifest_before = sha256_file(ROOT / "configs/data/longbench_pilot.manifest.json")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            # Synthetic inventory exercises construction only and is never executed
            # or advertised as a real installed GPU lock.
            lock = root / "synthetic-structural-lock.json"
            lock.write_text(json.dumps({"python_version": "3.12.14", "backend_commit": BACKEND_COMMIT,
                "packages": {"torch": "2.9.1", "transformers": "4.57.3", "kvpress": "0.5.5", "numpy": "2.3.5", "peft": "0.18.0"}}))
            for stage in ("smoke", "development75"):
                for task in ("lcc", "repobench-p"):
                    output = root / (stage + task + ".json")
                    result = make_stage_config(ROOT / DEFAULT_PLAN, stage, task, lock, "a" * 40, output)
                    config = load_json(output)
                    validate_config(config)
                    validate_inputs(config, root)
                    self.assertEqual(config["selection"]["eviction_ratios"], [0.5] if stage == "smoke" else [0.75])
                    self.assertEqual(result["counts"]["cache_builds"], 4 * result["counts"]["contexts"])
                    self.assertFalse(result["runtime_inventory_verified"])
                    self.assertFalse(result["execution_authorized"])
                    with self.assertRaisesRegex(ContractError, "overwrite"):
                        make_stage_config(ROOT / DEFAULT_PLAN, stage, task, lock, "a" * 40, output)
            lock_data = load_json(lock); lock_data["packages"]["torch"] = "fixture-do-not-execute"
            lock.write_text(json.dumps(lock_data))
            with self.assertRaisesRegex(ContractError, "fixture"):
                make_stage_config(ROOT / DEFAULT_PLAN, "smoke", "lcc", lock, "a" * 40, root / "blocked.json")
        self.assertEqual(sha256_file(ROOT / "configs/data/longbench_pilot.manifest.json"), manifest_before)

    def test_unknown_json_keys_and_nonfinite_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "bad.json"
            for text in ('{"x": 1, "x": 2}', '{"x": NaN}'):
                path.write_text(text)
                with self.assertRaises(ContractError):
                    load_json(path)

    def test_cli_read_only_and_rejection_exit(self):
        result = subprocess.run([sys.executable, "-m", "echo_pilot.stages", "verify"], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "verified_not_executed")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "too-costly.json"
            scenario = self.scenario(); scenario["quote_scenario"]["compute_cny_per_hour"] = "100"
            publish(path, scenario)
            result = subprocess.run([sys.executable, "-m", "echo_pilot.stages", "estimate", "--scenario", str(path)], cwd=ROOT, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(json.loads(result.stdout)["status"], "planning_rejected")


if __name__ == "__main__":
    unittest.main()
