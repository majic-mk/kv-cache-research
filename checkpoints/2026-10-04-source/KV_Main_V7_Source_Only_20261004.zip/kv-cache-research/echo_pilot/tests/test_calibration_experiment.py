"""Calibration screen CPU/mocked contract tests, never GPU/model evidence."""
from __future__ import annotations

import copy
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from echo_pilot import calibration_experiment as ex
from echo_pilot import calibration_experiment_analysis as ana
from echo_pilot import BACKEND_COMMIT
from echo_pilot.configure import make_config
from echo_pilot.contracts import ContractError, canonical_hash, load_config, sha256_file, validate_inputs
from echo_pilot.calibration_runtime import (CandidateBuild, DiagnosticBuild, CalibrationBuildError, _ledger,
                                           build_candidate, build_full_exact_diagnostic, prepare_common_replay)
from echo_pilot.tests.test_calibration_runtime import DEPS, Model, Tokenizer
from echo_pilot.contracts import PreparedContext
from research.calibration_methods.contracts import VirtualScores, AnchorObservations
from research.calibration_methods.methods import calibrate, plan_anchors
from research.calibration_methods.selection import select_logical
from research.calibration_methods.diagnostics import FullExactDiagnostic
from kv_harness.manifest import RunManifest

ROOT = ex.ROOT
MEMORY = {k: 0 for k in ("allocated_bytes", "reserved_bytes", "peak_allocated_bytes", "peak_reserved_bytes", "device_free_bytes", "device_total_bytes")}
# Synthetic archive timing fields have no scientific interpretation. Runtime
# tests below separately check that the executable never manufactures timings.
STATS = {"synchronized_wall_seconds": 0.0, "host_wall_seconds": 0.0, "memory": MEMORY}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def rows(path, values):
    path.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in values))


def record(plan):
    return {"schema": ex.SCHEMA, "plan_sha256": plan["plan_sha256"], "baseline_manifest_sha256": "b" * 64,
            "resource_id": "FIXTURE-NEVER-ALLOCATED", "resource_origin": "new_project_resource_only",
            "accounting_basis": "resource_id_specific", "external_stop_verified": True,
            "project_spent_cny": "0", "remaining_project_cny": "100", "screen_all_in_cap_cny": "20",
            "max_wall_seconds": 2700, "no_automatic_retry": True}


def config_files(root, task="lcc"):
    lock = {"python_version": "3.12.14", "backend_commit": BACKEND_COMMIT,
            "packages": {x: "fixture" for x in ("torch", "transformers", "kvpress", "numpy", "peft")}}
    write(root / "lock.json", lock)
    make_config(ROOT, ROOT / ex.MANIFEST, root / "lock.json", "a" * 40,
                task, "development", "smoke8k", root / "config.json")
    config = load_config(root / "config.json")
    contexts, questions, _ = validate_inputs(config, root)
    return config, contexts, questions, lock


def cache_description(n):
    return {"compacted": False, "kv_shapes": [[[1, 1, n, 2], [1, 1, n, 2]]],
            "kv_tensor_payload_bytes": 8 * n, "kv_unique_storage_bytes": 8 * n}


def synthetic_archive(root, task="lcc", *, duplicate_virtual_knots=False):
    """CPU fixture bytes on frozen natural inputs; no actual model is run.

    This is intentionally impossible to analyze as real_model. All timings,
    memory and resource identifiers are fixture placeholders, never measurements.
    """
    run = root / "run"; run.mkdir()
    plan = ex.make_plan(task)
    config, contexts, questions, lock = config_files(root, task)
    replays = ex.check_config(config, contexts, questions, plan)
    baseline = {"run_id": "fixture", "manifest_sha256": "b" * 64, "analysis_complete_sha256": "c" * 64}
    execution = record(plan)
    for name, value in (("plan.json", plan), ("baseline_config.json", config), ("baseline_evidence.json", baseline),
                        ("execution_record.json", execution), ("packages.lock.json", lock), ("environment.json", lock),
                        ("model_load.json", STATS)):
        write(run / name, value)
    # Preserve package-lock bytes exactly; pretty-print happens to match above.
    (run / "packages.lock.json").write_bytes((root / "lock.json").read_bytes())
    write(run / "resolved_model_config.json", {"num_hidden_layers": 1, "num_key_value_heads": 1, "head_dim": 2,
          "_name_or_path": config["model"]["id"], "_commit_hash": config["model"]["revision"]})
    evidence = RunManifest.create(repo=ROOT, evidence_kind="cpu_fixture", seed=ex.SEED,
        config={"schema": ex.SCHEMA, "plan": plan, "baseline_config": config, "execution_record": execution},
        artifacts={"model": {"identifier": config["model"]["id"], "revision_kind": "git_commit", "revision": config["model"]["revision"]},
                   "dataset": {"identifier": config["dataset"]["source_id"], "revision_kind": "git_commit", "revision": config["dataset"]["source_revision"]},
                   "screen_plan": {"identifier": ex.SCHEMA, "revision_kind": "sha256", "revision": plan["plan_sha256"]}})
    evidence.save(run / "evidence_manifest.json")
    event_rows, result_rows = [], []
    def event(operation):
        event_rows.extend([{"event": "started", "operation": operation, "utc": "fixture"},
                           {"event": "completed", "operation": operation, "utc": "fixture", **STATS}])
    event("model_load")
    for ci, (context, replay) in enumerate(zip(contexts, replays, strict=True)):
        folder = run / f"c{ci:05d}"; folder.mkdir()
        n = len(context.token_ids)
        virtual = VirtualScores(replay.partition, np.linspace(.01, .99, n, dtype=np.float32).reshape(1, 1, n))
        exact = FullExactDiagnostic(replay.partition, virtual.values * np.float32(.7))
        if duplicate_virtual_knots:
            # Unequal exact targets at equal source knots cannot be transported
            # by a score-only function. Keep this known-confounded archive
            # valid, visibly flagged, and in the complete quality denominator.
            duplicate = virtual.values.copy()
            duplicate[..., 3000:3002] = duplicate[..., 3000:3001]
            virtual = VirtualScores(replay.partition, duplicate)
        scores, masks, selections, calibration, accounting, capture = {}, {}, {}, {}, {}, {}
        first = None
        def ledger(ids, diagnostic):
            events = [{"input_tokens": len(x), "input_ids_sha256": canonical_hash(x), "phase": "prefill" if i == 0 else "exact_replay"}
                      for i, x in enumerate([replay.context_token_ids] + [replay.replay_token_ids[i] for i in ids])]
            value = _ledger(replay, ids, events, diagnostic=diagnostic, completed=ids)
            value.update(status="completed", scoring_host_wall_seconds=0., total_builder_host_wall_seconds=0.,
                         chunks=[replay.chunk_metadata(i) for i in range(len(replay.partition.chunks))])
            return value
        for anchors in ex.anchor_plans(replay):
            arm = anchors.policy
            obs = AnchorObservations(anchors, exact.values[..., anchors.token_indices])
            calibrated = calibrate(virtual, obs)
            scores[arm] = calibrated.scores
            masks[arm], selections[arm] = select_logical(calibrated.scores, replay.partition, ex.RATIO, seed=ex.SEED)
            calibration[arm] = calibrated.diagnostics
            accounting[arm] = {"runtime": {**ledger(anchors.chunk_ids, False), "anchor_plan_sha256": anchors.fingerprint},
                               "measured": STATS, "cache": cache_description(n)}
            capture["anchors__" + arm], capture["virtual__" + arm] = obs.values, virtual.values
            if arm == "first":
                first = SimpleNamespace(virtual=virtual, anchors=obs, calibration=calibrated, keep_mask=masks[arm])
            event(f"c{ci:05d}:{arm}:build")
        accounting["full_exact_diagnostic"] = {"runtime": ledger(tuple(range(len(replay.partition.chunks))), True), "measured": STATS}
        diagnostic = DiagnosticBuild(virtual, exact, accounting["full_exact_diagnostic"]["runtime"])
        ds, dm, selections2, report = ex.diagnostic_masks(first, diagnostic, replay)
        scores.update(ds); masks.update(dm); selections.update(selections2)
        event(f"c{ci:05d}:full_exact:build"); event(f"c{ci:05d}:diagnostic_mask_transforms")
        for arm in ex.ARMS:
            for q in questions[context.context_id]:
                result_rows.append({"schema": ex.SCHEMA, "context_id": context.context_id, "question_id": q["question_id"],
                    "arm": arm, "eviction_ratio": 0. if arm == "fullkv" else ex.RATIO, "diagnostic_only": arm in ex.ORACLES,
                    "query_token_ids_sha256": canonical_hash(q["question_token_ids"]), "mask_sha256": canonical_hash(masks[arm].tolist()),
                    "generated_token_ids": [1], "generated_token_count": 1, "stopped_on_eos": True,
                    "text": "fixture prediction", "text_with_special_tokens": "fixture prediction",
                    "clone_install": STATS, "generation": STATS, "query_cache": cache_description(n + len(q["question_token_ids"]))})
                prefix = f"c{ci:05d}:{arm}:{q['question_id']}"
                event(prefix + ":clone_install"); event(prefix + ":generate")
        capture.update({"score__" + k: v for k, v in scores.items()})
        capture.update({"keep__" + k: v for k, v in masks.items()})
        capture.update(full_exact=exact.values, diagnostic_virtual=virtual.values)
        np.savez(folder / "scores_masks.npz", **capture)
        write(folder / "build.json", {"schema": ex.SCHEMA, "context_id": context.context_id, "replay_sha256": replay.fingerprint,
            "accounting": accounting, "selection": selections, "calibration": calibration, "diagnostics": report,
            "capture_cpu_bytes": sum(v.nbytes for v in capture.values()), "capture_serialization_host_seconds": 0.,
            "transform_measured": STATS, "physical_memory_savings_demonstrated": False, "cache_compacted": False})
        write(folder / "context_timing.json", {"synchronized_wall_seconds": 0., "speedup_claim": False})
    event_rows.clear()
    for operation in ex.operation_sequence(plan): event(operation)
    rows(run / "events.jsonl", event_rows); rows(run / "results.jsonl", result_rows)
    (run / "runtime.log").write_text("CPU FIXTURE ONLY. No GPU/model/timing evidence.\n")
    write(run / "run_timing.json", {"host_wall_seconds": 0., "charged_work": plan["counts"], "no_speedup_claim": True, "provider_cost_cny": None})
    write(run / "manifest.json", {"schema": ex.SCHEMA, "status": "completed", "evidence_kind": "cpu_fixture", "backend_commit": BACKEND_COMMIT,
                                  "plan_sha256": plan["plan_sha256"], "source_sha256": ex.source_hashes(), "artifact_sha256": {}})
    reseal(run)
    return run


def reseal(run):
    manifest = json.loads((run / "manifest.json").read_text())
    manifest["artifact_sha256"] = {p.relative_to(run).as_posix(): sha256_file(p) for p in sorted(run.rglob("*"))
                                   if p.is_file() and p.name not in ("manifest.json", "COMPLETE.json")}
    write(run / "manifest.json", manifest)
    write(run / "COMPLETE.json", {"schema": ex.SCHEMA, "status": "completed", "manifest_sha256": sha256_file(run / "manifest.json")})


class PlanTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_tiny_frozen_counts_prompt_cost_and_no_labels(self):
        counts = {}
        for task in ("lcc", "repobench-p"):
            plan = ex.make_plan(task); counts[task] = plan["counts"]["contexts"]
            self.assertEqual(plan["policy"]["eviction_ratio"], .5)
            self.assertEqual(plan["policy"]["seed"], 20261003)
            self.assertNotIn("labels", plan["artifacts"])
            for row in plan["ordered_contexts"]:
                self.assertEqual(row["replay"]["partition"]["chunks"][0]["prompt_tokens"], 16)
                self.assertEqual(row["replay"]["partition"]["chunks"][0]["end"] - row["replay"]["partition"]["chunks"][0]["start"], 496)
                self.assertEqual(len({canonical_hash(p["cost_proxy"]) for p in row["anchors"]}), 1)
                self.assertTrue(all(p["cost_proxy"]["reconstruction_input_tokens"] == 2048 for p in row["anchors"]))
            self.assertEqual(plan["counts"]["query_cache_clones"], 9 * plan["counts"]["questions"])
        self.assertEqual(counts, {"lcc": 2, "repobench-p": 1})

    def test_dryrun_never_imports_model_libraries(self):
        script = '''import sys
from echo_pilot.calibration_experiment import make_plan, run, _write
from pathlib import Path
p=Path(sys.argv[1]); _write(p,make_plan("lcc")); print(run(p))
assert not ({"torch", "transformers", "kvpress"} & set(sys.modules))
'''
        done = subprocess.run([sys.executable, "-c", script, str(self.root / "plan.json")], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("validated_not_executed", done.stdout)

    def test_v2_adds_only_diagnostic_protocol_arm_and_query_work_to_v1(self):
        for task in ("lcc", "repobench-p"):
            plan = ex.make_plan(task)
            self.assertEqual(plan["schema"], "echo_calibration_experiment_v2")
            self.assertEqual(len(plan["arms"]), 9)
            self.assertIn("pooled_full_map_oracle", ex.ORACLES)
            historical = json.loads((ROOT / "research/diagnostics/calibration_experiment" / (task + ".dry_run.json")).read_text())
            self.assertEqual(historical["schema"], ex.LEGACY_SCHEMA)
            self.assertEqual(historical["plan_sha256"], ex.LEGACY_PLAN_SHA256[task])
            legacy = copy.deepcopy(plan)
            for key in ("plan_sha256", "diagnostic_protocol", "supersedes"):
                del legacy[key]
            legacy["schema"] = ex.LEGACY_SCHEMA
            legacy["arms"].remove("pooled_full_map_oracle")
            for key in ("query_cache_clones", "query_input_tokens", "max_generated_tokens"):
                self.assertEqual(plan["counts"][key] * 8, historical["counts"][key] * 9)
                legacy["counts"][key] = historical["counts"][key]
            self.assertEqual(legacy["counts"], historical["counts"])
            self.assertEqual(canonical_hash(legacy), ex.LEGACY_PLAN_SHA256[task])
            sequence = ex.operation_sequence(plan)
            self.assertEqual(sum(op.endswith(":build") for op in sequence), 4 * plan["counts"]["contexts"])
            self.assertEqual(sum(":pooled_full_map_oracle:" in op for op in sequence), 2 * plan["counts"]["questions"])

    def test_historical_v1_is_rejected_without_relabeling(self):
        plan = ex.make_plan("lcc"); plan["schema"] = ex.LEGACY_SCHEMA
        write(self.root / "plan.json", plan)
        original = (self.root / "plan.json").read_bytes()
        with self.assertRaisesRegex(ContractError, "historical v1"):
            ex.verify_plan(self.root / "plan.json")
        self.assertEqual((self.root / "plan.json").read_bytes(), original)

    def test_diagnostic_protocol_is_frozen_and_does_not_alias_constants(self):
        plan = ex.make_plan("lcc")
        plan["diagnostic_protocol"]["tie_sensitivities"]["selection_policies"] = ["stable"]
        write(self.root / "plan.json", plan)
        with self.assertRaises(ContractError): ex.verify_plan(self.root / "plan.json")
        self.assertEqual(ex.make_plan("lcc")["diagnostic_protocol"], ex.DIAGNOSTIC_PROTOCOL)

    def test_modified_plan_and_repeat_output_rejected(self):
        p = ex.make_plan("lcc"); write(self.root / "plan.json", p)
        ex.run(self.root / "plan.json", self.root / "out")
        with self.assertRaises(FileExistsError): ex.run(self.root / "plan.json", self.root / "out")
        p["policy"]["eviction_ratio"] = .75; write(self.root / "plan.json", p)
        with self.assertRaises(ContractError): ex.verify_plan(self.root / "plan.json")

    def test_execution_missing_prerequisites_marks_failed_without_load(self):
        write(self.root / "plan.json", ex.make_plan("lcc"))
        with patch("echo_pilot.runtime.load_dependencies") as load:
            with self.assertRaises(ContractError): ex.run(self.root / "plan.json", self.root / "out", execute_flag=True)
        load.assert_not_called()
        self.assertTrue((self.root / "out/FAILED.json").exists())
        self.assertFalse((self.root / "out/COMPLETE.json").exists())

    def test_clean_committed_gate_precedes_any_runtime_load(self):
        plan = ex.make_plan("lcc"); write(self.root / "plan.json", plan)
        config_files(self.root); write(self.root / "execution.json", record(plan))
        from kv_harness.manifest import ValidationError
        with patch.object(ex, "check_baseline", return_value={"manifest_sha256": "b" * 64}), \
             patch("kv_harness.manifest.RunManifest.create", side_effect=ValidationError("real_model requires clean committed source")) as source_gate, \
             patch.object(ex, "execute") as runtime:
            with self.assertRaisesRegex(ValidationError, "clean committed"):
                ex.run(self.root / "plan.json", self.root / "out", execute_flag=True,
                       config_path=self.root / "config.json", baseline_run=self.root / "baseline",
                       baseline_analysis=self.root / "baseline_analysis", execution_record=self.root / "execution.json")
        runtime.assert_not_called()
        self.assertEqual(source_gate.call_args.kwargs["evidence_kind"], "real_model")
        self.assertTrue((self.root / "out/FAILED.json").exists())

    def test_record_rejects_budget_expansion_and_legacy_resources(self):
        p = ex.make_plan("lcc"); b = {"manifest_sha256": "b" * 64}
        ex.check_execution_record(record(p), p, b)
        for changes in ({"screen_all_in_cap_cny": "21"}, {"remaining_project_cny": "101"}, {"project_spent_cny": "-1"},
                        {"screen_all_in_cap_cny": "NaN"}, {"screen_all_in_cap_cny": "bad"},
                        {"external_stop_verified": False}, {"resource_origin": "existing_resource"},
                        {"max_wall_seconds": 2701}, {"no_automatic_retry": False}, {"plan_sha256": "a" * 64}):
            with self.subTest(changes=changes), self.assertRaises(ContractError): ex.check_execution_record({**record(p), **changes}, p, b)

    def test_queries_and_gold_cannot_change_plan(self):
        p = ex.make_plan("lcc")
        config, contexts, qs, _ = config_files(self.root)
        ex.check_config(config, contexts, qs, p)
        qs[contexts[0].context_id][0]["reference_texts"] = ["forbidden"]
        with self.assertRaisesRegex(ContractError, "labels"): ex.check_config(config, contexts, qs, p)

    def test_dataset_metadata_mismatch_rejected_before_execution(self):
        plan = ex.make_plan("lcc")
        config, contexts, questions, _ = config_files(self.root)
        for key, value in (("source_revision", "f" * 40), ("preprocessing_sha256", "f" * 64),
                           ("source_id", "zai-org/LongBench/repobench-p"), ("split", "heldout"),
                           ("evidence_kind", "controlled_diagnostic")):
            changed = copy.deepcopy(config); changed["dataset"][key] = value
            with self.subTest(key=key), self.assertRaises(ContractError):
                ex.check_config(changed, contexts, questions, plan)

    def test_failure_log_preserves_attempted_scoring_cost(self):
        events = io.StringIO()
        torch = SimpleNamespace(cuda=SimpleNamespace(reset_peak_memory_stats=lambda _: None))
        def fail(): raise CalibrationBuildError("test", {"exact_replay_passes": 2, "status": "failed"})
        with patch("echo_pilot.runtime.synchronized_time", side_effect=lambda _: time.perf_counter()):
            with self.assertRaises(CalibrationBuildError): ex.timed_call(torch, events, "fixture", fail, time.monotonic() + 100)
        rows_ = [json.loads(x) for x in events.getvalue().splitlines()]
        self.assertEqual([r["event"] for r in rows_], ["started", "failed"])
        self.assertEqual(rows_[1]["attempted_forward_accounting"]["exact_replay_passes"], 2)
        self.assertGreaterEqual(rows_[1]["host_wall_seconds"], 0)

    def test_baseline_gate_checks_frozen_protocol_and_complete_scored_cells(self):
        plan = ex.make_plan("lcc")
        config, _, _, _ = config_files(self.root)
        run, analysis = self.root / "baseline", self.root / "baseline_analysis"
        run.mkdir(); analysis.mkdir(); write(run / "manifest.json", {"fixture_only": True})
        evidence = SimpleNamespace(payload={"evidence_kind": "real_model"}, run_id="fixture-gate", sha256="e" * 64)
        manifest = {"artifact_sha256": {"fixture": "a" * 64}}
        scores = []
        for ci, context in enumerate(plan["ordered_contexts"]):
            for q in context["questions"]:
                for arm in ("fullkv", "echo", "kvzip", "kvzip_echo_partition"):
                    scores.append({"run_id": evidence.run_id, "task": "lcc", "preset": "smoke8k", "split": "development",
                        "context_id": context["context_id"], "question_id": q["question_id"], "arm": arm,
                        "eviction_ratio": 0. if arm == "fullkv" else .5, "build_id": f"c{ci:05d}-{arm}-r00", "score": .5})
        paired = [{**r, "fullkv_score": .5, "partition_matched_kvzip_score": .5,
                   "delta_vs_fullkv": 0., "delta_vs_partition_matched_kvzip": 0.,
                   "fullkv_reference_build_id": r["build_id"].split("-")[0] + "-fullkv-r00",
                   "partition_matched_reference_build_id": r["build_id"].split("-")[0] + "-kvzip_echo_partition-r00"}
                  for r in scores if r["arm"] != "fullkv"]
        summary = {"status": "validated_quality_only", "run_id": evidence.run_id, "task": "lcc", "preset": "smoke8k", "split": "development",
                   "evidence": {"execution": "real_model", "fixture_only": False},
                   "arms": [{"arm": a, "eviction_ratio": 0. if a == "fullkv" else .5} for a in ("fullkv", "echo", "kvzip", "kvzip_echo_partition")],
                   "denominators": {"contexts": 2, "questions": 2, "builds": 8, "observed_result_cells": 8, "fullkv_observations": 2}}
        provenance = {"run_manifest_sha256": sha256_file(run / "manifest.json"), "data_manifest_sha256": ex.MANIFEST_SHA256,
                      "analysis_source_sha256": sha256_file(ROOT / "echo_pilot/analysis.py"), "run_artifact_sha256": manifest["artifact_sha256"],
                      "config_canonical_sha256": canonical_hash(config), "evidence_manifest_sha256": evidence.sha256}
        def seal():
            write(analysis / "ANALYSIS_COMPLETE.json", {"status": "validated_quality_only", "run_id": evidence.run_id,
                "artifact_sha256": {p.name: sha256_file(p) for p in analysis.iterdir() if p.name != "ANALYSIS_COMPLETE.json"}})
        write(analysis / "summary.json", summary); write(analysis / "provenance.json", provenance)
        rows(analysis / "question_scores.jsonl", scores); rows(analysis / "paired_questions.jsonl", paired); seal()
        with patch("echo_pilot.analysis._completed", return_value=(config, manifest, evidence)):
            self.assertEqual(ex.check_baseline(run, analysis, plan)["run_id"], evidence.run_id)
            for key, value in (("n_sink", 9), ("recent_tokens", 128), ("chunk_size", 1024)):
                original = config["selection"][key]; config["selection"][key] = value
                with self.subTest(key=key), self.assertRaises(ContractError): ex.check_baseline(run, analysis, plan)
                config["selection"][key] = original
            config["runtime"]["seed"] = 999
            with self.assertRaises(ContractError): ex.check_baseline(run, analysis, plan)
            config["runtime"]["seed"] = ex.SEED
            for name, original in (("question_scores.jsonl", scores), ("paired_questions.jsonl", paired)):
                rows(analysis / name, []); seal()
                with self.subTest(name=name), self.assertRaises(ContractError): ex.check_baseline(run, analysis, plan)
                rows(analysis / name, original); seal()
            summary["run_id"] = "wrong"; write(analysis / "summary.json", summary); seal()
            with self.assertRaises(ContractError): ex.check_baseline(run, analysis, plan)

    def test_post_build_envelope_failure_retains_accounting_and_releases_cache(self):
        torch = SimpleNamespace(cuda=SimpleNamespace(reset_peak_memory_stats=lambda _: None))
        for failure in ("deadline", "memory", "synchronization"):
            value = SimpleNamespace(cache=SimpleNamespace(layers=[object(), object()]),
                                    accounting={"status": "completed", "exact_replay_passes": 4})
            events = io.StringIO()
            sync = [1., 2.] if failure != "synchronization" else [1., RuntimeError("sync failed")]
            memory = RuntimeError("memory failed") if failure == "memory" else copy.deepcopy(MEMORY)
            with patch("echo_pilot.runtime.synchronized_time", side_effect=sync), \
                 patch("echo_pilot.runtime.memory_snapshot", side_effect=memory if isinstance(memory, Exception) else None,
                       return_value=memory), patch.object(ex.time, "monotonic", side_effect=[1., 20.]):
                with self.subTest(failure=failure), self.assertRaises((ContractError, RuntimeError)) as error:
                    ex.timed_call(torch, events, "candidate:build", lambda: value, deadline=10.)
            self.assertFalse(value.cache.layers)
            self.assertEqual(error.exception.accounting["exact_replay_passes"], 4)
            self.assertEqual(error.exception.accounting["operation_envelope_status"], "failed_after_scoring")
            self.assertEqual([r["event"] for r in map(json.loads, events.getvalue().splitlines())], ["started", "failed"])
            self.assertEqual(json.loads(events.getvalue().splitlines()[-1])["attempted_forward_accounting"]["exact_replay_passes"], 4)

    def test_deadline_refuses_forward(self):
        call = unittest.mock.Mock()
        with self.assertRaisesRegex(ContractError, "deadline"):
            ex.timed_call(None, io.StringIO(), "past", call, time.monotonic() - 1)
        call.assert_not_called()


class MaskEvaluationTests(unittest.TestCase):
    def test_oracles_do_not_rescore_and_clones_cannot_mutate_first_cache(self):
        context = PreparedContext("ctx", "fixture", (101, 102) + tuple(range(10, 34)), 2, (), 26, {})
        replay = prepare_common_replay(context, Tokenizer(), microchunk_tokens=4, sink_tokens=2,
                                      tokenizer_id="fixture/model", tokenizer_revision="a" * 40)
        model = Model(26)
        first = build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 2, "first"), eviction_ratio=.5, seed=ex.SEED)
        diagnostic = build_full_exact_diagnostic(DEPS, model, Tokenizer(), replay, diagnostic_only=True)
        forward_count = len(model.forward_ids)
        _, masks, _, _ = ex.diagnostic_masks(first, diagnostic, replay)
        self.assertEqual(len(model.forward_ids), forward_count)
        original = [layer.keys.copy() for layer in first.cache.layers]
        clones = []
        def fake_timed(torch, events, operation, call, deadline): return call(), copy.deepcopy(STATS)
        def mutate(torch, model, tok, ids, cache, length, limit):
            clones.append(cache)
            for layer in cache.layers: layer.keys[...] = -999
            return {"text": "fixture", "generated_token_ids": [1]}
        with patch.object(ex, "timed_call", fake_timed), patch("echo_pilot.runtime.greedy_answer", mutate), patch("echo_pilot.runtime.cache_bytes", return_value={}):
            for arm in ("fullkv", "no_calibration", *ex.ORACLES):
                ex.evaluate_mask(DEPS, model, Tokenizer(), first.cache, masks[arm], {"question_token_ids": [1]},
                                 26, 64, io.StringIO(), arm, time.monotonic() + 100)
        self.assertEqual(len(set(map(id, clones))), 6)
        self.assertTrue(all(not c.layers for c in clones))
        self.assertTrue(all(np.array_equal(a, b.keys) for a, b in zip(original, first.cache.layers)))
        self.assertTrue(all(l.self_attn.masked_key_indices is None for l in model.model.layers))

    def test_diagnostic_mismatch_fails_without_rescoring(self):
        context = PreparedContext("ctx", "fixture", (101, 102) + tuple(range(10, 34)), 2, (), 26, {})
        replay = prepare_common_replay(context, Tokenizer(), microchunk_tokens=4, sink_tokens=2, tokenizer_id="fixture/model", tokenizer_revision="a" * 40)
        model = Model(26)
        first = build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 2, "first"), eviction_ratio=.5)
        diag = build_full_exact_diagnostic(DEPS, model, Tokenizer(), replay, diagnostic_only=True)
        changed = DiagnosticBuild(VirtualScores(replay.partition, diag.virtual.values + 1), diag.full_exact, diag.accounting)
        count = len(model.forward_ids)
        with self.assertRaisesRegex(ContractError, "virtual scores differ"): ex.diagnostic_masks(first, changed, replay)
        self.assertEqual(len(model.forward_ids), count)


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.run = synthetic_archive(self.root)

    def analyze(self):
        return ana.analyze_run(self.run, self.root / "analysis", bootstrap_samples=20, allow_fixture=True)

    def test_complete_fixture_offline_scores_all_cells_in_real_context_clusters(self):
        result = self.analyze()
        self.assertTrue(result["fixture_only"])
        self.assertEqual(result["evidence_kind"], "cpu_fixture")
        self.assertEqual(result["denominators"], {"contexts": 2, "questions": 2, "arms": 9, "result_cells": 18})
        self.assertEqual({r["quality"]["context_count"] for r in result["arms"]}, {2})
        self.assertEqual(len({r["quality"]["draws_sha256"] for r in result["arms"]}), 1)
        contrast = result["regional_contrast"]
        self.assertEqual(contrast["pooled_arm"], "pooled_full_map_oracle")
        self.assertEqual(contrast["regional_arm"], "scale_map_oracle")
        self.assertEqual(len(contrast["context_audits"]), 2)
        self.assertFalse(contrast["model_quality_benefit_established"])
        paired = ana._rows(self.root / "analysis/paired_questions.jsonl")
        self.assertTrue(all("delta_vs_pooled_full_map_oracle" in r and
                            "pure_regional_contrast_interpretable" in r for r in paired))
        self.assertTrue((self.root / "analysis/ANALYSIS_COMPLETE.json").exists())

    def test_fixture_never_silently_upgrades_to_model_evidence(self):
        with self.assertRaisesRegex(ContractError, "explicitly opted-in"):
            ana.analyze_run(self.run, self.root / "analysis")

    def test_missing_or_duplicate_result_fails_even_after_resealing(self):
        path = self.run / "results.jsonl"
        data = ana._rows(path)
        for invalid in (data[:-1], data + data[:1]):
            rows(path, invalid); reseal(self.run)
            with self.assertRaises(ContractError): self.analyze()
        self.assertFalse((self.root / "analysis").exists())

    def test_resealed_oracle_mask_edit_fails_recomputation(self):
        path = self.run / "c00000/scores_masks.npz"
        with np.load(path, allow_pickle=False) as source: arrays = {k: source[k] for k in source.files}
        arrays["keep__rank_only_oracle"][..., 100] ^= True
        np.savez(path, **arrays); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "diagnostic/control mask"): self.analyze()

    def test_resealed_pooled_score_edit_fails_recomputation(self):
        path = self.run / "c00000/scores_masks.npz"
        with np.load(path, allow_pickle=False) as source: arrays = {k: source[k] for k in source.files}
        arrays["score__pooled_full_map_oracle"][..., 3000] += np.float32(.25)
        np.savez(path, **arrays); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "diagnostic/control mask"): self.analyze()

    def test_resealed_contrast_claim_fails_recomputation(self):
        path = self.run / "c00000/build.json"; build = ana._read(path)
        audit = build["diagnostics"]["allocation_diagnostic"]["regional_contrast"]
        audit["pure_regional_contrast_interpretable"] = not audit["pure_regional_contrast_interpretable"]
        write(path, build); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "provenance/allocation"): self.analyze()

    def test_confounded_cells_are_flagged_without_changing_quality_denominator(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            run = synthetic_archive(root, duplicate_virtual_knots=True)
            result = ana.analyze_run(run, root / "analysis", bootstrap_samples=20, allow_fixture=True)
            contrast = result["regional_contrast"]
            self.assertFalse(contrast["all_contexts_pure_regional_contrast_interpretable"])
            self.assertEqual(len(contrast["confounded_context_ids"]), 2)
            self.assertIn("confounded", contrast["interpretation"])
            self.assertEqual(result["denominators"], {"contexts": 2, "questions": 2, "arms": 9, "result_cells": 18})
            self.assertEqual(contrast["raw_paired_quality_delta"]["context_count"], 2)

    def test_pooled_result_cannot_be_reclassified_as_deployable(self):
        path = self.run / "results.jsonl"; data = ana._rows(path)
        next(r for r in data if r["arm"] == "pooled_full_map_oracle")["diagnostic_only"] = False
        rows(path, data); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "diagnostic status"): self.analyze()

    def test_resealed_replay_undercharge_fails(self):
        path = self.run / "c00000/build.json"; build = ana._read(path)
        build["accounting"]["full_exact_diagnostic"]["runtime"]["exact_replay_passes"] -= 1
        write(path, build); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "replay count"): self.analyze()

    def test_resealed_timing_nan_duplicate_json_and_failed_marker_rejected(self):
        (self.run / "FAILED.json").write_text("{}")
        with self.assertRaisesRegex(ContractError, "failed/partial"): self.analyze()
        (self.run / "FAILED.json").unlink()
        path = self.run / "results.jsonl"
        source = path.read_text(); path.write_text(source.replace('"generated_token_count": 1', '"generated_token_count": 1, "generated_token_count": 1', 1))
        reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Duplicate JSON"): self.analyze()

    def test_result_mask_query_or_cache_bindings_rejected(self):
        path = self.run / "results.jsonl"; original = ana._rows(path)
        for field, value in (("mask_sha256", "a" * 64), ("query_token_ids_sha256", "a" * 64), ("diagnostic_only", True),
                             ("query_cache", cache_description(2)), ("eviction_ratio", .75)):
            data = copy.deepcopy(original); data[0][field] = value
            rows(path, data); reseal(self.run)
            with self.subTest(field=field), self.assertRaises(ContractError): self.analyze()

    def test_missing_raw_event_and_unobserved_provider_money_rejected(self):
        path = self.run / "events.jsonl"; data = ana._rows(path)
        rows(path, data[:-2]); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "Missing operation"): self.analyze()
        rows(path, data)
        wall = ana._read(self.run / "run_timing.json"); wall["provider_cost_cny"] = 0
        write(self.run / "run_timing.json", wall); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "provider money"): self.analyze()

    def test_reordered_diagnostic_or_generation_log_rejected_after_reseal(self):
        path = self.run / "events.jsonl"; data = ana._rows(path)
        pairs = [data[i:i + 2] for i in range(0, len(data), 2)]
        for needle in ("full_exact:build", ":generate"):
            changed = sorted(pairs, key=lambda p: needle not in p[0]["operation"])
            rows(path, [event for pair in changed for event in pair]); reseal(self.run)
            with self.subTest(needle=needle), self.assertRaisesRegex(ContractError, "Operation order"):
                self.analyze()

    def test_extra_artifact_source_drift_and_baseline_schema_rejected(self):
        (self.run / "extra.txt").write_text("extra")
        with self.assertRaisesRegex(ContractError, "inventory"): self.analyze()
        (self.run / "extra.txt").unlink()
        manifest = ana._read(self.run / "manifest.json"); manifest["source_sha256"]["echo_pilot/runtime.py"] = "a" * 64
        write(self.run / "manifest.json", manifest); reseal(self.run)
        with self.assertRaisesRegex(ContractError, "source version"): self.analyze()


if __name__ == "__main__":
    unittest.main()
