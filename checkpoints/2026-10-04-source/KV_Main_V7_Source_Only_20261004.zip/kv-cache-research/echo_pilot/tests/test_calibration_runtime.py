"""CPU source-executing contract mocks, NOT native Torch/model parity tests."""
from __future__ import annotations

import ast
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field, replace
from functools import partial
import logging
import math
from pathlib import Path
import subprocess
import sys
from types import MethodType, ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from echo_pilot.calibration_runtime import (
    COMMON_PROMPT, CalibrationBuildError, FrozenReplayPlan, answer_candidate,
    build_candidate, build_full_exact_diagnostic, clone_query_cache,
    install_keep_mask, logical_to_mask_indices, mask_indices_to_keep,
    prepare_common_replay,
)
from echo_pilot.contracts import ContractError, PreparedContext
from research.calibration_methods.contracts import AnchorPlan
from research.calibration_methods.methods import plan_anchor_matrix, plan_anchors

ROOT = Path(__file__).resolve().parents[2]


class Tensor(np.ndarray):
    """Small NumPy-backed Torch spelling shim, only for the audited source paths."""
    def __new__(cls, values, dtype=None, device="cpu"):
        obj = np.asarray(values, dtype=dtype).view(cls)
        obj.device_name = str(device)
        return obj

    def __array_finalize__(self, obj):
        self.device_name = getattr(obj, "device_name", "cpu")

    @property
    def device(self): return self.device_name
    @property
    def is_cuda(self): return False
    def detach(self): return self
    def cpu(self): return Tensor(np.array(self), device="cpu")
    def clone(self): return Tensor(np.array(self), device=self.device)
    def numpy(self): return np.asarray(self)
    def float(self): return Tensor(self, dtype=np.float32, device=self.device)
    def to(self, target):
        return Tensor(self, device=target) if isinstance(target, str) else Tensor(self, dtype=target, device=self.device)
    def view(self, *shape): return Tensor(np.asarray(self).reshape(*shape), device=self.device)
    def reshape(self, *shape, **kwargs): return Tensor(np.asarray(self).reshape(*shape, **kwargs), device=self.device)
    def transpose(self, a, b): return Tensor(np.asarray(self).swapaxes(a, b), device=self.device)
    def unsqueeze(self, dim): return Tensor(np.expand_dims(np.asarray(self), dim), device=self.device)
    def contiguous(self): return self.clone()
    def size(self, dim=None): return self.shape[dim] if dim is not None else self.shape
    def amax(self, dim=None, keepdim=False): return Tensor(np.asarray(self).max(axis=dim, keepdims=keepdim), device=self.device)
    def sum(self, dim=None, keepdim=False, **kwargs):
        return Tensor(np.asarray(self).sum(axis=kwargs.pop("axis", dim), keepdims=kwargs.pop("keepdims", keepdim), **kwargs), device=self.device)
    def exp(self): return Tensor(np.exp(np.asarray(self)), device=self.device)
    def sin(self): return Tensor(np.sin(np.asarray(self)), device=self.device)
    def cos(self): return Tensor(np.cos(np.asarray(self)), device=self.device)
    def masked_fill(self, mask, value):
        result = self.clone()
        result[np.broadcast_to(mask, self.shape)] = value
        return result
    def masked_fill_(self, mask, value):
        self[np.broadcast_to(mask, self.shape)] = value
        return self
    def untyped_storage(self):
        return SimpleNamespace(data_ptr=lambda: self.__array_interface__["data"][0], nbytes=lambda: self.nbytes)


def softmax(values, dim):
    x = np.asarray(values).astype(np.float32)
    x = np.exp(x - x.max(axis=dim, keepdims=True))
    return Tensor((x / x.sum(axis=dim, keepdims=True)).astype(values.dtype))


TORCH = SimpleNamespace(
    Tensor=Tensor, long=np.int64, float32=np.float32, float16=np.float16,
    tensor=lambda value, dtype=None, device="cpu": Tensor(np.array(value, dtype=dtype), device=device),
    zeros=lambda *shape, dtype=np.float32, device="cpu": Tensor(np.zeros(shape[0] if len(shape) == 1 and isinstance(shape[0], tuple) else shape, dtype=dtype), device=device),
    full=lambda shape, fill, dtype=np.float32, device="cpu": Tensor(np.full(shape, fill, dtype=dtype), device=device),
    arange=lambda *args, device="cpu": Tensor(np.arange(*args), device=device),
    cat=lambda values, dim=0: Tensor(np.concatenate(values, axis=dim)),
    maximum=lambda a, b: Tensor(np.maximum(np.asarray(a), np.asarray(b))),
    matmul=lambda a, b: Tensor(np.matmul(np.asarray(a), np.asarray(b))),
    finfo=np.finfo, no_grad=nullcontext,
)


class Hook:
    def __init__(self, hooks, callback):
        self.hooks, self.callback = hooks, callback
        hooks.append(callback)
    def remove(self):
        if self.callback in self.hooks:
            self.hooks.remove(self.callback)


class Projection:
    def __init__(self): self.hooks = []
    def register_forward_hook(self, callback): return Hook(self.hooks, callback)
    def __call__(self, x):
        for hook in tuple(self.hooks): hook(self, (), x)
        return x


class DenseCache:
    last = None
    def __init__(self):
        self.layers = []
        DenseCache.last = self
    def get_seq_length(self, layer): return self.layers[layer].keys.shape[2]


class Attention:
    def __init__(self, idx, config, owner):
        self.layer_idx, self.config, self.owner = idx, config, owner
        self.head_dim = 2
        self.q_proj, self.hooks = Projection(), []
        self.masked_key_indices = None
    def register_forward_hook(self, callback, with_kwargs=False):
        if self.owner.fail_registration_layer == self.layer_idx:
            raise RuntimeError("injected hook registration failure")
        return Hook(self.hooks, callback)
    def __call__(self, hidden, cache, positions):
        self.q_proj(hidden)
        b, t, _ = hidden.shape
        keys = Tensor(np.asarray(hidden).reshape(b, t, 2, 2, 2).mean(axis=3).transpose(0, 2, 1, 3), dtype=self.owner.dtype)
        if len(cache.layers) <= self.layer_idx:
            cache.layers.append(SimpleNamespace(keys=keys, values=keys.clone()))
        else:
            layer = cache.layers[self.layer_idx]
            layer.keys = TORCH.cat([layer.keys, keys], dim=2)
            layer.values = TORCH.cat([layer.values, keys], dim=2)
        if self.owner.fail_replay_layer == self.layer_idx and cache.get_seq_length(self.layer_idx) > self.owner.context_length:
            raise RuntimeError("injected replay failure after cache append")
        embeddings = (Tensor(np.ones((1, t, 2), dtype=np.float32)), Tensor(np.zeros((1, t, 2), dtype=np.float32)))
        kwargs = {"hidden_states": hidden, "past_key_values": cache, "position_embeddings": embeddings}
        output = (hidden, None)
        for hook in tuple(self.hooks): output = hook(self, (), kwargs, output)
        if self.owner.leave_cache_tail and cache.get_seq_length(self.layer_idx) == self.owner.context_length and t != self.owner.context_length:
            cache.layers[self.layer_idx].keys = TORCH.cat([cache.layers[self.layer_idx].keys, keys[:, :, :1]], dim=2)
            cache.layers[self.layer_idx].values = TORCH.cat([cache.layers[self.layer_idx].values, keys[:, :, :1]], dim=2)
        return output


class ModelBody:
    def __init__(self, owner):
        self.owner, self.pre_hooks = owner, []
        self.layers = [SimpleNamespace(self_attn=Attention(i, owner.config, owner)) for i in range(2)]
        self.rotary_emb = SimpleNamespace(inv_freq=Tensor([0.0]))
    def register_forward_pre_hook(self, callback, with_kwargs=False): return Hook(self.pre_hooks, callback)
    def __call__(self, **kwargs):
        for hook in tuple(self.pre_hooks): hook(self, (), kwargs)
        return self.forward(**kwargs)
    def forward(self, input_ids, past_key_values, position_ids, **kwargs):
        self.owner.forward_ids.append(tuple(np.asarray(input_ids)[0].tolist()))
        hidden = Tensor((np.asarray(input_ids)[..., None] % 7 + np.arange(8)[None, None, :] + 1) / 20, dtype=self.owner.dtype)
        for layer in self.layers:
            layer.self_attn(hidden, past_key_values, position_ids)
        return SimpleNamespace(logits=Tensor([[[0., 1.]]]))


class Model:
    def __init__(self, context_length):
        self.config = SimpleNamespace(num_hidden_layers=2, num_key_value_heads=2, num_attention_heads=4,
                                      _attn_implementation="sdpa", model_type="llama", max_position_embeddings=1000)
        self.dtype, self.device = np.float16, "cpu"
        self.context_length = context_length
        self.forward_ids = []
        self.generation_config = SimpleNamespace(eos_token_id=1)
        self.fail_replay_layer = self.fail_registration_layer = None
        self.leave_cache_tail = False
        self.model = ModelBody(self)
    def __call__(self, **kwargs): return self.model(**kwargs)


def rotate_half(x):
    a = np.asarray(x)
    return Tensor(np.concatenate([-a[..., a.shape[-1] // 2:], a[..., :a.shape[-1] // 2]], axis=-1))


def query_states(module, hidden, positions):
    # Mock model uses zero-angle RoPE. The inherited virtual/exact scoring math
    # still executes; this helper is not evidence of native rotary/QK parity.
    return hidden.view(1, hidden.shape[1], 4, 2).transpose(1, 2)


def source_module(name, path, **extra):
    """Execute unedited audited function/class ASTs with explicit CPU shims."""
    module = ModuleType(name)
    module.__dict__.update(logging=logging, math=math, contextmanager=contextmanager,
        dataclass=dataclass, field=field, partial=partial, MethodType=MethodType,
        torch=TORCH, nn=SimpleNamespace(functional=SimpleNamespace(softmax=softmax)),
        BasePress=type("BasePress", (), {"post_init_from_model": lambda self, model: None}),
        QuantizedCache=type("QuantizedCache", (), {}), Gemma3PreTrainedModel=type("Gemma", (), {}),
        Qwen3Attention=type("Qwen", (), {}), SUPPORTED_MODELS=(Model,),
        rotate_half=rotate_half, HAS_TRITON=False,
        get_query_states=query_states,
        extract_keys_and_values=lambda cache, i: (cache.layers[i].keys, cache.layers[i].values))
    module.__dict__.update(extra)
    tree = ast.parse(path.read_text())
    tree.body = [ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)] + [
        node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
    ast.fix_missing_locations(tree)
    sys.modules[name] = module
    exec(compile(tree, str(path), "exec"), module.__dict__)
    return module


KVZIP = source_module("_cpu_audited_kvzip", ROOT / "research/sources/echopress_39748e9/kvpress/presses/kvzip_press.py")
ECHO = source_module("_cpu_audited_echo", ROOT / "research/sources/echopress_39748e9/kvpress/presses/echo_press.py", KVzipPress=KVZIP.KVzipPress)
DEPS = SimpleNamespace(torch=TORCH, transformers=SimpleNamespace(DynamicCache=DenseCache),
                       kvpress=SimpleNamespace(EchoPress=ECHO.EchoPress, KVzipPress=KVZIP.KVzipPress))


class Tokenizer:
    chat_template = "mock template"
    def apply_chat_template(self, messages, **kwargs): return "PREFIX" + messages[0]["content"] + "SUFFIX"
    def decode(self, ids, skip_special_tokens=False): return "mock answer"
    def encode(self, text, add_special_tokens=False):
        return {"PREFIX": [101, 102], "SUFFIX": [103], COMMON_PROMPT: [104, 105, 106]}[text]


def fixture():
    context = PreparedContext("context", "fixture", (101, 102) + tuple(range(10, 27)), 2, (), 19, {})
    replay = prepare_common_replay(context, Tokenizer(), microchunk_tokens=4, sink_tokens=2,
                                  tokenizer_id="mock/tokenizer", tokenizer_revision="a" * 40)
    return replay, Model(19)


class CommonRuntimeTests(unittest.TestCase):
    def assert_clean(self, model):
        self.assertEqual(model.model.pre_hooks, [])
        for layer in model.model.layers:
            self.assertEqual(layer.self_attn.q_proj.hooks, [])
            self.assertEqual(layer.self_attn.hooks, [])

    def test_plan_context_only_complete_inputs_offsets_and_budget(self):
        replay, _ = fixture()
        self.assertEqual([(c.start, c.end) for c in replay.partition.chunks], [(2, 6), (6, 10), (10, 14), (14, 18), (18, 19)])
        self.assertEqual([len(ids) for ids in replay.replay_token_ids], [8, 8, 8, 8, 5])
        plans = plan_anchor_matrix(replay.partition, 2, 16, random_seeds=(7, 11, 29))
        self.assertTrue(all(p.cost() == plans[0].cost() for p in plans))
        for i, chunk in enumerate(replay.partition.chunks):
            self.assertEqual(replay.replay_token_ids[i][-chunk.shape[0]:], replay.context_token_ids[chunk.start:chunk.end])
            self.assertEqual(replay.chunk_metadata(i)["rope_delta"], 19 + 4 - chunk.start)
        with self.assertRaisesRegex(ValueError, "token cap"):
            plan_anchor_matrix(replay.partition, 2, 15)
        with self.assertRaisesRegex(ContractError, "Replay IDs"):
            replace(replay, replay_token_ids=(replay.replay_token_ids[1],) + replay.replay_token_ids[1:])
        with self.assertRaisesRegex(ContractError, "PreparedContext"):
            prepare_common_replay({"context": [1], "query": "forbidden"}, Tokenizer(), microchunk_tokens=4,
                                  sink_tokens=0, tokenizer_id="mock", tokenizer_revision="a" * 40)
        with self.assertRaises(TypeError):
            prepare_common_replay(None, None, query="forbidden")

    def test_sparse_noncontiguous_replays_execute_pinned_scoring_at_absolute_offsets(self):
        replay, model = fixture()
        anchors = AnchorPlan(replay.partition, (1, 3), "random", 7)
        before_forward = model.model.forward
        candidate = build_candidate(DEPS, model, Tokenizer(), replay, anchors, eviction_ratio=.4, recent_tokens=1)
        self.assertEqual(model.forward_ids, [replay.context_token_ids, replay.replay_token_ids[1], replay.replay_token_ids[3]])
        self.assertEqual(candidate.virtual.values.shape, (2, 2, 19))
        self.assertEqual(candidate.anchors.values.shape, (2, 2, 8))
        self.assertEqual(candidate.accounting["observed_forward_input_lengths"], [19, 8, 8])
        self.assertEqual(candidate.accounting["exact_replay_input_tokens"], 16)
        self.assertEqual(candidate.accounting["exact_replay_prompt_tokens"], 8)
        self.assertEqual(candidate.accounting["exact_replay_context_tokens"], 8)
        self.assertEqual(candidate.accounting["replay_dense_causal_attention_pairs_proxy"], 2 * (19 * 8 + 8 * 9 // 2))
        self.assertEqual(candidate.accounting["exact_pre_storage_scalar_dtypes"], ["float16"])
        self.assertEqual(candidate.accounting["virtual_pre_storage_scalar_dtypes"], ["float32"])
        self.assertEqual(model.model.forward, before_forward)
        self.assertTrue(candidate.keep_mask[..., :2].all())
        self.assertTrue(candidate.keep_mask[..., -1].all())
        self.assertEqual((~candidate.keep_mask).sum(), int(2 * 2 * 19 * .4))
        self.assertEqual([candidate.cache.get_seq_length(i) for i in range(2)], [19, 19])
        self.assert_clean(model)

    def test_full_exact_matches_sparse_labels_and_denominators_are_policy_independent(self):
        replay, model = fixture()
        sparse = build_candidate(DEPS, model, Tokenizer(), replay,
                                 AnchorPlan(replay.partition, (1, 3), "random", 7), eviction_ratio=.3)
        diagnostic = build_full_exact_diagnostic(DEPS, Model(19), Tokenizer(), replay, diagnostic_only=True)
        self.assertTrue(np.array_equal(sparse.anchors.values, diagnostic.full_exact.values[..., sparse.anchors.plan.token_indices]))
        self.assertTrue(np.array_equal(sparse.virtual.values, diagnostic.virtual.values))
        self.assertEqual(sparse.accounting["chunks"], diagnostic.accounting["chunks"])
        self.assertEqual(diagnostic.accounting["observed_forward_input_lengths"], [19, 8, 8, 8, 8, 5])
        self.assertEqual(diagnostic.accounting["exact_replay_input_tokens"], 37)
        self.assertFalse(diagnostic.accounting["deployable_cost"])
        self.assertTrue(diagnostic.accounting["diagnostic_only"])
        self.assertNotEqual(sparse.accounting["exact_replay_input_tokens"], diagnostic.accounting["exact_replay_input_tokens"])
        with self.assertRaisesRegex(ContractError, "no diagnostic labels"):
            build_candidate(DEPS, model, Tokenizer(), replay, diagnostic.full_exact, eviction_ratio=.3)
        with self.assertRaisesRegex(ContractError, "explicit"):
            build_full_exact_diagnostic(DEPS, model, Tokenizer(), replay, diagnostic_only=False)
        with self.assertRaises(TypeError):
            build_full_exact_diagnostic(DEPS, model, Tokenizer(), replay)

    def test_mask_roundtrip_device_conversion_and_in_place_source_patch_on_independent_clone(self):
        replay, model = fixture()
        candidate = build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        masks = logical_to_mask_indices(candidate.keep_mask)
        self.assertTrue(np.array_equal(mask_indices_to_keep(masks, candidate.keep_mask.shape), candidate.keep_mask))
        frozen = candidate.cache.layers[0].keys.clone()
        clone = clone_query_cache(DEPS, model, candidate)
        self.assertNotEqual(clone.layers[0].keys.untyped_storage().data_ptr(), candidate.cache.layers[0].keys.untyped_storage().data_ptr())
        for layer in clone.layers:
            layer.keys.device_name = "mock:1"
            layer.values.device_name = "mock:1"
        installed = install_keep_mask(TORCH, model, candidate.keep_mask, clone)
        self.assertTrue(all(t.device == "mock:1" for triple in installed for t in triple))
        self.assertTrue(all(t.dtype == np.int64 for triple in installed for t in triple))
        self.assertIsNot(installed[0][0], model.model.layers[0].self_attn.masked_key_indices[0])
        patch = source_module("_cpu_audited_attention_patch", ROOT / "echo_pilot/vendor_audit/kvpress__attention_patch.py",
                              ALL_ATTENTION_FUNCTIONS={})
        patch.search_hyperplane = lambda q: Tensor(np.full((q.shape[0], q.shape[-1]), -999.))
        patched = patch.attention_patch(lambda module, q, k, v, attention_mask, dropout, **kwargs: k)
        key = clone.layers[0].keys
        output = patched(model.model.layers[0].self_attn, Tensor(np.ones((1, 4, 1, 2))), key,
                         clone.layers[0].values, None, 0.)
        pruned = ~candidate.keep_mask[0]
        self.assertTrue(np.all(np.asarray(output)[0][pruned] == -999))
        self.assertTrue(np.array_equal(candidate.cache.layers[0].keys, frozen))
        self.assertTrue(np.array_equal(np.asarray(output)[0][~pruned], np.asarray(frozen)[0][~pruned]))
        second = clone_query_cache(DEPS, model, candidate)
        self.assertTrue(np.array_equal(second.layers[0].keys, frozen))

    def test_invalid_masks_and_impossible_protection_fail_before_forward(self):
        for bad in [np.ones((2, 2, 5)), np.ones((2, 1, 2, 5), bool)]:
            with self.assertRaises(ContractError): logical_to_mask_indices(bad)
        masks = list(logical_to_mask_indices(np.ones((1, 2, 5), bool)))
        masks[0] = (np.array([0, 0]), np.array([1, 1]), np.array([2, 2]))
        with self.assertRaisesRegex(ContractError, "Duplicate"): mask_indices_to_keep(masks, (1, 2, 5))
        masks[0] = (np.array([1]), np.array([0]), np.array([0]))
        with self.assertRaisesRegex(ContractError, "bounds"): mask_indices_to_keep(masks, (1, 2, 5))
        replay, model = fixture()
        with self.assertRaisesRegex(ValueError, "Retained budget"):
            build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"),
                            eviction_ratio=.95, recent_tokens=3)
        self.assertEqual(model.forward_ids, [])

    def test_failure_after_partial_replay_restores_hooks_forward_masks_cache_and_accounting(self):
        replay, model = fixture()
        original = model.model.forward
        sentinel = ("previous",)
        model.model.layers[0].self_attn.masked_key_indices = sentinel
        model.fail_replay_layer = 1
        with self.assertRaises(CalibrationBuildError) as raised:
            build_candidate(DEPS, model, Tokenizer(), replay, AnchorPlan(replay.partition, (1, 3), "random", 7), eviction_ratio=.4)
        self.assertEqual(raised.exception.accounting["status"], "failed")
        self.assertEqual(raised.exception.accounting["observed_forward_input_lengths"], [19, 8])
        self.assertEqual(raised.exception.accounting["observed_replay_input_tokens"], 8)
        self.assertEqual(raised.exception.accounting["exact_replay_passes"], 1)
        self.assertEqual(raised.exception.accounting["completed_exact_replay_passes"], 0)
        self.assertEqual(raised.exception.accounting["planned_exact_replay_passes"], 2)
        self.assertEqual(DenseCache.last.layers, [])
        self.assertEqual(model.model.forward, original)
        self.assertIs(model.model.layers[0].self_attn.masked_key_indices, sentinel)
        self.assert_clean(model)

    def test_partial_hook_registration_and_leftover_cache_are_rejected_and_cleaned(self):
        for failure in ("fail_registration_layer", "leave_cache_tail"):
            with self.subTest(failure=failure):
                replay, model = fixture()
                setattr(model, failure, 1 if failure == "fail_registration_layer" else True)
                with self.assertRaises(CalibrationBuildError):
                    build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
                self.assertEqual(DenseCache.last.layers, [])
                self.assert_clean(model)

    def test_no_calibration_uses_same_paid_replays_and_only_replaces_anchors(self):
        replay, model = fixture()
        plan = AnchorPlan(replay.partition, (1, 3), "random", 7)
        candidate = build_candidate(DEPS, model, Tokenizer(), replay, plan, eviction_ratio=.4,
                                    calibration_enabled=False)
        mutable = [i for i in range(replay.partition.token_count) if i not in plan.token_indices]
        self.assertTrue(np.array_equal(candidate.calibration.scores[..., mutable], candidate.virtual.values[..., mutable]))
        self.assertTrue(np.array_equal(candidate.calibration.scores[..., plan.token_indices], candidate.anchors.values))
        self.assertEqual(candidate.accounting["completed_exact_chunk_ids"], [1, 3])
        self.assertEqual(candidate.accounting["exact_replay_input_tokens"], 16)

    def test_query_phase_uses_shared_decoder_and_new_cache_for_each_query(self):
        replay, model = fixture()
        candidate = build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        frozen = [layer.keys.clone() for layer in candidate.cache.layers]
        for query in ((81, 82), (83,)):
            answer = answer_candidate(DEPS, model, Tokenizer(), candidate, query, max_new_tokens=4)
            self.assertEqual(answer["generated_token_ids"], [1])
            self.assertTrue(answer["stopped_on_eos"])
            self.assertTrue(all(layer.self_attn.masked_key_indices is None for layer in model.model.layers))
            self.assertTrue(all(np.array_equal(layer.keys, old) for layer, old in zip(candidate.cache.layers, frozen)))
        self.assertEqual(model.forward_ids[-2:], [(81, 82), (83,)])
        self.assertEqual([candidate.cache.get_seq_length(i) for i in range(2)], [19, 19])

    def test_mask_allocation_failure_is_transactional_and_cleans_owned_cache(self):
        replay, model = fixture()
        previous = [("old layer zero",), ("old layer one",)]
        for layer, old in zip(model.model.layers, previous):
            layer.self_attn.masked_key_indices = old
        native_clone = Tensor.clone
        count = 0
        def fail_fourth_int_clone(value):
            nonlocal count
            if value.dtype == np.int64:
                count += 1
                if count == 4:
                    raise RuntimeError("injected mask clone allocation failure")
            return native_clone(value)
        with patch.object(Tensor, "clone", fail_fourth_int_clone):
            with self.assertRaisesRegex(CalibrationBuildError, "mask clone allocation") as raised:
                build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        self.assertEqual(raised.exception.accounting["status"], "failed_after_scoring")
        for layer, old in zip(model.model.layers, previous):
            self.assertIs(layer.self_attn.masked_key_indices, old)
        self.assertEqual(DenseCache.last.layers, [])
        self.assert_clean(model)
        candidate = build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        count = 0
        with patch.object(Tensor, "clone", fail_fourth_int_clone):
            with self.assertRaisesRegex(RuntimeError, "mask clone allocation"):
                answer_candidate(DEPS, model, Tokenizer(), candidate, (81,), max_new_tokens=4)
        self.assertTrue(all(layer.self_attn.masked_key_indices is None for layer in model.model.layers))
        self.assertEqual([candidate.cache.get_seq_length(i) for i in range(2)], [19, 19])

    def test_postscore_failure_keeps_completed_work_accounting(self):
        replay, model = fixture()
        with patch("echo_pilot.calibration_runtime.calibrate", side_effect=ValueError("injected calibration failure")):
            with self.assertRaises(CalibrationBuildError) as raised:
                build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 2, "first"), eviction_ratio=.4)
        accounting = raised.exception.accounting
        self.assertEqual(accounting["status"], "failed_after_scoring")
        self.assertEqual(accounting["completed_exact_replay_passes"], 2)
        self.assertEqual(accounting["exact_replay_input_tokens"], 16)
        self.assertEqual(DenseCache.last.layers, [])
        self.assert_clean(model)
        self.assertTrue(all(layer.self_attn.masked_key_indices is None for layer in model.model.layers))

    def test_invalid_calibration_and_model_modes_fail_before_forward(self):
        replay, model = fixture()
        context = PreparedContext("context", "fixture", replay.context_token_ids, 2, (), 19, {})
        tiny = prepare_common_replay(context, Tokenizer(), microchunk_tokens=1, sink_tokens=2,
                                     tokenizer_id="mock/tokenizer", tokenizer_revision="a" * 40)
        with self.assertRaisesRegex(ContractError, "two anchor knots"):
            build_candidate(DEPS, model, Tokenizer(), tiny, plan_anchors(tiny.partition, 1, "first"), eviction_ratio=.4)
        self.assertEqual(model.forward_ids, [])
        model.training = True
        with self.assertRaisesRegex(ContractError, "Evaluation mode"):
            build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        model.training = False
        model.hf_device_map = {"layer0": "cuda:0", "layer1": "cuda:1"}
        with self.assertRaisesRegex(ContractError, "Sharded"):
            build_candidate(DEPS, model, Tokenizer(), replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        self.assertEqual(model.forward_ids, [])

    def test_tokenizer_mismatch_fails_without_forward(self):
        replay, model = fixture()
        tokenizer = Tokenizer()
        tokenizer.chat_template = "changed"
        with self.assertRaisesRegex(ContractError, "no longer matches"):
            build_candidate(DEPS, model, tokenizer, replay, plan_anchors(replay.partition, 1, "first"), eviction_ratio=.4)
        self.assertEqual(model.forward_ids, [])

    def test_import_and_plan_have_no_ml_import_or_download(self):
        code = r'''
import builtins
real = builtins.__import__
def guarded(name, *args, **kwargs):
    if name.split('.')[0] in {'torch', 'transformers', 'kvpress', 'huggingface_hub'}:
        raise RuntimeError('forbidden native import: ' + name)
    return real(name, *args, **kwargs)
builtins.__import__ = guarded
from echo_pilot.calibration_runtime import prepare_common_replay, COMMON_PROMPT
from echo_pilot.contracts import PreparedContext
class T:
    chat_template = None
    def encode(self, s, add_special_tokens=False):
        return [] if s == '' else ([5] if s == '\n' else [6, 7])
c = PreparedContext('c', 's', tuple(range(20)), 0, (), 20, {})
p = prepare_common_replay(c, T(), microchunk_tokens=4, sink_tokens=1,
                          tokenizer_id='test', tokenizer_revision='a'*40)
assert len(p.replay_token_ids) == 5
'''
        result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__": unittest.main()
