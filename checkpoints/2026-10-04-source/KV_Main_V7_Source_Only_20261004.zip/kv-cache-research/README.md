# KV Cache Research

Status (2026-10-03): **CPU research completed to the declared stopping gates; no main-method innovation or useful quality improvement established. GPU work is paused by the user.** This checkpoint includes actual synthetic CPU experiments, reviewed source findings and two stopped pretrained CPU probes. It must not be described as merely a software-test package or as a positive compression result.

## Current outcomes

- **Candidates A/B/C are closed as main directions at their scoped CPU gates.** A's constructed score instability is removed by elementary softmax-first and centered-redundancy controls; C's exact-state defects are removed by boundary-capped accepted-state transactions. B's actual backing-buffer measurements favor a simple common retained prefix over the tested union representation at matched token-read count. These screens do not prove every related method bad, quality-dominated or universally slow. [A/C results](research/diagnostics/candidate_elimination/README.md), [B results](research/diagnostics/shared_prefix_memory/CPU_report.md), [independent rejection review](research/cpu_rejection_review.md)
- **HYPIC source finding and corrected-reference Gate 0 are distinct.** The source audit found a cold/hit seam contract defect and contextual warmup; the intended-semantics CPU reference passed 101 math fixtures and 32 tiny-random-HF checks. No released HYPIC/SGLang end-to-end or pretrained quality comparison ran. A source bug repair is not a new research mechanism. [Source review](research/hypic_baseline_source_review.md), [Gate 0](research/diagnostics/hybrid_recurrence_cpu/README.md)
- **Qwen3.5-0.8B FP32: competence stop.** The first full-recompute cell answered blue instead of red; 1/16 cells completed and 15 remain unrun. No exact-prefix or reuse result exists. One pre-forward JSON-logging failure and its logging-only retry are preserved; it was not an answer retry. [Results](research/diagnostics/hybrid_cpu_competence/RESULTS.md)
- **One Qwen3.5-2B BF16 qualification: numerical stop.** Full and exact-prefix both answered red on d01/A1, but candidate-margin drift was **−0.1250469423 nat** against the frozen strict **0.01-nat** cap; first-token TV was 0.0124600772 against 0.0025. Only 2/16 cells completed; 14 remain unrun. Correct answers do not waive parity failure. Arithmetic scheduling versus a cached-path implementation issue was not isolated. This does not establish observed answer degradation, general BF16 unsuitability, or failure of the recurrent-conditioning hypothesis. [Results](research/diagnostics/hybrid_cpu_competence_v3/RESULTS.md), [independent terminal review](research/bf16_probe_admission_review.md)

No held-out/reuse/donor/repair matrix or released-HYPIC comparison was executed. The 84 tiny pre-admission numerical controls passed but did not establish pretrained parity. No further model, precision fallback, threshold relaxation, continued cells or GPU action is released by this stopped route.

## Current control and delivery state

- **GPU paused; project-attributable spend CNY0.** The historical CNY100 limit is only a ceiling, not permission to restart. Discuss with the user before any GPU use and obtain a new applicable go-ahead. Every existing AutoDL resource remains off limits
- Earlier AutoDL login/offer observations are historical. They do not establish current inventory, price, shutdown readiness or execution authority
- Source is committed locally only. GitHub remains the last verified partial prior checkpoint (08:59 UTC); selected-repository App access is pending explicit confirmation. No push or grant accompanies this package
- The ZIP includes source, frozen protocols v1/v2/v3, safe raw CSV/JSON/logs, figures, source pins/licenses and the two saved BF16 logit captures needed for a no-forward audit. Constructed prompt/token fixtures are project-authored; external benchmark text/reversible plans, pretrained weights, wheelhouses, environments, credentials and private user files are excluded
- Exactly four allowlisted files under `outputs/hybrid_cpu_competence_v3/qualification_run/` are included for the unchanged saved-logit verifier: `cells.jsonl`, `summary.json`, and the two `*_raw_logits.pt` files. The rest of `outputs/` remains excluded

## Evidence and verification map

[Packaging verification](research/diagnostics/checkpoint_outcomes_20261003/README.md) separates current model-free checks and saved-result audits from actual research outcomes. It preserves one initial missing-dependency test error and the unchanged successful rerun in the existing appropriate environment. Packaging performs no pretrained load or model forward.

The earlier **360-test calibration checkpoint is historical**, at commit `36e6705`; its original logs and passed/skipped distinctions remain in [that report](research/diagnostics/checkpoint_v2_20261003/README.md). Its temporary native environments are no longer available and the full old aggregate was not rerun here. Counts from different research cells, software suites, property checks and historical repeats must not be combined into an inflated result count.

The previous nine-arm calibration protocol and audits remain preserved as historical work: [protocol](research/calibration_pooled_control_protocol_v2.md), [review](research/pooled_oracle_review.md), [novelty audit](research/calibration_novelty_followup.md). No substantive method novelty, downstream improvement, physical KV-memory saving or serving speedup was established there either. Its 64 baseline-stage builds remain planned and unexecuted.

## Reproducibility harness

The reusable harness below records software/evidence contracts. Its generated
fixtures are not model results. Actual research outcomes are separately labeled
and linked above. Nothing in its commands rents compute or calls a paid API.

The harness stays method-neutral. See the linked validation records for the precise tested scope of each component.

## Run locally without installation

The basic harness requires Python 3.11+ and Git and uses only the standard
library. Additional pilot, tokenizer and native CPU suites have the separately
documented dependencies. From this repository root:

```sh
python -m unittest discover -v
python -m kv_harness --help
python -m kv_harness cpu-fixture --output outputs/demo
python -m kv_harness validate \
  --manifest outputs/demo/manifest.json --results outputs/demo/results.jsonl
python -m kv_harness analyze \
  --manifest outputs/demo/manifest.json --results outputs/demo/results.jsonl \
  --baseline fixture_baseline --candidate fixture_candidate \
  --allow-nonexperimental --output outputs/demo/summary.json
python -m kv_harness ledger --path records/cost_ledger.csv
```

Use a new output directory for each run. Files are atomically published without
replacement. The two fixture methods perform identical hashing and CPU-copy work
on generated bytes. Their measured wall times test the plumbing, and cannot be
interpreted as an algorithm comparison. Fixture outputs are ignored by Git.

## Implemented

- Immutable, checksummed manifests: Git revision, staged/unstaged/combined diff
  hashes, untracked file hashes, immutable model/dataset pins, seed, configuration,
  Python/platform/package versions, and explicit hardware metadata
- Strict result JSONL: duplicate/unknown fields, malformed values, checksum
  mismatches, mixed evidence classes, incomplete or duplicate pairs, and missing
  timing costs are rejected
- Separate `real_model`, `cpu_fixture`, and `simulation` evidence labels. Fixture
  analysis requires an explicit opt-in and stays labeled nonexperimental
- End-to-end wall time, disjoint or overlapping phase costs, preprocessing,
  scoring, host/device copies, and measured shared-setup amortization
- Separate logical token/byte budgets from physically allocated/stored bytes and
  allocator peaks; masking is explicitly distinguishable from KV compaction
- Paired context/trace-cluster bootstrap. Questions sharing a cache use the same
  `cluster_id`; repeat measurements do not inflate the independent sample count
- Deterministic bootstrap seeds and result-content hashes in every summary
- Read-only cost-ledger audit, with decimal amounts and no currency conversion

## Current stopping boundaries

Do not rerun stopped pretrained cells or widen the model/precision/tolerance
search. The current CPU qualification route is closed under its frozen rules.
Future work would need a distinct justified question, appropriate user direction,
and a predeclared protocol before outcomes; no automatic experiment progression
follows from this package or from available budget.

The preserved GPU template, calibration plans and protocol runners are audit
artifacts, not launch authorization. Historical documents describe the state at
their own timestamp; the current GPU pause and stopped results above take priority.

## Contracts and limitations

Read [the evidence contract](docs/evidence_contract.md) before writing an adapter.
Manifest checksums detect changes relative to a supplied digest; they are not
signatures and do not prove that an experiment actually ran. A human or audited
adapter can still mislabel evidence. `real_model` manifests require a clean,
committed checkout. Submodules and Git index flags that can hide modifications
are currently rejected. Dirty fixture snapshots record hashes, not restorable
archives. Avoid changing source while snapshotting or running experiments.

Published files are read-only and the API refuses to overwrite them; a filesystem
owner can still edit or remove them. Archive actual source, inputs, outputs,
runtime logs and hardware/driver details when conducting real experiments. Keep
credentials and private environment variables out of explicit manifest metadata.

No remote repository publication is implied by a local commit. This scaffold
does not choose or confirm a license for third-party research code.
