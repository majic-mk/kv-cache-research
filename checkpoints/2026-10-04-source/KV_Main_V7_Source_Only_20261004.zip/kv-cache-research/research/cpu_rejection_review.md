# Independent review: CPU candidate-rejection evidence

Reviewed 2026-10-03 UTC. Scope: `research/diagnostics/candidate_elimination/` and `research/diagnostics/shared_prefix_memory/`. No author script, retained result, protocol, or project implementation was edited. No full allocation/scoring sweep was rerun, and no model, Torch, dependency installation, GPU, remote mutation, or commit was used.

## Decision

**Accept the two screens as valid, bounded negative evidence for the currently proposed method claims. No conclusion-changing implementation or arithmetic error was found.** Their interpretation must remain narrower than a claim that the underlying practical problems are unimportant or solved.

- **A:** two elementary scoring changes eliminate the specified common-key-translation dependence. This removes the mechanism-based novelty premise. It does not establish better natural retention quality, robustness of a deployed R-KV system, or numerical invariance at arbitrary precision/range.
- **C:** an ordinary accepted-state transaction capped at canonical eviction boundaries preserves this toy's serial contract. The cadence arithmetic exposes no substantial lost-slot problem at 128/8. This removes the stated need for a new reversible-eviction method at that gate. It does not measure speculative-decoding throughput or prove sampling correctness in a serving integration.
- **B:** the tested common-mask representation is cheaper at equal per-request retained-token counts; several diverse-mask layouts have no memory headroom even over a shared-full baseline. This does not establish common-mask quality dominance, nor prove independent/request-specific compression useless. No natural quality signal was measured. The screen supports declining to promote the current generic idea, not universally ruling out diverse-mask systems.

The current READMEs and detailed B report largely preserve these distinctions. Their statements that no model/GPU expansion is justified **by these screens alone** are appropriate resource-allocation decisions. They are not experimental proofs that a future, independently motivated natural-data question could never be worthwhile.

## Executed verification

### Retained evidence and reproducibility

1. Ran all eight A/C contract tests: passed.
2. Ran all thirteen B tests, including recursive State reachability, weak-reference destruction, deliberate corruption, and packer rejection: passed.
3. Ran B's retained-output verifier: all 56,160 rows passed byte/root/read/budget checks, and the two stored executions' seven compared raw/derived artifacts were byte-identical.
4. Independently checked all 45 files listed in B's `deliverable_hashes.json`: no hash mismatch, including the report and post-sweep analysis outputs.
5. Independently checked all five A/C retained output hashes; enumerated every expected row key; found exactly 19,200 A rows and 5,440 C rows, with no missing or duplicate grid keys. A's changed-set aggregates agree with its saved summaries.
6. Checked B's 1,440 case keys and 39 observations per case. Regenerated mask union and original-page cardinalities and compared all saved rows. This only regenerated masks and scalar cardinalities; it did not repeat the 1,440-case cache-allocation sweep.

### Fresh, bounded probes independent of the published tests

- **A:** separately implemented stable softmax, head reduction, seven-token max pooling, centered cosine suppression, and deterministic ranking on both retained one-fix counterexample inputs. Applying both fixes gave unchanged retained sets; the corresponding dense outputs were invariant to within 1e-11.
- **C:** implemented a separate exact-Fraction serial recurrence, including attention, ranking, query-ring evolution, event timing, and dropped counts. Compared it against the capped transactional arm in 130 small cases: cadences 3 and 7, all phases, widths 1/3/6, every accepted length, and a separately processed bonus input. Every complete state and output matched exactly. These are implementation robustness probes, not extra scientific trial counts.
- **B:** built 39 states at N=128, m=3, k=17 across three mask families and all thirteen representations. Recursively walked every persistent state field, followed owners without relying on the script's grouping, independently calculated bytes, checked reads and dense-copy isolation, and verified complete destruction after references were released. All passed. The non-page-aligned k exercises packed-page padding beyond the report's retained-token choices.

The complete executed probe and its JSON output are embedded below. The review therefore does not depend on an ephemeral `/tmp` script surviving.

## A: mechanism and claim audit

`run_a.py` implements the declared factorial consistently: old-key attention excludes the protected final eight keys before softmax, pooling occurs after observation reduction, redundancy uses the full key set, and selection restores the protected keys. The two fixes are crossed independently, so the large residual counts in each one-fix arm cannot be confused with the fully corrected arm. Protected/current keys are included in the common translation, which is necessary for the dense-attention invariance comparison.

The algebra is sound. A common translation adds a query-specific constant to all key logits. Per-query softmax cancels it; raw-logit head maximum generally does not. Subtracting the common key mean cancels the same translation before cosine similarity. The retained-set stability guard is a sufficient top-k perturbation test, not an arbitrary tolerance. Synthetic-value readout RMSE is correctly denied the status of natural-task quality evidence.

I reopened the pinned [R-KV HF utility source](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/HuggingFace/rkv/utils.py) and [HF scorer](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/HuggingFace/rkv/compression/r1_kv.py). The transcribed raw-head reduction and last-neighbor cosine suppression agree with those sources; the source itself already flags softmax-before-head-reduction. Lambda 0.1, deterministic tie breaking, and the FP64 reference are explicit screen choices rather than claims of bitwise source parity.

Two cautions remain essential:

- Finite grid success is not a guarantee against extremely large translations, low-precision cancellation, a cosine-threshold crossing induced by roundoff, or a near-tied retained-set cutoff.
- A post-RoPE common-key transformation is a controlled attention equivalence. Its natural occurrence, learned-model relevance, and downstream reliability were not measured.

No current report change is required to preserve these limits.

## C: semantics, acceptance, and cost audit

The canonical serial event occurs after the current query's readout and after its query metadata is recorded. The capped arm respects this ordering. It commits exactly the accepted prefix snapshot, executes eviction only at the accepted canonical boundary, and processes the correction/bonus input separately. The exact state comparison includes entries and original IDs, logical count, query count, query ring, dropped count, and event count; physical order is derived from the entries. There is no hidden tolerance in the successful state/output equality.

The unsafe arms intentionally conflate different failure mechanisms: destructive tentative eviction, metadata rollback without restoration of lost KV, and delayed accepted-only eviction. They are valid counterexamples to those strategies, not executable allegations about the supported author release. The pinned [R-KV serving documentation](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/docs/OPTIMIZATIONS.md) explicitly rejects speculative/multi-token decode before execution because compaction cannot be rolled back.

For width w <= cadence b, the uniform-phase calculation gives clipping frequency (w-1)/b and mean lost-slot fraction (w-1)/(2b). At 128/8 this is 7/128 and 7/256. The all-accepted aligned example counts 512 calls versus 4,096 serial calls, with equal query rows, attention terms, and scoring terms. These arithmetic claims check out.

They do not establish actual performance:

- Predetermined acceptance traces do not validate target/draft acceptance probabilities or speculative sampling.
- Uniform boundary phases are an illustrative model; repeated accepted blocks, rejection, and bonus scheduling correlate the phase process.
- Python snapshots copy state. The implementation deliberately excludes that cost from the abstract counters; it is not an efficient transaction implementation.
- No wall-clock, launch/queue overhead, kernel efficiency, multilayer scheduling, cache-copy peak, or serving integration was measured.
- The aligned 4,096-position arithmetic omits rejected work and separately forwarded bonus tokens, whereas the exact-state sweep accounts for tentative work under its own stated convention.

Thus the justified negative is “the simple exact baseline closes this semantic premise, with no demonstrated substantial cadence cost at 128/8,” not “safe speculative eviction is universally cheap.” The existing report already says this.

## B: physical storage, owners, metadata, and fair comparisons

### No uncounted persistent buffer found

The steady-state State object retains only arrays represented by its declared cache groups/read aliases. Following ndarray.base owners correctly counts disjoint views of one backing allocation once even when `np.shares_memory` between the views returns false. Construction's parent weak reference is non-owning. Compressed copies release the source; the full/shared and retained-parent controls intentionally keep it. Gather lists, union positions/page IDs, private suffix data, and suffix indices are real allocations and included.

The lifecycle and fresh destruction probes confirmed that no validation-only array or source reference survives inside the modeled State. Dense reconstruction arrays are distinct, live allocations. Their optional cost is charged explicitly rather than assumed necessary for every backend.

### Formula check

Write E=256, J=4, N=prefix tokens, m=requests, k=retained tokens/request, U=union cardinality, and s=32 private retained suffix tokens. Every control adds the same suffix term m*s*(E+J).

- Common prefix: k*(E+J)
- Private compaction: m*k*(E+J)
- Token union: U*(E+J) + m*k*J
- Packed union: ceil(U/P)*P*E + U*J + m*k*J
- Original-page union: t*P*E + t*J + m*k*J
- Active dense reconstructions: a*(k+s)*E for subset-reading representations

These match the actual allocations. A union beats directly consumed full sharing exactly when U*(E+J)+m*k*J+a*(k+s)*E < N*E. Against the direct full-prefix-with-subset-lists control, the shared m*k*J charge cancels. The report keeps these two comparators separate.

At equal k, token-union minus common storage is (U-k)*(E+J)+m*k*J >= 0. Private-compaction minus common storage is (m-1)*k*(E+J). The common-mask storage result is therefore a property of these representations, not an empirical discovery of equal-quality dominance. Sharing identical gather lists or specialized/compressed index encoding can narrow the metadata difference; neither is tested or needed for the current generic control.

### Important excluded bytes and timing effects

These are disclosed scope limits, not hidden omissions that overturn the result:

- Python/container overhead, engine block tables and reference counts, allocator reservation, device alignment, GPU workspace, and fragmentation outside the modeled page capacities are absent.
- Construction snapshots are selected lower bounds, not transition peaks. For example, packed-union building can transiently retain source, output pool, selection arrays, and a gather temporary. Reconstruction may also transiently hold gathered data in addition to its destination.
- Original-page layouts are represented with copied contiguous NumPy pools. They are not zero-copy page-alias implementations; original-page release and reference counting in a real engine remain untested.
- The retained-parent arm eagerly compacts children while keeping a full parent; it is not a page-level lazy copy-on-write allocator.
- Process RSS is reported separately and cannot be attributed to cache payload alone. No CPU timing is offered as GPU evidence.
- Per-layer/head versus globally shared mask metadata is explicitly separated in formula-only scaling; those larger architectures were not allocated.

The pinned [PolyKV value quantizer](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/turboquant.py), [pool counter](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/pool.py), [compressor](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/compress.py), and [agent](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/agents.py) support the source-derived accounting premise: int8 codes are charged nominally as 3-bit values, scale/norm storage is omitted by that counter, and a new dense DynamicCache is reconstructed. The NumPy fixture includes its declared scale/norm/codebook allocations and genuine packing. It does not reproduce the quantizer, model, device placement, or total live production footprint.

## Non-blocking reproducibility hardening

These do not change any result in the current files:

1. **A/C protocol enforcement:** several protocol fields are descriptive strings, while window, translation scales, lambda, budget, ring rule, phases, and work-count constants are hardcoded. They match now, but changing the JSON alone can silently leave execution unchanged. B has useful explicit guards for its fixed fixture. For future revisions, add equivalent A/C guards or make the numerical fields executable configuration.
2. **A/C source pins:** retained reproduction hashes cover outputs, not the local run scripts. This review records the current script/protocol hashes below. A future run manifest should pin source hashes directly.
3. **Counterexample overwrite behavior:** A/C retain the first counterexample file only if it does not already exist. The current files recompute and remain valid, but future protocol changes should use a new output directory or explicitly verify that preserved witnesses belong to the declared run.
4. **B verifier breadth:** `verify_outputs.py` checks the run manifest, original outputs, and selected two-run comparisons. The broader `deliverable_hashes.json` also covers post-analysis tables and the report but is not consumed by that verifier. All 45 entries passed an independent check here. Consuming the sidecar would strengthen the default one-command check.
5. **Predeclaration provenance:** present grids and declared priors are internally consistent with the retained results. The “written before execution” timestamps are the authors' records; this audit cannot independently establish historical ordering from file contents alone. Hashes establish content identity, not when a decision was made.

## Bottom line

Keep A/C rejected as new methods on these mechanisms. Keep B unpromoted because the tested storage controls are strong and a natural equal-quality frontier has not been established. Do not turn a lack of quality evidence into evidence of no quality value. No corrective rerun or model/GPU experiment is required by this audit.

## Commands rerun

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s research/diagnostics/candidate_elimination -p 'test_*.py' -v
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python research/diagnostics/shared_prefix_memory/test_screen.py
PYTHONDONTWRITEBYTECODE=1 python research/diagnostics/shared_prefix_memory/verify_outputs.py
```

## Fresh probe output and source pins

```json
{
  "retained_candidate_evidence": {
    "a_rows": 19200,
    "c_rows": 5440,
    "grid_complete_no_duplicate": true,
    "retained_artifact_hashes_match": {
      "a_results.json": true,
      "a_sweep.csv": true,
      "c_results.json": true,
      "c_sweep.csv": true,
      "c_work_counts.csv": true
    }
  },
  "independent_c_reference": {
    "cases": 130,
    "cadences": [
      3,
      7
    ],
    "all_exact_state_and_output_equal": true,
    "purpose": "robustness audit, not added scientific grid"
  },
  "independent_b_ownership": {
    "states": 39,
    "shape": {
      "N": 128,
      "m": 3,
      "k": 17
    },
    "formulas_roots_reads_reconstruction_release_pass": true,
    "purpose": "bounded implementation audit, not new sweep"
  },
  "retained_b_grid": {
    "rows": 56160,
    "configurations": 1440,
    "cardinalities_regenerated_without_allocating_cache_grid": true
  },
  "independent_a_fully_corrected_witnesses": {
    "witnesses": 2,
    "same_retained_set_and_dense_invariance": true
  },
  "source_hashes": {
    "candidate_elimination/run_a.py": "460f85b2463d7a4c499035f89db84bf2e0e937940c721a6156148fd85e679553",
    "candidate_elimination/run_c.py": "82abc88955b6cb11f3733654b6524997dcceec29df03303449e561860d5f573e",
    "candidate_elimination/protocol.json": "cd3f161bc9e4ffcd0495864c4e713b3015d5d905412ee76e143d02961aa47b2e",
    "shared_prefix_memory/screen.py": "b7a7aaf444f4ac9a0ba9113b628e7112e27bde22f9a97442b59802035ad3ebc2",
    "shared_prefix_memory/protocol.json": "61be388469909be2a3c16547268677610f6e057b55bb2175b59edc95f277ee5f"
  }
}
```

## Executed independent probe

The source below is the exact small audit script executed. Its R path names this checkout; adjust that path to reproduce elsewhere. This performs focused allocation/semantic probes and retained-data validation, not the full allocation sweep.

```python
import collections, copy, csv, hashlib, importlib.util, itertools, json, random, sys, weakref
from fractions import Fraction as F
from pathlib import Path
import numpy as np
R=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/research/diagnostics')
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p); m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
c=load('audited_c',R/'candidate_elimination/run_c.py')
s=load('audited_s',R/'shared_prefix_memory/screen.py')
result={}
# Complete retained grids/hash manifests: no numerical rerun or selection.
a_rows=list(csv.DictReader((R/'candidate_elimination/a_sweep.csv').open()))
c_rows=list(csv.DictReader((R/'candidate_elimination/c_sweep.csv').open()))
a_protocol=json.loads((R/'candidate_elimination/protocol.json').read_text())
hash_ok={k:hashlib.sha256((R/'candidate_elimination'/k).read_bytes()).hexdigest()==v for k,v in json.loads((R/'candidate_elimination/reproduction_expected.json').read_text()).items()}
assert all(hash_ok.values())
a_expected=set(itertools.product(range(10),[2,7],[16,64,128],[64,128],['gaussian','clustered'],['float64','float32'],[0.,.25,2.,8.,32.],a_protocol['A']['arms']))
a_keys=[(int(x['seed']),int(x['heads']),int(x['keys']),int(x['dimension']),x['distribution'],x['dtype'],float(x['shift_scale']),x['arm']) for x in a_rows]
assert len(a_keys)==len(set(a_keys)) and set(a_keys)==a_expected
counts=collections.Counter((x['dtype'],x['arm']) for x in a_rows if x['retained_set_changed']=='True')
expected_a={ (r['dtype'],r['arm']):r['changed_sets'] for r in json.loads((R/'candidate_elimination/a_results.json').read_text())['summary']}
assert all(counts[k]==v for k,v in expected_a.items())
c_expected=set((seed,b,ph,w,accepted,arm) for seed in range(4) for b in [2,8,128] for ph in (range(b) if b<128 else [0,119,120,121,122,123,124,125,126,127]) for w in [2,4,8] for accepted in range(w+1) for arm in a_protocol['C']['arms'][1:])
c_keys=[tuple(int(x[k]) for k in ['seed','cadence','phase','width','accepted'])+(x['arm'],) for x in c_rows]
assert len(c_keys)==len(set(c_keys)) and set(c_keys)==c_expected
result['retained_candidate_evidence']={'a_rows':len(a_rows),'c_rows':len(c_rows),'grid_complete_no_duplicate':True,'retained_artifact_hashes_match':hash_ok}
# Independently code serial recurrence and all canonical metadata fields.
def ref_step(st,t,b):
 q,k,v=t;pos=st['count'];st['entries'].append((pos,k,v));
 w=[F(2)**(q*e[1]) for e in st['entries']];z=sum(w)
 y=sum(x*e[2] for x,e in zip(w,st['entries']))/z
 st['ring']=(st['ring']+[(pos,q)])[-min(8,b):];st['count']+=1;st['qcount']+=1
 if st['count']%b==0 and len(st['entries'])>4:
  scores=[F(0) for e in st['entries']]
  for _,q0 in st['ring']:
   ww=[F(2)**(q0*e[1]) for e in st['entries']];zz=sum(ww)
   scores=[a+b0/zz for a,b0 in zip(scores,ww)]
  kept=sorted(sorted(range(len(scores)-1),key=lambda i:(-scores[i],st['entries'][i][0]))[:3]+[len(scores)-1])
  st['dropped']+=len(scores)-len(kept);st['entries']=[st['entries'][i] for i in kept];st['events']+=1
 return y
rng=random.Random(819)
checked=0
for cadence in [3,7]:
 for phase in range(cadence):
  st=dict(entries=[(-4+i,rng.randrange(-2,3),rng.randrange(-3,4)) for i in range(4)],count=0,qcount=0,ring=[],dropped=0,events=0)
  draw=lambda:tuple(rng.randrange(-2,3) for _ in range(2))+(rng.randrange(-3,4),)
  for _ in range(phase):ref_step(st,draw(),cadence)
  for width in [1,3,6]:
   toks=[draw() for _ in range(width)];bonus=draw()
   for accepted in range(width+1):
    ref=copy.deepcopy(st);outs=[ref_step(ref,t,cadence) for t in toks[:accepted]+[bonus]]
    initial=c.State(**copy.deepcopy(st));got,ys,_=c.evaluate(initial,toks,accepted,bonus,cadence,'boundary_capped_transactional')
    assert vars(got)==ref and ys==outs
    checked+=1
result['independent_c_reference']={'cases':checked,'cadences':[3,7],'all_exact_state_and_output_equal':True,'purpose':'robustness audit, not added scientific grid'}
# Recursively inventory state without depending on the declared grouping.
def walk(x):
 if isinstance(x,np.ndarray):yield x
 elif isinstance(x,dict):
  for v in x.values():yield from walk(v)
 elif isinstance(x,(list,tuple)):
  for v in x:yield from walk(v)
 elif isinstance(x,s.State):yield from walk(vars(x))
bstates=0
b_examples=[]
for family in ['identical','independent','clustered_shift']:
 masks=s.masks_for(128,3,17,family,'permuted',29)
 union=np.flatnonzero(masks.any(0));u=len(union)
 for method,page in s.methods():
  st=s.make_state(128,masks,method,page);s.validate_reads(st,masks,method)
  roots={}
  for a in walk(st):
   z=a
   while z.base is not None:
    assert isinstance(z.base,np.ndarray);z=z.base
   roots[id(z)]=z
  total=sum(x.nbytes for x in roots.values())
  if method=='shared_full':v=128*256
  elif method=='shared_full_subset':v=128*256+3*17*4
  elif method.startswith('common_'):v=17*260
  elif method in ['independent','cow_parent_retained']:v=3*17*260+(128*256 if method=='cow_parent_retained' else 0)
  elif method=='union_token':v=u*260+3*17*4
  elif method=='union_packed_pages':v=((u+page-1)//page)*page*256+(u+3*17)*4
  else:
   pages=len(set(int(x)//page for x in union));v=pages*page*256+(pages+3*17)*4
  assert total==v+3*32*260
  dense=s.reconstruct(st,3);assert all(not np.shares_memory(x,y) for x in dense for y in roots.values())
  assert sum(x.nbytes for x in dense)==3*((128 if method=='shared_full' else 17)+32)*256
  b_examples.append((family,method,page,total));bstates+=1
  refs=[weakref.ref(x) for x in roots.values()];parent=st.parent_ref
  del roots,st,dense,a,z
  assert all(ref() is None for ref in refs) and parent() is None
result['independent_b_ownership']={'states':bstates,'shape':{'N':128,'m':3,'k':17},'formulas_roots_reads_reconstruction_release_pass':True,'purpose':'bounded implementation audit, not new sweep'}
# Read all B rows, independently regenerate union/page cardinalities, audit case completeness.
b_rows=list(csv.DictReader((R/'shared_prefix_memory/results/allocations.csv').open()))
config={tuple(r[k] for k in ['N','concurrency','retention','seed','family','layout']) for r in b_rows}
byconfig=collections.Counter(tuple(r[k] for k in ['N','concurrency','retention','seed','family','layout']) for r in b_rows)
assert len(config)==1440 and set(byconfig.values())=={39}
regenerated={}
for n,m,ret,seed,fam,layout in config:
 mask=s.masks_for(int(n),int(m),int(int(n)*float(ret)),fam,layout,int(seed));ids=np.flatnonzero(mask.any(0))
 regenerated[(n,m,ret,seed,fam,layout)]=(len(ids),{p:len(set(int(x)//p for x in ids)) for p in [16,32,64]})
for r in b_rows:
 key=tuple(r[k] for k in ['N','concurrency','retention','seed','family','layout']);u,pages=regenerated[key]
 assert int(r['union_tokens'])==u
 if r['method']=='union_original_pages':assert int(r['pool_tokens'])==int(r['page_tokens'])*pages[int(r['page_tokens'])]
result['retained_b_grid']={'rows':len(b_rows),'configurations':len(config),'cardinalities_regenerated_without_allocating_cache_grid':True}
# A different summation/pooling implementation on the saved full-input witnesses.
a_checked=0
for name in ['rawmax_centered','softmaxfirst_uncentered']:
 ex=json.loads((R/'candidate_elimination'/f'a_counterexample_{name}.json').read_text())
 q,k=np.array(ex['queries']),np.array(ex['keys']);translation=np.array(ex['translation']);v=np.array(ex['values'])
 def sm(x):
  x=x-np.max(x,axis=-1,keepdims=True);e=np.exp(x);return e/np.sum(e,axis=-1,keepdims=True)
 scores=[];sets=[];dense=[]
 for shifted in [k,k+translation]:
  logits=(q@shifted.T)/np.sqrt(q.shape[-1]);probs=sm(logits[...,:-8]);important=np.mean(np.max(probs,axis=0),axis=0)
  pooled=np.array([np.max(important[max(0,i-3):min(len(important),i+4)]) for i in range(len(important))])
  z=shifted-shifted.mean(0);norm=np.sqrt(np.sum(z*z,axis=-1));z=z/(norm[:,None]+1e-8)
  sim=z@z.T;np.fill_diagonal(sim,0)
  for i in range(len(sim)):
   candidates=np.flatnonzero(sim[i]>.5);sim[i,candidates[-1] if len(candidates) else 0]=0
  score=.1*pooled-.9*sm(np.sum(sim,axis=0)/len(sim))[:-8]
  scores.append(score);sets.append(sorted(sorted(range(len(score)),key=lambda i:(-score[i],i))[:ex['row']['budget']-8]+list(range(len(score),len(k)))))
  dense.append(sm(logits[:,-1])@v)
 assert sets[0]==sets[1];assert np.max(np.abs(dense[0]-dense[1]))<1e-11
 a_checked+=1
result['independent_a_fully_corrected_witnesses']={'witnesses':a_checked,'same_retained_set_and_dense_invariance':True}
result['source_hashes']={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'candidate_elimination/run_a.py',R/'candidate_elimination/run_c.py',R/'candidate_elimination/protocol.json',R/'shared_prefix_memory/screen.py',R/'shared_prefix_memory/protocol.json']}
print(json.dumps(result,indent=2))
```
