# Calibration-transfer novelty boundary and pre-spend audit

Date: 2026-10-03 UTC. Search window: 2024-10-03 through 2026-10-03, with older foundations identified separately. Evidence: primary papers, author-linked repositories, fresh public GitHub reads, and the current local implementation. No GPU run, checkpoint download, installation, payment, code edit, commit, or remote write was made for this audit.

## Decision

**No substantive new compression method has been established.** Reconstruction scoring, training-free virtual reconstruction, per-request quantile calibration, layer/head score-scale correction, calibration-data selection, and recent-token protection are already occupied. First/random/uniform microchunk selection is an appropriate baseline family; changing these policies alone is a weak, unsurprising extension.

There is a narrow, potentially useful **empirical diagnostic gap**: test whether a single per-layer/head calibration map transfers across positions in a reusable, question-blind cache, and whether downstream damage comes from between-region allocation rather than within-region ranking. I did not find a primary source carrying out this exact, budget-matched, downstream intervention. That negative search result is not proof of novelty, and the question sits immediately beside EchoPress's existing analyses.

**The frozen eight-arm development screen cannot establish that regional mechanism.** It can detect integration failures and suggest or fail to suggest a score-transform effect. A minimal, predeclared pooled-full-context-map diagnostic is needed before interpreting a regional scale oracle as evidence of regional nonstationarity. It does not require a new candidate policy. Additional prerequisites for a substantive finding are below.

If the project requires a clearly novel *method* before any experimental spend, the current direction does not pass that requirement. A small falsification study is defensible only as research-risk reduction, without a promised positive or publishable result.

## 1. Closest work and exact claim overlap

Dates below are first submission and, where relevant, the inspected revision. Reported performance is author evidence, not reproduced evidence.

| Primary source and date | Already established | Boundary for this project |
|---|---|---|
| [EchoPress v1](https://arxiv.org/html/2610.00412v1), [submitted 2026-09-30](https://arxiv.org/abs/2610.00412) | Section 2.3 corrects layer/head scale using first-chunk empirical quantile maps. Section 3.4 measures within-head rank agreement. Appendix C compares first/later within-chunk ranks and controls preceding-context availability; it explicitly does not establish the optimal calibration chunk | The broad scale-versus-rank motivation is already present. What remains unverified is a downstream intervention isolating **regional transfer** and its practical importance. A new anchor location is not a new scoring principle |
| [KVzip v2](https://arxiv.org/html/2505.23416v2), 2025-05-29; revised 2025-09-30 | Context reconstruction supplies question-independent scores, reusable caches, and nonuniform head allocation; Appendix B.3 compares uniform/nonuniform head budgets | Neither query-blind reuse nor reconstruction-derived importance is new. Its scores are a useful reference, not downstream importance ground truth |
| [Compactor v2](https://arxiv.org/html/2507.08143v2), 2025-07-10; revised 2025-12-08 | Standardizes leverage and attention scores before blending; calibrates retention against context NLL/quality using an offline fitted curve. The revision includes a serving implementation | Different calibration target: context compressibility, not sparse regional virtual-to-exact transport. Nonetheless, “calibrated query-agnostic compression” and calibrated budget allocation are not empty territory |
| [Expected Attention](https://arxiv.org/html/2510.00636v1), 2025-10-01 | Approximates future-query attention distribution with prefill statistics and accounts for value/output contribution | Low-cost, training-free comparator. “Use distribution statistics without the future question” is not a novel claim |
| [G-KV v1](https://arxiv.org/html/2512.00504v1), 2025-11-29 | Section 5 and Appendix D normalize local scores before combining windows, explicitly addressing score dilution as sequence length changes | Different setting: decode-time observed queries and historical scores. It blocks generic claims about fixing cross-window scale inconsistency, but does not supply the proposed reconstruction-transfer intervention |
| [KVzap v2](https://arxiv.org/html/2601.07891v2), 2026-01-12; revised 2026-02-03 | Learns hidden-state predictors of normalized KVzip+ scores; threshold-based deployment includes a 128-token recent window. Appendix A discusses short-training-context shift. On its Qwen3-8B LCC ablation, removing the window reduces accuracy from 62.51 to 28.37 | A code-task gain must survive matched recency and strong released scorers. Plain KVzip targets and KVzip+ are different; raw score agreement is not a fair method-quality comparison |
| [Fast KVzip v2](https://arxiv.org/html/2601.17668v2), 2026-01-25; revised 2026-02-09 | Reconstruction-trained lightweight gates support prefill and decode eviction | A further construction-cost reduction or reconstruction surrogate is occupied. A fixed-budget full-prefill adaptation must be labeled as such, with protected recent tokens and checkpoint cost included |
| [BACON v3](https://arxiv.org/html/2606.14782v3), 2026-06-10; revised 2026-08-23 | Section 4.4 variance-matches structurally filtered boundary evidence to observation-window scores before retention | Score calibration across heads/layers and local evidence is established. It is a query/window-based multimodal mechanism, not question-blind regional reconstruction transport |
| [Query-visibility matched-budget audit](https://arxiv.org/html/2607.11942v1), 2026-07-11 | Paired protocol comparisons include random, key-norm and start-plus-recent controls; query-blind evaluation by itself does not ensure superiority | A matched-budget audit is not automatically a new contribution. The new scientific question must be identified separately from good experimental hygiene |
| [S4R v1](https://arxiv.org/html/2608.00528v1), 2026-08-01 | Builds prompt-specific low-rank bases from sampled positions. Section 3.1.2 and Appendix D.3 combine recent tokens with uniform earlier samples and compare ratios at a fixed total sample count | Newly checked adjacent prior: representative within-prompt sampling with fixed budget is already used in KV compression. Different target and decode mechanism, so not an exact duplicate; it further weakens a novelty claim based only on coverage |
| [Risk-Controlled KV-Cache Eviction v1](https://arxiv.org/html/2609.27981v1), 2026-09-23 | Post-hoc calibration certifies retention policies against a material-degradation risk target, with full-KV fallback | Distinguish score calibration from risk calibration. Do not expand this project into an unsupported “safe adaptive compression” claim |

An in-window broader precedent, [Is C4 Dataset Optimal for Pruning?](https://aclanthology.org/2024.emnlp-main.1004/) (arXiv 2024-10-09; EMNLP November 2024), studies the effect of calibration-data choice on weight pruning. It is not a KV-cache method, but confirms that “the calibration sample matters” is an established research question rather than a sufficient novelty claim. StreamingLLM is an earlier foundation; its sink-plus-recent behavior is relevant through the current KVzap code and query-visibility audit.

### Fresh immutable code verification

These are reproducibility pins, not evidence that the methods ran successfully here. Branch heads were resolved again on 2026-10-03. Primary descriptions above come from the papers unless a code behavior is explicitly named.

- EchoPress author branch remains [39748e9c8301944128eb2e681bfb074e9a2de860](https://github.com/ljwljwljwljw/kvpress/commit/39748e9c8301944128eb2e681bfb074e9a2de860), committed 2026-10-02 08:43:14 UTC, parent `327ed6f316cfadcff37a3e644a817f9ff58b8848`. Its commit author timestamp is 2026-09-11; that is not the public-paper submission date
- [Exact EchoPress implementation](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/echo_press.py): `_quantile_map` independently sorts source/target marginals, interpolates with left searchsorted and endpoint clipping; `_finalize` reconstructs the first chunk and `_apply_per_sample_calibration` maps later chunks. The inspected source has no equal-budget first/random/uniform anchor-policy comparison
- NVIDIA KVPress main remains [327ed6f316cfadcff37a3e644a817f9ff58b8848](https://github.com/NVIDIA/kvpress/commit/327ed6f316cfadcff37a3e644a817f9ff58b8848), committed 2026-10-01. Relevant pinned files: [KVzap](https://github.com/NVIDIA/kvpress/blob/327ed6f316cfadcff37a3e644a817f9ff58b8848/kvpress/presses/kvzap_press.py), [DMS wrapper](https://github.com/NVIDIA/kvpress/blob/327ed6f316cfadcff37a3e644a817f9ff58b8848/kvpress/presses/dms_press.py), [Fast KVzip](https://github.com/NVIDIA/kvpress/blob/327ed6f316cfadcff37a3e644a817f9ff58b8848/kvpress/presses/fastkvzip_press.py), [Expected Attention](https://github.com/NVIDIA/kvpress/blob/327ed6f316cfadcff37a3e644a817f9ff58b8848/kvpress/presses/expected_attention_press.py). Code confirms the KVzap scorer plus separate threshold/recency wrapper; scorer-only top-k is a different policy
- EchoPress's paper-reported original KVzip abbreviation `5d84729` resolves to [5d8472975d286e3da6b52178af39d18904330c0d](https://github.com/snu-mllab/KVzip/commit/5d8472975d286e3da6b52178af39d18904330c0d), committed 2026-02-11. This resolution was verified; that tree was not installed
- Compactor author repository main: [8bbac3a22f09e06633dc691dca5167b8e131ae4f](https://github.com/vnchari/compactor-vllm/commit/8bbac3a22f09e06633dc691dca5167b8e131ae4f), committed 2025-12-03. Repository identity/head verified, serving code not fully audited here. The KVPress port is not automatically paper-identical
- BACON's [author-linked repository](https://ryu1ion.github.io/official_BACON/) resolves to [1f9a876c98319acf922122ea367c7ec1c072ab72](https://github.com/ryu1ion/official_BACON/commit/1f9a876c98319acf922122ea367c7ec1c072ab72), committed 2026-10-02. G-KV's author repository resolves to [6db3b2ee0846dea897c9afa9247d19f860491b49](https://github.com/microsoft/G-KV/commit/6db3b2ee0846dea897c9afa9247d19f860491b49), committed 2026-03-13. Heads verified, full implementations not audited
- No author implementation for S4R or the risk-control paper was verified in this pass. The paper evidence is sufficient for the limited overlap statement; do not invent a code pin

## 2. Claim matrix

| Proposed claim | Current disposition | What could support a narrower claim |
|---|---|---|
| First training-free reconstruction-score calibration for reusable KV | Rejected; direct EchoPress overlap | None by relabeling |
| First separation of score scale and ranking in this setting | Rejected as broad wording; EchoPress already analyzes both | A specific downstream, histogram-controlled regional intervention may be distinct |
| Uniform/stratified anchors are a novel compression method | Not substantiated; ordinary sampling plus an existing mapper, adjacent S4R prior | At most a documented robustness fix unless a consequential non-obvious finding emerges |
| A pooled multi-anchor gain proves regional transport correction | False implication | Separate exact replacement, global map estimation, and region-dependent transport |
| A regional exact-map gain proves content heterogeneity is the cause | False implication | A pooled-full map control, tie checks, and separate position/content controls on natural data |
| Full-exact scores are a downstream quality upper bound | False | Treat as a reference; evaluate all interventions against full KV as well |
| Better score correlation or reference-mask recall proves useful compression | False | Held-out downstream paired quality at matched logical/physical budget and measured build cost |
| Current three-context screen proves a general failure or absence of failure | False | Replicated, adequately varied independent contexts; second architecture before generality |
| A useful diagnostic study of failure conditions could be new | Possible, unproven | Nontrivial regional effect surviving obvious controls and yielding a reusable explanatory result |

## 3. What the implemented screen actually identifies

Inspected local source at HEAD `c96b250f40fb484077a7761c338e49300189f529` before adding this report: `research/calibration_methods/{methods,diagnostics,selection}.py`, `echo_pilot/calibration_experiment.py`, and the experiment/audit documents.

The frozen recipe has two LCC contexts and one RepoBench-P context, one Qwen3-8B revision, one seed, 50% eviction, four 496-body-token exact anchors plus 16 prompt/suffix tokens each, a common partition, and no recent-token protection. “Region” currently means one positional microchunk, **not a semantic code/prose/document class**. First/random/uniform candidates all use a pooled map per layer/head and overwrite their selected anchors with exact scores. The separate full diagnostic supplies every microchunk's exact scores.

### Three identification limits

1. **Pooled-map order limitation.** For a fixed layer/head and two nonanchor values `v_i < v_j`, every pooled monotone map retains `M(v_i) <= M(v_j)`. Changing pooled anchors cannot fix a strict between-region inversion within that layer/head. It can change competition between heads, clipping/tie patterns, and which positions receive exact replacements. Any first-versus-uniform quality difference combines those effects. This is a mathematical consequence of the implemented transform, not a literature claim
2. **Regional oracle versus baseline is insufficient.** The regional scale oracle changes both the amount/location of exact calibration information and whether the map is region dependent. A gain can arise from a better global map estimate rather than regional nonstationarity. Conversely, a failure on three contexts cannot establish that transport always works. The eight arms lack the necessary pooled-full-information comparison
3. **Not an additive scale/rank decomposition.** The rank oracle permutes the baseline regional score multiset; the scale oracle changes those marginals while retaining virtual weak order. Top-k selection and generation are nonlinear. Their separate deltas need not sum to the full-exact delta; joint rank/scale effects can exist. Do not label a quality fraction as “the percentage explained by calibration” without a defined, stable contrast

The implementation correctly excludes anchors, prefix and protected positions **before** the oracle transformations. Preserve that behavior. A sparse arm's exact anchors are paid observations, not free labels. Diagnostic-only full reconstruction is separately charged and is not a deployable build-time result.

## 4. Minimal predeclared control: pooled full-context marginal map

This is a specification for a **new versioned diagnostic arm**, not a request to add a complex policy. No code is changed here. Because the parent reports no GPU results yet, it can be declared before observing outcomes. Do not silently change the existing `echo_calibration_experiment_v1` plan or reuse its source/plan identity.

### Inputs and invariant construction

For each layer/head, use exactly the same captured virtual vector `v`, same complete exact diagnostic vector `e`, and the same first-anchor baseline scores `b` already used by the regional oracle. Freeze:

- The identical context, microchunk boundaries, original-key softmax denominators, replay prompt/suffix token IDs, RoPE offsets, full-cache conditioning, precision path, and backend. Full-context *pooling of scalar labels* must not change scoring to a single long reconstruction
- Fixed set `F = prefix ∪ first-anchor positions ∪ sink positions ∪ recent positions`. The current recipe has recent=0; any later recency setting must be declared and common to every compared arm, deducted from the same total budget
- Mutable set `U = all positions outside F`. Set `U_r = U ∩ region r`. Remove fixed positions before fitting either map, not after

New pooled diagnostic `P`:

1. Initialize `P = b`
2. For each layer/head, fit `M_pool_full` by independently sorting `v[U]` and `e[U]`, with the same declared quantile-map/tie/cast semantics as the regional diagnostic
3. Set `P[U] = M_pool_full(v[U])`; leave `P[F] = b[F]`

Existing regional diagnostic `R` does the same separately on each `U_r`. Both use the already paid full exact captures, the same independent dense-cache clone convention, selection budget, mask installation and question generation. The new arm adds one downstream mask/generation per question plus transform/serialization work; it needs no additional prefill or exact reconstruction. Its analysis and accounting must still be versioned and validated.

### Required checks and what they mean

- Check `P[F] == R[F] == b[F]`, identical protection sets, exact total retained count, finite scores, and agreement of sparse exact anchors with full exact captures
- Check monotonicity within every mutable region for both P and R. The pooled transform should also be monotone over the entire mutable set within each layer/head
- Record duplicate source knots, exact and output ties, clipping, cutoff multiplicity, mutable-region size, and per-layer/head/region allocations. Any precision change is shared, never candidate-only
- **Strong attribution invariant:** compare sorted `P[U]`, sorted `R[U]`, and the consistently output-cast sorted target `e[U]` per layer/head. In ideal arithmetic with distinct source knots, evaluating empirical maps at their own knots transports the same exact score multiset in both arms. The implementation's `1e-12` denominator floor and floating-point operations mean even distinct knots do not automatically guarantee exact equality; check the actual outputs. When the invariant holds, global layer/head budgets coincide absent cutoff ties; their difference changes between-region allocation while retaining within-region order
- **Duplicates are a genuine identifiability limit.** Author-left quantile interpolation may collapse targets at repeated source knots, so the invariant above is not automatic. Float32 capture can reduce but does not guarantee elimination of ties. A deterministic score-only monotone function cannot give unequal outputs to equal inputs. Never silently split virtual ties by exact ranks: that imports rank information into a purported scale-only oracle
- If sorted-multiset equality fails, or cutoff ties permit different head allocations, explicitly mark the pure regional contrast as confounded. Report the existing tie-allocation bounds and predeclared tie sensitivities; do not claim a clean regional effect from that cell. A different tie-aware construction would need its own declared semantics and validation

Even a clean `quality(R) > quality(P)` is an **oracle intervention** showing useful region-dependent allocation under the chosen score target and partition. It does not by itself prove content statistics caused it, that four anchors can estimate the needed maps, or that a deployable conditional mapper is worth its cost.

## 5. Evidence that kills or sharply narrows the idea

| Observation | Correct decision |
|---|---|
| No material full-KV/author-EchoPress quality gap on intended natural workloads | No demonstrated practical headroom. Stop expansion on that workload; avoid inventing hostile-only mixtures to rescue the idea |
| Pooled-full and regional-full diagnostics perform alike, despite sufficient quality headroom and clean tie invariants | No evidence that **regional** maps are needed; investigate only ordinary sample-size/global-map estimation if warranted |
| Regional scale repair does not help but rank-only/full-exact does | Against a scale-only remedy in these tested conditions. Do not build region-conditioned calibration merely because regional histograms differ |
| Neither individual repair helps but full-exact does | Possible interaction or inadequacy of the intervention definitions; not evidence for a scale-first method |
| Uniform/random improvement vanishes when exact replacements are held fixed | Improvement is exact-score placement, not transferable calibration. The crossed same-map/same-replacement controls in the earlier audit are necessary before a mechanism claim |
| Improvement disappears with common float32 capture or tie handling | Numerical/selection issue rather than established content-conditioned transfer failure |
| Improvement disappears under same-partition no-calibration or common-partition full-exact controls | Rechunking/score-definition effect. Do not attribute it to choosing anchors |
| Matched sink-plus-recent or a simple recent-window addition closes the gap | Reject a complex calibration method claim. Especially important for LCC/RepoBench; recent protection is a mandatory next explanation before broader spending |
| Uniform coverage matches a conditional/adaptive candidate | Reject the adaptive-method claim. A small robustness contribution may remain; no need to manufacture a more complex rule |
| Released KVzap/Fast KVzip or training-free Expected Attention dominates quality/build cost under fair constraints | Calibration may remain an explanatory study, but no demonstrated deployment case |
| The effect is confined to one small development subset, one seed, one partition or one model | No generality claim. The current screen is especially weak statistically: two LCC clusters and one RepoBench cluster |

The earlier project's 1-point headroom, 2-point held-out benefit and regression limits are project decision thresholds, not universally sufficient significance or novelty criteria. Do not apply them as conclusive tests on three development contexts. A score reference can underperform another mask on downstream quality; therefore “recovery toward KVzip” must be reported alongside raw deltas and full-KV quality, without assuming a positive denominator or an upper bound.

## 6. What would count as a substantive surviving finding?

The strongest honest outcome would be an empirically established condition under which a reusable score map is non-transferable, demonstrated by the pooled-versus-regional downstream intervention, with exact replacement/recency/tie/partition alternatives excluded. It should connect observed threshold-crossing allocation mistakes to task outcomes on independent natural contexts, then show whether the cheapest existing calibration coverage rule is enough. A negative result showing that rank error or ordinary recency explains the apparent failure is also useful to this project.

A region-conditioned mapper, shrinkage coefficient, diversity sampler, or transport-distance trigger is **not justified yet**. The fixed-position screen does not establish meaningful semantic regions or predict which unseen regions need different maps. Forcing regional histograms equal would erase genuine importance differences. No such policy should be presented as the novel contribution in advance of evidence.

Finally, this harness uses logical eviction masks on dense KV storage. It cannot establish physical memory savings, serving throughput, or end-to-end latency superiority. Those claims require an independently validated compaction/backend path after the scientific question survives.

## Search and verification limitations

Searches included calibration, quantile/quantile matching, score normalization, cross-window scale, stratified/uniform anchor sampling, distribution transfer/shift, reconstruction scoring and recent-token controls. Searches spanned the two-year window and followed author-linked code; current source reads included EchoPress, KVzip, KVzap/Fast KVzip and nearby calibration work. Aggregators/social posts were not used as evidence. Exact sources and versions are linked above; dated arXiv pages take precedence over identifier-month or search-index relative dates.

This is a focused audit, not an exhaustive citation census, formal priority determination, or proof that no matching unpublished/recently unindexed work exists. No broad “first” claim is cleared. The search found substantial conceptual overlap and only a conditional diagnostic gap.

### Local inspection fingerprint

SHA-256 at inspection time, before this report:

- `research/calibration_methods/methods.py`: `95d0daf1892ef9d72985380b50c4d2f1d6e6bc55648d7f5e9a44263c98789328`
- `research/calibration_methods/diagnostics.py`: `7fc6751bdf88feebeb18c1542db9372e00b89e67a626dfcf7bb827718e34367b`
- `echo_pilot/calibration_experiment.py`: `812b130f265a0c17df69b054ecccad9456ef5db5f8ab313d5a7c82d9f467323f`
- `research/calibration_experiment.md`: `c42b98d80d10c8893e81e9b0101b1fc956bc28123ec96e5ecfac0aac64366d2f`

The earlier `narrow_alternatives.md` note that the EchoPress author branch could not be fetched is superseded by the successful pinned source audit and this fresh verification. Its suggested 4×512-body-token example is also superseded by actual prompt-counted 4×496-body-token planning. Preserve those older documents as history rather than using their stale availability/budget statements as current facts.
