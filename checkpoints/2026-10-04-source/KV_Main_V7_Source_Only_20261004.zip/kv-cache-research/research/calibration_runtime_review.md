# Independent calibration runtime review

Date: 2026-10-03. Scope: `echo_pilot/calibration_runtime.py`, `research/calibration_methods/`, their tests, and their interaction with the pinned EchoPress/KVzip source. This is an independent source/CPU-contract review, **not native Torch, Transformers, GPU, model, or tokenizer verification**. No weights were downloaded, no dependencies installed, no paid compute used, and no remote state was written.

## Verdict

The reviewed design maintains the intended context-only replay boundary, charges sparse anchors separately from full-label diagnostics, preserves a common original-key scoring partition, and installs the already selected logical mask rather than invoking author selection again. One concrete exception-isolation defect was found, reproduced, reported to the adapter author, and fixed. Independent adversarial probes pass after the fix.

A native single-device, evaluation-mode, dense Qwen3/Llama smoke remains a release gate before any scientific or runtime claim. The CPU tests are useful evidence of software contracts; they cannot establish native numerical or model compatibility.

## Finding fixed during this review

### Mixed per-layer masks after a mask-allocation failure

Initially, `install_keep_mask()` cloned each layer's coordinate tensors as that layer's mask was installed. A failure on the fourth int64 clone (the first coordinate of layer 2) left layer 1 on the new mask and layer 2 on its old mask. The candidate builder reported `failed_after_scoring`, but the model retained that mixed state. `answer_candidate()` also cloned/installed its query cache before entering its cleanup `try/finally`, so the same failure escaped cleanup. The private failed build's cache remained populated.

Reproduction used the existing NumPy-backed `Tensor` shim with only `Tensor.clone` patched to throw on the fourth int64 clone. Before the fix, mask identity preservation was `[False, True]` and the failed cache retained both 19-token layers. This is a realistic control-flow analogue of a device allocation failure, **not an actual CUDA OOM test**.

The author changed installation to allocate/clone all triples before mutation, roll back mask attributes if assignment fails, move query setup inside its cleanup scope, and clear private failed/query cache references. The independent regression verifies transactional build failure, clean query failure, and unchanged frozen candidate cache values. Additional preflight guards now reject training mode, explicit multi-device device maps, and enabled single-knot calibration with remaining unanchored body tokens before forwards. Dropping these references is not proof that all GPU allocations are immediately released: retained exception tracebacks, Torch's allocator, and other tensor references require native observation.

## Source and runtime compatibility checks

### Source identity and inherited operations

All 14 files in `research/sources/echopress_39748e9/provenance.json` were independently rehashed. Their SHA-256 and Git blob SHA-1 values match the recorded pin. The relevant author revision is `39748e9c8301944128eb2e681bfb074e9a2de860`.

The adapter's source flow is consistent with that source:

- Prefill installs projected-query capture and the inherited Echo `_prefill_hook`, retaining every fixed microchunk in `_chunks`
- Exact scoring uses inherited KVzip `forward_hook`, `score_kvzip`, and `_compute_cross_attention`; scalar capture occurs before assignment into `score_val`
- Sparse replays set both `start_idx` and `end_idx` from the selected original chunk, rather than advancing through selected chunks as if they were contiguous
- Explicit replay positions start at the full original context length for every independent replay; the virtual shift is `context_length + prompt_tokens - chunk.start`
- Prefill query hooks are removed before exact scoring recomputes projected queries, avoiding accidental capture of that second projection
- The inherited hook returns original-context K/V slices after each replay; every layer's sequence length and layout are checked
- `compress_post()` is deliberately disabled, so the stable selected mask is not silently replaced by the author's two-stage `topk`

Primary author sources: [EchoPress](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/echo_press.py), [KVzip](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/kvzip_press.py), [query-state helper](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/utils.py), [masking patch](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/attention_patch.py).

### Transformers 5.2.0 static cross-check

The official versioned [dense-cache source](https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/cache_utils.py) uses `torch.cat` to replace ordinary DynamicLayer keys/values; sequence length derives from the key shape. This supports the adapter's shallow reference/metadata rollback for the explicitly created dense DynamicCache. It would not justify that rollback for static in-place, quantized, offloaded, or sliding caches.

The versioned [Qwen3](https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/qwen3/modeling_qwen3.py) and [Llama](https://github.com/huggingface/transformers/blob/v5.2.0/src/transformers/models/llama/modeling_llama.py) code passes attention hidden states, position embeddings, and cache through keyword arguments compatible with the inherited hooks. Both derive omitted cache positions from current cache length. The explicit replay position IDs therefore agree with the dense-cache offset after successful truncation.

These are static compatibility observations, not an import or execution of those packages. Torch and Transformers are absent in this environment. The proposed dependency profile is still not an installed, fully resolved compatibility lock here.

## Causal-control audit

### What is held fixed correctly

- Plans bind actual immutable context/instruction/suffix/replay IDs, context hash, tokenizer declaration, template hash, source pin, and complete chunk bounds
- The builder accepts `PreparedContext` and frozen anchor/replay plans; there is no question, gold-answer, downstream-outcome, or full-exact-diagnostic argument
- First/random/uniform planning reads the frozen partition rather than scores; seeds and equal-shape eligibility are explicit
- An unequal short tail is scored but excluded by the standard equal-shape planner; reconstruction caps include every instruction and suffix token on every pass
- All anchor policies use the same complete original-key chunk denominator. Selected anchors do not redefine virtual chunk boundaries
- Full exact diagnostics rerun every chunk independently, including the tail, and are explicitly marked diagnostic/nondeployable in their accounting
- Pooled calibration gets only selected anchor labels; non-anchor exact counterfactuals cannot change it through its interface
- Sink/recent protection consumes the same retained-pair total. Coordinate conversion preserves the exact boolean mask. Query caches are independent because the upstream mask patch overwrites keys in place
- Scale/rank oracles exclude fixed anchors, prefix, and protection before transformation. The rank-only oracle preserves the exact baseline regional score multiset; tie-induced allocation changes are exposed rather than attributed silently

These contracts do not prove that a caller supplied honest provenance or froze a plan before looking at outcomes. They are not a security boundary against deliberately slicing full diagnostics into an anchor object.

### Interpretations that must remain explicit

1. **Original-key denominator equality is not full attention-denominator equality.** The virtual score omits prompt query/key rows and uses a causal virtual copy of the chunk. The exact score includes instruction/suffix/repeated-token query rows and causal repeated prompt/chunk keys. Exact hidden states attend the whole original cache, even though the diagnostic score later restricts original columns. This difference is inherited and documented; do not describe virtual and exact as identical normalized attention targets.
2. **The common prompt is a policy adaptation.** Reusing “Repeat the previous context exactly” for a middle fragment gives equal token construction, but does not guarantee equal semantic difficulty across positions. The first fragment has a special relationship to that instruction. Keep author first-chunk EchoPress separate, and avoid interpreting an anchor-location effect alone as evidence for regional calibration transfer.
3. **Float32 containers do not recover native precision.** Virtual scalar outputs are captured before storage. Exact weights/maxima already have native softmax/QK precision before capture; on BF16 models, casting them to NumPy float32 cannot recover information. `Precision()` is a storage/control setting, not full-FP32 exact inference.
4. **Tie handling is intentionally adapted.** The author-left quantile behavior, including duplicate maximum knots, is retained; duplicate-mean interpolation is a named ablation. Stable/reverse/random logical tie rules are not author two-stage `torch.topk` parity. Cutoff ties and region-allocation bounds remain necessary for interpretation.
5. **Matched token/shape/pair proxies are not measured matched compute.** Exact scoring also projects queries and materializes attention for scoring; setup, capture, clone, synchronization, and failure costs matter. Reported host wall time explicitly lacks CUDA synchronization and must not be treated as deployable GPU latency.
6. **No physical compression is implemented.** Logical masks do not shrink dense cache tensors, and slices may retain larger replay backing storage. Per-query deep copies incur additional storage/cost. No memory-saving claim follows from this adapter.

## Verification performed

Final reviewed adapter SHA-256: `4db332489adcb0cd5f72aec0fd3b50154272750a2f0fbe18547dbcb7b537ecda`.

- Full `echo_pilot/tests` CPU suite: 135 tests passed on the final reviewed revision, including 14 dedicated adapter tests
- `research/calibration_methods/tests`: 41 tests passed
- `research/diagnostics/echo_calibration`: 29 tests passed
- Fresh `research.calibration_methods.synthetic_smoke` JSON exactly matches the stored synthetic artifact
- `compileall` passed for the adapter and method package
- Four independent reviewer probes passed:
  - Transactional candidate mask failure and owned-cache cleanup
  - Query setup failure leaves no partial masks and preserves candidate KV values
  - Inherited virtual scorer matches an explicit NumPy attention formula with nonzero RoPE phase, several chunk offsets, and varying sink counts
  - Sparse/full label equality and virtual-score identity across prefix/sink/tail variants and first/random/uniform plans; recorded replay tokens equal the plan ledger

The independent probe file and logs were kept under `/tmp` during review; they are supplemental to the committed test suite, not an installed runtime.

## Remaining native gate

Before model results or deployable-cost claims, run a small authorized test using the exact resolved dependency/model/tokenizer pins and preserve failures as charged attempts. It must exercise native Qwen3 query normalization, nonzero rotary positions and dtype casts, real SDPA mask mutation, GQA grouping, device placement, cache cloning/truncation, repeated queries, and native exception cleanup. Compare sparse exact anchors with the separately charged full diagnostic under a predetermined tolerance and verify logical counts/protection. Measure synchronized build/query times and allocated/reserved/backing-storage bytes separately.

Keep train-mode, multi-device/offload, scaled/dynamic RoPE, quantized/sliding/static caches, and unsupported model families out of scope unless separately implemented and tested. A successful source/mock review is not permission to broaden that scope.
