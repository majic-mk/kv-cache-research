# Independent review: pretrained CPU competence probe

Review date: 2026-10-03 UTC. Scope: the existing frozen v1/v2 protocol, pretrained CPU execution, input/weight/score provenance, and stopping decision. **No new model instance, forward, task case, prompt variant, GPU work, download, or scientific protocol change was performed for this review.** Model-free retokenization, configuration inspection, hashing, arithmetic, and protocol tests were rerun.

## Decision

**Accept the bounded result: this checkpoint/prompt protocol failed its first predeclared full-recompute competence cell, and the probe correctly stopped. No material loading, tokenization, gold-mapping, or scoring defect was found in the audited path.**

- `d01 / A1 / full_recompute` is the only completed cell. It returned `blue<|im_end|>` when the frozen answer is `red`
- All other 15 planned cells are explicitly `not_run_competence`; exact-prefix completed cells = 0
- Exact-cache parity is **not evaluated**, not failed. The original `parity_gate_pass=false` boolean means its pass condition was never established; the final report correctly makes this distinction explicit
- No HYPIC, compressed/reused cache, chunked, donor, oracle, or held-out model cell ran. There is no compression-harm, cache-parity, general model-accuracy, or broad research-direction conclusion
- Stopping now is supported by the protocol. Rescuing this result through another prompt, another model, or a larger matrix would be a new experiment, not completion of this one

This is a negative outcome for a narrowly defined competence gate, leaving the proposed reuse-quality comparison uninformative. One error is sufficient for this gate because both selected changed-prefix pairs and all four unrelated controls were required correct. It is not sufficient to diagnose general inability at role lookup or refute the recurrent-conditioning hypothesis.

## 1. Correct pinned checkpoint and text-model load

The local shard was independently streamed through SHA-256, rather than trusting the reported checksum:

- Model: `Qwen/Qwen3.5-0.8B`
- Immutable revision: `2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`
- Shard size: **1,746,942,600 bytes**
- SHA-256: `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`, equal to the recorded official LFS checksum

The safetensors header and index have identical sets of 488 tensor names. Of these, exactly **320** are under `model.language_model`; their shape products sum to **752,393,024 parameters**, exactly matching the execution summary. The remaining branches are 153 visual tensors and 15 MTP tensors. The text tensors in the checkpoint comprise 284 BF16 and 36 FP32 tensors; the runner explicitly loads all text-model parameters into FP32, rather than claiming the source file itself is entirely FP32.

This checkpoint's top-level architecture is multimodal, but the chosen official text-only load is appropriate:

1. `Qwen3_5TextConfig.base_config_key = "text_config"`; independent configuration-only loading confirms hidden size 1024, vocabulary 248320, 24 layers, 18 linear-attention layers, 6 full-attention layers, and tied embeddings
2. The installed official conversion map for `qwen3_5_text` removes the `language_model` prefix beneath `model`
3. `Qwen3_5ForCausalLM` ties `lm_head.weight` to `model.embed_tokens.weight`
4. That class explicitly ignores visual and MTP unexpected keys. Thus the empty reported `unexpected_keys` list is consistent with intentionally excluded branches, not a claim that the shard contained no non-text weights
5. The actual load recorded empty missing, unexpected, mismatched, and error sets. The runner asserts no missing/mismatched/error keys and checks CPU device and FP32 dtype on every loaded parameter before any forward

The executed constructor is `from_pretrained(..., local_files_only=True, trust_remote_code=False, output_loading_info=True)`, not a config-only random-model constructor. `model.eval()` precedes inference, and all model forwards occur inside `torch.inference_mode()`. No random-weight fallback appears in this runner. The fixed seed is reproducibility metadata, not evidence that randomly initialized weights were used.

The CPU-only Torch build is `2.9.1+cpu`; the code asserts that the build has no CUDA and CUDA is unavailable. The installed official model, configuration, and cache files were independently byte-verified against the audited Transformers source pin `02d8fb9784e8f14a1251e4c992cd82a5762417c6`. The source hashes are respectively `f3fecce29dee6cea1ac951c947a538fdcf01abfc21f8f0e33a78b535fe6837c3`, `2f26c4bb911772d42a5f16e82bdea4b9ba1ac07872df527ec228622d35f3c30e`, and `2d2ab17aa02c9d2a993587ec58d1745b03595b6028c401cc6c976bb720ad6638`.

Sources: `diagnostics/hybrid_cpu_competence/v2_asset_provenance.json`, `v2_loading_info.json`, `run_probe.py`, and the ignored checkpoint/header/index; official implementation snapshots under `diagnostics/hybrid_recurrence_cpu/sources/` and installed `transformers/conversion_mapping.py`.

## 2. Input integrity and pre-outcome amendment

All **11 v1 frozen files** and **14 v2 frozen files** independently match their respective freeze manifests. The v1 fixture JSONL and v2 fixture JSONL are byte-identical. The only prompt-content difference in the template is one ASCII space appended after `Prefix:\n`; added revision labels are metadata. No case, answer, split, name, threshold, or per-case padding change is hidden in that amendment.

The v1 failure remains preserved: unequal A1/A2 prefix lengths in 11 of 16 groups, including d01 42/43 and d05 43/42, caused a token-integrity stop before pretrained weights. Its 16 planned cells remain non-executed.

The v2 freeze is timestamped **15:58:57 UTC**, before the checkpoint download at **16:02:08 UTC**, either loading attempt, or the first recorded model outcome at **16:05:19 UTC**. The preserved chronology supports a pre-outcome mechanical repair rather than outcome-driven prompt editing.

I independently reran the frozen token validator in memory using the local pinned tokenizer. All **64 contexts** exactly match the frozen token arrays. Checks include official chat-template equality, equal A1/A2 and U1/U2 prefix lengths, identical B and Q arrays within each group, no token crossing a segment cut, correct interior spans, and candidate-plus-EOS tokenization. The copy passed to the runner is byte-identical to frozen v2 `token_validation.json`.

Metadata SHA-256s for all six downloaded files were rechecked. Non-LFS Git blob SHA-1s were independently recomputed and match; the tokenizer's SHA-256 matches its recorded official LFS digest. These checks establish consistency with the preserved official metadata, rather than a fresh online attestation.

For the executed cell, A/B/Q lengths are 42/156/31, totaling 229 tokens. The recorded input hash matches the independently retokenized prompt. The important B sentence begins at B token 77. The official generation suffix closes the empty thinking block; it matches the pinned chat template. No extra BOS, competing system prompt, sampling, or answer text is appended to the model input.

## 3. Gold, decoding, and likelihood arithmetic

The frozen semantic mapping is unambiguous:

- A1: Alice is the courier; Bruno is the observer
- B: the courier receives the red key; the observer receives the blue key
- Q: which color key did Alice receive?
- Gold: **red**

The saved generated IDs decode independently to `blue<|im_end|>`. This is the other candidate with a valid terminator, not a scoring parser accident, truncation, or wrong gold label. The answer-normalization function also independently returns false. The frozen chat EOS is 248046; the base text config's 248044 end-of-text token is not silently substituted. Stopping explicitly on the frozen chat EOS is correct for this rendered chat response.

The first-token logits come from the last position of the entire fresh prompt. Explicit absolute positions start at zero; the official text model expands the runner's 2-D positions into its text/temporal/height/width convention. The all-ones attention mask supplies valid tokens while the official implementation creates the causal/recurrent masks. `logits_to_keep=1` retains the correct next-token prediction.

Candidate scoring uses one independently cloned post-prompt cache per candidate: score the answer token from the prompt logits, forward that answer token, then score EOS. Greedy decoding uses a separate clone and greedy argmax from the same prompt logits. The code checks non-aliasing/equality of cloned state tensors and verifies the source cache remains exactly unchanged after scoring. It neither teacher-forces the gold answer into the greedy cache nor scores a candidate using the other's continuation state.

The saved per-token arithmetic reproduces exactly:

- red: −0.9024131894111633 + −0.004888487514108419 = **−0.9073016769252717 nat**
- blue: −0.6230743527412415 + −0.0031880526803433895 = **−0.6262624054215848 nat**
- gold minus other: **−0.2810392715036869 nat**

These are sequence log-probabilities including EOS, not probabilities normalized over just the two answers. The observed preference is relatively close, but the fixed deterministic competence rule does not contain a margin exception.

Audit limit: full vocabulary logits and loaded in-memory parameter samples were not archived. This review validates the saved raw output, likelihood arithmetic, checkpoint structure, load record, and code path; it does not independently regenerate the model output or eliminate every possible upstream-library defect. A second model run was deliberately not used to strengthen a stopped experiment.

## 4. Prior implementation controls and their limits

The earlier saved tiny-model gate contains 101 independent FP64 algebra fixtures and 32 official-HF numerical/structural checks. It covers full/exact-prefix continuation, sequential chunking, long 149-token sequences crossing GDN chunk boundaries, single-token continuation, future causality, and official chunk-versus-recurrent kernels. Its maximum direct and cache-coordinate errors are approximately 2.38e−7 and 4.77e−7, well inside the 1e−4 tolerances.

Those are useful evidence against elementary recurrence/cache errors in the official CPU backend. They are random tiny-model implementation checks, not pretrained competence or full-checkpoint parity evidence. None of them rescues or overrides the current competence stop. The unmodified official CPU fallbacks and monolithic full-recompute path, not the HYPIC-inspired adapter, produced the observed answer.

## 5. Retry, work, and resource accounting

The first load attempt failed while serializing Transformers' loading-info sets, at `model.eval(); write(...loading_info...)`, before a cell or model forward. Its execution-order list is empty, events contain load-start and finish only, and traceback identifies JSON serialization. The preserved attempt-1 source and current runner differ by exactly the serialization fallback; their recorded before/after hashes independently match.

The logging-only retry did not alter the prompt, tokenizer, dtype, backend, scoring, or thresholds. It retained the original execution-start time and absolute 30-minute deadline. Both loads and their overhead are disclosed:

- Failed attempt process wall time: **8.011 s**
- Successful attempt process wall time: **11.021 s**
- Sum of process wall times: **19.032 s**
- Original envelope including the intervening fix: **98.533 s**
- Successful load: **5.578 s**, potentially benefiting from filesystem pages warmed by the first attempt; not an independent cold-load estimate
- Completed cell: **4.279 s**, including **3.046 s** monolithic prefill
- Recorded model work: **4 forwards / 232 network input tokens**: 229 prompt + 2 candidate continuations + 1 greedy continuation. EOS is scored but never unnecessarily forwarded

Peak RSS is **5,082,800,128 bytes (4.734 GiB)**, matching the process high-water report and external monitor. The external watchdog samples RSS/high-water marks every second, enforces 8 GiB and load/wall limits, and recorded no resource stop. The smallest recorded host-available memory during the successful attempt was 4,512,391,168 bytes. One intra-op and one inter-op thread were configured; `/proc` records two process threads during inference and briefly six during loading, so configured compute-thread counts should not be described as a single OS-thread process.

The 44.47-second checkpoint download and prior metadata acquisition are separately recorded rather than hidden inside model compute. One checkpoint plus the existing 1.173-GB environment left over 9.18 GB free disk, above the 5-GB reserve. The checkpoint path is Git-ignored. No speedup, remaining-grid completion estimate, cached-Q latency, or source-tuple cost can be inferred from this one stopped full-prefill cell.

## 6. Validation performed by this reviewer

- Streaming checkpoint SHA-256 and byte-size verification
- Safetensors-header/index key comparison, tensor categories, shape-product parameter count, and checkpoint dtype counts
- Offline text-config extraction and official conversion/tied-head inspection; no model construction
- Hash verification of six metadata assets, 11 v1 frozen files, 14 v2 frozen files, both preserved runner versions, and three installed audited source files
- Full model-free retokenization of all 64 contexts, exact comparison with frozen IDs, output decoding, gold mapping, and stored likelihood arithmetic
- Rerun of all 16 v2 protocol unit tests: **passed**
- Review of both attempts' raw logs, events, status ledgers, watchdogs, RSS records, and final reporting

Only this review file was added by the reviewer. The historical failure, protocols, model outputs, and implementation were not edited. The appropriate next state is a closed, failed initial competence probe with the research claim still untested, not automatic escalation or a post-outcome rescue run.
