# Architecture-specific KV gap screen

Research cutoff: **2026-10-03 UTC**. Main literature window: October 2024–October 2026, with the older Dynamic-NTK cache inconsistency explicitly separated. This is a source/code investigation and a proposed CPU falsification protocol. **No model run, implementation, model/dependency download, GPU use, paid operation, or commit was performed.**

## Decision

**No new main research topic is established. One architecture-specific problem merits a small CPU falsification screen: whether cross-segment conditioning of deep recurrent layers causes answer-relevant errors after HYPIC's existing transition, positional, convolution, and seam repairs.** This is an acknowledged open problem, not our discovery of a failure and not a proposed new algorithm. The screen must demonstrate something beyond large hidden-state norms and beyond widening an existing seam.

Dynamic positional scaling, generic hybrid prefix caching, and broad repeated-visual-prefix/M-RoPE reuse do **not** survive as novel topics. The current literature and implementations already cover their obvious mechanisms. In particular, do not rename the stopped generic RAG repair project: this screen concerns the missing cross-layer response of a recurrent state to its incoming context, with a specific hybrid model and a specific existing baseline. It is not query fusion, generic token recomputation selection, or another calibration heuristic.

| Branch | Strongest current finding | Decision |
|---|---|---|
| Sequence-dependent RoPE | Known basis inconsistency; modern pinned code still makes the basis depend on maximum position | Kill method claim; useful regression fixture only |
| Mixed sliding/global attention | Mask semantics and per-group reuse/eviction are explicit, actively engineered constraints | Kill generic architectural-awareness claim |
| Hybrid recurrent segment reuse | HYPIC removes frozen-input transition error but deeper inputs retain cross-segment dependence; project acknowledges this boundary | Conditional CPU **problem** screen only |
| Multimodal repeated visual prefixes | Kamera, VLCache, MiniPIC and current serving discussions cover relocation, conditioning and nonuniform-anchor limitations | Kill broad claim; no multimodal main promoted |

## 1. Dynamic positional scaling: a clear falsifier, an old problem

### Primary evidence and code

The original [Transformers issue #25104](https://github.com/huggingface/transformers/issues/25104), opened **2023-07-26**, explicitly describes cached keys using rotation bases from previous sequence lengths. Its [closing discussion](https://github.com/huggingface/transformers/issues/25104#issuecomment-1667862099) on **2023-08-07** records the speed/correctness tradeoff. This predates the search window and must not be repackaged as a 2026 discovery.

At Transformers commit [02d8fb9784e8f14a1251e4c992cd82a5762417c6](https://github.com/huggingface/transformers/commit/02d8fb9784e8f14a1251e4c992cd82a5762417c6), **2026-10-02 20:59:34 UTC**:

- [modeling_rope_utils.py, lines 33–125](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/modeling_rope_utils.py#L33-L125) updates dynamic frequencies from `max(position_ids)+1`, with per-layer-type support and reset logic
- [Llama attention, lines 250–259](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/llama/modeling_llama.py#L250-L259) applies RoPE before cache update
- [common RoPE tests, lines 6013–6097 and 6230–6250](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/tests/test_modeling_common.py#L6013-L6097) test forward/frequency properties; these inspected tests are not a compressed-prefix/frequency-epoch equivalence test. This does **not** prove the entire repository lacks such coverage

Minimal algebraic witness: an unrotated key `(1,0)` at a position whose angle changes from zero to π/2 becomes `(0,1)`. With post-rotation query `(1,0)`, a second zero key, and values `[1,0]`, a stale old key produces `e/(e+1)` whereas correctly rephasing produces `1/2`. No checkpoint is needed to check this.

Mandatory controls are a fixed frequency epoch, fully specified source/target position metadata, pre-RoPE storage or exact old-to-new rotation, and a full recomputation reference. Rephasing stored keys alone is not a proof of full-network equivalence: changing earlier attention can also change deeper pre-RoPE K and V. Likewise, changing the reference's RoPE convention can manufacture an apparent compression improvement.

### Why this is not a fresh compression mechanism

[CommVQ, ICML 2025](https://arxiv.org/abs/2506.18879) already makes RoPE commutation central; author code is pinned at [d1f0377429b30ff8933fd0debcbc9c0d4efd06a3](https://github.com/UMass-Embodied-AGI/CommVQ/tree/d1f0377429b30ff8933fd0debcbc9c0d4efd06a3), **2025-09-02**. [RAP](https://arxiv.org/abs/2602.02599), February 2026, uses whole rotary pairs to avoid reconstruction. No RAP author-code pin was verified here.

The useful distinction is between an algebra valid for an entire rotation family and an implementation using the wrong coordinates/basis. A pairwise construction that commutes for every angle does not become a new method because the angle is selected dynamically. Missing model-family support, scalar-position assumptions, and metadata repairs are implementation work unless a separate quality/compute tradeoff survives these exact controls. **Kill as a main.**

## 2. Mixed windows: do not mistake a changed attention mask for a new compression failure

The public [KVLens case study](https://github.com/gcgarriga/KVLens/blob/7fe02f8220275e19323379562c8873c2c09e0108/study/gemma4-kv-cache-eviction.md) already compares sparse selection with FIFO on hybrid Gemma attention. Inspected commit: **7fe02f8220275e19323379562c8873c2c09e0108**, **2026-09-01**. Treat its results as author-reported, not reproduced here.

A source-level confound matters: [attention.py, `_build_attention_mask`](https://github.com/gcgarriga/KVLens/blob/7fe02f8220275e19323379562c8873c2c09e0108/src/kvlens/attention.py#L80-L108) returns only the causal predicate when explicit cached positions are present, bypassing the local-window predicate used by its other branch. Its [position tests](https://github.com/gcgarriga/KVLens/blob/7fe02f8220275e19323379562c8873c2c09e0108/tests/test_cache_positions.py) verify noncontiguous retained indices; the inspected [prefill parity tests](https://github.com/gcgarriga/KVLens/blob/7fe02f8220275e19323379562c8873c2c09e0108/tests/test_prefill_cache_semantics.py) concern the standard cache. Thus the headline divergence cannot, from this source alone, isolate sparse selection under the unchanged trained mask. It does not establish that a mask fix explains every reported number.

Hand-checkable control: query position 4, local width 3, retained positions `[0,3,4]`, equal logits, values `[9,0,0]`. Causal-only attention outputs 3; the original local mask excludes position 0 and outputs 0. This detects a semantic mismatch without a pretrained model. Preserve original absolute positions **and** the original causal/window predicate before assessing selection quality. Also compare FIFO within local layers with compression confined to global layers.

Serving-level problems are public too. [vLLM #48435](https://github.com/vllm-project/vllm/issues/48435), opened July 12 and closed September 3, reports SWA tail residency causing cross-session hit collapse. [RFC #54661](https://github.com/vllm-project/vllm/issues/54661), opened September 1, already proposes per-group retention and distinguishes target-required state from draft-only state. These issue reports are evidence of known scope, not independently verified performance. [PR #46384](https://github.com/vllm-project/vllm/pull/46384), merged **2026-07-12**, commit [481e481be786c1ca3229e26aa34c15ffd22375af](https://github.com/vllm-project/vllm/commit/481e481be786c1ca3229e26aa34c15ffd22375af), already adds token-length hybrid hits and partial-block copy-on-write. Elementary mask restoration, per-group byte accounting, and checkpoint-boundary handling are insufficient novelty. **Kill the broad direction.**

## 3. Hybrid recurrent conditioning: the one conditional CPU seed

### Closest methods and the remaining distinction

- [Marconi, MLSys 2025](https://arxiv.org/abs/2411.19379) handles hybrid admission/eviction and exact-state reuse opportunities. Its author artifact is pinned at [08016617b1524e6bf6ac29b680641cc945bda7f0](https://github.com/ruipeterpan/marconi/tree/08016617b1524e6bf6ac29b680641cc945bda7f0), **2025-03-05**
- [Sparse Prefix Caching](https://arxiv.org/abs/2605.05219), first submitted **2026-04-17** according to arXiv, formalizes exact recurrent checkpoint placement and suffix recomputation. No author implementation pin verified
- [HYPIC](https://arxiv.org/html/2607.01299v2), July 2026, caches each isolated segment's zero-start recurrent state and cumulative transition, plus positional/convolution repair and a beginning-of-segment recomputation window. This is the closest mandatory baseline
- [Tail-Replay](https://arxiv.org/abs/2608.30310), August 31, and [SuffixReplay](https://arxiv.org/html/2609.33477v1), September 27, use recurrent forgetting to reconstruct **matched-prefix** state. The latter stores sparse group-entry anchors and explicitly states forgetting/model-dependent replay limits. No linked author-code pin was verified for either. Reusing an identical prefix is different from conditioning the same isolated segment on a changed earlier segment

HYPIC's paper already qualifies layer exactness by **identical input hidden states**. Its [project collaborator response](https://github.com/redai-studio/HYPIC/issues/10#issuecomment-5506131951), **2026-09-02 07:35:27 UTC**, confirms that a table's claimed deepest-layer statistic was actually an all-layer aggregate. The collaborator agrees that roughly 0.29 relative error at the last recurrent layer is consistent with their observations, and identifies recovery of cross-segment recurrent context as open. Issue #10 was closed September 10 after that explanation. The comment's verified GitHub association is `COLLABORATOR`; no individual author identity is assumed here.

**This is not evidence of 29% answer degradation.** The reporter also says end-to-end MultiNews results broadly agree with the paper. Norm error can lie in directions a continuation does not read. The potentially useful question is whether changed-prefix conditioning produces **answer-relevant**, persistent error beyond existing seam repair on tasks the small model can solve when recomputed.

### Exact author-code provenance

HYPIC commit [98147c01909004e66d98bcb18b886927d41b0ee5](https://github.com/redai-studio/HYPIC/commit/98147c01909004e66d98bcb18b886927d41b0ee5), **2026-07-21 06:09:31 UTC**, is the latest commit returned before this screen's cutoff.

- [PICache](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py): hit-seam position construction and cache lifecycle
- [GDN backend](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py): recurrent transition composition, fp32 state staging, interior/seam decomposition
- [Convolution-tail handling](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/conv_tails.py): previous-tail loading and interior-tail capture
- [Six-way baseline script](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/quick_test_offline.py): full recompute, prefix cache, addition, transition, transition+RoPE, transition+RoPE+seam
- [Layer-divergence diagnostic](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/diag_layer_divergence.py) already inspects internal drift. Merely producing layer-error plots is not new
- [Seam parameter tests](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/test/srt/pic/test_seam_sink.py) exercise width interpretation. [Issue #3](https://github.com/redai-studio/HYPIC/issues/3), open at inspection, reports the PIC tests are outside normal CPU CI selection; no tests were run here

### Tiny mechanistic witness, not a paper claim

Consider two scalar recurrent layers over a reused segment B of length n with zero external input to the first layer. Let that layer enter with state a and update `s_t = r*s_(t-1)`. Its output is `h_t = s_t`. The second layer enters with `z_0 = 0` and updates `z_t = r*z_(t-1) + h_t`; it therefore receives nonzero endogenous writes in the full computation.

In isolation, B has `a=0`, so its upper-layer cached affine tuple is `T=r^n, u=0`. With a changed real prefix, the full second-layer result is `z_n=n*r^n*a`. If only the first w positions are recomputed and the rest use the isolated upper-layer tuple, the result is `w*r^n*a`; the missing contribution is `(n-w)*r^n*a`. The construction still holds for `0<r<1`, not only a non-forgetting recurrence.

This is a **derived two-layer recurrence witness**, not the full Qwen architecture or an executed HYPIC reproduction. It isolates a cross-layer input effect even when the per-layer affine algebra is correct. The joint two-state transition `[[r,0],[r,r]]` composes exactly, so this is not an impossibility result for composition. For fixed `0<r<1`, absolute error eventually vanishes as n grows even while relative error is `1-w/n`. It does not disprove the qualified identical-input theorem, and the underlying issue is already acknowledged upstream. It motivates a natural-model screen, not an automatic low-rank/Jacobian/learned repair. No substantive new mechanism has yet been identified.

### Smallest features-matched public CPU substrate

Use [Qwen/Qwen3.5-0.8B](https://huggingface.co/Qwen/Qwen3.5-0.8B/tree/2b48083dfa97c3cbf0220cf1a5e6cffe0a511157), config revision **2b48083dfa97c3cbf0220cf1a5e6cffe0a511157**. Its [official config](https://huggingface.co/Qwen/Qwen3.5-0.8B/blob/2b48083dfa97c3cbf0220cf1a5e6cffe0a511157/config.json) has 18 GDN and 6 full-attention layers in a 3:1 pattern, convolution width 4, GDN head dimensions 128, full-attention dimensions 256, and partial interleaved M-RoPE. The weights need not be downloaded for the algebra gate.

Features match the causal question, but **not all large-model details**: [Qwen3.5-35B-A3B config](https://huggingface.co/Qwen/Qwen3.5-35B-A3B/blob/41adbc1e50345066ac5153217957e9910204e632/config.json) uses 30 GDN/10 full layers, MoE, and 16 key/32 value recurrent heads; 0.8B is dense and has 16/16 recurrent heads. Its full-attention query/KV ratio is also different. A success or failure on 0.8B cannot establish 35B magnitude or throughput. Add a small synthetic grouped-head test if the CPU adapter supports that layout, without pretending the small checkpoint naturally has it.

Pinned Transformers [PyTorch recurrent fallback, lines 431–491](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/qwen3_5/modeling_qwen3_5.py#L431-L491) performs the GDN recurrence in fp32, accepts an initial state, and returns an endpoint state. CPU source support exists; actual installed-version execution and peak RSS have **not** been checked. HYPIC's supplied end-to-end examples target large SGLang models and are not a ready-made CPU reproduction. A future CPU adapter needs its own parity gate.

RAM design: roughly 3.2 GB for the advertised 0.8B language parameters in fp32, plus vision weights if loaded, runtime buffers and short-context activations. At 16 heads × 128 × 128 × 4 bytes, each GDN endpoint is 1 MiB; all 18 endpoints are 18 MiB. Keep one model and evaluate arms sequentially. Do **not** retain a state at every token: 512 positions across those 18 layers alone would occupy 9 GiB. Use endpoint states, online scalar error summaries, at most one layer's input trace, 256–512 text tokens, batch one, no autograd and last-token/selected-token logits. An 8 GiB process safety ceiling is a proposed guard, not a measured guarantee. If the required adapter exceeds the 9 GB budget, stop; do not switch to GPU.

### Falsification protocol and exact controls

**Gate 0: implementation validity without weights.** Check the two-layer witness, GDN tuple composition against sequential recurrence on identical inputs, original versus grouped recurrent heads, convolution-history boundaries, and correct causal positions. Float64 tensor fixtures should agree near numerical precision. A failure here is an adapter bug.

**Gate 1: establish the small model can answer.** Prepare a fixed, tiny set of paired prompts `A1 + B + Q` and `A2 + B + Q`. B is byte/token-identical, but a preceding definition, entity mapping, or resolved reference changes how an interior sentence should be interpreted. Place the relevant interior material beyond the first 32 tokens, and include unrelated-prefix and exact-prefix controls. Predeclare about 12–16 pairs, 128–256-token B, and a short answer. These constructed pairs are mechanism checks; reserve a separate small set of ordinary cross-document/coreference examples with fixed segmentation for practical relevance. Predeclare an answer-harm threshold and a held-out split before inspecting failures. Score every prompt, report the full set and the full-recompute-correct subset, and do not post-select only dramatic failures. If recomputation cannot solve enough pairs to support the question, the task/model pair is uninformative, not evidence of cache failure. A tiny inconclusive sample is a no-go for investment, not proof that the effect never occurs.

**Gate 2: same-checkpoint paired arms.** Run (a) full recompute, (b) exact-prefix cached continuation, (c) isolated affine tuples with corrected positional and convolution handling, and (d) HYPIC-style transition+RoPE+seam with `w=8,16,32`. Include genuine sequential chunked prefill with every cache carried forward to measure numerical scheduling noise, and require `w=all reused tokens` to recover full recomputation. Use one exact tokenization, template, separators, causal mask, RoPE metadata and dtype. Seam exclusion must remove those contributions from the cached tuple without silently changing how isolated interior hidden states were generated. Do not compare different prompts introduced by separator handling. Recompute Q freshly in every arm. Compare externally scored answers, greedy exact answer tokens, correct-answer log probability, and next-token distribution differences; preserve each prompt's outcome. Full-attention KV must remain uncompressed in this first screen.

**Gate 3: causal attribution.** After B, run the identical fresh Q under a 2×2 endpoint-donor control: baseline versus full-recompute GDN states, crossed with baseline versus full-recompute full-attention KV. Treat convolution state as its own intervention, or explicitly label a joint recurrent-plus-conv swap. The all-full donor must recover full logits/answers. A recurrent donor rescue identifies an answer-relevant recurrent channel; it does not prove that the original error arose exclusively in GDN, because earlier full-attention differences can feed it. At one recurrent group at a time, additionally feed target-prefill input hidden states as an oracle while keeping the same affine composition. This distinguishes correct fixed-input algebra from changed-input forcing. Oracle hidden states are a diagnostic upper bound with their computation cost disclosed, never a deployable method. If only the full-attention donor or convolution repair rescues answers, narrow or kill the recurrent-specific framing.

**Promotion requires all of the following:** reproducible answer-relevant loss above the exact-prefix/chunking noise control; attribution to recurrent contextual inputs; persistence beyond the simple wider-seam controls at a useful recomputation budget; and a credible way to recover that loss with less total work/storage than full recompute. The current source review establishes none of the last empirical conditions. Any later claim of a new mechanism needs another focused novelty search.

**Kill or stop:** only state norms move; only incorrect position/convolution handling causes failure; full recompute is itself unreliable; `w=16/32` removes the practical gap cheaply; benefits require oracle target-conditioned traces at essentially full-prefill cost; effects are restricted to artificial extreme states; or the CPU resource cap is exceeded. A negative result is enough to close this seed. Do not launch large-model experiments merely because a source calls the problem open.

## 4. Multimodal geometry: broad claim killed, narrower fallback still unproven

[Kamera](https://arxiv.org/html/2606.23581v1), June 2026, directly covers reusable visual chunks, relocation, cross-chunk conditioning, low-rank patches, reorder/slide/recall, and Qwen2.5-VL/Qwen3-VL. It leaves predicting corrections without a target-conditioned forward open. No author-code pin was verified. [VLCache](https://arxiv.org/html/2512.12977v2) already discusses cumulative conditioning errors under another visual prefix; [MiniPIC](https://arxiv.org/abs/2606.13126) stores unrotated keys and rotates during attention. The absence of a multimodal CommVQ implementation does not establish a new algebraic method.

The concrete user-facing boundary is already public in [vLLM RFC #51948](https://github.com/vllm-project/vllm/issues/51948): bounded visual sessions retain a pinned sink while evicting old frames. The September 30 [discussion](https://github.com/vllm-project/vllm/issues/51948#issuecomment-5907011073) explains that compacting only survivors changes sink-relative distances; preserving noncontiguous coordinates and periodically re-prefilling are existing alternatives. PR #53876 head **89bfabd975d9f006e4b2dfc2448846f346c2dbc4** includes [continuation arithmetic](https://github.com/vllm-project/vllm/blob/89bfabd975d9f006e4b2dfc2448846f346c2dbc4/vllm/v1/streaming/mrope.py) and [tests](https://github.com/vllm-project/vllm/blob/89bfabd975d9f006e4b2dfc2448846f346c2dbc4/tests/v1/streaming/test_mrope_streaming.py). Those arithmetic/mock tests are not pretrained-cache equivalence evidence.

Tiny witness: one active rotary pair with frequency 1, a sink at 0 and current visual token at 3, unrotated query/keys `(1,0)`, sink/self values `[1,0]`. The two logits are `cos(3),1`. Move only the current token to 1: even perfectly corrected rotations yield `cos(1),1`. The attention output changes, so deeper unrotated K/V generally change too. Moving **both** positions equally is the invariant control. This demonstrates the known boundary, not a new theorem.

A possible but unpromoted question is whether geometry-dependent deep-state corrections can compact/retime visual chunks around a fixed anchor more cheaply than existing recomputation and leave-gap retention. It must first beat correct M-RoPE layout, leave-gap retention, Kamera-style correction and periodic consolidation. No evidence here shows a new estimator or a better frontier.

For a later CPU falsifier, [Qwen2-VL-2B-Instruct revision 895c3a49bc3fa70a340399125c650a463535e71c](https://huggingface.co/Qwen/Qwen2-VL-2B-Instruct/tree/895c3a49bc3fa70a340399125c650a463535e71c) has a 4.43 GB repository-weight footprint, leaving plausible headroom for tiny BF16 CPU inputs; total RSS is unmeasured. It predates the main literature window but is a cheap architectural substrate. Qwen2.5-VL-3B's 7.52 GB repository footprint is too close to the limit to promise <9 GB runtime. Compare source prefill, target full prefill, exact key relocation and leave-gap retention before adding compression.

Two additional audit cautions prevent false novelty:

- [Programmable-KV image-shift code](https://github.com/19PINE-AI/programmable-kv/blob/e9085eafcc6c83e60c548de69060c4bd5b210c96/esys/composable_vision_shift.py), pin **e9085eafcc6c83e60c548de69060c4bd5b210c96**, expands M-RoPE section widths elementwise rather than repeating the list, unlike the [official HF layout](https://github.com/huggingface/transformers/blob/cd22550692cabffb037b7e5a956e8da3cbbb2b67/src/transformers/models/qwen2_5_vl/modeling_qwen2_5_vl.py#L576-L615). Its agreement statistic compares correctness booleans; different wrong answers can agree. Neither issue is a new compression contribution
- [QVAC grid-shift tests](https://github.com/tetherto/qvac-fabric-llm.cpp/blob/43c8e7c0248d780fd00fc23e8fb5fbd207904033/tests/test-kv-cells.cpp), pin **43c8e7c0248d780fd00fc23e8fb5fbd207904033**, already cover multiaxis shift bookkeeping. [RSQR RFC #57672](https://github.com/vllm-project/vllm/issues/57672) already discusses repeated-rotation drift and raw-key/query-side alternatives; extending that to another coordinate layout requires more than an adapter

## Search boundary and exact known/unknown

Primary sources inspected include recent papers, author repositories, Transformers, vLLM and the HYPIC issue discussion. Search terms covered dynamic/sequence-dependent RoPE with cache reuse; hybrid recurrent and sliding-window compression; position-independent recurrent caching; M-RoPE/visual-prefix relocation and quantization. This was a targeted screen, not an exhaustive novelty proof. Unlinked or inaccessible implementations are marked rather than assumed absent.

| Statement | Evidence status |
|---|---|
| Dynamic-NTK basis inconsistency is old | Primary 2023 issue plus current pinned source |
| Sparse-cache masks can change local attention semantics | Pinned KVLens branch and algebraic witness; no model attribution run |
| Generic hybrid reuse is crowded | Marconi, sparse checkpoints, HYPIC, Tail-Replay, SuffixReplay |
| HYPIC deep recurrent conditioning remains open | Qualified paper claim plus dated collaborator admission |
| 0.29 recurrent-state error means degraded answers | **Not established and must not be claimed** |
| Qwen3.5-0.8B is architecturally relevant and CPU-code-supported | Pinned config and PyTorch fallback; runtime/RSS untested |
| A new repair improves the quality/work/byte frontier | **Unknown; no repair designed or tested** |
| Nonuniform visual rephasing alone guarantees reuse | False algebraically; already recognized in serving discussion |
| A new multimodal main exists | **No candidate promoted** |

Recommended next action, only if implementation is separately requested: the bounded HYPIC/Qwen3.5-0.8B CPU falsification gates above. The useful deliverable would initially be a yes/no causal result with strong controls, not another named KV method.
