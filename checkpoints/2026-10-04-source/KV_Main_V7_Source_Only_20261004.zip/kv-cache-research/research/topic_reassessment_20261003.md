# KV cache topic reassessment

Date and cutoff: 2026-10-03 UTC. Main search window: 2024-10-03 through 2026-10-03; older foundations are marked separately. This is a problem-first reassessment, independent of the existing EchoPress implementation. It incorporates the previous calibration and backup audits without reopening their rejected claims.

## Recommendation

**No candidate currently passes both the substantive-novelty gate and the evidence gate for a main research project. Do not spend on GPU experiments for these three candidates yet.** All three have precise, inexpensive CPU falsification tests. Their current status is a research-risk screen, not a promise of a new compression method or a publishable paper.

**Source-status caution:** HeadQ was withdrawn on **2026-05-19**. Its old manuscript is mentioned only as a public conceptual-overlap warning, not as accepted prior work, trustworthy experimental evidence, or a reproduction target. Candidate A's mathematical statements and code observations are independently checkable; no HeadQ numerical result supports this report.

The most useful remaining question is **how request-specific eviction changes the actual unique physical memory of a shared prefix**. It has a broader possible measurement contribution than either a known scorer correction or a straightforward speculative-decoding adapter. However, even that question must beat shared-full-prefix and common-mask controls. A source-code accounting error alone is insufficient.

Recommended order for a subsequent CPU-only pass:

1. Close the small algebraic tests for scorer invariance and speculative execution. Their simplest controls are strong enough that these should probably end as rejected method candidates.
2. Run the shared-prefix physical-byte/retention-union pilot, first with explicit arrays and masks. This can determine whether any nontrivial tradeoff exists beyond known sharing and compression mechanisms.
3. Download a small pretrained model only if a surviving question needs natural attention/retention traces. Do not load the prepared 8B checkpoint into this CPU environment.

No repository implementation was changed, no model/dependency assets were downloaded, no GPU was started, and no remote state was changed for this reassessment. Only this research report was added. Small inline NumPy/arithmetic calculations checked the two attention witnesses and memory formulas below; proposed model experiments have not run. This was a targeted primary-source search, not proof that every relevant paper or implementation has been found.

## Three candidate comparison

| Narrow candidate | Source-backed issue | Possible contribution beyond the source | Simplest strong control | Current decision |
|---|---|---|---|---|
| A. Exact-attention-invariance audit of GQA eviction scores | Max pooling raw logits and uncentered cosine redundancy can respond to transformations that leave dense attention unchanged | A narrowly scoped interaction/negative-result study, if it exposes consequential failures beyond a known one-line scorer change | Softmax before head reduction; independently center keys for redundancy scoring; factorial ablation | Reject as main: R-KV explicitly flags the elementary pooling change; withdrawn HeadQ is a conceptual-overlap warning only |
| B. Shared-prefix retention under a unique physical-byte budget | Request-specific compaction conflicts with shared storage; nominal pool bytes can omit active dense reconstructions | An empirical boundary for when independent eviction ceases to save memory after sharing is correctly implemented, with a common/private retention repair only if simple controls leave headroom | Share the full prefix and compress private suffixes; one common compressed prefix; union-deduplicated selected tokens; ordinary copy-on-write | Highest-priority CPU question, but no main selected: natural mask/quality evidence and a distinct mechanism remain absent |
| C. Serial-consistent speculative decoding with online eviction | Destructive compaction and scoring metadata cannot simply be cropped after rejection; crossing an eviction boundary changes the verification target | A precise semantic contract and integration result, only if boundary-capped verification proves inadequate | Cap verification at canonical eviction boundaries and commit accepted metadata only | Reject as main: the obvious exact control appears cheap at the released method's cadence |

These are three different failure objects: representation symmetry, physical aliasing/storage, and execution-state semantics. They are not new names for regional calibration, generic scheduling, mass correction, or risk certification.

## A Exact attention invariance of GQA eviction

### Problem and closest work

A fixed attention query cannot distinguish a common translation of every key in its visible set: adding the same vector to all post-RoPE keys adds a constant to that query's logits, which softmax cancels. An eviction scorer can nevertheless change its retained set under this transformation.

The closest public conceptual description found is [HeadQ](https://arxiv.org/abs/2605.03562), submitted **2026-05-05 09:34:51 UTC** and **withdrawn on 2026-05-19 17:40:13 UTC**. The current arXiv record attributes withdrawal to ethical concerns identified after posting. Its older [sections 3.1 and 5.2](https://arxiv.org/html/2605.03562v1) describe the same softmax-null direction and mean-key intervention. This is a warning against a broad firstness claim, not validated evidence that a method or experiment works. No reported HeadQ numerical finding is used, and no author-code pin was verified. The common-key-translation identity follows directly from softmax algebra and was independently checked below; the actual eviction behavior is grounded in the pinned R-KV source.

The narrow target is [R-KV](https://arxiv.org/abs/2505.24133), first submitted **2025-05-30 02:03:24 UTC**, revised **2026-01-22 01:31:36 UTC**. Its author tree was verified at [6715468b9872442be72e5c97322e4d9c9a2abf55](https://github.com/Zefan-Cai/R-KV/commit/6715468b9872442be72e5c97322e4d9c9a2abf55), committed **2026-07-20 04:27:09 UTC**. The [Hugging Face scorer](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/HuggingFace/rkv/compression/r1_kv.py) max-pools GQA logits before softmax and already contains the TODO “Softmax then reduce head”. Its cosine-redundancy term is separately sensitive to a common key translation. The released serving ports and Hugging Face path must not be assumed algorithm-identical without tracing their aggregation rules.

### Hand-checkable quantitative witness

Use two query heads sharing two scalar keys, retention budget one:

- Queries: q1 = 2, q2 = -1
- Keys: k1 = 1, k2 = 0; values: v1 = 1, v2 = 0
- Before translation the two logit rows are [2, 0] and [-1, 0]
- Max across heads gives [2, 0], retaining token 1
- Translate both keys by -2. The rows become [-2, -4] and [1, 2]
- Max across heads now gives [1, 2], retaining token 2

Dense per-head attention is unchanged: [0.880797, 0.119203] and [0.268941, 0.731059]. Yet the one-token retained attention readout switches from 1 to 0 in both heads. This is an algebraic counterexample to an intermediate scorer's invariance, **not** a measured failure frequency or quality result for full R-KV.

Both max-after-softmax and per-query mean-centering before max retain token 1 in either representation for this example. Mean-centering keys also removes the translation from the cosine-redundancy input. The pooling fix alone does not fix the full two-term policy.

The intervention is after RoPE and must cover every key visible to the tested query, including protected/recent/current keys. Adding a vector before position-dependent RoPE, or translating only historical keys while leaving current keys unchanged, is not the same invariance test. Repeated model-step tests must maintain this convention on every append. Invariance alone also does not establish which invariant scorer is better on unmodified natural states.

### Falsifiable predictions and controls

Prediction A1: under common-key translations, dense attention agrees to the numerical baseline while raw-max importance sometimes changes rank/selection. Prediction A2: correcting only pooling can leave selection changes through cosine redundancy. Prediction A3, currently unestablished: natural key means make this instability large enough to change the downstream quality/byte frontier, rather than merely changing representations in an artificial stress test.

Run a 2-by-2 factorial: raw-max versus softmax-first importance, crossed with original versus mean-centered redundancy keys. Also include mean-head attention, uniform/random selection, and a no-eviction reference. Keep retention counts, recency protection, score weights, ties, and output precision identical. Do not change the keys used for actual attention when the experimental arm only changes the score computation.

### Minimal CPU pilot

No checkpoint is needed for the first gate. NumPy float64 arrays with 2/7 query heads per KV group, 16–128 keys, dimensions 64/128, ten fixed seeds, and several declared common translations suffice. Include the exact witness, nonzero-key variants, and clustered as well as Gaussian inputs. Measure:

- Dense-attention and dense-readout difference before/after translation
- Retained-set Jaccard, cutoff margins, and tie frequency
- Compressed readout error under each of the four scorer combinations
- Failures attributable to importance versus redundancy

A few megabytes of arrays suffice. Compare float32 against float64 separately; a floating-point mismatch is not evidence of a new semantic mechanism.

### Kill criteria and novelty boundary

Kill the method claim if the two simple centering/normalization controls explain the effect. That would be a useful implementation diagnosis, with the pooling change already acknowledged upstream. Kill broader claims if effects require extreme artificial translations and do not appear on natural captured states. A useful negative result would explain a specific GQA importance–redundancy interaction. The withdrawn HeadQ manuscript makes a broad firstness claim unsafe, but is not an accepted or empirically validated foundation. The elementary identity and known R-KV TODO independently make the proposed method weak. There is currently no reason to finance a large-model sweep of this candidate.

## B Shared prefix retention under a physical byte budget

### Problem and closest work

When multiple requests share identical prefix KV, the correct memory baseline stores the prefix once. Independent token eviction can privatize that prefix or produce different retained sets. A nominal per-request token reduction is therefore not the same as reducing unique live cache bytes across concurrent requests.

This is a real implementation constraint. The pinned [R-KV serving validation document](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/docs/OPTIMIZATIONS.md) says prefix caching is disabled to prevent in-place compaction from modifying another request's shared blocks, and already proposes copy-on-write. The bug and its proposed repair are known; neither is the proposed research contribution.

Two recent primary works sharply limit the available claim:

- [TokenDance](https://arxiv.org/abs/2604.03143), **2026-04-03 16:04:40 UTC**, collectively reuses All-Gather contexts and stores sibling caches as sparse differences against a master. Its [design](https://arxiv.org/html/2604.03143v1) already makes cross-request storage redundancy a first-class problem. This is a different setting from exact-prefix retention-mask diversity. No author implementation pin was verified; a similarly named GitHub organization is not sufficient evidence of authorship
- [PolyKV by Ishan Patel and Ishan Joshi](https://arxiv.org/abs/2604.24971), **2026-04-27 20:10:21 UTC**, already proposes a shared asymmetrically compressed pool. Its author code is pinned at [148aba6de632d043459b4d86b72d378aea770919](https://github.com/ishan1410/PolyKV/commit/148aba6de632d043459b4d86b72d378aea770919), **2026-04-26 20:31:01 UTC**. This is not the different June 2026 paper also named PolyKV

There is also older method precedent: [BumbleBee, COLM 2024](https://openreview.net/forum?id=8w0RApM5yG), uses offline/streaming submodular KV summarization and explicitly discusses shared-prompt use. Applying facility-location or greedy subset selection here is not sufficient novelty by itself.

### A concrete source accounting issue

In PolyKV's pinned [quantizer](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/turboquant.py), value indices are int8 tensors. The pinned [pool counter](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/pool.py) nevertheless charges 0.375 bytes per value index and omits scaling/norm metadata from that total. The pinned [agent](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/agents.py) decompresses every layer into a fresh DynamicCache before generation. Its pool-only summary therefore does not measure all live reconstructed cache allocations during concurrent generation.

These are source-derived statements, not an executed reproduction of reported model results. Correctly packing codes and counting active buffers are obvious controls. Fixing this counter is an engineering correction, not a publishable research result by itself. README/package metadata declare MIT; the inspected tree did not contain a separate LICENSE file, so retain that distinction before redistributing copied code.

### Quantitative model that can be checked without a language model

Let a common prefix contain N equal-sized KV entries and let request i retain set S_i. Ignore page rounding and metadata temporarily:

- Shared full prefix: N entries
- Independently packed retained copies: sum_i |S_i|
- Ideal deduplicated retained union: |union_i S_i|
- One common compressed mask of retention r: rN entries

If m independently selected masks retain fraction r, the expected union size is N[1-(1-r)^m]. This independence model is a diagnostic reference, not a claim about real attention masks. The following arithmetic was checked in this pass:

| m requests at r = 0.25 | Private retained bytes / shared full bytes | Expected union bytes / shared full bytes |
|---|---:|---:|
| 1 | 0.25 | 0.25 |
| 2 | 0.50 | 0.4375 |
| 4 | 1.00 | 0.683594 |
| 8 | 2.00 | 0.899887 |
| 16 | 4.00 | 0.989977 |

Thus 75% per-request eviction can use twice the storage of a fully shared uncompressed prefix with eight private copies. Even ideal union deduplication saves only about 10% under independent masks. With identical masks, the union remains 25%; mask correlation is therefore a critical measurable quantity. Real copy-on-write can also retain the original parent while children are alive; that must be counted explicitly.

### Narrow potential mechanism

The candidate is **not** “share a compressed cache”. The unresolved measurement question is whether request-specific selection supplies enough quality benefit to justify its loss of sharing, once unique physical bytes and live reconstruction are counted.

A possible repair would jointly choose a shared retained core and small private exceptions under a total physical-byte budget. All currently observed queries may be used only in a clearly query-aware serving protocol; future queries remain unavailable. A common mask from aggregated attention, and a standard greedy union-budget optimizer, are mandatory baselines. A sophisticated learned optimizer is unwarranted until those simple policies leave a real gap.

Keep a second axis for per-request attention reads. Reading a small request-specific subset from an otherwise full shared prefix saves reads but does not by itself save resident prefix memory. A larger common mask can have an unfair read-cost advantage over a private-copy arm at the same total bytes. Report both the unique-resident-byte/quality frontier and a matched-per-request-read-budget slice; do not collapse these into one nominal compression ratio.

### Falsifiable predictions and minimal CPU pilot

Prediction B1: private-copy memory grows near m*r for a fixed shared prefix, while union memory depends on mask diversity. Prediction B2: a pool-only counter understates live memory if every active consumer owns dense reconstructions. Prediction B3, unestablished: the best common-mask policy materially loses quality relative to diverse request-specific masks at the same unique-byte budget, leaving room for a common/private repair.

Stage 1 needs only arrays and storage IDs:

- N = 1,024–8,192, m = 1/2/4/8/16, r = 1/8, 1/4, 1/2
- Masks with identical, independently drawn, and tunably correlated membership
- Token-level ideal union, page-granularity union with page sizes 16/32/64, independent compacted copies, and shared full prefix
- Count distinct backing allocations, actual dtype bytes, scales, index lists, masks, parent references, transient dense buffers, and private suffixes separately
- Exercise fork, read, append, compact, and free in a deterministic lifecycle trace; verify readouts and aliasing before claiming a byte result

Use one layer, one KV head, and dimension 64 for the allocation fixture. This fits well below 256 MB RAM and needs no asset downloads. Allocating several small real arrays and holding all consumers live is preferable to multiplying an ideal formula and calling it a memory measurement. No CPU timing result should be extrapolated to GPU attention latency.

Stage 2, only if justified, captures masks sequentially from a small model for eight contexts and four independent questions each, initially 256–512 context tokens and 32 continuation tokens. Compare exact common-prefix states; do not deduplicate semantically similar but causally different caches. Record the full quality/unique-byte Pareto frontier, per-question failures, and overlap by layer/head. Avoid an aggregate F1-only conclusion.

### Strong controls and kill criteria

Required controls are shared full prefix plus compressed private suffix; one shared question-blind compressed prefix; one shared mask fitted to currently visible query scores; ordinary copy-on-write; ideal union deduplication as an optimistic storage bound; and actual packed quantization with all scales/metadata counted.

Kill the new-method claim if a common mask or shared-full-prefix policy dominates. Kill it if the entire result is the PolyKV counter correction or R-KV's already documented copy-on-write issue. Kill practical relevance if benefits disappear with page rounding, persistent parent copies, or reconstruction buffers included. A measurement paper would need a reproducible general boundary across multiple independent implementations/workload families, not one faulty counter. **This is the best remaining CPU screening question, but its required natural-data and mechanism evidence has not been obtained.**

### Evidence support matrix

| Claim for Candidate B | Current support | What is still missing |
|---|---|---|
| Private-copy and retained-union formulas | Derived analytically; checked with inline arithmetic | No claim that independent masks model natural requests |
| R-KV compaction conflicts with shared-prefix mutation | Pinned author documentation | No new engine reproduction; author already guards the unsupported combination |
| PolyKV counter omits actual int8 packing cost and active reconstructed buffers | Pinned source inspection | No executed live-allocation measurement or reproduction of its paper results |
| A NumPy fixture can distinguish logical elements, aliases, and unique physical bytes | Proposed bounded implementation | Fixture has not been implemented or run in this reassessment |
| Request-specific selection improves quality at equal unique bytes and reads | No evidence yet | Matched natural-state model tests with competent full-KV controls |
| Common/private retention is a new useful method | Not established | A surviving gap against simple controls and a defensible delta from prior work |

The first CPU deliverable is a logical-versus-physical support/measurement check. It cannot establish language-model quality, scientific novelty, or publication value by itself.

## C Serial consistent speculative execution with online eviction

### Problem and closest work

The target contract is equality to the **same serial compressed model**, not equality to a full-KV model. Online eviction changes a model's next-token distribution; speculative execution must preserve that changed target if it claims serial equivalence.

The pinned [R-KV port](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/docs/OPTIMIZATIONS.md#L448-L454) explicitly rejects speculative/multi-token decoding because destructive eviction runs before acceptance. This is an unsupported combination guarded by the implementation, not evidence that the supported release silently fails. Its [query accounting](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/rkv/integration.py#L482-L610) advances the query ring per forward and records a final query row; speculative adaptation needs accepted-token-granular metadata.

Relevant recent primary work:

- [VeriCache](https://arxiv.org/html/2605.17613v1), submitted **2026-05-17**, already uses verification to recover full-model behavior. Full-KV verification is therefore not the novelty proposed here
- [Dustin](https://arxiv.org/html/2606.24957v1), submitted **2026-06-23**, uses draft lookahead and target history for sparse target verification while retaining historical KV allocation
- [Transformers PR 47447](https://github.com/huggingface/transformers/pull/47447), merged **2026-07-22**, implements sliding-window rollback support; merge pin [bd970fda476f204f9852fb551aa07a4b3fbc5540](https://github.com/huggingface/transformers/commit/bd970fda476f204f9852fb551aa07a4b3fbc5540)
- [TreeWY](https://arxiv.org/html/2608.20961v1), submitted **2026-08-21**, already replaces hybrid recurrent per-node snapshots with tree-structured verification and accepted-state reconstruction. Generic reversible hybrid-state caching is not an open fallback. No author code pin for TreeWY, Dustin, or VeriCache was verified here

### Two distinct hazards

Cropping rejected KV is insufficient if rejected queries remain in importance histories, query rings, counters, or physical-position metadata. Separately, even accepted-only metadata does not ensure equivalence if verification crosses a serial eviction boundary before applying that eviction. The second mismatch can occur when every drafted token is accepted.

A scalar attention witness establishes the second issue. At the boundary, cached key/value pairs are a=(0,-1), b=(1,+1), d=(0,0). Protect recent d and keep the old token with highest attention. A boundary query ln(3) keeps b. For the next query -ln(3), append c=(0,0):

- Serial eviction attends to {b,d,c}, producing z=1/7
- Deferred eviction attends to {a,b,d,c}, producing z=-1/5
- With output logits [z,0], token-0 probabilities are 0.53565367 and 0.45016600
- The total-variation difference is 0.08548767 and greedy decoding flips

This constructed arithmetic witness is not a measured R-KV quality regression or evidence of prevalence.

### Simple control and CPU experiment

Cap each verification segment at the next canonical eviction event in logical attention/query positions. Commit only accepted KV and their query/counter state; apply the unchanged compressor at that event; then continue. Handle the speculative bonus-token convention explicitly rather than counting “generated tokens” ambiguously.

Between such events the cache is append-only and causal. By induction over events, boundary-capped execution should equal the serial compressed target in exact arithmetic if metadata, positions, ties, and eviction inputs match. A no-compression block-versus-serial control measures ordinary floating-point differences.

Minimal pilot: a one/two-layer toy attention state machine, the witness above, fixed accepted traces, and varying rejected suffixes. Compare serial, crop-only, accepted-only with deferred compaction, and boundary-capped transactional execution. Measure kept original positions, query-ring content, counters, logit/TV differences, and greedy disagreement. Include no-boundary and no-rejection controls. This needs no pretrained model and well under 128 MB RAM.

A later Qwen2.5-0.5B CPU check could use eight fixed prompts, 512–1,024 tokens, budgets 64/128, buffers 16/32/128, verification widths 2/4/8, and acceptance lengths 0 through the width. It would test semantics, not GPU speed.

The paper's buffer is 128 and its observation window is eight. For width eight under an illustrative uniform boundary phase, only 7/128 = 5.47% of proposed blocks cross a boundary and clipping loses an average 2.73% of proposed slots. This is a simple phase-model calculation, not measured performance; aligned all-accepted blocks can avoid this loss entirely.

Kill the main-method claim if the boundary-capped control is equivalent and costs little verification work. A complex reversible eviction mechanism would have to beat this safe control on actual overhead, not merely beat an unsafe crop-only implementation. At present this looks like a useful integration task rather than a research main.

## CPU feasibility and model matching

Read-only environment checks in this pass found about **9.0 GiB available RAM**, **11 GiB free filesystem space**, NumPy available, and no installed torch, transformers, or safetensors in the active Python runtime. Treat the requested 9 GB RAM / 10 GB disk envelope as the planning ceiling. Do not install the previously staged CUDA dependency set merely to run these small CPU tests.

All first-stage tests above can run in NumPy or the Python standard library with no model download. For any later pretrained test, a useful small candidate is [Qwen2.5-0.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct), released September 2024 and therefore an older experimental substrate rather than recent novelty evidence. Its official [license](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/blob/main/LICENSE) is Apache-2.0. The verified initial model/config upload is [eaa56b503cc0a8a4d15de1dd8bd2a7e95a716be2](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/commit/eaa56b503cc0a8a4d15de1dd8bd2a7e95a716be2), dated 2024-09-16. That page records a 988,097,824-byte safetensors file; no bytes were downloaded. Resolve the complete chosen current model/tokenizer/license revision again before executing, rather than treating this initial config pin as a fully audited asset manifest.

Feature matching from the official [small configuration](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/blob/main/config.json) and [Qwen2.5-Math-7B configuration](https://huggingface.co/Qwen/Qwen2.5-Math-7B-Instruct/blob/main/config.json):

| Property | Qwen2.5-0.5B-Instruct | R-KV's Qwen2.5-Math-7B-Instruct substrate |
|---|---:|---:|
| Model family | Qwen2ForCausalLM | Qwen2ForCausalLM |
| Query heads / KV heads | 14 / 2 | 28 / 4 |
| GQA queries per KV head | 7 | 7 |
| Head dimension | 64 | 128 |
| Layers | 24 | 28 |
| Sliding window enabled | No | No |
| RoPE theta | 1,000,000 | 10,000 |
| Context limit in config | 32,768 | 4,096 |
| Tied word embeddings | Yes | No |

This matches GQA grouping and the causal full-attention family needed for the scorer/state contract tests. It does **not** match reasoning capability, width, head dimension, RoPE frequencies, training, or the original Qwen3-8B project. Therefore a pass supports a local mechanism check, not a forecast of 7B/8B benchmark improvements.

At FP32, roughly 0.49B parameters imply about 1.96 GB weight storage before runtime overhead. KV is 2 (K and V) × 24 layers × 2 KV heads × 64 dimensions × 4 bytes = **24,576 bytes per token**, or 12 MiB at 512 tokens and 24 MiB at 1,024. One model in a no-gradient, batch-one process, sequential arm evaluation, and small prefill chunks is plausible within the envelope. Measure peak RSS; avoid simultaneously keeping duplicate models, full vocabulary logits for all positions, all-layer quadratic attention matrices, or multiple virtual environments. Runtime/package download size and CPU speed remain unverified.

## Why other fresh sounding pivots were not promoted

Fresh primary-source screening also found direct overlap for several tempting alternatives:

- RoPE-commuting vector quantization: [CommVQ, ICML 2025](https://arxiv.org/abs/2506.18879), with [author code](https://github.com/UMass-Embodied-AGI/CommVQ)
- Cross-adapter cache reuse/recovery: [CacheReforge](https://arxiv.org/abs/2609.30884), 2026-09-25, and [PReCache](https://arxiv.org/abs/2609.34054), 2026-09-28, directly address evolving adapters and low-rank shared-prefix reconstruction
- General teacher-forcing versus live-cache evaluation or resident/read-bit separation: [Geodesia-KV](https://arxiv.org/abs/2608.23599), 2026-08-19, already makes these distinctions
- Generic safety degradation from eviction: [The Pitfalls of KV Cache Compression](https://arxiv.org/abs/2510.00231), submitted 2025-09-30 and revised 2026-05-13, already examines multi-instruction behavior and system-prompt leakage

These were screening exclusions, not reproduced baselines. Their absence of a fully audited code pin here does not make the problems unoccupied.

## Promotion rule and stopping point

For a new main direction, require all of the following before GPU discussion:

1. A precise limitation in a supported configuration, distinguished from documented unsupported combinations and counter mistakes
2. A smallest counterexample or natural CPU trace showing the mechanism, with negative controls
3. A simple strong baseline that does not already close the gap
4. A specific delta from the closest 2025–2026 paper and current author implementation
5. A reason the remaining finding matters beyond one tiny model, contrived transformation, or broken counter
6. A bounded next test with actual-byte accounting and predeclared failure criteria

None currently satisfies all six. Candidate B remains the most informative next CPU-only screen, not an approved main project. If its common-mask/shared-full controls close the opportunity, record the negative boundary and stop rather than adding complexity. Candidates A and C should not trigger asset downloads merely to turn obvious controls into large experiments. The previous calibration direction remains diagnostic-only; the TensorRT NVFP4 backup remains unsuitable for the intended RTX 5090 path. The closed multiSource, QCFuse, and P3 projects are not reopened.

## Bounded one to three day decision plan

This is an estimate for reaching a direction decision, not a promise of a positive finding or a finished paper. No stage authorizes GPU use.

**Day 1, no downloads:** implement Candidate B's one-layer NumPy allocation fixture and independently verify distinct backing storage, parent/child aliasing, compacted-mask union, page rounding, and overlapping live consumers. Freeze the exact question and expected formulas before running it. Include the shared full/common-mask/read-subset controls. Produce a compact measured-byte table and retain correctness checks. The existing algebraic A/C witnesses can become small regression checks, but do not expand them into separate projects. If the only finding is the already identified accounting error or the elementary union formula, stop any new-method claim immediately.

**Day 2, conditional small-model evidence:** proceed only if Day 1 leaves a specific unresolved quality/read/storage tradeoff, and designate that narrow question before acquiring assets. Resolve a full public model/tokenizer revision and prepare one isolated pinned CPU-only environment. Budget roughly 1.1 GB for Qwen2.5-0.5B assets; inspect exact dependency transfer/install size before installation, with a conservative 3 GB total incremental disk ceiling and abort-before-allocation guards. Begin with eight 256-token contexts, four questions each, and no more than 32 generated tokens per question, processing arms sequentially. Capture states/masks rather than storing all dense attention matrices. Validate uncompressed competence on the chosen simple tasks before interpreting compressed failures; otherwise the model is an unsuitable substrate.

**Day 3, decision only if needed:** repeat the small natural-trace contrast with disjoint contexts, sweep the two physical/read budgets, and inspect paired errors. Promote only if the effect survives shared full/common-mask/union controls and corresponds to a precise mechanism absent from the closest work. A suggested screen is a reproducible frontier gap of at least 10% unique bytes at matched read budget and quality, or at least 2 absolute quality points at matched bytes and reads; these are project gates, not a significance claim from 32 questions. Such a tiny pilot can justify another CPU study, not establish generality. If no gap survives, the result is “none of the screened directions qualifies”; stop without GPU rental or escalating to 8B. If setup or model competence blocks the test, report that exact blocker rather than treating missing evidence as either success or failure.
