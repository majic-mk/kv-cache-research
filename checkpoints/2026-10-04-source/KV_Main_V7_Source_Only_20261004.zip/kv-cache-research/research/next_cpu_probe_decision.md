# Decision: do not launch the next CPU checkpoint

**2026-10-03 UTC. NO-GO under the current protocol/resources; stop this seed at its published 0.8B competence failure.** A single independently declared stronger-model qualification could be scientifically legitimate, but it is not presently the most useful next experiment. It would establish a usable substrate, not test a new repair. The released-HYPIC comparator remains blocked, no economical repair mechanism has been proposed or demonstrated in this seed, and the unchanged FP32 execution path has insufficient demonstrated memory margin. Do not escalate checkpoint size merely to obtain a positive.

## What the failure does and does not establish

The [preserved result](diagnostics/hybrid_cpu_competence/RESULTS.md) is one completed full-recompute cell: d01/A1 answered blue rather than red. The other 15 initial cells did not run. This falsifies this task/model gate, not the general conditioning hypothesis. No cache comparison, parity result, or HYPIC quality result exists. Keep both historical freezes, the failed answer, loading/logging incident, and all costs unchanged.

The [architecture screen](architecture_specific_gap_screen.md) identifies an already acknowledged cross-layer conditioning limitation. The [source audit](diagnostics/hybrid_recurrence_cpu/SOURCE_AUDIT.md) establishes a separate blocker: the released pin can apply a full cached B tuple after a fresh seam, and cold traces can include warmup context. A seam-excluded, explicitly source-conditioned reference would be useful for isolating the known mathematical question, but remains a **corrected HYPIC-inspired reference, not released HYPIC reproduction**. Even a positive answer-loss/donor result would diagnose a known problem; it would not establish a new method or practical benefit. A competence-only run cannot resolve either scientific obstacle.

## Exact candidate pin and size

The smallest stronger official same-family candidate examined is **Qwen/Qwen3.5-2B**, post-trained dense hybrid, Apache-2.0, revision **`15852e8c16360a2fea060d615a32b45270f8a8fc`**. Its pinned config retains 24 language layers: 18 GDN and six full-attention layers, with 2048 hidden width and tied embedding/output weights. It uses the same official Transformers model family and PyTorch CPU fallback already exercised by 0.8B. This is source-level CPU compatibility, not an executed 2B guarantee. The model card reports stronger general benchmark results; those are author reports, not evidence it solves these fixtures. [Official model card](https://huggingface.co/Qwen/Qwen3.5-2B/blob/15852e8c16360a2fea060d615a32b45270f8a8fc/README.md), [config](https://huggingface.co/Qwen/Qwen3.5-2B/blob/15852e8c16360a2fea060d615a32b45270f8a8fc/config.json)

The [official file metadata](https://huggingface.co/api/models/Qwen/Qwen3.5-2B/revision/15852e8c16360a2fea060d615a32b45270f8a8fc?blobs=true) and bounded safetensors-header reads establish:

- One shard: **4,548,221,488 bytes**; official LFS SHA-256 **`aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`**
- Text: **320 tensors / 1,881,825,088 parameters**; stored payload **3,763,655,360 bytes**, comprising 1,881,822,496 BF16 and 2,592 FP32 elements
- Excluded vision: 331,416,576 parameters; excluded MTP: 60,828,160 parameters. Total checkpoint: 2,274,069,824 parameters. Do not estimate text RAM from the advertised “2B” or the complete multimodal count
- Header length: 76,648 bytes, SHA-256 `ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d`; tensor names exactly match the pinned index. Only bytes 0–7 and 8–76,655 were retrieved from the shard. **No tensor payload or weights were downloaded**

Metadata, header, hashes and host snapshot are retained in ignored `outputs/next_cpu_probe_metadata/`. The parameter count is an exact header-derived prospective text count, not a newly loaded model measurement.

## Resource gate

At 16:17:54 UTC, actual free disk was **9,183,465,472 bytes**. The shard alone would leave **4,635,243,984 bytes**, already **364,756,016 bytes below** the 5 GB reserve, before additional tokenizer/metadata copies or run outputs. The old Qwen3-8B directory occupies 16,397,484,060 logical bytes; deletion could address disk only, requires a separate parent decision, and was not performed. Actual reclaimed blocks must be remeasured rather than assumed from logical size.

FP32 text parameters require exactly **7,527,300,352 bytes = 7.010 GiB**, leaving only **1,062,634,240 bytes = 0.990 GiB** beneath the **8 GiB process RSS** cap. The existing 0.8B run peaked at 5,082,800,128 bytes against 3,009,572,096 parameter bytes: **2,073,228,032 bytes** additional RSS. Even holding that overhead constant would put 2B at **9,600,528,384 bytes = 8.941 GiB**, exceeding both the process cap and 9 GB host budget. This is a warning extrapolation, not a measured 2B peak or proof that every imaginable loader fails. The current load/cast path has no demonstrated safe margin, and staging/mappings can grow. Do not claim fit or develop a new loader just to rescue this seed.

The host reported 10,451,460,096 total bytes, about 8.31 GB available, and no swap; the declared lower budgets still apply. Hardware advertises AVX512-BF16 and the installed Torch 2.9.1+cpu confirms AVX512-BF16 support and enabled oneDNN. **No BF16 operator or model parity was tested.** BF16 storage is promising, but hardware flags do not validate the complete graph. The pinned GDN fallback explicitly accumulates in FP32. Changing projections/attention/conv to BF16 would change numerical behavior and invalidate silently carrying over FP32 tolerances; it needs its own pre-outcome operator, cache-state-dtype, scheduling and parity controls. BF16 is therefore not an approved workaround in this decision.

## Narrow condition for ever reopening

Only reconsider if there is a concrete, independently reviewed scientific next step beyond model qualification: an explicit corrected-reference estimand and source-warmup contract, with the released comparator separately specified or the narrower claim expressly amended. Resolve memory/disk feasibility first, without GPU, raised caps, or an open-ended model ladder.

If one 2B qualification is then separately authorized, declare it exploratory model selection prompted by the recorded 0.8B failure. Preserve all **16 groups / 32 changed-prefix contexts plus 32 unrelated controls**, texts, golds, split, order, scoring and stopping rules. Create a new model-specific freeze and rerun all 64 token/template integrity checks before outcomes. The official tokenizer payload hash matches 0.8B, but tokenizer configuration and chat-template bytes differ, so the old validation cannot simply be relabeled. Run only the same at-most-16-cell initial full/exact gate, stop on the first competence/parity/resource failure, and retain all failures. Passing it does not authorize the remaining matrix or resolve HYPIC semantics.

**Current action: retain the negative result and close the CPU seed.** No prompt/gold changes, model retry, new implementation, installation, weight acquisition, model forward, asset eviction, paid resource, GPU, or commit was performed in this assessment.
