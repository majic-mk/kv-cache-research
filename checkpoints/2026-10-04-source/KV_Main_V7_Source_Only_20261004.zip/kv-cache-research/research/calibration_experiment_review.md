# Independent calibration experiment review

Date: 2026-10-03. Scope: `echo_pilot/calibration_experiment.py`, `echo_pilot/calibration_experiment_analysis.py`, their new tests, the frozen development plans, and their interaction with the existing baseline and calibration adapter.

## Verdict

**Ready for a reviewed CPU/software checkpoint within the stated scope.** Four concrete defect groups were independently reproduced, fixed by the implementation author, and retested. No remaining blocking defect was found in this review. The new entrypoint and offline archive validator can be retained as CPU-validated scaffolding; real-model execution remains gated.

No GPU, pretrained weights, new dependency installation, resource allocation, commit, or push was performed. This verdict is not GPU readiness, execution authorization, a baseline release, or research-quality evidence.

## Findings fixed and independently retested

### 1. Frozen dataset metadata was checked too late

`check_config()` initially accepted a validly shaped but incorrect `dataset.source_revision`, while offline `_data()` rejected the same metadata against the pinned data manifest. A run could therefore pass the pre-execution gates, pay for the full screen, and become impossible to analyze. The independent reproduction changed only that revision to forty `f` characters in the existing test config: pre-execution accepted it and offline analysis raised `Dataset source/preprocessor pin mismatch`.

The final implementation binds pinned dataset source/preprocessor metadata in the frozen screen protocol before any model load and shares `check_protocol()` with the baseline release gate. The original independent revision-mutation reproduction now fails immediately with `Dataset source/preprocessor metadata differs from frozen screen`.

### 2. Late envelope failure lost paid build accounting and owned cache cleanup

An independent native tiny-Qwen probe wrapped the actual `build_candidate()` and advanced the mocked deadline immediately after the candidate returned. `timed_call()` initially emitted both a completed event and a failed event, then raised a plain `ContractError` without the completed build's forward accounting. `execute()` had not received the return value, so neither `candidate` nor `first` owned it; the candidate retained both cache layers, and no build ledger was written. Model masks did clear.

The same ownership gap can occur if synchronization, memory capture, or completion logging fails after a successful call. The final wrapper retains successful-build accounting on envelope failure, clears its owned cache, drops its result reference, and emits completion only after the deadline gate. The original end-to-end native reproduction now retains all four charged exact passes, leaves zero candidate cache layers, clears model masks, and records only start/failure events. Added tests also cover synchronization and memory-capture failure. Model loading acquires outer ownership before device placement/evaluation; a native injected placement failure confirms that the entrypoint traceback frames retain no owned model reference and masks are cleared. This is a Python reference/contract assertion; it cannot establish immediate CUDA allocator release.

Independent reproduction: `/tmp/probe_experiment_deadline.py` (temporary reviewer probe; no real-model completion archive).

### 3. Event inventory did not enforce causal execution order

The initial validator checked unique operation membership and adjacent start/completion pairing, but accepted a resealed fixture whose full-exact diagnostic build was moved before model load and all sparse builds. It returned `validated_quality_only` with `c00000:full_exact:build` as the first operation. This contradicted the claimed sparse-before-full-label boundary. The same omission permitted generation-before-clone ordering.

The final validator enforces the exact frozen operation sequence independently of results-file order. Both the original diagnostic-before-load reproduction and the added generation-before-clone regression now fail. Normal reversed results-file order still produces identical quality output.

### 4. Baseline release accepted mismatched protocol and incomplete score evidence

The initial `check_baseline()` bound model, ratio, data digests and analysis-file hashes, but omitted the frozen sink/recency/chunk-size/seed protocol. Its isolated release-gate test accepted a baseline with sink count 9, recency 128, chunk size 1024 and seed 999. The existing baseline analyzer allows varying selection/seed, so a completed archive alone does not guarantee the unchanged smoke recipe.

It also did not parse the question-score or paired-score files: empty rehashed files were accepted if summary arm names were retained. The independent test mocked only `_completed()`'s already-complete boundary; it is a semantic gate reproduction, not a claim that the review fabricated authentic real-model evidence.

The final gate enforces the full frozen protocol and binds run identity, expected denominators, all question-score cells, paired references, and deltas. Its positive unit fixture and the mismatched-policy/seed, empty-score-file and wrong-run-ID negative regressions pass. The positive path remains an isolated CPU gate fixture, not a validated real-model baseline.

## Final independent validation

- Dedicated experiment CPU suite: **24/24 passed**
- Native experiment suite in the existing `/tmp/kv_tiny_qwen_cpu_20261003` environment: **5/5 passed**
- Existing tiny random-Qwen native integration suite: **12/12 passed**
- Calibration methods/control suite: **41/41 passed**
- Independent adversarial archive/analysis sweep: **14/14 passed again on the final implementation**
- Full dependency-light pilot suite: **164 discovered, 159 passed, 5 optional native skips**; the five skipped tests were separately run and passed in the existing native CPU environment
- General harness suite: **46/46 passed**
- Actual dirty-source `RunManifest` gate rejected execution with zero runtime calls and wrote only a failure marker; that check mocked the previously completed baseline boundary, not the source gate
- Both regenerated frozen plans passed default no-execution CLI validation
- Targeted `compileall` and `git diff --check` passed
- Both implementation modules and both test files retained identical hashes throughout final reruns

Final reviewed SHA-256 values:

- `echo_pilot/calibration_experiment.py`: `812b130f265a0c17df69b054ecccad9456ef5db5f8ab313d5a7c82d9f467323f`
- `echo_pilot/calibration_experiment_analysis.py`: `eeb1a627c347d7396a5491dd17041ce7ccc5c94bfa872f4b98c19ed388600be1`
- `echo_pilot/tests/test_calibration_experiment.py`: `ab55fd62c6649c62a0e8c46f928d14e70e1ada041cc3a0df33c7df15232f7809`
- `echo_pilot/tests/test_calibration_experiment_native.py`: `e18662d92f3a1f48628b5d659d570dc21ad4500b6b06d9928ab8ec3efcf9c8ea`

The independent 14-case sweep verifies rejection of a non-dense full-KV mask, nonfinite score, float64 capture, sparse/full anchor disagreement, edited oracle score, missing array, resealed extra file, symlink, failed event, duplicate JSON field, mismatched attempted-forward IDs, and incomplete result coverage. It also verifies nontrivial per-question arm pairing, results-order invariance, and absent confidence intervals for the single RepoBench context. Failed validation publishes no analysis-completion directory.

Temporary independent logs/probes are under `/tmp`; the implementation author's maintained tests and validation records are under `research/diagnostics/calibration_experiment/`.

## Scope and interpretations

- The plan freezes existing smoke8k development data only: two LCC contexts/questions and one RepoBench-P context/question, eight arms, eviction ratio 0.5 and one seed. There is no heldout or architecture/ratio/seed expansion.
- The common-microchunk replay is a named adaptation. It is not unchanged author EchoPress. Complete instruction/suffix/body token IDs and independent sparse/full forward ledgers are checked.
- First, uniform and random build independently. The full diagnostic pays for a fresh prefill and every chunk. Derived controls reuse paid observations and receive no independent deployable build-cost attribution.
- All query evaluations clone the original dense cache. Full KV explicitly clears masks and bypasses fake-key search; the new native tests verify this. Oracle masks are installed directly and cannot invoke candidate rescoring through the tested path.
- Sparse/full exact observations and virtual-score observations must agree exactly. Offline analysis recomputes sparse calibration, controls/oracles, logical masks, selection budgets, support diagnostics and tied allocations from the captures.
- Synchronized operation measurements, host/capture/serialization intervals and nested whole-context/run envelopes are not additive standalone deployment costs. Deterministic token/pass counts and attention-pair proxies are not measured FLOPs, time or money.
- Provider cost remains unobserved. A JSON accounting declaration is not provider proof, approval, enforced spending control or shutdown verification. Local deadline checks cannot preempt a stalled GPU call; resource-specific external enforcement and ledger reconciliation remain separate gates.
- Dense masks do not compact cache tensors. Backing-storage bytes may exceed visible tensor payload, including after deep clone. No physical-memory saving or serving-speedup claim follows.
- Quality uses the existing pinned LongBench code-similarity implementation. Each question is paired with its own first/full-KV result, and bootstrap draws use actual whole context IDs with shared draws. One context has no interval; two context clusters cannot support reliable significance, equivalence, power, or generalization claims.
- Artifact checksums and source identities establish internal consistency, not source authenticity or proof that real model execution occurred.

## Remaining release gates

This checkout is uncommitted; the real-model clean-source gate intentionally refuses it. There is no validated real-model baseline archive, complete verified installed GPU dependency lock, executed pinned pretrained tokenizer/model, BF16/CUDA parity result, provider ledger, or resource-shutdown observation from this review. Native evidence uses a tiny in-memory random Qwen3 model, CPU float32, a synthetic tokenizer, patched GPU timing/environment/loading gates for the internal orchestration test, and audited author modules rather than the entire installed kvpress/PEFT package. It creates no real-model completion archive.
