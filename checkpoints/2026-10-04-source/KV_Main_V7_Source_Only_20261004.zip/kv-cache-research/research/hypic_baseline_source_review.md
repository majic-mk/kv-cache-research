# Independent HYPIC baseline source review

Review date: 2026-10-03 UTC. Audited public HYPIC revision: `98147c01909004e66d98bcb18b886927d41b0ee5` (main). This review is read-only with respect to implementation. It inspected primary source, checked a dependency-free rational-arithmetic witness, and independently reran the other auditor's actual-source metadata fixture. It did not execute SGLang/Triton kernels, load a pretrained model, install packages, use a GPU, commit, publish, or contact upstream.

## Decision

1. **The ordinary Qwen GDN recompute path has a reachable source-level cold/hit contract defect:** a cold middle segment stores its full recurrent tuple, while a hit advances the recomputed leading seam and then applies that same full tuple. No inspected cache key, flag, token-index conversion, or kernel writeback convention cancels the duplicated recurrence.
2. **Ordinary multi-segment warmup is contextual, not an isolated-B forward.** The zero-start operation is local to tuple extraction. Forwarded GDN outputs carry the composed prefix; full-attention miss queries see preceding segments. Thus deeper cached tuples can depend on the warmup context even though lookup is token-only.
3. A clean suffix-only CPU reference can implement a clearly stated reading of the paper's seam algorithm. It must be labeled **a HYPIC-inspired intended-semantics reference/CPU port**, not execution of the released code and not reproduction of paper quality. Establishing superiority over actual HYPIC, or attributing actual HYPIC quality loss to deep conditioning, remains blocked by this baseline mismatch and absent kernel/checkpoint validation.
4. The defect does not invalidate the paper's fixed-input affine identity. It is also not evidence of any particular answer-quality loss, nor a novel repair mechanism.

## Primary-source provenance and upstream state

The [default-branch commit collection](https://api.github.com/repos/redai-studio/HYPIC/commits?per_page=3) and [branch collection](https://api.github.com/repos/redai-studio/HYPIC/branches?per_page=100), checked during this review, still return main at the audited pin. Its committer date is 2026-07-21 06:09:31 UTC. The only other listed repository branch, `bot/update-est-time-20260727`, points to `9d9b985b409b6759b2c786212d250d25b61809e2`. Direct file reads on that branch return the same four affected blobs below. Therefore no fix is present on either listed upstream branch. This is not a search of every fork or unpublished revision.

| File below `python/sglang/srt/` | Git blob at pin and other listed branch |
|---|---|
| `layers/attention/linear/gdn_backend.py` | `80fab5e638626d3cd87fafd9609b5dbaee69fc58` |
| `layers/attention/hybrid_linear_attn_backend.py` | `a31e9a8bfb67d5bc227b586fc2c358bffb8374fe` |
| `pic/picache.py` | `2be86895586b88a98840a75ce98777a56e9b43a7` |
| `model_executor/forward_batch_info.py` | `7a6d4e657fa219f8a2a606db5fb137fb05108145` |

The local `sources/gdn_backend.py` Git blob hash independently matches the connector's pinned blob. Local source copies are under `research/diagnostics/hybrid_recurrence_cpu/sources/`; further server, scheduler, tokenizer, memory-pool and FLA kernel files were read directly through the GitHub connector at the same pin.

The [all-state PR collection](https://api.github.com/repos/redai-studio/HYPIC/pulls?state=all&per_page=100) returned PRs 6–9, all open. [PR 7](https://github.com/redai-studio/HYPIC/pull/7) changes GDN addition-mode state composition; its inspected patch does not change recompute metadata or its compose loop. PR titles 6, 8 and 9 concern CI registration, addition admission, and allocator release batching. None is a merged correction to this baseline.

## Reachable path and guards

Use a normal supported Qwen3.5 GDN server with `pic_enable=True`, `pic_mode="transition_rope_recompute"`, `chunked_prefill_size=-1`, `page_size=1`, no forced cache miss, adequate capacity, and an eligible segment B. The supplied quick test uses these PIC settings. [Policy](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/policy.py#L20-L43) maps this mode to transition composition, RoPE, and recompute simultaneously. [Server constraints](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/server_args.py#L6664-L6725) require unchunked/page-one prefill, select Triton linear kernels, and select no-buffer Mamba scheduling; they do not disable a cold or warm recompute branch.

Take three nonempty segments `SYS | B | Q`. Warm with B as a nonfirst, nonlast segment, allow the request to finish and register its cache, then issue another request with identical B tokens. SYS can be a hit or miss on replay. Q remains fresh.

1. **Segmentation and key.** [The segmenter](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/segmenter.py#L14-L48) strips separators and concatenates independently encoded parts, retaining half-open token offsets. The key hashes only B's token IDs, and [lookup](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py#L193-L234) also checks complete token equality. No prefix, absolute position or seam exclusion is encoded in that key. The cache is normally engine/mode scoped; this finding does not require mixing modes in one cache.
2. **Cold miss.** [PICache](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py#L264-L301) creates seams only for cache hits. [ForwardBatch](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/model_executor/forward_batch_info.py#L744-L827) supplies only that hit-seam map. In [GDN metadata](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L889-L977), every cold/miss middle segment therefore gets `x_sink_eff=0`, one full-length compute row, and a persistence mapping to its cache slot. The nearby “interior ONLY” comment does not make the row suffix-only.
3. **Allocation and registration.** [RoPE allocation](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/pic_alloc.py#L193-L246) gives a nonlast miss its own public/private attention slots and Mamba slot. [Cache registration](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py#L324-L409) indexes the resulting public KV and that Mamba slot under the complete B key. It does not strip a recurrent prefix or substitute a suffix tuple.
4. **Hit seam.** At replay B is nonfirst/nonlast and `n=|B|>=2`. A positive `PIC_SEAM_SINK` produces `w=resolve(spec,n-1)`, hence `1<=w<=n-1`. [Match-prefix lines 291–300](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py#L286-L301) remove w attention slots from the counted hit and put the first w absolute positions back into the forward batch. It retains the same complete-segment recurrent slot.
5. **Token offsets are genuine seam tokens.** [Request preparation](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/managers/schedule_batch.py#L1220-L1263) merges misses and seams in sorted absolute order; [batch input construction](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/managers/schedule_batch.py#L2078-L2097) selects the corresponding actual token IDs. [Allocation](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/pic_alloc.py#L215-L265) aligns private slots to those same positions. They are not dummy rows or the last w tokens.
6. **Dispatch really reaches the suspect method.** [Hybrid dispatch](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1126-L1180) initializes GDN PIC metadata and calls transition; [GDN transition](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1212-L1237) routes recompute directly to the three-pass method. The metadata initialization [returns after constructing recompute metadata](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L594-L605); ordinary transition metadata cannot repair it afterward.
7. **Actual composition.** [Passes and persistence](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1514-L1547) produce and store the cold full-B tuple. [The compose loop](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1556-L1605) first advances the fresh seam row and then the cached tuple. There is no subtraction, inverse, saved pre-seam rewind, or conditional skip between them. Its other docstring saying seam is output-pass-only is contradicted by the executed loop.

The default minimum cacheable length is -1 (all lengths eligible). Raising that threshold above n, disabling caching, evicting B, using a zero seam, using `n=1`, keeping B first, or choosing a non-recompute mode removes this specific witness. These are boundary cases, not an invariant that protects the standard nonzero-seam path. Very long forgotten segments or special fixed-point states may numerically hide the error without correcting the recurrence.

## Kernel-state convention does not cancel the discrepancy

The SGLang state is `[value_head,V,K]` and applies a cached tuple as `H_out = H_in @ T + U`. This is the transpose of the common `[K,V]` presentation. Pass 1 starts each row at zero and obtains U; pass 2 starts at identity with zero writes and obtains T. The [FLA kernel](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/fla/chunk_delta_h.py#L115-L126) reads the selected initial-state slot, and its [epilogue and wrapper](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/fla/chunk_delta_h.py#L274-L357) write the final state back to the same slot with `INPLACE_UPDATE=True`. Thus the temporary arrays copied to the pool are endpoint tuples, not untouched seeds. Pass 3 writes to a separate seeded workspace, after the request endpoint has already been assembled. It does not overwrite the cold pool with suffix data.

With fixed inputs, let `F_B(H)=H T_B+U_B`, and let W be B's seam. Correct full-B application is `F_B(H)`; the source hit path applies `F_B(F_W(H))`. The difference is

`[H(T_W-I)+U_W] T_B`.

This is not merely “adding the seam twice”: it repeats its transition/decay as well as its writes. If inputs change at replay there are additional errors, but they are unnecessary for this witness.

### Minimal exact witness

Let B have two tokens and w=1. In one active GDN state coordinate choose normalized key 1, gate beta=1/2, decay alpha=1/2 and value 2. Every token then applies `h <- h/4 + 1`. These gate values are finite and nondegenerate; the coordinate embeds in a larger head. Start with h=0 and keep the convolved inputs identical between cache creation and replay.

- Cold/full B: `T_B=1/16`, `U_B=5/4`, hence endpoint `5/4`
- Fresh one-token seam: endpoint `1`
- Source hit: `1*(1/16)+5/4 = 21/16`
- Suffix-only composition: `1*(1/4)+1 = 5/4`
- Source discrepancy: `1/16`

Python standard-library `fractions.Fraction` assertions were executed in this review and returned exactly these values. No model or kernel was run. The rational calculation validates the consequence of the source control flow, not a measured GPU error. An optional following token with nonzero transition preserves some difference; an appropriate query can read the changed coordinate, but this does not establish natural-language answer harm.

The separate [source audit](diagnostics/hybrid_recurrence_cpu/SOURCE_AUDIT.md) executes the unmodified Python-list portion of the actual GDN metadata builder. Its `SYS[0,2), B[2,7), Q[7,9)` fixture produces cold row lengths `[2,5,2]`, persisting the complete length-five B row; replay with seam positions `[2,3]` produces `[2,2]`, then a seam-row-plus-pool compose plan. The stdlib fixture was independently rerun successfully with `python research/diagnostics/hybrid_recurrence_cpu/source_audit/run_metadata_fixture.py`; [raw results](diagnostics/hybrid_recurrence_cpu/source_audit/metadata_results.json) identify its extraction boundary. This corroborates the source reading without importing SGLang or pretending to execute its numerical kernels.

## Warmup context, full attention, convolution, and position controls

**Zero-start tuple extraction does not imply isolated network inputs.** In cold ordinary `SYS | B | Q` execution, the output pass seeds each GDN compute row with the composed preceding state. Those outputs become the next layer's inputs. In full-attention layers, the actual [Phase A/B/C dispatch](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1503-L1523) uses Phase A only to stage KV, then sends all local-miss queries into cross-segment Phase C. The [Qwen planner](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1829-L1975) includes every preceding segment plus the causal prefix of B. Its output is scattered back to B's forwarded rows. An older isolated-attention docstring is not the operative behavior.

Consequently, source cache entries are trace-dependent on the context of their first accepted construction. The supplied warmups contain SYS, so “isolated B” is inaccurate even though the documents are warmed in separate requests. Keeping SYS fixed and warming `SYS | B | Q` is a legitimate explicitly specified cache-generation policy, but it differs from computing B alone. This review does not generalize the ordinary warmup result to every distributed scatter path; those require their own execution contract.

Other details that must remain explicit in a CPU port:

- [Convolution tails](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/conv_tails.py#L115-L180) contain raw pre-convolution projected `mixed_qkv` rows. The recompute path captures complete cold segment tails, supplies the preceding segment's tail to fresh seam convolution, and leaves a hit's cached end tail in place for its successor. This does not remove any recurrent seam term. Very short segments need a separate continuity test because persisted tails are zero-padded locally.
- [Public keys](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1555-L1585) are segment-relative `R(j)k`, obtained by removing the old segment start, not fully unrotated token keys. Restore the new start with the same fixed frequency basis; preserve the nonrotary dimensions and V. Seam KV overwrites private slots only.
- [ForwardBatch positions](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/model_executor/forward_batch_info.py#L942-L962) and Qwen's `pic_rope_positions` preserve actual absolute positions of packed misses/seams. Packed index plus cached-token count is not an equivalent coordinate system.
- [Seam syntax](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/__init__.py#L8-L18) uses `(0,1]` as a ratio and values above 1 as a count; literal `1` does not mean one token. Width is capped at n-1. “All B freshly recomputed” is therefore an adapter diagnostic, not a supported source seam setting.
- Independently tokenizing separated parts can differ from tokenizing their concatenation. Use one fixed token array and boundary map for every quality arm. The tokenizer has `PIC_DIAG_FORCE_SPLIT=1` support, but the quick script's separator-free baseline text does not by itself prove identical tokens.

## What a defensible clean CPU baseline can establish

The [paper, Sections 4.2–4.3](https://arxiv.org/html/2607.01299v2#S4.S3), describes excluding the seam from cached recurrent accumulation, then composing the freshly computed seam and reusable suffix. It also limits layer exactness to identical input hidden states and distinguishes that from deeper network drift. The paper therefore supports a suffix-only mathematical construction; the inspected release does not implement that cold/hit contract consistently. This review does not infer which code/configuration produced the published results.

A fair diagnostic reference must declare, freeze and test:

1. Its cache-generation context, including system tokens, attention visibility, convolution history, and positions
2. A complete source forward trace through B, followed by suffix-only tuple extraction from the existing convolved/projected trace; do not regenerate B's suffix as a separate sequence
3. Fresh target-prefix seam exactly once followed by cached suffix; preserve all full-attention KV, positional correction and conv end-history choices
4. Author-literal behavior as a separate identified source witness, never silently mixing its contextual warmup with an “isolated” description
5. Identical-token exact-prefix and sequential-chunk controls, fixed-input affine parity, nonsymmetric/noncommuting transitions, grouped-head conventions, and a full-recompute limit
6. Checkpoint/fallback parity and independently reviewed end-to-end adapter execution before reporting any natural-model result

If the adapter additionally recomputes the first `conv_width-1` interior projected/convolved rows from fresh seam history, record this as an extra boundary-convolution repair and include its compute. It is stronger than simply applying the cached suffix tuple and is another reason the adapter cannot silently stand in for the pinned runtime.

The clean reference is sufficient for a conditional statement such as “under this explicitly defined seam-corrected reuse scheme, frozen suffix inputs miss a cross-layer contextual effect.” Without baseline parity it is insufficient for “HYPIC fails by X,” “we outperform HYPIC,” or a new-method quality claim. A source bug repair is an engineering correction; it must not be counted as a research contribution or allowed to inflate the apparent benefit of a proposed conditioning repair.

**Current evidence boundary:** source/control-flow defect and exact algebraic witness established; ordinary warmup context dependence established; actual SGLang kernel magnitude, pretrained answer impact, paper-result replication, runtime benefit and novelty remain unestablished.
