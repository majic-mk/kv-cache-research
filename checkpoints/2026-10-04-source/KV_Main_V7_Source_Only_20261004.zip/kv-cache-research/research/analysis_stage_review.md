# Independent review of offline analysis and staged admission

Date: 2026-10-03 UTC. CPU-only review of the working tree, including `echo_pilot/analysis.py`, `stages.py`, their tests, the runtime and CLI they consume, `research/cpu_readiness_review.md`, and stage documentation. Authors were active during review. No implementation files were edited by this reviewer. No GPU, dependency installation, checkpoint download, provider action, remote write, commit or push was performed.

## Initial findings sent to the owners

These findings describe the initial reviewed implementation. They are not a claim that the fixes are still outstanding; see the final verification addendum below when present.

### 1. Valid package lock serialization can make a completed archive unanalyzable

**Priority: P1, release-blocking interface mismatch. Owner: analysis/CLI.**

`validate_inputs` accepts a valid JSON package lock regardless of formatting and verifies its raw byte hash against the frozen config. `cli.run` then archived the parsed object through `write_json`, changing whitespace/key order. `_completed` requires the archived file byte hash to equal the original config pin. Thus a legitimate compact lock passes input validation but the emitted completed archive fails analysis with `Archived package lock digest mismatch`.

The independent probe validated a compact source lock and used the exact CLI writer. The source SHA-256 was `78a6844aa72df346279f8967523e7b5ef2b1e32174cd26c02846a850d98a7de8`; the rewritten archive was `d28d8eeeebb6c13000fd1d4a07ce332601614e83bb625268c39c283ca62b1782`. Fixture archives had hidden this because they pin the already rewritten archive. Preserve verified input bytes or define an explicit canonical-hash contract; do not weaken the pin to accept arbitrary changes.

### 2. Pair-equal reconstruction drift passed strict analysis

**Priority: P1, provenance/invariant gap. Owner: analysis.**

The original chunk validator checked contiguity, replay lengths, forward counts and Echo-versus-matched-KVzip equality, but did not reconstruct the expected replay from the pinned context, suffix and prompts. Changing a body token to `123456` in the same first replay of Echo and matched KVzip, then resealing the fixture archive, still returned `validated_quality_only`.

The audited author sources define the actual replay as first/later prompt IDs, then the previous chunk's last up-to-eight tokens for later chunks, then suffix IDs, then this chunk's context token IDs. KVzip uses native `chunk_size` bodies; Echo/matched KVzip use first `chunk_size - first_prompt_length - suffix_length`, then `chunk_size`. Both content and boundaries should be independently checked. The initial fixture's `[99] + body + [9]` replay and identical native/matched 5/5 boundaries did not represent that format.

Resealing is deliberate in this probe: raw file tampering is already detected by artifact hashes. The issue is whether self-consistent producer metadata can violate the independently specified reconstruction protocol.

### 3. Known-impossible 45-minute first inference was admitted

**Priority: P1, scenario admission false positive. Owner: stages.**

With only the smoke RepoBench invocation remaining, 2,600 accounted first-gate seconds, zero additional setup/load, and a declared prefill throughput of 30 tokens/second, the first 5,765-token full-KV prefill completes no earlier than 2,792.17 paid seconds. This exceeds the 2,700-second useful-inference deadline even before query processing. The original estimator returned `planning_admitted` because it checked only elapsed + setup + model load against that deadline.

Include the work required to reach the first useful output under the same supplied throughput assumptions. This is an internal consistency rejection, not a claim that any throughput scenario guarantees real inference. The existing admission explicitly denies execution authority, so this finding did not create authorization or spend.

### 4. Useful-inference timestamp was checked against another resource's time

**Priority: P1, resource-specific accounting gap. Owner: stages.**

A target-resource useful-inference record at second 900 was accepted with no accounted target-resource time when a different allowed project resource supplied 1,000 first-gate seconds. Shared gate elapsed is appropriate for the shared cap, but not sufficient to validate the target record's timestamp. Keep target-resource elapsed separate for this check. This probe also returned `planning_admitted` initially.

## What the initial passing tests do establish

- Full expected task/preset/split coverage, question/context identity, all arm/ratio cells and one full-KV reference per context are checked
- Duplicate/missing cells, wrong labels/query/context digests, broken completion markers, artifact drift, unexpected files, mask-budget violations and protected-token deletion are rejected in synthetic archives
- Natural/controlled workload evidence is separate from execution evidence; fixture analysis needs an explicit opt-in and remains `cpu_fixture`/`fixture_only`
- Official pinned code similarity is used, including empty-text outputs, rather than replacing it with exact match
- Context-cluster bootstrap uses question-weighted means, carries all questions in a sampled context together, does not make ratios/reused full-KV into clusters, and gives no identified interval for one context
- The frozen stage recipe independently matches the pinned development inputs and expected 12+52 builds, 23+131 exact replays, four model loads and 13 distinct contexts; smoke repeats three contexts
- Decimal cost arithmetic includes hourly ancillary charges, one-time/unbilled reserves, shutdown reserve, billing-quantum rounding, first-gate and project ceilings, and resource-ID allowlists. No provider execution is present

## Verification limits: these are not Torch/model integration tests

The initial `python -m unittest discover -s echo_pilot/tests -v` passed 100 tests. The root harness suite passed 46. Stage `verify --retokenize` passed with the already installed CPU tokenizer environment. Compile and `git diff --check` passed. Authors were adding tests concurrently, so final counts may differ.

`importlib.util.find_spec('torch')` returned `None`. This review did not install dependencies. Therefore:

- Analysis happy paths load JSON fixture archives through `_fixture_masks`, not actual `torch.save`/`torch.load` tensor archives
- The missing-Torch test proves fail-closed behavior; a mocked `torch.load` full-KV test proves only the `map_location='cpu', weights_only=True` call contract
- Fixture masks do not execute Torch dtype/shape/indexing checks in the compressed `_torch_masks` branch
- Cache isolation/storage tests use `FixtureTensor`/`FixtureCache`, not Transformers `DynamicCache`, tensor views, real storage aliasing or fake-key mutation
- Generation tests use fake logits and vectors; they establish control flow, absolute position arithmetic and EOS behavior, not Qwen3 forward semantics, attention-cache growth, deferred-query fake-key feasibility or tokenizer decode parity
- Structural synthetic package locks used in stage construction do not prove an installed environment or CUDA wheel compatibility
- No actual full model run, real tensor round trip, kernels/cache hooks, measured speed/memory/quality or provider shutdown was validated

A CPU-capable Torch round-trip fixture would close an additional serialization/mask-check coverage gap, but even that would not establish CUDA/model compatibility. The paid-release prerequisites in the readiness review remain in force.

## Independent reproduction artifacts

The review's script and initial JSON evidence are at `/tmp/analysis_stage_review_probes.py` and `/tmp/analysis_stage_review_probes.json`; test logs are `/tmp/analysis_stage_review_tests.log` and `/tmp/analysis_stage_review_harness.log`. These scratch files are local review support, not model outputs. The authoritative retained summary is this report.

## Final verification addendum

All four initial defects were corrected by their owners and independently rechecked. A related fifth timing ambiguity was found during that recheck and corrected too: target-local success at second 900 after 2,600 seconds already consumed on another first-gate resource must not waive the shared 45-minute gate. The evidence record now requires both target-local and shared-gate first-success timestamps, with consistency bounds against accounted target/other/shared durations.

Observed final behavior:

1. CLI preserves raw verified package-lock bytes and checks the copied hash. The actual CLI writer path passes a compact-lock mocked-execution regression; a complete fixture with a compact pinned lock passes offline analysis. The mocked CLI execution itself does not represent an analyzable real-model run.
2. Analysis independently reconstructs every replay token and author-defined boundary. Shared Echo/matched context-token corruption and substitution of Echo boundaries for native KVzip fail. The replay fixtures now use the authored prompt/postfix/suffix/body ordering and distinct partitions.
3. The 2,600-second/slow-Repo-prefill scenario now returns `planning_rejected`; the reported conservative first complete answer occurs at 2,810.8467 shared billable seconds.
4. A target proof with no accounted target time is rejected, irrespective of another resource's elapsed time.
5. A target-local 900/shared-gate 3,500 success is rejected. A success at local 900/shared 900 can still be admitted when other resource spending happened afterward; the caller must supply and externally substantiate that chronology.

The success timestamp and rates remain caller evidence/scenarios, explicitly unverified by this read-only tool. No software arithmetic can establish provider resource identity, actual measured inference, complete bill attribution or effective shutdown without those external records.

Final independent checks:

| Check | Observed result |
|---|---|
| `python -m unittest echo_pilot.tests.test_analysis echo_pilot.tests.test_stages -v` | 83 passed: 45 analysis + 38 stages |
| `python -m unittest discover -v` | 46 passed |
| Entire pilot suite, during the coordinated update | 127 passed at that snapshot: 45 analysis + 35 stages + 38 contracts + 9 newly added adapter tests |
| `data_prep/local/venv/bin/python -m echo_pilot.stages verify --retokenize` | Passed |
| Independently compare non-fixture replay reconstruction against frozen natural build plans | All 64 builds' exact replay lengths and context-body sequences matched |
| Independent post-fix adversarial probes | Replay drift, impossible first-answer scenario, unsupported target timestamp and late shared success all rejected; valid early shared success preserved |
| `python -m compileall -q echo_pilot` and `git diff --check` | Passed |

Post-fix scratch evidence: `/tmp/analysis_stage_review_recheck.py`, `/tmp/analysis_stage_review_recheck.json`, `/tmp/analysis_stage_review_final_focused.log`, `/tmp/analysis_stage_review_final_harness.log`. The whole-pilot count above is a precisely labeled intermediate snapshot; it is not substituted for later final aggregate verification by the coordinator.

Reviewed post-fix implementation SHA-256:

- `analysis.py`: `087cc2a359c1466cf9b4498e7aabbd21dc374932da20811cfe76d53f902a9ce0`
- `stages.py`: `8d22f3b520451e63ea8bde0d37b9c848ff237212a20e6b59f5420b30dc24d1df`
- `cli.py`: `7a1f1da42f7fbafad79487a684fbec24abd41a2512f64418977f8dcfdf02c71c`
- Unchanged `runtime.py`: `a4092fbfc7c00ed43e108e8cf44c6d8fbb0cdc854025f1a106962ca9f3e96788`
- Unchanged `contracts.py`: `1bcf3321e9d37e85de24f3fe7ea9a2ecd9a8a4882468ffe8c772fd8ac801d9af`

**Review conclusion:** no additional reproducible blocker was identified in the reviewed CPU/static analysis-and-admission scope after these fixes. This is not blanket correctness, real Torch archive integration, real model execution, or GPU rental readiness. The explicit integration/environment/asset/resource-stop gates above and in the earlier readiness review remain unresolved. The concurrently developed calibration adapter was not part of this code review; incidental passing tests do not confer review approval on it.
