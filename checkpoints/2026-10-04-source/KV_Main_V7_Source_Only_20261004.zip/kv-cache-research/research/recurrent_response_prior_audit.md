# Recurrent segment response correction: prior-art and feasibility audit

Research cutoff: **2026-10-03 UTC**. This is a literature, source, and mathematical audit. No checkpoint was loaded, no method was implemented, and no model/dependency downloads, GPU work, commits, or publication were performed. Small standard-library arithmetic checks verified the counterexample and byte counts below. They are not model experiments.

## Decision

**No-go for promoting “cross-layer first-order / sketched-Jacobian correction” as a research topic in its current form.** The generic mechanism has substantive prior art, and its cheap input contract has not been specified. A narrowly defined hybrid-state response operator is not conclusively covered by the inspected papers, but absence of an exact match is insufficient novelty or feasibility evidence.

Three findings matter most:

1. **Low-rank input-response correction of cached neural activations already exists.** ICC, CVPR 2025, uses cached output plus a low-rank weight map applied to current-minus-cached input. For its linear operations, that weight map is the exact input Jacobian before truncation. RFC and DiCache additionally cover input-conditioned and shallow-probe-controlled correction of cached deep features.
2. **Low-rank cross-prefix cache deltas already exist.** KVCOMM, Kamera, and the September 28, 2026 KVCMAS paper cover progressively closer versions. Kamera explicitly reports unsuccessful cheap estimators of deep conditioning coefficients. Moving from token KV to recurrent state is a possible architecture-specific distinction, not a contribution by itself.
3. **Incoming recurrent states, convolution tails, and a finite leading seam are not generally sufficient to determine a hybrid segment's interior forcing.** A concrete stable-recurrence counterexample is given below. A Jacobian cannot recover information its online inputs omit.

The existing CPU result establishes **no answer-quality gap to repair**: the first full-recompute Qwen3.5-0.8B competence cell failed, so exact-prefix parity, reuse quality, donors, and response corrections were never measured. The source baseline issue also remains separate. See [the recorded competence stop](diagnostics/hybrid_cpu_competence/RESULTS.md) and [independent HYPIC source review](hypic_baseline_source_review.md). This audit does not authorize a larger model or another experiment.

## 1. Closest primary priors and exact overlap

### ICC: the closest algebraic overlap

[Increment-Calibrated Caching with Channel-Aware SVD, CVPR 2025](https://arxiv.org/html/2505.05829v1#S3.S3) computes

`y_new ≈ y_cached + W_a,r W_b,r (x_new − x_cached)`.

This is an actual low-rank response correction, not just similar terminology. The method approximates linear projections inside attention and MLPs; nonlinear activation, normalization, and attention operations still execute. Its correction costs `O(N r (C_in+C_out))` instead of a dense projection's `O(N C_in C_out)`, with input/output caches and factor storage. Channel-aware calibration uses 256 images. The distinction available here would have to be a response operator for an entire nonlinear recurrent segment, including cross-layer interactions and new prefix attention. Merely applying ICC's idea to GDN-associated projections would be an adaptation.

The [pinned author MLP implementation](https://github.com/ccccczzy/icc/blob/dafee02efc89cdfbe81395a5a8a8fbeb17cf9be4/DiT/models/models_sp_step_decomp.py#L91-L109) explicitly subtracts cached inputs, applies low-rank factors, and adds cached outputs. [Attention lines 176–221](https://github.com/ccccczzy/icc/blob/dafee02efc89cdfbe81395a5a8a8fbeb17cf9be4/DiT/models/models_sp_step_decomp.py#L176-L221) still evaluate attention after projection correction.

### Direct KV correction priors

- **[KVCOMM, NeurIPS 2025](https://arxiv.org/html/2510.12872v1#S3):** stores context-free base caches and observed prefix-dependent offsets; matches current cached representations to anchors and interpolates their offsets. It already treats cross-context reuse as additive cache correction without replay on accepted hits. It is an empirical anchor interpolator, not a boundary Jacobian. Anchor construction needs actual contextual caches, and full-dimensional anchor storage and matching must be counted. [Pinned code, lines 806–989](https://github.com/FastMAS/KVCOMM/blob/48ca0b376c7f4fbf1c24042c1709a6fe4148c959/KVCOMM/llm/kvcomm_engine.py#L806-L989) verifies weighted delta addition, rather than derivatives.
- **[KVCMAS, September 28, 2026](https://arxiv.org/html/2609.34060v1#S3):** factors both anchor base caches and contextual deltas, then chains correction from the preceding agent's already-produced cache. Its default paper setting uses rank 32 and up to ten anchors per slot. For a cache matrix `Z ∈ R^(n×d)`, stored factors require `r(n+d)` elements; accepted corrections reconstruct full target KV. This establishes low-rank, dynamically matched cross-prefix correction as occupied territory. It does not cache the derivative of an entire hybrid recurrent segment. [Author source](https://github.com/hjeon2k/KVCMAS/blob/e2170cf4b1790bd93f98d15e926397999d590867/KVCMAS/llm/kvcmas_engine.py#L594-L638) uses per-layer SVD of token-by-head-feature matrices; [lines 1318–1348](https://github.com/hjeon2k/KVCMAS/blob/e2170cf4b1790bd93f98d15e926397999d590867/KVCMAS/llm/kvcmas_engine.py#L1318-L1348) form observed target-minus-source deltas. This is not evidence of a low-rank context-to-state Jacobian.
- **[Kamera, June 2026](https://arxiv.org/html/2606.23581v1#A1):** adds a low-rank cross-chunk conditioning patch after positional relocation. Patch formation explicitly runs a conditioned forward of the chunk. Its [Appendix B](https://arxiv.org/html/2606.23581v1#A2) reports negative tests for per-antecedent linear operators, A-side streaming, and shallow predictors; shared output directions did not remove the need for item-specific coefficients. A never-seen antecedent still pays the forming forward. It explicitly excludes linear-attention/SSM state deltas from its operator's scope. This is close problem/repair prior and an especially important input-acquisition warning, not proof that our particular model must fail. No author-code pin was verified.
- **[GraphFlow, May 2026, §5.1](https://arxiv.org/html/2605.22566v1#S5.SS1):** uses a context-free base and sparse residuals for recurring workflow-prefix relations. It is another context-delta storage precedent; its inspected construction is neither a low-rank recurrent response map nor an arbitrary unseen-prefix solver. No author-code pin was verified.

### Diffusion forecasting and residual correction: relevant distinctions

- **[RFC, ICLR 2026](https://arxiv.org/html/2602.19506v1):** uses an input/output gain measured between full evaluations and the magnitude of the current input change to calibrate a Taylor-predicted output direction. This is current-input-conditioned first-order reasoning, but a scalar gain with a temporal direction rather than a matrix acting on arbitrary input perturbations. Its local-linearity and stable-direction assumptions are material. No author-code pin was verified.
- **[DiCache, 2025/ICLR 2026](https://arxiv.org/html/2508.17356v1):** fresh shallow probes determine a scalar extrapolation along a cached deep-residual difference. It therefore already covers cross-layer probe-controlled residual repair. The [author FLUX implementation](https://github.com/Bujiazi/DiCache/blob/fdbe20b669c9174bbed5ec994de073fd881c8010/FLUX/run_flux_dicache.py#L149-L154) clamps its coefficient to `[1,1.5]`. A probe cost and its potentially incomplete visibility of deeper changes remain.
- **[MeanCache, January 2026](https://arxiv.org/html/2601.19961v1):** describes cached JVP-based correction, but the [inspected `compute_current_jvp` implementation](https://github.com/UnicomAI/MeanCache/blob/2e12280abfa9be521ad65c300ac50ad51f426e21/MeanCache4Qwen-Image/Mc_qwenimage.py) estimates a trajectory derivative from latent displacement and velocity differences; it is not AD of a nonlinear module for arbitrary input directions. Historical tensors and offline schedule calibration are required. Calling our proposal “cached JVP” would still demand careful differentiation.
- **[TaylorSeer, ICCV 2025](https://arxiv.org/html/2503.06923v1):** estimates time derivatives from successive feature differences and forecasts in elapsed denoising time. Its [author functions](https://github.com/Shenyi-Z/TaylorSeer/blob/704ee98c74f7f04da443daa3c0aa2cc7803d86e3/TaylorSeer-FLUX/src/flux/taylor_utils/__init__.py) verify finite differences, not an input Jacobian. Higher orders store more feature-sized tensors. Time smoothness within one denoising trajectory does not imply smoothness between arbitrary LLM prefixes.
- **[Δ-DiT, June 2024](https://arxiv.org/html/2406.01125v1):** reuses `F(x_old)−x_old` and adds it to `x_new`, equivalent to an identity input-response term. This is older background, outside the main two-year window. [TeaCache](https://arxiv.org/html/2411.19108v1) and [FirstBlockCache's source](https://github.com/chengzeyi/ParaAttention/blob/4de137c5b96416489f06e43e19f2c14a772e28fd/src/para_attn/first_block_cache/utils.py#L238-L318) add refresh decisions based on input or first-block changes; neither establishes a full arbitrary-input Jacobian.

Additional screened distinctions: [ERTACache](https://arxiv.org/html/2508.21091v1) fits output-error correction and timestep adjustments; [SenCache](https://arxiv.org/html/2602.24208v1) uses first-order sensitivity estimates for refresh decisions; [MomentKV](https://arxiv.org/html/2606.01563v1#S3) uses first-order moment-based correction for evicted attention outputs; [Jacap](https://arxiv.org/abs/2609.08131) uses a softmax Jacobian in an eviction objective. These prevent broad first-order-attention claims, but are not the proposed hybrid segment response operator.

**Search conclusion:** no inspected primary source established exactly a sketched cross-layer nonlinear hybrid-segment boundary-response operator with sufficient full-attention context and a demonstrated cheaper-than-seam cost. This is a bounded search result, not a claim that no such work exists. None of the above performance claims was reproduced here.

## 2. HYPIC boundary and the object that would actually be new

[HYPIC §4.2–4.3](https://arxiv.org/html/2607.01299v2#S4.S2) already provides fixed-input affine recurrence composition and seam repair. Its [collaborator response](https://github.com/redai-studio/HYPIC/issues/10#issuecomment-5506131951) acknowledges deeper cross-segment context loss; discovering that loss again is not novelty. The existing source audit at `98147c01909004e66d98bcb18b886927d41b0ee5` also shows that normal warmup can be contextual and that literal nonzero-seam replay has a tuple/seam contract defect. A corrected CPU reference must remain labeled HYPIC-inspired, not a reproduced author baseline.

For one layer with its entire input sequence fixed, use the source orientation

`H_out = H_in T_B + U_B`.

The derivative with respect to incoming H is already exactly represented by `T_B`. Re-estimating that derivative is redundant. The missing object is the response caused by **changes in the segment's deeper inputs** and, in a hybrid, its prefix-attention forcing.

For a pure recurrent stack, concatenate all layer states and convolution histories into `z`. Fixed segment tokens define a generally nonlinear map `F_B(z)`. A first-order approximation of the complete map includes cross-layer terms. For a hybrid model the correct boundary object is instead

`z = (all recurrent states, all convolution histories, all full-attention prefix KV, masks/positions/RoPE metadata)`.

The full-attention component grows with prefix length. A function of only recurrent states is not generally `F_B`. Source/target arrays of unequal prefix length cannot be subtracted without an explicit alignment and mask/presence parameterization.

If `G_B` is the chosen seam-corrected reference, a principled response target is its **residual**

`E_B(z) = F_B(z) − G_B(z)`;

estimate `E_B(z0) + D E_B(z0)(z−z0)`. This avoids charging the already-exact frozen-input transition as a contribution. It also exposes what each oracle experiment actually gives the correction. `D E_B` is a standard derivative object; novelty would need a new, justified sufficient input representation, structure, or reuse economics.

Correcting terminal recurrent states alone cannot guarantee the future answer if the segment's full-attention KV or convolution state remains wrong. Treat these as separate output components and costs. Oracle full-prefix/segment hidden states diagnose a ceiling; they are not a cheap deployment input.

## 3. Irreducible information: an exact collision test

Let `g(A)` be everything the online correction sees about prefix A, including any measured seam. Let `f(A)` be the target corrected state or forcing. If two admissible prefixes obey

`g(A1)=g(A2)` but `f(A1)≠f(A2)`,

every deterministic correction from g produces the same estimate on both. Its worst-case error is at least `||f(A1)−f(A2)||/2`. Increasing response rank or offline probes cannot fix this omission.

### Stable scalar hybrid witness, with an arbitrarily long invisible seam

This is a deliberately constructed attention-plus-recurrence model, **not a claim of a natural-token collision in Qwen**.

- One scalar softmax-attention head has six prefix keys `[1,0,0,0,0,0]`
- All prefix queries are zero
- Prefix values are either `+[1,−2,1,0,0,0]` or the negative of that vector
- An upper scalar recurrence consumes attention outputs: `s_t=(1/2)s_(t−1)+o_t`, with initial state zero

The attention outputs over the prefix are respectively `+[1,−1/2,0,0,0,0]` and their negatives. In both cases the recurrent endpoint is exactly zero, and the last three attention outputs are zero. Identity short convolution can therefore have the same zero tail. The raw Q/K/V tails are also the same over the last three positions.

Now append the same B. Its first w tokens have query/key/value zero. Because the prefix values sum to zero, all w seam outputs and recurrent states remain exactly zero for both prefixes. At the next interior token set query 1, key 0, value 0. Its attention output, and hence recurrent state, is

`± (e−1)/(e+6+w)`.

The isolated-B cache, incoming recurrent state, tails, prefix length, positions, and every seam observation are identical; the required interior forcing is different. The complete prefix **V cache** distinguishes them. This disproves universal sufficiency of the recurrent-plus-tail-plus-leading-seam summary. It does not disprove a method that reads appropriate additional prefix information.

Executed stdlib checks gave exact prefix endpoint/tail equality and these numerical lower bounds on worst-case scalar error:

| Leading seam w | Minimum possible worst-case error from the deficient summary |
|---:|---:|
| 0 | 0.1970895025 |
| 8 | 0.1027786136 |
| 32 | 0.0421992715 |

These numbers have no language-model quality interpretation. The construction can be scaled; its point is missing information, not a claimed effect magnitude.

### Stronger test for a proposed compressed observation

For continuous prefix perturbations u, a necessary local condition for differentiable factorization `f=h∘g` is

`ker(Dg) ⊆ ker(Df)`.

Find a direction v with `Dg v=0` but `Df v≠0`, or inspect `Df (I−Dg†Dg)`. This is a direct insufficiency test. A numerical near-collision needs an explicit noise tolerance and matched output/readout difference; it is not an exact impossibility theorem for discrete natural prompts.

For fixed attention keys and queries, prefix-value forcing is linear: `O=A V`. A sketch/probe matrix R is sufficient for those outputs only if `ker(R)⊆ker(A)`. A null vector of R outside the nullspace of A is a weight-free falsifier. Adaptive probe selection does not escape a demonstrated collision between its complete observed transcripts.

## 4. First-order validity and low rank are separate gates

### Linearization at an empty prefix can already be poor in one attention head

With a fixed query, write the isolated segment's attention numerator/denominator as `(N_B,Z_B)` and prefix contributions as `(N_A,Z_A)`. Introduce prefix presence λ:

`o(λ) = (N_B+λN_A)/(Z_B+λZ_A)`.

Let `ρ=Z_A/Z_B`. The exact change from λ=0 to 1 is

`ρ/(1+ρ) · (o_A−o_B)`;

the first-order change at zero is

`ρ · (o_A−o_B)`.

Its error relative to the true nonzero change is exactly ρ. At ρ=1 it is already as large as the signal; at ρ=4 it is four times the signal. This is an exact model-free warning about an isolated reference, not a universal failure of all anchor choices. Computing `(N_A,Z_A)` permits exact state merging for that fixed query, but obtaining the correct deep queries and scanning their prefix keys/values is then part of the online work.

### Cross-layer response is not automatically low rank

1. With identical layer inputs, the vectorized GDN transition is a Kronecker-structured map derived from T. It is generally full rank. Small storage comes from structure, not generic low rank.
2. In the prior two-layer linear witness `s_t=r s_(t−1)`, `z_t=r z_(t−1)+s_t`, the joint transition is `[[r,0],[r,r]]`. Over n tokens, the missing cross-layer response is `n r^n` from incoming s to final z. Full joint first-order response is exact here; it is standard linear composition, not a new algorithm. A seam of w captures only `w r^n`.
3. Softmax attention can have full token-axis response rank even with scalar keys/queries. For distinct positive `x_j` and queries `q_i=i−1`, choose `k_j=log(x_j)`. The unnormalized attention matrix is Vandermonde, `exp(q_i k_j)=x_j^(i−1)`, hence full rank; row normalization preserves rank. There is no architecture-only guarantee that a few probes recover all forcing.
4. Low matrix rank of each state correction is different from low rank of a response operator. For example, each `ΔH_j=e_j vᵀ` is rank one, while the flattened corrections span as many independent directions as there are `e_j`. KVCMAS-style per-cache SVD, endpoint tensor rank, and context-to-endpoint Jacobian rank are three different claims.

The useful spectrum is that of **the residual response over the intended prefix-perturbation distribution**, optionally measured through fixed downstream readouts. A spectrum of isolated states or a few teacher-fitted endpoint deltas does not establish it. Readout-weighting must also account for future queries outside the calibration set.

## 5. Cost and storage: what must be paid

Use n segment tokens, m prefix tokens, D available input-summary coordinates, M output-state coordinates, r response rank, and b bytes per coefficient. Let `C_F` be a complete segment recomputation, `C_H(w)` the corrected HYPIC-inspired reference at seam w, and `C_in` the extra cost of obtaining response inputs.

| Construction | Additional storage | Build/probe work | Online work that cannot be omitted |
|---|---|---|---|
| Dense whole-segment Jacobian | `b M D` | Generic forward/reverse AD needs many directional derivatives; dense extraction is prohibitive at full state dimension | `M D` multiply-accumulates plus current input acquisition |
| Explicit rank-r `U Vᵀ` | `b r(M+D)` | Common two-sided randomized construction uses approximately r JVP and r VJP directions plus factorization; tape/recomputation must be charged | `r(M+D)` MACs, factor reads, output writes, `C_in` |
| Known input basis Ω and `JΩ` | `b M r`, plus Ω unless structured/shared | r directional JVPs, or r one-sided / 2r central finite-difference segment forwards | Coefficients of actual perturbation in Ω, projection residual, `M r` MACs |
| Empirical anchor residuals | Full deltas or factored cache tensors | Actual contextual forwards to observe deltas, fitting/SVD, pool refresh | Anchor matching, blending/materialization, fallbacks; close to KVCOMM/KVCMAS |
| Fresh directional JVP for every request | Saved trace/tape or its regeneration | Less persistent operator storage | A generic tangent pass still visits the segment/network; it is not constant-in-n or automatically cheaper than prefill |

`JΩ` alone does not provide a general low-rank approximation for arbitrary inputs. Projecting onto a random input basis may discard the relevant perturbation. A range basis U also needs `UᵀJ`, obtained by VJPs or additional observations. Batched derivatives can alter constants and memory, not erase their work.

Full-attention prefix reads are not free. A direct current-query pass over all prefix KV costs approximately `O(L_A n m h_q d_h)` arithmetic and reads the prefix cache; corrected deep queries may require earlier response propagation. An s-query probe reduces that term to `O(L_A s m h_q d_h)`, but creates the sufficiency problem above. Reading all current deep hidden inputs through an ordinary forward simply pays much of the computation being bypassed.

### Concrete lower-bound accounting on the existing 0.8B configuration

The already-present official config, revision [`2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`](https://huggingface.co/Qwen/Qwen3.5-0.8B/blob/2b48083dfa97c3cbf0220cf1a5e6cffe0a511157/config.json), has 18 recurrent layers, 16 value heads, and 128×128 recurrent matrices. Thus **S=4,718,592 scalar recurrent coordinates**, or **18 MiB in FP32**. These are arithmetic counts, not measured new allocations.

| Stored object, per segment, FP32 | Size |
|---|---:|
| One recurrent endpoint across layers | 18 MiB |
| Dense cumulative T plus U in the straightforward HYPIC layout | 36 MiB |
| Dense recurrent-state-to-recurrent-state Jacobian | **81 TiB** |
| Rank 4 response, two dense factors with input/output dimension S | 144 MiB |
| Rank 8 response, same | 288 MiB |
| Rank 16 response, same | 576 MiB |
| Rank 32 response, same | 1,152 MiB |

Even if a tiny online input sketch eliminates the large input-side factor, the output basis alone costs **18r MiB**: 144 MiB at rank 8. A thousand such segment bases would require about 140.6 GiB before ordinary cache data. Sharing or structured factorization could change this, but it must be specified and validated rather than assumed.

These counts exclude full-attention output corrections and convolution histories. At n=256, six attention layers × two KV heads × head dimension 256 × K/V × FP32 occupy another **6 MiB**. Three raw history positions for the recurrent Q/K/V projections occupy about **1.266 MiB** across the 18 layers. Exact allocated layouts can retain four positions instead; count the actual buffer, not only the mathematical minimum.

The existing frozen-input `H T` compositions cost about **603,979,776 MACs** across these recurrent heads. A rank-8 two-factor response adds **75,497,472 MACs** plus 288 MiB of factor traffic and output materialization. Thus the arithmetic itself is not obviously fatal; **per-segment bytes, sufficient online information, derivative construction, and amortization** may be the real limits. No latency conclusion follows from these counts.

### Compare to widening the seam, not just full recomputation

For R valid future hits, use

`C_total,response = C_build,response + R [C_H(w)+C_in+C_corr]`

versus

`C_total,wide = C_build,wide + R C_H(w')`.

If `C_H(w')−C_H(w)−C_in−C_corr ≤ 0`, response correction never amortizes against that wider seam. Otherwise its break-even hit count is the extra build cost divided by this positive per-hit saving. Include derivative/probe failures, refreshes, cache eviction, serialization, and misses in the observed reuse distribution.

Illustration only: if eight one-sided probes each cost one full segment forward, and widening the seam costs another 10% of that forward, then even zero-cost application needs more than **80 subsequent hits** to repay eight extra forwards. Eight central-difference directions need more than **160 hits**. Against full recomputation with 80% saved per hit, the respective optimistic figures are over 10 and 20 hits. These are transparent arithmetic scenarios, not workload estimates. HYPIC source tuple-building passes and any width-specific suffix rebuilding must also enter their baseline's build cost.

## 6. CPU-first rejection gates before a larger model

The following are **decision requirements**, not completed experimental results. No new pretrained execution was performed or authorized by this audit.

### Gate A: define the claim and complete input contract

Write the exact online observation g, output target f, reference context, prefix-length/position convention, segment cache key, and allowed class of prefix changes. Include whether g reads full-prefix KV, which probes it computes, and how it obtains coefficients.

**Hard no-go:** g consists only of recurrent boundary states/tails and a leading seam while the claim covers arbitrary hybrid prefixes. The collision in §3 already rules that claim out. Adding an unpriced “context embedding” is not a resolution.

### Gate B: model-free algebra and observation tests

Use tiny stable, noncommuting recurrent stacks plus a full-attention layer. Verify complete-state first-order response on the linear witness, exact fixed-input tuple parity, and the attention-prefix collision. For the proposed sketch, explicitly search the nullspace of its observation matrix against target forcing. Keep prefix masks and convolution state separate.

**Hard no-go:** the proposed correction cannot distinguish an admitted equal-observation/different-target pair beyond the declared tolerance. Passing selected random examples is not a sufficiency theorem.

### Gate C: oracle linear-response ceiling, only if later authorized

Before compressing a response map, test an exact directional derivative supplied with complete boundary information. Compare its prediction at small perturbations and at the actual source-to-target displacement. The current isolated-prefix proposal must handle the normalization example in §4. Disclose any oracle attention/hidden inputs and their cost.

**Hard no-go for first-order repair:** even the uncompressed complete-information first-order oracle cannot meet the predeclared error/quality tolerance at the real displacement, while only infinitesimal displacements work. A rank sweep cannot repair a bad linearization. Choosing more anchors changes construction, storage, and the novelty comparison to anchor methods.

### Gate D: rank and predictability ceiling

Freeze a byte/cost-derived `r_max` first. On independent held-out prefix changes, compare (i) the best rank-r approximation of the **flattened residual responses**, (ii) the actual input-conditioned predictor, and (iii) the complete response. Use sufficiently many independent directions to test the proposed rank: a matrix made from r contexts cannot validate a rank-r hypothesis. For a small screen, more than `2r` independent perturbations is a useful minimum, not a statistical guarantee.

**Hard no-go:** the best rank-`r_max` oracle already misses the target tolerance, or oracle coefficients work but deployable observations cannot predict them. The latter is precisely the distinction that small endpoint SVD plots can conceal.

### Gate E: budget and baseline dominance

Freeze cache bytes, construction budget, expected reusable lifetime, and matched quality before comparing full recompute, corrected small/wider seams, and the response path. Account for source-context reuse and training/anchor data exactly. Use wall time and total resident bytes, not only token-recompute counts.

**Hard no-go:** no positive break-even denominator, expected valid hits below break-even, or a wider seam meets the same quality at lower total cost/bytes. Also no-go if a new conditioned forward is needed for each unseen prefix merely to obtain response coefficients; that is an oracle/compile operating point akin to Kamera, not the proposed cheap unseen-prefix solution.

### Gate F: answer-relevant problem and causal attribution

A CPU-competent model/task pair, exact continuation controls, and an answer-relevant residual gap must exist before claiming usefulness. Separate recurrent-state, convolution, and full-attention-KV donors. A recurrent endpoint rescue does not prove an exclusively recurrent origin; attention changes can cause the state error.

**Current status: unmet.** The frozen 0.8B run stopped at competence. The corrected reference's algebraic tests do not imply pretrained parity or quality. A larger model would investigate problem existence, not validate this proposed method. No quality gain, hardware speedup, or main-topic promotion is warranted now.

## 7. Primary-source pins verified in this audit

| Project | Commit | Committer date UTC | Inspected mechanism |
|---|---|---|---|
| ICC | `dafee02efc89cdfbe81395a5a8a8fbeb17cf9be4` | 2025-05-14 05:47:15 | Low-rank input-increment correction in `models_sp_step_decomp.py` |
| FastMAS/KVCOMM | `48ca0b376c7f4fbf1c24042c1709a6fe4148c959` | 2025-11-03 03:54:24 | Anchor matching and weighted cache delta addition |
| KVCMAS | `e2170cf4b1790bd93f98d15e926397999d590867` | 2026-09-26 00:50:48 | SVD of observed cache deltas and materialization |
| DiCache | `fdbe20b669c9174bbed5ec994de073fd881c8010` | 2026-01-26 14:21:54 | Probe-driven residual extrapolation, coefficient clamp |
| MeanCache | `2e12280abfa9be521ad65c300ac50ad51f426e21` | 2026-02-05 03:16:52 | Displacement-based `compute_current_jvp` |
| TaylorSeer | `704ee98c74f7f04da443daa3c0aa2cc7803d86e3` | 2026-03-02 03:12:05 | Finite-difference feature coefficients and forecast |

HYPIC's previously audited pin is `98147c01909004e66d98bcb18b886927d41b0ee5`, July 21, 2026. Its defect and warmup semantics are inherited from the linked independent source audit, not newly rerun here. The archived `HankYe/KVCOMM` README directs readers to `FastMAS/KVCOMM`; the latter pin is used above. Repository existence and matching source do not independently reproduce any paper's experiments.

**Bottom line:** the remaining potentially interesting question is whether a specifically sufficient, cheaply observable hybrid-context representation yields a structured cross-layer residual response that beats widening HYPIC's seam after all costs. Nothing in the present evidence establishes that representation, low rank, prediction accuracy, quality gap, or cost advantage. The cheapest next intellectual step is the observation-contract/collision gate, not a larger model or an implementation.
