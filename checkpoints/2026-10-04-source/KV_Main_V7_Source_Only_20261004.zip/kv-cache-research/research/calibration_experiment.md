# Frozen calibration experiment entrypoint

Status: implemented and CPU tested; no pretrained checkpoint, CUDA, paid resource,
model-quality result, or deployable performance result. This is a separate
`echo_calibration_experiment_v2` archive, not an extension of the four baseline
arms. The existing baseline CLI, contracts, runtime and analysis are unchanged.

Version 2 implements the predeclared [pooled-versus-regional diagnostic protocol](calibration_pooled_control_protocol_v2.md)
from the [novelty follow-up](calibration_novelty_followup.md). Historical v1 plans,
dry-run hashes and evidence remain unchanged under
`research/diagnostics/calibration_experiment/` and source commit `c96b250`. The
current entrypoint rejects v1 rather than relabeling or silently migrating it.

## Small first screen

`python -m echo_pilot.calibration_experiment` provides `freeze`, `run`, and
`analyze`. `run` validates only unless `--execute` is present. The frozen recipe
uses the existing smoke8k **development** records, unchanged and in original
order: **two LCC contexts/questions and one RepoBench-P context/question**. One
invocation handles one task. There is no heldout, ratio, seed, subset, architecture,
recency, precision, tie-policy, or comparator-matrix expansion switch.

- Qwen3-8B model/tokenizer revision, data manifest, source and template pins match
  the original smoke. Ratio is 0.5; seed is 20261003; max generation is 64 tokens
- Common context-only replay prompts are frozen as actual token IDs and rechecked
  against the local pinned tokenizer before loading weights. The actual prompt
  plus suffix has **16 tokens**, so four **496-body-token** anchors fit a 2048
  replay-input-token cap. Short tails remain scored but are ineligible anchors
- First, uniform and one seeded-random policy independently run one context
  prefill and four exact replays each. Plans see no questions, labels or outcomes
- One additional, separately charged diagnostic build runs a fresh context
  prefill and every exact microchunk, including the tail. It is never presented
  as sparse/deployable build cost
- Nine downstream arms: dense full KV, first, uniform, random, no calibration,
  pooled-full-map oracle, regional scale-map oracle, rank-only oracle and
  full-exact score reference
- The last five controls are derived from the first candidate's paid sparse
  observations and/or the paid full diagnostic. No calibration retains exact
  anchor overrides. Pooled/regional/rank/full-exact controls fix anchors, prefix and
  protection exactly as the method contracts require
- Full diagnostic virtual scores and exact anchors must agree exactly with all
  independently collected sparse observations. A discrepancy fails the run;
  there is no tolerance tuning, extra replay, or silent retry
- Every arm/question starts from an independent dense cache clone. Sparse arms
  use their own original cache; controls use the first candidate's pristine
  dense cache. Existing selected masks are installed directly. No oracle is
  recast as a candidate or passed through `compress_post`/rescoring
- Full KV explicitly clears masks. Empty coordinate triples would otherwise
  trigger upstream fake-key search even when nothing is evicted

LCC costs eight independent scoring builds, 42,232 prefill input tokens, 24 sparse
exact replays / 12,288 sparse replay-input tokens, 22 full-diagnostic exact replays /
10,904 diagnostic replay-input tokens, and 18 query clones. RepoBench-P costs four
builds, 23,060 prefill tokens, 12 sparse replays / 6,144 input tokens, 12 diagnostic
replays / 5,954 input tokens, and nine query clones. These are deterministic work
counts, **not measured time, FLOPs, money, or statistical power**. Running both
invocations costs two model loads. Query input tokens increase from v1 to 252
for LCC and 4,032 for RepoBench-P; maximum generated tokens become 1,152 and 576,
respectively. This adds one clone/generation per question and transform/archive
work, with **no extra scoring, prefill, or exact reconstruction**. The recipe does
not run both automatically.

The safe dry-run counts, plan digests and validation records are under
`research/diagnostics/calibration_experiment_v2/`. Generated `*.plan.json` files
contain reversible natural benchmark context/replay token IDs and are deliberately
excluded from Git and the source checkpoint. After reproducing the pinned local
data/tokenizer preparation, regenerate private plans and validate without model
imports:

```sh
python -m echo_pilot.calibration_experiment freeze --task lcc \
  --output outputs/new-lcc-screen.plan.json
python -m echo_pilot.calibration_experiment freeze --task repobench-p \
  --output outputs/new-repobench-p-screen.plan.json
python -m echo_pilot.calibration_experiment run \
  --plan outputs/new-lcc-screen.plan.json
python -m echo_pilot.calibration_experiment run \
  --plan outputs/new-repobench-p-screen.plan.json
```

Freeze uses exclusive creation. Keep generated plans, inputs and eventual model
outputs local; a source checkpoint is not a redistribution of benchmark data.

Dry-run uses NumPy for method contracts, but does not import Torch, Transformers
or KVPress and never loads a model/tokenizer, queries the network, or provisions
anything. It hashes the locally staged tokenizer/data source artifacts and builds
replay IDs from their previously verified pinned encoding. A dry-run is not actual
runtime/tokenizer compatibility verification.

## Execution gates and bounded accounting

Execution requires all of the following before runtime loading:

1. A valid original smoke configuration with a complete installed environment
   lock, exact model/tokenizer revision and byte-pinned natural development data
2. A completed real-model four-arm baseline archive and its validated offline
   analysis for the same complete frozen task/smoke/model/selection/seed protocol.
   Analysis provenance binds the baseline manifest and audited analysis source;
   every scored and paired question cell, build ID, denominator and run ID must
   agree. Fixture archives cannot release this gate
3. A clean committed source checkout via the existing real-model `RunManifest`
   gate. Source digests and Git source identity are rechecked after execution
4. An explicit `--execute` invocation and a resource-specific execution-accounting
   record bound to this plan and baseline manifest. This is an evidence and budget
   gate under the existing approval, not a request for new human approval
5. Existing runtime checks: complete installed package inventory, audited author
   source bytes/PEP-610 commit, deterministic CUDA configuration, supported local
   model config/revision, local tokenizer/template, actual replay IDs and lengths.
   Dataset source/preprocessor metadata and offline metric source pins are also
   checked before loading weights, avoiding an otherwise guaranteed offline failure

Execution-accounting record fields are exact, with no extra keys:

```json
{
  "schema": "echo_calibration_experiment_v2",
  "plan_sha256": "ACTUAL_PLAN_DIGEST",
  "baseline_manifest_sha256": "ACTUAL_COMPLETED_BASELINE_MANIFEST_DIGEST",
  "resource_id": "ACTUAL_NEW_PROJECT_RESOURCE_ID",
  "resource_origin": "new_project_resource_only",
  "accounting_basis": "resource_id_specific",
  "external_stop_verified": true,
  "project_spent_cny": "ACTUAL_ALREADY_SPENT",
  "remaining_project_cny": "ACTUAL_REMAINING_APPROVAL",
  "screen_all_in_cap_cny": "ACTUAL_RESERVED_SCREEN_CAP",
  "max_wall_seconds": 2700,
  "no_automatic_retry": true
}
```

This example is deliberately non-runnable: it contains no invented provider ID,
cost observation, or release. Use actual existing resource-controller and ledger
evidence. Remaining plus spent cannot exceed CNY100; this screen's reserved cap
cannot exceed remaining approval or CNY20. The local useful-work deadline cannot
exceed 2700 seconds. There is no retry loop or resource allocation code. Previously
existing AutoDL resources remain off limits.

The JSON record is a declaration, not provider verification or authority by itself.
This entrypoint cannot prove a provider has stopped charging, enforce a CNY meter,
or preempt a stalled CUDA call. A separately verified resource-specific external
stop/deadline is mandatory. Local checks stop before the next operation and mark
an operation crossing its deadline failed. The actual provider ledger must be
reconciled afterward; `provider_cost_cny` remains null until that separate work.
No successful local exit is proof of resource shutdown.

```sh
CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m echo_pilot.calibration_experiment run \
  --plan research/diagnostics/calibration_experiment_v2/lcc.plan.json \
  --config /path/to/frozen-lcc-smoke-config.json \
  --baseline-run /path/to/completed-baseline \
  --baseline-analysis /path/to/validated-baseline-analysis \
  --execution-record /path/to/verified-screen-accounting.json \
  --output outputs/calibration-lcc-new --execute
```

Use a new output directory. No checkpoint download occurs; `local_files_only=True`
and `trust_remote_code=False` remain mandatory. The present development checkout
is uncommitted and has no valid baseline GPU archive or real environment lock;
these are real remaining prerequisites, not bypass switches. This revision is
CPU-only and does not authorize a GPU run or paid resource.

## Artifacts, failure and overhead

The archive includes the full context-only replay/anchor plan, original baseline
configuration, baseline evidence digests, package lock, clean-source evidence,
source inventory, resolved model config, raw stdout/stderr log, started/completed
operation event log, generated IDs/text, per-context score/mask NPZ, build ledgers,
selection/support/tie reports, cache shape/payload/backing-storage reports, and
measured load/build/transform/clone/generation/serialization/context/run intervals.

- GPU intervals are measured with actual CUDA synchronization. Host capture and
  serialization overhead are labeled separately. Nested intervals are not
  additive independent costs. Whole-run/context intervals include the relevant
  writes; final hashing/OS-buffer durability exclusions are explicit
- Every replay's observed token IDs, input lengths, absolute bounds and prompt
  tokens are validated against the plan, including attempted forwards on failure
- Transform masks share actual paid builds. They receive no invented zero-cost
  or independently deployable build timing. Dense full KV is a quality reference,
  with a reused original dense cache, not a standalone full-KV latency benchmark
- Dense cache view payload and distinct backing storage are retained separately.
  Replay-restored views/clones can retain backing storage larger than their view
  payload. Nothing here compacts caches or demonstrates physical memory savings
- Prerequisite and runtime exceptions create `FAILED.json`; no failed run gets a
  completion marker. Failure events preserve host elapsed time and the adapter's
  attempted-forward ledger. If scoring succeeds but synchronization, memory
  capture, logging or a post-operation deadline check fails, the timing envelope
  preserves the completed replay ledger and clears its untransferred candidate
  cache. Model ownership is acquired before device placement/eval so outer
  cleanup also runs on load-envelope failure. Dropping owned references is not
  proof of CUDA allocator release. The caller must stop/check its owned resource
- Full-KV bypasses fake-key search; compressed/oracle search failures are recorded
  and propagated. There is no silent attention-backend substitution

## Offline analysis

```sh
python -m echo_pilot.calibration_experiment analyze \
  --run outputs/calibration-lcc-new \
  --output outputs/calibration-lcc-analysis-new
```

Only this command reads gold labels. It reuses the existing strict data/metric
pinning and paired context-cluster bootstrap helpers, but has a separate archive
validator. It rejects incomplete/failed archives, extra/missing artifacts,
duplicate JSON fields/cells, changed sources/inputs, wrong query/context links,
missing costs, mismatched cache growth, unsupported memory claims and nonfinite
values. NPZ is loaded with `allow_pickle=False`. Every sparse calibration and
control/oracle mask is recomputed from captured observations, including equal
budget, exact anchor and virtual-score agreement, support diagnostics and tied
allocation audits. Rehashing an edited mask or undercharged replay ledger does
not make it valid. Raw operation events must witness the exact frozen order of model load, sparse
builds and their queries, full diagnostic, transforms, and control queries. Each
clone must immediately precede its generation. Reordered but rehashed logs fail.

Metric: the already pinned LongBench code-similarity implementation with its
fuzzywuzzy 0.18.0 difflib behavior. All nine cells report per-question scores,
means and paired deltas against first/full KV/pooled-full-map. The regional-minus-
pooled raw quality contrast includes every frozen question. Each context carries
recomputed multiset/order/budget/cutoff-membership interpretability flags; any confounded context
blocks a clean cohort-level regional attribution, without dropping that cell.
Bootstrap resamples actual whole
`context_id` clusters with shared draws, never questions, arms, or ratios as
independent contexts. RepoBench's one cluster receives **no interval**. LCC's two
clusters give only an exploratory and very unstable interval. No arm is selected
or suppressed based on its result.

The optional `--allow-fixture` is exclusively for clearly labeled `cpu_fixture`
archives; it never changes their evidence kind. The normal executable cannot
produce a fixture-as-real archive. This is a testing facility, not a route around
model/source/environment gates.

## Validation and limitations

```sh
python -m unittest echo_pilot.tests.test_calibration_experiment -v
# Optional existing isolated native CPU environment, no installations:
/tmp/kv_tiny_qwen_cpu_20261003/bin/python -m unittest \
  echo_pilot.tests.test_calibration_experiment_native -v
```

CPU tests cover frozen counts and prompt overhead, import-free model dry-run,
no-query/gold planning, release caps, fail markers, clean-source gate ordering,
attempted-cost logging and post-build envelope failures, clone isolation, no oracle rescoring, exact diagnostic
agreement, full output/metric coverage, context-cluster pairing, and resealed
artifact tampering. Native tests use the existing random 22,720-parameter Qwen3
fixture, actual Transformers 5.2 DynamicCache/SDPA, and the audited source modules.
They exercise all nine arms/four builds, original-cache preservation, exact
score agreement, the full-KV fake-key bypass, deadline-crossed cache/ledger
ownership, and model-placement failure cleanup. Native integration fixtures
patch GPU timing and loader/environment gates, use an explicitly synthetic
tokenizer, and produce no real-model completion archive. CPU host timings are
labeled as CPU-only; no GPU timing is manufactured.

These checks do not establish Qwen3-8B pretrained quality, true tokenizer runtime
compatibility, native BF16/CUDA parity, full installed KVPress/PEFT compatibility,
provider cost, sufficient statistical power, a useful calibration effect or
physical memory benefit. The first screen is intended to detect integration failures and inspect a conditional oracle contrast cheaply. It cannot
establish a novel method, a regional gain, or a useful deployment benefit. Strong
learned comparators, additional seeds/ratios,
a bigger natural subset and heldout evaluation remain later, separately justified
steps after baseline evidence and measured cost review.
