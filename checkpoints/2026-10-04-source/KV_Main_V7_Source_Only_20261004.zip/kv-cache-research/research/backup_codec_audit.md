# Backup audit: repeated TensorRT-LLM cold-page encoding

Audit date: 2026-10-03 UTC. Scope: public source, source-linked lifecycle inspection, and an isolated CPU arithmetic diagnostic. No CUDA kernel, serving engine, model weights, model inference, GPU rental, paid API, upstream installation, or remote write was used.

## Decision

**Do not promote this backup to a GPU pilot on the proposed RTX 5090.** The concrete cold-page implementation rejects the RTX 5090's SM120: its admission predicate accepts SM versions from 100 through 109, and its documented supported devices are SM100/103/107. Bypassing that guard or porting the backend would be a new engineering project. This audit does not propose a different rental. [Hardware admission][admission], [predicate][predicate], [RTX 5090 compute capability][gpu]

The source-level scientific question has a more nuanced answer:

- **Repeated lossy encoding is reachable.** Normal cold-to-hot migration releases the old cold slot; it does not maintain a canonical cold-byte replica for the immutable page. A later eviction encodes the restored hot tensor again. [Migration ownership][ownership], [onboarding][onboarding]
- **Same-representation migration is a byte-copy path.** Hot-to-hot defragmentation and cold-to-cold Host/Disk movement do not run the quantizer. If active KV is already NVFP4, the factory skips cold NVFP4 quantization and uses lossless migration. These cases must be excluded from any drift claim. [Raw copies][rawcopies], [active-NVFP4 bypass][activebypass]
- **The encode/decode composite is not universally idempotent.** A small source-equation counterexample exists with identity global scales and representable FP16/BF16 values. Its first and second restored values differ because the block scale is recomputed. This is a source-faithful synthetic arithmetic result, not a CUDA reproduction, production incident, model-quality regression, or novelty claim. [Encode primitive][quantmath], [kernel caller][kernelcall], [decode][decodemath]
- **The broad proposed gap is already substantially occupied.** Upstream explicitly tests a second lossy cycle, compares it with a second-cycle numerical reference, and requires repeated-compression/lifecycle validation. A contribution cannot be “we discovered that lossy re-encoding can change values.” Canonical-byte retention is an obvious baseline before considering a new method. [Existing repeated-cycle test][repeattest], [validation guide][validation]

Disposition: the original mixed-history backup is **not execution-ready and is rejected as the next experiment for the current hardware/budget plan**. Retain only the bounded source-equation diagnostic below. End-to-end significance remains unestablished.

## 1. Exact version, provenance, and license

The documentation's displayed `c76f4a8` resolves to **c76f4a856447820aa1f994b053da7580d69b657d**, which is exactly the tag **v1.3.0rc29**. GitHub marks that release as a **prerelease**, published 2026-09-29. The documentation says generated from this commit and updated 2026-09-26; the commit itself is dated 2026-09-24. These are different timestamps, not evidence of three different code versions. [Commit][commit], [release][release], [feature docs][feature]

This is not the latest stable release: GitHub's latest-stable endpoint returned **v1.2.1**, commit **376f7e1bd8ed543f75014309e3fd4b237e9b0e73**. Its complete recursive source tree contains neither `nvfp4ColdPageKernels` nor the cold-page codec files audited here. Do not advertise this result as a reproduced defect in the stable release. [Stable release][stable], [stable source tree][stabletree]

The repository license is Apache-2.0, with separately listed third-party notices; the audited NVIDIA source files carry Apache-2.0 headers. No model-weight license is involved because no model was downloaded. [License][license]

Public raw files were downloaded to temporary storage. Their Git blob hashes were compared with the pinned commit's non-truncated recursive Git tree; no mismatch was found. Key SHA-256 hashes:

| Pinned source file | SHA-256 |
| --- | --- |
| `cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp` | `69eb2fac2cb28173cf8ff19bebfe20b8c62fc8480099ca9600dfba841375720b` |
| `cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu` | `04c44c9424ca9f354ec02891db3202f1043bf586fde95b74b7aca4af9f519b3d` |
| `cpp/tests/unit_tests/kernels/nvfp4ColdPageKernelsTest.cpp` | `9a75981f71cf88cc209de3f0a7cc6fc9eec205a8003b34f1f1779413bed4fd1f` |
| `tensorrt_llm/_torch/kv_cache_compression/quantization_for_cold_page/nvfp4_quantization.py` | `f031d457a7d8b8d723c746a20fa58da0ba4908a9b14ea6b55bfea8012401d968` |

## 2. The actual supported path

### Admission and fixed configuration

The feature uses the PyTorch backend, native C++ KVCM V2, a nonzero cold tier, and supported SM100-family hardware. The quantizing runtime formats are FP16, BF16, and FP8. The compression config selects only `nvfp4`; this is not a runtime arbitrary-format transition API. The provider resolves the runtime dtype at construction. Block reuse is explicitly supported. [Config][config], [dtype dispatch][dtype], [example requirements][requirements]

The source chooses one compression manager. A workflow alternating TriAttention compaction, arbitrary active dtypes, and cold NVFP4 is therefore **not** established by these sources. The feature docs explicitly allow one compression method per LLM instance. Neither appending tokens nor changing physical compaction history is needed for the counterexample, and neither is used to justify it. [Feature documentation][feature]

### Page identity does not imply retained canonical bytes

`Page` inherits one `Slot` and stores one `cacheLevel`. `CommittedPage` is read-only to consumers after commit, with token validity and reuse identity tracked separately. There is no canonical-cold-replica field in this page object. This structural observation is supported by the migration implementation, not merely inferred from a missing name. [Page state][pagestate]

Normal migration does the following:

1. Allocate destination slots and wait on source/destination readiness events
2. Call `submitMigrationBatch` with source/destination levels
3. Attach the completion event
4. With `updateSrc=true`, exchange the page's slot for the destination, release the source slot to its pool, and set the new `cacheLevel`

The ordinary onboarding call passes `updateSrc=true`; eviction's accepted-page migration also passes `true`. Retaining allocations until asynchronous work completes prevents use-after-free, but is not canonical representation retention after migration. [Transaction and release, L1113–1233][ownership], [onboarding, L1241–1257][onboarding], [eviction, L1060–1086][eviction]

A reachable sequence for one immutable committed prefix page is consequently:

1. A reusable page is on the hot tier
2. Once unlocked and eligible, capacity pressure evicts it to Host/Disk; this executes encode
3. A later prefix consumer locks/reuses it; `batchedLockToGpu` migrates it back and waits for completion before publishing the hot mapping; this executes decode
4. The cold source slot is released
5. After the consumer releases its lock, the page can become eviction-eligible again
6. Another hot-tier eviction executes encode on the restored hot values

This sequence does not require modifying the page's tokens or appending to that page. Steps 2/3/6 use the same configured codec; there is no change of model, scale checkpoint, or global scale state. [Lock-to-GPU path][locking], [unlock and rescheduling][unlock], [encode/decode routing][routing]

This is **source-level reachability**, not an observed two-cycle production trace. Upstream's checked-in integration test independently exercises real KVCM/provider Host migration with suspend, pressure, encode-call counting, resume, and decode-call counting. It writes test cache values rather than running a model forward, and was inspected but not executed here. It supports the lifecycle interpretation without establishing model quality or a two-cycle drift result. [Integration test, L441–555][integration]

### Paths that do preserve representation

- `srcIsHot == dstIsHot` takes the copy-engine route and returns before codec invocation; repeated raw moves do not numerically requantize the payload
- Host and Disk share the same cold representation. Moving between them copies the blob, including the existing block scales
- Normal cold-to-hot migration is different: it decodes and releases the cold source slot
- Active NVFP4 is different again: the factory returns no cold quantization manager and migrates that already-quantized representation losslessly
- Non-Attention state and explicitly lossless auxiliary buffers follow lossless routes

Thus neither a Host↔Disk loop nor an active-NVFP4↔cold loop is valid evidence of cumulative cold-page quantization. [Raw-copy branch][rawcopies], [factory bypass][activebypass], [format contract][format]

## 3. Exact numerical counterexample, with its limits

For FP16/BF16, the production kernel calls `cvt_warp_fp16_to_fp4<T,16,false>`. The primitive finds the absolute maximum of each natural 16-value group, constructs an E4M3 block scale from the scaled maximum divided by 6, normalizes values using the decoded block scale, and converts them to E2M1. Decode multiplies the E2M1 value by the stored E4M3 scale and global dequantization scale, then rounds to FP16/BF16. The old E4M3 scale is not written to the hot tensor. [Caller][kernelcall], [primitive, L457–537][quantmath], [decode, L467–484 and L552–575][decodemath]

For this diagnostic, global quantization/dequantization scales are both 1, which is the documented default. The 16 inputs are all **19/1024 = 0.0185546875**. All hot input/restored values below are exactly representable in both FP16 and BF16.

| Stage | E4M3 block scale | E2M1 value | Restored hot scalar |
| --- | --- | --- | --- |
| Initial hot value | — | — | `19/1024` |
| First encode/decode | `2/512` (scale byte `0x02`) | `4` (nibble `0x6`) | `1/64 = 0.015625` |
| Second encode/decode, without hot writes | `1/512` (scale byte `0x01`) | `6` (nibble `0x7`) | `3/256 = 0.01171875` |
| Third encode/decode | `1/512` | `6` | `3/256` |

Explanation:

- First scale input is `(19/1024)/6 ≈ 0.003092448`, whose nearest E4M3 value is `2/512`
- Normalization produces `4.75`, whose nearest E2M1 value is `4`; restore gives `4 × 2/512 = 1/64`
- The next scale input is `(1/64)/6 ≈ 0.002604167`, whose nearest E4M3 value is `1/512`
- Normalization now produces `8`, which saturates to E2M1 `6`; restore gives `6/512 = 3/256`

These choices are away from rounding ties. The CUDA primitive uses approximate reciprocals; the CPU check does not emulate that instruction, but the exhibited decisions have ample margin, and all hot stores are exact for this example. This is a counterexample to universal idempotence of the source equations, not a bit-for-bit verification of GPU instructions. The second restore differs from the first by `1/256` (25% of the first value), but the absolute magnitude is small. It reaches a fixed point on the third cycle; **this is not evidence of unbounded accumulating drift**.

The mechanism here is E4M3 **subnormal block-scale granularity**. The input activation itself is not a BF16/FP16 subnormal. Frequency of such 16-value groups in real KV, effects of non-identity ModelOpt scales, FP8 runtime behavior, and downstream attention/output sensitivity are all unmeasured. The example does not support a claim that ordinary normal-scale groups generally drift, or that an accuracy loss is material.

The isolated diagnostic and tests are in [`diagnostics/backup_codec/README.md`](diagnostics/backup_codec/README.md). They execute only original stdlib arithmetic, do not import TensorRT-LLM or torch, and do not create a synthetic serving lifecycle. The README also records a bounded normal-scale fixed-point argument for identity-global FP16/BF16 and 1,904 checked normal-scale/code cases. That counterevidence is important: lossy cycles do not necessarily keep changing every page.

Independent verification from the repository root:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s research/diagnostics/backup_codec -p 'test_*.py' -v
PYTHONDONTWRITEBYTECODE=1 python research/diagnostics/backup_codec/nvfp4_source_equation_check.py
```

All **6 tests passed**. The emitted JSON matched the saved `result.json` byte-for-byte. Both Python files compiled successfully. Tests cover the two dtype traces, third-cycle stabilization, adjacent-binary32 reciprocal perturbations, canonical-byte retention, example-only scale retention, and the scoped normal-scale cases. These are CPU arithmetic tests only; native/GPU/serving tests remain unrun.

## 4. What upstream tests already know

The native round-trip test has repeated-cycle cases for FP16, BF16, and FP8, including model-like geometry. The second-cycle branch recomputes its expected cold representation as `compressReference(decompressReference(previous_reference))`, then compares the actual second encode/decode with that updated reference. It does **not** require equality between first-cycle and second-cycle bytes or values. [Test logic, L779–805][repeattest], [test cases, L1211–1216][repeatcases]

This is important negative evidence against novelty: repeated lossy conversion is already an intentional test dimension, and the test contract allows a second-cycle change if it matches the numerical reference. Calling the counterexample a previously unknown production corruption bug would be unjustified. The compression development guide likewise calls for repeat-frequency disclosure, reuse, rewind, suspend/resume, and actual route evidence. [Development validation][validation]

A bounded public-history check found:

- Initial cold NVFP4 implementation: PR #18091, commit `f77d1a2b2be798fbcdfa228a0f072beb910ee103`
- DeepSeek-V4 extension: PR #18783, commit `d457278045012e1d2fc4399ec19995546dc6b27f`
- The superficially relevant NVFP4 scale fix #19192 addresses allocating active-KV block-scale buffers from the resolved dtype, rather than the original config string. It does not implement canonical cold-byte preservation or change the recomputed-scale equation above

- Later PR #19580, merged 2026-10-02 at `80f1809362f1a1e5d5eafc5ac0e744b98e13f271`, adds opt-in sparse tier-aware locking. Its description plans host-authoritative history with clean fetched GPU copies, but says fetch/attention/runtime integration is follow-up work and dense defaults are preserved. Comparing its `storageManager.cpp` with the audited pin shows the same source-slot exchange/release and `updateSrc=true` migration; the changes add locked-page rejection, tier selection, and deduplication. It is not evidence of a completed supported canonical-copy solution for this dense cold-NVFP4 path. It is further counterevidence against claiming that host-authoritative/canonical-copy policy is a new idea

Sources: [initial implementation][initialpr], [extension][extensionpr], [resolved-dtype fix][dtypefix], [later sparse-storage work][sparsepr], [later migration source][newstorage]. This is a limited source/history check, not proof that no related issue, private fix, or later change exists.

## 5. Simple baselines and the bounded diagnostic that remains

**Canonical cold-byte retention is the first baseline.** For an immutable page, retain its first encoded payload and scales while materializing hot copies for consumers; future restores decode the retained bytes. That trivially removes repeated re-encoding from this page's history, while preserving its first compression error. It changes storage ownership/accounting and consumes additional cold capacity while the page is hot. It is not implemented or benchmarked here, and it is not a novel algorithm merely because it is a useful baseline.

For pure quantized values, one 16-value cold group uses 8 data bytes plus 1 scale byte, before padding/side buffers. Retaining that cold group while a FP16/BF16 hot copy exists adds 9 bytes alongside the 32-byte hot group. A fair future comparison must charge those bytes and any reduced cold-tier capacity. Retaining only scale metadata can stabilize this particular scalar case, but is not established as sufficient across hot dtypes, global scales, rounding, and saturation. [Cold layout][format]

The only justified no-GPU continuation is a **source-contract/fixed-point diagnostic**: independently enumerate or construct representable groups, record first-cycle versus second-cycle encoded bytes and restored values, distinguish normal/subnormal scales and runtime dtypes, and compare with canonical retention. This is a small numerical robustness check, not a replacement research-paper claim. The delivered scalar diagnostic closes the cheap existence gate for one narrow case.

Before any future serving claim, all of these would be necessary: an admitted hardware/backend, native-kernel parity, route traces proving the same immutable page actually cycles twice, exposure frequency in real KV, quality impact beyond one-shot NVFP4 loss, and a matched-byte comparison with canonical retention. None is established here. The current RTX5090 plan stops at the unsupported-hardware boundary; do not rent hardware, modify guards, download models, or build a custom backend on the strength of this counterexample.

## Source index

All source-line links below use the full audited commit.

[commit]: https://github.com/NVIDIA/TensorRT-LLM/commit/c76f4a856447820aa1f994b053da7580d69b657d
[release]: https://github.com/NVIDIA/TensorRT-LLM/releases/tag/v1.3.0rc29
[stable]: https://github.com/NVIDIA/TensorRT-LLM/releases/tag/v1.2.1
[stabletree]: https://api.github.com/repos/NVIDIA/TensorRT-LLM/git/trees/376f7e1bd8ed543f75014309e3fd4b237e9b0e73?recursive=1
[license]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/LICENSE#L1-L11
[feature]: https://nvidia.github.io/TensorRT-LLM/features/kv-cache-compression.html
[validation]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/docs/source/developer-guide/kv-cache-compression-development.md
[admission]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_torch/pyexecutor/_util.py#L3376-L3395
[gpu]: https://developer.nvidia.com/cuda/gpus
[predicate]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_utils.py#L729-L745
[config]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/llmapi/llm_args.py#L3890-L3912
[dtype]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_torch/kv_cache_compression/quantization_for_cold_page/nvfp4_quantization.py#L328-L352
[requirements]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/examples/kv_cache_compression/nvfp4_cold_page.md#L45-L81
[pagestate]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/page.h#L42-L116
[ownership]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L1113-L1233
[onboarding]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L1241-L1257
[eviction]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L1060-L1086
[locking]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/page.cpp#L429-L489
[unlock]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/page.cpp#L289-L315
[routing]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L616-L705
[rawcopies]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L579-L614
[activebypass]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_torch/pyexecutor/_util.py#L3439-L3454
[format]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/examples/kv_cache_compression/nvfp4_cold_page.md#L24-L54
[integration]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tests/unittest/_torch/attention/sparse/deepseek_v4/test_deepseek_v4_cache_manager.py#L441-L555
[kernelcall]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L645-L655
[quantmath]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/quantization.cuh#L457-L537
[decodemath]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L467-L575
[repeattest]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tests/unit_tests/kernels/nvfp4ColdPageKernelsTest.cpp#L779-L805
[repeatcases]: https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tests/unit_tests/kernels/nvfp4ColdPageKernelsTest.cpp#L1211-L1216
[initialpr]: https://github.com/NVIDIA/TensorRT-LLM/pull/18091
[extensionpr]: https://github.com/NVIDIA/TensorRT-LLM/pull/18783
[dtypefix]: https://github.com/NVIDIA/TensorRT-LLM/pull/19192

[sparsepr]: https://github.com/NVIDIA/TensorRT-LLM/pull/19580
[newstorage]: https://github.com/NVIDIA/TensorRT-LLM/blob/80f1809362f1a1e5d5eafc5ac0e744b98e13f271/cpp/tensorrt_llm/batch_manager/kv_cache_manager_v2/storageManager.cpp#L1204-L1262
