"""External wall/RSS/host/disk guard; random-model gate only."""
import datetime, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path
R=Path(__file__).resolve().parent
assert not (R/'tiny_watchdog.json').exists(), 'Do not overwrite prior attempts'
c=json.loads((R/'numerical_freeze.json').read_text())
cmd=[sys.executable,str(R/'run_tiny_gate.py'),'--frozen-contract-sha256',c['contract']['sha256'],'--review',str(R.parents[1]/'bf16_probe_admission_review.md')]
assert shutil.disk_usage(R).free>=5_000_000_000
start=time.monotonic();samples=[];stop=None
with (R/'tiny_gate.log').open('x') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 while p.poll() is None:
  try:
   status=dict(x.split(':',1) for x in Path(f'/proc/{p.pid}/status').read_text().splitlines() if ':' in x)
   rss=int(status.get('VmRSS','0 kB').strip().split()[0])*1024
  except FileNotFoundError:break
  mem=dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines() if ':' in x);total=int(mem['MemTotal'].split()[0])*1024;avail=int(mem['MemAvailable'].split()[0])*1024
  free=shutil.disk_usage(R).free;elapsed=time.monotonic()-start
  samples.append(dict(elapsed_seconds=elapsed,RSS_bytes=rss,host_unavailable_bytes=total-avail,free_disk_bytes=free))
  if rss>=8589934592:stop='RSS cap'
  elif total-avail>=9000000000:stop='Host 9GB budget'
  elif free<5000000000:stop='Disk reserve'
  elif elapsed>=1800:stop='1800 second wall cap'
  if stop:p.terminate();break
  time.sleep(.2)
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
result=dict(started_command=cmd,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=p.returncode,resource_stop=stop,wall_seconds=time.monotonic()-start,samples=samples,limits=dict(RSS_bytes=8589934592,host_bytes=9000000000,free_disk_reserve_bytes=5000000000,wall_seconds=1800))
(R/'tiny_watchdog.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='samples'}))
if stop or p.returncode:raise SystemExit(1)
