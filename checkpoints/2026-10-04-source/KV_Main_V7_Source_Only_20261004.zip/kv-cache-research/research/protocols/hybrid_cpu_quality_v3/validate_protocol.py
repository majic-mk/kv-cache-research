"""Offline fixture validation only. Never loads weights, downloads, or installs.

No tokenizer arguments: structural checks, with token checks explicitly pending.
With --tokenizer-dir and --provenance: verify offline pinned tokenizer artifacts,
then freeze full-prompt token slices, candidate IDs, lengths, and identity checks.
The provenance hashes establish identity relative to a recorded source manifest;
they are not signatures or independent proof that the assets came from that URL.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL = 'Qwen/Qwen3.5-2B'
REV = '15852e8c16360a2fea060d615a32b45270f8a8fc'
ARMS = ['full_recompute', 'exact_prefix']


def sha(x):
    return hashlib.sha256(x).hexdigest()


def load_fixtures(root=ROOT):
    return [json.loads(s) for s in (root / 'fixtures.jsonl').read_text().splitlines() if s]


def contexts(row):
    return [dict(variant=v, A=row[v], expected_answer=row['expected_answer_' + v])
            for v in ('A1', 'A2')] + row['unrelated_prefix_controls']


def render(row, ctx, template):
    a = template['prefix_before_A'] + ctx['A'] + template['prefix_after_A']
    q = template['suffix_before_Q'] + row['Q'] + template['suffix_after_Q']
    return a + row['B'] + q, (len(a), len(a) + len(row['B']))


def score_answer(raw, expected, *, eos_within_cap):
    # No extracting an answer from a sentence, substring match, synonyms or judge.
    if not eos_within_cap:
        return False
    text = raw.strip().casefold()
    if re.fullmatch(r'[a-z]+[.!?]?', text):
        return text.rstrip('.!?') == expected
    return False


def validate_structure(rows, template):
    assert len(rows) == 16
    assert [r['pair_id'] for r in rows] == [f'd{x:02d}' for x in range(1, 9)] + [f'h{x:02d}' for x in range(1, 9)]
    assert sum(r['split'] == 'development' for r in rows) == 8
    assert sum(r['split'] == 'held_out' for r in rows) == 8
    assert template['model_id'] == MODEL and template['revision'] == REV
    out = []
    for row in rows:
        assert row['A1'] != row['A2']
        assert len(set(row['answer_candidates'])) == 2
        assert [row['expected_answer_A1'], row['expected_answer_A2']] == row['answer_candidates']
        assert all(re.fullmatch('[a-z]+', x) for x in row['answer_candidates'])
        assert row['B_sha256'] == sha(row['B'].encode())
        start, end = row['important_interior_char_span']
        assert row['B'][start:end] == row['important_interior_text']
        assert len(row['B'][:start].split()) >= 50  # word check, NOT a token count
        assert row['B'].endswith('\n\n')
        cs = contexts(row)
        assert [c['variant'] for c in cs] == ['A1', 'A2', 'U1', 'U2']
        assert cs[2]['expected_answer'] == cs[3]['expected_answer'] == row['expected_answer_A1']
        assert all('<|' not in row[k] for k in ('A1', 'A2', 'B', 'Q'))
        texts = [render(row, c, template)[0] for c in cs]
        assert len(set(texts)) == 4
        out.append({'pair_id': row['pair_id'], 'split': row['split'], 'B_sha256': row['B_sha256'],
                    'B_utf8_bytes': len(row['B'].encode()), 'B_words': len(row['B'].split()),
                    'words_before_important_interior': len(row['B'][:start].split())})
    return out


def check_assets(folder, provenance):
    meta = json.loads(Path(provenance).read_text())
    assert meta['model_id'] == MODEL and meta['revision'] == REV, 'Wrong tokenizer model or immutable revision'
    paths = {}
    for filename in ('tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja'):
        record = meta['files'][filename]
        expected = f'https://huggingface.co/{MODEL}/resolve/{REV}/{filename}'
        assert record['source_url'] == expected
        path = Path(folder) / filename
        assert sha(path.read_bytes()) == record['sha256'], f'{filename} hash mismatch'
        paths[filename] = path
    return paths, meta


def validate_tokens(rows, template, folder, provenance):
    # Import only if the existing offline package is already installed.
    from tokenizers import Tokenizer
    paths, meta = check_assets(folder, provenance)
    tokenizer = Tokenizer.from_file(str(paths['tokenizer.json']))
    config = json.loads(paths['tokenizer_config.json'].read_text())
    for text, tid in template['required_special_token_ids'].items():
        assert tokenizer.token_to_id(text) == tid, f'Wrong Qwen3.5 special token: {text}'
        assert config['added_tokens_decoder'][str(tid)]['content'] == text
    assert config.get('bos_token') is None and not config.get('add_bos_token', False)
    # Check the official text-only template through its installed renderer when
    # available; string suffix check is necessary, never sufficient by itself.
    from jinja2.sandbox import ImmutableSandboxedEnvironment
    env = ImmutableSandboxedEnvironment(trim_blocks=True, lstrip_blocks=True)
    assert config['chat_template'] == paths['chat_template.jinja'].read_text(), 'Pinned template and tokenizer config disagree'
    official = env.from_string(config['chat_template'])
    results = []
    lim = template['limits']
    for row in rows:
        b_ids_by_variant = []
        q_ids_by_variant = []
        a_lengths = []
        for ctx in contexts(row):
            full, (bc0, bc1) = render(row, ctx, template)
            content = full[len('<|im_start|>user\n'):full.index('<|im_end|>')]
            reference = official.render(messages=[{'role': 'user', 'content': content}], add_generation_prompt=True)
            assert reference == full, 'Frozen rendering differs from pinned official template'
            encoded = tokenizer.encode(full, add_special_tokens=False)
            offsets = encoded.offsets
            for cut in (bc0, bc1):
                assert not any(s < cut < e for s, e in offsets), f'Token crosses B boundary: {row["pair_id"]}'
            b_idx = [i for i, (s, e) in enumerate(offsets) if s >= bc0 and e <= bc1 and e > s]
            assert b_idx and b_idx == list(range(b_idx[0], b_idx[-1] + 1))
            b0, b1 = b_idx[0], b_idx[-1] + 1
            assert offsets[b0][0] == bc0 and offsets[b1 - 1][1] == bc1
            aid, bid, qid = encoded.ids[:b0], encoded.ids[b0:b1], encoded.ids[b1:]
            assert lim['B_tokens_min'] <= len(bid) <= lim['B_tokens_max']
            assert len(aid) <= lim['A_tokens_max'] and len(qid) <= lim['Q_tokens_max']
            assert len(encoded.ids) <= lim['total_prompt_tokens_max']
            imp0, imp1 = row['important_interior_char_span']
            important = [i - b0 for i, (s, e) in enumerate(offsets) if e > bc0 + imp0 and s < bc0 + imp1]
            assert important and min(important) >= lim['important_first_token_min_zero_based']
            answer_ids = {}
            for answer in row['answer_candidates']:
                appended = tokenizer.encode(full + answer + '<|im_end|>', add_special_tokens=False).ids
                assert appended[:len(encoded.ids)] == encoded.ids, 'Answer changes prompt tokenization'
                ids = appended[len(encoded.ids):]
                assert ids[-1] == template['required_special_token_ids']['<|im_end|>']
                assert 1 < len(ids) <= template['candidate_total_token_cap_including_eos']
                answer_ids[answer] = ids
            assert len({tuple(v) for v in answer_ids.values()}) == 2
            b_ids_by_variant.append(bid)
            q_ids_by_variant.append(qid)
            a_lengths.append(len(aid))
            results.append({'pair_id': row['pair_id'], 'variant': ctx['variant'], 'split': row['split'],
                            'expected_answer': ctx['expected_answer'], 'input_ids': encoded.ids,
                            'A_ids': aid, 'B_ids': bid, 'Q_ids': qid,
                            'answer_candidate_ids_including_eos': answer_ids,
                            'important_token_span_zero_based_in_B': [min(important), max(important) + 1],
                            'full_prompt_sha256': sha(full.encode())})
        assert all(x == b_ids_by_variant[0] for x in b_ids_by_variant), 'B token identity failed'
        assert all(x == q_ids_by_variant[0] for x in q_ids_by_variant), 'Q token identity failed'
        assert a_lengths[0] == a_lengths[1], 'A1/A2 position confound: revise before outcomes, never drop one case'
        assert a_lengths[2] == a_lengths[3], 'U1/U2 position confound'
    return {'tokenizer_provenance': meta, 'contexts': results}


def operation_counts():
    return {'total_answer_evaluation_cells':16,'first_cheap_probe_cells_max':16,'primary_target_contexts':8,'primary_arms':2,'other_model_forwards_authorized':False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tokenizer-dir', type=Path)
    parser.add_argument('--provenance', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'validation.json')
    args = parser.parse_args()
    rows = load_fixtures()
    template = json.loads((ROOT / 'template.json').read_text())
    result = {'evidence_class': 'pre_outcome_protocol_validation_no_models',
              'fixture_jsonl_sha256': sha((ROOT / 'fixtures.jsonl').read_bytes()),
              'template_sha256': sha((ROOT / 'template.json').read_bytes()),
              'structure_status': 'passed', 'fixtures': validate_structure(rows, template),
              'operation_counts': operation_counts()}
    if bool(args.tokenizer_dir) != bool(args.provenance):
        parser.error('Pass both --tokenizer-dir and --provenance, or neither')
    if args.tokenizer_dir:
        result['token_checks'] = validate_tokens(rows, template, args.tokenizer_dir, args.provenance)
        result['token_status'] = 'passed'
    else:
        result['token_status'] = 'pending_correct_pinned_Qwen3.5_tokenizer_assets'
        result['token_checks'] = None
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'structure_status': result['structure_status'], 'token_status': result['token_status'],
                      'pair_groups': len(rows), 'planned_cells': operation_counts()['total_answer_evaluation_cells']}))

if __name__ == '__main__':
    main()
