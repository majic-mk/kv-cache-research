"""Bounded random-only BF16 CPU gate. Never downloads or loads pretrained weights.
Contract must be independently reviewed and frozen before this script is invoked.
Results are append-persisted; an existing result blocks rerun. No numerical retries.
"""
import os
os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
import argparse, copy, datetime, hashlib, json, math, resource, sys, time, traceback
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--frozen-contract-sha256', required=True); ap.add_argument('--review', type=Path, required=True)
    args = ap.parse_args(); contract = ROOT/'numerical_contract.json'; c = json.loads(contract.read_text())
    assert sha(contract) == args.frozen_contract_sha256
    frozen=json.loads((ROOT/'numerical_freeze.json').read_text())
    assert sha(Path(__file__))==frozen['runner']['sha256'] and sha(contract)==frozen['contract']['sha256']
    assert args.review.exists(), 'Independent review must exist before forward'
    output = ROOT/'tiny_gate_results.json'; assert not output.exists(), 'Existing outcomes: no silent rerun'
    report = dict(status='RUNNING', started_utc=now(), contract_sha256=sha(contract), script_sha256=sha(Path(__file__)), independent_review_path=str(args.review), independent_review_sha256=sha(args.review), pretrained_weights_loaded=False, pretrained_forwards=0, tests=[], current_test=None)
    started = time.monotonic()
    def save(): output.write_text(json.dumps(report, indent=2)+'\n')
    def begin(name): report['current_test']=name; save()
    def done(name, **metrics): report['tests'].append(dict(name=name, passed=True, **metrics)); report['current_test']=None; save()
    def finite(x): assert bool(x.isfinite().all()), 'Nonfinite tensor'
    def compare(a,b,atol,rtol):
        finite(a);finite(b); a=a.float();b=b.float();delta=(a-b).abs(); tol=atol+rtol*b.abs()
        m=dict(max_abs=float(delta.max()), max_scaled_tolerance_ratio=float((delta/tol).max()), atol=atol, rtol=rtol)
        assert bool((delta<=tol).all()), m
        return m
    try:
        import torch, transformers
        from transformers import Qwen3_5TextConfig, Qwen3_5ForCausalLM
        from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
        torch.set_num_threads(1);torch.set_num_interop_threads(1)
        assert torch.__version__ == '2.9.1+cpu' and torch.version.cuda is None and not torch.cuda.is_available()
        assert sha(Path(hf.__file__)) == 'f3fecce29dee6cea1ac951c947a538fdcf01abfc21f8f0e33a78b535fe6837c3'
        resource.setrlimit(resource.RLIMIT_AS, (8*1024**3, 8*1024**3))
        report['software']=dict(torch=torch.__version__, transformers=transformers.__version__, python=sys.version, modeling_sha256=sha(Path(hf.__file__)), cpu_capability=torch.backends.cpu.get_cpu_capability(), mkldnn_enabled=torch.backends.mkldnn.enabled)
        report['all_tiny_controls_planned']=dict(value_heads=c['tiny_cases']['value_heads'], sequence_lengths=[s['length'] for s in c['tiny_cases']['sequences']], schedules=['full_recompute','exact_prefix','chunked'], repeats=3, operator_lengths=c['tiny_cases']['operator_sequence_lengths'])
        save()
        def tensors(cache):
            for i,l in enumerate(cache.layers):
                if hasattr(l,'recurrent_states'):
                    for k,t in sorted(l.recurrent_states.items()): yield i,'recurrent',str(k),t
                    for k,t in sorted(l.conv_states.items()): yield i,'conv',str(k),t
                else:
                    yield i,'keys','',l.keys;yield i,'values','',l.values
        def clone(cache):
            out=copy.deepcopy(cache);assert out.get_seq_length()==cache.get_seq_length()
            for (i,k,s,a),(ii,kk,ss,b) in zip(tensors(cache),tensors(out)):
                assert (i,k,s)==(ii,kk,ss) and a.data_ptr()!=b.data_ptr() and torch.equal(a,b)
            return out
        def cache_stats(a,b,mode):
            assert a.get_seq_length()==b.get_seq_length()
            aa=list(tensors(a));bb=list(tensors(b));assert len(aa)==len(bb);res=[]
            for (i,k,s,x),(ii,kk,ss,y) in zip(aa,bb):
                assert (i,k,s)==(ii,kk,ss) and x.shape==y.shape
                if mode=='bitwise': assert torch.equal(x,y);m=dict(max_abs=0.0)
                elif mode=='fp32': m=compare(x,y,1e-4,1e-4)
                elif mode=='semantic': m=compare(x,y,.005 if k=='recurrent' else .025,.05)
                else: m=compare(x,y,.002 if k=='recurrent' else .01,.02)
                res.append(dict(layer=i,kind=k,slot=s,actual_dtype=str(x.dtype),reference_dtype=str(y.dtype),**m))
            return res
        def log_stats(a,b,mode):
            if mode=='bitwise': assert torch.equal(a,b);m=dict(max_abs=0.0)
            else:
                at,rt,tvmax=(1e-4,1e-4,1e-4) if mode=='fp32' else ((.025,.02,.01) if mode=='semantic' else (.01,.01,.0025))
                m=compare(a,b,at,rt);tv=float((a.float().softmax(-1)-b.float().softmax(-1)).abs().sum(-1).max()/2)
                assert tv<=tvmax, dict(TV=tv,max=tvmax);m.update(TV=tv)
            return m
        def fwd(model,ids,cache=None):
            n=0 if cache is None else cache.get_seq_length();inp=torch.tensor([ids],dtype=torch.long)
            z=model(input_ids=inp,past_key_values=cache,attention_mask=torch.ones((1,n+len(ids)),dtype=torch.long),position_ids=torch.arange(n,n+len(ids)).unsqueeze(0),use_cache=True,logits_to_keep=1)
            finite(z.logits)
            for _,kind,_,t in tensors(z.past_key_values):
                finite(t)
                if next(model.parameters()).dtype==torch.bfloat16: assert t.dtype==(torch.float32 if kind=='recurrent' else torch.bfloat16),(kind,t.dtype)
            return z
        def run(model,ids,seq,arm):
            if arm=='full_recompute': z=fwd(model,ids)
            elif arm=='exact_prefix':
                k=seq['A']+seq['B'];pre=fwd(model,ids[:k]);saved=clone(pre.past_key_values);z=fwd(model,ids[k:],clone(pre.past_key_values));cache_stats(pre.past_key_values,saved,'bitwise')
            else:
                cache=None;lo=0
                for hi in seq['chunk_stops']: z=fwd(model,ids[lo:hi],cache);cache=z.past_key_values;lo=hi
                assert lo==len(ids)
            base=z.past_key_values;saved=clone(base);first=z.logits[0,-1].clone();candidates=[]
            for candidate in c['tiny_cases']['candidate_ids']:
                branch=clone(base);logits=first;vals=[];ls=[]
                for index,tid in enumerate(candidate):
                    ls.append(logits.clone());vals.append(float(logits.float().log_softmax(-1)[tid]))
                    if index<len(candidate)-1: zz=fwd(model,[tid],branch);branch=zz.past_key_values;logits=zz.logits[0,-1]
                assert all(math.isfinite(x) for x in vals) and math.isfinite(sum(vals)), 'Nonfinite candidate score'
                candidates.append(dict(ids=candidate,logits=ls,sum_logprob=sum(vals),token_logprobs=vals))
            branch=clone(base);logits=first;gen=[];margins=[];greedy_logits=[]
            for index in range(c['tiny_cases']['greedy_steps']):
                greedy_logits.append(logits.clone());tid=int(logits.argmax());gen.append(tid);top=logits.float().topk(2).values;margins.append(float(top[0]-top[1]))
                if index<c['tiny_cases']['greedy_steps']-1: zz=fwd(model,[tid],branch);branch=zz.past_key_values;logits=zz.logits[0,-1]
            cache_stats(base,saved,'bitwise')
            return dict(first=first, cache=base, candidates=candidates, greedy_ids=gen,greedy_top_two_margins=margins,greedy_logits=greedy_logits,greedy_cache=branch)
        def comparisons(a,b,mode):
            logs=[log_stats(a['first'],b['first'],mode)];deltas=[]
            if mode!='semantic': logs.extend(log_stats(x,y,mode) for x,y in zip(a['greedy_logits'],b['greedy_logits']))
            for ca,cb in zip(a['candidates'],b['candidates']):
                logs.extend(log_stats(x,y,mode) for x,y in zip(ca['logits'],cb['logits']))
                delta=ca['sum_logprob']-cb['sum_logprob'];deltas.append(delta)
                if mode=='bitwise':assert delta==0
                elif mode=='fp32': assert abs(delta)<=1e-4, deltas
                elif mode=='bf16': assert abs(delta)<.01, deltas
            margin_delta=deltas[0]-deltas[1]
            if mode=='bf16': assert abs(margin_delta)<.01,margin_delta
            if mode=='fp32': assert abs(margin_delta)<=1e-4,margin_delta
            if mode!='semantic': assert a['greedy_ids']==b['greedy_ids'],dict(actual=a['greedy_ids'],reference=b['greedy_ids'],actual_margins=a['greedy_top_two_margins'],reference_margins=b['greedy_top_two_margins'])
            return dict(logits=logs,cache=cache_stats(a['cache'],b['cache'],mode),greedy_cache=(cache_stats(a['greedy_cache'],b['greedy_cache'],mode) if mode!='semantic' else 'Cross-dtype greedy may differ; not a matched-input endpoint'),candidate_sum_deltas=deltas,candidate_margin_delta=margin_delta,greedy_equal=a['greedy_ids']==b['greedy_ids'],greedy_ids=a['greedy_ids'],reference_greedy_ids=b['greedy_ids'],greedy_top_two_margins=a['greedy_top_two_margins'],near_tie_flag=any(x<=.02 for x in a['greedy_top_two_margins']))
        with torch.inference_mode():
            torch.manual_seed(20261003)
            for vh in [2,4]:
                for n in [19,149]:
                    name=f'operators_{vh}heads_{n}tokens';begin(name)
                    q=torch.randn(1,n,2,4).bfloat16().repeat_interleave(vh//2,2);k=torch.randn_like(q);v=torch.randn(1,n,vh,3).bfloat16();g=-torch.rand(1,n,vh)*.4;beta=torch.rand(1,n,vh).bfloat16();state=torch.randn(1,vh,4,3)
                    bf=[q,k,v,g,beta];fp=[x.float() for x in bf]
                    y,s=hf.torch_chunk_gated_delta_rule(*bf,initial_state=state,output_final_state=True,use_qk_l2norm_in_kernel=True)
                    yf,sf=hf.torch_chunk_gated_delta_rule(*fp,initial_state=state,output_final_state=True,use_qk_l2norm_in_kernel=True)
                    yr,sr=hf.torch_recurrent_gated_delta_rule(*fp,initial_state=state,output_final_state=True,use_qk_l2norm_in_kernel=True)
                    assert y.dtype==torch.bfloat16 and s.dtype==torch.float32
                    metrics=dict(bf16_output=compare(y,yf,1/128,1/128),fp32_recurrence_state=compare(s,sf,1e-4,1e-4),fp32_chunk_vs_recurrent_output=compare(yf,yr,1e-4,1e-4),fp32_chunk_vs_recurrent_state=compare(sf,sr,1e-4,1e-4))
                    raw=torch.randn(1,9,n).bfloat16();weight=(torch.randn(9,4)*.1).bfloat16();cy=hf.causal_conv1d_fn(raw,weight,activation='silu');cf=hf.causal_conv1d_fn(raw.float(),weight.float(),activation='silu')
                    metrics['conv']=compare(cy,cf,1/128,1/128);done(name,**metrics)
            for seed,vh in zip(c['tiny_cases']['seeds'],c['tiny_cases']['value_heads']):
                torch.manual_seed(seed)
                cfg=Qwen3_5TextConfig(vocab_size=97,hidden_size=32,intermediate_size=64,num_hidden_layers=4,num_attention_heads=4,num_key_value_heads=2,head_dim=8,linear_key_head_dim=4,linear_value_head_dim=3,linear_num_key_heads=2,linear_num_value_heads=vh,linear_conv_kernel_dim=4,rope_parameters={'rope_type':'default','rope_theta':10000.,'partial_rotary_factor':.5,'mrope_section':[1,1,0]},layer_types=c['tiny_cases']['layers'])
                cfg._attn_implementation='eager';original=Qwen3_5ForCausalLM(cfg).eval().cpu();bf16=copy.deepcopy(original).to(dtype=torch.bfloat16);rounded=copy.deepcopy(bf16).float()
                report.setdefault('model_metadata',[]).append(dict(seed=seed,value_heads=vh,parameter_count=sum(p.numel() for p in bf16.parameters()),parameter_dtypes=sorted(set(str(p.dtype) for p in bf16.parameters())),config=cfg.to_dict()))
                for seq in c['tiny_cases']['sequences']:
                    ids=torch.randint(1,96,(seq['length'],)).tolist();case=f'heads{vh}_length{len(ids)}';refs={}
                    report.setdefault('inputs',[]).append(dict(case=case,ids=ids,sequence=seq))
                    for dtype,model in [('fp32',original),('bf16',bf16)]:
                        for arm in ['full_recompute','exact_prefix','chunked']:
                            primary=None
                            for repeat in range(3):
                                name=f'{case}_{dtype}_{arm}_repeat{repeat}';begin(name);out=run(model,ids,seq,arm)
                                if repeat:metrics=comparisons(out,primary,'bitwise')
                                elif arm=='full_recompute':primary=out;refs[dtype]=out;metrics=dict(greedy_ids=out['greedy_ids'],candidate_sums=[q['sum_logprob'] for q in out['candidates']],greedy_top_two_margins=out['greedy_top_two_margins'],cache_dtypes=[dict(layer=i,kind=k,dtype=str(t.dtype)) for i,k,_,t in tensors(out['cache'])])
                                else:primary=out;metrics=comparisons(out,refs[dtype],dtype)
                                done(name,**metrics)
                    name=f'{case}_bf16_vs_rounded_fp32_semantic';begin(name);sem=run(rounded,ids,seq,'full_recompute');done(name,**comparisons(refs['bf16'],sem,'semantic'))
                    name=f'{case}_bf16_vs_original_fp32_descriptive';begin(name)
                    # Cross-precision original weights are descriptive, not another acceptance threshold.
                    done(name,first_logit_max_abs=float((refs['bf16']['first'].float()-refs['fp32']['first'].float()).abs().max()),greedy_equal=refs['bf16']['greedy_ids']==refs['fp32']['greedy_ids'])
        report.update(status='PASS_TINY_NUMERICAL_CONTROLS_ONLY', qualification_authorized=False)
    except Exception as exc:
        report.update(status='FAIL_TINY_NUMERICAL_OR_IMPLEMENTATION_GATE',failure=dict(test=report['current_test'],exception=repr(exc),traceback=traceback.format_exc()),qualification_authorized=False,unrun_reason='Stopped at first failure; all remaining planned controls and all 16 pretrained cells unrun')
        print(traceback.format_exc(),flush=True)
    finally:
        report.update(finished_utc=now(),wall_seconds=time.monotonic()-started,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        save();print(json.dumps({k:report.get(k) for k in ['status','wall_seconds','peak_RSS_bytes','failure']}),flush=True)
if __name__=='__main__':main()
