"""Model-free tests; never downloads or performs a forward."""
import hashlib,json,unittest
from pathlib import Path
from validate_protocol import ROOT,contexts,load_fixtures,render,score_answer,validate_structure
class QualificationTests(unittest.TestCase):
 def setUp(self):
  self.p=json.loads((ROOT/'protocol.json').read_text());self.t=json.loads((ROOT/'template.json').read_text());self.rows=load_fixtures()
 def test_fixture_bytes_unchanged(self):
  for name in ['hybrid_cpu_quality','hybrid_cpu_quality_v2']:
   self.assertEqual((ROOT/'fixtures.jsonl').read_bytes(),(ROOT.parent/name/'fixtures.jsonl').read_bytes())
 def test_rendered_texts_unchanged_all_64(self):
  t=json.loads((ROOT.parent/'hybrid_cpu_quality_v2/template.json').read_text())
  for row in self.rows:
   for ctx in contexts(row): self.assertEqual(render(row,ctx,self.t),render(row,ctx,t))
 def test_structure(self): self.assertEqual(len(validate_structure(self.rows,self.t)),16)
 def test_historical_freezes_unchanged(self):
  for name in ['hybrid_cpu_quality','hybrid_cpu_quality_v2']:
   r=ROOT.parent/name;f=json.loads((r/'freeze_manifest.json').read_text())
   for filename,d in f['files'].items(): self.assertEqual(hashlib.sha256((r/filename).read_bytes()).hexdigest(),d['sha256'])
 def test_failed_08_result_preserved(self):
  rows=[json.loads(x) for x in (ROOT.parents[1]/'diagnostics/hybrid_cpu_competence/v2_probe_cells.jsonl').read_text().splitlines()]
  self.assertEqual(len(rows),16);done=[x for x in rows if x['status']=='completed'];self.assertEqual(len(done),1)
  r=done[0];self.assertEqual((r['pair_id'],r['variant'],r['arm']),('d01','A1','full_recompute'));self.assertEqual(r['decoded_answer_text'],'blue');self.assertEqual(r['expected_answer'],'red');self.assertFalse(r['normalized_answer_correct'])
 def test_only_original_initial_cells(self):
  want=[[g,v,a] for g in ['d01','d05'] for v in ['A1','A2','U1','U2'] for a in ['full_recompute','exact_prefix']]
  self.assertEqual(self.p['execution_order'],want);self.assertEqual(self.p['cells_max'],16)
 def test_resource_limits_not_relaxed(self):
  r=self.p['resources'];self.assertEqual(r['process_RSS_safety_stop_bytes'],8589934592);self.assertEqual(r['host_budget_bytes'],9000000000);self.assertEqual(r['free_disk_reserve_bytes'],5000000000);self.assertEqual(r['wall_seconds_including_load_and_all_execution'],1800);self.assertFalse(r['GPU_allowed']);self.assertFalse(r['cleanup_allowed'])
 def test_competence_first(self): self.assertTrue(self.p['competence']['stop_immediately_on_first_wrong_full_recompute'])
 def test_numerical_contract_identity(self):
  f=json.loads((ROOT/'numerical_freeze.json').read_text())
  for d in [f['contract'],f['runner']]:self.assertEqual(hashlib.sha256((ROOT/d['path']).read_bytes()).hexdigest(),d['sha256'])
 def test_strict_answer_noise_and_greedy(self):
  c=json.loads((ROOT/'numerical_contract.json').read_text());b=c['bf16_exact_schedule_controls'];self.assertEqual(b['candidate_sum_logprob_delta_abs_strictly_below'],.01);self.assertEqual(b['candidate_margin_delta_abs_strictly_below'],.01);self.assertEqual(b['greedy_token_disagreements_allowed'],0)
 def test_scoring_not_reworded(self):
  for text in ['red',' RED ','red.','red!','red?']: self.assertTrue(score_answer(text,'red',eos_within_cap=True))
  for text in ['the answer is red','red blue','red...','blue','']:self.assertFalse(score_answer(text,'red',eos_within_cap=True))
  self.assertFalse(score_answer('red','red',eos_within_cap=False))
 def test_all_64_new_token_checks_pass(self):
  d=json.loads((ROOT/'token_validation.json').read_text());self.assertEqual(d['token_status'],'passed');self.assertEqual(len(d['token_checks']['contexts']),64)
  old=json.loads((ROOT.parent/'hybrid_cpu_quality_v2/token_validation.json').read_text());self.assertEqual(d['token_checks']['contexts'],old['token_checks']['contexts'])
 def test_no_method_claim(self): self.assertTrue(self.p['author_HYPIC_comparison'].startswith('BLOCKED'));self.assertEqual(self.p['pretrained_model_forwards_in_preparation'],0)
if __name__=='__main__':unittest.main(verbosity=2)
