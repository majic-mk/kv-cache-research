# Exploratory 2B BF16 CPU substrate qualification, v3

## Current finding

The separate, predeclared **tiny random-model numerical gate passed 84 controls**, and **all 64 pinned-2B tokenizer/template integrity checks passed**. No pretrained forward has been performed by this preparation task. These findings clear only those two preparation gates; they do not establish 2B competence, fit, quality improvement, a repair mechanism, HYPIC reproduction, or a paper contribution.

The original 0.8B FP32 failure remains unchanged: d01/A1/full answered **blue** instead of **red**, and the other 15 initial cells never ran. V1's token-length failure, V2's one-space pre-outcome revision, the failed pre-inference logging attempt, and both historical freeze manifests are preserved. Thirteen model-free tests verified this history and exact fixture/rendered-text continuity.

## One checkpoint, one bounded question

This is explicitly exploratory model selection prompted by the preserved 0.8B failure. Only `Qwen/Qwen3.5-2B` at revision `15852e8c16360a2fea060d615a32b45270f8a8fc` is eligible. The purpose is to ask whether this checkpoint is a usable substrate for the existing constructed fixtures. Passing would permit a later research decision; it does not automatically permit a reuse matrix.

The new scientific reference is full recomputation under ordinary direct BF16-loaded CPU execution, eager attention and the unmodified official PyTorch fallbacks. The official configuration declares `text_config.dtype=bfloat16` and `mamba_ssm_dtype=float32`. Source code explicitly promotes recurrence inputs/accumulation to FP32 and uses internal FP32 normalization and attention softmax. Output logits remain BF16, so scoring promotes them to FP32 before log-softmax, candidate sums, TV, margins and error statistics. Greedy argmax uses the unchanged model output.

The source checkpoint contains 1,881,825,088 text parameters, including 2,592 stored FP32 elements and 1,881,822,496 stored BF16 elements. Storage dtype is not a loaded-parameter guarantee: ordinary requested BF16 loading may cast the stored scalars. A future run must record actual per-parameter and per-cache dtypes, without selective post-outcome precision overrides. The tiny model used all-BF16 parameters; its recurrent caches were FP32 and convolution/attention caches BF16. No unrun 2B FP32 equivalence is claimed.

Primary sources (pinned and locally hash-verified):

- [Official 2B configuration](https://huggingface.co/Qwen/Qwen3.5-2B/blob/15852e8c16360a2fea060d615a32b45270f8a8fc/config.json)
- [Official 2B metadata](https://huggingface.co/api/models/Qwen/Qwen3.5-2B/revision/15852e8c16360a2fea060d615a32b45270f8a8fc?blobs=true)
- [Official 2B tokenizer configuration](https://huggingface.co/Qwen/Qwen3.5-2B/blob/15852e8c16360a2fea060d615a32b45270f8a8fc/tokenizer_config.json)
- [Official Transformers source](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/qwen3_5/modeling_qwen3_5.py)

## Numerical freeze and observed tiny results

`numerical_contract.json` was finalized before every BF16 forward and independently reviewed. Its SHA-256 is `34e903f80162b661eb504e26b16273e5fb5aeaa361a728dd3d69c6a26a7f88f3`; no tolerance, case, seed, model shape or precision change was made after execution. The runnable script's frozen hash is in `numerical_freeze.json`; exact pre-run independent review bytes are retained as `tiny_admission_review_pre_run.md` and match the execution receipt.

The test used two actual random official hybrid models (2 and 4 value heads), 46- and 229-token sequences, and separate FP32 original-weight and BF16-rounded-weight FP32 semantic controls. BF16 operator references consumed the same rounded inputs. Full recomputation, independent exact-prefix continuation, and nontrivial chunk schedules crossed convolution histories and 64-token recurrence chunk boundaries, including single-token cached decoding. Every schedule ran three times. All repeated logits, candidate scores, greedy-step logits, post-prefill caches and final greedy caches were bitwise equal. All score and output tensors were finite. Every branch began from a verified equal, non-aliasing clone; sources remained unchanged.

Frozen engineering gates include:

- BF16 full/exact/chunk logit absolute/relative tolerance 0.01/0.01; TV at most 0.0025
- FP32 recurrent-cache endpoint absolute/relative tolerance 0.002/0.02; BF16 convolution/KV tolerance 0.01/0.02
- Both candidate-sum and candidate-margin noise strictly below 0.01 nat, one tenth of the unchanged future 0.1-nat sensitivity threshold
- Zero exact-control greedy-token disagreement, including near ties; top-two margins at or below 0.02 are reported, never exempted
- FP32 semantic/scheduling and operator tolerances are separately specified, not inherited as if BF16 were FP32

Observed across eight BF16 exact/chunk comparisons:

- Maximum logit difference, TV, candidate-sum difference and candidate-margin difference: **0**
- Greedy disagreements: **0**; six near-tie cases retained
- Maximum recurrent endpoint difference: **2.2846506908535957e-9**
- Maximum convolution/KV endpoint difference: **0**
- Runtime **9.9555 seconds**; peak process RSS **406,200,320 bytes**; clean external watchdog

These finite small-random-graph results support implementation feasibility, not pretrained numerical accuracy at scale. The subsequent 2B full/exact pairs must still independently satisfy the frozen answer-level and all-cache numerical gates. Three repeats and chunked controls apply only to the tiny stage. This task intentionally performed no 0.8B BF16 bridge or other pretrained forward; the tighter preparation scope differs from that optional recommendation in the selection review.

## Token and prompt continuity

`fixtures.jsonl` is byte-identical to both historical freezes. All rendered texts are identical to v2; template edits change only model/source metadata. Tokenizer payload reuse was allowed only after matching its exact official pinned-2B LFS SHA-256. The 2B tokenizer config and separate Jinja template were independently verified, and their template contents were checked for exact agreement.

The validator rendered the official 2B text-only chat template independently for every context, encoded complete strings once, checked cut boundaries, identical B/Q slices, equal A1/A2 and U1/U2 lengths, 128–256-token interiors, answer candidate plus EOS IDs, and all original span/length requirements. All 64 resulting context records exactly equal v2 after these new checks. Full prompt lengths remain 229–248 tokens. No context, question, candidate, gold, split or order was changed or removed.

## Pretrained admission and stopping rules

Only after separate verified asset/resource admission and independent runner review may the original 16 cells run, in this exact nesting order:

1. Groups d01, d05
2. Variants A1, A2, U1, U2
3. Arms full_recompute, exact_prefix

Every full arm uses a fresh complete prompt. Every exact arm uses an independent fresh A+B prefill, a verified complete-cache clone, and Q at explicit absolute positions. All answers are greedily decoded within the existing eight-token cap and scored by the unchanged narrow parser; strict gold-token equality is also recorded. Both changed-prefix pairs and all four unrelated full contexts must be correct. Stop on the **first wrong full answer**, first numerical discrepancy, integrity problem, or resource failure. Preserve each attempted and every unrun cell.

Caps remain 30 minutes including loading and execution, 15 minutes maximum loading, 8 GiB process RSS, 9 GB total host budget, and at least 5 GB free disk. No GPU, paid service, larger model, precision rescue, cap increase, cleanup, rewording, tolerance tuning, retry to select a favorable result, or additional pretrained control is authorized by this protocol. Resource measurements and an external watchdog are required; theoretical parameter bytes alone do not establish fit.

The original checkpoint shard is 4,548,221,488 bytes. Its full local retention does not meet the recorded disk reserve. A separately audited asset worker may hash the **entire** official stream against LFS SHA-256 while retaining exact language-model tensor bytes in a separately hashed, truthfully labeled derived safetensors artifact. This is an asset projection with discarded vision/MTP bytes, not an identical copy of the original file. Every name, shape, dtype, offset and payload must be independently verified; standard official text-model loading must report clean keys. A streaming proposal or partial file is not a verified checkpoint. No custom model loader may be developed to rescue fit.

## Scientific boundary

The released-HYPIC fidelity blocker remains unresolved. An explicitly source-conditioned, seam-corrected reference would be a corrected HYPIC-inspired reference, not a released-code reproduction. No HYPIC, cache reuse, donor, repair, hidden-state quality surrogate, natural benchmark, speedup, journal outcome or publication claim follows from this qualification. On a pass, stop and decide whether the separate causal diagnostic is justified; on a failure, close this affordable same-family seed.

## Audit files

- `protocol.json`, `template.json`, `fixtures.jsonl`: prospective 2B-only bounded question
- `numerical_contract.json`, `numerical_freeze.json`, `tiny_admission_review_pre_run.md`: pre-BF16-outcome contract and review
- `run_tiny_gate.py`, `watch_tiny_gate.py`, `tiny_gate_results.json`, `tiny_gate_summary.json`, `tiny_watchdog.json`, `tiny_gate.log`: the one completed random-only numerical run
- `validate_protocol.py`, `test_protocol.py`, `tests.log`: model-free integrity checks
- `tokenizer_provenance.json`, `token_validation.json`, `token_validation.log`, `token_extent_summary.json`: fresh official 2B token/template checks
- `result_contract.json`: retained record fields; unused reuse/donor fields remain null and do not authorize those arms

Do not rerun the completed tiny gate to improve its outcome. The runner rejects existing results, and shell exit success alone does not establish a pass: check the explicit result status and clean watchdog together.
