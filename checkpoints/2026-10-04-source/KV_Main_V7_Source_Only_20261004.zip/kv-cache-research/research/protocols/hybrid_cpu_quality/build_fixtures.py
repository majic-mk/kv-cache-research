"""Deterministically emit the frozen, model-independent mechanism fixture texts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BEFORE = (
    "Segment B:\n"
    "The following notes describe a routine visit to a small records office. "
    "The entrance was open, the lamps were working, and the chairs were arranged beside the wall. "
    "A clock stood above the reception desk. The waiting area contained a plain table, a calendar, "
    "a glass of water, and a stack of blank forms. Nobody changed the assignments listed in the prefix.\n"
)
AFTER = (
    "\nAfter these events, the office closed for a short cleaning break. "
    "The staff wiped the table, checked the windows, collected the blank forms, and switched off the lamps. "
    "The clock stayed above the desk. These final housekeeping notes add no new assignments, "
    "change no names, and do not reverse any earlier action.\n\n"
)
# Every ordered row is an independently scored pair group. The two variants swap
# entity roles; the reused B bytes, question, and candidate order stay identical.
ROWS = [
    ("d01", "development", "role_lookup", "Alice", "Bruno", "courier", "observer",
     "The courier received the red key. The observer received the blue key.",
     "What color key did Alice receive?", "red", "blue"),
    ("d02", "development", "alias_lookup", "Clara", "David", "person called Finch", "person called Robin",
     "Finch collected the green folder. Robin collected the gold folder.",
     "What color folder did Clara collect?", "green", "gold"),
    ("d03", "development", "demonstrative_coreference", "Elena", "Felix", "visitor referred to as this guest", "visitor referred to as that guest",
     "This guest waited in the north room. That guest waited in the south room.",
     "Which room did Elena wait in?", "north", "south"),
    ("d04", "development", "ordinal_reference", "Grace", "Henry", "first person on the list", "second person on the list",
     "The first person on the list chose tea. The second person on the list chose coffee.",
     "Which drink did Grace choose?", "tea", "coffee"),
    ("d05", "development", "occupational_reference", "Irene", "Jacob", "editor", "artist",
     "The editor stored a copper badge. The artist stored a silver badge.",
     "What material was Irene's badge made of?", "copper", "silver"),
    ("d06", "development", "team_reference", "Karen", "Louis", "member of team Cedar", "member of team Maple",
     "The Cedar member took the east exit. The Maple member took the west exit.",
     "Which exit did Karen take?", "east", "west"),
    ("d07", "development", "possessive_reference", "Maria", "Noah", "owner of the suitcase", "owner of the backpack",
     "The suitcase owner ate an apple. The backpack owner ate a pear.",
     "Which fruit did Maria eat?", "apple", "pear"),
    ("d08", "development", "label_reference", "Olive", "Peter", "holder of ticket Alpha", "holder of ticket Beta",
     "The Alpha ticket holder received a circle stamp. The Beta ticket holder received a square stamp.",
     "Which shape was on Olive's stamp?", "circle", "square"),
    ("h01", "held_out", "role_lookup", "Quinn", "Rosa", "guide", "listener",
     "The guide received the white scarf. The listener received the black scarf.",
     "What color scarf did Quinn receive?", "white", "black"),
    ("h02", "held_out", "alias_lookup", "Sarah", "Thomas", "person called Pine", "person called Birch",
     "Pine collected the orange envelope. Birch collected the purple envelope.",
     "What color envelope did Sarah collect?", "orange", "purple"),
    ("h03", "held_out", "demonstrative_coreference", "Uma", "Victor", "visitor referred to as this client", "visitor referred to as that client",
     "This client waited by the river gate. That client waited by the garden gate.",
     "Which gate did Uma wait by?", "river", "garden"),
    ("h04", "held_out", "ordinal_reference", "Wendy", "Xavier", "first person on the register", "second person on the register",
     "The first person on the register chose rice. The second person on the register chose pasta.",
     "Which food did Wendy choose?", "rice", "pasta"),
    ("h05", "held_out", "occupational_reference", "Yara", "Zach", "baker", "tailor",
     "The baker stored an oak button. The tailor stored a metal button.",
     "What material was Yara's button made of?", "oak", "metal"),
    ("h06", "held_out", "team_reference", "Alan", "Betty", "member of team Coral", "member of team Pearl",
     "The Coral member took the upper passage. The Pearl member took the lower passage.",
     "Which passage did Alan take?", "upper", "lower"),
    ("h07", "held_out", "possessive_reference", "Celia", "Dylan", "owner of the parcel", "owner of the satchel",
     "The parcel owner ate a peach. The satchel owner ate a plum.",
     "Which fruit did Celia eat?", "peach", "plum"),
    ("h08", "held_out", "label_reference", "Esther", "Frank", "holder of card Delta", "holder of card Gamma",
     "The Delta card holder received a star stamp. The Gamma card holder received a heart stamp.",
     "Which shape was on Esther's stamp?", "star", "heart"),
]

def fixtures():
    for pid, split, family, p1, p2, role1, role2, important, question, ans1, ans2 in ROWS:
        a1 = f"{p1} is the {role1}. {p2} is the {role2}."
        a2 = f"{p2} is the {role1}. {p1} is the {role2}."
        b = BEFORE + important + AFTER
        yield {
            "pair_id": pid, "split": split, "family": family,
            "A1": a1, "A2": a2, "B": b, "Q": question,
            "expected_answer_A1": ans1, "expected_answer_A2": ans2,
            "answer_candidates": [ans1, ans2],
            "important_interior_text": important,
            "important_interior_char_span": [len(BEFORE), len(BEFORE) + len(important)],
            "B_sha256": hashlib.sha256(b.encode()).hexdigest(),
            "unrelated_prefix_controls": [
                {"variant": "U1", "A": a1 + " An unrelated weather bulletin mentions rain.", "expected_answer": ans1},
                {"variant": "U2", "A": a1 + " An unrelated weather bulletin mentions snow.", "expected_answer": ans1},
            ],
            "exact_prefix_control": "Build a fresh exact cache for this target A+B, clone all channels, and continue identical Q.",
            "rationale": "A1/A2 swap the two referents. The answer depends on a B sentence beyond the seam; B and Q never change within a pair. U1/U2 change only an irrelevant weather sentence.",
            "evidence_class": "constructed_mechanism_fixture_not_natural_benchmark",
        }

if __name__ == "__main__":
    target = ROOT / "fixtures.jsonl"
    target.write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True) + "\n" for x in fixtures()))
