# Conditional HYPIC recurrent-conditioning CPU quality protocol

**Status: pre-outcome text and decision-rule freeze, 2026-10-03 UTC. No model outcomes.**
This directory is independent of the adapter/algebra implementation in
`research/diagnostics/hybrid_recurrence_cpu/`. It does not download assets, install
packages, load weights, execute inference, use GPU, or authorize remote work.

## Question and claim boundary

Does changed earlier context cause answer-relevant recurrent-channel error when an
identical later segment is reused with a source-audited realization of HYPIC-style
transition, position, convolution and seam repairs? A hidden-state norm discrepancy alone is insufficient.
The relevant gap is already acknowledged by HYPIC, and this is a bounded problem
screen, not a new method or a natural benchmark.

Read `../../architecture_specific_gap_screen.md` first. Mandatory source pins:

- HYPIC `98147c01909004e66d98bcb18b886927d41b0ee5`
- Qwen/Qwen3.5-0.8B `2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`
- Transformers source reference `02d8fb9784e8f14a1251e4c992cd82a5762417c6`

The checkpoint is the small dense hybrid, not the large MoE checkpoint. A result
here does not estimate large-model degradation or serving throughput. The CPU
adapter must publish precisely which author semantics it ports and any remaining
non-equivalence; a partial emulation must not be named an author reproduction.

## Frozen constructed set

`fixtures.jsonl` contains **16 pair groups: d01–d08 development, h01–h08 held out**.
Each has A1, A2, one B, one Q, two exact answers, the important B span and two
unrelated-prefix controls U1/U2. A1/A2 exchange two referents. Their gold answers
differ. U1/U2 retain A1's assignments and change only unrelated weather; their
gold answer is the same. Names and answer vocabulary are disjoint across splits.
The held-out set shares construction families and filler with development: it
checks transfer to different slots, **not unseen-template generalization**.

The eight families are role lookup, alias lookup, demonstrative coreference,
ordinal reference, occupational reference, team reference, possessive reference,
and label reference. The full literal texts are in the JSONL, not reconstructed
from a model's output. `build_fixtures.py` deterministically recreates them. The
shared filler deliberately puts the relevant sentence well inside B. It is an
artificial control; do not call it realistic evidence merely because it reads as
prose. Prefix assignments, the interior B sentence and Q must jointly determine
the gold answer. Full attention may provide a shortcut; that is a legitimate way
for the proposed failure to be absent, not a reason to redesign after observing
results.

`template.json` freezes the entire text-only, one-user-message rendering. It uses
the pinned official assistant suffix with the empty thinking block. No system
message, candidate list, tools, images, extra BOS, sampling or alternate prompting
may be introduced in one arm. The important span must start at a zero-based B
token index >=32, so it is outside w=32 (tokens 0–31). B must contain 128–256 tokens;
A (including template preamble) <=160, Q (including generation suffix) <=96; total
prompt <=512. Answers are one word but **are not assumed to be one token**.

### Integrity gate, currently partially verified

The dependency-free structural validator passes. The local previously staged
Qwen3-8B tokenizer is a different vocabulary and must not be substituted.
**Correct Qwen3.5 token lengths and token identity have not yet been measured.**
Run token validation only with already available, source-recorded assets from the
exact pin and an existing `tokenizers`/`jinja2` environment:

```
python research/protocols/hybrid_cpu_quality/validate_protocol.py
python research/protocols/hybrid_cpu_quality/validate_protocol.py \
  --tokenizer-dir /path/to/pinned/tokenizer \
  --provenance /path/to/tokenizer_provenance.json \
  --output /new/run/path/token_validation.json
```

The provenance JSON must state model_id, revision, and `files` entries for
`tokenizer.json` and `tokenizer_config.json`, each with the exact official pinned
resolve URL and SHA-256. Hashes are integrity records, not authentication proofs.
The validator checks the official rendered template, special IDs, full-string
offsets, absence of cross-boundary tokens, B/Q identity across all four contexts,
equal A1/A2 lengths and equal U1/U2 lengths, interior location and answer IDs.
All arms take slices of the **same full-prompt encoding**; separately tokenized
text pieces must not silently introduce another prompt. Only B's token slice is
used for the isolated source build. Recompute Q freshly in every arm.

If any text/template fails token validation, stop. A new version may correct the
mechanical issue **before any model outcomes are seen**, with old hashes retained
and a reason logged. Do not drop a group or adapt wording to observed accuracy.

## Mandatory implementation gate and eight quality arms

**Current blocking condition:** source inspection establishes that the released
pin can cache a full-B tuple then apply it after replaying a seam, and its source
trace can include earlier warmup context. The paper-style interior-only construction
is consequently **not a reproduction of the released author code**. All four
`intended_w*` arms below are explicitly HYPIC-inspired intended-semantics references.
No reuse-quality comparison is authorized by this freeze while the author-literal
comparator and source warmup contract remain unresolved. An independently reviewed
pre-outcome amendment must specify them; it must add and count any extra literal
source arms rather than replacing them silently. The current 976 count covers only
the declared intended-reference grid. See the local
[source contract audit](../../diagnostics/hybrid_recurrence_cpu/SOURCE_AUDIT.md) and
[independent source review](../../hypic_baseline_source_review.md).

Do not interpret quality until the independent CPU algebra gate passes. It must
cover identical-input affine composition, two-layer changed-input witness,
convolution tails, positions/RoPE, seam inclusion/exclusion, real 16/16 head shape
and a labeled synthetic unequal grouped-head shape. Float64 fixture agreement is
an algebra test; it is not checkpoint quality or pretrained cache parity.

For **every one of 64 target contexts** (16 groups x A1/A2/U1/U2), run all eight:

1. `full_recompute`: monolithic fresh target A+B+Q, no reused state
2. `exact_prefix`: freshly build the **same target A+B**, clone every cache channel,
   then fresh Q. This is matched-prefix reuse, not an isolated-segment baseline
3. `chunked_16`: fresh target stream in 16-token chunks, carry every cache, use
   original absolute positions and final short chunk. Never reset between chunks
4. `intended_w0`: isolated B with cumulative transition, position repair, previous
   convolution-tail repair and uncompressed full-attention KV; no seam replay
5. `intended_w8`: same controls plus first 8 B tokens recomputed under target A
6. `intended_w16`: same, first 16 B tokens recomputed
7. `intended_w32`: same, first 32 B tokens recomputed; predeclared primary reuse arm
8. `all_seam`: enter the **same adapter seam route** with w=|B|, recompute every B
   token under A, no retained cached-interior contribution. This is an adapter-only
   parity control: the author path caps its seam at |B|-1

An all-seam shortcut that calls the reference routine while bypassing stitching
is not an adapter test. Keep author transition orientation/precision, convolution
width four, actual partial/interleaved RoPE and original causal positions. For the **intended interior-only reference**,
w>0 the cached interior tuple excludes seam writes and seam transition factors,
while source interior hidden states were still generated by the original isolated
B including its seam. Deleting the source seam and recoding B[w:] is a different
baseline. The actual author baseline must additionally preserve the source-confirmed
warmup context and transition scope. Its cold full-B tuple plus replayed seam
behavior must never be silently replaced by this intended correction. The missing
author-literal comparator blocks comparisons; no checkpoint quality result from
the intended reference alone may be stated as HYPIC quality.
Previous-tail convolution repair and the seam are separate requirements.
Full-attention KV is never sparsified or quantized. All model arms use one exact
checkpoint, dtype (FP32 CPU), backend, mask, tokenizer, position metadata and
thread configuration. Run batch one, evaluation/inference mode, no autograd.

Before judgments, full/exact/chunked/all-seam must have identical decoded answers
and greedy answer token sequences, and satisfy the frozen numeric parity limits
in `protocol.json`. Compare logits at the first answer step and teacher-forced
candidate continuations, full-attention K/V where comparable, and each recurrent
and conv endpoint. Endpoint tolerances are assessed relative to that tensor's
scale; the logit and distribution checks cannot be replaced by a state norm.
Any missing arm, position difference, failed all-full recovery or parity failure
makes the implementation invalid for causal claims. Report the offending cell.
Do not relax tolerances after seeing harm.

## Scoring, competence and sensitivity gate

Generate greedily at most 8 tokens and stop at the first official EOS. Preserve
all generated token IDs and decoded text. Primary answer scoring requires EOS
within the cap, strips outside whitespace, case-folds, and permits at most one
terminal '.', '!' or '?'. The result must otherwise be exactly the gold word.
No substring extraction, semantic judge, hidden synonym list or best-of decoding.
Separately report strict equality to the canonical gold+EOS token sequence.

For both candidate answers, score the entire candidate+EOS with teacher forcing
from an independent clone of the post-Q cache. Sum log probabilities; report
length-normalized values secondarily, never as a silently substituted score.
Record correct-answer sum log probability, two-candidate margin, first-token total
variation to full and maximum absolute logit difference. Candidate branches and
greedy generation must never mutate a cache subsequently used by another arm.

Process the development split first; its full-recompute stage is a stop gate:

- At least **6/8 groups must have both A1 and A2 correct**, and at least **14/16
  unrelated contexts** must be correct
- After development controls/arms are complete and valid, use the exact frozen
  setup on held out. Its competence threshold is also 6/8 fully correct pairs and
  14/16 unrelated contexts. No held-out tuning, replacement or additional examples
- Report all 64 contexts and all planned cells, as well as the predetermined
  full-recompute-both-correct paired subset. The subset is a labeled competence
  analysis; it never replaces the full-set denominator

Noise calibration uses the fixed d01/d05 groups, **all four contexts**, with full,
exact-prefix and chunked arms run three times total. Their first runs are already
in the primary grid, hence 48 additional evaluations. Fix CPU threads; record
any nondeterminism, execution order and timings. Zero answer/token flips and
numeric parity are required. More runs of a prompt do not create more samples.

A minimal **screen-positive answer-harm signal** on held out requires, at w=32:

- At least two A1/A2 full-correct -> reuse-wrong prompts from **two different**
  fully full-correct pair groups, and an overall held-out A1/A2 accuracy decrease
  of at least 2/16 = 12.5 percentage points
- Zero such flips in the exact/chunked/all-seam controls
- Those harmed cases also have a correct-answer log-probability loss exceeding
  max(0.10 nat, ten times that case's largest exact/chunked/all-seam absolute
  log-probability delta, ten times the fixed-repeat maximum drift)

This is a coarse **sensitivity threshold, not a statistical-power claim**. The
independent unit is a pair group; 16 prompts are not 16 unrelated draws. Report
all count/rate denominators and both directions of answer changes. No p-value or
population effect is warranted by this deliberately tiny constructed set. A
smaller effect, norm-only effect, or no effect is a no-go for investment from this
screen, not proof of universal absence. Record unrelated-prefix answer changes as
a specificity check; comparable harm there weakens conditioning-specific framing.

## Attribution: independently intervene on recurrent, attention and conv channels

Only after valid competence/parity and a screen-positive held-out w32 gap, run the
entire fixed attribution grid on **all 32 A1/A2 contexts**, not only failures.
No U context is added selectively. At the end of B, construct the eight endpoint
donors R x K x C, each baseline-w32 (0) or exact-target-full (1):

- R: all 18 recurrent endpoint tensors
- K: all six uncompressed full-attention K/V tensors plus their valid positions
- C: all recurrent-layer convolution histories, kept separate from R

Carry identical cache length/position metadata, validate shapes/device/dtype, clone
before use, and run the identical Q. Cell 000 reuses the already scored w32 cell;
**111 is explicitly rerun** and must recover reference logits/answers. Seven new
cells x32 =224. Also report all four R x K cells at C=0 and at C=1, interactions,
and which donor channels rescue each error. A recurrent-donor rescue identifies
an answer-relevant recurrent endpoint channel. It **does not prove** the earlier
error originated exclusively in recurrent layers; attention can have fed it.
If only K or C rescues, narrow or reject recurrent-input attribution. Strong
interactions require a mixed-channel explanation, not exclusive attribution.

For forcing attribution, there are six fixed recurrent groups (three recurrent
layers before each full-attention layer). On all 32 A1/A2 contexts, take one group
at a time: obtain full-target input hidden states for its three recurrent layers,
build the group's affine tuples from those inputs, and substitute only that
oracle-conditioned recurrent update into the unchanged w32 route. Keep the
baseline convolution donor for the endpoint test; if oracle inputs require a
conv-operation change, expose it as a joint intervention, never hide it in R.
Compare against the same-group identical-input recurrence truth. Precisely log
whether a trace is pre-conv, post-conv or post-projection. The independent gate
worker owns this contract, and must refuse ambiguously defined injection sites.
No-gain cells remain in the grid. Six groups x32 =192 diagnostic cells and up to
192 additional trace passes, retaining at most one group's trace at a time.
These target-informed oracles are upper bounds, not deployable corrections. Their
full trace-generation and replay cost counts in total work. If obtaining the
oracle already costs full recomputation, it cannot demonstrate an economic repair.

## Work, resource and stopping budget

`validation.json` records executable arithmetic. The complete design is **976
answer cells**: 512 mandatory arms +48 fixed repeats +224 new donor cells +192
group oracles. It has 1,952 candidate branches, 976 greedy generations, 16 isolated
B model builds, and up to 192 extra target-trace passes. The optional natural
source plan below is not included in those counts and is not authorized to run.

Under the frozen token caps, the conservative network-token envelope is **446,976
prefill tokens plus 23,424 answer-token equivalents =470,400**. It includes two
<=512-token passes per oracle. Actual answer forward calls are often smaller
because the first candidate token is scored from Q's logits; record actual counts.
These are network-token work counters, **not FLOPs or predicted wall time**.
Any endpoint regeneration, failed/retried call, validation probe or extra trace
adds its actual tokens and CPU time; it must not vanish into setup.

Dense 128x128 transition-on-state application for 18 recurrent layers x16 heads
requires 18*16*128^3 =603,979,776 multiply-accumulates per target reuse arm.
Across 64 targets and four reuse arms that is **154,618,822,656 MACs**, plus
transition construction, projections, conv, attention, repairs, copying and model
forwards. A different algebra/kernel must report its actual dimensions and work,
not inherit this count as measured speed. The dense T/u inventory for all 16 B x4
seams is **2,415,919,104 bytes (2.25 GiB)** before metadata; build/process source B
sequentially and spill to disk rather than holding it all resident. Count cold
source builds separately from warm per-target work and report amortization for
one, two and four uses. A warm-cache saving is not an end-to-end saving.

**The 976-cell grid is a ceiling for accounting, not an automatic launch.** This
directory runs no models. Planned hard caps, not promises about an unmeasured host:

- No GPU, no paid service, no dependency installation or asset download in this
  protocol-preparation task. A later model run needs its own access/asset checks
- One CPU model, one active target, one source segment/trace at a time; do not keep
  all-token recurrent states. Sample peak RSS externally every second, record
  thread count and CPU model; 8 GiB process safety stop, never exceed 9 GB host
  budget. If a lower real memory limit is visible, use it
- The **first cheap model gate is at most 16 cells**: d01/d05 x A1/A2/U1/U2
  x full/exact-prefix, with **30 minutes total including load**, a 15-minute load
  stop, and the RSS guard. Stop immediately if either full-recompute pair is not
  both correct or any of the four unrelated full-recompute controls is incorrect.
  Publish those outcomes as a probe, not an estimate for the full set
- Do not run the other 960 cells automatically. First publish observed cold-load,
  full-prefill, cached-Q and decode/scoring times, memory, competence and parity.
  Resolve/review baseline source semantics before any reuse comparison. Project
  each remaining complete stage using measured median plus max variability, not
  parameter-count speed guesses. Unmeasured source/tuple work needs a bounded
  source-only timing measurement before committing to the rest of that stage
- The complete future design has a **four wall-clock hour ceiling**, including
  load, source builds, parity, scoring, copies, failures and diagnostics. This is
  a cap rather than an instruction to spend four hours. If continuing is justified,
  finish the fixed chunked controls and two repeat rounds without changing the
  declared grid. Reproject after the first fixed w32 cell. Unmeasured donor/oracle
  work is conservatively bounded using full passes plus measured tuple work
- Proceed to the next complete stage only if that stage plus required parity,
  loading/IO, and a 25% time reserve fits the remaining four-hour budget. Do not
  start an expensive stage assuming optional CPU resources will appear. A measured
  overrun/resource stop leaves remaining cells explicitly `not_run_budget`

Stage order: integrity, algebra and source-fidelity review -> 16-cell cheap probe
-> report competence/resources and project -> remaining fixed repeat controls -> all development full ->
all development arms -> held-out full -> held-out arms -> full fixed donor grid ->
full fixed group-oracle grid. No held-out answer is examined to change parameters.
Stop for weak full competence, invalid parity or cache interfaces, resource caps,
only state-norm movement, no qualifying w32 harm, or cheap w16/32 recovery. If
budget prevents a complete critical grid, report it as inconclusive; never call
unrun cases clean. No widening model, context, data or GPU merely because the
literature calls the problem open. A positive screen still needs practical-data
relevance, a non-oracle lower-work remedy and a renewed novelty review before
promotion. No predictions of positive or negative outcomes are made here.

## Reporting contract and deliverables

`result_contract.json` lists required fields. Write one record per predeclared
context/arm/intervention even when unrun, with a reason; all grids must be
accounted for. Preserve source/protocol hashes, raw answers, strict and normalized
scores, correct log probability, candidate margin, paired changes, numerical
parity, endpoint channel errors, timing, peak RSS, actual network tokens, tuple
MAC/byte counters and provenance. Missing data are null with status, never zero.
Do not edit text, split, answer aliases, thresholds, seam sizes or selection after
outcomes. Keep amendments append-only. The freeze hashes are integrity records,
not evidence of external preregistration or of model execution.

`natural_source_plan.md` specifies a separate small ordinary cross-document
source and blind selection plan. **No natural examples have been selected or
run**, and the constructed results cannot be described as natural-task accuracy.
