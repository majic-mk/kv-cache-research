# Separate ordinary cross-document source plan (not materialized)

**Plan only, frozen before constructed checkpoint outcomes.** No dataset assets
were downloaded, no rows selected and no natural-task model result exists. This
plan cannot be cited as evidence of practical relevance.

## Source and license boundary

Use the official HotpotQA development **distractor** file, `hotpot_dev_distractor_v1.json`,
linked by the [official dataset homepage](https://hotpotqa.github.io/) and
[author repository README](https://github.com/hotpotqa/hotpot/blob/master/README.md).
The author README declares the dataset CC BY-SA 4.0; preserve its attribution and
[license link](https://creativecommons.org/licenses/by-sa/4.0/legalcode). Record the
paper citation, original row IDs, Wikipedia titles and source URLs alongside any
excerpts. Keep any redistributed/adapted dataset subset and its attribution under
the applicable share-alike terms; do not mislabel it as newly authored fixtures or
put it under the surrounding code license. The official sources were inspected
2026-10-03 UTC; no mirror or convenience repackaging was used.

## Outcome-blind eight-example selection

Materialization is a separate later step. Download only if independently permitted,
record actual official URL, retrieval date and complete file SHA-256, and freeze
all selected row IDs and literal prompts **before running either constructed or
natural model outcomes** if natural transfer is to be part of the same screen.
Otherwise declare it a later exploratory validation with a fresh freeze.

1. Enumerate official development rows sorted by `_id` in ascending Unicode order
2. Keep `type == bridge`, exactly two distinct annotated supporting titles, and
   answers of 1–3 whitespace-delimited words; exclude yes/no answers
3. Retain the two complete supporting paragraphs in their original `context`
   order: first is A, second is B. Preserve titles and sentence order. Do not
   truncate paragraphs, copy only supporting sentences, paraphrase, invent a
   changed prefix or manufacture a counterfactual gold answer
4. Use the protocol's exact tokenizer/template. Require A<=160, B=128–256,
   Q<=96, prompt<=512 tokens, answer+EOS<=8 tokens, and an annotated B supporting
   sentence with first token >=32. Structural filtering is independent of any
   model's success or cache error
5. Before outputs, a human-readable evidence note must explain why the question
   requires combining these two documents; reject rows answerable from the
   second paragraph alone using the provided text. This manual text-only criterion
   has subjectivity: retain the full accepted/rejected ledger and rationale, and
   do not describe the subset as random or representative
6. Take the first eight eligible, evidence-checked rows. If fewer qualify, report
   the shortfall; do not loosen the caps or replace examples based on outcomes

These are ordinary existing questions with complete supporting text, but selecting
support paragraphs supplies an oracle-retrieval advantage. This is a small QA
mechanism-transfer check, **not the HotpotQA benchmark or a headline score**.
Preserve all eight outcomes. Full-recompute competence must be >=6/8 before cache
quality interpretation. Run the same eight mandatory arms (64 primary answer
cells) with its exact-prefix/chunked/all-seam parity gates; account for this work
separately from the 976-cell constructed ceiling. Do not automatically append the
natural run or its cost to an approved constructed probe.

There is no A1/A2 counterfactual pair here. Do not pool these eight questions with
the artificial pair denominator, use their task errors to establish recurrent
causality, or select only examples showing a constructed-like failure. A natural
negative or uninformative full-recompute result must remain visible.
