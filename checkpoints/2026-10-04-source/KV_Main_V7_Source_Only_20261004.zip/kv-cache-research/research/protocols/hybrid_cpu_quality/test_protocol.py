"""Model-free protocol integrity and scoring tests."""
import copy
import json
import unittest
from pathlib import Path
from build_fixtures import fixtures
from validate_protocol import ARMS, ROOT, contexts, load_fixtures, operation_counts, render, score_answer, validate_structure


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.rows = load_fixtures()
        self.template = json.loads((ROOT / 'template.json').read_text())

    def test_generator_is_exact_frozen_dataset(self):
        self.assertEqual(self.rows, list(fixtures()))

    def test_structure(self):
        self.assertEqual(len(validate_structure(self.rows, self.template)), 16)

    def test_split_and_family_matching_are_explicit(self):
        self.assertEqual([r['family'] for r in self.rows[:8]], [r['family'] for r in self.rows[8:]])
        self.assertEqual({r['split'] for r in self.rows[:8]}, {'development'})
        self.assertEqual({r['split'] for r in self.rows[8:]}, {'held_out'})

    def test_all_four_contexts_share_literal_B_and_Q(self):
        for r in self.rows:
            b, q = [], []
            for c in contexts(r):
                text, (start, end) = render(r, c, self.template)
                b.append(text[start:end]); q.append(text[end:])
            self.assertEqual(len(set(b)), 1)
            self.assertEqual(len(set(q)), 1)

    def test_changed_and_unrelated_answer_controls(self):
        for r in self.rows:
            c = contexts(r)
            self.assertNotEqual(c[0]['expected_answer'], c[1]['expected_answer'])
            self.assertEqual(c[0]['expected_answer'], c[2]['expected_answer'])
            self.assertEqual(c[2]['expected_answer'], c[3]['expected_answer'])

    def test_normalized_scoring_is_narrow(self):
        for answer in ('red', ' RED ', 'red.', 'red!', 'red?'):
            self.assertTrue(score_answer(answer, 'red', eos_within_cap=True))
        for answer in ('red blue', 'the answer is red', 'red...', 'red\nblue', '<think>red', 'blue', ''):
            self.assertFalse(score_answer(answer, 'red', eos_within_cap=True))

    def test_unterminated_answer_is_incorrect(self):
        self.assertFalse(score_answer('red', 'red', eos_within_cap=False))

    def test_B_tampering_is_detected(self):
        data = copy.deepcopy(self.rows); data[0]['B'] += 'extra'
        with self.assertRaises(AssertionError):
            validate_structure(data, self.template)

    def test_answer_tampering_is_detected(self):
        data = copy.deepcopy(self.rows); data[0]['expected_answer_A1'] = 'blue'
        with self.assertRaises(AssertionError):
            validate_structure(data, self.template)

    def test_pair_order_tampering_is_detected(self):
        with self.assertRaises(AssertionError):
            validate_structure(list(reversed(self.rows)), self.template)

    def test_wrong_model_pin_is_detected(self):
        template = dict(self.template, revision='main')
        with self.assertRaises(AssertionError):
            validate_structure(self.rows, template)

    def test_work_arithmetic(self):
        c = operation_counts()
        self.assertEqual(c['primary_cells'], 512)
        self.assertEqual(c['parity_repeat_cells'], 48)
        self.assertEqual(c['additional_donor_cells'], 224)
        self.assertEqual(c['oracle_group_cells'], 192)
        self.assertEqual(c['total_answer_evaluation_cells'], 976)
        self.assertEqual(c['prefill_network_token_upper_bound'], 446976)
        self.assertEqual(c['total_network_token_conservative_upper_bound'], 470400)
        self.assertEqual(c['dense_128x128_transition_state_multiply_MACs_primary'], 154618822656)
        self.assertEqual(c['dense_affine_T_and_u_storage_bytes_16B_4seams'], 2415919104)

    def test_freeze_has_cheap_gate_and_source_block(self):
        p = json.loads((ROOT / 'protocol.json').read_text())
        self.assertEqual(p['first_cheap_probe']['cells_max'], 16)
        self.assertEqual(p['first_cheap_probe']['wall_seconds_max_including_load'], 1800)
        self.assertFalse(p['full_matrix_is_automatic_launch'])
        self.assertEqual(p['arms'], ARMS)
        self.assertEqual(p['model_runs_performed'], 0)
        self.assertTrue(p['author_baseline_fidelity_status'].startswith('blocked_'))
        self.assertEqual(p['token_validation_status'], 'pending_correct_pinned_Qwen3.5_assets')


if __name__ == '__main__':
    unittest.main(verbosity=2)
