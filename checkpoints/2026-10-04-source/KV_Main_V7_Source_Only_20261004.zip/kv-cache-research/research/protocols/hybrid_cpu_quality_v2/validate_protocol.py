"""Offline fixture validation only. Never loads weights, downloads, or installs.

No tokenizer arguments: structural checks, with token checks explicitly pending.
With --tokenizer-dir and --provenance: verify offline pinned tokenizer artifacts,
then freeze full-prompt token slices, candidate IDs, lengths, and identity checks.
The provenance hashes establish identity relative to a recorded source manifest;
they are not signatures or independent proof that the assets came from that URL.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL = 'Qwen/Qwen3.5-0.8B'
REV = '2b48083dfa97c3cbf0220cf1a5e6cffe0a511157'
ARMS = ['full_recompute', 'exact_prefix', 'chunked_16', 'intended_w0',
        'intended_w8', 'intended_w16', 'intended_w32', 'all_seam']


def sha(x):
    return hashlib.sha256(x).hexdigest()


def load_fixtures(root=ROOT):
    return [json.loads(s) for s in (root / 'fixtures.jsonl').read_text().splitlines() if s]


def contexts(row):
    return [dict(variant=v, A=row[v], expected_answer=row['expected_answer_' + v])
            for v in ('A1', 'A2')] + row['unrelated_prefix_controls']


def render(row, ctx, template):
    a = template['prefix_before_A'] + ctx['A'] + template['prefix_after_A']
    q = template['suffix_before_Q'] + row['Q'] + template['suffix_after_Q']
    return a + row['B'] + q, (len(a), len(a) + len(row['B']))


def score_answer(raw, expected, *, eos_within_cap):
    # No extracting an answer from a sentence, substring match, synonyms or judge.
    if not eos_within_cap:
        return False
    text = raw.strip().casefold()
    if re.fullmatch(r'[a-z]+[.!?]?', text):
        return text.rstrip('.!?') == expected
    return False


def validate_structure(rows, template):
    assert len(rows) == 16
    assert [r['pair_id'] for r in rows] == [f'd{x:02d}' for x in range(1, 9)] + [f'h{x:02d}' for x in range(1, 9)]
    assert sum(r['split'] == 'development' for r in rows) == 8
    assert sum(r['split'] == 'held_out' for r in rows) == 8
    assert template['model_id'] == MODEL and template['revision'] == REV
    out = []
    for row in rows:
        assert row['A1'] != row['A2']
        assert len(set(row['answer_candidates'])) == 2
        assert [row['expected_answer_A1'], row['expected_answer_A2']] == row['answer_candidates']
        assert all(re.fullmatch('[a-z]+', x) for x in row['answer_candidates'])
        assert row['B_sha256'] == sha(row['B'].encode())
        start, end = row['important_interior_char_span']
        assert row['B'][start:end] == row['important_interior_text']
        assert len(row['B'][:start].split()) >= 50  # word check, NOT a token count
        assert row['B'].endswith('\n\n')
        cs = contexts(row)
        assert [c['variant'] for c in cs] == ['A1', 'A2', 'U1', 'U2']
        assert cs[2]['expected_answer'] == cs[3]['expected_answer'] == row['expected_answer_A1']
        assert all('<|' not in row[k] for k in ('A1', 'A2', 'B', 'Q'))
        texts = [render(row, c, template)[0] for c in cs]
        assert len(set(texts)) == 4
        out.append({'pair_id': row['pair_id'], 'split': row['split'], 'B_sha256': row['B_sha256'],
                    'B_utf8_bytes': len(row['B'].encode()), 'B_words': len(row['B'].split()),
                    'words_before_important_interior': len(row['B'][:start].split())})
    return out


def check_assets(folder, provenance):
    meta = json.loads(Path(provenance).read_text())
    assert meta['model_id'] == MODEL and meta['revision'] == REV, 'Wrong tokenizer model or immutable revision'
    paths = {}
    for filename in ('tokenizer.json', 'tokenizer_config.json'):
        record = meta['files'][filename]
        expected = f'https://huggingface.co/{MODEL}/resolve/{REV}/{filename}'
        assert record['source_url'] == expected
        path = Path(folder) / filename
        assert sha(path.read_bytes()) == record['sha256'], f'{filename} hash mismatch'
        paths[filename] = path
    return paths, meta


def validate_tokens(rows, template, folder, provenance):
    # Import only if the existing offline package is already installed.
    from tokenizers import Tokenizer
    paths, meta = check_assets(folder, provenance)
    tokenizer = Tokenizer.from_file(str(paths['tokenizer.json']))
    config = json.loads(paths['tokenizer_config.json'].read_text())
    for text, tid in template['required_special_token_ids'].items():
        assert tokenizer.token_to_id(text) == tid, f'Wrong Qwen3.5 special token: {text}'
        assert config['added_tokens_decoder'][str(tid)]['content'] == text
    assert config.get('bos_token') is None and not config.get('add_bos_token', False)
    # Check the official text-only template through its installed renderer when
    # available; string suffix check is necessary, never sufficient by itself.
    from jinja2.sandbox import ImmutableSandboxedEnvironment
    env = ImmutableSandboxedEnvironment(trim_blocks=True, lstrip_blocks=True)
    official = env.from_string(config['chat_template'])
    results = []
    lim = template['limits']
    for row in rows:
        b_ids_by_variant = []
        q_ids_by_variant = []
        a_lengths = []
        for ctx in contexts(row):
            full, (bc0, bc1) = render(row, ctx, template)
            content = full[len('<|im_start|>user\n'):full.index('<|im_end|>')]
            reference = official.render(messages=[{'role': 'user', 'content': content}], add_generation_prompt=True)
            assert reference == full, 'Frozen rendering differs from pinned official template'
            encoded = tokenizer.encode(full, add_special_tokens=False)
            offsets = encoded.offsets
            for cut in (bc0, bc1):
                assert not any(s < cut < e for s, e in offsets), f'Token crosses B boundary: {row["pair_id"]}'
            b_idx = [i for i, (s, e) in enumerate(offsets) if s >= bc0 and e <= bc1 and e > s]
            assert b_idx and b_idx == list(range(b_idx[0], b_idx[-1] + 1))
            b0, b1 = b_idx[0], b_idx[-1] + 1
            assert offsets[b0][0] == bc0 and offsets[b1 - 1][1] == bc1
            aid, bid, qid = encoded.ids[:b0], encoded.ids[b0:b1], encoded.ids[b1:]
            assert lim['B_tokens_min'] <= len(bid) <= lim['B_tokens_max']
            assert len(aid) <= lim['A_tokens_max'] and len(qid) <= lim['Q_tokens_max']
            assert len(encoded.ids) <= lim['total_prompt_tokens_max']
            imp0, imp1 = row['important_interior_char_span']
            important = [i - b0 for i, (s, e) in enumerate(offsets) if e > bc0 + imp0 and s < bc0 + imp1]
            assert important and min(important) >= lim['important_first_token_min_zero_based']
            answer_ids = {}
            for answer in row['answer_candidates']:
                appended = tokenizer.encode(full + answer + '<|im_end|>', add_special_tokens=False).ids
                assert appended[:len(encoded.ids)] == encoded.ids, 'Answer changes prompt tokenization'
                ids = appended[len(encoded.ids):]
                assert ids[-1] == template['required_special_token_ids']['<|im_end|>']
                assert 1 < len(ids) <= template['candidate_total_token_cap_including_eos']
                answer_ids[answer] = ids
            assert len({tuple(v) for v in answer_ids.values()}) == 2
            b_ids_by_variant.append(bid)
            q_ids_by_variant.append(qid)
            a_lengths.append(len(aid))
            results.append({'pair_id': row['pair_id'], 'variant': ctx['variant'], 'split': row['split'],
                            'expected_answer': ctx['expected_answer'], 'input_ids': encoded.ids,
                            'A_ids': aid, 'B_ids': bid, 'Q_ids': qid,
                            'answer_candidate_ids_including_eos': answer_ids,
                            'important_token_span_zero_based_in_B': [min(important), max(important) + 1],
                            'full_prompt_sha256': sha(full.encode())})
        assert all(x == b_ids_by_variant[0] for x in b_ids_by_variant), 'B token identity failed'
        assert all(x == q_ids_by_variant[0] for x in q_ids_by_variant), 'Q token identity failed'
        assert a_lengths[0] == a_lengths[1], 'A1/A2 position confound: revise before outcomes, never drop one case'
        assert a_lengths[2] == a_lengths[3], 'U1/U2 position confound'
    return {'tokenizer_provenance': meta, 'contexts': results}


def operation_counts():
    contexts_n, arms, repeats = 64, 8, 48
    primary = contexts_n * arms
    donors = 32 * 7  # baseline 000 is already present; rerun all-full 111
    oracle = 32 * 6
    cells = primary + repeats + donors + oracle
    # Conservative network-token upper bounds under frozen caps. These are work
    # counters, not FLOPs or timing predictions. Tuple application is extra.
    prefill = {
        'full_exact_chunk_all_seam': 64 * 4 * 512,
        'four_reuse_arms_A_plus_Q_plus_seam': 64 * (4 * (160 + 96) + 0 + 8 + 16 + 32),
        'isolated_B_builds': 16 * 256,
        'parity_repeat_prefills': 48 * 512,
        'donor_fresh_Q': donors * 96,
        'group_oracle_target_trace_and_replay': oracle * 2 * 512,
    }
    return {'first_cheap_probe_cells_max': 16, 'remaining_cells_not_automatically_launched': cells - 16,
            'primary_target_contexts': contexts_n, 'primary_arms': arms,
            'primary_cells': primary, 'parity_repeat_cells': repeats,
            'additional_donor_cells': donors, 'oracle_group_cells': oracle,
            'total_answer_evaluation_cells': cells, 'isolated_B_model_builds': 16,
            'group_oracle_extra_trace_passes': oracle,
            'candidate_teacher_force_branches': cells * 2,
            'greedy_generations': cells, 'prefill_token_upper_bounds': prefill,
            'prefill_network_token_upper_bound': sum(prefill.values()),
            'answer_network_token_conservative_upper_bound': cells * 24,
            'total_network_token_conservative_upper_bound': sum(prefill.values()) + cells * 24,
            'matrix_transition_applications_primary': 64 * 4 * 18,
            'dense_128x128_transition_state_multiply_MACs_primary': 64 * 4 * 18 * 16 * 128**3,
            'dense_affine_T_and_u_storage_bytes_16B_4seams': 16 * 4 * 18 * 16 * (128 * 128 * 2) * 4,
            'warning': 'Upper bounds are planning arithmetic, not measured runtime, implementation FLOPs, evidence of savings, or permission to execute. Log retries, disk I/O, tuple builds and alternate algorithms separately.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tokenizer-dir', type=Path)
    parser.add_argument('--provenance', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'validation.json')
    args = parser.parse_args()
    rows = load_fixtures()
    template = json.loads((ROOT / 'template.json').read_text())
    result = {'evidence_class': 'pre_outcome_protocol_validation_no_models',
              'fixture_jsonl_sha256': sha((ROOT / 'fixtures.jsonl').read_bytes()),
              'template_sha256': sha((ROOT / 'template.json').read_bytes()),
              'structure_status': 'passed', 'fixtures': validate_structure(rows, template),
              'operation_counts': operation_counts()}
    if bool(args.tokenizer_dir) != bool(args.provenance):
        parser.error('Pass both --tokenizer-dir and --provenance, or neither')
    if args.tokenizer_dir:
        result['token_checks'] = validate_tokens(rows, template, args.tokenizer_dir, args.provenance)
        result['token_status'] = 'passed'
    else:
        result['token_status'] = 'pending_correct_pinned_Qwen3.5_tokenizer_assets'
        result['token_checks'] = None
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'structure_status': result['structure_status'], 'token_status': result['token_status'],
                      'pair_groups': len(rows), 'planned_cells': operation_counts()['total_answer_evaluation_cells']}))

if __name__ == '__main__':
    main()
