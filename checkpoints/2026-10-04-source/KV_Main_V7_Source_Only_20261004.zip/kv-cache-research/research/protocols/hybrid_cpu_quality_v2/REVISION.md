# V2 amendment: paired-prefix tokenization before model outcomes

Date: 2026-10-03 UTC. This is an explicit pre-outcome mechanical amendment.
The entire v1 directory and its freeze manifest remain unchanged. This directory
supersedes v1 for future input rendering; it does not retroactively label v1 valid.

## Observed defect and minimal repair

The actual official Qwen3.5-0.8B tokenizer at
`2b48083dfa97c3cbf0220cf1a5e6cffe0a511157` found unequal A1/A2 token lengths in
11 of the 16 v1 pairs. For example, d01 had A1=42 and A2=43 tokens: initial
`Alice` was one token, whereas initial `Bruno` split into `Brun` and `o`;
space-prefixed ` Bruno` was one token. The full paired token lengths and exact
asset provenance are in `revision_diagnostics.json`. No checkpoint weights had
been loaded, no quality output was available, and no model outcome informed the
repair.

The **only prompt-content change** is appending one ASCII space to
`template.json`'s `prefix_before_A`, after its existing `Prefix:\n`. Both the first
and second name now have the same leading-space tokenizer context. The official
chat template still renders the resulting message exactly. No per-case padding,
name replacement, answer replacement, case selection or outcome-based tuning was
used.

`fixtures.jsonl` is byte-identical to v1, including all 16 pair IDs, the 8/8 split,
A1/A2/B/Q strings, gold answers, unrelated-prefix controls and B hashes. Numeric
parity limits, all-seam control, competence/noise thresholds, donor grid, oracle
groups, CPU limits, natural-source plan and 976-cell accounting ceiling are
unchanged. The author-literal HYPIC comparator remains blocked independently of
this tokenizer repair. The first future probe remains at most 16 full/exact cells
and 30 minutes, never an automatic launch of the complete matrix.

## Actual validation

The full validator ran with existing official pinned tokenizer files and the
already installed `/tmp/hybrid_recurrence_cpu_env/bin/python`; this revision task
downloaded nothing, installed nothing and ran no models.

- All 16 pairs /64 contexts pass the official chat-template comparison
- All A1/A2 prefix lengths match, as do every U1/U2 pair
- B and Q token arrays are identical across each pair's four contexts
- B lengths are 155–160 tokens; the important sentence starts at zero-based B
  token 77 in every context, well beyond the first 32 tokens
- A lengths are 42–59 and Q lengths are 30–34; full prompts are 229–248 tokens
- Candidate answers including EOS have 2–3 tokens, with distinct candidate arrays
- The 16-cell initial probe contains 3,736 planned prompt-token positions, at
  most 128 generated-token positions and 72 candidate-token positions including
  EOS. These are input/work-plan counts, not measured model execution or timing

`token_validation.json` retains all exact token arrays and provenance;
`token_extent_summary.json` records their compact extents. `tests.log` records
model-free tests, including a byte comparison with v1, all actual token identities,
and verification that every v1 frozen file still matches its original hash.
The new `freeze_manifest.json` records v2 files and the prior manifest hash.

To repeat full validation, use an existing pinned environment and write to a
**new output path**, not a frozen artifact:

```
PYTHONDONTWRITEBYTECODE=1 /tmp/hybrid_recurrence_cpu_env/bin/python \
  research/protocols/hybrid_cpu_quality_v2/validate_protocol.py \
  --tokenizer-dir outputs/hybrid_cpu_competence/Qwen3.5-0.8B \
  --provenance outputs/hybrid_cpu_competence/asset_provenance.json \
  --output /new/run/path/token_validation.json
```
