#!/usr/bin/env python3
"""Verify and restore both frozen scientific attempt directories. No model execution."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, stat, zipfile
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--archives-dir',type=Path,required=True)
p.add_argument('--project-root',type=Path,required=True)
a=p.parse_args()
m=json.loads((HERE/'RAW_PAYLOAD_MANIFEST.json').read_text())
index=json.loads((HERE/'ARCHIVE_LIBRARY_INDEX.json').read_text())
records={r['filename']:r for r in index['parts']}
def sha_file(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
if not a.project_root.is_dir():raise SystemExit('--project-root must already be a directory')
if a.project_root.is_symlink():raise SystemExit('Refusing symlink project root')
project=a.project_root.resolve()
for attempt in ('original_stage1_attempt_01','original_stage1_attempt_02'):
 target=project/'research/reconstructed/contextual_harm_stage1_20261004'/attempt
 if target.exists():raise SystemExit('Refusing to overwrite an existing attempt directory: '+str(target))
opened={}
try:
 for part in m['parts']:
  name=part['filename'];r=records[name];path=a.archives_dir/name
  if path.stat().st_size!=r['bytes'] or sha_file(path)!=r['sha256']:raise ValueError('Archive size/hash mismatch: '+name)
  z=zipfile.ZipFile(path);opened[part['part']]=z
  if len(z.namelist())!=len(set(z.namelist())):raise ValueError('Duplicate ZIP entry: '+name)
  actual={x for x in z.namelist() if x.startswith('kv-cache-research/')}
  expected={'kv-cache-research/'+r['path'] for r in m['files'] if r['part']==part['part']}
  if actual!=expected:raise ValueError('Wrong payload partition: '+name)
 for r in m['files']:
  q=PurePosixPath(r['path'])
  if q.is_absolute() or '..' in q.parts or '\\' in r['path']:raise ValueError('Unsafe path')
  path=project/Path(*q.parts)
  if not path.resolve().is_relative_to(project):raise ValueError('Path escapes project root')
  z=opened[r['part']];i=z.getinfo('kv-cache-research/'+r['path'])
  if stat.S_ISLNK(i.external_attr>>16):raise ValueError('Symlink entry')
  data=z.read(i)
  if len(data)!=r['bytes'] or hashlib.sha256(data).hexdigest()!=r['sha256']:raise ValueError('Payload mismatch: '+r['path'])
 # Every archive and payload hash has now passed before restoration starts.
 for r in m['files']:
  target=project/Path(*PurePosixPath(r['path']).parts);target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():raise ValueError('Refusing overwrite: '+str(target))
  with target.open('xb') as f:f.write(opened[r['part']].read('kv-cache-research/'+r['path']))
  target.chmod(r['mode'] or 0o644)
 receipt={'status':'all_raw_attempt_files_restored_and_verified','files':len(m['files']),'bytes':sum(r['bytes'] for r in m['files']),'scientific_status':m['scientific_status'],'model_execution':False}
 receipt_path=project/'SCIENTIFIC_RAW_RESTORATION_VERIFIED.json'
 with receipt_path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps(receipt))
finally:
 for z in opened.values():z.close()
