# Restore the complete v7 scientific checkpoint

The main v7 ZIP is a source/report/history checkpoint. It does NOT contain the
1,367,949,798 raw bytes from the two completed original-size scientific attempts.
Those exact bytes are safely preserved in the eight separately saved raw ZIPs
listed below. A complete restoration requires the main ZIP plus all eight.
Every raw file is retained, including the failed first technical attempt.

## Steps

1. Download and extract the main checkpoint into a NEW directory. Do not use an
   existing research working directory.
2. Download all eight raw ZIPs below into a separate folder, preserving names.
3. From the extracted `kv-cache-research` root, run with Python 3:

   python3 research/reconstructed/scientific_checkpoint_20261004/restore_scientific_raw.py --archives-dir /path/to/raw-zips --project-root .

The script uses only the standard library. It verifies all archive and payload
SHA-256 hashes before writing, rejects unsafe paths, and refuses to overwrite
an existing attempt directory. It restores all 2,355 original files with exact
bytes and modes, performs no model/project execution, and writes a verification
receipt. The script was tested against every file in this recovery set.

4. Read `research/reconstructed/contextual_harm_stage1_20261004/FIRST24_RESULTS.md`
   and the independent terminal review under `research/reconstructed/`.
5. For editable Git history, clone `LOCAL_HISTORY.bundle` into another NEW
   checkout, then use the same raw-restoration script there if desired. Raw
   science payloads are referenced externally and are not hidden in the bundle.

## Required raw archives

- [KV_CPU_Science_20261004_Raw_01_of_08.zip](https://chatgpt.com/api/library/files/libfile_2c9157fd07d481919c005a9c0e310456/download): 181,258,631 bytes; SHA-256 `3d41ba33459b9b39e2678b9acd6da5f86d7000cacff7ff736f1b9bee981df264`
- [KV_CPU_Science_20261004_Raw_02_of_08.zip](https://chatgpt.com/api/library/files/libfile_fb74e622076c819199afedfb18767a34/download): 178,649,157 bytes; SHA-256 `9f9b885a6a42dfafdbe35446258f7836334a861a2e2e4fb7bf5c1203297c4240`
- [KV_CPU_Science_20261004_Raw_03_of_08.zip](https://chatgpt.com/api/library/files/libfile_99dacfc83cac819189c8c4e0ac104e67/download): 178,634,689 bytes; SHA-256 `5f6857901e15bd2fc11c0cd3291d14038ad5272d65fb92ad6d4bd5ce1e58b8e4`
- [KV_CPU_Science_20261004_Raw_04_of_08.zip](https://chatgpt.com/api/library/files/libfile_c62aa67a74408191a9f40b20c72524a9/download): 161,376,751 bytes; SHA-256 `8935cc5b3ab52cd3f9e89ecb60c78cf0c6f26bf3e40bca17f85d6bf4557c4f1c`
- [KV_CPU_Science_20261004_Raw_05_of_08.zip](https://chatgpt.com/api/library/files/libfile_5d66563f2e3881918d0edc65d5e7a712/download): 157,385,121 bytes; SHA-256 `3354d7460315aa8aaaede7c83af2ae239837fb09a6825b97d593680500e927e8`
- [KV_CPU_Science_20261004_Raw_06_of_08.zip](https://chatgpt.com/api/library/files/libfile_66736a38b5b08191a64e926c6d56765b/download): 153,552,885 bytes; SHA-256 `13a19c006c6b401f6413ad01fc53289d17ad64fe2a5c04dbe2b73e043786e306`
- [KV_CPU_Science_20261004_Raw_07_of_08.zip](https://chatgpt.com/api/library/files/libfile_63df4554758c819181edc7f70c7cedbb/download): 178,786,995 bytes; SHA-256 `482279d5751dd56950110dd5c2516be467086f60ded16234bd3e0821349771b0`
- [KV_CPU_Science_20261004_Raw_08_of_08.zip](https://chatgpt.com/api/library/files/libfile_7add2aee70ac8191af0cfa7fae26e787/download): 88,664,480 bytes; SHA-256 `1f8c599401274fa6928c82799e0a210baabc7eccd213d68cb3020e546633932a`

## Integrity indexes

- `RAW_PAYLOAD_MANIFEST.json`: every original scientific attempt path, size,
  SHA-256, mode, and required archive number
- `ARCHIVE_LIBRARY_INDEX.json`: exact private Library IDs, stable download
  links, archive sizes and SHA-256 hashes
- Main root `CHECKPOINT_MANIFEST.json`: all files actually included in the main
  ZIP; it does not pretend external raw files are inside that ZIP
- `verified_asset_receipts/`: verified official source/projection/disk identity
  receipts for the successful weight restoration, without weight payloads

An additional emergency provenance archive is saved separately and listed in
`ARCHIVE_LIBRARY_INDEX.json`. It is a supplemental point-in-time source/release/
runtime backup, not a substitute for any raw part. Its early documents precede
the final report. The main v7 report and receipts supersede those status texts.

Pretrained weights, runtime environments, wheels and downloads are deliberately
not included. Recreating an execution environment or reacquiring model weights
is a separate action. Pins and official-source identity receipts are provided;
this archive and script authorize no additional experiment, GPU or paid work.

## Scientific decision

The completed second attempt is `STOP_NO_QUALIFYING_HARM`: all 24 answers were
correct, all required numerical controls and the resource guard passed, but the
frozen two-group confidence-harm gate was not met. The d05/A2 gold-score loss was
below 0.1 nat despite its large margin loss. Do not select only d01, switch to
margin-only criteria, relax thresholds, or advance the conditional repair branch.
The first attempt's pre-forward metadata-serialization failure is retained.
