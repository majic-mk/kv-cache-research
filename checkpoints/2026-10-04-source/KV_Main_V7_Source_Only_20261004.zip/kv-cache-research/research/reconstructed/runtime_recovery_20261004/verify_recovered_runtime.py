"""Import/source-only runtime audit: no weights, models, or model forwards."""
from __future__ import annotations

import datetime
import hashlib
import importlib.metadata as metadata
import json
import pathlib
import platform
import re
import shutil
import sys
import tarfile

import numpy
import torch
import transformers
from transformers import cache_utils
from transformers.models.qwen3_5 import configuration_qwen3_5, modeling_qwen3_5

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[2]
OLD = REPO / "research/diagnostics/hybrid_recurrence_cpu"
PIN = "02d8fb9784e8f14a1251e4c992cd82a5762417c6"
EXPECTED_ARCHIVE = "e61a3b05ba4fc95ad588147bcc04723f8ee25687b33141fcd89b255ef0e2c1ad"


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def main() -> None:
    assert pathlib.Path(sys.prefix) == HERE / ".venv", sys.prefix
    assert torch.__version__ == "2.9.1+cpu"
    assert torch.version.cuda is None
    assert numpy.__version__ == "2.2.6"
    assert transformers.__version__ == "5.19.0.dev0"
    assert shutil.disk_usage(HERE).free >= 5_000_000_000

    installed = {normalized(d.metadata["Name"]): d.version for d in metadata.distributions()}
    expected = {}
    for line in (OLD / "requirements.freeze.txt").read_text().splitlines():
        if "==" in line:
            name, version = line.split("==", 1)
            expected[normalized(name)] = version
    mismatches = {
        name: {"expected": version, "actual": installed.get(name)}
        for name, version in expected.items()
        if installed.get(name) != version
    }
    assert not mismatches, mismatches
    forbidden = [n for n in installed if n.startswith("nvidia-") or n == "triton"]
    assert not forbidden, forbidden

    archive = HERE / "downloads" / f"transformers-{PIN}.tar.gz"
    assert sha256(archive) == EXPECTED_ARCHIVE
    checked = []
    for module, name in [
        (modeling_qwen3_5, "modeling_qwen3_5.py"),
        (configuration_qwen3_5, "configuration_qwen3_5.py"),
        (cache_utils, "cache_utils.py"),
    ]:
        actual = pathlib.Path(module.__file__)
        preserved = OLD / "sources" / name
        assert actual.read_bytes() == preserved.read_bytes(), name
        checked.append({"file": name, "sha256": sha256(actual), "matches_recovered_source": True})

    # Compare all package files that are present in both the official source
    # archive and installed package. Packaging exclusions are recorded, not
    # silently treated as byte equality of the entire old runtime.
    package_root = pathlib.Path(transformers.__file__).parent
    package_files = []
    excluded_source_files = []
    prefix = f"transformers-{PIN}/src/transformers/"
    with tarfile.open(archive) as source:
        for member in source.getmembers():
            if not member.isfile() or not member.name.startswith(prefix):
                continue
            rel = member.name.removeprefix(prefix)
            path = package_root / rel
            if not path.is_file():
                excluded_source_files.append(rel)
                continue
            expected_bytes = source.extractfile(member).read()
            actual_bytes = path.read_bytes()
            assert actual_bytes == expected_bytes, f"Installed Transformers source mismatch: {rel}"
            package_files.append({"path": rel, "sha256": hashlib.sha256(actual_bytes).hexdigest()})

    old_inputs = [
        "requirements.freeze.txt", "reproduce.sh", "verify_environment.py",
        "provenance.json", "logs/environment_verification.json",
        "logs/install_torch.log", "logs/install_transformers.log",
    ]
    result = {
        "status": "passed",
        "audit_scope": "dependency versions and import/source identity only",
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "python_executable": sys.executable,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "torch_cuda_build": torch.version.cuda,
        "numpy": numpy.__version__,
        "transformers": transformers.__version__,
        "transformers_commit": PIN,
        "transformers_archive_sha256": EXPECTED_ARCHIVE,
        "frozen_versions_checked": len(expected),
        "frozen_version_mismatches": mismatches,
        "packages_absent_from_historical_freeze": {
            n: v for n, v in installed.items() if n not in expected and n != "transformers"
        },
        "installed_versions": dict(sorted(installed.items())),
        "critical_source_checks": checked,
        "source_archive_package_files_matched": len(package_files),
        "source_archive_files_not_in_installed_package": excluded_source_files,
        "source_archive_package_file_hashes": package_files,
        "recovered_inputs_sha256": {p: sha256(OLD / p) for p in old_inputs},
        "free_disk_bytes": shutil.disk_usage(HERE).free,
        "minimum_disk_reserve_bytes": 5_000_000_000,
        "old_whole_runtime_byte_identity_established": False,
        "no_pretrained_weights_downloaded_or_loaded_by_this_recovery": True,
        "no_model_forward_by_this_recovery": True,
        "no_gpu_execution_by_this_recovery": True,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
