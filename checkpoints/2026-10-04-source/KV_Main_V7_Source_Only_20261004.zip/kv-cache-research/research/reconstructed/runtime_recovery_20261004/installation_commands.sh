#!/usr/bin/env bash
# Record of installation commands used on 2026-10-04, from repository root.
# This file deliberately refuses execution: a fresh install destination must
# be chosen explicitly and old runtime/log files must not be overwritten.
echo 'This is an audit record, not an executable setup script.' >&2
exit 2

# Before these commands, the official codeload archive was fetched and verified
# with the expected SHA-256. The exact URL, bytes, hash and time are in
# logs/transformers_download.json. The archive remains in downloads/.
# requirements.dependencies.txt is the historical freeze without torch and
# the independently hash-verified Transformers archive.
R=research/reconstructed/runtime_recovery_20261004
python -m venv "$R/.venv"
mkdir -p "$R/tmp"
export TMPDIR="$PWD/$R/tmp" PIP_CONFIG_FILE=/dev/null
export PIP_DISABLE_PIP_VERSION_CHECK=1
"$R/.venv/bin/python" -m pip install --no-cache-dir --retries 0 --timeout 45 \
  --no-deps --index-url https://download.pytorch.org/whl/cpu \
  'torch==2.9.1+cpu' --report "$R/logs/install_torch.report.json"
"$R/.venv/bin/python" -m pip install --no-cache-dir --retries 0 --timeout 45 \
  --only-binary=:all: --index-url https://pypi.org/simple \
  -r "$R/requirements.dependencies.txt" \
  --report "$R/logs/install_dependencies.report.json"
"$R/.venv/bin/python" -m pip install --no-cache-dir --no-index \
  --no-build-isolation --no-deps \
  "$R/downloads/transformers-02d8fb9784e8f14a1251e4c992cd82a5762417c6.tar.gz" \
  --report "$R/logs/install_transformers.report.json"
bash "$R/cpu_python.sh" research/diagnostics/hybrid_recurrence_cpu/verify_environment.py
bash "$R/cpu_python.sh" "$R/verify_recovered_runtime.py"
bash "$R/cpu_python.sh" -m pip check
bash "$R/cpu_python.sh" -m pip freeze --all
