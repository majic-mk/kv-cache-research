# CPU runtime reconstruction, 2026-10-04

**Ready for separately authorized CPU work.** This is environment recovery, not
a new model experiment or a rerun of stopped research cells.

## Verified result

- Python 3.12.14; Torch **2.9.1+cpu**, CUDA build `None`; NumPy **2.2.6**
- Transformers **5.19.0.dev0**, official commit
  `02d8fb9784e8f14a1251e4c992cd82a5762417c6`
- The official source archive SHA-256 matches the preserved value:
  `e61a3b05ba4fc95ad588147bcc04723f8ee25687b33141fcd89b255ef0e2c1ad`
- All **33 version-pinned packages** from the historical freeze match. The
  separately pinned Transformers source matches as above. Pip 25.0.1 was seeded
  by Python's bundled `ensurepip`; the historical freeze did not pin pip
- The unchanged historical `verify_environment.py` passes. Installed
  `modeling_qwen3_5.py`, `configuration_qwen3_5.py`, and `cache_utils.py` match
  recovered source bytes and their preserved hashes
- All **3,048 package files present in both the source archive and installed
  Transformers package** match byte-for-byte. Two non-package source files are
  excluded by packaging: `models/gpt2/CONVERSION.md` and
  `models/t5/download_from_gcp.sh`
- `pip check` passes. No CUDA/NVIDIA runtime package or Triton was installed
- 30,414,725,120 bytes of workspace disk were free at verification, above the
  5,000,000,000-byte reserve

No pretrained weights were downloaded or loaded, no model instance was created,
and no model forward or GPU action was performed by this recovery. Importing
Torch and the pinned model/cache modules was part of source verification. No old
freeze, source, or historical research outcome was edited.

## Run in the recovered environment

From the repository root:

```sh
bash research/reconstructed/runtime_recovery_20261004/cpu_python.sh YOUR_SCRIPT.py
```

The wrapper selects the isolated workspace `.venv`, CPU visibility, offline
Hugging Face mode, disabled telemetry, and single-thread BLAS/OpenMP defaults.
These defaults are a convenience, not a security sandbox or authority for a
new experiment. Keep the relevant scientific execution gate in force.

To repeat only the import/source verification:

```sh
bash research/reconstructed/runtime_recovery_20261004/cpu_python.sh \
  research/diagnostics/hybrid_recurrence_cpu/verify_environment.py
bash research/reconstructed/runtime_recovery_20261004/cpu_python.sh \
  research/reconstructed/runtime_recovery_20261004/verify_recovered_runtime.py
```

The detailed verifier needs the verified source archive in `downloads/`, which
is intentionally excluded from Git along with `.venv/` and temporary build data.

## Evidence and reproducibility

- `logs/environment_verification.json`: unchanged historical verifier output
- `logs/recovery_verification.json`: actual versions, recovered-input hashes,
  source comparisons, platform, and disk reserve
- `logs/install_*.log` and `logs/install_*.report.json`: fresh installation
  activity with exact official URLs and download hashes
- `provenance.json`: consolidated sources and explicit identity limitations
- `requirements.actual.freeze.txt`: complete installed freeze, including pip
- `requirements.dependencies.txt`: untouched historical pins filtered to omit
  the independently installed CPU Torch and source-built Transformers
- `requirements.cpython312-linux_x86_64.lock`: exact 33 wheel URLs and SHA-256
  hashes observed during this reconstruction
- `installation_commands.sh`: documentation of the commands actually used

Downloads came only from the official PyTorch wheel service, PyPI's official
file service, and Hugging Face's official GitHub source archive. Dependencies
were pinned to the recovered freeze rather than resolved to newer versions.
Transformers was built locally with the pinned setuptools and
`--no-index --no-build-isolation --no-deps`, after archive hash verification.

### Identity limit

This is a verified reconstruction, **not proven byte identity of the former
runtime**. Its Transformers wheel hash is
`c1bf54a04b5adaf8c3c4f2a83e06fd92d8c79072d26b484323deca7407b04018`,
whereas the old build log records
`492b53fb0f2322ae2400dc9f9fa13c0a339724ee850641acf1f4117b3b822c22`.
The old wheel and venv are unavailable for complete binary comparison. Wheel
metadata, build paths, timestamps, compiled caches, installer identity, and
whole-dependency binary equality to the old environment have not been proven.
The source archive, audited source bytes, version pins, and fresh download
hashes are the verified claims.
