# Focused original first24 source review

Date: 2026-10-04 UTC. Decision: **conditional admission after three concrete guard fixes and the outstanding verified-asset/execution release**. The tight analytical memory margin is bounded empirical uncertainty, not an additional reason to require another numerical qualification campaign.

Reviewed reconstruction manifest: `e78aca974fa56c08c09cc264b2902cbbfef0cdd177c9ccde65919ecd71ec5d09`. All 732 listed file sizes/hashes matched. Thirty-five focused stdlib tests passed independently: canonical source contracts, original admission, and actual native-capture identity hooks with model-free owners. This review used static source and saved evidence; it did not construct/load/forward a model or run a native test.

## Scientific/native wiring is coherent

The earlier source-ancestry defect is closed. Complete cells are compared with a detached canonical plan; later edits are rejected. Capture obtains its identity from the actual active B call and successful tracked B result, and requires the frozen group R/A1 IDs, call, and producer. Every Hctx build checks that source ancestor and the current target A before target forwards. Its actual fresh-seam parent and complete derived cache are separately registered. These checks preserve contextual A1 source reuse under A2/U targets rather than permitting a self-consistent wrong source.

The first24 coordinator now enforces fixed order and uses the verified tokenizer, all-root raw-logit sink, immediate cache/logit endpoint observer, candidate/EOS scoring, and sequential competence/exact-control/harm decisions. References are taken from the correct R variant or F32/A1 cell. R references are consumed immediately by F32; the two F32/A1 banks are kept for the later self-reuse controls. A failed cell stops later execution and retains explicit unrun identities. No later donor/repair/holdout work is released.

The meta constructor → exact local safetensors assignment → official retie route is consistent with the pinned source. Before accepting it, the loader checks file-backed payload extents and unchanged assigned pointers, exact key coverage, original dtypes, tied head identity, and absence of residual meta buffers. The helper restores only the small source-F32 parameters and official CPU RoPE. The added scalar RoPE preflight/integrity check closes the earlier scaling gap. This is a coherent prepared loader, not an observation that original loading succeeds.

## Three guard corrections are required

1. **Enforce the existing host ceiling.** `guard_original_stage1_reconstructed.py` never samples host memory. Comparing the process estimate with 9GB in `original_admission_reconstructed.py:209` does not enforce the preserved host unavailable-memory ceiling. The recovered v3 README/watchdog contract defines that as MemTotal minus MemAvailable. Sample it, stop on the existing 9,000,000,000-byte bound, and retain it in the receipt alongside process-tree HWM. This restores an existing requirement.

2. **Do not bypass terminal limits.** The successful `wait4` branch at guard lines 72–74 breaks before the loop's wall/disk/retained/log checks. Finalization currently rechecks only RSS and source pins. A process crossing another limit in its last sampling interval can therefore receive a guard PASS. Recheck applicable terminal limits before assigning status, including space/retained bytes reserved for the final receipt.

3. **Keep ownership until descendants are stopped.** At guard lines 109–110 the owned process group is killed only when the leader has not been reaped. If termination reaps the leader first, a surviving descendant is merely flagged at lines 114–117. Stop and verify the owned group/identified descendants even after leader termination; do not return while an owned original process remains running.

Focused model-free terminal/descendant/host-limit tests can close these defects. They do not require another tiny or original model run.

## Accounting and admission limits

Mapped evidence preserves logical tensor values/metadata, verifies file bytes before mapping, and explicitly discards inactive private pages. Source integrity is checked before eviction; mapped references are comparison inputs rather than native mutable branch caches. The accounting includes the 21 additional F32/A1 endpoint artifacts, both source-A caches, all possible root logits, source traces/suffixes, hash reads, mapping/eviction and serialization time, and extra continuation clones. Physical page-fault I/O remains explicitly unmeasured, so no serving-cost or speedup claim follows.

The reported 8,496,386,400-byte execution estimate includes 1,744,830,464 bytes of explicit reserves and leaves 93,548,192 bytes below 8GiB. The 4,988,402,496-byte loader estimate and 1,971,304,448-byte new evidence envelope reconcile with the declared route. Actual allocator retention, workspace, page residency, loader behavior, and peak RSS remain empirical. A resource stop is a valid terminal outcome under unchanged limits; analytical fit is not a guarantee. Eager attention/mask instrumentation still supports this short CPU experiment, not economical long-context deployment.

After the three fixes, bind refreshed source identities and the prospective resource/evidence envelope to one authorized first24 attempt when exact weights become available. The HTTP-403 recovery block remains; a preallocated partial file is not a checkpoint. Preserve all earlier failures and the third tiny child's incomplete external guard qualification. No extra generic gate, tolerance relaxation, cap increase, or historical-result relabeling is needed.
