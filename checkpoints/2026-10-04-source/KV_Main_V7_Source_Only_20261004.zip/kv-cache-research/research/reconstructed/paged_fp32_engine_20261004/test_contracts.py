"""Only stdlib tests. No Torch import, construction, allocations, or forwards."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
from contracts import (ExclusiveLedger, PatchStack, cast_elements, read_source_manifest,
                       sha256_file, EXPECTED_ARENA_BYTES, rope_scaling_signature)


class LeaseTests(unittest.TestCase):
    def test_one_largest_head_arena(self):
        self.assertEqual(248320 * 2048 * 4, EXPECTED_ARENA_BYTES)
        self.assertEqual(cast_elements([('BF16', 9), ('F32', 5), ('BF16', 2)]), 11)

    def test_exclusive_reuse_without_accumulation(self):
        ledger = ExclusiveLedger(12)
        with ledger.lease(12, 'head'):
            self.assertTrue(ledger.busy)
            self.assertEqual(ledger.current_cast_bytes, 48)
        with ledger.lease(3, 'conv'):
            self.assertEqual(ledger.current_cast_bytes, 12)
        self.assertFalse(ledger.busy)
        self.assertEqual(ledger.max_live_cast_bytes, 48)
        self.assertEqual(ledger.current_cast_bytes, 0)

    def test_nested_lease_rejected_parent_preserved(self):
        ledger = ExclusiveLedger(12)
        with ledger.lease(12, 'parent'):
            with self.assertRaises(RuntimeError):
                with ledger.lease(1, 'nested'):
                    self.fail('Nested lease was admitted')
            self.assertEqual(ledger.current_cast_bytes, 48)
        self.assertFalse(ledger.busy)

    def test_exception_cleanup(self):
        ledger = ExclusiveLedger(12)
        with self.assertRaisesRegex(RuntimeError, 'leaf failed'):
            with ledger.lease(3, 'conv'):
                raise RuntimeError('leaf failed')
        self.assertFalse(ledger.busy)
        with ledger.lease(12, 'linear after conv'):
            pass
        self.assertEqual([r['event'] for r in ledger.events], ['acquire', 'release'] * 2)

    def test_invalid_size(self):
        ledger = ExclusiveLedger(12)
        for value in (-1, 13, True, 1.5):
            with self.assertRaises(ValueError):
                with ledger.lease(value, 'bad'):
                    pass
        self.assertEqual(ledger.lease_count, 0)

    def test_streaming_and_bounded_history(self):
        streamed = []
        ledger = ExclusiveLedger(12, sink=streamed.append, history_limit=2)
        for _ in range(4):
            with ledger.lease(1, 'leaf'):
                pass
        self.assertEqual(len(streamed), 8)
        self.assertEqual(len(ledger.events), 2)
        self.assertEqual(ledger.lease_count, 4)

    def test_sink_exception_cleanup(self):
        def sink(row):
            if row['event'] == 'acquire':
                raise OSError('stream failed')
        ledger = ExclusiveLedger(12, sink=sink)
        with self.assertRaises(OSError):
            with ledger.lease(1, 'leaf'):
                pass
        self.assertFalse(ledger.busy)
        self.assertEqual(ledger.current_cast_bytes, 0)

    def test_acquire_budget_error_survives_poisoned_release_sink(self):
        class BudgetExceeded(RuntimeError): pass
        class JournalPoisoned(RuntimeError): pass
        original = BudgetExceeded('cost journal cap exceeded')
        def sink(row):
            if row['event'] == 'acquire':
                raise original
            raise JournalPoisoned('journal already poisoned')
        ledger = ExclusiveLedger(12, sink=sink)
        with self.assertRaises(BudgetExceeded) as caught:
            with ledger.lease(1, 'capped leaf'):
                self.fail('Acquire error did not stop the body')
        self.assertIs(caught.exception, original)
        self.assertFalse(ledger.busy)
        self.assertEqual(ledger.current_cast_bytes, 0)
        self.assertEqual(ledger.secondary_errors[-1]['error_type'], 'JournalPoisoned')
        self.assertEqual(ledger.secondary_errors[-1]['primary_error_type'], 'BudgetExceeded')
        ledger.sink = None
        with ledger.lease(12, 'proves lock was released'):
            pass

    def test_body_error_survives_release_sink_error(self):
        original = ValueError('actual leaf failure')
        def sink(row):
            if row['event'] == 'release':
                raise OSError('release evidence failed')
        ledger = ExclusiveLedger(12, sink=sink)
        with self.assertRaises(ValueError) as caught:
            with ledger.lease(3, 'leaf'):
                raise original
        self.assertIs(caught.exception, original)
        self.assertEqual(ledger.secondary_errors[-1]['error_type'], 'OSError')
        self.assertFalse(ledger.busy)
        self.assertEqual(ledger.current_cast_bytes, 0)

    def test_release_only_sink_error_is_not_silenced(self):
        original = OSError('release-only failure')
        def sink(row):
            if row['event'] == 'release':
                raise original
        ledger = ExclusiveLedger(12, sink=sink)
        with self.assertRaises(OSError) as caught:
            with ledger.lease(3, 'successful leaf'):
                pass
        self.assertIs(caught.exception, original)
        self.assertFalse(ledger.busy)
        self.assertEqual(ledger.current_cast_bytes, 0)
        self.assertEqual(len(ledger.secondary_errors), 0)

    def test_secondary_error_evidence_is_bounded_without_tracebacks(self):
        def sink(row):
            if row['event'] == 'release':
                raise OSError('x' * 2000)
        for history_limit in (0, 2):
            ledger = ExclusiveLedger(12, sink=sink, history_limit=history_limit)
            for _ in range(3):
                with self.assertRaises(ValueError):
                    with ledger.lease(1, 'leaf'):
                        raise ValueError('primary')
            self.assertEqual(len(ledger.secondary_errors), max(1, history_limit))
            self.assertEqual(ledger.secondary_errors[-1]['lease_id'], 3)
            self.assertEqual(len(ledger.secondary_errors[-1]['message']), 512)
            json.dumps(list(ledger.secondary_errors))

    def test_patches_restore_class_method_ownership(self):
        class Example:
            def forward(self): return 'class method'
        obj = Example()
        stack = PatchStack()
        stack.set(obj, 'forward', lambda: 'patched')
        stack.set(obj, 'new_attr', 9)
        self.assertEqual(obj.forward(), 'patched')
        stack.restore()
        self.assertNotIn('forward', vars(obj))
        self.assertNotIn('new_attr', vars(obj))
        self.assertEqual(obj.forward(), 'class method')
        stack.restore()

    def test_patches_restore_owned_attribute(self):
        class Example: pass
        obj = Example()
        marker = obj.forward = object()
        stack = PatchStack()
        stack.set(obj, 'forward', 3)
        stack.set(obj, 'forward', 5)
        stack.restore()
        self.assertIs(obj.forward, marker)

    def test_reject_unknown_dtypes(self):
        for spec in [('F16', 3), ('F32', -1), ('BF16', True)]:
            with self.assertRaises(ValueError):
                cast_elements([spec])


class RoPEScalarTests(unittest.TestCase):
    def test_exact_scalar_signature_rejects_invalid_or_nonfinite_state(self):
        self.assertEqual(rope_scaling_signature(1.0), ('float', '0x1.0000000000000p+0'))
        self.assertNotEqual(rope_scaling_signature(1.0), rope_scaling_signature(1.0000000000000002))
        for value in (True, None, '1.0', float('nan'), float('inf'), float('-inf'), object()):
            with self.assertRaises(ValueError):
                rope_scaling_signature(value)

    @staticmethod
    def make_engine():
        from types import SimpleNamespace
        from paged_fp32_engine import PagedArenaEngine
        # Plain Python fakes; no Torch import, tensor or model construction.
        expected_buffer = object()
        rotary = SimpleNamespace(rope_type='default', attention_scaling=1.0,
                                 inv_freq=expected_buffer, original_inv_freq=expected_buffer,
                                 config=object(), compute_default_rope_parameters=lambda _: (expected_buffer, 1.0))
        model = SimpleNamespace(model=SimpleNamespace(rotary_emb=rotary),
            named_parameters=lambda **_: [], named_buffers=lambda **_: [], named_modules=lambda: [])
        engine = PagedArenaEngine(model, None, SimpleNamespace(equal=lambda a,b:a is b), synthetic=True)
        engine._fp32 = lambda *_: None  # Scalar regression does not test tensor dtype checks.
        return engine, rotary

    def test_source_check_compares_official_returned_scaling(self):
        engine, rotary = self.make_engine()
        engine._check_rope_source(rotary)
        rotary.attention_scaling = 1.0000000000000002
        with self.assertRaisesRegex(ValueError, 'attention_scaling changed'):
            engine._check_rope_source(rotary)
        # The expected initializer result is used, rather than a hardcoded unit.
        rotary.attention_scaling = 2.0
        buffer = rotary.inv_freq
        rotary.compute_default_rope_parameters = lambda _: (buffer, 2.0)
        engine._check_rope_source(rotary)

    def test_scalar_drift_changes_snapshot_and_deep_hashes(self):
        engine, rotary = self.make_engine()
        engine._before, engine._before_hashes = engine._snapshot(), engine._hashes()
        engine.verify_integrity(deep=True)
        rotary.attention_scaling = 1.125
        self.assertNotEqual(engine._snapshot(), engine._before)
        self.assertNotEqual(engine._hashes(), engine._before_hashes)
        with self.assertRaisesRegex(RuntimeError, 'RoPE scaling changed'):
            engine.verify_integrity()
        with self.assertRaisesRegex(RuntimeError, 'RoPE scaling changed'):
            engine.verify_integrity(deep=True)
        rotary.attention_scaling = 1.0
        engine.verify_integrity(deep=True)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'synthetic.safetensors'

    def tearDown(self): self.tmp.cleanup()

    def write(self, header=None, payload=None):
        if header is None:
            header = {'model.language_model.embed_tokens.weight': {'dtype': 'BF16', 'shape': [2, 2], 'data_offsets': [0, 8]},
                      'model.language_model.layers.0.linear_attn.A_log': {'dtype': 'F32', 'shape': [2], 'data_offsets': [8, 16]}}
        raw = header if isinstance(header, bytes) else json.dumps(header).encode()
        if payload is None:
            # Non-roundtrippable F32 values; the parser must preserve literal bits.
            payload = bytes.fromhex('003f80bf01007f3f') + struct.pack('<ff', 1.0001, -0.00013)
        self.path.write_bytes(struct.pack('<Q', len(raw)) + raw + payload)
        return raw, payload

    def test_mixed_storage_exact_extents(self):
        raw, payload = self.write()
        records = read_source_manifest(self.path, require_2b=False)
        self.assertEqual([r.dtype for r in records], ['BF16', 'F32'])
        self.assertEqual(records[0].model_name, 'model.embed_tokens.weight')
        self.assertEqual(records[1].offset, 8 + len(raw) + 8)
        import hashlib
        self.assertEqual(sha256_file(self.path, records[1].offset, 8), hashlib.sha256(payload[8:]).hexdigest())

    def test_production_identity_rejects_synthetic_file(self):
        self.write()
        with self.assertRaises(ValueError): read_source_manifest(self.path)

    def test_duplicate_json_key_rejected(self):
        self.write(b'{"x":1,"x":2}')
        with self.assertRaises(ValueError): read_source_manifest(self.path, require_2b=False)

    def test_overlap_rejected(self):
        self.write({'model.language_model.a': {'dtype': 'BF16', 'shape': [4], 'data_offsets': [0, 8]},
                    'model.language_model.b': {'dtype': 'F32', 'shape': [2], 'data_offsets': [0, 8]}})
        with self.assertRaises(ValueError): read_source_manifest(self.path, require_2b=False)

    def test_nontext_key_rejected(self):
        self.write({'model.visual.a': {'dtype': 'F32', 'shape': [4], 'data_offsets': [0, 16]}})
        with self.assertRaises(ValueError): read_source_manifest(self.path, require_2b=False)

    def test_truncation_rejected(self):
        self.write()
        self.path.write_bytes(self.path.read_bytes()[:-1])
        with self.assertRaises(ValueError): read_source_manifest(self.path, require_2b=False)

    def test_hash_truncated_range_rejected(self):
        self.write()
        with self.assertRaises(ValueError): sha256_file(self.path, length=10000)

    def test_size_shape_mismatch_rejected(self):
        self.write({'model.language_model.a': {'dtype': 'BF16', 'shape': [4], 'data_offsets': [0, 16]}})
        with self.assertRaises(ValueError): read_source_manifest(self.path, require_2b=False)


if __name__ == '__main__':
    unittest.main(verbosity=2)
