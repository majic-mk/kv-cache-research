"""Reconstructed 2026-10-04. Pure-stdlib storage and exclusive-lease contracts.

These tests establish bookkeeping, not Torch numerical correctness. The lost
historical engine is NOT recovered by this module.
"""
from collections import Counter, deque
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import struct
import threading
import time

DERIVED_SHA256 = '42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c'
DERIVED_BYTES = 3_763_696_896
MODEL_REVISION = '15852e8c16360a2fea060d615a32b45270f8a8fc'
TRANSFORMERS_REVISION = '02d8fb9784e8f14a1251e4c992cd82a5762417c6'
MODELING_SHA256 = 'f3fecce29dee6cea1ac951c947a538fdcf01abfc21f8f0e33a78b535fe6837c3'
EXPECTED_ARENA_BYTES = 2_034_237_440
DTYPE_BYTES = {'BF16': 2, 'F32': 4}


def sha256_file(path, start=0, length=None, chunk_bytes=4 * 1024**2):
    if start < 0 or (length is not None and length < 0) or chunk_bytes <= 0:
        raise ValueError('Invalid bounded read')
    result = hashlib.sha256()
    with Path(path).open('rb') as source:
        source.seek(start)
        remaining = length
        while remaining is None or remaining:
            block = source.read(chunk_bytes if remaining is None else min(chunk_bytes, remaining))
            if not block:
                if remaining:
                    raise ValueError('Truncated input')
                break
            result.update(block)
            if remaining is not None:
                remaining -= len(block)
    return result.hexdigest()


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


@dataclass(frozen=True)
class TensorRecord:
    source_name: str
    model_name: str
    dtype: str
    shape: tuple
    offset: int
    nbytes: int

    @property
    def numel(self):
        return math.prod(self.shape)


def read_source_manifest(path, *, require_2b=True):
    """Read metadata and verify the lossless derivative's whole-file identity.

    No mmap, Torch import, tensor materialization, network or model construction.
    The official text mapping removes exactly the model.language_model prefix.
    """
    path = Path(path)
    size = path.stat().st_size
    with path.open('rb') as source:
        prefix = source.read(8)
        if len(prefix) != 8:
            raise ValueError('Truncated safetensors length')
        length = struct.unpack('<Q', prefix)[0]
        if not 2 <= length <= min(16 * 1024**2, size - 8):
            raise ValueError('Invalid or oversized safetensors header')
        header = json.loads(source.read(length), object_pairs_hook=_unique)
    if not isinstance(header, dict):
        raise ValueError('Safetensors header must be an object')
    records = []
    for name, item in header.items():
        if name == '__metadata__':
            if not isinstance(item, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in item.items()):
                raise ValueError('Invalid metadata')
            continue
        if not isinstance(item, dict) or set(item) != {'dtype', 'shape', 'data_offsets'}:
            raise ValueError('Unexpected tensor fields')
        dtype, shape, offsets = item['dtype'], item['shape'], item['data_offsets']
        if dtype not in DTYPE_BYTES:
            raise ValueError('Only source BF16/F32 is admitted')
        if not isinstance(shape, list) or any(type(x) is not int or x < 0 for x in shape):
            raise ValueError('Invalid tensor shape')
        if not isinstance(offsets, list) or len(offsets) != 2 or any(type(x) is not int for x in offsets):
            raise ValueError('Invalid offsets')
        begin, end = offsets
        if begin < 0 or end - begin != math.prod(shape) * DTYPE_BYTES[dtype]:
            raise ValueError('Invalid tensor extent')
        # Official Qwen3.5 text-only checkpoint conversion, restricted to text.
        prefix = 'model.language_model.'
        if not name.startswith(prefix):
            raise ValueError('Non-text or unexpected source key: ' + name)
        mapped = 'model.' + name[len(prefix):]
        records.append(TensorRecord(name, mapped, dtype, tuple(shape), 8 + length + begin, end - begin))
    records.sort(key=lambda r: (r.offset, r.nbytes, r.source_name))
    cursor = 8 + length
    for record in records:
        if record.offset != cursor:
            raise ValueError('Tensor gap or overlap')
        cursor += record.nbytes
    if cursor != size or not records:
        raise ValueError('Source file size or tensor count mismatch')
    if len({r.model_name for r in records}) != len(records):
        raise ValueError('Mapped names are not unique')
    if require_2b:
        if size != DERIVED_BYTES or sha256_file(path) != DERIVED_SHA256:
            raise ValueError('Not the exact verified historical derivative')
        if Counter(r.dtype for r in records) != {'BF16': 284, 'F32': 36}:
            raise ValueError('Original mixed dtype profile changed')
        if sum(r.numel for r in records) != 1_881_825_088:
            raise ValueError('Source element count changed')
        if sum(r.numel for r in records if r.dtype == 'F32') != 2_592:
            raise ValueError('Source F32 scalar/norm count changed')
    return records


def cast_elements(specs):
    """Specs are (source dtype string, element count); F32 needs no cast copy."""
    total = 0
    for dtype, elements in specs:
        if dtype not in DTYPE_BYTES or type(elements) is not int or elements < 0:
            raise ValueError('Invalid cast specification')
        if dtype == 'BF16':
            total += elements
    return total


def rope_scaling_signature(value):
    """Immutable exact scalar signature; rejects bool, nonfinite or tensor state.

    The pinned official default initializer returns a Python float. Keeping its
    type and exact binary-value spelling detects later scalar drift independently
    of the inverse-frequency tensor buffers.
    """
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('RoPE attention_scaling must be a finite Python scalar')
    return (type(value).__name__, float(value).hex())


class ExclusiveLedger:
    """Non-reentrant CPU arena accounting with bounded history + streaming sink."""
    def __init__(self, capacity_elements, *, sink=None, history_limit=1024):
        if type(capacity_elements) is not int or capacity_elements < 0:
            raise ValueError('Invalid arena capacity')
        if type(history_limit) is not int or history_limit < 0:
            raise ValueError('Invalid history limit')
        self.capacity_elements = capacity_elements
        self.sink = sink
        self.events = deque(maxlen=history_limit)
        # Keep at least the latest secondary sink failure even when ordinary
        # event retention is disabled. Never retain exception/traceback objects.
        self.secondary_errors = deque(maxlen=max(1, history_limit))
        self.busy = False
        self.current_cast_bytes = 0
        self.max_live_cast_bytes = 0
        self.lease_count = 0
        self._lock = threading.Lock()

    def _emit(self, row):
        self.events.append(row)
        if self.sink is not None:
            self.sink(dict(row))

    @contextmanager
    def lease(self, elements, label):
        if type(elements) is not int or not 0 <= elements <= self.capacity_elements:
            raise ValueError('Cast exceeds exclusive arena capacity')
        if not self._lock.acquire(blocking=False):
            raise RuntimeError('Nested/concurrent arena lease rejected: ' + label)
        self.busy = True
        self.current_cast_bytes = elements * 4
        self.max_live_cast_bytes = max(self.max_live_cast_bytes, self.current_cast_bytes)
        self.lease_count += 1
        row = dict(lease_id=self.lease_count, label=label, cast_bytes=self.current_cast_bytes,
                   arena_bytes=self.capacity_elements * 4, thread=threading.get_ident())
        primary_error = None
        try:
            self._emit(dict(row, event='acquire', monotonic=time.monotonic()))
            yield row
        except BaseException as error:
            primary_error = error
            raise
        finally:
            # Cleanup remains unconditional even when the sink or leaf fails.
            self.current_cast_bytes = 0
            self.busy = False
            self._lock.release()
            try:
                self._emit(dict(row, event='release', monotonic=time.monotonic()))
            except BaseException as release_error:
                if primary_error is None:
                    # A release-only failure must still be visible to the caller.
                    raise
                try:
                    message = str(release_error)[:512]
                except BaseException:
                    message = '<exception message unavailable>'
                self.secondary_errors.append(dict(
                    event='release_sink_failure', lease_id=row['lease_id'],
                    error_type=type(release_error).__name__, message=message,
                    primary_error_type=type(primary_error).__name__))
                # The pending acquire/body exception is re-raised unchanged;
                # a poisoned sink must not replace the actual stopping reason.


class PatchStack:
    """Restore original instance-vs-class attribute ownership, not just equality."""
    def __init__(self):
        self._undo = []

    def set(self, target, name, value):
        owned = name in vars(target)
        old = vars(target).get(name)
        setattr(target, name, value)
        self._undo.append((target, name, owned, old))

    def restore(self):
        failures = []
        while self._undo:
            target, name, owned, old = self._undo.pop()
            try:
                if owned:
                    setattr(target, name, old)
                else:
                    delattr(target, name)
            except Exception as error:
                failures.append(error)
        if failures:
            raise RuntimeError('Failed to restore patched attributes') from failures[0]
