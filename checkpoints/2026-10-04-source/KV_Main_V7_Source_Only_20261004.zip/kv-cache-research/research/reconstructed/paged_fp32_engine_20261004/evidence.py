"""Call-local materialized-mask and complete cache evidence for CPU revalidation.

No default capture of a pretrained run; callers own artifact budgets. Tensor
snapshots are small in the tiny gate; production can stream per-call snapshots.
"""
import copy
import inspect
try:
    from .paged_fp32_engine import tensor_digest
except ImportError:
    from paged_fp32_engine import tensor_digest


def cache_snapshot(cache, torch):
    """Include every cache/layer instance attribute, not only recurrent/KV data."""
    tensors = {}
    def visit(value, path):
        if isinstance(value, torch.Tensor):
            if value.device.type != 'cpu':
                raise ValueError('Non-CPU cache at ' + path)
            if value.is_floating_point() and value.dtype != torch.float32:
                raise ValueError('Non-FP32 cache at ' + path)
            contiguous = value.contiguous()
            tensors[path] = value
            return dict(tensor=True, shape=list(value.shape), dtype=str(value.dtype),
                        sha256=tensor_digest(contiguous))
        if value is None or type(value) in (str, int, float, bool):
            return value
        if isinstance(value, (torch.dtype, torch.device)):
            return str(value)
        if isinstance(value, type):
            return dict(class_reference=value.__module__ + '.' + value.__qualname__)
        if isinstance(value, dict):
            return {'mapping': [[visit(k, path + '.key'), visit(v, path + '[' + repr(k) + ']')]
                                for k, v in value.items()]}
        if isinstance(value, (tuple, list)):
            return {type(value).__name__: [visit(v, path + '[' + str(i) + ']') for i, v in enumerate(value)]}
        if type(value).__module__ == 'transformers.cache_utils':
            return {'type': type(value).__name__, 'attributes':
                    {k: visit(v, path + '.' + k) for k, v in vars(value).items()}}
        raise ValueError('Unaccounted cache metadata at ' + path + ': ' + type(value).__name__)
    return visit(cache, 'cache'), tensors


def clone_cache_checked(cache, torch):
    before, original = cache_snapshot(cache, torch)
    cloned = copy.deepcopy(cache)
    after, copied = cache_snapshot(cloned, torch)
    if before != after or set(original) != set(copied):
        raise ValueError('Cache clone changed values or complete metadata')
    source_storages = {t.untyped_storage().data_ptr() for t in original.values() if t.numel()}
    if any(t.numel() and t.untyped_storage().data_ptr() in source_storages for t in copied.values()):
        raise ValueError('Scoring clone aliases source cache storage')
    return cloned


class MaterializedMaskCapture:
    """Validate actual per-layer masks for an unpadded batch-one text call.

    context(manager) covers exactly one call; provide real history and current
    token IDs. Full-attention tensors are copied and retained, recurrent masks
    must be None. No replacement mask is supplied to the model.
    """
    def __init__(self, model, torch, history_ids, input_ids):
        self.model, self.torch = model, torch
        self.history_ids, self.input_ids = list(history_ids), list(input_ids)
        if not self.input_ids:
            raise ValueError('Empty forward call')
        self.start = len(self.history_ids)
        self.positions = list(range(self.start, self.start + len(self.input_ids)))
        self.masks = {}
        self.handles = []
        self.expected_full = {i for i, block in enumerate(model.model.layers) if hasattr(block, 'self_attn')}
        self.expected_recurrent = {i for i, block in enumerate(model.model.layers) if hasattr(block, 'linear_attn')}
        self.recurrent = set()
        self.observed_call = None

    def __enter__(self):
        torch = self.torch
        try:
            signature = inspect.signature(self.model.forward)
            def root_hook(module, args, kwargs, signature=signature):
                if self.observed_call is not None:
                    raise ValueError('Capture covers more than one root call')
                bound = signature.bind(*args, **kwargs)
                bound.apply_defaults()
                actual_ids = bound.arguments['input_ids']
                if actual_ids is None or actual_ids.tolist() != [self.input_ids]:
                    raise ValueError('Actual model input IDs differ from declared call')
                actual_positions = bound.arguments['position_ids']
                if actual_positions is None or actual_positions.tolist() != [self.positions]:
                    raise ValueError('Explicit actual absolute text position IDs required')
                actual_mask = bound.arguments['attention_mask']
                if not isinstance(actual_mask, torch.Tensor) or tuple(actual_mask.shape) != (1, self.start + len(self.input_ids)) or not bool((actual_mask == 1).all()):
                    raise ValueError('This evidence contract requires explicit unpadded attention input')
                past = bound.arguments['past_key_values']
                length = 0 if past is None else past.get_seq_length()
                if length != self.start:
                    raise ValueError('Actual cache length differs from declared history')
                self.observed_call = dict(input_ids=actual_ids.tolist()[0],
                    absolute_text_position_ids=actual_positions.tolist()[0],
                    past_cache_length=int(length), attention_mask_shape=list(actual_mask.shape))
            self.handles.append(self.model.register_forward_pre_hook(root_hook, with_kwargs=True))
            for index, block in enumerate(self.model.model.layers):
                module = block.self_attn if index in self.expected_full else block.linear_attn
                signature = inspect.signature(module.forward)
                def hook(module, args, kwargs, index=index, signature=signature):
                    bound = signature.bind(*args, **kwargs)
                    bound.apply_defaults()
                    mask = bound.arguments['attention_mask']
                    if index in self.expected_recurrent:
                        if mask is not None:
                            raise ValueError('Unpadded recurrent mask is not None')
                        self.recurrent.add(index)
                        return
                    if index in self.masks:
                        raise ValueError('Capture covers more than one forward')
                    if not isinstance(mask, torch.Tensor) or mask.dtype != torch.float32 or mask.device.type != 'cpu':
                        raise ValueError('Missing actual CPU FP32 full-attention mask')
                    q, k = len(self.input_ids), len(self.history_ids) + len(self.input_ids)
                    if tuple(mask.shape) != (1, 1, q, k):
                        raise ValueError('Materialized mask shape differs from token history')
                    forbidden = torch.arange(k)[None, :] > torch.tensor(self.positions)[:, None]
                    actual = mask[0, 0]
                    if not torch.equal(actual == 0, ~forbidden):
                        raise ValueError('Actual causal support/absolute positions differ')
                    if forbidden.any() and not bool((actual[forbidden] <= torch.finfo(torch.float32).min).all()):
                        raise ValueError('Future tokens are not completely masked')
                    position_ids = bound.arguments.get('position_ids')
                    if position_ids is None:
                        position_ids = bound.arguments.get('kwargs', {}).get('position_ids')
                    if position_ids is not None and position_ids.tolist() != [self.positions]:
                        raise ValueError('Actual text position IDs changed')
                    self.masks[index] = mask.detach().clone()
                self.handles.append(module.register_forward_pre_hook(hook, with_kwargs=True))
        except BaseException:
            self._remove()
            raise
        return self

    def _remove(self):
        for handle in self.handles:
            handle.remove()
        self.handles.clear()

    def __exit__(self, kind, value, tb):
        self._remove()
        if kind is None and (self.observed_call is None or set(self.masks) != self.expected_full or self.recurrent != self.expected_recurrent):
            raise ValueError('Did not observe every hybrid layer mask')
        return False

    def summary(self):
        return dict(history_ids=self.history_ids, history_provenance='caller-declared token lineage; actual cache length checked',
                    observed_root_call=self.observed_call,
                    full_attention_masks={str(k): {'shape': list(v.shape), 'sha256': tensor_digest(v)}
                                          for k, v in self.masks.items()},
                    recurrent_mask_none_layers=sorted(self.recurrent))
