"""External bounded watchdog for the one cohesive no-pretrained tiny test suite."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time


def rss(pid):
    try:
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if line.startswith('VmRSS:'):
                return int(line.split()[1])*1024
    except FileNotFoundError:
        pass
    return 0


def family(pid):
    result = [pid]
    try:
        children = Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except FileNotFoundError:
        children = []
    for child in children:
        result.extend(family(int(child)))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--attempt', required=True)
    args = parser.parse_args()
    if not args.attempt.isalnum():
        raise ValueError('Simple unique attempt name required')
    here = Path(__file__).resolve().parent
    root = here.parents[2]
    wrapper = here.parent/'runtime_recovery_20261004/cpu_python.sh'
    output = here/f'tiny_{args.attempt}.json'
    log = here/f'tiny_{args.attempt}.log'
    receipt = here/f'guard_{args.attempt}.json'
    if any(p.exists() for p in (output, log, receipt)):
        raise ValueError('Refusing to overwrite a prior attempt')
    disk_floor, rss_limit, artifact_limit = 5_000_000_000, 500_000_000, 10_000_000
    if shutil.disk_usage(here).free < disk_floor:
        raise RuntimeError('5GB reserve unavailable')
    started = time.monotonic()
    peak = 0
    stopped = None
    with log.open('x') as stdout:
        process = subprocess.Popen(['bash',str(wrapper),str(here/'run_tiny_gate.py'),'--out',str(output)],
                                   cwd=root, stdout=stdout, stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            current = rss(os.getpid()) + sum(rss(pid) for pid in family(process.pid))
            peak = max(peak,current)
            artifact_bytes = sum(p.stat().st_size for p in here.rglob('*') if p.is_file())
            if current >= rss_limit: stopped = 'combined_parent_child_RSS_limit'
            elif shutil.disk_usage(here).free < disk_floor: stopped = 'disk_reserve'
            elif artifact_bytes > artifact_limit: stopped = 'artifact_limit'
            elif time.monotonic()-started > 180: stopped = '180_second_tiny_gate_timeout'
            if stopped:
                os.killpg(process.pid, signal.SIGKILL)
                break
            time.sleep(.05)
        code = process.wait()
    receipt.write_text(json.dumps(dict(exit_code=code, stopped_by=stopped,
        combined_peak_rss_bytes=peak, rss_limit_bytes=rss_limit,
        disk_floor_bytes=disk_floor, artifact_limit_bytes=artifact_limit,
        elapsed_seconds=time.monotonic()-started, sampling_seconds=.05,
        scope='new tiny random model only; no pretrained assets'),indent=2)+'\n')
    print(receipt.read_text())
    print(log.read_text())
    raise SystemExit(code if code >= 0 else 1)


if __name__ == '__main__': main()
