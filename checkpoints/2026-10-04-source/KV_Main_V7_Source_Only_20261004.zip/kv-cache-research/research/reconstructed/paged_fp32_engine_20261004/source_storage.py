"""Optional preparation after the official CPU BF16 loader, before engine install.

Never call model.float(). Re-read the 36 tiny source-F32 parameters (2,592
values, 10,368 bytes in 2B) from the original mixed file and restore their dtype
and literal bytes. The official loader handles all model construction, mapping
and tied parameters; validate_source_parameters independently checks all values.
No loading or model construction occurs on import.
"""
try:
    from .contracts import read_source_manifest
    from .paged_fp32_engine import validate_source_parameters, tensor_digest
except ImportError:
    from contracts import read_source_manifest
    from paged_fp32_engine import validate_source_parameters, tensor_digest


def restore_original_small_fp32(model, source_path, torch):
    """Explicit preparation, not a forward or a claim of recovered weight bytes.

    Requires the exact derivative. Call after clean official from_pretrained(...,
    dtype=torch.bfloat16, local_files_only=True, attn_implementation='eager') and
    model.eval(), while no engine is installed. Returned audit verifies all 320
    source tensors. The smallest F32 restoration is not a new full-size payload.
    """
    from safetensors import safe_open
    records = read_source_manifest(source_path)
    named = dict(model.named_parameters())
    if set(named) != {r.model_name for r in records}:
        raise ValueError('Official model/source name coverage differs')
    if model.lm_head.weight is not model.model.embed_tokens.weight:
        raise ValueError('Official tied head was not loaded')
    if any(p.device.type != 'cpu' for p in named.values()):
        raise ValueError('CPU source-resident model required')
    restored = []
    with torch.no_grad(), safe_open(str(source_path), framework='pt', device='cpu') as source:
        for record in records:
            parameter = named[record.model_name]
            if tuple(parameter.shape) != record.shape:
                raise ValueError('Original parameter shape changed')
            if record.dtype == 'F32':
                original = source.get_tensor(record.source_name)
                if original.dtype != torch.float32:
                    raise ValueError('Source file did not return original F32 dtype')
                # Preserve Parameter identity and ties; own the 10KB tiny values.
                parameter.data = original.clone()
                restored.append(record.model_name)
            elif parameter.dtype != torch.bfloat16:
                raise ValueError('Large source parameter was not kept BF16')
        rotary = model.model.rotary_emb
        if rotary.rope_type != 'default':
            raise ValueError('Only pinned default text RoPE is supported')
        # These are constructor-derived nonpersistent buffers, not checkpoint
        # tensors. Rebuild via the pinned official formula instead of widening
        # any buffer previously rounded by an indiscriminate model.bfloat16().
        expected, scale = rotary.compute_default_rope_parameters(rotary.config)
        if expected.dtype != torch.float32 or expected.device.type != 'cpu':
            raise ValueError('Official default RoPE did not produce CPU FP32')
        for name in ('inv_freq', 'original_inv_freq'):
            rotary._buffers[name] = expected.clone()
        rotary.attention_scaling = scale
    audit = validate_source_parameters(model, source_path)
    audit.update(restored_source_fp32_names=restored, restored_source_fp32_bytes=10_368,
                 rope_source='pinned official compute_default_rope_parameters',
                 rope_sha256=tensor_digest(model.model.rotary_emb.inv_freq))
    return audit
