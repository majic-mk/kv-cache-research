# Reconstructed paged CPU FP32 engine

This is **new source written on 2026-10-04**, not recovered bytes of the lost
historical engine. Nothing here reinstates its historical pretrained results.
The exact recovered source tree and its BF16 qualification failure are unchanged.

## Implemented execution contract

- Keep the original mixed source parameters resident: 284 BF16 + 36 F32 tensors
  in the historical text-only 2B derivative. Source F32 A_log and gated norm
  weights must not be BF16-rounded. All 320 names, shapes, dtypes and literal
  bytes are checked against that exact source file before production install
- One reusable FP32 arena, sized to the largest leaf: the tied 248,320 × 2,048
  output head, **2,034,237,440 bytes**. This is additional working memory, not a
  claim that total RSS is 2GB. No full `model.float()` or full FP32 checkpoint
- A Linear borrows its FP32 weight/bias views only during its synchronous CPU
  operation. Embedding gathers original source rows first, then widens only the
  selected activation. Parameter identities and embedding/head tie never change
- The two actual official functional conv helpers are wrapped, including cached
  single-token updates. Their lease ends at the helper return. A lease never
  spans an entire GDN module and therefore cannot overlap its nested Linear calls
- Native RMSNorm retains the official `1 + weight.float()` arithmetic. Native
  GDN/recurrence, nonlinearities and RoPE are not replaced. Constructor-derived
  FP32 RoPE buffers must match the pinned official formula exactly
- CPU-only pinned Torch, inference mode, CPU autocast off, highest float32 matmul
  precision and oneDNN matmul/conv/rnn IEEE mode. No GPU, autograd, offloading,
  custom Linear/Embedding, dynamic RoPE, alternate kernels or concurrent engine
- Nested/concurrent arena leases fail. Lease events can stream to a callback;
  retained history is bounded. The meter covers engine Linear/conv cast copies;
  activations, native small norm temporaries, caches and backend workspace are
  outside it and must be covered by the independent RSS guard
- Context exit restores methods, helper globals and precision settings even on
  exceptions, then checks source identities, aliases, hooks, buffer values and
  parameter bytes. The engine installs no hooks of its own

## Files and API

`contracts.py`: stdlib-only source metadata parser, exclusive cast accounting,
bounded event stream, and exact method-attribute restoration.

`paged_fp32_engine.py`: `PagedArenaEngine(model, hf, torch, source_path=...)`.
Use `with engine:` around model and adapter calls, or `install()` followed by
`with execution():` and `remove()` in a finally block. `synthetic=True` is an
explicit tiny-test-only bypass; it does not certify checkpoint provenance.

`source_storage.py`: optional `restore_original_small_fp32` after the ordinary
official BF16 loader, before engine install. It re-reads only the original 36
small F32 entries (10,368 bytes total) and source-formula RoPE, preserving
Parameter identities. All resident values are then audited against the file.
This preparation helper is implemented but **not exercised on a 2B model**.

`evidence.py`: `MaterializedMaskCapture` observes a single root call's actual
input IDs, explicit positions and cache length, plus the actual materialized
mask at every full-attention layer. It verifies causal support and recurrent
mask None. History token lineage is explicitly caller-declared; cache length
alone cannot prove those historical token identities. `cache_snapshot` includes
every cache/layer instance attribute and all R/C/K/V tensors;
`clone_cache_checked` verifies complete metadata and independent tensor storage.
Install temporary capture hooks inside the engine execution context, and remove
them before exiting it. Save mask tensors separately if later comparison is
needed; JSON summaries contain hashes, not raw masks.

## Current validation

- `test_contracts.py`: **18 stdlib tests pass**, no Torch/model needed
- `run_tiny_gate.py`, externally launched through `guard_tiny_gate.py`: one
  cohesive new tiny random-model suite. See `tiny_verified.json` and
  `guard_verified.json` for the final current result; earlier attempts are preserved
- Tiny topology is 18 recurrent + 6 full-attention layers, 213,574 parameters.
  Both arms have exactly the same source values. Only the tiny reference is
  widened wholly to FP32; the mixed arm uses the arena
- Covers full 69-token prefill, 66+3 exact-prefix schedule, cached single-token
  convolution update, all six actual masks, all cache channels + metadata,
  nonalias cache cloning, nonzero RMSNorm sensitivity, source bytes, tie, RoPE,
  nested lease rejection, and leaf/outer exception restoration
- Tiny tolerances are atol=rtol=1e-6, TV≤1e-6, no greedy disagreements. They do
  not replace any scientific or pretrained qualification thresholds
- Preserved failures: first attempt's config listed four layer types for 24
  layers; second omitted the tiny config's tie_word_embeddings=True. Both test
  fixtures were corrected. After adding root-call input/position observation, a
  closure accidentally reused a layer signature; that instrumentation error
  failed before the forward and was corrected by binding the root signature.
  `tiny_final.log` preserves that failure. No failed scientific cell was retried
  or erased
- No pretrained file was downloaded, no pretrained model loaded, no 2B forward,
  contextual-harm cell, held-out test or method-benefit comparison ran here

Run stdlib checks from the repository root:

```sh
python -m unittest discover -s research/reconstructed/paged_fp32_engine_20261004 -p test_contracts.py -v
```

The tiny watchdog refuses reused attempt names; retains stdout/failures; checks
parent+child RSS every 50ms against 500,000,000 bytes, a 5GB free-disk floor,
10MB local artifacts, and 180 seconds. Its bounded sampling is not an OS-level
hard RSS limit. Tiny model forwards require an explicit release, already granted
for this reconstruction's focused suite; this does not authorize 2B execution.

## Smallest remaining runtime/asset path

The recovered dependency freeze and hashes are in:

- `research/diagnostics/hybrid_recurrence_cpu/requirements.freeze.txt`
- `research/diagnostics/hybrid_recurrence_cpu/provenance.json`
- `research/diagnostics/hybrid_recurrence_cpu/verify_environment.py`
- `research/diagnostics/hybrid_recurrence_cpu/logs/environment_verification.json`
- Its `logs/install_torch.log` and `logs/install_transformers.log` are historical
  install logs, **not a cryptographic wheel manifest**

The independently reconstructed runtime is now available through
`research/reconstructed/runtime_recovery_20261004/cpu_python.sh`: Torch
2.9.1+cpu, NumPy2.2.6, Transformers commit
02d8fb9784e8f14a1251e4c992cd82a5762417c6 (5.19.0.dev0). No extra package is needed
for this engine. Safetensors0.8.0 is in the recovered freeze for small F32 restore.

Remaining pretrained asset, if separately authorized: original lossless text
subset of Qwen/Qwen3.5-2B at revision
15852e8c16360a2fea060d615a32b45270f8a8fc. Expected derivative is 3,763,696,896B,
SHA-256 42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c.
Original official full-stream SHA-256 is
aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1.
Config/tokenizer exact hashes and lossless preparation source are preserved in
`research/diagnostics/text_only_asset_projection/RESULTS.md` and its directory.
Those historical manifests establish the desired identity, not current presence.

Do not re-run the old broad Gate0 or invent more generic admission suites. The
next scoped step is the separately declared small scientific stage: load the
verified mixed source correctly, enforce its resource limits, check the exact
full/prefix control in that stage, and advance only as its frozen rules allow.
The present tiny pass does not establish 2B memory fit or pretrained parity.
