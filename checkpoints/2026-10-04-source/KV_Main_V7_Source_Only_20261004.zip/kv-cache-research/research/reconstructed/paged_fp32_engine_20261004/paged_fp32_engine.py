"""New reconstruction, NOT the lost historical paged FP32 implementation.

Inference-only, single-threaded patch owner for the pinned official Qwen3.5 text
model. Source BF16/F32 parameters are never swapped or mutated. Only Linear and
functional convolution operands borrow one CPU FP32 arena; Embedding widens the
gathered output. Native norms/recurrence/RoPE retain their original source code.
No import-time Torch dependency, model construction, download or forward.
"""
from collections import Counter
from contextlib import contextmanager
import ctypes
import hashlib
import inspect
from pathlib import Path
import threading
import types

try:
    from .contracts import (ExclusiveLedger, PatchStack, cast_elements,
                            read_source_manifest, sha256_file, MODELING_SHA256,
                            EXPECTED_ARENA_BYTES, rope_scaling_signature)
except ImportError:
    from contracts import (ExclusiveLedger, PatchStack, cast_elements,
                           read_source_manifest, sha256_file, MODELING_SHA256,
                           EXPECTED_ARENA_BYTES, rope_scaling_signature)


def tensor_digest(tensor, chunk_bytes=4 * 1024**2):
    """Bounded raw-byte hashing; no NumPy dependency or full FP32 copy."""
    if tensor.device.type != 'cpu' or not tensor.is_contiguous():
        raise ValueError('Byte audit requires resident contiguous CPU tensors')
    digest = hashlib.sha256()
    remaining, address = tensor.numel() * tensor.element_size(), tensor.data_ptr()
    while remaining:
        size = min(remaining, chunk_bytes)
        digest.update(ctypes.string_at(address, size))
        address += size
        remaining -= size
    return digest.hexdigest()


def _tensor_signature(tensor):
    return (id(tensor), str(tensor.dtype), str(tensor.device), tuple(tensor.shape),
            tuple(tensor.stride()), tensor.storage_offset(), tensor.data_ptr())


def _hook_signature(module):
    # Do not register any engine hooks: existing callbacks and their order survive.
    return {key: tuple((ident, id(value)) for ident, value in data.items())
            for key, data in vars(module).items()
            if 'hook' in key and isinstance(data, dict)}


def validate_source_parameters(model, source_path, *, require_2b=True):
    """Check each resident parameter against its original mixed checkpoint bytes.

    A conventional dtype=BF16 load fails for source-F32 A_log/gated norm entries.
    Caller must first load original per-tensor dtypes; this is not a loader.
    """
    records = read_source_manifest(source_path, require_2b=require_2b)
    named = dict(model.named_parameters())
    if set(named) != {r.model_name for r in records}:
        raise ValueError('Resident/source parameter-name coverage differs')
    hashes = {}
    for record in records:
        parameter = named[record.model_name]
        dtype = {'torch.bfloat16': 'BF16', 'torch.float32': 'F32'}.get(str(parameter.dtype))
        if dtype != record.dtype or tuple(parameter.shape) != record.shape:
            raise ValueError('Original source dtype/shape lost: ' + record.model_name)
        expected = sha256_file(source_path, record.offset, record.nbytes)
        if tensor_digest(parameter) != expected:
            raise ValueError('Original source bytes lost: ' + record.model_name)
        hashes[record.model_name] = expected
    return dict(parameter_sha256=hashes, tensor_count=len(records),
                dtype_counts=dict(Counter(r.dtype for r in records)),
                source_path=str(Path(source_path).resolve()), source_exact=True)


class PagedArenaEngine:
    """One model, one arena, synchronous CPU operations, never autograd.

    Production callers must pass source_path. synthetic=True only permits the
    explicitly labeled tiny numerical test; it cannot certify pretrained values.
    `with engine:` installs, enters FP32 inference execution, and always restores.
    Alternatively install(); with execution(): ...; remove() in finally.
    All model/adapter calls using patched helpers must be inside execution().
    """
    def __init__(self, model, hf, torch, *, source_path=None, synthetic=False,
                 arena_elements=None, lease_sink=None, history_limit=1024):
        if source_path is None and not synthetic:
            raise ValueError('Original source file required; no guessed mixed profile')
        self.model, self.hf, self.torch = model, hf, torch
        self.synthetic = synthetic
        self.source_path = source_path
        self._requested_elements = arena_elements
        self._lease_sink, self._history_limit = lease_sink, history_limit
        self.arena = None
        self.ledger = None
        self._patches = PatchStack()
        self._installed = False
        self._executing = False
        self._thread = None
        self._context = None
        self._source_audit = None
        self._before = None
        self._before_hashes = None
        self._conv_parameters = set()
        self.events = []

    @property
    def busy(self):
        return self.ledger.busy if self.ledger else False

    @property
    def current_cast_bytes(self):
        return self.ledger.current_cast_bytes if self.ledger else 0

    @property
    def max_live_cast_bytes(self):
        return self.ledger.max_live_cast_bytes if self.ledger else 0

    @property
    def lease_events(self):
        return list(self.ledger.events) if self.ledger else []

    def _snapshot(self):
        # remove_duplicate=False includes the embedding/head identity alias.
        return dict(parameters={n: _tensor_signature(p) for n, p in self.model.named_parameters(remove_duplicate=False)},
                    buffers={n: _tensor_signature(b) for n, b in self.model.named_buffers(remove_duplicate=False)},
                    hooks={n: _hook_signature(m) for n, m in self.model.named_modules()},
                    training={n: m.training for n, m in self.model.named_modules()},
                    rope_attention_scaling=rope_scaling_signature(self.model.model.rotary_emb.attention_scaling))

    def _hashes(self):
        return dict(parameters={n: tensor_digest(p) for n, p in self.model.named_parameters()},
                    buffers={n: tensor_digest(b) for n, b in self.model.named_buffers()},
                    rope_attention_scaling=hashlib.sha256(repr(rope_scaling_signature(
                        self.model.model.rotary_emb.attention_scaling)).encode('ascii')).hexdigest())

    def verify_integrity(self, *, deep=False):
        if self._before is None or self._snapshot() != self._before:
            raise RuntimeError('Source identities/dtypes/buffers/tie/hooks/training/RoPE scaling changed')
        if deep and self._hashes() != self._before_hashes:
            raise RuntimeError('Source parameter or RoPE buffer bytes changed')
        return dict(structural=True, byte_exact=bool(deep))

    def _dtype(self, tensor):
        if tensor.device.type != 'cpu' or not tensor.is_contiguous():
            raise ValueError('Only contiguous CPU source parameters are supported')
        if tensor.dtype == self.torch.bfloat16:
            return 'BF16'
        if tensor.dtype == self.torch.float32:
            return 'F32'
        raise ValueError('Unexpected source dtype: ' + str(tensor.dtype))

    def _elements(self, tensors):
        return cast_elements([(self._dtype(t), t.numel()) for t in tensors if t is not None])

    def _check_execution(self):
        if not self._executing or threading.get_ident() != self._thread:
            raise RuntimeError('Use the engine execution context on its owning thread')
        if self.torch.is_grad_enabled() or self.torch.is_autocast_enabled('cpu'):
            raise RuntimeError('FP32 inference/autocast-off contract violated')

    def _fp32(self, value, label):
        if value.device.type != 'cpu' or value.dtype != self.torch.float32:
            raise ValueError(label + ' must be CPU FP32; no hidden activation downcast')

    @contextmanager
    def _lease(self, tensors, label):
        self._check_execution()
        elements = self._elements(tensors)
        with self.ledger.lease(elements, label):
            widened, cursor = [], 0
            for tensor in tensors:
                if tensor is None or tensor.dtype == self.torch.float32:
                    widened.append(tensor)
                else:
                    size = tensor.numel()
                    view = self.arena.narrow(0, cursor, size).view(tensor.shape)
                    view.copy_(tensor)  # BF16 -> FP32 in the already allocated arena
                    widened.append(view)
                    cursor += size
            yield widened
        # Views may not escape this context. CPU linear/conv outputs own storage.

    def _linear(self, module, name):
        def forward(_module, input):
            self._check_execution()
            self._fp32(input, name + ' input')
            with self._lease((module.weight, module.bias), name) as (weight, bias):
                return self.torch.nn.functional.linear(input, weight, bias)
        return types.MethodType(forward, module)

    def _embedding(self, module, original, name):
        def forward(_module, input):
            self._check_execution()
            # BF16 lookup is byte selection, not arithmetic. Widen selected rows;
            # never widen the entire embedding/head matrix for a lookup.
            output = original(input).to(dtype=self.torch.float32)
            self._fp32(output, name + ' output')
            return output
        return types.MethodType(forward, module)

    def _conv_helper(self, original, name):
        signature = inspect.signature(original)
        def wrapped(*args, **kwargs):
            self._check_execution()
            bound = signature.bind(*args, **kwargs)
            bound.apply_defaults()
            self._fp32(bound.arguments['hidden_states'], name + ' input')
            if name == 'causal_conv1d_update':
                self._fp32(bound.arguments['conv_state'], name + ' state')
            weight, bias = bound.arguments['weight'], bound.arguments['bias']
            for operand in (weight, bias):
                if operand is not None and (operand.data_ptr(), operand.numel(), str(operand.dtype)) not in self._conv_parameters:
                    raise ValueError('Functional convolution used an unregistered source weight')
            with self._lease((weight, bias), name) as (wide_weight, wide_bias):
                bound.arguments['weight'], bound.arguments['bias'] = wide_weight, wide_bias
                return original(*bound.args, **bound.kwargs)
        return wrapped

    def _check_rope_source(self, rotary):
        torch = self.torch
        if rotary.rope_type != 'default':
            raise ValueError('Dynamic RoPE can replace buffers; only default source RoPE is admitted')
        for name in ('inv_freq', 'original_inv_freq'):
            self._fp32(getattr(rotary, name), 'source RoPE ' + name)
        expected_rope, expected_scaling = rotary.compute_default_rope_parameters(rotary.config)
        if rope_scaling_signature(rotary.attention_scaling) != rope_scaling_signature(expected_scaling):
            raise ValueError('Source RoPE attention_scaling changed')
        for name in ('inv_freq', 'original_inv_freq'):
            if not torch.equal(getattr(rotary, name), expected_rope):
                raise ValueError('Source FP32 RoPE values changed: ' + name)

    def _preflight(self):
        torch = self.torch
        if torch.__version__ != '2.9.1+cpu' or torch.version.cuda is not None:
            raise ValueError('Use the recovered CPU-only Torch pin 2.9.1+cpu')
        if sha256_file(self.hf.__file__) != MODELING_SHA256:
            raise ValueError('Official Qwen3.5 modeling source differs from recovered pin')
        if type(self.model) is not self.hf.Qwen3_5ForCausalLM:
            raise ValueError('Only official Qwen3_5ForCausalLM text graph is supported')
        if self.model.config._attn_implementation != 'eager':
            raise ValueError('Materialized eager full-attention masks are required')
        if any(m.training for m in self.model.modules()):
            raise ValueError('Call eval() before installing the inference engine')
        if self.model.lm_head.weight is not self.model.model.embed_tokens.weight:
            raise ValueError('Original tied embedding/head identity lost')
        self._check_rope_source(self.model.model.rotary_emb)
        plans = []
        for name, module in self.model.named_modules():
            for parameter in module.parameters(recurse=False):
                self._dtype(parameter)
            if isinstance(module, torch.nn.Linear):
                if type(module) is not torch.nn.Linear or module.forward.__func__ is not torch.nn.Linear.forward:
                    raise ValueError('Custom/replaced Linear forward: ' + name)
                plans.append(self._elements((module.weight, module.bias)))
            elif isinstance(module, torch.nn.Embedding):
                if type(module) is not torch.nn.Embedding or module.max_norm is not None:
                    raise ValueError('Custom/mutating embedding is not supported')
                if module.forward.__func__ is not torch.nn.Embedding.forward:
                    raise ValueError('Embedding forward already replaced')
            elif isinstance(module, torch.nn.Conv1d):
                plans.append(self._elements((module.weight, module.bias)))
                for tensor in (module.weight, module.bias):
                    if tensor is not None:
                        self._conv_parameters.add((tensor.data_ptr(), tensor.numel(), str(tensor.dtype)))
            elif list(module.parameters(recurse=False)) and type(module).__name__ not in {
                    'Qwen3_5RMSNorm', 'Qwen3_5RMSNormGated', 'Qwen3_5GatedDeltaNet'}:
                raise ValueError('Unaccounted direct parameter consumer: ' + name)
        for name, module in self.model.named_modules():
            if hasattr(module, '_hf_hook'):
                raise ValueError('Accelerate/offload hooks are outside this source-resident engine')
            if type(module).__name__ == 'Qwen3_5GatedDeltaNet':
                self._fp32(module.A_log, name + '.A_log')
                self._fp32(module.norm.weight, name + '.norm.weight')
        return max(plans, default=0)

    def install(self):
        if self._installed:
            raise RuntimeError('Engine already installed')
        if getattr(self.hf, '_reconstructed_paged_fp32_owner', None) is not None:
            raise RuntimeError('Official helper globals already owned by another engine')
        needed = self._preflight()
        capacity = needed if self._requested_elements is None else self._requested_elements
        if type(capacity) is not int or capacity < needed:
            raise ValueError('Arena is smaller than the largest leaf cast')
        if not self.synthetic and capacity * 4 != EXPECTED_ARENA_BYTES:
            raise ValueError('2B arena must equal the one FP32 tied-head size')
        self._source_audit = (validate_source_parameters(self.model, self.source_path)
                              if self.source_path is not None else {'source_exact': False, 'synthetic': True})
        self._before, self._before_hashes = self._snapshot(), self._hashes()
        self.ledger = ExclusiveLedger(capacity, sink=self._lease_sink, history_limit=self._history_limit)
        self.arena = self.torch.empty(capacity, dtype=self.torch.float32, device='cpu')
        try:
            self._patches.set(self.hf, '_reconstructed_paged_fp32_owner', self)
            for name, module in self.model.named_modules():
                if type(module) is self.torch.nn.Linear:
                    self._patches.set(module, 'forward', self._linear(module, name))
                elif type(module) is self.torch.nn.Embedding:
                    self._patches.set(module, 'forward', self._embedding(module, module.forward, name))
            # Scope is exactly one functional conv call, NOT its parent GDN forward.
            # Later in_proj/out_proj calls can therefore reuse the exclusive arena.
            for name in ('causal_conv1d_fn', 'causal_conv1d_update'):
                self._patches.set(self.hf, name, self._conv_helper(getattr(self.hf, name), name))
            self._installed = True
            self.events.append({'event': 'installed', 'arena_bytes': capacity * 4,
                                'label': 'new_reconstruction_not_historical_recovery'})
        except BaseException:
            self._patches.restore()
            self.arena = None
            raise
        return self

    @contextmanager
    def execution(self):
        if not self._installed or self._executing:
            raise RuntimeError('Install first; nested execution is forbidden')
        self.verify_integrity()
        changes = []
        old_matmul = self.torch.get_float32_matmul_precision()
        self._executing, self._thread = True, threading.get_ident()
        try:
            # CPU autocast off is necessary but not sufficient: oneDNN has its own
            # internal precision switches. Require the pinned CPU backend controls.
            for operator in ('matmul', 'conv', 'rnn'):
                backend = getattr(self.torch.backends.mkldnn, operator)
                changes.append((backend, backend.fp32_precision))
                backend.fp32_precision = 'ieee'
                if backend.fp32_precision != 'ieee':
                    raise RuntimeError('CPU FP32 IEEE mode was not applied')
            self.torch.set_float32_matmul_precision('highest')
            with self.torch.inference_mode(), self.torch.autocast('cpu', enabled=False):
                yield self
        finally:
            self._executing, self._thread = False, None
            try:
                for backend, value in reversed(changes):
                    backend.fp32_precision = value
            finally:
                self.torch.set_float32_matmul_precision(old_matmul)
            if self.busy or self.current_cast_bytes:
                raise RuntimeError('Leaked exclusive arena lease')

    def remove(self):
        if self._executing:
            raise RuntimeError('Exit execution context before removing engine')
        try:
            self._patches.restore()
        finally:
            self._installed = False
            self.arena = None
        if self._before is not None:
            self.verify_integrity(deep=True)
        self.events.append({'event': 'removed', 'source_bytes_rechecked': True})

    def __enter__(self):
        self.install()
        try:
            self._context = self.execution()
            self._context.__enter__()
        except BaseException:
            self.remove()
            raise
        return self

    def __exit__(self, *exception):
        try:
            return self._context.__exit__(*exception)
        finally:
            self._context = None
            self.remove()

    def report(self):
        return dict(label='new_reconstruction_not_historical_recovery',
                    source=self._source_audit, installed=self._installed,
                    arena_bytes=self.ledger.capacity_elements * 4 if self.ledger else 0,
                    current_cast_bytes=self.current_cast_bytes,
                    max_live_cast_bytes=self.max_live_cast_bytes, busy=self.busy,
                    lease_count=self.ledger.lease_count if self.ledger else 0,
                    numerical_validation='not_established_by_engine_or_stdlib_tests')


# Descriptive alias; historical API identity is not asserted.
PagedFP32Engine = PagedArenaEngine
