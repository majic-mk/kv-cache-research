"""Explicitly authorized tiny-only numerical revalidation. Never loads weights.

Run through guard_tiny_gate.py. This is a new test of newly reconstructed code,
not recovered historical output, pretrained competence, or the 24-cell study.
"""
import argparse
import copy
import json
from pathlib import Path
import resource
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError('Preserve prior results; use a new path')
    import torch
    from transformers import Qwen3_5TextConfig, Qwen3_5ForCausalLM
    from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
    from paged_fp32_engine import PagedArenaEngine, tensor_digest
    from evidence import MaterializedMaskCapture, cache_snapshot, clone_cache_checked
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.manual_seed(20261004)
    torch.set_float32_matmul_precision('highest')
    for operator in ('matmul', 'conv', 'rnn'):
        getattr(torch.backends.mkldnn, operator).fp32_precision = 'ieee'
    started = time.monotonic()
    # Match the 18 recurrent / 6 full-attention topology with tiny dimensions.
    cfg = Qwen3_5TextConfig(vocab_size=97, hidden_size=32, intermediate_size=64, tie_word_embeddings=True,
        num_hidden_layers=24, num_attention_heads=4, num_key_value_heads=2, head_dim=8,
        linear_key_head_dim=4, linear_value_head_dim=3, linear_num_key_heads=2,
        linear_num_value_heads=4, linear_conv_kernel_dim=4,
        rope_parameters={'rope_type':'default', 'rope_theta':10000.,
                         'partial_rotary_factor':.5, 'mrope_section':[1,1,0]},
        layer_types=(['linear_attention'] * 3 + ['full_attention']) * 6)
    cfg._attn_implementation = 'eager'
    model = Qwen3_5ForCausalLM(cfg).eval().cpu()
    with torch.no_grad():
        for name, parameter in model.named_parameters():
            if name.endswith('.A_log'):
                parameter.fill_(0.1234567)  # Deliberately not BF16 representable.
            elif name.endswith('.linear_attn.norm.weight'):
                parameter.fill_(0.9876543)  # Deliberately not BF16 representable.
            else:
                if name.endswith('norm.weight') or name.endswith('layernorm.weight'):
                    parameter.fill_(0.00390625)  # BF16 1+w would round incorrectly.
                parameter.data = parameter.data.to(torch.bfloat16)
    reference = copy.deepcopy(model).float().eval()
    original_methods = {name: ('forward' in vars(module), vars(module).get('forward'))
                        for name, module in model.named_modules()}
    original_helpers = (hf.causal_conv1d_fn, hf.causal_conv1d_update)
    original_hooks = {name: dict(module._forward_pre_hooks) for name, module in model.named_modules()}
    report = dict(label='new_reconstruction_tiny_random_model_only', checks=[], calls=[],
                  model_parameters=sum(p.numel() for p in model.parameters()),
                  synthetic_mixed_dtypes={str(dtype):sum(p.numel() for p in model.parameters() if p.dtype == dtype)
                                          for dtype in (torch.bfloat16, torch.float32)},
                  thresholds=dict(atol=1e-6, rtol=1e-6, tv=1e-6, greedy_disagreements=0),
                  pretrained_loads=0, pretrained_forwards=0)
    def check(label, actual, expected):
        delta = float((actual - expected).abs().max()) if actual.numel() else 0.
        assert torch.allclose(actual, expected, atol=1e-6, rtol=1e-6), (label, delta)
        report['checks'].append(dict(name=label, max_abs=delta))
    def cache_compare(label, actual, expected):
        a_meta, aa = cache_snapshot(actual, torch)
        e_meta, ee = cache_snapshot(expected, torch)
        assert set(aa) == set(ee)
        for path in aa:
            check(label + '/' + path, aa[path], ee[path])
        # Byte hashes may differ within tolerance; all other metadata must agree.
        def remove_hash(value):
            if isinstance(value, dict): return {k:remove_hash(v) for k,v in value.items() if k != 'sha256'}
            if isinstance(value, list): return [remove_hash(v) for v in value]
            return value
        assert remove_hash(a_meta) == remove_hash(e_meta)
    def call(target, ids, history=(), cache=None):
        positions = torch.arange(len(history), len(history)+len(ids)).unsqueeze(0)
        with MaterializedMaskCapture(target, torch, history, ids) as masks:
            out = target(input_ids=torch.tensor([ids]), past_key_values=cache,
                         position_ids=positions, attention_mask=torch.ones((1,len(history)+len(ids)),dtype=torch.long),
                         use_cache=True)
        assert out.logits.dtype == torch.float32
        assert len(masks.masks) == 6 and len(masks.recurrent) == 18
        report['calls'].append(masks.summary())
        return out, masks
    ids = [int(x) for x in torch.randint(1,96,(69,))]
    a, b, q = ids[:7], ids[7:66], ids[66:]
    report['tokens'] = dict(A=a, B=b, Q=q)
    with torch.inference_mode(), torch.autocast('cpu', enabled=False):
        expected, ref_masks = call(reference, ids)
        ref_prefix, _ = call(reference, ids[:66])
        ref_cont, _ = call(reference, q, ids[:66], clone_cache_checked(ref_prefix.past_key_values, torch))
        ref_decode, _ = call(reference, [17], ids, clone_cache_checked(expected.past_key_values, torch))
        engine = PagedArenaEngine(model, hf, torch, synthetic=True, history_limit=16)
        streamed = []
        engine._lease_sink = streamed.append
        with engine:
            assert model.lm_head.weight is model.model.embed_tokens.weight
            lookup = model.model.embed_tokens(torch.tensor([[1,2]]))
            check('embedding_gather_widens_selected_rows', lookup, reference.model.embed_tokens(torch.tensor([[1,2]])))
            assert engine.ledger.lease_count == 0
            x = torch.randn(2,32)
            check('native_nonzero_rms_1_plus_weight_in_fp32', model.model.norm(x), reference.model.norm(x))
            # Test the sensitivity of this fixture to the known wrong BF16 add.
            wrong = model.model.norm._norm(x) * (1.0 + model.model.norm.weight).float()
            assert not torch.equal(wrong, reference.model.norm(x))
            actual, masks = call(model, ids)
            check('full_logits_vs_same_values_fp32_reference', actual.logits, expected.logits)
            cache_compare('full_cache', actual.past_key_values, expected.past_key_values)
            for layer in masks.masks:
                assert torch.equal(masks.masks[layer], ref_masks.masks[layer])
            prefix, _ = call(model, ids[:66])
            frozen, _ = cache_snapshot(prefix.past_key_values, torch)
            continuation, _ = call(model, q, ids[:66], clone_cache_checked(prefix.past_key_values, torch))
            check('split_Q_logits_vs_same_schedule_reference', continuation.logits, ref_cont.logits)
            check('exact_prefix_vs_full_fresh_Q', continuation.logits, actual.logits[:,-len(q):])
            cache_compare('split_Q_cache', continuation.past_key_values, ref_cont.past_key_values)
            assert cache_snapshot(prefix.past_key_values, torch)[0] == frozen
            decode, _ = call(model, [17], ids, clone_cache_checked(actual.past_key_values, torch))
            check('cached_single_token_conv_update_logits', decode.logits, ref_decode.logits)
            cache_compare('single_token_cache', decode.past_key_values, ref_decode.past_key_values)
            tv = float((actual.logits.softmax(-1) - expected.logits.softmax(-1)).abs().sum(-1).max()/2)
            disagreements = int((actual.logits.argmax(-1) != expected.logits.argmax(-1)).sum())
            assert tv <= 1e-6 and disagreements == 0
            report['logit_metrics'] = dict(max_tv=tv, greedy_disagreements=disagreements)
            # A failing functional leaf releases its lease; next Linear is safe.
            try:
                with engine._lease((model.lm_head.weight, None), 'intentional_failure'):
                    raise ValueError('intentional leaf exception')
            except ValueError:
                pass
            assert not engine.busy and engine.current_cast_bytes == 0
            model.lm_head(torch.randn(1,1,32))
            with engine._lease((model.lm_head.weight,), 'nested_lease_negative'):
                try:
                    model.lm_head(torch.randn(1,1,32))
                except RuntimeError:
                    pass
                else:
                    raise AssertionError('Nested arena call was accepted')
            assert engine.max_live_cast_bytes == model.lm_head.weight.numel() * 4
        assert all(original_methods[n] == ('forward' in vars(m), vars(m).get('forward')) for n,m in model.named_modules())
        assert original_helpers == (hf.causal_conv1d_fn, hf.causal_conv1d_update)
        assert all(original_hooks[n] == dict(m._forward_pre_hooks) for n,m in model.named_modules())
        # Outer failure must also restore module methods/helpers/precision settings.
        try:
            with PagedArenaEngine(model, hf, torch, synthetic=True):
                model.lm_head(torch.randn(1,1,32))
                raise ValueError('intentional context exception')
        except ValueError:
            pass
        assert original_helpers == (hf.causal_conv1d_fn, hf.causal_conv1d_update)
        assert all(original_methods[n] == ('forward' in vars(m), vars(m).get('forward')) for n,m in model.named_modules())
        assert all(getattr(torch.backends.mkldnn, op).fp32_precision == 'ieee' for op in ('matmul','conv','rnn'))
        assert model.lm_head.weight is model.model.embed_tokens.weight
        # A source FP32 value intentionally survives without a round trip.
        assert float(model.model.layers[0].linear_attn.A_log[0]) != float(model.model.layers[0].linear_attn.A_log[0].bfloat16().float())
        report['engine'] = engine.report()
        report['lease_event_count'] = len(streamed)
        report['bounded_lease_history_count'] = len(engine.lease_events)
        report['special_checks'] = ['source_parameter_and_buffer_byte_integrity', 'parameter_identities_and_head_tie',
            'module_methods_helpers_and_hooks_restored', 'nested_lease_rejection', 'leaf_exception_cleanup',
            'outer_exception_cleanup', 'source_F32_nonrepresentable_values_preserved',
            'FP32_RoPE_matches_source_formula', 'materialized_masks_all_six_layers',
            'all_18_recurrent_masks_none', 'complete_cache_metadata_and_nonalias_clone',
            'original_prefix_cache_unmutated', 'CPU_autocast_disabled_and_IEEE_mode',
            'native_RMSNorm_nonzero_sensitivity']
    report.update(status='PASS_TINY_RECONSTRUCTION_ONLY', elapsed_seconds=time.monotonic()-started,
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
    args.out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','calls','tokens')}, indent=2))


if __name__ == '__main__':
    main()
