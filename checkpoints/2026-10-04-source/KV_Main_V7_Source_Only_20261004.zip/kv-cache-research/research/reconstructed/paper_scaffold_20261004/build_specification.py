"""Write documentation-only source receipts and analytical counts; no model imports."""
from pathlib import Path
import hashlib, json, datetime
R=Path(__file__).resolve().parents[3]
O=Path(__file__).resolve().parent
sources={
 'E01':['research/hypic_baseline_source_review.md'],
 'E02':['research/cpu_rejection_review.md','research/diagnostics/candidate_elimination/README.md','research/diagnostics/shared_prefix_memory/CPU_report.md'],
 'E03':['research/diagnostics/hybrid_cpu_competence/README.md','research/diagnostics/hybrid_cpu_competence/v1_integrity_failure.json','research/diagnostics/hybrid_cpu_competence/v1_probe_cells.jsonl'],
 'E04':['research/diagnostics/hybrid_cpu_competence/RESULTS.md','research/diagnostics/hybrid_cpu_competence/v2_run_report.json','research/diagnostics/hybrid_cpu_competence/v2_probe_cells.jsonl'],
 'E05':['research/diagnostics/hybrid_cpu_competence_v3/RESULTS.md','research/bf16_probe_admission_review.md','outputs/hybrid_cpu_competence_v3/qualification_run/cells.jsonl','outputs/hybrid_cpu_competence_v3/qualification_run/summary.json','outputs/hybrid_cpu_competence_v3/qualification_run/d01_A1_exact_prefix_raw_logits.pt','outputs/hybrid_cpu_competence_v3/qualification_run/d01_A1_full_recompute_raw_logits.pt'],
 'E06':['research/reconstructed/contextual_harm_stage1_20261004/PROTOCOL_RECONSTRUCTED.md','research/reconstructed/contextual_harm_stage1_20261004/README_RECONSTRUCTED.md'],
 'E07':['research/reconstructed/paged_fp32_engine_20261004/README.md','research/reconstructed/paged_fp32_engine_20261004/validation_summary.json','research/reconstructed/paged_fp32_engine_20261004/tiny_verified.json','research/reconstructed/paged_fp32_engine_20261004/guard_verified.json'],
 'E08':['research/reconstructed/model_assets_recovery_20261004/FAILED.json','research/reconstructed/model_assets_recovery_20261004/metadata_verification.json'],
 'E09':['research/recurrent_response_prior_audit.md'],
 'E10':['docs/evidence_contract.md'],
 'E11':['outputs/model_assets_recovery_20261004/Qwen3.5-2B-derived-text/config.json','research/diagnostics/text_only_asset_projection/RESULTS.md']}
def receipt(p):
 b=(R/p).read_bytes()
 return {'repository_relative_path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
manifest={'document_status':'new_prospective_scaffold_not_experimental_result', 'snapshot_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'recovered_base_commit':'ecc1c87aaf0e609302f6b08023096078345f6f7a','scope':'Read surviving reports and metadata; did not rerun their scientific experiments. Hashes establish file identity, not execution or historical ordering.','sources':{k:[receipt(p) for p in ps] for k,ps in sources.items()},'primary_web_sources':[{'id':'P01','title':'NVIDIA GeForce RTX 5090 official product specifications','url':'https://www.nvidia.com/en-gb/geforce/graphics-cards/50-series/rtx-5090/','checked_date_utc':'2026-10-04','claim':'Standard memory configuration 32 GB GDDR7','scope':'No actual device availability, free memory, price or kernel compatibility verified.'}]}
(O/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
c=json.loads((R/sources['E11'][0]).read_text())['text_config']
nr=c['layer_types'].count('linear_attention');na=c['layer_types'].count('full_attention')
s=nr*c['linear_num_value_heads']*c['linear_key_head_dim']*c['linear_value_head_dim']
convch=2*c['linear_num_key_heads']*c['linear_key_head_dim']+c['linear_num_value_heads']*c['linear_value_head_dim']
kvcoeff=2*na*c['num_key_value_heads']*c['head_dim']
counts={'status':'analytical_counts_only_no_tensor_allocation_or_model_forward','config_receipt':receipt(sources['E11'][0]),'unique_text_parameters_from_retained_E05':1881825088,'full_fp32_parameter_payload_bytes':1881825088*4,'mixed_source_file_bytes_from_retained_E07':3763696896,'cpu_cast_arena_bytes_from_retained_E07':2034237440,'recurrent_layers':nr,'full_attention_layers':na,'recurrent_scalar_coordinates':s,'fp32_recurrent_endpoint_bytes':s*4,'fp32_dense_T_and_U_bytes':s*8,'fp32_four_position_conv_bytes':nr*convch*c['linear_conv_kernel_dim']*4,'fp32_three_position_minimum_conv_bytes':nr*convch*(c['linear_conv_kernel_dim']-1)*4,'fp32_attention_kv_bytes_per_token':kvcoeff*4,'bf16_attention_kv_bytes_per_token':kvcoeff*2,'fp32_attention_kv_bytes_at_32768_tokens':kvcoeff*4*32768,'bf16_attention_kv_bytes_at_32768_tokens':kvcoeff*2*32768,'fp32_dense_recurrent_to_recurrent_response_bytes':4*s*s,'fp32_two_dense_rank8_factor_bytes':4*8*(s+s),'fp32_explicit_single_layer_attention_scores_at_32768_tokens_bytes':c['num_attention_heads']*32768**2*4,'notes':['GB is decimal; GiB/MiB/KiB are binary. NVIDIA product memory label is quoted as GB without converting usable capacity.','KV assumes one request, no padding, no tensor duplication and one K and V per full-attention layer.','Conv estimate assumes four stored raw projection positions; actual runtime layout must be inventoried.','Dense response estimates concern all recurrent coordinates; a smaller structured operator needs its own actual dimensions.','Attention-score estimate assumes explicitly materialized [batch=1, heads=8, L, L] FP32 scores. A memory-efficient kernel may avoid it; not a measured runtime allocation.','Counts exclude activations, workspace, allocator reserve, metadata, source population, serving concurrency and staging buffers.']}
assert s*4==18*2**20
assert kvcoeff*4*32768==768*2**20
assert 4*s*s==81*2**40
assert c['num_attention_heads']*32768**2*4==32*2**30
(O/'analytical_counts.json').write_text(json.dumps(counts,indent=2)+'\n')
print(json.dumps({'source_files':sum(map(len,sources.values())),'analytical_assertions_passed':4,'model_imports':0,'model_forwards':0}))
