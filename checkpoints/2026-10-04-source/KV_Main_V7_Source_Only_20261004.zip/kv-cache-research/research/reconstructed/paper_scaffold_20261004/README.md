# Deployment and paper evidence scaffold

New prospective documentation, 2026-10-04 UTC. No result recovery or new scientific result is claimed. The next scientific action remains the bounded reconstructed first24, conditional on verified assets and its own release. This package does not authorize any execution.

## Read first

- `实验决策说明.md`: Chinese decision note covering preparation, small tests, conditional diagnostics, formal evaluation, deployment and publication boundaries
- `paper.tex`: editable English LaTeX scaffold, with every empirical result sourced or visibly TODO
- `paper.pdf`: compiled five-page reading copy, visually checked on all pages
- `claim_evidence_matrix.md`: 14 currently supportable scoped claims and 13 missing-evidence claims
- `deployment_contract.json`: proposed interfaces, source ancestry, lifetime/fallback rules, native profiling fields and complete cost accounting; this is a design specification, not implemented server code
- `source_manifest.json`: identity receipts for 28 surviving source/report/config/raw-result files plus one newly checked NVIDIA primary page
- `analytical_counts.json`: explicitly analytical one-request payload and workspace estimates, derived without model imports or tensor allocation

The important practical boundary is that weights and KV fitting on one card do not establish long-context fit. For the verified config, a hypothetical explicitly materialized eight-head FP32 32K-by-32K attention score tensor alone is 32 GiB. This is a conditional allocation calculation, not a measured kernel peak. Likewise, stored correction factors and source traces must be counted, not silently moved outside the cost model.

## Evidence discipline

Released HYPIC, the suffix-corrected intended-semantics CPU reference, and any future deployable correction are separate identities. Surviving v1/v2/v3 failures remain failures. Historical late FP32/full24 tiny proof was lost; new tiny checks are not pretrained quality evidence. The model-recovery failure is a point-in-time 403 record; verified metadata is not verified weights. No dummy result points or novelty claims are included.

Literature mechanisms and source pins are taken from the already existing source audits with their 2026-10-03 cutoff. This package did not repeat a literature survey. The only concrete new web check was NVIDIA's official standard RTX 5090 memory specification. No actual GPU, price, availability or compatibility was checked.

## Compilation and checks

The PDF was compiled with the existing pdfTeX/LaTeX files only, shell escape disabled. The initial compiler command could not find its prebuilt format; its normal font-map/database registration was also absent. A local format and font map were generated from existing TeX files under `qa/`, with no installation or download. Early failed attempts and final logs remain there.

For an ordinary complete TeX installation, run `pdflatex -no-shell-escape -halt-on-error paper.tex` twice. For this workspace's existing but unregistered TeX tree, `build_pdf.sh` recreates the local format/map and compiles twice. It does not install packages or contact a network. PNGs and intermediate compiler files under `qa/` are QA materials, not paper figures or scientific results.

`build_specification.py` uses only the standard library to snapshot source identities and calculate analytical byte counts. Re-running it refreshes the receipt timestamp, so preserve the original receipt if historical document provenance matters.

See `validation.json` for the final checks and `deliverable_hashes.json` for output identities. Five rendered final PDF pages were inspected for clipping, overlap, missing glyphs, broken tables and sparse accidental pages. The final compiler log has no overfull/underfull box or undefined-reference warning.

## Scope of this work

Only this new documentation directory was created/edited. No recovered tracked files were changed. No package installation, model import/load/forward, model download, GPU action, publication, deletion or spending was performed. The JSON interface and formal-experiment section deliberately retain TODOs for the actual method, observer, datasets, statistical sample size and native serving implementation.
