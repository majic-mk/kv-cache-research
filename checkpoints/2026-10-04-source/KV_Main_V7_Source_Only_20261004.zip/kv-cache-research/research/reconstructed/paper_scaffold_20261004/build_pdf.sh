#!/usr/bin/env bash
# Compile with existing system TeX resources only; no installs or network.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p qa
export TEXMF="{/usr/share/texmf,/usr/share/texlive/texmf-dist}"
if [[ ! -f qa/pdflatex.fmt ]]; then
  (cd qa && pdftex -ini -etex -no-shell-escape -halt-on-error \
    -interaction=nonstopmode -jobname=pdflatex -progname=pdflatex \
    pdflatex.ini > format_build.stdout.log 2>&1)
fi
cat /usr/share/texmf/fonts/map/dvips/lm/lm.map \
  /usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts/{cm,cmextra,euler,latxfont}.map \
  > qa/pdftex.map
export TEXFONTMAPS="$PWD/qa:/usr/share/texmf/fonts/map//:/usr/share/texlive/texmf-dist/fonts/map//"
for pass in 1 2; do
  pdflatex -fmt=qa/pdflatex.fmt -no-shell-escape -halt-on-error \
    -interaction=nonstopmode -output-directory=qa paper.tex \
    > "qa/rebuild_pass${pass}.stdout.log" 2>&1
done
cp qa/paper.pdf paper.pdf
pdfinfo paper.pdf > qa/rebuild_pdfinfo.txt
printf 'Compiled paper.pdf; re-render and inspect if the source changed.\n'
