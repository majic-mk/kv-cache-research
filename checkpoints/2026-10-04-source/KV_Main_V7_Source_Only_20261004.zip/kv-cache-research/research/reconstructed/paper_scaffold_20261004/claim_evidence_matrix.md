# Claim and evidence matrix

Date: 2026-10-04 UTC. This is a writing and experiment decision aid. “Retained evidence” means the listed surviving source/report was read for this scaffold; it does not mean that this worker reran its experiment. Hashes snapshot the files read and establish identity, not historical ordering or truth. See `source_manifest.json` for exact paths, byte sizes and SHA-256 values.

## Claims that can be made now

| ID | Permitted claim | Evidence and level | Boundary that must travel with the claim |
|---|---|---|---|
| C01 | Pinned HYPIC ordinary cold/hit recompute code has the audited full-tuple plus fresh-seam contract defect | E01; source/control-flow audit and retained exact witness | About revision 98147c01909004e66d98bcb18b886927d41b0ee5, not every release, current upstream status, numerical GPU magnitude, or paper result |
| C02 | The audited ordinary HYPIC warmup is contextual | E01; source tracing of GDN and full attention | Not a statement about every distributed path or every cache-generation policy |
| C03 | A suffix-only intended-semantics CPU reference is distinct from released HYPIC | E01/E06; explicit reference definition | Do not label it author-runtime reproduction or use source-defect correction as method novelty |
| C04 | v1 failed token-boundary integrity before model execution | E03; surviving report and v1 ledger | 16/16 unrun; not model incompetence |
| C05 | v2 0.8B/FP32 stopped on its first full-recompute wrong answer | E04; report/ledger | 1/16 completed; no exact-prefix/reuse result; not general model quality |
| C06 | v3 2B/BF16 failed frozen numerical parity despite equal correct answers | E05; report/ledger and separately retained logits | 2/16 completed; scheduling versus implementation cause unisolated; not general BF16 failure |
| C07 | Current reconstructed tiny tests support only their engineering scope | E07; retained tiny/guard/summary | Newly reconstructed evidence, not late lost FP32 proof, pretrained parity, model benefit, or serving speed |
| C08 | Current weight restoration is unverified following a 403 failure | E08; FAILED.json at 07:23:53Z and metadata report at 07:22:26Z | Point-in-time status; metadata verification does not authorize loading a partial weight file |
| C09 | A/C mechanisms were closed by simple controls; B lacked storage advantage over its common-mask comparator | E02; retained bounded CPU review | No natural quality or universal dominance claim; distinct screens, not new main method |
| C10 | The next protocol is a new prospective 24-cell reconstruction with fixed stop gates | E06 | Not a recovered freeze or automatic execution authorization; current R schedule differs from historical v3 |
| C11 | Generic low-rank/input-response/cache-delta correction has close prior overlap | E09; primary papers and code pins recorded there | Targeted review cutoff 2026-10-03; not exhaustive search or exact-disjointness/firstness proof |
| C12 | Recurrent state/tails/finite seam are not universally sufficient for arbitrary hybrid-prefix forcing | E09; constructed collision argument | Theoretical witness, not an observed natural-token Qwen collision or proof that additional observations fail |
| C13 | Standard RTX 5090 is listed with 32 GB GDDR7 | P01; NVIDIA official product page checked 2026-10-04 | No actual hardware availability, variant identity, price, usable free memory or kernel support inferred |
| C14 | Listed parameter/cache/factor byte counts follow declared config and arithmetic | E05/E07/E11 plus analytical_counts.json | Payload estimates, not measured RSS, device peak, supported context length or achieved throughput |

## Claims still requiring evidence

| ID | Desired claim | Minimum missing evidence | Strong control or rejection condition | Status |
|---|---|---|---|---|
| T01 | Contextual reuse harms an otherwise competent model on the fixed screen | Verified weights; all 16 R/F32 controls; A1 self-reuse; both A2 groups pass frozen losses; raw logits/cache/ancestry/masks | Stop on first competence/parity/integrity/resource failure; answer errors separate from confidence shifts | TODO |
| T02 | Recurrent correction addresses an answer-relevant causal route | Complete Dall/D20/DR/DKC diagnostic; exact-target donor identity; Dall recovery; channel-wise outcomes | Recurrent rescue does not prove exclusively recurrent origin; donors are not deployable inputs | TODO |
| T03 | Online observer is informative enough | Explicit g(A), read sets and acquisition cost; collision/near-collision analysis; held-out prediction at actual displacement | Hidden target whole-B forward or insufficient observation kills cheap arbitrary-prefix claim | TODO |
| T04 | A proposed mechanism is substantively distinct | Exact mechanism statement and targeted comparison to HYPIC, ICC, KVCOMM, Kamera, KVCMAS and relevant later work before submission | Source fix, changed architecture, generic Jacobian or low-rank endpoint alone is insufficient | TODO |
| T05 | Correction improves quality | Paired held-out answers/scores from a frozen method and evaluator; independent contexts and intervals | No post-outcome case/model/width/rank/threshold selection; compare cheap wider seams | TODO |
| T06 | Correction is cheaper at matched quality | Native implemented path; complete build/hit/miss/fallback costs; matched quality tolerance | No positive per-hit saving or domination by wider seam rejects amortized-speedup claim | TODO |
| T07 | Offline work amortizes in the intended workload | Observed source lifetimes, realized valid hits, misses, eviction/refresh and unused builds | Hypothetical R curves cannot stand in for observed reuse | TODO |
| T08 | System reduces actual physical memory | Unique backing allocation and serializer inventory; active clone/materialization/workspace peaks across tiers | Logical masks/tokens or factor-only storage cannot support total saving | TODO |
| T09 | System runs usefully on one 5090 | Exact device/driver/kernel/dtype record, synchronized profiles, VRAM/HWM, quality controls, realistic pool and concurrency | Weights fitting alone is insufficient; long eager attention or pool/factor memory can defeat fit | TODO |
| T10 | Released HYPIC is outperformed | Compatible pinned author runtime, original settings and tokens, independently qualified reproduction, same costs/quality workload | Corrected CPU port alone cannot substantiate this comparison | TODO |
| T11 | Method generalizes beyond constructed cases | Frozen natural tasks and licenses, multiple template/source families, independent test clusters, justified sample size | Two development groups or h01/h05 same-family slots do not establish broad generalization | TODO |
| T12 | System is deployable | Actual interface implementation, immutable artifact lifetime, miss/invalidation, cancellation, concurrency, safe fallback, native profiling | Current sequential CPU cast engine and call-spy/tiny checks are insufficient | TODO |
| T13 | Paper is appropriate for a target journal tier | Completed evidence, scoped contribution, current venue fit and peer review | No guarantee of acceptance or SCI quartile from a plan | TODO |

## Exact result language

Allowed now: “We specify a prospective, cost-accounted evaluation of a suffix-corrected HYPIC-inspired reference. Existing records establish source-contract findings and bounded unsuccessful qualification attempts; method utility remains unestablished.”

Not allowed now: “Our method repairs HYPIC,” “we achieve X-times speedup,” “single-5090 deployment is feasible,” “the first recurrent response correction,” “negligible offline cost,” “lossless cache reuse,” or any benchmark number absent a corresponding executed, qualified result.

Do not create result-shaped dummy rows or plots. Missing values stay null with a reason in future records; TODO text stays visibly prospective in this scaffold. Build hashes and file presence are integrity checks, not a scientific pass.
