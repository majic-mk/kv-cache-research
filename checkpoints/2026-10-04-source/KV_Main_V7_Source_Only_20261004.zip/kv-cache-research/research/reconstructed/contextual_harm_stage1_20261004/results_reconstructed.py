"""NEW reconstructed scalar evidence contract, not recovered native results."""
import math
import contract_reconstructed as c
from scoring_reconstructed import normalized_correct,finite


def initial_records():
    return [dict(**{k:p[k] for k in ('cell_id','pair_id','variant','arm')},status='not_run_reconstructed_hold',
        reason='Native implementation/evidence and execution release absent',measurements=None) for p in c.plan()]


def validate_completed(cell,r):
    if any(r.get(k)!=cell[k] for k in ('cell_id','pair_id','variant','arm')) or r.get('status')!='completed':raise ValueError('Wrong active identity/status')
    candidates=cell['candidates'];scores=r.get('candidate_scores',{});per=r.get('candidate_per_token_logprobs',{})
    if list(scores)!=list(candidates) or list(per)!=list(candidates):raise ValueError('Candidate order/coverage')
    for answer,ids in candidates.items():
        if len(per[answer])!=len(ids) or any(not finite(x) or x>0 for x in per[answer]) or not finite(scores[answer]) or scores[answer]>0:raise ValueError('Invalid candidate values')
        if abs(math.fsum(per[answer])-scores[answer])>1e-5*max(1,abs(scores[answer])):raise ValueError('Sum incoherent with per-token values')
    gold=cell['expected_answer'];other=next(x for x in candidates if x!=gold)
    if r.get('gold_logprob')!=scores[gold] or not finite(r.get('gold_margin')) or abs(r['gold_margin']-(scores[gold]-scores[other]))>1e-5*max(1,abs(r['gold_margin'])):raise ValueError('Gold/margin invalid')
    ids=r.get('raw_greedy_ids');ended=r.get('eos_within_cap')
    if not isinstance(ids,list) or not 1<=len(ids)<=8 or any(type(x)!=int or not 0<=x<c.VOCAB for x in ids):raise ValueError('Invalid greedy IDs')
    if c.EOS in ids[:-1] or ended is not (ids[-1]==c.EOS) or (not ended and len(ids)!=8):raise ValueError('EOS stop invalid')
    if not isinstance(r.get('decoded_answer'),str) or r.get('normalized_answer_correct') is not normalized_correct(r['decoded_answer'],gold,ended):raise ValueError('Parser result invalid')
    if r.get('strict_gold_token_equality') is not (ids==candidates[gold]):raise ValueError('Token equality invalid')
    if r.get('native_checks_passed') is not True:raise ValueError('Native controls must be explicitly supplied')
    return True


class StageState:
    def __init__(self):self.plan=c.plan();self.records=initial_records();self.next_index=0;self.first_failure=None;self.status='RECONSTRUCTED_HOLD'
    def stop(self,kind,cell_id,detail):
        if self.first_failure:return self.status
        self.first_failure=dict(cell_id=cell_id,kind=kind,detail=detail);self.status='STOP_'+kind.upper()
        index=next(i for i,r in enumerate(self.records) if r['cell_id']==cell_id)
        self.records[index].update(status='failed_'+kind,first_failure=self.first_failure)
        for r in self.records[index+1:]:r.update(status='not_run_gate',first_failure=self.first_failure)
        return self.status
    def accept(self,record):
        if self.first_failure or self.next_index>=24:raise ValueError('Stage stopped/complete')
        index=self.next_index;cell=self.plan[index]
        try:validate_completed(cell,record)
        except (TypeError,KeyError,ValueError) as exc:
            self.records[index]['attempted_record_repr']=repr(record)
            return self.stop('integrity',cell['cell_id'],str(exc))
        self.records[index]=dict(record);self.next_index+=1
        if cell['arm']=='R' and not record['normalized_answer_correct']:return self.stop('competence',cell['cell_id'],'First wrong R or missing EOS')
        if cell['arm']=='F32' or (cell['arm']=='Hctx32' and cell['variant']=='A1'):
            ref=next(r for r in self.records if r['cell_id']==cell['reference_cell']);limits=c.numerical_limits()
            ok=all(abs(record['candidate_scores'][a]-ref['candidate_scores'][a])<limits['candidate_sum_logprob_delta_abs_strictly_below'] for a in cell['candidates'])
            ok &= abs(record['gold_margin']-ref['gold_margin'])<limits['candidate_margin_delta_abs_strictly_below']
            ok &= record['raw_greedy_ids']==ref['raw_greedy_ids'] and record['eos_within_cap']==ref['eos_within_cap']
            if not ok:return self.stop('numerical',cell['cell_id'],'Final scalar/ID control; backend must also fail before dependent calls')
        self.status='RUNNING'
        if self.next_index==24:self.status=self.assess_harm()['status']
        return self.status
    def assess_harm(self):
        if self.next_index!=24 or self.first_failure:raise ValueError('No partial or selected-group harm decision')
        idx={(r['pair_id'],r['variant'],r['arm']):r for r in self.records};statistics=('gold_logprob','gold_margin')
        noise={s:max(abs(idx[g,v,'F32'][s]-idx[g,v,'R'][s]) for g in c.GROUPS for v in c.VARIANTS) for s in statistics}
        threshold={s:max(.1,10*noise[s]) for s in statistics};groups=[]
        for g in c.GROUPS:
            losses={s:idx[g,'A2','F32'][s]-idx[g,'A2','Hctx32'][s] for s in statistics}
            groups.append(dict(pair_id=g,losses=losses,qualifying=all(losses[s]>=threshold[s] for s in statistics),
                observed_answer_harm=idx[g,'A2','F32']['normalized_answer_correct'] and not idx[g,'A2','Hctx32']['normalized_answer_correct']))
        return dict(status='PASS_STAGE1_COMPETENCE_AND_CONTEXTUAL_HARM_ONLY' if all(r['qualifying'] for r in groups) else 'STOP_NO_QUALIFYING_HARM',
            noise=noise,threshold=threshold,groups=groups,continuation_authorized=False,method_benefit_established=False,
            interpretation='Confidence harm alone is not answer-accuracy loss or method benefit')
