"""NEW compact tiny-test costs: exact logical counts; no per-ATen trace claim."""
import collections,json
import contract_reconstructed as c

class TinyCostSummary:
    def __init__(self,journal):
        self.journal=journal;self.operations={};self.leases={};self.active={};self.first_sink_failure=None;self.secondary_failures=[]
        self.rows_seen=0;self.root_started=0;self.root_invoked=0;self.root_returned=0;self.root_tokens=0
    def _append(self,row):
        if self.first_sink_failure is not None:return
        try:self.journal.append(row)
        except BaseException as exc:
            self.first_sink_failure={'type':type(exc).__name__,'message':str(exc)};raise
    def emit(self,row):
        self.rows_seen+=1
        if row.get('kind')=='arena':
            label=row['label'];r=self.leases.setdefault(label,dict(acquires=0,releases=0,cast_bytes=0,lease_wall_seconds=0.))
            if row['event']=='acquire':
                if row['lease_id'] in self.active:raise ValueError('Duplicate lease acquisition')
                r['acquires']+=1;r['cast_bytes']+=row['cast_bytes'];self.active[row['lease_id']]=(label,row['monotonic'])
            elif row['event']=='release':
                if row['lease_id'] not in self.active:raise ValueError('Release without observed acquisition')
                name,start=self.active.pop(row['lease_id'])
                if name!=label:raise ValueError('Lease label changed')
                r['releases']+=1;r['lease_wall_seconds']+=row['monotonic']-start
            else:raise ValueError('Unknown arena event')
        elif row.get('event')=='contextual_operator':
            key=row['operator']+':'+str(row.get('layer','all'))
            r=self.operations.setdefault(key,dict(calls=0,failures=0,wall_ns=0,process_cpu_ns=0,explicit_bytes=0))
            r['calls']+=1;r['failures']+=not row['successful'];r['wall_ns']+=row['wall_ns'];r['process_cpu_ns']+=row['process_cpu_ns'];r['explicit_bytes']+=row.get('bytes',0)
        elif row.get('kind')=='root_call':
            if row['status']=='started':
                if row['model_invoked']:
                    self.root_invoked+=1
                    self._append({'kind':'root_invoked','call_id':row['call_id']})
                else:
                    self.root_started+=1;self.root_tokens+=len(row['input_ids'])
                    self._append({k:row[k] for k in ('kind','call_id','purpose','history_ids','input_ids','absolute_start','status','model_invoked','model_returned')})
            else:
                self.root_returned+=row['model_returned']
                compact={k:v for k,v in row.items() if k!='cache_descriptor'}
                if 'cache_descriptor' in row:compact['complete_cache_descriptor_sha256']=c.digest(row['cache_descriptor'])
                self._append(compact)
        else:self._append(row)
    def summary(self):
        return dict(rows_seen=self.rows_seen,operations=self.operations,arena_by_operation=self.leases,
            unmatched_active_leases=len(self.active),root_started=self.root_started,root_invoked=self.root_invoked,root_returned=self.root_returned,attempted_network_tokens=self.root_tokens,
            first_sink_failure=self.first_sink_failure,coverage='Exact logical arena event/count/cast-byte totals and source-operator inclusive timing aggregates; bounded per-call provenance/mask summaries; no full ATen census or physical-memory-traffic claim',
            timing='Root, arena and source timings overlap; do not sum nested durations. Outer process CPU/wall/RSS includes all setup/check/hash/I/O work.')
