"""NEW reconstruction, 2026-10-04; neither exact recovery nor numerical evidence.

Capture the actual, already-required A1-conditioned whole-B invocation. Never
forward isolated B, reproject hidden states, repair the conv boundary, or load a
model. The caller owns all native calls, ancestry registration and artifact I/O.

Backend protocol: torch, hf, engine; installed_context() (engine execution or a
null context when already inside it); cost_event(dict); cache_of(owner_or_cache);
history_of(owner_or_cache); checked_forward(ids, parent, branch, purpose). The
last returns an owned native result; history_of must check live native ancestry.
The backend binds a complete canonical current cell and provides
active_capture_identity(incoming_cache) only inside its actual native invocation,
and completed_capture_identity(owner_or_cache) only for that registered output.
build() returns (native_cache, trace); caller MUST register its derived A+B
history before using it. No native cache length is treated as ancestry proof.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from functools import wraps
import copy
import inspect
import hashlib
import json
import time
import weakref
import contract_reconstructed as contract

LABEL = 'NEW_RECONSTRUCTION_NOT_EXACT_RECOVERY'
WIDTH = 32


def _tokens(values):
    values = tuple(values)
    if not values or any(type(x) is not int or x < 0 for x in values):
        raise ValueError('Expected nonempty exact token IDs')
    return values


def _tensor_spec(tensor):
    return dict(shape=list(tensor.shape), dtype=str(tensor.dtype), device=str(tensor.device),
                stride=list(tensor.stride()))


def _native_cache(backend, value):
    return backend.cache_of(value)


def _check_fp32(torch, tensor, name):
    if not isinstance(tensor, torch.Tensor) or tensor.dtype != torch.float32 or tensor.device.type != 'cpu':
        raise ValueError(name + ' must be CPU FP32')


class _Costs:
    def __init__(self, backend):
        self.backend = backend
        if not callable(getattr(backend, 'cost_event', None)):
            raise TypeError('A real cost_event sink is required')

    @contextmanager
    def time(self, operator, **metadata):
        start, cpu = time.perf_counter_ns(), time.process_time_ns()
        successful = False
        try:
            yield
            successful = True
        finally:
            self.backend.cost_event(dict(event='contextual_operator', operator=operator,
                wall_ns=time.perf_counter_ns()-start, process_cpu_ns=time.process_time_ns()-cpu,
                successful=successful, reconstruction=LABEL, **metadata))

    def copy(self, tensor, name):
        _check_fp32(self.backend.torch, tensor, name)
        with self.time('tensor_clone', tensor_name=name, bytes=tensor.numel()*tensor.element_size()):
            return tensor.detach().clone(memory_format=self.backend.torch.contiguous_format)

    def snapshot(self, cache, name):
        with self.time('complete_cache_hash', cache_name=name):
            return self.backend.evidence.cache_snapshot(cache, self.backend.torch)[0]

    def clone_cache(self, cache, name):
        with self.time('complete_cache_clone_and_verify', cache_name=name):
            return self.backend.evidence.clone_cache_checked(cache, self.backend.torch)

    def digest(self, tensor, name):
        with self.time('source_tensor_hash', tensor_name=name,
                       bytes=tensor.numel()*tensor.element_size()):
            return self.backend.support.tensor_digest(tensor.contiguous())


class _Patches:
    def __init__(self):
        self.entries = []

    def set(self, owner, name, value):
        owned, old = name in vars(owner), getattr(owner, name)
        self.entries.append((owner, name, owned, old))
        setattr(owner, name, value)

    def restore(self):
        for owner, name, owned, old in reversed(self.entries):
            if owned:
                setattr(owner, name, old)
            else:
                delattr(owner, name)
        self.entries.clear()


def _bind(callable_, args, kwargs):
    bound = inspect.signature(callable_).bind(*args, **kwargs)
    bound.apply_defaults()
    return bound.arguments


def _validate_cache(cache, model, history):
    """Admit exactly the pinned native dynamic hybrid schema; reject other modes."""
    if type(cache).__name__ != 'DynamicCache' or type(cache).__module__ != 'transformers.cache_utils':
        raise ValueError('Only the pinned native DynamicCache is supported')
    if len(cache.layers) != len(model.model.layers) or cache.get_seq_length() != len(history):
        raise ValueError('Complete native cache extent differs from declared token history')
    for block, layer in zip(model.model.layers, cache.layers):
        expected = 'LinearAttentionLayer' if hasattr(block, 'linear_attn') else 'DynamicLayer'
        if type(layer).__name__ != expected or type(layer).__module__ != 'transformers.cache_utils':
            raise ValueError('Unsupported hybrid cache layer schema')
        if expected == 'LinearAttentionLayer':
            if layer.record_past or layer.number_of_states != 1:
                raise ValueError('Recording/multiple-state cache modes are not reconstructed')
            for name in ('conv_states', 'recurrent_states', 'has_previous_state',
                         'is_conv_states_initialized', 'is_recurrent_states_initialized'):
                values = getattr(layer, name)
                if set(values) != {0} or values[0] is None or values[0] is False:
                    raise ValueError('Incomplete native recurrent cache: ' + name)
        elif layer.keys.shape[-2] != len(history) or layer.values.shape[-2] != len(history):
            raise ValueError('A full-attention layer has incomplete history')


@dataclass
class AffineSuffix:
    width: int
    tokens: int
    layers: dict
    manifest: dict


@dataclass(frozen=True)
class SourceBinding:
    model_ref: object
    engine_ref: object
    fingerprint: str


def _engine_binding(model, backend, costs):
    engine = backend.engine
    if (engine.model is not model or engine.hf is not backend.hf
            or not engine._installed
            or getattr(backend.hf, '_reconstructed_paged_fp32_owner', None) is not engine):
        raise ValueError('Source requires this live installed model/engine/helper owner')
    with costs.time('verify_source_model_storage_and_provenance'):
        engine.verify_integrity()
        def digest(value):
            return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        identity = dict(model_identity=id(model), engine_identity=id(engine),
            hf_identity=id(backend.hf), synthetic=bool(engine.synthetic),
            source_path=None if engine.source_path is None else str(engine.source_path),
            source_audit_sha256=digest(engine._source_audit),
            storage_identity_sha256=digest(engine._snapshot()),
            binding_scope='live_identity_storage_and_installed_engine_source_audit_not_new_weight_byte_scan')
        return identity, digest(identity)


def _verify_binding(source, model, backend, costs):
    _verify_source_provenance(source)
    if source.binding.model_ref() is not model or source.binding.engine_ref() is not backend.engine:
        raise ValueError('Contextual source belongs to a different or expired live model/engine')
    _, fingerprint = _engine_binding(model, backend, costs)
    if fingerprint != source.binding.fingerprint:
        raise ValueError('Contextual source model storage or engine provenance changed')


@dataclass
class ContextualSource:
    A: tuple
    B: tuple
    incoming_cache: object
    cache: object
    layers: dict
    traces: dict
    manifest: dict
    binding: SourceBinding
    provenance: dict
    suffix: AffineSuffix | None = None


def _verify_source_provenance(source, target_cell=None):
    """Check frozen external producer identity before touching target state."""
    provenance = (contract.validate_source_provenance(source.A, source.B, source.provenance)
        if target_cell is None else
        contract.validate_hctx_source(target_cell, source.A, source.B, source.provenance))
    if not contract._exact_value(source.manifest.get('capture_provenance'), provenance):
        raise ValueError('Contextual manifest capture provenance changed')
    if (not contract._exact_value(source.manifest.get('A_ids'), list(source.A))
            or not contract._exact_value(source.manifest.get('B_ids'), list(source.B))
            or not contract._exact_value(source.manifest.get('history_ids'), list(source.A+source.B))):
        raise ValueError('Contextual source manifest history differs from frozen producer')
    return provenance


class ContextualCapture:
    """with capture: existing_whole_B_call(); source = capture.finish(result).

    All wrappers call the exact original operation once and restore on failure.
    No hooks or source weight casts are added. The engine must already be
    installed; checked_forward is responsible for entering its execution context.
    """
    def __init__(self, model, backend, A, B, *, trace_layers=(19, 20)):
        self.model, self.backend = model, backend
        self.A, self.B = _tokens(A), _tokens(B)
        self.provenance = contract.source_provenance(backend.current)
        contract.validate_source_provenance(self.A, self.B, self.provenance)
        if not all(callable(getattr(backend, name, None)) for name in
                   ('active_capture_identity', 'completed_capture_identity')):
            raise TypeError('Actual native capture identity hooks are required')
        self.observed_provenance = None
        if len(self.B) <= WIDTH:
            raise ValueError('Hctx32 source requires a nonempty suffix after token 32')
        self.costs, self.patches = _Costs(backend), _Patches()
        self.layers, self.traces = {}, {}
        self.trace_layers = tuple(i for i in trace_layers if i < len(model.model.layers))
        self.active_layer = None
        self.incoming = self.returned = None
        self.calls = 0
        self.finished = self.entered = self.context_success = False
        self.expected = {i for i, block in enumerate(model.model.layers) if hasattr(block, 'linear_attn')}

    def _root(self, original):
        @wraps(original)
        def wrapped(*args, **kwargs):
            if self.calls:
                raise ValueError('Contextual capture permits exactly one whole-B call')
            bound = _bind(original, args, kwargs)
            ids, cache = bound.get('input_ids'), bound.get('past_key_values')
            if ids is None or ids.tolist() != [list(self.B)] or cache is None:
                raise ValueError('Capture requires actual whole B and an incoming A cache')
            if tuple(self.backend.history_of(cache)) != self.A:
                raise ValueError('Actual incoming source cache ancestry is not A1')
            identity = self.backend.active_capture_identity(cache)
            contract.validate_source_provenance(self.A, self.B, identity)
            if not contract._exact_value(identity, self.provenance):
                raise ValueError('Actual source invocation differs from captured frozen cell/call')
            self.observed_provenance = copy.deepcopy(identity)
            _validate_cache(cache, self.model, self.A)
            self.calls += 1
            self.incoming = self.costs.clone_cache(cache, 'source_incoming_A1')
            output = original(*args, **kwargs)
            self.returned = output.past_key_values
            return output
        return wrapped

    def _linear(self, index, original):
        @wraps(original)
        def wrapped(*args, **kwargs):
            if self.active_layer is not None or index in self.layers:
                raise ValueError('Reentrant/duplicate source recurrent layer')
            self.active_layer = index
            self.layers[index] = {}
            try:
                return original(*args, **kwargs)
            finally:
                self.active_layer = None
        return wrapped

    def _projection(self, index, module, original):
        @wraps(original)
        def wrapped(*args, **kwargs):
            raw = original(*args, **kwargs)
            if self.active_layer != index or raw.shape[:2] != (1, len(self.B)):
                raise ValueError('Raw projected source trace is not the complete B call')
            # Compact source raw halos; no second learned projection is performed.
            width = module.conv_kernel_size
            slices = {'raw_prefix': (0, min(width, len(self.B))),
                      'raw_seam_halo': (max(0, WIDTH-width+1), WIDTH),
                      'raw_tail': (max(0, len(self.B)-width), len(self.B))}
            for name, (start, stop) in slices.items():
                self.layers[index][name] = self.costs.copy(raw[:, start:stop].transpose(1, 2), f'{index}.{name}')
            self.layers[index]['raw_halo_ranges'] = slices
            return raw
        return wrapped

    def _recurrence(self, original):
        @wraps(original)
        def wrapped(*args, **kwargs):
            index = self.active_layer
            if index is None:
                raise ValueError('Unattributed recurrence inside source capture')
            values = _bind(original, args, kwargs)
            module = self.model.model.layers[index].linear_attn
            if values.get('use_qk_l2norm_in_kernel') is not True:
                raise ValueError('Source does not use native Q/K L2 normalization')
            record = self.layers[index]
            if 'k' in record:
                raise ValueError('Duplicate source factors')
            groups = module.num_v_heads // module.num_k_heads
            if groups < 1 or module.num_v_heads % module.num_k_heads:
                raise ValueError('Unsupported grouped-head dimensions')
            for dst, src in (('q','query'), ('k','key'), ('v','value'), ('g','g'), ('beta','beta')):
                tensor = values[src]
                if tensor.shape[:2] != (1, len(self.B)):
                    raise ValueError('Recurrence source is not whole B')
                if dst in ('q', 'k'):
                    if tensor.shape[2] != module.num_v_heads:
                        raise ValueError('Native recurrence grouped-head expansion missing')
                    compact = tensor[:, :, ::groups]
                    with self.costs.time('verify_grouped_head_identity', layer=index, factor=dst):
                        for group in range(groups):
                            if not self.backend.torch.equal(compact, tensor[:, :, group::groups]):
                                raise ValueError('Nonidentical expanded key/query heads')
                    tensor = compact
                record[dst] = self.costs.copy(tensor, f'{index}.{dst}')
            record.update(groups=groups, key_heads=module.num_k_heads,
                          value_heads=module.num_v_heads, l2_eps=1e-6,
                          query_scale=module.head_k_dim**-0.5,
                          recurrence_helper=getattr(original, '__name__', type(original).__name__))
            return original(*args, **kwargs)
        return wrapped

    def _trace(self, index, original):
        @wraps(original)
        def wrapped(*args, **kwargs):
            bound = _bind(original, args, kwargs)
            before = self.costs.copy(bound['hidden_states'], f'block{index}.input')
            output = original(*args, **kwargs)
            after = output[0] if isinstance(output, (tuple, list)) else output
            self.traces[index] = dict(input=before, output=self.costs.copy(after, f'block{index}.output'))
            return output
        return wrapped

    def __enter__(self):
        if not contract._exact_value(contract.source_provenance(self.backend.current), self.provenance):
            raise ValueError('Bound source cell changed before capture')
        if self.backend.engine.model is not self.model or self.backend.engine.hf is not self.backend.hf:
            raise RuntimeError('Capture engine/model/helper identity mismatch')
        if self.entered or not getattr(self.backend.engine, '_installed', False):
            raise RuntimeError('Capture is single-use and requires the installed FP32 engine')
        self.entered = True
        try:
            self.patches.set(self.model, 'forward', self._root(self.model.forward))
            for index, block in enumerate(self.model.model.layers):
                if index in self.expected:
                    module = block.linear_attn
                    self.patches.set(module, 'forward', self._linear(index, module.forward))
                    projection = module.in_proj_qkv
                    self.patches.set(projection, 'forward', self._projection(index, module, projection.forward))
                if index in self.trace_layers:
                    self.patches.set(block, 'forward', self._trace(index, block.forward))
            for name in ('torch_chunk_gated_delta_rule', 'torch_recurrent_gated_delta_rule'):
                self.patches.set(self.backend.hf, name, self._recurrence(getattr(self.backend.hf, name)))
        except BaseException:
            self.patches.restore()
            raise
        return self

    def __exit__(self, kind, value, tb):
        self.patches.restore()
        if kind is None and (self.returned is None or set(self.layers) != self.expected):
            raise ValueError('Source capture did not observe a complete successful whole-B call')
        self.context_success = kind is None
        return False

    def finish(self, owner_or_cache):
        if self.patches.entries or self.finished or not self.context_success:
            raise RuntimeError('Finish exactly once after the successful capture context exits')
        identity = self.backend.completed_capture_identity(owner_or_cache)
        contract.validate_source_provenance(self.A, self.B, identity)
        if (not contract._exact_value(identity, self.provenance)
                or not contract._exact_value(identity, self.observed_provenance)):
            raise ValueError('Completed source output is not the captured frozen cell/call')
        cache = _native_cache(self.backend, owner_or_cache)
        if cache is not self.returned or tuple(self.backend.history_of(owner_or_cache)) != self.A+self.B:
            raise ValueError('Returned source cache/history is not the captured A1+B output')
        with self.backend.installed_context():
            _validate_cache(cache, self.model, self.A+self.B)
            frozen = self.costs.clone_cache(cache, 'source_complete_pre_Q')
            hashes = {}
            for index, record in self.layers.items():
                if not all(key in record for key in ('q','k','v','g','beta','raw_tail','raw_seam_halo')):
                    raise ValueError('Missing actual source factors')
                with self.costs.time('verify_raw_source_conv_tail', layer=index):
                    if not self.backend.torch.equal(record['raw_tail'], frozen.layers[index].conv_states[0]):
                        raise ValueError('Source cache conv tail differs from actual raw projection tail')
                hashes[str(index)] = {name: self.costs.digest(tensor, f'{index}.{name}')
                    for name, tensor in record.items() if isinstance(tensor, self.backend.torch.Tensor)}
            engine_identity, fingerprint = _engine_binding(self.model, self.backend, self.costs)
            binding = SourceBinding(weakref.ref(self.model), weakref.ref(self.backend.engine), fingerprint)
            manifest = dict(reconstruction=LABEL, source='actual_A1_conditioned_whole_B',
                capture_provenance=copy.deepcopy(identity),
                engine_binding=engine_identity, engine_binding_sha256=fingerprint,
                model_identity=id(self.model),
                layer_metadata={str(i): copy.deepcopy({k: v for k, v in r.items()
                    if not isinstance(v, self.backend.torch.Tensor)}) for i, r in self.layers.items()},
                source_factor_specs={str(i): {name: _tensor_spec(value) for name, value in r.items()
                    if isinstance(value, self.backend.torch.Tensor)} for i, r in self.layers.items()},
                block_trace_specs={str(i): {name: _tensor_spec(value) for name, value in r.items()}
                    for i, r in self.traces.items()},
                A_ids=list(self.A), B_ids=list(self.B), history_ids=list(self.A+self.B),
                model_calls_observed=1, extra_source_model_calls=0, source_factor_hashes=hashes,
                block_trace_hashes={str(i): {name: self.costs.digest(tensor, f'block{i}.{name}')
                    for name, tensor in record.items()} for i, record in self.traces.items()},
                source_complete_cache=self.costs.snapshot(frozen, 'source_complete_pre_Q'),
                source_incoming_cache=self.costs.snapshot(self.incoming, 'source_incoming_A1'),
                block_trace_layers=sorted(self.traces),
                block_trace_semantics='decoder_block_input_output_only_not_lost_exact_observer_fields',
                completed=['actual_contextual_capture'],
                unimplemented=['durable_artifact_serialization_owned_by_caller', 'numerical_validation_not_run',
                               'layer19_20_lost_exact_observer_fields_not_recovered'])
        self.finished = True
        return ContextualSource(self.A, self.B, self.incoming, frozen, self.layers, self.traces,
                                manifest, binding, copy.deepcopy(identity))


def _verify_frozen_source(source, backend, costs):
    """Rehash actual retained operands/tuples, not merely the endpoint cache."""
    _verify_source_provenance(source)
    manifest = source.manifest
    if list(source.A) != manifest['A_ids'] or list(source.B) != manifest['B_ids']:
        raise ValueError('Frozen source token history changed')
    if set(map(str, source.layers)) != set(manifest['source_factor_hashes']):
        raise ValueError('Frozen source layer coverage changed')
    for index, record in source.layers.items():
        actual = {name: costs.digest(value, f'{index}.{name}.integrity')
                  for name, value in record.items() if isinstance(value, backend.torch.Tensor)}
        metadata = {name: value for name, value in record.items()
                    if not isinstance(value, backend.torch.Tensor)}
        specs = {name: _tensor_spec(value) for name, value in record.items()
                 if isinstance(value, backend.torch.Tensor)}
        if (specs != manifest['source_factor_specs'][str(index)]
                or actual != manifest['source_factor_hashes'][str(index)]
                or metadata != manifest['layer_metadata'][str(index)]):
            raise ValueError('Frozen source factor bytes/metadata changed')
    trace_hashes = {str(i): {name: costs.digest(tensor, f'block{i}.{name}.integrity')
        for name, tensor in record.items()} for i, record in source.traces.items()}
    trace_specs = {str(i): {name: _tensor_spec(value) for name, value in record.items()}
                   for i, record in source.traces.items()}
    if trace_specs != manifest['block_trace_specs'] or trace_hashes != manifest['block_trace_hashes']:
        raise ValueError('Frozen source block traces changed')
    if costs.snapshot(source.cache, 'frozen_source_integrity') != manifest['source_complete_cache']:
        raise ValueError('Frozen source complete cache changed')
    if costs.snapshot(source.incoming_cache, 'frozen_source_incoming_integrity') != manifest['source_incoming_cache']:
        raise ValueError('Frozen incoming source cache changed')
    if source.suffix is not None:
        if source.suffix.width != WIDTH or source.suffix.tokens != len(source.B)-WIDTH:
            raise ValueError('Frozen suffix extent changed')
        if set(source.suffix.layers) != set(source.layers):
            raise ValueError('Frozen suffix tuple coverage changed')
        for index, factors in source.suffix.layers.items():
            expected = source.suffix.manifest[str(index)]
            for name, key in (('T','T_sha256'), ('U','U_sha256'), ('normalized_scaled_q','q_sha256')):
                if (_tensor_spec(factors[name]) != expected['factor_specs'][name]
                        or costs.digest(factors[name], f'{index}.{name}.integrity') != expected[key]):
                    raise ValueError('Cached suffix tuple bytes changed')


def _extract_suffix(source, backend, costs, width):
    """One FP32 left-state affine extraction, cached across target contexts."""
    if source.suffix is not None:
        if source.suffix.width != width:
            raise ValueError('Source suffix already extracted with another width')
        return source.suffix
    torch, layers, manifest = backend.torch, {}, {}
    with costs.time('extract_source_suffix_affine', suffix_start=width, suffix_stop=len(source.B)):
        for index, record in source.layers.items():
            with costs.time('compose_FP32_affine_T_U', layer=index, tokens=len(source.B)-width):
                k = record['k'][:, width:]
                q = record['q'][:, width:]
                k = k * torch.rsqrt((k*k).sum(-1, keepdim=True)+record['l2_eps'])
                q = q * torch.rsqrt((q*q).sum(-1, keepdim=True)+record['l2_eps'])
                q = q / (q.shape[-1] ** 0.5)
                k = k.repeat_interleave(record['groups'], dim=2)
                v, g, beta = (record[name][:, width:] for name in ('v','g','beta'))
                batch, tokens, heads, kd = k.shape
                vd = v.shape[-1]
                T = torch.eye(kd, dtype=torch.float32, device='cpu').expand(batch, heads, kd, kd).clone()
                U = torch.zeros((batch, heads, kd, vd), dtype=torch.float32, device='cpu')
                for token in range(tokens):
                    kt, vt = k[:, token], v[:, token]
                    alpha = g[:, token].exp()[..., None, None]
                    bt = beta[:, token][..., None]
                    # A_t = exp(g_t)*(I-beta_t*k_t*k_t^T), left-state [K,V].
                    # Later transition acts on earlier T/U, never the reverse.
                    T = T*alpha
                    T = T-kt.unsqueeze(-1)*(((T*kt.unsqueeze(-1)).sum(-2))*bt).unsqueeze(-2)
                    U = U*alpha
                    U = U+kt.unsqueeze(-1)*((vt-(U*kt.unsqueeze(-1)).sum(-2))*bt).unsqueeze(-2)
                layers[index] = dict(T=T, U=U, normalized_scaled_q=q)
            manifest[str(index)] = dict(tokens=tokens, state_orientation='batch,value_head,key,value',
                T_sha256=costs.digest(T, f'{index}.suffix_T'), U_sha256=costs.digest(U, f'{index}.suffix_U'),
                q_sha256=costs.digest(q, f'{index}.suffix_normalized_scaled_q'),
                factor_specs={name: _tensor_spec(value) for name, value in layers[index].items()},
                tuple_bytes=(T.numel()+U.numel())*4, dtype='torch.float32')
    source.suffix = AffineSuffix(width, len(source.B)-width, layers, manifest)
    return source.suffix


class HctxAdapter:
    def __init__(self, model, backend, source):
        self.model, self.backend, self.source = model, backend, source
        self.costs = _Costs(backend)
        _verify_source_provenance(source, backend.current)
        _verify_binding(source, model, backend, self.costs)

    def build(self, A, B, width=WIDTH):
        A, B = _tokens(A), _tokens(B)
        target = contract.canonical_cell(self.backend.current)
        provenance = _verify_source_provenance(self.source, target)
        target_A = tuple(next(p['input_ids'] for p in target['calls'] if p['label'] == 'A'))
        if A != target_A:
            raise ValueError('Fresh target A differs from bound canonical Hctx32 cell')
        if type(width) is not int or width != WIDTH or B != self.source.B:
            raise ValueError('This reconstructed gate is fixed to the source B and width 32')
        _verify_binding(self.source, self.model, self.backend, self.costs)
        if (self.model.model.rotary_emb.rope_type != 'default'
                or self.model.model.rotary_emb.attention_scaling != 1.0):
            raise ValueError('Only fixed-frequency text partial RoPE is reconstructed')
        with self.backend.installed_context():
            _verify_frozen_source(self.source, self.backend, self.costs)
        # Exactly the two required fresh target calls; ancestry checks stay native.
        owner = self.backend.checked_forward(A, parent=None, branch='prefill', purpose='A')
        seam = self.backend.checked_forward(B[:width], parent=owner, branch='prefill', purpose='B_seam')
        if tuple(self.backend.history_of(seam)) != A+B[:width]:
            raise ValueError('Fresh seam cache ancestry does not match target A+seam')
        with self.backend.installed_context():
            suffix = _extract_suffix(self.source, self.backend, self.costs, width)
            cache = self.costs.clone_cache(_native_cache(self.backend, seam), 'fresh_seam_assembly_private')
            _validate_cache(cache, self.model, A+B[:width])
            offset = len(A)-len(self.source.A)
            for index, block in enumerate(self.model.model.layers):
                dest, source = cache.layers[index], self.source.cache.layers[index]
                if hasattr(block, 'linear_attn'):
                    factors = suffix.layers[index]
                    with self.costs.time('apply_FP32_affine_once', layer=index):
                        actual_fresh_R = dest.recurrent_states[0]
                        _check_fp32(self.backend.torch, actual_fresh_R, 'actual fresh seam R')
                        result = factors['T'] @ actual_fresh_R + factors['U']
                        dest.recurrent_states[0].copy_(result)
                    with self.costs.time('copy_source_conv_tail', layer=index):
                        dest.conv_states[0].copy_(source.conv_states[0])
                else:
                    start = len(self.source.A)+width
                    keys, values = source.keys[:, :, start:], source.values[:, :, start:]
                    with self.costs.time('shift_partial_RoPE_and_append_source_KV', layer=index,
                                         offset=offset, suffix_tokens=len(B)-width):
                        if offset:
                            positions = self.backend.torch.full((3, 1, keys.shape[2]), offset, dtype=self.backend.torch.long, device='cpu')
                            cos, sin = self.model.model.rotary_emb(keys, positions)
                            keys = self.backend.hf.apply_rotary_pos_emb(keys, keys, cos, sin)[1]
                        dest.keys = self.backend.torch.cat((dest.keys, keys), dim=2)
                        dest.values = self.backend.torch.cat((dest.values, values), dim=2)
            _validate_cache(cache, self.model, A+B)
            complete = self.costs.snapshot(cache, 'assembled_complete_pre_Q')
            _verify_frozen_source(self.source, self.backend, self.costs)
        trace = dict(reconstruction=LABEL, history_ids=list(A+B), A_ids=list(A), B_ids=list(B),
            capture_provenance=copy.deepcopy(provenance),
            source_history_ids=list(self.source.A+self.source.B), source_context='A1', width=width,
            suffix_range=[width,len(B)], suffix_extraction='once_per_source', fresh_seam_applications=1,
            extra_source_model_calls=0, extra_conv_boundary_repair=False, source_end_conv_tail=True,
            full_attention_prefix='exact_fresh_A_plus_seam', rope_shift=offset,
            tuple_manifest=suffix.manifest, complete_cache=complete,
            fresh_seam_owner=seam, requires_derived_history_registration=True,
            completed=['source_suffix_FP32_affine', 'fresh_seam_state_application', 'native_complete_cache_assembly'],
            unimplemented=['numerical_validation_not_run', 'caller_owned_ancestry_registration',
                           'caller_owned_durable_artifact_serialization'])
        return cache, trace
