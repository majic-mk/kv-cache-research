"""Mocked terminal/host/owned-pidfd tests. No child/model or real signal."""
import copy,json,signal,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as O
from unittest.mock import patch
import guard_original_stage1_reconstructed as g

LIMITS=dict(wall_seconds=1800,load_seconds=900,host_budget_bytes=9_000_000_000,disk_floor_bytes=5_000_000_000,combined_rss_hwm_bytes=8*1024**3,sample_interval_seconds=1)
BOUNDS=dict(retained_artifact_cap_bytes=10_000_000,guard_log_reserve_bytes=2_000_000,new_artifact_envelope_bytes=1000)
def snapshot(**changes):
    value=dict(elapsed_seconds=1.,phase='engine_restored',host_total_bytes=10_000_000_000,host_available_bytes=8_000_000_000,host_unavailable_bytes=2_000_000_000,free_disk_bytes=6_000_000_000,retained_bytes=0,log_and_sample_bytes=0,prospective_receipt_bytes=g.RECEIPT_RESERVE_BYTES)
    value.update(changes);return value

class HostAndLimitTests(unittest.TestCase):
    def test_exact_host_definition_no_baseline_subtraction(self):
        self.assertEqual(g.host_memory('MemTotal: 100 kB\nMemAvailable: 40 kB\n')['host_unavailable_bytes'],60*1024)
    def test_malformed_host_fails_closed(self):
        for raw in ('MemTotal: 100 kB\n','MemTotal: -1 kB\nMemAvailable: 0 kB','MemTotal: 100 kB\nMemAvailable: 101 kB','MemTotal: x kB\nMemAvailable: 0 kB','MemTotal: 100 MB\nMemAvailable: 1 kB','MemTotal: 0 kB\nMemAvailable: 0 kB'):
            with self.subTest(raw=raw),self.assertRaises(g.ProcessMetricsUnavailable):g.host_memory(raw)
    def test_host_ceiling_exact(self):
        self.assertNotIn('host_unavailable_memory_limit',g.resource_violations(snapshot(host_unavailable_bytes=8_999_999_999),LIMITS,BOUNDS))
        self.assertIn('host_unavailable_memory_limit',g.resource_violations(snapshot(host_unavailable_bytes=9_000_000_000),LIMITS,BOUNDS))
    def test_receipt_is_counted_for_disk_retained_and_log(self):
        changes=[dict(free_disk_bytes=LIMITS['disk_floor_bytes']+g.RECEIPT_RESERVE_BYTES-1),dict(retained_bytes=BOUNDS['retained_artifact_cap_bytes']-g.RECEIPT_RESERVE_BYTES),dict(log_and_sample_bytes=BOUNDS['guard_log_reserve_bytes']-g.RECEIPT_RESERVE_BYTES)]
        for change,want in zip(changes,('disk_floor','retained_artifact_cap','guard_log_reserve_exceeded')):
            self.assertIn(want,g.resource_violations(snapshot(**change),LIMITS,BOUNDS))

class PidfdTests(unittest.TestCase):
    def test_reaped_or_reused_numeric_pid_never_used_for_signal(self):
        identity=dict(pid=123,pgid=123,sid=123,starttime_ticks=456)
        with patch.object(g.os,'pidfd_open',return_value=77),patch.object(g,'process_identity',return_value=identity),patch.object(g.signal,'pidfd_send_signal') as send,patch.object(g.os,'kill') as kill,patch.object(g.os,'killpg') as killpg,patch.object(g.os,'close'):
            owner=g.OwnedProcessGroup(123)
            # The original leader can now be reaped/reused; only fd77 is used.
            owner.send(signal.SIGKILL);owner.close()
            send.assert_called_once_with(77,signal.SIGKILL,None,4);kill.assert_not_called();killpg.assert_not_called()
    def test_wrong_session_identity_rejected(self):
        with patch.object(g.os,'pidfd_open',return_value=77),patch.object(g,'process_identity',return_value=dict(pid=123,pgid=7,sid=7,starttime_ticks=456)),patch.object(g.os,'close') as close:
            with self.assertRaises(g.ProcessMetricsUnavailable):g.OwnedProcessGroup(123)
            close.assert_called_once_with(77)
    def test_group_survivor_killed_after_leader_reap(self):
        calls=[];answers=iter((True,True,False,False))
        owner=O(send=lambda sig:(calls.append(sig),next(answers))[1])
        result=g.terminal_group_cleanup(owner)
        self.assertEqual(calls,[0,signal.SIGKILL,0,0]);self.assertTrue(result['group_survived_leader']);self.assertFalse(result['group_still_present'])
    def test_ESRCH_is_only_benign_send_failure(self):
        owner=g.OwnedProcessGroup.__new__(g.OwnedProcessGroup);owner.fd=7;owner.closed=False
        with patch.object(g.signal,'pidfd_send_signal',side_effect=ProcessLookupError):self.assertFalse(owner.send(signal.SIGKILL))
        with patch.object(g.signal,'pidfd_send_signal',side_effect=PermissionError):
            with self.assertRaises(PermissionError):owner.send(signal.SIGKILL)
    def test_capability_probe_is_zero_signal_only(self):
        with patch.object(g.os,'pidfd_open',return_value=77),patch.object(g.signal,'pidfd_send_signal') as send,patch.object(g.os,'close'):
            g.verify_group_pidfd_support();send.assert_called_once_with(77,0,None,4)

class GuardTerminalTests(unittest.TestCase):
    def run_guard(self,resources,*,survivor=False,cleanup_error=False,observations=None):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);admission=O(assert_execution_allowed=lambda:None,limits=LIMITS,bounds=BOUNDS,asset_directory=root,source_sha256='fixed')
            child=O(pid=123,returncode=None);usage=O(ru_maxrss=1,ru_utime=.1,ru_stime=.2)
            terminal={'terminal':(0,usage),'terminal_proc_race_resolved':False}
            observations=observations or [terminal]
            owner=O(identity=dict(pid=123,pgid=123,sid=123,starttime_ticks=4),close=lambda:None,send=lambda sig:False)
            cleanup=dict(group_survived_leader=survivor,kill_sent=survivor,group_still_present=False)
            with patch.object(g.c,'HERE',root),patch.object(g,'source_pins',return_value={'fixed':'sha'}),patch.object(g,'host_memory',return_value=snapshot()),patch.object(g,'verify_group_pidfd_support'),patch.object(g.shutil,'disk_usage',return_value=O(free=10_000_000_000)),patch.object(g.subprocess,'Popen',return_value=child) as start,patch.object(g,'OwnedProcessGroup',return_value=owner),patch.object(g,'sample_or_reap',side_effect=observations),patch.object(g,'status',return_value={'VmRSS':1,'VmHWM':1}),patch.object(g,'descendants',return_value=[]),patch.object(g.time,'sleep'),patch.object(g,'resource_snapshot',side_effect=resources),patch.object(g,'terminal_group_cleanup',side_effect=PermissionError('pidfd denied') if cleanup_error else None,return_value=cleanup) as cleaned:
                result=g.guard_once(admission,root/'attempt')
                self.assertTrue(result['terminal_wait4_receipt_present']);self.assertEqual(result['child_peak_RSS_bytes'],1024)
                self.assertEqual(start.call_count,1);cleaned.assert_called_once_with(owner)
                return result
    def test_immediate_terminal_still_enforces_every_limit(self):
        cases=[({'elapsed_seconds':1800},'load_and_execution_wall_limit'),({'host_unavailable_bytes':9_000_000_000},'host_unavailable_memory_limit'),({'free_disk_bytes':4_999_999_999},'disk_floor'),({'retained_bytes':10_000_000},'retained_artifact_cap'),({'log_and_sample_bytes':2_000_000},'guard_log_reserve_exceeded')]
        for change,want in cases:
            with self.subTest(change=change):
                result=self.run_guard([snapshot(**change)])
                self.assertEqual(result['status'],'FAIL_ORIGINAL_FIRST24_PROCESS_GUARD');self.assertEqual(result['resource_stop'],want)
    def test_limit_crossed_after_last_live_sample(self):
        live={'terminal':None,'metrics':{'VmRSS':1,'VmHWM':1}}
        usage=O(ru_maxrss=1,ru_utime=.1,ru_stime=.2)
        terminal={'terminal':(0,usage),'terminal_proc_race_resolved':False}
        for changed in (dict(elapsed_seconds=1800),dict(free_disk_bytes=1),dict(retained_bytes=10_000_000),dict(log_and_sample_bytes=2_000_000)):
            with self.subTest(change=changed):
                result=self.run_guard([snapshot(),snapshot(**changed)],observations=[live,terminal])
                self.assertEqual(result['status'],'FAIL_ORIGINAL_FIRST24_PROCESS_GUARD')
    def test_valid_terminal_can_pass_resource_guard_only(self):
        result=self.run_guard([snapshot()]);self.assertEqual(result['status'],'PASS_ORIGINAL_FIRST24_PROCESS_GUARD');self.assertTrue(result['native_result_is_separate'])
    def test_reaped_leader_survivor_prevents_PASS(self):
        result=self.run_guard([snapshot()],survivor=True);self.assertEqual(result['resource_stop'],'owned_group_survived_leader')
    def test_cleanup_failure_prevents_PASS(self):
        result=self.run_guard([snapshot()],cleanup_error=True);self.assertEqual(result['resource_stop'],'owned_group_cleanup_failure')

if __name__=='__main__':unittest.main(verbosity=2)
