# Original first24 result: stop for no qualifying harm

2026-10-04 UTC. **STOP_NO_QUALIFYING_HARM**. The fixed first24 experiment is
complete. All 24 cells answered correctly with EOS, all strict gold-token checks
passed, and all reference/self-reuse numerical controls passed. No answer harm
was observed. The condition requiring both fixed A2 groups to meet both losses
was not met. No conditional repair, donor, wider-seam or holdout execution is
released by this result; do not replace fixtures or change the threshold.

## Frozen scientific decision

The gold-logprob noise was 0.000001758337 and margin noise 0.000013351440.
Consequently both prospectively fixed thresholds remained 0.1 nat.

| Changed-context group | Gold logprob loss | Gold-minus-other margin loss | Both >=0.1? | Answer harm |
|---|---:|---:|---|---|
| d01/A2 | 0.1362178102 | 0.8870320320 | Yes | No |
| d05/A2 | 0.0170323327 | 1.0556178093 | No | No |

The d05 margin change cannot replace the separately required gold-loss condition.
The d01 effect cannot be selected as the success of the two-group screen. This
negative decision is compatible with some context-dependent confidence changes;
it is not a theorem that cross-context reuse is always harmless.

## Execution and complete cost boundary

Attempt 1 failed before any logical model forward: the caller supplied
`torch.__version__` as its string-subclass type, rejected by the strict evidence
serializer. The exact loader had returned past its live source assertions, but
its audit event was never durably written. Its failure, empty evidence journal,
resource receipt and exact source snapshot remain preserved. The separately
approved technical retry cast only that caller field to plain `str`; serializer,
scientific inputs, thresholds and limits stayed unchanged.

| Run | Logical calls/tokens | Wall seconds | Child user/system CPU seconds | Combined terminal HWM |
|---|---:|---:|---:|---:|
| Attempt 1, metadata failure | 0 / 0 | 24.721408 | 19.463904 / 1.724770 | 4,230,381,568 bytes |
| Attempt 2, scientific completion | 173 / 4,705 | 386.226860 | 374.204514 / 7.968548 | 7,270,092,800 bytes |

Cumulative attempt wall time: **410.948268 seconds**. Cumulative child CPU:
**403.361736 seconds**. Offline validation and post-run auditing are separately
recorded preparation/review work, not omitted successful-run throughput.
The conservative maximum of sampled and terminal combined HWM was
**7,270,248,448 bytes**, below 8 GiB. The host-unavailable peak was
4,726,112,256 bytes, below 9 GB. The guard passed with owned wait4, no resource
stop, unchanged source pins and completed engine teardown.

The cost ledger records 35,465 logical arena acquisitions and
1,302,149,398,528 logical cast bytes. Clone/hash/source/serialization/file-mapping
work is also recorded, including source acquisition inside R/A1. These are
instrumented CPU diagnostic costs. Nested timers overlap; logical byte totals
are not measured physical memory or disk traffic. Do not turn an Hctx-versus-R
root-call timing into an economic serving claim: R/A1 also pays source capture,
and these eager FP32 diagnostic paths are not an optimized long-context system.

## Evidence available

- 173 complete raw vocabulary-logit outputs and 24 raw pre-Q caches
- Two incoming-source A caches, actual contextual operands/halos/block traces,
  two suffix factor sets, and ten actually needed additional F32/A1 reference
  endpoint caches (21 was the conservative cap)
- 2,305 raw artifacts totaling **1,363,509,248 bytes**; all hashes and byte/shape
  extents passed post-run readback
- 2,881 passing live cache/logit checks; maximum absolute difference
  0.000030040741 and maximum logit TV 0.000001486179
- Durable call, ancestry, numerical, scalar, terminal, cost and guard records

The raw journal is `original_stage1_attempt_02/evidence/evidence.jsonl`; raw
floats are beside it. The scientific terminal record is its `first24_terminal`
row. Machine-readable results are in `FIRST24_TERMINAL_RESULT.json`; the readback
is `original_stage1_attempt_02_readback_audit.json`. Guard receipts and launch
identities are the sibling `original_stage1_attempt_01*` and `...02*` files.
Attempt 1's `frozen_source/` snapshot is byte-verified against the matching guard
before/after pins. Current source digest is
`581632d5433f81f10d44433176984163dcc3bb30c44369ad2a5b6f4aa8ee3515`;
attempt2 release SHA is
`117c8b4e451b7eb79d76a327c93556b972336073fa84a940bbdf190513d2d921`.

Post-run readback establishes raw identity/extents and record consistency, not
independent recomputation of every numerical comparison. Transient caches beyond
the designated reference banks retain live metrics/hashes rather than all raw
tensors. Independent terminal review found no invalidating discrepancy. It independently
recomputed all 173 raw logit vectors with float64 log-sum-exp, checked all 480
pre-Q tensor comparisons and 49 exact score-step vector comparisons, and retained
the same negative gate decision. See [terminal review](../contextual_harm_stage1_original_terminal_review_20261004.md).

## What this justifies

The implementation can execute this exact small original-2B FP32 screen within
its guard. It does not erase the earlier 0.8B competence failure, earlier 2B BF16
numerical failure, two tiny evidence-budget failures, or the third tiny run's
incomplete watchdog evidence. The corrected contextual arm is HYPIC-inspired
intended semantics, not an author-runtime reproduction.

There is no basis here to promote the proposed observer/value-write correction,
claim novelty, promise a publication tier, or spend on GPU expansion. A limited
read-only interpretation is recorded separately, preserving this failed screen.
