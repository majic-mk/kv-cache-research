# Narrow original guard correction

Source-only revision after the original preparation review, 2026-10-04. The
original experiment remains source-locked. No model, child process, or native
integration was run for this correction.

## Changed behavior

- Sample host unavailable memory as `(MemTotal - MemAvailable) * 1024`, with the
  preserved strict 9,000,000,000-byte ceiling and no baseline subtraction
- Fail closed on missing, malformed or impossible host memory fields
- After owned `wait4`, check wall/load time, host memory, disk floor, retained
  bytes and log/sample bytes before assigning a guard PASS
- Reserve 256 KiB for the final receipt in disk, retained and log accounting;
  an oversized receipt cannot be written with a PASS label
- Capture the new-session leader's pidfd, PID/PGID/SID and start identity before
  any reap. Keep the pidfd until cleanup has run even after leader exit
- Send group-scoped signals through that retained pidfd. There is no numeric
  `killpg` fallback that could target a recycled group. A surviving group is
  killed and prevents PASS; unsupported capability or cleanup failures also
  prevent PASS

Python's existing `os.pidfd_open` and `signal.pidfd_send_signal` APIs are used.
The group flag is documented in the Linux UAPI and its implementation passes the
retained kernel PID object to group signaling, without a fresh numeric PGID lookup:
[flag definition](https://raw.githubusercontent.com/torvalds/linux/v6.18/include/uapi/linux/pidfd.h),
[kernel implementation](https://raw.githubusercontent.com/torvalds/linux/v6.18/kernel/signal.c).
No custom syscall, process anchor, system setting or security change is added.

## Evidence

Fourteen new mocked tests cover immediate terminal success with each bound
crossed, last-sample-to-terminal crossings, receipt overhead, exact host ceiling,
malformed memory data, retained pidfd signaling, reaped-leader cleanup and failure
handling. All 152 contextual model-free tests pass. The kernel is 6.18.44. A
signal-0 probe on the checker process's own pidfd accepted group flag 4; signal 0
is an existence/permission check and delivers no signal. This establishes flag
acceptance only, not a real post-reap group-cleanup test. Independent focused source review confirmed closure for these three defects at
guard SHA661628774e41efdef6e382edeaa17b5af9fe40554e5f4b5b49d64b1a0ce1290b.
Original asset activation and parent execution release remain separate.

The reviewed fresh asset directory is recorded in
`prospective_reviewed_asset_activation.json`. Its appearance does not unlock
execution or qualify the older partial file. The old default asset path and
historical evidence remain unchanged.
