"""NEWLY RECONSTRUCTED, 2026-10-04; not exact recovery or native integration.

Fail-closed cache provenance for a future caller adapter. This module never
imports a model package or performs a model forward. The caller MUST provide:
  * weak-referenceable owners and actual caches, with stable get_cache(owner)
    and monotonic integer get_version(owner) accessors; version changes on EVERY
    cache mutation/replacement, including in-place native updates;
  * TrackedNativeOutput only after a successfully returned native invocation,
    using the ACTUAL returned cache/version and exact complete token history;
  * a verified_clone callback that checks content equality AND independent
    mutable storage, returning VerifiedClone with its explicit attestations.
The caller also synchronizes cache mutation from claim through invocation and
output registration, and retains each root/parent owner while descendants exist.
These are trust boundaries, not facts this generic registry can infer from
lengths or Python identities. No native caller adapter is reconstructed here.

Before a forward, claim_for_forward atomically checks exact parent, full token
history, branch/purpose, live owner/version/cache identities and root identity.
A candidate is single-use even if a subsequent invocation fails. Native output
must be registered explicitly; claims alone cannot manufacture parent records.
Hctx assembly has a separate verified-derived path. Its callback must verify the
actual complete cache/metadata, independent storage, trace, exact parent, and
externally fixed full A+B history. A derived record is NEVER a native output.
"""
from __future__ import annotations

import threading
import weakref
from dataclasses import dataclass, replace
from typing import Callable

try:
    from .evidence_sink_reconstructed import METADATA_LIMIT, check_metadata_budget
except ImportError:
    from evidence_sink_reconstructed import METADATA_LIMIT, check_metadata_budget


class AncestryError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class TrackedNativeOutput:
    owner: object
    returned_cache: object
    returned_version: int
    token_history: tuple[int, ...]
    model_invoked: bool
    model_returned: bool
    completed_successfully: bool


@dataclass(frozen=True, slots=True)
class VerifiedClone:
    owner: object
    cache: object
    version: int
    token_history: tuple[int, ...]
    content_verified: bool
    independent_storage_verified: bool


@dataclass(frozen=True, slots=True)
class DerivedCache:
    """Untrusted non-forward assembly result supplied to the required verifier."""
    owner: object
    cache: object
    version: int
    token_history: tuple[int, ...]
    metadata: object
    adapter_trace: object


@dataclass(frozen=True, slots=True)
class DerivedVerification:
    """Callback attestation bound to actual parent/child identities and trace."""
    parent_owner: object
    parent_cache: object
    parent_version: int
    derived_owner: object
    derived_cache: object
    derived_version: int
    token_history: tuple[int, ...]
    branch: str
    purpose: str
    complete_cache_verified: bool
    independent_storage_verified: bool
    adapter_trace_verified: bool
    adapter_trace_sha256: str
    verifier_provenance: str


@dataclass(frozen=True, slots=True)
class CacheRecord:
    serial: int
    owner_ref: weakref.ReferenceType
    cache_ref: weakref.ReferenceType
    owner_identity: int
    cache_identity: int
    version: int
    token_history: tuple[int, ...]
    parent_serial: int | None
    root_serial: int
    branch: str
    purpose: str
    origin: str
    claimed: bool = False
    verifier_provenance: str | None = None
    verifier_callback: str | None = None
    adapter_trace_sha256: str | None = None


@dataclass(frozen=True, slots=True)
class ForwardPermit:
    """Opaque single-use claim; registry checks object identity, not its fields."""
    serial: int
    candidate_serial: int
    parent_serial: int
    root_serial: int
    token_history: tuple[int, ...]
    appended_tokens: tuple[int, ...]
    branch: str
    purpose: str


class CacheAncestryRegistry:
    def __init__(self, *, get_cache: Callable[[object], object],
                 get_version: Callable[[object], int], metadata_limit: int = METADATA_LIMIT):
        if not 0 < metadata_limit <= METADATA_LIMIT:
            raise ValueError("ancestry metadata may only tighten the 32 MiB cap")
        self._get_cache = get_cache
        self._get_version = get_version
        self.metadata_limit = metadata_limit
        self._records: dict[int, CacheRecord] = {}
        self._by_owner: dict[int, int] = {}
        self._seen_cache: dict[int, weakref.ReferenceType] = {}
        self._permits: dict[int, ForwardPermit] = {}
        self._next_serial = 1
        self._lock = threading.RLock()

    @staticmethod
    def _tokens(tokens: tuple[int, ...]) -> tuple[int, ...]:
        if type(tokens) is not tuple or any(type(token) is not int or token < 0 for token in tokens):
            raise AncestryError("token history must be an exact tuple of nonnegative integer IDs")
        return tokens

    @staticmethod
    def _label(label: str) -> str:
        if type(label) is not str or not 1 <= len(label) <= 128:
            raise AncestryError("branch/purpose must be nonempty bounded strings")
        return label

    def _version(self, owner: object) -> int:
        version = self._get_version(owner)
        if type(version) is not int or version < 0:
            raise AncestryError("owner must expose an explicit nonnegative integer version")
        return version

    def _current(self, record: CacheRecord) -> object:
        owner = record.owner_ref()
        cache = record.cache_ref()
        if owner is None or cache is None:
            raise AncestryError("registered owner/cache is no longer alive")
        if id(owner) != record.owner_identity or id(cache) != record.cache_identity:
            raise AncestryError("weak owner/cache identity mismatch")
        if self._get_cache(owner) is not cache or self._version(owner) != record.version:
            raise AncestryError("actual owner cache identity or version changed")
        return owner

    def _lookup(self, owner: object) -> CacheRecord:
        serial = self._by_owner.get(id(owner))
        if serial is None:
            raise AncestryError("parent/candidate owner is not registered")
        record = self._records[serial]
        if record.owner_ref() is not owner:
            raise AncestryError("owner identity was recycled or is stale")
        self._current(record)
        self._check_root(record)
        return record

    def _check_root(self, record: CacheRecord) -> None:
        root = self._records.get(record.root_serial)
        if root is None or root.origin != "successful_native_root":
            raise AncestryError("ancestry has no successfully tracked native root")
        self._current(root)

    def _bound(self, *proposed: object) -> None:
        check_metadata_budget((self._records, self._by_owner, self._seen_cache,
                               self._permits, proposed), limit=self.metadata_limit)

    def _fresh_cache(self, cache: object) -> None:
        previous = self._seen_cache.get(id(cache))
        if previous is not None and previous() is cache:
            raise AncestryError("cache object has already been registered; candidate reuse forbidden")

    def _new_record(self, *, owner: object, cache: object, version: int,
                    tokens: tuple[int, ...], parent: int | None, root: int | None,
                    branch: str, purpose: str, origin: str,
                    may_replace: CacheRecord | None = None,
                    verifier_provenance: str | None = None,
                    verifier_callback: str | None = None,
                    adapter_trace_sha256: str | None = None) -> CacheRecord:
        try:
            owner_ref, cache_ref = weakref.ref(owner), weakref.ref(cache)
        except TypeError as exc:
            raise AncestryError("owner and actual cache must support weak identity references") from exc
        if self._get_cache(owner) is not cache or self._version(owner) != version:
            raise AncestryError("reported cache/version is not the actual owner's current cache/version")
        if type(version) is not int or version < 0:
            raise AncestryError("reported version must be a nonnegative integer")
        prior_serial = self._by_owner.get(id(owner))
        prior = self._records.get(prior_serial)
        if prior is not None and prior.owner_ref() is owner:
            if may_replace is None or prior.serial != may_replace.serial:
                raise AncestryError("owner is already registered under another provenance record")
            if version <= prior.version:
                raise AncestryError("native output must advance the reused owner's version")
        prior_cache = self._seen_cache.get(id(cache))
        if prior_cache is not None and prior_cache() is cache:
            if may_replace is None or may_replace.cache_ref() is not cache:
                raise AncestryError("native output/clone reused an unrelated registered cache")
        serial = self._next_serial
        record = CacheRecord(serial, owner_ref, cache_ref, id(owner), id(cache), version,
                             self._tokens(tokens), parent, serial if root is None else root,
                             self._label(branch), self._label(purpose), origin,
                             verifier_provenance=verifier_provenance,
                             verifier_callback=verifier_callback,
                             adapter_trace_sha256=adapter_trace_sha256)
        # Reserve actual resized maps before publishing any provenance.
        records, owners, caches = dict(self._records), dict(self._by_owner), dict(self._seen_cache)
        records[serial], owners[id(owner)], caches[id(cache)] = record, serial, cache_ref
        self._bound(records, owners, caches, record)
        self._records, self._by_owner, self._seen_cache = records, owners, caches
        self._next_serial += 1
        return record

    def _validate_output(self, output: TrackedNativeOutput) -> None:
        if type(output) is not TrackedNativeOutput or not (
                output.model_invoked is True and output.model_returned is True
                and output.completed_successfully is True):
            raise AncestryError("only explicitly tracked successful native returns may be registered")
        self._tokens(output.token_history)
        if self._get_cache(output.owner) is not output.returned_cache:
            raise AncestryError("tracked native returned cache is not the actual owner cache")
        if self._version(output.owner) != output.returned_version:
            raise AncestryError("tracked native returned version differs from actual owner version")

    def register_native_root(self, output: TrackedNativeOutput, *, branch: str,
                             purpose: str) -> CacheRecord:
        """Caller attests this root came from a successful full native prefix."""
        with self._lock:
            self._validate_output(output)
            self._fresh_cache(output.returned_cache)
            return self._new_record(owner=output.owner, cache=output.returned_cache,
                                    version=output.returned_version, tokens=output.token_history,
                                    parent=None, root=None, branch=branch, purpose=purpose,
                                    origin="successful_native_root")

    def verified_clone(self, parent_owner: object, *, expected_tokens: tuple[int, ...],
                       branch: str, purpose: str,
                       clone_callback: Callable[[object, str, str], VerifiedClone]) -> VerifiedClone:
        """Callback verifies equality/storage isolation; generic code cannot infer it."""
        with self._lock:
            parent = self._lookup(parent_owner)
            if parent.claimed:
                raise AncestryError("a consumed candidate is not a verified parent; a successful output is required")
            if parent.token_history != self._tokens(expected_tokens):
                raise AncestryError("clone request does not match the exact parent token history")
            branch, purpose = self._label(branch), self._label(purpose)
            if not callable(clone_callback):
                raise AncestryError("an explicit verified-clone callback is required")
            clone = clone_callback(parent_owner, branch, purpose)
            # The callback must not mutate or replace parent/root cache state.
            self._current(parent)
            self._check_root(parent)
            if type(clone) is not VerifiedClone or not (
                    clone.content_verified is True and clone.independent_storage_verified is True):
                raise AncestryError("clone callback did not verify content and independent mutable storage")
            if clone.owner is parent_owner or clone.cache is parent.cache_ref():
                raise AncestryError("clone must have distinct owner and cache identities")
            if self._tokens(clone.token_history) != parent.token_history:
                raise AncestryError("verified clone has the wrong exact token history")
            self._fresh_cache(clone.cache)
            self._new_record(owner=clone.owner, cache=clone.cache, version=clone.version,
                             tokens=clone.token_history, parent=parent.serial,
                             root=parent.root_serial, branch=branch, purpose=purpose,
                             origin="verified_clone")
            # The returned value keeps the new owner alive for the caller; the
            # registry itself retains only weak owner/cache references.
            return clone

    def register_derived(self, parent_owner: object, output: DerivedCache, *,
                         expected_history: tuple[int, ...], branch: str,
                         verifier_callback: Callable[[object, DerivedCache, tuple[int, ...],
                                                      str, str], DerivedVerification],
                         purpose: str = "Hctx32_assembly") -> CacheRecord:
        """Register verified non-forward assembly, never a native invocation.

        expected_history is an externally fixed complete A+B sequence, not a
        history inferred from the candidate cache length. The callback validates
        the adapter's actual full cache/metadata and trace against that history
        and the supplied actual parent. Its attestation and callable identity are
        recorded, but this module cannot verify native tensors/storage itself.
        """
        with self._lock:
            parent = self._lookup(parent_owner)
            if parent.claimed:
                raise AncestryError("a consumed candidate is not an immutable derived parent")
            if type(output) is not DerivedCache:
                raise AncestryError("non-forward assembly requires an explicit DerivedCache")
            history = self._tokens(expected_history)
            if self._tokens(output.token_history) != history:
                raise AncestryError("derived history differs from externally fixed exact history")
            if history[:len(parent.token_history)] != parent.token_history:
                raise AncestryError("derived A+B history does not preserve the exact parent's prefix")
            branch, purpose = self._label(branch), self._label(purpose)
            if output.owner is parent_owner or output.cache is parent.cache_ref():
                raise AncestryError("derived cache must not alias its parent owner or cache")
            if self._get_cache(output.owner) is not output.cache or self._version(output.owner) != output.version:
                raise AncestryError("derived reported cache/version is not the actual owner state")
            self._fresh_cache(output.cache)
            self._bound(output.metadata, output.adapter_trace)
            if not callable(verifier_callback):
                raise AncestryError("derived assembly requires an explicit verifier callback")
            verification = verifier_callback(parent_owner, output, history, branch, purpose)
            self._current(parent)
            self._check_root(parent)
            if type(verification) is not DerivedVerification or not (
                    verification.complete_cache_verified is True
                    and verification.independent_storage_verified is True
                    and verification.adapter_trace_verified is True):
                raise AncestryError("derived verifier did not verify full cache, independence, and adapter trace")
            if not (verification.parent_owner is parent_owner
                    and verification.parent_cache is parent.cache_ref()
                    and type(verification.parent_version) is int
                    and verification.parent_version == parent.version):
                raise AncestryError("derived verification identifies the wrong actual parent")
            if not (verification.derived_owner is output.owner
                    and verification.derived_cache is output.cache
                    and type(verification.derived_version) is int
                    and verification.derived_version == output.version):
                raise AncestryError("derived verification identifies the wrong actual child cache")
            if (self._tokens(verification.token_history) != history
                    or verification.branch != branch or verification.purpose != purpose):
                raise AncestryError("derived verification has the wrong history, branch, or purpose")
            digest = verification.adapter_trace_sha256
            if type(digest) is not str or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise AncestryError("verified adapter trace requires a lowercase SHA-256 digest")
            provenance = self._label(verification.verifier_provenance)
            callback_name = (f"{getattr(verifier_callback, '__module__', type(verifier_callback).__module__)}."
                             f"{getattr(verifier_callback, '__qualname__', type(verifier_callback).__qualname__)}")
            if len(callback_name) > 512:
                raise AncestryError("verifier callable identity is unexpectedly oversized")
            return self._new_record(owner=output.owner, cache=output.cache, version=output.version,
                                    tokens=history, parent=parent.serial, root=parent.root_serial,
                                    branch=branch, purpose=purpose, origin="verified_derived_cache",
                                    verifier_provenance=provenance, verifier_callback=callback_name,
                                    adapter_trace_sha256=digest)

    def origin_counts(self) -> dict[str, int]:
        """Compact provenance counts; derived registration never increments native counts."""
        with self._lock:
            counts: dict[str, int] = {}
            for record in self._records.values():
                counts[record.origin] = counts.get(record.origin, 0) + 1
            return counts

    def assert_ready_before_forward(self, candidate_owner: object, *, parent_owner: object,
                                    expected_tokens: tuple[int, ...], branch: str,
                                    purpose: str) -> CacheRecord:
        """Read-only check; adapters must use claim_for_forward immediately before call."""
        with self._lock:
            candidate, parent = self._lookup(candidate_owner), self._lookup(parent_owner)
            if parent.claimed:
                raise AncestryError("a consumed candidate cannot be used as the current parent")
            if candidate.origin != "verified_clone" or candidate.claimed:
                raise AncestryError("only a never-claimed verified clone may enter a forward")
            if candidate.parent_serial != parent.serial:
                raise AncestryError("candidate came from the wrong actual parent, regardless of length")
            tokens = self._tokens(expected_tokens)
            if candidate.token_history != tokens or parent.token_history != tokens:
                raise AncestryError("exact candidate/parent token histories differ")
            if candidate.branch != branch or candidate.purpose != purpose:
                raise AncestryError("candidate branch or clone purpose does not match")
            if candidate.root_serial != parent.root_serial:
                raise AncestryError("candidate and parent roots differ")
            return candidate

    def claim_for_forward(self, candidate_owner: object, *, parent_owner: object,
                          expected_tokens: tuple[int, ...], appended_tokens: tuple[int, ...],
                          branch: str, purpose: str) -> ForwardPermit:
        """Consume once before caller invokes native code; failures never release it."""
        with self._lock:
            candidate = self.assert_ready_before_forward(candidate_owner, parent_owner=parent_owner,
                                                         expected_tokens=expected_tokens,
                                                         branch=branch, purpose=purpose)
            appended_tokens = self._tokens(appended_tokens)
            if not appended_tokens:
                raise AncestryError("a native continuation must declare nonempty exact appended tokens")
            permit = ForwardPermit(self._next_serial, candidate.serial, candidate.parent_serial,
                                   candidate.root_serial, expected_tokens, appended_tokens,
                                   branch, purpose)
            claimed = replace(candidate, claimed=True)
            records, permits = dict(self._records), dict(self._permits)
            records[candidate.serial], permits[permit.serial] = claimed, permit
            self._bound(records, permits, claimed, permit)
            self._records, self._permits = records, permits
            self._next_serial += 1
            return permit

    def _permit(self, permit: ForwardPermit) -> CacheRecord:
        if type(permit) is not ForwardPermit or self._permits.get(permit.serial) is not permit:
            raise AncestryError("forward permit is unknown, forged, failed, or already completed")
        candidate = self._records[permit.candidate_serial]
        self._check_root(candidate)
        return candidate

    def register_native_output(self, permit: ForwardPermit,
                               output: TrackedNativeOutput) -> CacheRecord:
        with self._lock:
            candidate = self._permit(permit)
            # Consume even when validation fails; no fabricated/repeated output retry.
            del self._permits[permit.serial]
            self._validate_output(output)
            if output.token_history != permit.token_history + permit.appended_tokens:
                raise AncestryError("native output history does not equal exact parent plus declared input")
            # A successful call may update candidate in-place or return a new cache.
            # Reusing any other registered owner/cache is forbidden.
            owner = candidate.owner_ref()
            if owner is None:
                raise AncestryError("candidate owner died before native output registration")
            same_owner = output.owner is owner
            if not same_owner and output.returned_cache is candidate.cache_ref():
                raise AncestryError("native output changed owner around the old candidate cache")
            return self._new_record(owner=output.owner, cache=output.returned_cache,
                                    version=output.returned_version, tokens=output.token_history,
                                    parent=candidate.serial, root=candidate.root_serial,
                                    branch=permit.branch, purpose=permit.purpose,
                                    origin="successful_native_output",
                                    may_replace=candidate if same_owner else None)

    def record_native_failure(self, permit: ForwardPermit) -> None:
        """Remove permission to register an output; candidate remains consumed."""
        with self._lock:
            self._permit(permit)
            del self._permits[permit.serial]

    def inspect(self, owner: object) -> CacheRecord:
        with self._lock:
            return self._lookup(owner)
