"""Model-free OS mapping tests; no torch or model import."""
import hashlib,struct,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as O
from file_backed_evidence_reconstructed import MappedEvidence

class Tensor:
    def __init__(self,buffer=None):self.buffer=buffer;self.shape=[]
    def reshape(self,shape):self.shape=list(shape);return self
    def values(self):return struct.unpack('='+str(len(self.buffer)//4)+'f',self.buffer)
class Tests(unittest.TestCase):
    def fixture(self,tmp):
        path=Path(tmp);raw=struct.pack('=ff',1.25,-2.5);(path/'x.f32').write_bytes(raw)
        receipt=dict(path='x.f32',dtype='float32',byte_order=sys.byteorder,shape=[2],bytes=8,sha256=hashlib.sha256(raw).hexdigest())
        torch=O(Tensor=Tensor,float32='f32',frombuffer=lambda b,dtype:Tensor(b),empty=lambda shape,dtype:Tensor(bytearray()))
        return MappedEvidence(path,torch),receipt,raw
    def test_values_survive_inactive_eviction_without_replay(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping,receipt,raw=self.fixture(tmp);tensor=mapping.tensor(receipt)
            self.assertEqual(tensor.values(),(1.25,-2.5));mapping.evict();self.assertEqual(tensor.values(),(1.25,-2.5))
            self.assertEqual(mapping.summary()['model_calls'],0);self.assertEqual(mapping.bytes,8)
    def test_changed_raw_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping,receipt,raw=self.fixture(tmp);(Path(tmp)/'x.f32').write_bytes(raw[::-1])
            with self.assertRaisesRegex(ValueError,'bytes differ'):mapping.tensor(receipt)
            self.assertEqual(mapping.maps,[])
    def test_complete_cache_structure_and_field_coverage(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping,receipt,raw=self.fixture(tmp)
            Cache=type('DynamicCache',(),{});Cache.__module__='transformers.cache_utils'
            original=Cache();original.layers=[{'states':{0:Tensor()}}];original.length=2
            copied=mapping.cache(original,{'cache.layers[0][\'states\'][0]':receipt})
            self.assertIsNot(copied,original);self.assertIsNot(copied.layers,original.layers);self.assertEqual(copied.length,2)
            self.assertEqual(copied.layers[0]['states'][0].values(),(1.25,-2.5))
            with self.assertRaisesRegex(ValueError,'missing field'):mapping.cache(original,{})
    def test_unsupported_byteorder_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping,receipt,raw=self.fixture(tmp);receipt['byte_order']='big' if sys.byteorder=='little' else 'little'
            with self.assertRaises(ValueError):mapping.tensor(receipt)

if __name__=='__main__':unittest.main(verbosity=2)
