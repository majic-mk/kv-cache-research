"""Model-free admission, dead-load, and owned guard route regressions only."""
import ast
from dataclasses import replace
import io
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import sys
import contract_reconstructed as c
import original_admission_reconstructed as a
import run_original_stage1_reconstructed as run
import guard_original_stage1_reconstructed as guard

class AdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.admission=a.preflight()
        cls.bounds=cls.admission.bounds
    def test_stdlib_only_imports(self):
        self.assertNotIn('torch',sys.modules)
        self.assertNotIn('transformers',sys.modules)
        self.assertNotIn('tokenizers',sys.modules)
    def test_exact_existing_small_assets(self):
        self.assertEqual(set(a.SMALL_ASSETS),set(self.admission.asset_checks)-{'checkpoint','restored_runtime_source_files'})
        self.assertEqual(self.admission.asset_checks['checkpoint']['status'],'MISSING_OR_UNVERIFIED')
    def test_partial_cannot_qualify(self):
        with patch.object(Path,'is_file',return_value=False),patch.object(a,'_load_contracts') as loader:
            with self.assertRaisesRegex(a.OriginalExecutionHold,'partial'):
                a.verify_checkpoint_layout()
            loader.assert_not_called()
    def test_fixed_work_and_reference_owner_counts(self):
        b=self.bounds
        self.assertEqual((b['root_model_calls_max'],b['network_tokens_max'],b['scored_vocab_vectors_max']),(308,4840,252))
        self.assertEqual((b['retained_f32_a1_endpoints_max'],b['current_r_endpoints_max']),(23,12))
        self.assertEqual(b['complete_live_cache_count_max'],27)
        self.assertEqual(b['anonymous_live_cache_count_max'],24)
        self.assertEqual(b['active_mapped_reference_cache_count_max'],1)
        self.assertEqual(b['active_mapped_source_cache_count_max'],2)
        self.assertEqual(b['max_sequence_tokens'],245)
        self.assertEqual(b['cache_bytes_max'],26664960)
        self.assertTrue(b['additional_continuation_cache_clones_charged'])
    def test_complete_memory_sum(self):
        b=self.bounds
        self.assertEqual(sum(b['execution_components'].values()),b['analytical_execution_envelope_bytes'])
        self.assertEqual(b['analytical_combined_envelope_bytes'],max(b['analytical_execution_envelope_bytes'],b['analytical_loader_envelope_bytes']))
        self.assertEqual(b['execution_components']['source_resident_bytes'],3763655360)
        self.assertEqual(b['execution_components']['fp32_arena_bytes'],2034237440)
        self.assertLess(b['analytical_combined_envelope_bytes'],a.LIMITS['combined_rss_hwm_bytes'])
        self.assertGreater(b['explicit_runtime_guard_workspace_reserve_bytes'],1024**3)
        self.assertGreater(b['known_payload_and_operator_estimate_bytes'],a.SOURCE_PARAMETER_BYTES+a.ARENA_BYTES)
        self.assertFalse(b['tiny_RSS_used_for_admission'])
        self.assertFalse(b['native_workspace_qualified'])
        self.assertFalse(b['loader_peak_qualified'])
    def test_evidence_includes_all_calls_and_extra_source_A(self):
        b=self.bounds
        self.assertEqual(b['extra_source_incoming_A_artifacts'],2)
        self.assertEqual(b['extra_file_backed_reference_cache_artifacts'],21)
        self.assertTrue(b['inactive_evidence_mapping_eviction_required'])
        self.assertFalse(b['source_preQ_disk_duplication'])
        self.assertGreater(b['raw_artifact_bytes_max'],24*b['cache_bytes_max']+308*c.VOCAB*4)
        self.assertEqual(b['new_artifact_envelope_bytes'],b['raw_artifact_bytes_max']+b['journal_cap_bytes']+b['metadata_reserve_bytes']+b['guard_log_reserve_bytes'])
        cfg,_=a.verify_small_assets()
        extra=a.analytical_envelope(cfg,retained_before_bytes=10)
        self.assertEqual(extra['retained_total_envelope_bytes'],b['new_artifact_envelope_bytes']+10)
    def test_source_lock_cannot_be_changed_by_release_fields(self):
        forged=replace(self.admission,blockers=(),execution_authorized=True,resource_qualified=True,tokenizer_verified=True)
        with self.assertRaisesRegex(a.OriginalExecutionHold,'source_locked'):
            forged.assert_execution_allowed()
    def test_native_loader_blocked_before_import_or_callback(self):
        with patch.object(run,'_verified_offline_tokenizer') as tokenizer:
            with self.assertRaises(a.OriginalExecutionHold):run._prepare_native(self.admission,None,None)
            tokenizer.assert_not_called()
        self.assertNotIn('torch',sys.modules)
    def test_run_creates_no_output_while_locked(self):
        target=c.HERE/'uncreated_original_model_free_test'
        self.assertFalse(target.exists())
        with self.assertRaises(a.OriginalExecutionHold):run.run_original(self.admission,target)
        self.assertFalse(target.exists())
    def test_guard_does_not_start_child_or_outputs(self):
        target=c.HERE/'uncreated_original_guard_test'
        with patch.object(guard.subprocess,'Popen') as spawn:
            with self.assertRaises(a.OriginalExecutionHold):guard.guard_once(self.admission,target)
            spawn.assert_not_called()
        self.assertFalse(target.exists())
    def test_cli_execute_is_hold_not_unlock(self):
        with patch.object(sys,'stdout',io.StringIO()) as stream:
            result=run.main(['--execute'])
            self.assertEqual(result,2)
            self.assertEqual(json.loads(stream.getvalue())['native_model_actions'],0)
        with patch.object(sys,'stdout',io.StringIO()) as stream:
            result=guard.main(['--execute'])
            self.assertEqual(result,2)
            self.assertFalse(json.loads(stream.getvalue())['child_started'])
    def test_loader_uses_meta_and_exact_assign_without_duplicate_resident_payload(self):
        text=Path(run.__file__).read_text();tree=ast.parse(text)
        calls=[node for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='load_state_dict']
        self.assertEqual(len(calls),1)
        values={arg.arg:arg.value for arg in calls[0].keywords}
        self.assertTrue(values['strict'].value)
        self.assertTrue(values['assign'].value)
        self.assertIn("with torch.device('meta')",text)
        self.assertIn('source_storage.restore_original_small_fp32',text)
        self.assertIn('model.tie_weights()',text)
        self.assertNotIn('.float()',text)
        self.assertNotIn('.from_pretrained(',text)
    def test_file_backed_pointer_proof(self):
        class Stat:st_dev=0x801;st_ino=42
        maps='1000-2000 rw-p 00000000 08:01 42 /verified/model.safetensors\n'
        self.assertTrue(run._source_mapped_extent(0x1100,64,0x100,Stat(),maps))
        self.assertFalse(run._source_mapped_extent(0x1100,64,0x101,Stat(),maps))
        self.assertFalse(run._source_mapped_extent(0x1fff,64,0xfff,Stat(),maps))
        self.assertFalse(run._source_mapped_extent(0x1100,64,0x100,Stat(),maps.replace('42','43')))
    def test_exact_source_loader_is_locked_before_model_or_safetensors(self):
        with self.assertRaises(a.OriginalExecutionHold):run._load_exact_source_once(self.admission,None,None,None,None)
        self.assertNotIn('torch',sys.modules)
        self.assertNotIn('safetensors',sys.modules)
    def test_guard_reuses_owned_wait4_truth(self):
        from guard_native_self_reuse_reconstructed import sample_or_reap
        self.assertIs(guard.sample_or_reap,sample_or_reap)

if __name__=='__main__':unittest.main()
