"""Source-only file-backed references: verified raw bytes, no model replay.

Private read/write mappings support torch.frombuffer while preserving immutable
on-disk evidence. Inactive clean pages are explicitly discarded. This is an
RSS-reduction implementation, not a demonstrated original-size memory bound.
"""
import copy,hashlib,mmap,time
from pathlib import Path

class MappedEvidence:
    def __init__(self,path,torch):
        self.path=Path(path);self.torch=torch;self.maps=[];self.bytes=0;self.hash_read_bytes=0
        self.restore_wall_seconds=0.;self.restore_cpu_seconds=0.;self.advice_calls=0;self.advice_wall_seconds=0.;self.advice_cpu_seconds=0.
    def tensor(self,receipt):
        if receipt['dtype']!='float32' or receipt['byte_order']!=__import__('sys').byteorder:raise ValueError('Unsupported mapped evidence representation')
        start=time.monotonic();cpu=time.process_time()
        file=self.path/receipt['path'];h=hashlib.sha256()
        with file.open('rb') as f:
            if file.stat().st_size!=receipt['bytes']:raise ValueError('Mapped raw extent differs')
            for block in iter(lambda:f.read(65536),b''):h.update(block);self.hash_read_bytes+=len(block)
            if h.hexdigest()!=receipt['sha256']:raise ValueError('Mapped raw bytes differ')
            if receipt['bytes']==0:return self.torch.empty(receipt['shape'],dtype=self.torch.float32)
            backing=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_COPY)
        self.maps.append(backing);self.bytes+=receipt['bytes']
        tensor=self.torch.frombuffer(backing,dtype=self.torch.float32).reshape(receipt['shape'])
        backing.madvise(mmap.MADV_DONTNEED)
        self.restore_wall_seconds+=time.monotonic()-start;self.restore_cpu_seconds+=time.process_time()-cpu
        return tensor
    def cache(self,original,fields):
        seen=set()
        def visit(value,path):
            if isinstance(value,self.torch.Tensor):
                if path not in fields:raise ValueError('Mapped cache missing field '+path)
                seen.add(path);return self.tensor(fields[path])
            if isinstance(value,dict):return {k:visit(v,path+'['+repr(k)+']') for k,v in value.items()}
            if isinstance(value,(tuple,list)):
                values=[visit(v,path+'['+str(i)+']') for i,v in enumerate(value)]
                return tuple(values) if isinstance(value,tuple) else values
            if type(value).__module__=='transformers.cache_utils':
                result=copy.copy(value)
                for key,item in vars(value).items():setattr(result,key,visit(item,path+'.'+key))
                return result
            return value
        result=visit(original,'cache')
        if seen!=set(fields):raise ValueError('Unused mapped cache fields')
        return result
    def tree(self,original,receipts,prefix):
        result={}
        for key,value in original.items():
            name=prefix+'.'+str(key)
            if isinstance(value,self.torch.Tensor):result[key]=self.tensor(receipts[name])
            elif isinstance(value,dict):result[key]=self.tree(value,receipts,name)
            else:result[key]=copy.deepcopy(value)
        return result
    def evict(self):
        # Private mappings must never be used as mutable native branch caches.
        # Discarding changed private pages would conceal mutations, so callers
        # only evict after immutable-reference comparisons/source integrity checks.
        start=time.monotonic();cpu=time.process_time()
        for backing in self.maps:backing.madvise(mmap.MADV_DONTNEED)
        wall=time.monotonic()-start;cpu=time.process_time()-cpu
        self.advice_calls+=1;self.advice_wall_seconds+=wall;self.advice_cpu_seconds+=cpu
        return {'mapped_virtual_bytes_advised':self.bytes,'wall_seconds':wall,'CPU_seconds':cpu,'RSS_reduction_measured':False}
    def summary(self):return {'mapped_virtual_bytes':self.bytes,'mappings':len(self.maps),'private_mapping':True,
        'hash_file_read_bytes':self.hash_read_bytes,'restore_wall_seconds':self.restore_wall_seconds,'restore_CPU_seconds':self.restore_cpu_seconds,
        'advice_calls':self.advice_calls,'advice_wall_seconds':self.advice_wall_seconds,'advice_CPU_seconds':self.advice_cpu_seconds,
        'inactive_pages_discarded_explicitly':True,'model_calls':0,'physical_page_fault_IO_bytes':'UNMEASURED',
        'RSS_reduction_measured':False,'copy_semantics':'Metadata copies only;private file-backed tensor views;kernel I/O is not assumed free'}
