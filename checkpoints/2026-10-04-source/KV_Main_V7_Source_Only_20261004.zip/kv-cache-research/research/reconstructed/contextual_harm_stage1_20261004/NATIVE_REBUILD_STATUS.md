# New reconstruction: native integration status

The baseline and earlier firststage code are new reconstructions, not recovered historical byte copies. The actual rebuilt paged engine is used by native_backend_reconstructed.py and contextual_native_reconstructed.py. Original/pretrained execution remains locked.

New attempt01 is a preserved engineering failure: the private 2.8-MB cost-journal cap was reached during Hctx/Q. Its external guard stayed within 500 MB (457,711,616 combined bytes), 7.05 seconds, with no external resource stop. The durable prefix records 28 root invocations and 27 returns / 581 attempted network tokens. All 586 completed live R/F32 and Hctx pre-Q comparisons passed, maximum absolute difference 8.642673492431641e-7. Hctx Q/remaining scoring were not completed, so the suite did not pass. Raw completed pre/post-Q caches and Q vectors are retained; no quality result exists.

Narrow source fixes replace repetitive per-lease rows with exact acquisition/release/cast-byte aggregates and bounded per-call provenance. Contextual operator counts and inclusive CPU/wall times are aggregated without pretending nested times are additive or estimating physical traffic. A model-free replay preserves the observed prefix counts and reduces 2,799,933 encoded bytes to 165,783. Arena cleanup and native evidence finalization preserve the primary exception when secondary reporting fails. Earlier files remain unchanged.

Corrected attempt02 is also preserved as failed/incomplete. It reached 28 completed root calls / 581 network tokens in 4.69 seconds at 459,644,928 combined HWM bytes, then the retained-output budget check stopped raw Hctx post-Q cache writing. Hctx candidate/greedy scoring was not run. No numerical mismatch was observed, but no complete integration pass is claimed. Its compact cost journal is 169,635 bytes; 242 prior raw blobs were reused only after verifying newly produced bytes and rehashing the stored blob. No file was deleted.

OUTPUT_INVENTORY_RECONSTRUCTED.json inventories 9,019,972 bytes before the inventory itself. The full intended raw payload is 3,601,408 bytes; 172,448 raw bytes remained unstored after attempt02. A whole fresh attempt without any dedup allowance would need at most 7,963,552 more bytes including bounded logs/reports. A prospective 20-MiB total cap would safely accommodate all prior evidence and that entire envelope; this arithmetic is not itself authority for another run. No further native test is running.

The eager CPU masks/attention implementation is a small numerical diagnostic. It is not a deployable long-context path: configuration arithmetic can place a 32K/8-head FP32 attention-score tensor near 32 GiB even when KV is much smaller. Any eventual single-card system needs an appropriate optimized attention path and new end-to-end quality, latency, peak-memory and complete amortized-cost evidence against current strong baselines. This package claims none of those results.

## Third attempt and final boundary

Parent prospectively admitted a 20-MiB total retained cap from the complete no-dedup payload envelope; RSS 500 MB, disk floor 5 GB, seed, shapes, inputs and tolerances stayed fixed. The third child completed 37 calls / 590 tokens and all 1,076 live controls passed. Maximum absolute cache/logit difference 8.642673492431641e-7; maximum native TV 1.491548573540058e-8. Its own report records 5.059 seconds and 443,912,192-byte child HWM. These are child observations, not a recovered external wait4 resource receipt.

The watchdog failed on a terminal process-state race (missing VmRSS after its first nonblocking wait4); the child report/raw outputs survived, but the guard's final receipt and sampling series did not. native_self_reuse_guard_03_incomplete.json preserves that qualification failure. The subsequent source fix resolves vanished/zombie metrics only through owned wait4 truth; six model-free race tests pass. No fourth model run was performed. Do not relabel this as a complete bounded-guard pass.

The new numerical child pass is supported by 37 terminal call summaries, 1,076 live comparisons and 365 raw-artifact references totaling 3,601,408 logical FP32 bytes. saved_raw_audit.json independently verifies all raw hashes/shapes/finiteness, 192 raw pre/post-Q cache-tensor comparisons and two Q-logit comparisons with stdlib arithmetic. Raw logits for other continuation/prefill steps were not archived; their evidence is native live comparisons, hashes and scalar summaries. This is a known d01/A1 tiny self-reuse result, not model competence, contextual harm, a restored historical pass, full 24 admission or deployability.

All earlier attempts remain preserved failures. Their time/resource/I/O work is separate from the successful child's numerical work; no excluded failed cost is folded into a serving-speed claim. Full original-weight recovery/admission and optimized long-context deployment remain separate open work.

## Source-only original first24 preparation after independent review

Canonical plans are now detached from callers and fixed in an immutable serialized
snapshot after recovered-freeze verification. Source capture requires the actual
active/completed group R/A1 B producer, including live ancestry/version checks.
The companion engine freezes official scalar attention_scaling. A complete
first24 coordinator, raw production evidence, verified file-backed reference/source
route, and source-locked original loader/guard have been prepared.

The current revision passed 138 model-free tests and all64 offline token/template
revalidation. No fourth tiny or original run was performed. These source changes
are therefore not covered by the third tiny numerical pass. Exact original
weights, resource/evidence-cap admission and an execution release remain blockers.
See ORIGINAL_ADMISSION_RECONSTRUCTED.md for the one-copy loader and the tight,
unmeasured 8,496,386,400-byte analytical envelope. Historical child/guard/raw files
were not rewritten. The old v6 manifest is preserved locally and in the prior
checkpoint; new source identity is provided by the current reconstruction manifest.

The later narrow guard correction restores the9 GB host unavailable-memory stop,
terminal non-RSS checks with receipt space, and retained-pidfd process-group
cleanup after leader reap. Independent source review closed all three defects;
14 new mocked tests and the full152-test model-free suite pass. A signal0 probe
only checked group-flag acceptance; no signal was delivered. No original or
fourth tiny experiment was run. Fresh reviewed checkpoint activation remains
prospective and does not qualify the older partial asset.
