# Original first24 admission and loader preparation

New source-only preparation, 2026-10-04. Original execution remains HOLD. No
original model construction (including meta construction), parameter loading,
forward, fourth tiny run, download, installation, or GPU work was performed.

## What is runnable now

The existing restored interpreter can run the model-free entry:

```sh
bash ../runtime_recovery_20261004/cpu_python.sh \
  run_original_stage1_reconstructed.py --validate-tokens
```

This rehashes the four pinned offline config/tokenizer/template assets and four
critical installed official runtime sources, then reproduces all 64 complete
prompt arrays, offset-based A/B/Q cuts, candidates with EOS, and official template
renderings. It imports tokenizers/Jinja only; Torch and Transformers imports are
rejected in this mode. The experiment uses chat EOS 248046 deliberately; the
config's 248044 default must never silently replace it. The observed all64 check
passed. Exit code 2 and `HOLD_ORIGINAL_FIRST24` are intentional, even when tokenizer
validation passes. Plain invocation performs only stdlib hash/layout/accounting.

`--execute` does not unlock anything. The immutable current source lock, missing
checkpoint, absent original resource qualification, and absent execution release
are independent blockers. No environment variable, receipt label, tiny pass, or
CLI flag constitutes original admission. A future release needs a separately
reviewed admission change binding the exact sources, genuine available resources,
complete retained-artifact envelope, and execution authority.

The exact `model.safetensors` is absent. The existing expected-size `.partial`
file is only an unverified preallocation from the blocked HTTP-403 recovery
attempt; neither its length nor a filename change can qualify it. A complete
future source must pass the existing strict stdlib header/coverage/dtype checks
and SHA-256 42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c.

## Prepared one-copy loader, not executed

After admission and before any model construction, the loader revalidates the
checkpoint and all64 tokenizer evidence. It then prepares the pinned official
text model on meta, with no resident weight allocation, assigns the 320 exact
local safetensors source tensors using strict `load_state_dict(assign=True)`, and
restores the official embedding/head tie. Source names use the existing exact
text-only mapping. Shape, dtype, key coverage, absence of extra persistent
buffers, actual file-backed `/proc/self/maps` extents, and unchanged assigned
storage pointers are required. A parser/loader that copies a source payload is
rejected instead of silently increasing the memory budget.

The existing source_storage helper restores only the 10,368 bytes of tiny source
FP32 values and official CPU FP32 RoPE buffers/scaling, then checks all 320
resident source tensors against the complete checkpoint. Residual meta buffers
are forbidden. Large source weights remain original BF16 storage; PagedArenaEngine
provides the established FP32 arithmetic route. There is no full model.float(),
BF16 arithmetic rescue, quantization, remote loader, or reconstructed weight.
This load route is prepared code, not evidence that original loading works.

## Resource arithmetic and practical reduction

The initial all-resident reference design had a 9,186,907,360-byte conservative
execution estimate and 8,752,047,488-byte duplicate-loader estimate. Those numbers
included deliberately explicit unqualified reserves; they were not measured OOMs
and did not prove the task impossible. The first saved preflight receipt retains
that earlier source-state estimate unchanged.

The prepared route now avoids duplicate weight payloads and file-backs persistent
F32/A1 reference banks and contextual sources. Inactive mappings must explicitly
discard resident pages; the current active mapping is always charged. Immediate
R references are consumed/released at the corresponding F32 endpoint. Mapping a
saved bank evicts each tensor immediately after verification, rather than
faulting the complete bank into RSS at once.

Current conservative analytical account:

- Original source-resident payload: 3,763,655,360 bytes
- Shared FP32 arena: 2,034,237,440 bytes
- Maximum complete cache: 26,664,960 bytes, using maximum sequence length 245
- Anonymous cache ceiling: 24 (12 current R reference endpoints, 8 working/helper
  caches, 4 source-capture caches), plus 1 active mapped reference cache and
  2 active mapped source caches
- One active source trace/factor/suffix set, six eager materialized masks,
  attention/projection/MLP and affine temporaries, retained/working logits,
  16 MiB hash/serialization staging, and 10,368-byte FP32 restoration copy
- Tensor payload plus explicit operator estimates: 6,751,555,936 bytes
- Additional assumptions: 1 GiB runtime/tokenizer/allocator, 128 MiB guard, and
  512 MiB native workspace reserves, totaling 1,744,830,464 bytes
- Execution envelope: 8,496,386,400 bytes; one-copy loader envelope: 4,988,402,496
- Analytical headroom below the unchanged 8 GiB guard: 93,548,192 bytes

These remain assumptions, with tight headroom. Native workspaces, allocator
retention, the future source-backed loader, page-discard behavior, and original
peak RSS are unqualified. The code therefore refuses execution rather than
turning analytical fit or tiny RSS into admission. The 9 GB host budget,
30-minute overall limit, 15-minute load limit, one CPU process, and 5 GB free
storage floor remain unchanged.

## Retained evidence envelope

The prepared production store retains all 24 pre-Q caches, two incoming source-A
caches, all 308 possible root-call full logit vectors, source operands/halos,
block-19/20 input/output traces, suffix T/U/normalized-q, and terminal/cost/control
metadata. Source pre-Q caches link to their existing R/A1 artifacts. Persistent
F32/A1 references add 21 cache endpoint artifacts after the two pre-Q duplicates
are removed; their logits reuse existing all-call blobs.

The conservative raw-artifact cap is 1,820,309,504 bytes. The complete new-attempt
envelope is 1,971,304,448 bytes after 64 MiB journal, 64 MiB terminal/metadata, and
16 MiB guard-log reserves. All old retained files must also be charged before a
run. The 2 GiB whole-retained ceiling is a proposal requiring explicit admission,
not a silent change to the old tiny-run 20 MiB cap or permission to delete proof.
The live store receives the raw cap; the external guard checks total retained
bytes and reserves the entire new envelope plus the unchanged free-disk floor.

## Guard and teardown truth

The new guard uses the corrected existing `sample_or_reap` helper: only owned
`wait4` truth resolves disappeared/zombie process metrics and supplies terminal
RSS/CPU usage. Missing live metrics fail closed. Any unexpected descendant is
charged, rejected, and stopped with the owned process group. Wall, load, retained
bytes, free disk, and combined guard/child HWM are independently checked. Receipt,
log, output directory, and sample journal must be new; no automatic retry exists.

The loader owns PagedArenaEngine context exit and a fallback remove path, closes
evidence unconditionally, preserves the primary error separately from cleanup
failures, and records loader failures. Guard qualification and scientific cell
results remain separate. Neither this source nor its tests repairs the missing
terminal receipt of the third tiny child or relabels prior failures.

## Checks completed

Fifteen stdlib-only tests cover fixed accounting, extra artifact counts, exact
asset layout, file-backed extent arithmetic, source-lock behavior before native
imports/model actions/output creation, strict meta/assign source structure, and
reuse of owned wait4 truth. Offline all64 token/template validation also passed
with installed assets. No native numerical test was executed.
