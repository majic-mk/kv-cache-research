"""Model-free checks for the one-attempt activation token and CLI-inclusive timer."""
import json,os,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as O
from unittest.mock import patch
import original_admission_reconstructed as a
import guard_original_stage1_reconstructed as g
from test_original_guard_revision_reconstructed import LIMITS,BOUNDS
class Tests(unittest.TestCase):
    def test_expired_initial_preflight_blocks_child(self):
        admission=O(assert_execution_allowed=lambda:None,limits=LIMITS,bounds=BOUNDS)
        with patch.object(g.time,'monotonic',return_value=1800),patch.object(g.subprocess,'Popen') as spawn:
            with self.assertRaisesRegex(a.OriginalExecutionHold,'preflight exhausted'):
                g.guard_once(admission,g.c.HERE/'never_started_expired_test',started=0)
            spawn.assert_not_called()
    def test_main_passes_clock_started_before_preflight(self):
        seen=[]
        admission=O()
        with patch.object(g.time,'monotonic',side_effect=lambda:(seen.append('clock'),10)[1]),patch.object(g,'preflight',side_effect=lambda *x,**k:(seen.append('preflight'),admission)[1]),patch.object(g,'retained_bytes',return_value=0),patch.object(g,'guard_once',return_value={'status':'PASS_ORIGINAL_FIRST24_PROCESS_GUARD'}) as run,patch('sys.stdout'):
            self.assertEqual(g.main(['--execute']),0)
            self.assertEqual(seen[:2],['clock','preflight']);self.assertEqual(run.call_args.kwargs['started'],10)
    def test_exact_release_token_only_and_resource_remains_unmeasured(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);path=root/'release.json'
            row=dict(kind='ONE_ORIGINAL_FIRST24_BOUNDED_EMPIRICAL_RELEASE',attempt_count=1,source_sha256='source',limits=dict(a.LIMITS),root_model_calls_max=308,network_tokens_max=4840,derived_sha256=a.DERIVED_SHA256,asset_directory=str(root),resource_behavior_measured=False,automatic_retry=False)
            path.write_text(json.dumps(row));token=a.c.sha(path)
            with patch.object(a,'RELEASE_MANIFEST',path),patch.object(a,'REVIEWED_ASSET_DIRECTORY',root),patch.dict(os.environ,{'RECONSTRUCTED_ORIGINAL_RELEASE_SHA256':token}):
                self.assertTrue(a.bounded_release_matches(root,'source'))
                self.assertFalse(a.bounded_release_matches(root,'changed'))
                self.assertFalse(a.bounded_release_matches(root/'wrong','source'))
                row['resource_behavior_measured']=True;path.write_text(json.dumps(row));self.assertFalse(a.bounded_release_matches(root,'source'))
    def test_no_token_cannot_unlock(self):
        with patch.dict(os.environ,{},clear=True):self.assertFalse(a.bounded_release_matches(a.REVIEWED_ASSET_DIRECTORY,'any'))
if __name__=='__main__':unittest.main(verbosity=2)
