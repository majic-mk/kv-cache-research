"""NEW stdlib-only original first24 admission. Import/preflight cannot load a model.

The analytical envelope is deliberately conservative, not an observed RSS bound.
Tiny receipts never admit the original. This checked-in version is source locked:
no command line switch, environment variable, or release JSON can unlock it.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import importlib.util
import json
import os
from pathlib import Path
from types import MappingProxyType
import contract_reconstructed as c

ORIGINAL_EXECUTION_LOCKED = True
MODEL_REVISION = '15852e8c16360a2fea060d615a32b45270f8a8fc'
DERIVED_SHA256 = '42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c'
DERIVED_BYTES = 3_763_696_896
SOURCE_PARAMETER_BYTES = 3_763_655_360
ARENA_BYTES = 2_034_237_440
ASSET_DIRECTORY = c.REPO/'outputs/model_assets_recovery_20261004/Qwen3.5-2B-derived-text'
RUNTIME_DIRECTORY = c.HERE.parent/'runtime_recovery_20261004'
SMALL_ASSETS = {
    'config.json': (2908, 'ed1c1723241f23f7f4e23430759cbd7dcfb4103cbdfe052bfe7626b57c2615b4'),
    'tokenizer.json': (12807982, '5f9e4d4901a92b997e463c1f46055088b6cca5ca61a6522d1b9f64c4bb81cb42'),
    'tokenizer_config.json': (16709, '49e2b6e395f959f077f1e992b338919c0d4a9732fc6e613995e06557f843500c'),
    'chat_template.jinja': (7755, '273d8e0e683b885071fb17e08d71e5f2a5ddfb5309756181681de4f5a1822d80'),
}
MiB = 1024**2
LIMITS = MappingProxyType(dict(combined_rss_hwm_bytes=8*1024**3,
    host_budget_bytes=9_000_000_000, wall_seconds=1800, load_seconds=900,
    disk_floor_bytes=5_000_000_000, sample_interval_seconds=1,
    retained_artifact_cap_bytes=2*1024**3))

class OriginalExecutionHold(RuntimeError):
    pass


RELEASE_MANIFEST = c.HERE/'original_first24_retry_release_20261004.json'
REVIEWED_ASSET_DIRECTORY = c.REPO/'outputs/model_assets_recovery_20261004_reviewed/Qwen3.5-2B-derived-text'

def bounded_release_matches(directory,source_sha256):
    """Only the parent-confirmed SHA token for this exact one-attempt release.

    Does not qualify unmeasured original resource behavior. Without the explicit
    launch token, the reviewed source hardlock remains effective.
    """
    token=os.environ.get('RECONSTRUCTED_ORIGINAL_RELEASE_SHA256')
    if not token or len(token)!=64:return False
    try:
        if c.sha(RELEASE_MANIFEST)!=token:return False
        r=c.read(RELEASE_MANIFEST)
        return (r['kind']=='ONE_ORIGINAL_FIRST24_BOUNDED_EMPIRICAL_RELEASE'
            and r['attempt_count']==1 and r['source_sha256']==source_sha256
            and r['limits']==dict(LIMITS) and r['root_model_calls_max']==308
            and r['network_tokens_max']==4840 and r['derived_sha256']==DERIVED_SHA256
            and Path(r['asset_directory']).resolve()==Path(directory).resolve()==REVIEWED_ASSET_DIRECTORY.resolve()
            and r['resource_behavior_measured'] is False and r['automatic_retry'] is False)
    except (OSError,ValueError,KeyError,TypeError):return False


def _load_contracts():
    path = c.HERE.parent/'paged_fp32_engine_20261004/contracts.py'
    name = '_original_source_manifest_contracts'
    import sys
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def source_pins():
    paths = list(c.HERE.glob('*.py')) + list((c.HERE.parent/'paged_fp32_engine_20261004').glob('*.py'))
    paths += [RUNTIME_DIRECTORY/'cpu_python.sh']
    paths += [c.REPO/name for name in c.input_pins()]  # Frozen protocol inputs are part of this execution identity too.
    return {str(p.relative_to(c.REPO)): c.sha(p) for p in sorted(paths)}


def verify_runtime_source_layout():
    """Bound restored runtime paths/hashes without importing native/model modules."""
    base=RUNTIME_DIRECTORY/'.venv/lib/python3.12/site-packages/transformers'
    expected={
        'models/qwen3_5/modeling_qwen3_5.py':'f3fecce29dee6cea1ac951c947a538fdcf01abfc21f8f0e33a78b535fe6837c3',
        'models/qwen3_5/configuration_qwen3_5.py':'2f26c4bb911772d42a5f16e82bdea4b9ba1ac07872df527ec228622d35f3c30e',
        'cache_utils.py':'2d2ab17aa02c9d2a993587ec58d1745b03595b6028c401cc6c976bb720ad6638',
        'modeling_utils.py':'3a32f432917a1265fc3f26b2a36032b047b9c4d367ea75a5c8d389b1d268cda0',
    }
    for relative,digest in expected.items():
        if c.sha(base/relative)!=digest:raise ValueError('Restored official runtime source changed: '+relative)
    if not (RUNTIME_DIRECTORY/'.venv/bin/python').is_file():
        raise ValueError('Restored interpreter is absent')
    return expected


def verify_small_assets(directory=ASSET_DIRECTORY):
    """Hash original config/tokenizer/template, with no tokenizer/native import."""
    directory = Path(directory)
    actual = {}
    for name, (size, expected) in SMALL_ASSETS.items():
        path = directory/name
        if not path.is_file() or path.is_symlink() or path.stat().st_size != size or c.sha(path) != expected:
            raise ValueError('Missing/changed pinned offline asset: '+name)
        actual[name] = dict(bytes=size, sha256=expected)
    if (directory/'model.safetensors.index.json').exists():
        raise ValueError('Full multimodal index must remain outside text loader directory')
    cfg = c.read(directory/'config.json')['text_config']
    if (cfg['num_hidden_layers'],cfg['hidden_size'],cfg['vocab_size']) != (24,2048,c.VOCAB):
        raise ValueError('Original architecture identity differs')
    template = c.read(c.V3/'template.json')
    if template['model_id'] != 'Qwen/Qwen3.5-2B' or template['revision'] != MODEL_REVISION:
        raise ValueError('Protocol model identity differs')
    tok = c.read(directory/'tokenizer_config.json')
    if tok['chat_template'] != (directory/'chat_template.jinja').read_text():
        raise ValueError('Offline tokenizer/template bytes disagree')
    if tok.get('bos_token') is not None or tok.get('add_bos_token',False):
        raise ValueError('Unexpected BOS configuration')
    for text, token in template['required_special_token_ids'].items():
        if tok['added_tokens_decoder'][str(token)]['content'] != text:
            raise ValueError('Special-token identity differs')
    # Official text-config EOS 248044 is not this experiment's chat EOS 248046.
    # Never silently use model.generate's default EOS instead of the frozen IDs.
    if template['required_special_token_ids']['<|im_end|>'] != c.EOS:
        raise ValueError('Experiment EOS differs')
    c.verify_recovered_freezes()
    c.recovered_contexts()
    return cfg, actual


def verify_checkpoint_layout(directory=ASSET_DIRECTORY):
    """The exact complete file and bounded stdlib header/hash checks are required."""
    path = Path(directory)/'model.safetensors'
    if not path.is_file() or path.is_symlink():
        raise OriginalExecutionHold('Exact model.safetensors absent; .partial preallocation is not an asset')
    records = _load_contracts().read_source_manifest(path,require_2b=True)
    return dict(path=str(path.resolve()),sha256=DERIVED_SHA256,bytes=DERIVED_BYTES,
                tensor_count=len(records),payload_bytes=sum(r.nbytes for r in records),
                source_parameter_elements=sum(r.numel for r in records),
                dtype_counts={d:sum(r.dtype==d for r in records) for d in ('BF16','F32')})


def analytical_envelope(cfg, *, retained_before_bytes=0):
    """Account fixed graph, including immutable reference banks and clone peaks.

    Full-size current workspace costs are NOT qualified by this calculation.
    Exact source assignment requires file-backed tensor pointer identity, avoiding
    a second resident payload. Inactive evidence mappings are explicitly evicted;
    active mapped source/reference pages remain charged. Tiny RSS proves nothing.
    """
    if type(retained_before_bytes) is not int or retained_before_bytes < 0:
        raise ValueError('Invalid retained evidence size')
    cells = c.plan()
    rows = [r for r in c.recovered_contexts() if r['pair_id'] in c.GROUPS]
    max_sequence = max(len(r['input_ids'])+c.GREEDY_CAP-1 for r in rows)
    max_b = max(len(r['B_ids']) for r in rows)
    max_a = max(len(r['A_ids']) for r in rows)
    max_call = max(r['network_tokens'] for x in cells for r in x['calls'])
    linear = cfg['layer_types'].count('linear_attention')
    full = cfg['layer_types'].count('full_attention')
    kh,vh,kd,vd = (cfg[k] for k in ('linear_num_key_heads','linear_num_value_heads','linear_key_head_dim','linear_value_head_dim'))
    conv = cfg['linear_conv_kernel_dim']; channels = 2*kh*kd+vh*vd
    state_bytes = 4*linear*(vh*kd*vd+channels*conv)
    def cache_bytes(tokens):
        return state_bytes+4*full*2*cfg['num_key_value_heads']*cfg['head_dim']*tokens
    def endpoints(cell):
        return 1+sum(r['label']=='Q' or r['branch_id']=='greedy' or r['branch_id'].startswith('candidate:') for r in cell['calls'])
    retained_f32 = sum(endpoints(x) for x in cells if x['arm']=='F32' and x['variant']=='A1')
    current_r = max(endpoints(x) for x in cells if x['arm']=='R')
    # Four pinned source caches: two source A and two source preQ. Current native
    # root/nodes, candidate clone pairs, assembly/capture helper clones: eight.
    source_caches = 4; helper_caches = 8
    anonymous_caches = current_r+source_caches+helper_caches
    mapped_reference_caches = 1; mapped_source_caches = 2
    live_caches = anonymous_caches+mapped_reference_caches+mapped_source_caches
    full_cache = cache_bytes(max_sequence)
    source_operands = 4*linear*(max_b*(2*kh*kd+vh*vd+2*vh)+(3*conv-1)*channels)
    block_traces = 4*2*2*max_b*cfg['hidden_size']
    suffix = 4*linear*(vh*kd*kd+vh*kd*vd+(max_b-c.WIDTH)*kh*kd)
    source_trace_one = source_operands+block_traces+suffix
    # All six materialized eager masks are retained until a call returns.
    masks = 4*full*max_call*max_sequence
    # Two live attention intermediates per head plus projection/MLP activations;
    # add a 512MiB unqualified native workspace reserve, not a proven upper bound.
    attention_workspace = 4*2*cfg['num_attention_heads']*max_call*max_sequence
    activation_estimate = 4*max_call*(8*cfg['hidden_size']+4*cfg['intermediate_size']+4*channels)
    affine_temporary = 4*8*vh*max(kd*kd,kd*vd)+4*4*(max_b-c.WIDTH)*vh*max(kd,vd)
    logit_bytes = c.VOCAB*4
    live_logits = current_r+helper_caches+4+1
    runtime_reserve = 1024**3; guard_reserve = 128*MiB; native_reserve = 512*MiB
    hash_io = 16*MiB
    components = dict(source_resident_bytes=SOURCE_PARAMETER_BYTES,fp32_arena_bytes=ARENA_BYTES,
        restored_small_source_F32_copy_bytes=10_368,anonymous_live_cache_bytes=anonymous_caches*full_cache,
        active_mapped_reference_cache_bytes=mapped_reference_caches*full_cache,
        active_mapped_source_cache_bytes=mapped_source_caches*full_cache,
        active_source_trace_and_suffix_bytes=source_trace_one,
        six_eager_masks_bytes=masks,attention_workspace_bytes=attention_workspace,
        projection_mlp_activation_estimate_bytes=activation_estimate,affine_temporary_bytes=affine_temporary,
        retained_and_working_logits_bytes=live_logits*logit_bytes,hash_serialization_staging_bytes=hash_io,
        runtime_tokenizer_allocator_reserve_bytes=runtime_reserve,guard_reserve_bytes=guard_reserve,
        unqualified_native_workspace_reserve_bytes=native_reserve)
    execution = sum(components.values())
    load = SOURCE_PARAMETER_BYTES+10_368+runtime_reserve+guard_reserve+hash_io
    reference_cache_artifacts = retained_f32-len(c.GROUPS)
    raw = (24+reference_cache_artifacts)*full_cache+2*cache_bytes(max_a)+2*source_trace_one+len([r for x in cells for r in x['calls']])*logit_bytes
    # The raw cache estimate intentionally uses maximum sequence for all 24.
    journals = 64*MiB; terminal_and_metadata = 64*MiB; guard_log = 16*MiB
    artifact = raw+journals+terminal_and_metadata+guard_log
    return dict(c.work_bounds(),max_sequence_tokens=max_sequence,max_call_tokens=max_call,
        cache_bytes_max=full_cache,retained_f32_a1_endpoints_max=retained_f32,current_r_endpoints_max=current_r,
        working_and_helper_cache_count_max=helper_caches,source_cache_count_max=source_caches,
        complete_live_cache_count_max=live_caches,anonymous_live_cache_count_max=anonymous_caches,
        active_mapped_reference_cache_count_max=mapped_reference_caches,active_mapped_source_cache_count_max=mapped_source_caches,
        cache_live_bytes_max=live_caches*full_cache,
        logit_vector_bytes=logit_bytes,source_trace_and_suffix_bytes_per_group=source_trace_one,
        execution_components=components,analytical_execution_envelope_bytes=execution,
        explicit_runtime_guard_workspace_reserve_bytes=runtime_reserve+guard_reserve+native_reserve,
        known_payload_and_operator_estimate_bytes=execution-runtime_reserve-guard_reserve-native_reserve,
        analytical_headroom_under_8GiB_bytes=LIMITS['combined_rss_hwm_bytes']-max(execution,load),
        analytical_loader_envelope_bytes=load,analytical_combined_envelope_bytes=max(execution,load),
        raw_artifact_bytes_max=raw,journal_cap_bytes=journals,metadata_reserve_bytes=terminal_and_metadata,
        guard_log_reserve_bytes=guard_log,new_artifact_envelope_bytes=artifact,
        retained_before_bytes=retained_before_bytes,retained_artifact_cap_bytes=LIMITS['retained_artifact_cap_bytes'],
        retained_total_envelope_bytes=retained_before_bytes+artifact,
        extra_source_incoming_A_artifacts=2,extra_file_backed_reference_cache_artifacts=reference_cache_artifacts,
        source_preQ_disk_duplication=False,persistent_F32_reference_banks_file_backed=True,
        inactive_evidence_mapping_eviction_required=True,source_loader_route='meta_assign_exact_source_backing',
        source_payload_resident_copies_max=1,
        additional_continuation_cache_clones_charged=True,tiny_RSS_used_for_admission=False,
        native_workspace_qualified=False,loader_peak_qualified=False,
        analytical_fits_existing_memory_cap=max(execution,load)<LIMITS['combined_rss_hwm_bytes'],
        analytical_fits_existing_host_budget=max(execution,load)<LIMITS['host_budget_bytes'],
        retained_evidence_fits_proposed_cap=retained_before_bytes+artifact<LIMITS['retained_artifact_cap_bytes'])


@dataclass(frozen=True)
class OriginalAdmission:
    asset_directory: Path
    bounds: dict
    asset_checks: dict
    source_sha256: str
    blockers: tuple
    limits: dict = field(default_factory=lambda:dict(LIMITS))
    tokenizer_verified: bool = False
    execution_authorized: bool = False
    resource_qualified: bool = False
    guarded_empirical_release: bool = False

    def assert_execution_allowed(self):
        if type(self) is not OriginalAdmission:
            raise OriginalExecutionHold('Exact OriginalAdmission object required')
        bounded_release=bounded_release_matches(self.asset_directory,self.source_sha256)
        reasons = list(self.blockers)
        if ORIGINAL_EXECUTION_LOCKED and not bounded_release: reasons.insert(0,'source_locked_original_execution')
        if not self.execution_authorized or not bounded_release: reasons.append('explicit_original_first24_execution_release_absent')
        if not self.resource_qualified and not (self.guarded_empirical_release and bounded_release): reasons.append('original_loader_and_native_workspace_not_resource_qualified')
        if reasons: raise OriginalExecutionHold('HOLD_ORIGINAL_FIRST24: '+'; '.join(dict.fromkeys(reasons)))
        if self.source_sha256 != c.digest(source_pins()):
            raise OriginalExecutionHold('HOLD_ORIGINAL_FIRST24: source changed since admission')
        return self

    def as_dict(self):
        return dict(status='ADMITTED_BOUNDED_EMPIRICAL_FIRST24' if self.execution_authorized and not self.blockers else 'HOLD_ORIGINAL_FIRST24',source_locked=ORIGINAL_EXECUTION_LOCKED,
            source_lock_bypassed_by_bound_release=self.guarded_empirical_release,
            execution_authorized=self.execution_authorized,resource_qualified=self.resource_qualified,
            guarded_empirical_release=self.guarded_empirical_release,
            tokenizer_verified=self.tokenizer_verified,
            tokenizer_all64_context_count=64 if self.tokenizer_verified else None,
            asset_directory=str(self.asset_directory),asset_checks=self.asset_checks,bounds=self.bounds,
            limits=self.limits,source_sha256=self.source_sha256,blockers=list(self.blockers),
            model_constructed=False,model_loaded=False,model_forward_executed=False,
            native_tests_run=False,weight_download_attempted=False)


def preflight(directory=ASSET_DIRECTORY, *, retained_before_bytes=0):
    cfg, assets = verify_small_assets(directory)
    assets['restored_runtime_source_files']=verify_runtime_source_layout()
    blockers = []
    try: assets['checkpoint'] = verify_checkpoint_layout(directory)
    except (ValueError,OSError,OriginalExecutionHold) as exc:
        assets['checkpoint'] = dict(status='MISSING_OR_UNVERIFIED',reason=str(exc))
        blockers.append('exact_original_checkpoint_missing_or_unverified')
    bounds = analytical_envelope(cfg,retained_before_bytes=retained_before_bytes)
    if not bounds['analytical_fits_existing_memory_cap']:
        blockers.append('conservative_original_envelope_exceeds_8GiB_limit')
    if not bounds['analytical_fits_existing_host_budget']:
        blockers.append('conservative_original_envelope_exceeds_9GB_host_budget')
    if not bounds['retained_evidence_fits_proposed_cap']:
        blockers.append('retained_evidence_exceeds_proposed_cap')
    source_sha256=c.digest(source_pins())
    released=bounded_release_matches(directory,source_sha256)
    if not released:blockers += ['no_qualified_original_load_or_workspace_bound','retained_evidence_cap_is_proposal_not_authorization']
    return OriginalAdmission(Path(directory).resolve(),bounds,assets,source_sha256,tuple(blockers),
        execution_authorized=released,guarded_empirical_release=released,resource_qualified=False)
