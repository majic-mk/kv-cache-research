"""NEW reconstructed scoring/stop orchestration; no native backend recovered.

Backend arithmetic, native clone validation and metered forward primitives are
explicit dependencies. Spy tests cover order/stopping only, never FP32 parity.
"""
from __future__ import annotations
import copy,math,re
import contract_reconstructed as contract

class ScoringFailure(RuntimeError):
    def __init__(self,kind,detail,*,category='integrity',partial=None):
        super().__init__(kind+': '+str(detail));self.kind=kind;self.detail=detail
        self.category=category;self.partial=copy.deepcopy(partial)

def normalized_correct(text,gold,ended):
    if not ended:return False
    text=text.strip().casefold()
    return bool(re.fullmatch(r'[a-z]+[.!?]?',text)) and text.rstrip('.!?')==gold

def finite(x):return type(x) in (float,int) and math.isfinite(x)

def score_post_q_with_backend(cell,post_q,backend,*,exact_reference=None,observe=lambda *args:None):
    """Backend interface is a trust boundary, NOT proof of native execution.

    Requires logits/cache(output), signature(value), clone_owned(cache,purpose),
    assert_clone(source,clone), logprob_fp32(logits,token), sum_fp32(values),
    margin_fp32(gold,other), argmax_with_gap(logits), forward(ids,cache,purpose,start),
    and decode(ids). Caller must bind forward to the frozen plan, actual ancestry,
    cost ledger and native masks/positions/dtypes; none is replaced by this API.
    """
    frozen=next((c for c in contract.plan() if c['cell_id']==cell.get('cell_id')),None)
    if frozen is None or any(cell.get(k)!=frozen[k] for k in ('candidates','expected_answer','A_tokens','B_tokens','Q_tokens')):
        raise ScoringFailure('changed_scoring_inputs',cell.get('cell_id'))
    candidates=cell['candidates'];limits=contract.numerical_limits()
    partial=dict(candidate_scores={},candidate_per_token_logprobs={},gold_logprob=None,gold_margin=None,
        raw_greedy_ids=[],top_two_margins=[],eos_within_cap=None,decoded_answer=None,
        statuses={**{'candidate:'+a:'not_run' for a in candidates},'margin':'not_run','greedy':'not_run','decode':'not_run'},
        comparisons=[],observed_endpoints=[],continuation_calls=0,current='post_Q',first_failure=None)
    base=backend.cache(post_q);first=backend.logits(post_q);source_signature=backend.signature((base,first))
    total=cell['A_tokens']+cell['B_tokens']+cell['Q_tokens']
    def stop(kind,detail,category='integrity'):
        raise ScoringFailure(kind,detail,category=category,partial=partial)
    def control(kind,actual,expected,threshold=None):
        passed=actual==expected if threshold is None else abs(actual-expected)<threshold
        row=dict(kind=kind,actual=actual,reference=expected,strict_threshold=threshold,passed=passed)
        partial['comparisons'].append(row)
        if not passed:stop(kind,row,'numerical')
    def endpoint(label,out):
        observe(label,backend.cache(out),backend.logits(out));partial['observed_endpoints'].append(label)
    def branch(purpose):
        clone=backend.clone_owned(base,purpose)
        if backend.assert_clone(base,clone) is not True:stop('clone_ownership',purpose)
        return clone
    def forward(token,cache,label,start):
        if token==contract.EOS:stop('EOS_forward_forbidden',label)
        partial['continuation_calls']+=1
        out=backend.forward([token],cache,label,start);endpoint(label,out);return out
    try:
        if exact_reference is not None:
            ids=exact_reference.get('raw_greedy_ids')
            if (list(exact_reference.get('candidate_scores',{}))!=list(candidates) or
                any(not finite(x) or x>0 for x in exact_reference['candidate_scores'].values()) or
                not finite(exact_reference.get('gold_margin')) or not isinstance(ids,list) or not 1<=len(ids)<=8 or
                any(type(x)!=int or not 0<=x<contract.VOCAB for x in ids) or contract.EOS in ids[:-1] or
                (ids[-1]!=contract.EOS and len(ids)!=8) or exact_reference.get('eos_within_cap') is not (ids[-1]==contract.EOS)):
                stop('invalid_exact_reference','Malformed scalar/ID/EOS reference')
        endpoint('post_Q',post_q)
        for answer,ids in candidates.items():
            key='candidate:'+answer;partial['current']=key;partial['statuses'][key]='running'
            cache=branch('candidate_'+answer);logits=first;values=[]
            partial['candidate_per_token_logprobs'][answer]=values
            for j,token in enumerate(ids):
                value=backend.logprob_fp32(logits,token)
                if not finite(value) or value>0:stop('nonfinite_logprob',answer,'numerical')
                values.append(float(value))
                if j<len(ids)-1:
                    out=forward(token,cache,f'candidate_{answer}_{j+1}',total+j)
                    cache,logits=backend.cache(out),backend.logits(out)
            score=backend.sum_fp32(values)
            if not finite(score) or score>0:stop('nonfinite_candidate_sum',answer,'numerical')
            partial['candidate_scores'][answer]=float(score)
            if answer==cell['expected_answer']:partial['gold_logprob']=float(score)
            if exact_reference is not None:
                control('candidate_sum',score,exact_reference['candidate_scores'][answer],limits['candidate_sum_logprob_delta_abs_strictly_below'])
            partial['statuses'][key]='completed'
        partial['current']='margin';partial['statuses']['margin']='running'
        gold=cell['expected_answer'];other=next(a for a in candidates if a!=gold)
        margin=backend.margin_fp32(partial['candidate_scores'][gold],partial['candidate_scores'][other])
        if not finite(margin):stop('nonfinite_margin',gold,'numerical')
        partial['gold_margin']=float(margin)
        if exact_reference is not None:control('candidate_margin',margin,exact_reference['gold_margin'],limits['candidate_margin_delta_abs_strictly_below'])
        partial['statuses']['margin']='completed';partial['statuses']['greedy']='running';partial['current']='greedy'
        cache=branch('greedy');logits=first
        for j in range(contract.GREEDY_CAP):
            token,gap=backend.argmax_with_gap(logits)
            if type(token)!=int or not 0<=token<contract.VOCAB or not finite(gap) or gap<0:stop('invalid_greedy_token',token)
            partial['raw_greedy_ids'].append(token);partial['top_two_margins'].append(float(gap))
            ended=token==contract.EOS
            if exact_reference is not None:
                expected=exact_reference['raw_greedy_ids'];want=expected[j] if j<len(expected) else None
                control('greedy_ID_before_next_forward',token,want)
                control('greedy_EOS_before_next_forward',ended,want==contract.EOS)
            if ended or j==contract.GREEDY_CAP-1:break
            out=forward(token,cache,f'greedy_{j+1}',total+j)
            cache,logits=backend.cache(out),backend.logits(out)
        partial['eos_within_cap']=ended
        if exact_reference is not None:
            control('greedy_sequence_length',len(partial['raw_greedy_ids']),len(exact_reference['raw_greedy_ids']))
            control('EOS_within_cap',ended,exact_reference['eos_within_cap'])
        partial['statuses']['greedy']='completed';partial['statuses']['decode']='running';partial['current']='decode'
        ids=partial['raw_greedy_ids'];text=backend.decode(ids[:-1] if ended else ids)
        if not isinstance(text,str):stop('decode_type',type(text).__name__)
        partial['decoded_answer']=text;partial['statuses']['decode']='completed'
        if backend.signature((base,first))!=source_signature:stop('post_Q_source_mutated',cell['cell_id'])
        partial.update(normalized_answer_correct=normalized_correct(text,gold,ended),strict_gold_token_equality=ids==candidates[gold])
        return partial
    except BaseException as exc:
        partial['first_failure']=dict(type=type(exc).__name__,message=str(exc),stage=partial['current'])
        for key,status in partial['statuses'].items():
            if status=='running':partial['statuses'][key]='failed'
            elif status=='not_run':partial['statuses'][key]='not_run_gate'
        if isinstance(exc,ScoringFailure):exc.partial=copy.deepcopy(partial);raise
        raise ScoringFailure('backend_failure',repr(exc),partial=partial) from exc
