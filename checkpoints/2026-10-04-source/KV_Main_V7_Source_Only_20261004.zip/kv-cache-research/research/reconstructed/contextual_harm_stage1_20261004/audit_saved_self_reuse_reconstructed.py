"""Independent stdlib raw-artifact audit; no model, tokenizer or tensor runtime."""
import array,hashlib,json,math,sys
from pathlib import Path
import contract_reconstructed as c

def values(record):
    path=(c.HERE/record['path']).resolve()
    if not path.is_relative_to(c.HERE) or record['dtype']!='float32':raise ValueError('Unexpected raw artifact path/dtype')
    raw=path.read_bytes()
    if len(raw)!=record['bytes'] or len(raw)!=4*math.prod(record['shape']) or hashlib.sha256(raw).hexdigest()!=record['sha256']:raise ValueError('Raw artifact length/hash/shape mismatch')
    numbers=array.array('f');numbers.frombytes(raw)
    if record['byte_order']!=sys.byteorder:numbers.byteswap()
    if any(not math.isfinite(x) for x in numbers):raise ValueError('Nonfinite saved raw operand')
    return numbers

def audit():
    report=c.read(c.HERE/'native_self_reuse_attempt_03/report.json');art=report['raw_artifacts'];rows=[]
    for record in art.values():values(record)
    for a,b in (('F32','R'),('Hctx32','F32')):
        for phase in ('preQ','postQ'):
            aa={r['cache_field']:r for n,r in art.items() if n.startswith(a+'_'+phase+'_')}
            bb={r['cache_field']:r for n,r in art.items() if n.startswith(b+'_'+phase+'_')}
            if set(aa)!=set(bb) or len(aa)!=48:raise ValueError('Incomplete complete-cache raw scope')
            for field,x in aa.items():
                y=bb[field]
                if x['shape']!=y['shape']:raise ValueError('Raw cache shapes differ')
                u,v=values(x),values(y);R='recurrent_states' in field;lim=c.numerical_limits()
                atol=lim['endpoint_recurrent_atol' if R else 'endpoint_conv_attention_atol'];rtol=lim['endpoint_recurrent_rtol' if R else 'endpoint_conv_attention_rtol']
                rows.append(dict(actual=a,reference=b,phase=phase,field=field,max_abs=max(abs(x-y) for x,y in zip(u,v)),passed=all(abs(x-y)<=atol+rtol*abs(y) for x,y in zip(u,v))))
        x,y=values(art[a+'_Q_logits']),values(art[b+'_Q_logits'])
        def softmax(v):
            m=max(v);out=[math.exp(t-m) for t in v];s=math.fsum(out);return [t/s for t in out]
        px,py=softmax(x),softmax(y)
        tv=math.fsum(abs(u-v) for u,v in zip(px,py))/2
        same=max(range(len(x)),key=x.__getitem__)==max(range(len(y)),key=y.__getitem__)
        lim=c.numerical_limits()
        rows.append(dict(actual=a,reference=b,phase='Q_logits',max_abs=max(abs(u-v) for u,v in zip(x,y)),
            TV_float64_recomputation=tv,same_first_argmax=same,
            passed=all(abs(u-v)<=lim['logit_atol']+lim['logit_rtol']*abs(v) for u,v in zip(x,y)) and tv<=lim['TV_max'] and same))
    result=dict(status='PASS_SAVED_RAW_SUBSET_AUDIT_ONLY' if all(r['passed'] for r in rows) else 'FAIL_SAVED_RAW_SUBSET_AUDIT',
        report_sha256=c.sha(c.HERE/'native_self_reuse_attempt_03/report.json'),raw_artifacts_verified=len(art),
        raw_logical_bytes=sum(r['bytes'] for r in art.values()),checks=rows,
        scope='192 raw pre/postQ cache tensor comparisons and2 Q-logit comparisons; float64 Python recomputation from retained FP32 bytes. Not audit of unsaved candidate/greedy arrays or external guard. No native/model execution.',
        guard_evidence='INCOMPLETE_TERMINAL_WAIT4_RECEIPT',original_or_pretrained_claim=False)
    (c.HERE/'saved_raw_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    return {'status':result['status'],'raw_artifacts_verified':len(art),'raw_checks':len(rows),'max_abs':max(r['max_abs'] for r in rows)}
if __name__=='__main__':print(json.dumps(audit(),indent=2))
