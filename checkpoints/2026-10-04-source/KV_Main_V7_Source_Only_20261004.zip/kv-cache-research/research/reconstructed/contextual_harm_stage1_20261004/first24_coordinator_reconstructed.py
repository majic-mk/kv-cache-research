"""NEW runnable first24 wiring behind the separate original-admission source lock.

No model is constructed here. Numerical endpoints retain at most the fixed two
F32/A1 banks, one previous R bank and this cell's bank. Failed cells and all later
unrun identities are durable; there is no fixture reselection or model replay.
"""
import gc,time
import contract_reconstructed as c
from results_reconstructed import StageState
from scoring_reconstructed import score_post_q_with_backend,ScoringFailure
from evidence_sink_reconstructed import check_metadata_budget


def _without_hashes(value):
    if isinstance(value,dict):return {k:_without_hashes(v) for k,v in value.items() if k!='sha256'}
    if isinstance(value,list):return [_without_hashes(v) for v in value]
    return value

class NativeFirst24:
    def __init__(self,model,engine,torch,hf,tokenizer,store,admission):
        from native_backend_reconstructed import NativeCalls,TorchScoreBackend
        admission.assert_execution_allowed()
        self.model,self.engine,self.torch,self.hf,self.store=model,engine,torch,hf,store
        self.calls=NativeCalls(model,engine,torch,hf,admission=admission,emit=store.emit,raw_logit_sink=store.raw_logits)
        self.scoring=TorchScoreBackend(self.calls,lambda ids:tokenizer.decode(ids,skip_special_tokens=True,clean_up_tokenization_spaces=False))
        self.sources={};self.banks={};self.bank_backings={};self.scores={};self.max_retained_endpoint_owners=0
    def _compare(self,label,owner,reference,logits=None,reference_logits=None):
        limits=c.numerical_limits();torch=self.torch;evidence=self.calls.evidence;start=time.monotonic();cpu=time.process_time()
        with self.calls.installed_context():
            actual,at=evidence.cache_snapshot(owner.cache,torch);expected,rt=evidence.cache_snapshot(reference.cache,torch)
            if _without_hashes(actual)!=_without_hashes(expected) or set(at)!=set(rt):raise ScoringFailure('cache_schema',label,category='numerical')
            for path,x in at.items():
                y=rt[path];is_r='recurrent_states' in path
                atol=limits['endpoint_recurrent_atol' if is_r else 'endpoint_conv_attention_atol']
                rtol=limits['endpoint_recurrent_rtol' if is_r else 'endpoint_conv_attention_rtol']
                passed=bool(torch.allclose(x,y,atol=atol,rtol=rtol));delta=float((x-y).abs().max()) if x.numel() else 0.
                self.store.emit({'kind':'live_cache_control','label':label,'field':path,'max_abs':delta,'atol':atol,'rtol':rtol,'passed':passed})
                if not passed:raise ScoringFailure('cache_endpoint',label+'/'+path,category='numerical')
            if logits is not None:
                tv=float((logits.softmax(-1)-reference_logits.softmax(-1)).abs().sum()/2)
                delta=float((logits-reference_logits).abs().max())
                passed=bool(torch.allclose(logits,reference_logits,atol=limits['logit_atol'],rtol=limits['logit_rtol'])) and tv<=limits['TV_max']
                self.store.emit({'kind':'live_logit_control','label':label,'max_abs':delta,'TV':tv,'passed':passed})
                if not passed:raise ScoringFailure('logit_endpoint',label,category='numerical')
        self.store.emit({'kind':'endpoint_comparison_cost','label':label,'wall_seconds':time.monotonic()-start,'CPU_seconds':time.process_time()-cpu})
    def execute(self,cell):
        from contextual_native_reconstructed import ContextualCapture,HctxAdapter
        cell=c.canonical_cell(cell);self.calls.bind(cell)
        context=next(r for r in c.recovered_contexts() if (r['pair_id'],r['variant'])==(cell['pair_id'],cell['variant']))
        A,B,Q=[tuple(context[k]) for k in ('A_ids','B_ids','Q_ids')]
        cid=cell['cell_id'];group=cell['pair_id'];arm=cell['arm'];source=None;trace=None
        exact=cell['reference_cell'] if arm=='F32' or (arm=='Hctx32' and cell['variant']=='A1') else None
        retain=arm=='R' or (arm=='F32' and cell['variant']=='A1')
        bank={} if retain else None
        if arm=='Hctx32':
            source=self.sources[group]
            assembled,trace=HctxAdapter(self.model,self.calls,source).build(A,B,32)
            preq=self.calls.register_hctx(assembled,trace,source)
            self.store.save_suffix(group,source)
            self.store.emit({'kind':'Hctx_assembly','cell_id':cid,'trace':{k:v for k,v in trace.items() if k!='fresh_seam_owner'}})
            del assembled,trace
        else:
            a=self.calls.checked_forward(A,branch='prefill',purpose='A')
            if arm=='R':
                if cell['source_capture_during_B']:
                    with ContextualCapture(self.model,self.calls,A,B) as capture:
                        preq=self.calls.checked_forward(B,a,branch='prefill',purpose='B')
                    source=capture.finish(preq);self.sources[group]=source
                    del capture
                else:preq=self.calls.checked_forward(B,a,branch='prefill',purpose='B')
            else:
                seam=self.calls.checked_forward(B[:32],a,branch='prefill',purpose='B_seam')
                preq=self.calls.checked_forward(B[32:],seam,branch='prefill',purpose='B_fresh_suffix')
                del seam
            del a
        preq=self.calls.register_pre_q(preq)
        if exact:
            ref,_=self.banks[exact].pop('pre_Q');self._compare(cid+'.pre_Q',preq,ref);del ref
            if exact in self.bank_backings:self.store.emit({'kind':'mapped_reference_eviction','cell_id':cid,**self.bank_backings[exact].evict()})
        if retain:bank['pre_Q']=(preq,None)
        self.store.save_cache(cid,preq)
        if cell['source_capture_during_B']:self.store.save_source(group,source)
        q=self.calls.checked_forward(Q,preq,branch='Q_from_owned_pre_Q_clone',purpose='Q')
        def observe(label,owner,logits):
            if exact:
                ref,ref_logits=self.banks[exact].pop(label)
                self._compare(cid+'.'+label,owner,ref,logits,ref_logits)
                if exact in self.bank_backings:self.store.emit({'kind':'mapped_reference_eviction','cell_id':cid,**self.bank_backings[exact].evict()})
            if retain:bank[label]=(owner,logits)
        scores=score_post_q_with_backend(cell,q,self.scoring,exact_reference=self.scores[exact] if exact else None,observe=observe)
        self.calls.finish()
        if retain:
            if arm=='F32':bank,self.bank_backings[cid]=self.store.map_reference_bank(cell,bank)
            self.banks[cid]=bank
        self.scores[cid]={k:scores[k] for k in ('candidate_scores','gold_logprob','gold_margin','raw_greedy_ids','eos_within_cap')}
        self.max_retained_endpoint_owners=max(self.max_retained_endpoint_owners,sum(len(x) for x in self.banks.values()))
        # Consume the previous reference only after all comparisons/scoring finish.
        if exact:
            if self.banks[exact]:raise ValueError('Unconsumed exact reference endpoints')
            self.banks.pop(exact);self.bank_backings.pop(exact,None)
        if source is not None:
            for backing in getattr(source,'_evidence_backings',[]):self.store.emit({'kind':'source_mapping_eviction','pair_id':group,**backing.evict()})
        if arm=='Hctx32' and cell['variant']=='U2':self.sources.pop(group)
        if len(self.sources)>2 or len(self.banks)>3 or any(len(b)>12 for b in self.banks.values()):raise ValueError('Fixed source/reference-bank lifetime bound')
        check_metadata_budget(self.scores)
        return {**{k:cell[k] for k in ('cell_id','pair_id','variant','arm')},**scores,'status':'completed','native_checks_passed':True}
    def abort(self):
        self.calls.abort_cell();self.sources.clear();self.banks.clear();self.bank_backings.clear();gc.collect()
    def summary(self):
        return {'root_calls_attempted':self.calls.calls,'network_tokens_attempted':self.calls.tokens,
            'root_calls_issued':self.store.costs.root_invoked,'root_calls_returned':self.store.costs.root_returned,'max_retained_endpoint_owners_after_cell':self.max_retained_endpoint_owners,
            'cache_lifetime':'R bank consumed endpoint-by-endpoint by immediate F32;F32/A1 banks raw-file-backed through ch17/ch21;sources raw-file-backed and inactive pages evicted;other endpoints cell-local',
            'extra_reconstructed_continuation_clones':True,'evidence_scope':'This run only; no general numerical or deployability qualification'}


def coordinate_first24(executor,store):
    """Deterministic state/evidence wiring, also exercised with model-free spies."""
    state=StageState();active=None;primary=None
    try:
        for cell in state.plan:
            active=cell['cell_id'];store.begin_cell(cell)
            try:
                record=executor.execute(cell)
                state.accept(record)
                if state.first_failure:
                    store.terminal.terminal(active,'failed',{'record':record,'first_failure':state.first_failure})
                    break
                store.terminal.terminal(active,'succeeded',record)
            except BaseException as exc:
                primary=exc;category=getattr(exc,'category','integrity')
                state.stop(category,active,{'type':type(exc).__name__,'message':str(exc)})
                details={'first_failure':state.first_failure,'partial_score':getattr(exc,'partial',None)}
                if store.terminal.active_cell_id==active:
                    try:store.terminal.fail_active(details)
                    except BaseException as secondary:
                        state.first_failure['secondary_evidence_failure']={'type':type(secondary).__name__,'message':str(secondary)}
                break
        result={'status':state.status,'first_failure':state.first_failure,'records':state.records,
            'harm_assessment':state.assess_harm() if state.next_index==24 and not state.first_failure else None,
            'execution':executor.summary(),'continuation_authorized':False}
        check_metadata_budget(result)
        try:store.emit({'kind':'first24_terminal','result':result})
        except BaseException as secondary:
            if primary is None:raise
            result['terminal_evidence_failure']={'type':type(secondary).__name__,'message':str(secondary)}
        return result
    finally:executor.abort()


def run_first24(model,engine,torch,hf,tokenizer,store,admission):
    admission.assert_execution_allowed()
    # Loader owns offline tokenizer revalidation and marks it explicitly; using
    # a numeric-ID dummy decoder cannot silently enter this production path.
    if not getattr(admission,'tokenizer_verified',False):raise RuntimeError('Verified original tokenizer required')
    return coordinate_first24(NativeFirst24(model,engine,torch,hf,tokenizer,store,admission),store)
