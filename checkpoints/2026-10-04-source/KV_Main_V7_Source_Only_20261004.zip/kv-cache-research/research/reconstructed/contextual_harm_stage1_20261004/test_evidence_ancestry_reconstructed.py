"""NEWLY RECONSTRUCTED stdlib safety tests, not exact recovery/model evidence.

Run directly from any directory with Python 3.11+. Tests create unique tiny
files under evidence_fixtures, retain every file, and never delete old evidence.
No model packages, model forwards, network, installs, downloads, or GPU actions.
"""
from __future__ import annotations

import gc
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import sys
import unittest
import uuid
import weakref

if __package__:
    from . import evidence_sink_reconstructed as evidence
    from . import ancestry_reconstructed as ancestry
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import evidence_sink_reconstructed as evidence
    import ancestry_reconstructed as ancestry

FIXTURES = Path(__file__).resolve().parent / "evidence_fixtures"


def fixture(name: str) -> Path:
    FIXTURES.mkdir(exist_ok=True)
    return FIXTURES / f"newly_reconstructed_{name}_{uuid.uuid4().hex}.jsonl"


class EvidenceTests(unittest.TestCase):
    def journal(self, name: str, **kwargs) -> evidence.BoundedJSONLJournal:
        sink = evidence.BoundedJSONLJournal(fixture(name), **kwargs)
        self.addCleanup(sink.close)  # Close only; NO cleanup/deletion of files.
        return sink

    def test_real_journal_roundtrip_and_acknowledged_digest(self):
        sink = self.journal("roundtrip")
        event = {"label": "newly reconstructed", "string": 'line\nquote" emoji\U0001f4a1',
                 "nested": [None, True, False, -3, 1.25, {"x": (1, 2)}]}
        receipt = sink.append(event)
        raw = sink.path.read_bytes()
        self.assertEqual(json.loads(raw)["nested"][-1], {"x": [1, 2]})
        self.assertEqual(receipt.sha256, hashlib.sha256(raw).hexdigest())
        self.assertTrue(receipt.durable and receipt.persistent)
        self.assertEqual((sink.actual_written_bytes, sink.durable_ack_bytes), (len(raw), len(raw)))
        sink.close()
        self.assertTrue(sink.path.exists())

    def test_streaming_writer_never_receives_more_than_64k(self):
        requests = []
        def spy(fd, data):
            requests.append(len(data))
            return os.write(fd, data)
        sink = self.journal("chunk_bound", write_fn=spy)
        sink.append({"string": "x" * 70000})
        self.assertGreater(len(requests), 1)
        self.assertLessEqual(max(requests), 65536)
        self.assertEqual(len(json.loads(sink.path.read_bytes())["string"]), 70000)

    def test_long_unicode_scalar_is_streamed_in_bounded_chunks(self):
        event = {"text": "\U0001f4a1" * 20000}
        count = 0
        length = 0
        for chunk in evidence.jsonl_chunks(event, chunk_bytes=127):
            self.assertLessEqual(len(chunk), 127)
            count += 1
            length += len(chunk)
        self.assertGreater(count, 1000)
        self.assertEqual(length, len(json.dumps(event, ensure_ascii=True, separators=(",", ":")).encode()) + 1)

    def test_positive_short_writes_are_completed_before_fsync_ack(self):
        calls = []
        def short(fd, data):
            calls.append(len(data))
            return os.write(fd, data[:3])
        sink = self.journal("short_success", write_fn=short, chunk_bytes=11)
        receipt = sink.append({"ok": "abcdefghijk"})
        self.assertGreater(len(calls), 3)
        self.assertEqual(json.loads(sink.path.read_bytes()), {"ok": "abcdefghijk"})
        self.assertEqual(receipt.end_byte, sink.actual_written_bytes)

    def test_zero_write_poisons_permanently_without_retry(self):
        calls = []
        def zero(fd, data):
            calls.append(1)
            return 0
        sink = self.journal("zero_write", write_fn=zero)
        with self.assertRaises(evidence.EvidenceError):
            sink.append({"cell": "first"})
        with self.assertRaises(evidence.JournalPoisoned):
            sink.append({"cell": "second"})
        self.assertEqual(calls, [1])
        self.assertEqual((sink.actual_written_bytes, sink.durable_ack_bytes), (0, 0))
        self.assertTrue(sink.poisoned)

    def test_partial_then_zero_retains_torn_file_and_no_durable_ack(self):
        calls = []
        def partial(fd, data):
            calls.append(1)
            return os.write(fd, data[:5]) if len(calls) == 1 else 0
        sink = self.journal("partial_zero", write_fn=partial)
        with self.assertRaises(evidence.EvidenceError):
            sink.append({"cell": "broken"})
        before = sink.path.read_bytes()
        self.assertEqual(len(before), 5)
        self.assertEqual((sink.actual_written_bytes, sink.durable_ack_bytes), (5, 0))
        with self.assertRaises(evidence.JournalPoisoned):
            sink.append({"attempt": "forbidden"})
        sink.close()
        self.assertEqual(sink.path.read_bytes(), before)

    def test_exception_after_actual_partial_write_observes_real_file_bytes(self):
        def writes_then_raises(fd, data):
            os.write(fd, data[:7])
            raise OSError("injected exception after actual bytes reached the file")
        sink = self.journal("write_exception", write_fn=writes_then_raises)
        with self.assertRaises(OSError):
            sink.append({"cell": "broken"})
        self.assertEqual((sink.actual_written_bytes, sink.durable_ack_bytes), (7, 0))
        with self.assertRaises(evidence.JournalPoisoned):
            sink.append({"retry": False})

    def test_fsync_failure_preserves_actual_and_previous_durable_offsets(self):
        calls = []
        def fsync(fd):
            calls.append(1)
            if len(calls) == 2:
                raise OSError("injected fsync failure")
            os.fsync(fd)
        sink = self.journal("fsync_failure", fsync_fn=fsync)
        first = sink.append({"cell": "first"})
        with self.assertRaises(OSError):
            sink.append({"cell": "second"})
        self.assertGreater(sink.actual_written_bytes, first.end_byte)
        self.assertEqual(sink.durable_ack_bytes, first.end_byte)
        self.assertEqual(sink.durable_events, 1)
        with self.assertRaises(evidence.JournalPoisoned):
            sink.append({"cell": "third"})
        self.assertEqual(len(calls), 2)
        self.assertEqual(len(sink.path.read_bytes().splitlines()), 2)

    def test_invalid_write_count_poisons(self):
        for invalid in (None, True, -1, 1000):
            with self.subTest(invalid=invalid):
                sink = self.journal("invalid_count", write_fn=lambda fd, data, n=invalid: n)
                with self.assertRaises(evidence.EvidenceError):
                    sink.append({"x": 1})
                self.assertTrue(sink.poisoned)
                self.assertEqual(sink.durable_ack_bytes, 0)

    def test_event_limit_is_checked_before_any_bytes_are_written(self):
        sink = self.journal("event_limit", event_limit=20)
        with self.assertRaises(evidence.BudgetExceeded):
            sink.append({"large": "x" * 30})
        self.assertEqual(sink.path.stat().st_size, 0)
        self.assertTrue(sink.poisoned)

    def test_total_limit_preserves_prior_acknowledged_rows(self):
        sink = self.journal("total_limit", total_limit=20)
        receipt = sink.append({"x": 1})
        with self.assertRaises(evidence.BudgetExceeded):
            sink.append({"y": "a" * 20})
        self.assertEqual(sink.actual_written_bytes, receipt.end_byte)
        self.assertEqual(sink.path.read_bytes(), b'{"x":1}\n')

    def test_existing_file_is_never_reopened_or_truncated(self):
        sink = self.journal("exclusive")
        sink.append({"keep": "all evidence"})
        sink.close()
        before = sink.path.read_bytes()
        with self.assertRaises(FileExistsError):
            evidence.BoundedJSONLJournal(sink.path)
        self.assertEqual(sink.path.read_bytes(), before)

    def test_invalid_json_and_depth_reject_before_writing(self):
        deep = []
        for _ in range(130):
            deep = [deep]
        cyclic = []
        cyclic.append(cyclic)
        for event in ({"bad": float("nan")}, {1: "bad key"}, {"bad": object()},
                      {"deep": deep}, {"cycle": cyclic}):
            sink = self.journal("invalid_json")
            with self.assertRaises(evidence.EvidenceError):
                sink.append(event)
            self.assertEqual(sink.actual_written_bytes, 0)

    def test_deep_metadata_counts_all_dict_children_not_shallow_head(self):
        payload = {f"key_{i}": [f"unique_{i}_" + "x" * 100] for i in range(60)}
        self.assertLess(sys.getsizeof(payload), 2000)
        with self.assertRaises(evidence.BudgetExceeded):
            evidence.check_metadata_budget(payload, limit=5000)
        self.assertGreater(evidence.check_metadata_budget(payload), 12000)

    def test_deep_metadata_counts_container_subclasses(self):
        class NestedList(list):
            pass
        with self.assertRaises(evidence.BudgetExceeded):
            evidence.check_metadata_budget(NestedList(["x" * 3000]), limit=2048)

    def test_deep_metadata_handles_aliases_and_cycles(self):
        child = ["x" * 500]
        shared = [child, child]
        self.assertEqual(evidence.deep_size_bytes(shared),
                         sys.getsizeof(shared) + sys.getsizeof(child) + sys.getsizeof(child[0]))
        cycle = []
        cycle.append(cycle)
        self.assertEqual(evidence.deep_size_bytes(cycle), sys.getsizeof(cycle))

    def test_deep_event_budget_rejects_before_io(self):
        sink = self.journal("deep_limit", metadata_limit=2048)
        with self.assertRaises(evidence.BudgetExceeded):
            sink.append({"nested": [["x" * 2500]]})
        self.assertEqual(sink.actual_written_bytes, 0)

    def test_default_caps_cannot_be_relaxed(self):
        for kw in ({"event_limit": evidence.EVENT_LIMIT + 1},
                   {"total_limit": evidence.JOURNAL_LIMIT + 1},
                   {"metadata_limit": evidence.METADATA_LIMIT + 1},
                   {"chunk_bytes": evidence.CHUNK_LIMIT + 1}):
            with self.assertRaises(ValueError):
                evidence.BoundedJSONLJournal(fixture("invalid_cap"), **kw)

    def test_terminal_row_is_acknowledged_before_payload_eviction(self):
        payload = {"large": "x" * 1000}
        store_holder = []
        observed = []
        def fsync(fd):
            store = store_holder[0]
            observed.append((store.active_cell_id, store.active_payload is payload,
                             bool(store.compact_terminal)))
            os.fsync(fd)
        sink = self.journal("terminal_order", fsync_fn=fsync)
        store = evidence.TerminalEvidenceStore(sink)
        store_holder.append(store)
        store.begin_cell("actual-cell-A", payload)
        store.mark_model_invoked("actual-cell-A")
        store.mark_model_returned("actual-cell-A")
        receipt = store.terminal("actual-cell-A", "succeeded", {"fixture_only": True})
        self.assertEqual(observed, [("actual-cell-A", True, False)])
        self.assertIsNone(store.active_payload)
        self.assertIsNone(store.active_cell_id)
        compact = store.compact_terminal["actual-cell-A"]
        self.assertNotIn("payload", compact)
        self.assertTrue(compact["model_invoked"] and compact["model_returned"])
        self.assertEqual(compact["end_byte"], receipt.end_byte)
        self.assertEqual(store.counts, {"started": 1, "terminal": 1, "model_invoked": 1, "model_returned": 1})

    def test_failed_terminal_retains_active_payload_and_blocks_retries(self):
        def fail(fd):
            raise OSError("terminal durability unavailable")
        sink = self.journal("terminal_retained", fsync_fn=fail)
        store = evidence.TerminalEvidenceStore(sink)
        payload = {"must": "remain available"}
        store.begin_cell("failed-cell-explicit", payload)
        store.mark_model_invoked("failed-cell-explicit")
        with self.assertRaises(OSError):
            store.fail_active("injected native-call error")
        self.assertIs(store.active_payload, payload)
        self.assertEqual(store.active_cell_id, "failed-cell-explicit")
        self.assertEqual(store.compact_terminal, {})
        self.assertEqual(store.counts["terminal"], 0)
        self.assertTrue(store.blocked)
        with self.assertRaises(evidence.JournalPoisoned):
            store.fail_active("retry forbidden")

    def test_failure_uses_explicit_active_identity_not_next_index_minus_one(self):
        sink = self.journal("explicit_failure_id")
        store = evidence.TerminalEvidenceStore(sink)
        store.begin_cell("nonsequential-cell-947", {"fixture": True})
        store.fail_active("failure before model invocation")
        row = json.loads(sink.path.read_bytes())
        self.assertEqual(row["cell_id"], "nonsequential-cell-947")
        self.assertFalse(row["model_invoked"])
        self.assertFalse(row["model_returned"])
        self.assertEqual(store.counts["model_invoked"], 0)

    def test_cell_flags_and_duplicate_cell_protection(self):
        sink = self.journal("cell_flags")
        store = evidence.TerminalEvidenceStore(sink)
        store.begin_cell("a", {})
        with self.assertRaises(evidence.EvidenceError):
            store.mark_model_returned("a")
        with self.assertRaises(evidence.EvidenceError):
            store.mark_model_invoked("wrong-id")
        with self.assertRaises(evidence.EvidenceError):
            store.terminal("a", "succeeded")
        store.fail_active("pre-invocation failure")
        with self.assertRaises(evidence.EvidenceError):
            store.begin_cell("a", {})

    def test_terminal_metadata_cap_includes_deep_active_payload(self):
        sink = self.journal("terminal_meta_cap")
        store = evidence.TerminalEvidenceStore(sink, metadata_limit=2500)
        with self.assertRaises(evidence.BudgetExceeded):
            store.begin_cell("large", {"nested": ["x" * 3000]})
        self.assertIsNone(store.active_cell_id)
        self.assertEqual(store.counts["started"], 0)
        self.assertEqual(sink.actual_written_bytes, 0)

    def test_digest_sink_is_explicit_nonpersistent_tiny_test_only(self):
        sink = evidence.TinyNonpersistentDigestTestSink()
        with self.assertRaises(evidence.EvidenceError):
            evidence.TerminalEvidenceStore(sink)
        store = evidence.TerminalEvidenceStore(sink, allow_nonpersistent_test_sink=True)
        store.begin_cell("fixture-cell", {})
        receipt = store.fail_active("stdlib test fixture only")
        self.assertFalse(receipt.durable or receipt.persistent)
        self.assertEqual(sink.durable_ack_bytes, 0)
        self.assertEqual(sink.durable_events, 0)
        self.assertEqual(len(sink.digest), 64)
        with self.assertRaises(ValueError):
            evidence.TinyNonpersistentDigestTestSink(total_limit=65537)

    def test_exhausted_digest_sink_stays_poisoned(self):
        sink = evidence.TinyNonpersistentDigestTestSink(total_limit=40)
        sink.append({"a": 1})
        with self.assertRaises(evidence.BudgetExceeded):
            sink.append({"too_big": "x" * 40})
        with self.assertRaises(evidence.JournalPoisoned):
            sink.append({"retry": 1})


class SpyCache:
    def __init__(self, tokens):
        self.tokens = list(tokens)


class SpyOwner:
    def __init__(self, tokens):
        self.cache = SpyCache(tokens)
        self.version = 1


class AncestryTests(unittest.TestCase):
    def setUp(self):
        self.registry = ancestry.CacheAncestryRegistry(
            get_cache=lambda owner: owner.cache, get_version=lambda owner: owner.version)
        self.owners = []
        self.callback_calls = 0
        self.dispatch_spy_calls = 0

    def output(self, owner, *, tokens=None, returned=None, success=True):
        return ancestry.TrackedNativeOutput(owner, owner.cache if returned is None else returned,
            owner.version, tuple(owner.cache.tokens) if tokens is None else tokens,
            True, True, success)

    def root(self, tokens=(11, 22)):
        owner = SpyOwner(tokens)
        self.owners.append(owner)
        self.registry.register_native_root(self.output(owner), branch="root", purpose="native-prefix")
        return owner

    def clone_callback(self, parent, branch, purpose):
        self.callback_calls += 1
        clone = SpyOwner(parent.cache.tokens)
        self.owners.append(clone)
        return ancestry.VerifiedClone(clone, clone.cache, clone.version,
                                      tuple(clone.cache.tokens), True, True)

    def clone(self, parent, *, branch="A", purpose="query"):
        verified = self.registry.verified_clone(parent, expected_tokens=tuple(parent.cache.tokens),
            branch=branch, purpose=purpose, clone_callback=self.clone_callback)
        return verified.owner

    def claim(self, clone, parent, *, tokens=None, branch="A", purpose="query", appended=(33,)):
        return self.registry.claim_for_forward(clone, parent_owner=parent,
            expected_tokens=tuple(parent.cache.tokens) if tokens is None else tokens,
            appended_tokens=appended, branch=branch, purpose=purpose)

    def test_successful_native_root_verified_clone_and_native_output_chain(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        clone.cache.tokens.append(33)  # stdlib storage spy mutation, no model forward
        clone.version += 1
        record = self.registry.register_native_output(permit, self.output(clone))
        self.assertEqual(record.origin, "successful_native_output")
        self.assertEqual(record.token_history, (11, 22, 33))
        continuation = self.clone(clone, branch="B", purpose="continuation")
        self.registry.claim_for_forward(continuation, parent_owner=clone,
            expected_tokens=(11, 22, 33), appended_tokens=(44,), branch="B", purpose="continuation")

    def test_unregistered_parent_rejected_before_clone_callback(self):
        parent = SpyOwner((11, 22))
        with self.assertRaises(ancestry.AncestryError):
            self.registry.verified_clone(parent, expected_tokens=(11, 22),
                branch="A", purpose="query", clone_callback=self.clone_callback)
        self.assertEqual(self.callback_calls, 0)

    def test_unsuccessful_or_unreturned_native_output_never_registers_root(self):
        owner = SpyOwner((11, 22))
        bad = ancestry.TrackedNativeOutput(owner, owner.cache, owner.version,
                                           (11, 22), True, False, False)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_root(bad, branch="root", purpose="native")
        with self.assertRaises(ancestry.AncestryError):
            self.registry.inspect(owner)

    def test_native_root_requires_actual_returned_cache_identity(self):
        owner = SpyOwner((11, 22))
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_root(self.output(owner, returned=SpyCache((11, 22))),
                                               branch="root", purpose="native")

    def test_same_length_same_tokens_wrong_actual_parent_rejected_before_dispatch(self):
        root_a = self.root((11, 22))
        root_b = self.root((11, 22))
        clone = self.clone(root_a)
        try:
            self.claim(clone, root_b)
        except ancestry.AncestryError:
            pass
        else:
            self.dispatch_spy_calls += 1
        self.assertEqual(self.dispatch_spy_calls, 0)
        self.assertFalse(self.registry.inspect(clone).claimed)

    def test_same_length_wrong_token_history_rejected(self):
        root = self.root()
        clone = self.clone(root)
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root, tokens=(11, 99))

    def test_reused_candidate_is_rejected_before_second_dispatch(self):
        root = self.root()
        clone = self.clone(root)
        self.claim(clone, root)
        self.dispatch_spy_calls += 1
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root)
        self.assertEqual(self.dispatch_spy_calls, 1)

    def test_branch_and_clone_purpose_are_both_bound(self):
        root = self.root()
        clone = self.clone(root)
        for changes in ({"branch": "B"}, {"purpose": "donor"}):
            with self.subTest(changes=changes), self.assertRaises(ancestry.AncestryError):
                self.claim(clone, root, **changes)
        self.assertFalse(self.registry.inspect(clone).claimed)

    def test_root_actual_cache_replacement_is_rechecked_without_length_change(self):
        root = self.root()
        clone = self.clone(root)
        root.cache = SpyCache((11, 22))
        # Even a buggy caller that forgot to increment version is caught by identity.
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root)

    def test_root_version_change_is_rechecked_for_same_cache_identity(self):
        root = self.root()
        clone = self.clone(root)
        root.version += 1
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root)

    def test_candidate_actual_cache_and_version_are_rechecked(self):
        root = self.root()
        clone = self.clone(root)
        clone.version += 1
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root)

    def test_clone_callback_requires_both_content_and_independence_verification(self):
        root = self.root()
        for content, independent in ((False, True), (True, False)):
            def unverified(parent, branch, purpose):
                clone = SpyOwner(parent.cache.tokens)
                self.owners.append(clone)
                return ancestry.VerifiedClone(clone, clone.cache, clone.version,
                                              tuple(clone.cache.tokens), content, independent)
            with self.assertRaises(ancestry.AncestryError):
                self.registry.verified_clone(root, expected_tokens=(11, 22), branch="A",
                                             purpose="query", clone_callback=unverified)

    def test_clone_cannot_alias_parent_even_with_true_attestations(self):
        root = self.root()
        def aliased(parent, branch, purpose):
            return ancestry.VerifiedClone(parent, parent.cache, parent.version, (11, 22), True, True)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.verified_clone(root, expected_tokens=(11, 22), branch="A",
                                         purpose="query", clone_callback=aliased)

    def test_clone_cannot_return_already_registered_candidate_cache(self):
        root = self.root()
        clone = self.clone(root)
        def reused(parent, branch, purpose):
            other = SpyOwner((11, 22))
            other.cache = clone.cache
            self.owners.append(other)
            return ancestry.VerifiedClone(other, other.cache, other.version, (11, 22), True, True)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.verified_clone(root, expected_tokens=(11, 22), branch="B",
                                         purpose="query", clone_callback=reused)

    def test_clone_callback_mutating_parent_cannot_register_clone(self):
        root = self.root()
        def mutated(parent, branch, purpose):
            clone = self.clone_callback(parent, branch, purpose)
            parent.version += 1
            return clone
        with self.assertRaises(ancestry.AncestryError):
            self.registry.verified_clone(root, expected_tokens=(11, 22), branch="A",
                                         purpose="query", clone_callback=mutated)

    def test_failed_invocation_consumes_candidate_and_never_registers_parent(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        self.registry.record_native_failure(permit)
        with self.assertRaises(ancestry.AncestryError):
            self.claim(clone, root)
        clone.cache.tokens.append(33)
        clone.version += 1
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_output(permit, self.output(clone))

    def test_consumed_candidate_cannot_be_recloned_as_a_verified_parent(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        self.registry.record_native_failure(permit)
        before = self.callback_calls
        with self.assertRaises(ancestry.AncestryError):
            self.clone(clone, branch="retry", purpose="query")
        self.assertEqual(self.callback_calls, before)

    def test_parent_consumption_invalidates_existing_child_before_dispatch(self):
        root = self.root()
        parent = self.clone(root)
        child = self.clone(parent, branch="B", purpose="query")
        self.claim(parent, root)
        with self.assertRaises(ancestry.AncestryError):
            self.claim(child, parent, branch="B")

    def test_native_output_wrong_history_consumes_permit_and_registers_nothing(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        clone.cache.tokens.append(99)
        clone.version += 1
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_output(permit, self.output(clone))
        clone.cache.tokens[-1] = 33
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_output(permit, self.output(clone))

    def test_native_output_reusing_owner_requires_monotonic_version_advance(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        clone.cache.tokens.append(33)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_native_output(permit, self.output(clone))

    def test_successful_output_can_have_a_new_actual_owner_and_cache(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        output_owner = SpyOwner((11, 22, 33))
        self.owners.append(output_owner)
        record = self.registry.register_native_output(permit, self.output(output_owner))
        self.assertEqual(record.token_history, (11, 22, 33))
        self.assertIs(record.owner_ref(), output_owner)

    def test_forged_equal_permit_is_rejected(self):
        root = self.root()
        clone = self.clone(root)
        permit = self.claim(clone, root)
        forged = ancestry.ForwardPermit(permit.serial, permit.candidate_serial,
            permit.parent_serial, permit.root_serial, permit.token_history,
            permit.appended_tokens, permit.branch, permit.purpose)
        self.assertEqual(forged, permit)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.record_native_failure(forged)

    def test_registry_uses_weak_owner_identity_and_does_not_keep_cache_alive(self):
        root = self.root()
        record = self.registry.inspect(root)
        owner_ref, cache_ref = weakref.ref(root), weakref.ref(root.cache)
        self.owners.clear()
        del root
        gc.collect()
        self.assertIsNone(owner_ref())
        self.assertIsNone(cache_ref())
        with self.assertRaises(ancestry.AncestryError):
            self.registry._current(record)

    def test_metadata_budget_covers_deep_token_history_before_registration(self):
        registry = ancestry.CacheAncestryRegistry(get_cache=lambda owner: owner.cache,
            get_version=lambda owner: owner.version, metadata_limit=2500)
        root = SpyOwner(tuple(range(1000)))
        with self.assertRaises(evidence.BudgetExceeded):
            registry.register_native_root(self.output(root), branch="root", purpose="native")
        with self.assertRaises(ancestry.AncestryError):
            registry.inspect(root)

    def derived_output(self, tokens=(11, 22, 77)):
        owner = SpyOwner(tokens)
        self.owners.append(owner)
        return ancestry.DerivedCache(owner, owner.cache, owner.version, tuple(tokens),
            {"reconstructed_fixture": True}, {"operation": "nonforward_assembly_spy"})

    def derived_verifier(self, parent, output, history, branch, purpose):
        self.callback_calls += 1
        complete = tuple(output.cache.tokens) == history and output.metadata == {"reconstructed_fixture": True}
        independent = output.cache is not parent.cache and output.cache.tokens is not parent.cache.tokens
        trace_ok = output.adapter_trace == {"operation": "nonforward_assembly_spy"}
        digest = hashlib.sha256(json.dumps(output.adapter_trace, sort_keys=True).encode()).hexdigest()
        return ancestry.DerivedVerification(parent, parent.cache, parent.version,
            output.owner, output.cache, output.version, history, branch, purpose,
            complete, independent, trace_ok, digest, "stdlib-test-verifier-v1")

    def test_derived_assembly_is_not_native_output_and_needs_clone_for_forward(self):
        root = self.root()
        output = self.derived_output()
        before = self.registry.origin_counts()
        record = self.registry.register_derived(root, output, expected_history=(11, 22, 77),
            branch="Hctx32", verifier_callback=self.derived_verifier)
        after = self.registry.origin_counts()
        self.assertEqual(record.origin, "verified_derived_cache")
        self.assertEqual(record.root_serial, self.registry.inspect(root).serial)
        self.assertEqual(record.parent_serial, self.registry.inspect(root).serial)
        self.assertEqual(record.purpose, "Hctx32_assembly")
        self.assertEqual(record.verifier_provenance, "stdlib-test-verifier-v1")
        self.assertIn("derived_verifier", record.verifier_callback)
        self.assertEqual(len(record.adapter_trace_sha256), 64)
        self.assertEqual(after.get("successful_native_root"), before.get("successful_native_root"))
        self.assertEqual(after.get("successful_native_output", 0), 0)
        self.assertEqual(self.dispatch_spy_calls, 0)
        with self.assertRaises(ancestry.AncestryError):
            self.claim(output.owner, root, tokens=(11, 22, 77), branch="Hctx32", purpose="Hctx32_assembly")
        candidate = self.clone(output.owner, branch="Hctx32", purpose="continuation")
        self.claim(candidate, output.owner, branch="Hctx32", purpose="continuation", appended=(88,))

    def test_derived_requires_verifier_object_and_all_three_attestations(self):
        root = self.root()
        for flag in ("complete_cache_verified", "independent_storage_verified", "adapter_trace_verified", None):
            output = self.derived_output()
            def unverifiable(parent, result, history, branch, purpose):
                if flag is None:
                    return True
                return replace(self.derived_verifier(parent, result, history, branch, purpose), **{flag: False})
            with self.subTest(flag=flag), self.assertRaises(ancestry.AncestryError):
                self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                    branch="Hctx32", verifier_callback=unverifiable)
            with self.assertRaises(ancestry.AncestryError):
                self.registry.inspect(output.owner)

    def test_derived_verification_wrong_same_length_parent_rejected(self):
        root, wrong = self.root(), self.root()
        output = self.derived_output()
        def wrong_parent(parent, result, history, branch, purpose):
            return replace(self.derived_verifier(parent, result, history, branch, purpose),
                           parent_owner=wrong, parent_cache=wrong.cache, parent_version=wrong.version)
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                branch="Hctx32", verifier_callback=wrong_parent)

    def test_derived_reported_wrong_cache_identity_rejected_before_verifier(self):
        root = self.root()
        output = replace(self.derived_output(), cache=SpyCache((11, 22, 77)))
        before = self.callback_calls
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                branch="Hctx32", verifier_callback=self.derived_verifier)
        self.assertEqual(self.callback_calls, before)

    def test_derived_verifier_wrong_child_identity_is_rejected(self):
        root = self.root()
        output = self.derived_output()
        def wrong_child(parent, result, history, branch, purpose):
            return replace(self.derived_verifier(parent, result, history, branch, purpose),
                           derived_cache=SpyCache(history))
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                branch="Hctx32", verifier_callback=wrong_child)

    def test_derived_cannot_alias_parent_or_existing_candidate(self):
        root = self.root()
        clone = self.clone(root)
        aliased = ancestry.DerivedCache(root, root.cache, root.version, (11, 22), {}, {})
        reused = ancestry.DerivedCache(clone, clone.cache, clone.version, (11, 22), {}, {})
        for output in (aliased, reused):
            with self.assertRaises(ancestry.AncestryError):
                self.registry.register_derived(root, output, expected_history=(11, 22),
                    branch="Hctx32", verifier_callback=self.derived_verifier)

    def test_derived_exact_history_not_inferred_from_equal_length(self):
        root = self.root()
        output = self.derived_output((11, 22, 99))
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                branch="Hctx32", verifier_callback=self.derived_verifier)
        self.assertEqual(self.callback_calls, 0)

    def test_derived_callback_cannot_mutate_parent_or_child_identity(self):
        root = self.root()
        output = self.derived_output()
        def mutates_child(parent, result, history, branch, purpose):
            checked = self.derived_verifier(parent, result, history, branch, purpose)
            result.owner.cache = SpyCache(history)
            return checked
        with self.assertRaises(ancestry.AncestryError):
            self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                branch="Hctx32", verifier_callback=mutates_child)

    def test_derived_invalid_trace_digest_or_empty_provenance_rejected(self):
        root = self.root()
        for changes in ({"adapter_trace_sha256": "not-a-digest"}, {"verifier_provenance": ""}):
            output = self.derived_output()
            def invalid(parent, result, history, branch, purpose):
                return replace(self.derived_verifier(parent, result, history, branch, purpose), **changes)
            with self.assertRaises(ancestry.AncestryError):
                self.registry.register_derived(root, output, expected_history=(11, 22, 77),
                    branch="Hctx32", verifier_callback=invalid)

    def test_exact_tuple_tokens_reject_bool_or_noninteger_or_negative_ids(self):
        for tokens in ([11, 22], (True, 22), (-1, 22), (11.0, 22)):
            root = SpyOwner((11, 22))
            with self.assertRaises(ancestry.AncestryError):
                self.registry.register_native_root(self.output(root, tokens=tokens),
                                                   branch="root", purpose="native")


if __name__ == "__main__":
    unittest.main(verbosity=2)
