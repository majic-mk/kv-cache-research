"""Model-free source/call identity regressions; no native numerical claims."""
import copy
from contextlib import nullcontext
import unittest
from unittest.mock import patch

import contract_reconstructed as contract
import contextual_native_reconstructed as contextual
from native_backend_reconstructed import NativeCalls


class Box:
    def __init__(self, **values):
        self.__dict__.update(values)


class CanonicalCellTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cells = contract.plan()

    def test_all24_complete_cells_are_detached(self):
        for cell in self.cells:
            result = contract.canonical_cell(cell)
            self.assertEqual(result, cell)
            self.assertIsNot(result, cell)
            self.assertIsNot(result['calls'], cell['calls'])
            self.assertIsNot(result['calls'][0]['input_ids'], cell['calls'][0]['input_ids'])
            self.assertIsNot(result['candidates'], cell['candidates'])

    def test_every_top_level_field_is_required_and_fixed(self):
        for name in self.cells[16]:
            with self.subTest(field=name):
                cell = copy.deepcopy(self.cells[16])
                del cell[name]
                with self.assertRaises(ValueError):
                    contract.canonical_cell(cell)
                cell = copy.deepcopy(self.cells[16])
                cell[name] = object()
                with self.assertRaises(ValueError):
                    contract.canonical_cell(cell)

    def test_every_call_field_is_required_and_fixed(self):
        for index, call in enumerate(self.cells[0]['calls']):
            for name in call:
                with self.subTest(call=index, field=name):
                    cell = copy.deepcopy(self.cells[0])
                    cell['calls'][index][name] = object()
                    with self.assertRaises(ValueError):
                        contract.canonical_cell(cell)

    def test_edited_A_B_Q_candidates_orders_and_extra_fields_fail(self):
        changes = [
            lambda c: c['calls'][0]['input_ids'].__setitem__(0, 17),
            lambda c: c['calls'][1]['input_ids'].__setitem__(0, 17),
            lambda c: c['calls'][2]['input_ids'].__setitem__(0, 17),
            lambda c: c['candidates'][c['expected_answer']].__setitem__(0, 17),
            lambda c: c['calls'].reverse(),
            lambda c: c.update(candidates=dict(reversed(tuple(c['candidates'].items())))),
            lambda c: c.update(unfrozen='extra'),
            lambda c: c['calls'][0].update(unfrozen='extra'),
        ]
        for change in changes:
            cell = copy.deepcopy(self.cells[0])
            change(cell)
            with self.assertRaises(ValueError):
                contract.canonical_cell(cell)

    def test_exact_types_reject_bool_int_coercion_and_subclasses(self):
        cell = copy.deepcopy(self.cells[0])
        cell['calls'][0]['absolute_start'] = False
        with self.assertRaises(ValueError):
            contract.canonical_cell(cell)
        cell = copy.deepcopy(self.cells[0])
        cell['source_capture_during_B'] = 1
        with self.assertRaises(ValueError):
            contract.canonical_cell(cell)
        class DictSubclass(dict):
            pass
        with self.assertRaises(ValueError):
            contract.canonical_cell(DictSubclass(self.cells[0]))

    def test_native_bind_rejects_changed_cell_and_detaches_nested_inputs(self):
        backend = NativeCalls.__new__(NativeCalls)
        backend.current = None
        cell = copy.deepcopy(self.cells[0])
        changed = copy.deepcopy(cell)
        changed['calls'][0]['input_ids'][0] += 1
        with self.assertRaises(ValueError):
            backend.bind(changed)
        self.assertIsNone(backend.current)
        backend.bind(cell)
        cell['calls'][0]['input_ids'][0] += 1
        cell['candidates'][cell['expected_answer']][0] += 1
        self.assertEqual(backend.current, self.cells[0])


class CanonicalSourceTests(unittest.TestCase):
    def setUp(self):
        self.cells = contract.plan()
        self.cell = self.cells[0]
        self.A, self.B = (tuple(p['input_ids']) for p in self.cell['calls'][:2])
        self.provenance = contract.source_provenance(self.cell)

    def source(self):
        return Box(A=self.A, B=self.B, provenance=copy.deepcopy(self.provenance),
            manifest=dict(A_ids=list(self.A), B_ids=list(self.B),
                history_ids=list(self.A+self.B), capture_provenance=copy.deepcopy(self.provenance)))

    def test_only_two_frozen_R_A1_cells_are_sources(self):
        admitted = []
        for cell in self.cells:
            if cell['cell_id'] in ('ch01', 'ch09'):
                p = contract.source_provenance(cell)
                self.assertEqual(p['call_id'], cell['pre_Q_producer'])
                self.assertEqual(p['root_call_id'], cell['calls'][0]['call_id'])
                admitted.append(cell['cell_id'])
            else:
                with self.assertRaises(ValueError):
                    contract.source_provenance(cell)
        self.assertEqual(admitted, ['ch01', 'ch09'])

    def test_complete_provenance_fields_and_tokens_are_fixed(self):
        self.assertEqual(contract.validate_source_provenance(self.A, self.B, self.provenance), self.provenance)
        for key in self.provenance:
            with self.subTest(field=key):
                edited = copy.deepcopy(self.provenance)
                edited[key] = 'wrong'
                with self.assertRaises(ValueError):
                    contract.validate_source_provenance(self.A, self.B, edited)
        for A, B in ((self.A[:-1], self.B), (self.A, self.B[:-1]),
                     ((True,)+self.A[1:], self.B), (list(self.A), self.B)):
            with self.assertRaises(ValueError):
                contract.validate_source_provenance(A, B, self.provenance)

    def test_A2_cannot_be_internally_consistent_but_mislabeled_A1(self):
        A2 = tuple(self.cells[2]['calls'][0]['input_ids'])
        forged = copy.deepcopy(self.provenance)
        forged['A_ids_sha256'] = contract.digest(list(A2))
        forged['history_ids_sha256'] = contract.digest(list(A2+self.B))
        with self.assertRaises(ValueError):
            contract.validate_source_provenance(A2, self.B, forged)
        with self.assertRaises(ValueError):
            contract.validate_source_provenance(A2, self.B, self.provenance)

    def test_all_four_target_variants_require_their_own_group_R_A1(self):
        for target in self.cells[16:20]:
            self.assertEqual(contract.validate_hctx_source(target, self.A, self.B, self.provenance), self.provenance)
        for target in self.cells[20:]:
            with self.assertRaises(ValueError):
                contract.validate_hctx_source(target, self.A, self.B, self.provenance)
        with self.assertRaises(ValueError):
            contract.validate_hctx_source(self.cell, self.A, self.B, self.provenance)

    def test_source_manifest_cannot_relabel_provenance_or_history(self):
        for key in ('capture_provenance', 'A_ids', 'B_ids', 'history_ids'):
            source = self.source()
            source.manifest[key] = None
            with self.assertRaises(ValueError):
                contextual._verify_source_provenance(source, self.cells[16])

    def capture(self, *, cell=None, active_identity=None, completed_identity=None):
        cell = self.cell if cell is None else cell
        model = Box(model=Box(layers=[]))
        cache = Box()
        result = Box(cache=cache)
        backend = Box(current=cell, engine=Box(), torch=Box(Tensor=type('UnusedTensor', (), {})),
            cost_event=lambda row: None,
            active_capture_identity=lambda cache: copy.deepcopy(self.provenance if active_identity is None else active_identity),
            completed_capture_identity=lambda owner: copy.deepcopy(self.provenance if completed_identity is None else completed_identity),
            history_of=lambda value: self.A+self.B if value is result else self.A,
            cache_of=lambda value: value.cache,
            installed_context=lambda: nullcontext())
        capture = contextual.ContextualCapture(model, backend, self.A, self.B)
        capture.costs = Box(clone_cache=lambda cache, name: Box(), snapshot=lambda cache, name: {},
                            time=lambda *a, **kw: nullcontext())
        return capture, backend, result

    def test_capture_rejects_non_source_cell_before_installing_any_hooks(self):
        for cell in (self.cells[1], self.cells[2], self.cells[16]):
            with self.assertRaises(ValueError):
                self.capture(cell=cell)

    def test_capture_requires_backend_actual_identity_hooks(self):
        backend = Box(current=self.cell)
        with self.assertRaisesRegex(TypeError, 'identity hooks'):
            contextual.ContextualCapture(Box(), backend, self.A, self.B)

    def test_rebound_capture_cell_is_rejected_before_hook_installation(self):
        capture, backend, result = self.capture()
        backend.current = self.cells[8]
        with self.assertRaisesRegex(ValueError, 'Bound source cell changed'):
            capture.__enter__()
        self.assertEqual(capture.patches.entries, [])
        self.assertFalse(capture.entered)

    def test_root_refuses_wrong_active_call_identity_before_original(self):
        forged = copy.deepcopy(self.provenance)
        forged['call_id'] = 'ch03.n02'
        capture, backend, result = self.capture(active_identity=forged)
        calls = []
        def original(input_ids, past_key_values):
            calls.append(True)
            return Box(past_key_values=result.cache)
        with self.assertRaises(ValueError):
            capture._root(original)(Box(tolist=lambda: [list(self.B)]), Box())
        self.assertEqual(calls, [])
        self.assertEqual(capture.calls, 0)

    def test_finish_retains_the_actual_active_and_completed_capture_identity(self):
        capture, backend, result = self.capture()
        def original(input_ids, past_key_values):
            return Box(past_key_values=result.cache)
        with patch.object(contextual, '_validate_cache'), patch.object(contextual, '_engine_binding',
                return_value=({'stubbed_model_free': True}, 'stubbed-model-free')):
            capture._root(original)(Box(tolist=lambda: [list(self.B)]), Box())
            capture.context_success = True
            source = capture.finish(result)
        self.assertEqual(source.provenance, self.provenance)
        self.assertEqual(source.manifest['capture_provenance'], self.provenance)
        self.assertIsNot(source.provenance, source.manifest['capture_provenance'])
        self.assertEqual(source.manifest['model_calls_observed'], 1)
        self.assertEqual(source.manifest['extra_source_model_calls'], 0)

    def test_finish_rejects_wrong_completed_owner_identity(self):
        forged = copy.deepcopy(self.provenance)
        forged['cell_id'] = 'ch03'
        capture, backend, result = self.capture(completed_identity=forged)
        capture.context_success = True
        capture.observed_provenance = self.provenance
        with self.assertRaises(ValueError):
            capture.finish(result)
        self.assertFalse(capture.finished)

    def test_target_calls_do_not_start_for_wrong_group_source_or_target_tokens(self):
        calls = []
        backend = Box(current=self.cells[20], checked_forward=lambda *a, **kw: calls.append((a, kw)))
        adapter = contextual.HctxAdapter.__new__(contextual.HctxAdapter)
        adapter.backend, adapter.source = backend, self.source()
        with self.assertRaises(ValueError):
            adapter.build(tuple(self.cells[20]['calls'][0]['input_ids']), adapter.source.B)
        backend.current = self.cells[16]
        for A, B in ((self.A[:-1], self.B), (self.A, self.B[:-1])):
            with self.assertRaises(ValueError):
                adapter.build(A, B)
        with self.assertRaises(ValueError):
            adapter.build(self.A, self.B, width=32.0)
        self.assertEqual(calls, [])


if __name__ == '__main__':
    unittest.main()
