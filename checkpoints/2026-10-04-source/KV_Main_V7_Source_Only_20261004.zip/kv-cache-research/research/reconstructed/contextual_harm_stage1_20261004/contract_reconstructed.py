"""NEW reconstruction from recovered v3 inputs and retained conversation context.

Not byte-identical recovery of the lost firststage implementation. Stdlib-only;
no model, tokenizer, environment acquisition or execution capability exists here.
"""
from __future__ import annotations
import copy,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
V3=REPO/'research/protocols/hybrid_cpu_quality_v3'
GROUPS=('d01','d05');VARIANTS=('A1','A2','U1','U2');WIDTH=32
EOS=248046;VOCAB=248320;GREEDY_CAP=8
RECONSTRUCTION='NEW_RECONSTRUCTION_NOT_EXACT_RECOVERY'

def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(1024**2),b''):h.update(data)
    return h.hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def verify_recovered_freezes():
    n=0
    for name in ('hybrid_cpu_quality','hybrid_cpu_quality_v2','hybrid_cpu_quality_v3'):
        directory=V3.parent/name
        for file,record in read(directory/'freeze_manifest.json')['files'].items():
            if sha(directory/file)!=record['sha256']:raise ValueError('Recovered freeze changed: '+str(directory/file))
            n+=1
    return n

def recovered_contexts():
    """Check saved all64 records; this does not rerun missing tokenizer assets."""
    raw=read(V3/'token_validation.json')
    if sha(V3/'fixtures.jsonl')!=raw['fixture_jsonl_sha256'] or sha(V3/'template.json')!=raw['template_sha256']:
        raise ValueError('Recovered token evidence source differs')
    rows=raw['token_checks']['contexts']
    order=[(f'{split}{i:02d}',v) for split in ('d','h') for i in range(1,9) for v in VARIANTS]
    if [(r['pair_id'],r['variant']) for r in rows]!=order:raise ValueError('All64 order differs')
    fixtures={r['pair_id']:r for r in map(json.loads,(V3/'fixtures.jsonl').read_text().splitlines())}
    for r in rows:
        if r['input_ids']!=r['A_ids']+r['B_ids']+r['Q_ids']:raise ValueError('A/B/Q not whole-token slices')
        f=fixtures[r['pair_id']]
        gold=f['expected_answer_'+r['variant']] if r['variant'] in ('A1','A2') else f['expected_answer_A1']
        if gold!=r['expected_answer'] or list(r['answer_candidate_ids_including_eos'])!=f['answer_candidates']:
            raise ValueError('Gold/candidate order differs')
        if not 128<=len(r['B_ids'])<=256 or len(r['input_ids'])>512:raise ValueError('Extent differs')
        for ids in r['answer_candidate_ids_including_eos'].values():
            if not 2<=len(ids)<=8 or ids[-1]!=EOS or EOS in ids[:-1]:raise ValueError('EOS contract differs')
    for pair in fixtures:
        rr=[r for r in rows if r['pair_id']==pair]
        if len({digest(r['B_ids']) for r in rr})!=1 or len({digest(r['Q_ids']) for r in rr})!=1:raise ValueError('Shared B/Q differ')
    return rows

def numerical_limits():
    # Surviving source, not a reconstructed lost FP32 result. The remembered
    # FP32 protocol retained these exact engineering thresholds prospectively.
    return read(V3/'numerical_contract.json')['bf16_exact_schedule_controls']

def plan():
    contexts=[r for r in recovered_contexts() if r['pair_id'] in GROUPS]
    sequence=[(r,a) for r in contexts for a in ('R','F32')]+[(r,'Hctx32') for r in contexts]
    cells=[]
    for index,(r,arm) in enumerate(sequence,1):
        cid=f'ch{index:02d}';A,B,Q=[r[k] for k in ('A_ids','B_ids','Q_ids')];calls=[]
        a,n,total=len(A),len(B),len(A+B+Q)
        def add(label,ids,start,branch='prefill',conditional=False):
            calls.append(dict(call_id=f'{cid}.n{len(calls)+1:02d}',label=label,branch_id=branch,
                input_ids=ids,network_tokens=1 if ids is None else len(ids),
                absolute_start=start,absolute_stop_exclusive=start+(1 if ids is None else len(ids)),
                conditional_on_no_previous_EOS=conditional,cache_parent=None,cache_ownership=None))
        add('A',A,0)
        if arm=='R':add('B',B,a)
        else:
            add('B_seam',B[:WIDTH],a)
            if arm=='F32':add('B_fresh_suffix',B[WIDTH:],a+WIDTH)
        add('Q',Q,a+n,'Q_from_owned_pre_Q_clone')
        for answer,ids in r['answer_candidate_ids_including_eos'].items():
            for j,token in enumerate(ids[:-1]):add(f'candidate_{answer}_{j+1}',[token],total+j,'candidate:'+answer)
        for j in range(GREEDY_CAP-1):add(f'greedy_{j+1}',None,total+j,'greedy',True)
        q=next(c['call_id'] for c in calls if c['label']=='Q');last={}
        for j,c in enumerate(calls):
            branch=c['branch_id']
            if c['label']=='A':c['cache_ownership']='independent_empty_cache'
            elif c['label']=='Q':c.update(cache_parent=cid+'.pre_Q',cache_ownership='verified_nonaliasing_clone')
            elif branch=='greedy' or branch.startswith('candidate:'):
                c.update(cache_parent=last.get(branch,q),cache_ownership='private_branch_continuation' if branch in last else 'verified_nonaliasing_post_Q_clone');last[branch]=c['call_id']
            else:c.update(cache_parent=calls[j-1]['call_id'],cache_ownership='same_owned_prefill_cache')
        cells.append(dict(cell_id=cid,pair_id=r['pair_id'],variant=r['variant'],arm=arm,split='development',
            expected_answer=r['expected_answer'],candidates=r['answer_candidate_ids_including_eos'],
            A_tokens=a,B_tokens=n,Q_tokens=len(Q),full_ids_sha256=digest(A+B+Q),B_ids_sha256=digest(B),
            source_capture_during_B=arm=='R' and r['variant']=='A1',source_ancestor=None,reference_cell=None,
            pre_Q_producer=cid+'.Hctx32_assembly' if arm=='Hctx32' else next(c['call_id'] for c in reversed(calls) if c['label'] in ('B','B_fresh_suffix')),
            calls=calls,status='not_run_reconstructed_hold',reconstruction=RECONSTRUCTION))
    index={(r['pair_id'],r['variant'],r['arm']):r['cell_id'] for r in cells}
    for c in cells:
        if c['arm']=='F32':c['reference_cell']=index[c['pair_id'],c['variant'],'R']
        elif c['arm']=='Hctx32':
            c['reference_cell']=index[c['pair_id'],c['variant'],'F32'];c['source_ancestor']=index[c['pair_id'],'A1','R']
    return cells

def _exact_value(actual, expected):
    """JSON-shaped equality without bool/int coercion or container subclasses."""
    if type(actual) is not type(expected):return False
    if type(expected) is dict:
        return (all(type(k) is str for k in actual) and actual.keys()==expected.keys()
            and all(_exact_value(actual[k],v) for k,v in expected.items()))
    if type(expected) is list:
        return len(actual)==len(expected) and all(_exact_value(a,e) for a,e in zip(actual,expected))
    return actual==expected

_CANONICAL_PLAN_JSON=None
def _canonical_plan_snapshot():
    global _CANONICAL_PLAN_JSON
    if _CANONICAL_PLAN_JSON is None:
        verify_recovered_freezes()
        _CANONICAL_PLAN_JSON=json.dumps(plan(),separators=(',',':'),allow_nan=False)
    return json.loads(_CANONICAL_PLAN_JSON)

def canonical_cell(cell):
    """Validate every field against the fixed first24; return a detached copy.

    Neither caller labels nor a self-reported digest turn an edited call plan
    into the frozen experiment. Copy the trusted reconstruction, not caller
    objects, so later edits of any nested candidate/call/token list are isolated.
    Candidate mapping order is scientific scoring order and is also fixed.
    """
    if type(cell) is not dict or type(cell.get('cell_id')) is not str:
        raise ValueError('Expected a complete canonical first24 cell')
    expected=next((p for p in _canonical_plan_snapshot() if p['cell_id']==cell['cell_id']),None)
    if (expected is None or not _exact_value(cell,expected)
            or list(cell['candidates'])!=list(expected['candidates'])):
        raise ValueError('Cell differs from complete canonical first24 plan')
    return copy.deepcopy(expected)

def source_provenance(cell):
    """Frozen producer identity; actual invocation/owner checks belong to backend.

    A capture obtains this identity from the active native B call, then again
    from its successfully registered output. It must never infer provenance
    from the A/B values supplied by the capture caller alone.
    """
    cell=canonical_cell(cell)
    if not (cell['source_capture_during_B'] is True and cell['arm']=='R'
            and cell['variant']=='A1' and cell['pair_id'] in GROUPS):
        raise ValueError('Contextual source must be the frozen group R/A1 producer')
    root=next(p for p in cell['calls'] if p['label']=='A')
    call=next(p for p in cell['calls'] if p['label']=='B')
    return dict(pair_id=cell['pair_id'],variant='A1',arm='R',cell_id=cell['cell_id'],
        cell_sha256=digest(cell),call_id=call['call_id'],call_sha256=digest(call),
        root_call_id=root['call_id'],root_call_sha256=digest(root),
        source_pre_Q_producer=cell['pre_Q_producer'],
        A_ids_sha256=digest(root['input_ids']),B_ids_sha256=digest(call['input_ids']),
        history_ids_sha256=digest(root['input_ids']+call['input_ids']))

def validate_source_provenance(A, B, provenance):
    """Require exact frozen A1+B IDs and complete canonical source identity."""
    if type(provenance) is not dict or type(provenance.get('cell_id')) is not str:
        raise ValueError('Missing canonical contextual source provenance')
    cell=next((p for p in plan() if p['cell_id']==provenance['cell_id']),None)
    if cell is None:raise ValueError('Unknown contextual source producer')
    expected=source_provenance(cell)
    if not _exact_value(provenance,expected):
        raise ValueError('Contextual source provenance differs from frozen R/A1 producer')
    source_A=next(p['input_ids'] for p in cell['calls'] if p['label']=='A')
    source_B=next(p['input_ids'] for p in cell['calls'] if p['label']=='B')
    if (type(A) is not tuple or type(B) is not tuple
            or not _exact_value(list(A),source_A) or not _exact_value(list(B),source_B)):
        raise ValueError('Contextual source IDs differ from frozen group A1+B')
    return expected

def validate_hctx_source(cell, A, B, provenance):
    """Bind a source to this exact target's prospectively fixed source ancestor."""
    cell=canonical_cell(cell)
    if cell['arm']!='Hctx32':raise ValueError('A canonical Hctx32 target cell is required')
    expected=validate_source_provenance(A,B,provenance)
    if (expected['cell_id']!=cell['source_ancestor']
            or expected['pair_id']!=cell['pair_id'] or digest(list(B))!=cell['B_ids_sha256']):
        raise ValueError('Contextual source is not this target group frozen R/A1 ancestor')
    return expected

def work_bounds(cells=None):
    cells=plan() if cells is None else cells;calls=[r for c in cells for r in c['calls']]
    scored=[r for r in calls if r['label']=='Q' or r['branch_id']=='greedy' or r['branch_id'].startswith('candidate:')]
    return dict(scored_cells=len(cells),root_model_calls_max=len(calls),network_tokens_max=sum(r['network_tokens'] for r in calls),
        mandatory_calls=sum(not r['conditional_on_no_previous_EOS'] for r in calls),
        greedy_continuation_calls_max=sum(r['conditional_on_no_previous_EOS'] for r in calls),
        scored_vocab_vectors_max=len(scored),source_only_model_calls=0,reconstruction_model_calls=0,
        complete_pre_Q_artifacts=24,extra_source_incoming_A_artifacts=2,
        exact_F32_A1_reference_cache_artifacts_max=21,other_transient_cache_raw_artifacts=0,
        source_traces=2,teacher_traces=0,seam_traces=0,
        later_teacher_and_seam_observer_traces='UNIMPLEMENTED_NOT_REQUIRED_BY_FIRST24',
        measured=False,reconstruction=RECONSTRUCTION)

def input_pins():
    files=[V3/x for x in ('fixtures.jsonl','template.json','token_validation.json','numerical_contract.json','freeze_manifest.json')]
    files += [REPO/'research/hypic_baseline_source_review.md',REPO/'research/diagnostics/hybrid_recurrence_cpu/SOURCE_AUDIT.md',
              REPO/'research/diagnostics/hybrid_cpu_competence/RESULTS.md',REPO/'research/diagnostics/hybrid_cpu_competence_v3/RESULTS.md']
    return {str(p.relative_to(REPO)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in files}

def refuse_execution():
    raise RuntimeError('HOLD_RECONSTRUCTED: native dependencies, assets, evidence and execution authority absent')
