"""Regression for the attempt1 string-subclass metadata failure; no Torch import."""
import ast,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as O
import run_original_stage1_reconstructed as loader
from evidence_sink_reconstructed import BoundedJSONLJournal,EvidenceError
class Version(str):pass
class Tests(unittest.TestCase):
    def test_actual_loader_version_expression_becomes_plain_str(self):
        tree=ast.parse(Path(loader.__file__).read_text())
        fields=[node.value for node in ast.walk(tree) if isinstance(node,ast.keyword) and node.arg=='torch_version']
        self.assertEqual(len(fields),1)
        value=eval(compile(ast.Expression(fields[0]),'<actual-loader-metadata>','eval'),{'torch':O(__version__=Version('2.9.1+cpu')),'str':str})
        self.assertIs(type(value),str)
        with tempfile.TemporaryDirectory() as tmp:
            sink=BoundedJSONLJournal(Path(tmp)/'accepted.jsonl');receipt=sink.append({'torch_version':value});sink.close();self.assertTrue(receipt.durable)
    def test_strict_serializer_still_rejects_unconverted_subclass(self):
        with tempfile.TemporaryDirectory() as tmp:
            sink=BoundedJSONLJournal(Path(tmp)/'rejected.jsonl')
            with self.assertRaisesRegex(EvidenceError,'unsupported JSON type: Version'):sink.append({'torch_version':Version('2.9.1+cpu')})
            self.assertTrue(sink.poisoned);self.assertEqual(sink.durable_ack_bytes,0);sink.close()
if __name__=='__main__':unittest.main(verbosity=2)
