"""NEWLY RECONSTRUCTED, 2026-10-04; not an exact recovery or a model result.

Standard-library-only evidence plumbing. Files are created exclusively and are
never truncated, removed, automatically reopened, or retried after failure.
The caller must keep event/metadata containers unchanged during a call and must
not share the file descriptor or permit other processes to modify the journal.
A receipt acknowledges both the row fsync and creation-directory fsync. This is
an OS durability acknowledgement, not a guarantee against broken storage.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
import threading
from dataclasses import dataclass, fields, is_dataclass
from pathlib import Path
from typing import Callable, Iterator

CHUNK_LIMIT = 64 * 1024
EVENT_LIMIT = 16 * 1024 * 1024
JOURNAL_LIMIT = 256 * 1024 * 1024
METADATA_LIMIT = 32 * 1024 * 1024
MAX_JSON_DEPTH = 128


class EvidenceError(RuntimeError):
    pass


class BudgetExceeded(EvidenceError):
    pass


class JournalPoisoned(EvidenceError):
    pass


def deep_size_bytes(value: object, *, limit: int = METADATA_LIMIT) -> int:
    """Bound owned Python container metadata, counting shared objects once.

    Supports ordinary dict/list/tuple/set/frozenset containers and dataclasses.
    Weak references are counted, not dereferenced. This is Python object-size
    accounting, not process RSS or a measurement of native/model allocations.
    Stops immediately at the budget, including when a nested child exceeds it.
    """
    if type(limit) is not int or not 0 < limit <= METADATA_LIMIT:
        raise ValueError("metadata limit must be positive and at most 32 MiB")
    seen: set[int] = set()
    stack = [iter((value,))]
    size = 0
    while stack:
        try:
            item = next(stack[-1])
        except StopIteration:
            stack.pop()
            continue
        identity = id(item)
        if identity in seen:
            continue
        seen.add(identity)
        size += sys.getsizeof(item)
        if size > limit:
            raise BudgetExceeded(f"deep Python metadata exceeds {limit} bytes")
        if isinstance(item, dict):
            stack.append(iter(item.values()))
            stack.append(iter(item.keys()))
        elif isinstance(item, (list, tuple, set, frozenset)):
            stack.append(iter(item))
        elif is_dataclass(item) and not isinstance(item, type):
            # __dict__ capacity belongs to a nonslotted dataclass too.
            attributes = getattr(item, "__dict__", None)
            if attributes is not None:
                stack.append(iter((attributes,)))
            else:
                stack.append(iter(tuple(getattr(item, field.name) for field in fields(item))))
    return size


def check_metadata_budget(value: object, *, limit: int = METADATA_LIMIT) -> int:
    return deep_size_bytes(value, limit=limit)


def _json_pieces(value: object, depth: int = 0, ancestors: set[int] | None = None) -> Iterator[bytes]:
    """Stream even a large individual string without encoding it all at once."""
    if ancestors is None:
        ancestors = set()
    if depth > MAX_JSON_DEPTH:
        raise EvidenceError("JSON nesting exceeds the explicit depth bound")
    kind = type(value)
    if value is None:
        yield b"null"
    elif kind is bool:
        yield b"true" if value else b"false"
    elif kind is str:
        yield b'"'
        # ensure_ascii makes output byte bounds independent of UTF-8 width;
        # one input character expands to at most twelve bytes (surrogate pair).
        for offset in range(0, len(value), 4096):
            piece = json.dumps(value[offset:offset + 4096], ensure_ascii=True)[1:-1].encode("ascii")
            if piece:
                yield piece
        yield b'"'
    elif kind is int:
        # Bound conversion before constructing an arbitrarily large integer string.
        if value.bit_length() > 65536:
            raise EvidenceError("integer exceeds the scalar encoding bound")
        yield str(value).encode("ascii")
    elif kind is float:
        if not math.isfinite(value):
            raise EvidenceError("non-finite JSON numbers are forbidden")
        yield json.dumps(value, allow_nan=False).encode("ascii")
    elif kind in (dict, list, tuple):
        identity = id(value)
        if identity in ancestors:
            raise EvidenceError("cyclic JSON containers are forbidden")
        ancestors.add(identity)
        try:
            yield b"{" if kind is dict else b"["
            first = True
            if kind is dict:
                for key, child in value.items():
                    if type(key) is not str:
                        raise EvidenceError("JSON object keys must be strings")
                    if not first:
                        yield b","
                    first = False
                    yield from _json_pieces(key, depth + 1, ancestors)
                    yield b":"
                    yield from _json_pieces(child, depth + 1, ancestors)
            else:
                for child in value:
                    if not first:
                        yield b","
                    first = False
                    yield from _json_pieces(child, depth + 1, ancestors)
            yield b"}" if kind is dict else b"]"
        finally:
            ancestors.remove(identity)
    else:
        raise EvidenceError(f"unsupported JSON type: {kind.__name__}")


def jsonl_chunks(event: object, *, chunk_bytes: int = CHUNK_LIMIT) -> Iterator[bytes]:
    if type(chunk_bytes) is not int or not 1 <= chunk_bytes <= CHUNK_LIMIT:
        raise ValueError("write chunks must be between 1 byte and 64 KiB")
    if type(event) is not dict:
        raise EvidenceError("each JSONL event must be an object")
    pending = bytearray()
    for piece in _json_pieces(event):
        view = memoryview(piece)
        for offset in range(0, len(view), chunk_bytes):
            segment = view[offset:offset + chunk_bytes]
            while segment:
                take = min(chunk_bytes - len(pending), len(segment))
                pending.extend(segment[:take])
                segment = segment[take:]
                if len(pending) == chunk_bytes:
                    yield bytes(pending)
                    pending.clear()
    pending.extend(b"\n")
    if pending:
        yield bytes(pending)


@dataclass(frozen=True, slots=True)
class DurableReceipt:
    event_index: int
    start_byte: int
    end_byte: int
    sha256: str
    durable: bool
    persistent: bool


class BoundedJSONLJournal:
    """Append-only exclusive JSONL; any failed append permanently poisons it.

    Short positive writes are completed. A subsequent zero/exception/invalid
    return, fsync failure, mutation, or failed preflight stops the sink forever.
    actual_written_bytes is observed file size, including a torn row;
    durable_ack_bytes advances only after a complete matching row and fsync.
    There is deliberately no reset/retry/resume/delete API.
    """
    persistent = True

    def __init__(self, path: str | Path, *, event_limit: int = EVENT_LIMIT,
                 total_limit: int = JOURNAL_LIMIT, metadata_limit: int = METADATA_LIMIT,
                 chunk_bytes: int = CHUNK_LIMIT,
                 write_fn: Callable[[int, bytes | memoryview], int] = os.write,
                 fsync_fn: Callable[[int], None] = os.fsync):
        if not 0 < event_limit <= EVENT_LIMIT or not 0 < total_limit <= JOURNAL_LIMIT:
            raise ValueError("event/total limits may only tighten 16/256 MiB caps")
        if not 0 < metadata_limit <= METADATA_LIMIT or not 0 < chunk_bytes <= CHUNK_LIMIT:
            raise ValueError("metadata/chunk limits may only tighten 32 MiB/64 KiB caps")
        self.path = Path(path)
        self.event_limit, self.total_limit = event_limit, total_limit
        self.metadata_limit, self.chunk_bytes = metadata_limit, chunk_bytes
        self._write, self._fsync = write_fn, fsync_fn
        self._lock = threading.RLock()
        self.poisoned = False
        self.poison_reason: str | None = None
        self.closed = False
        self.actual_written_bytes = 0
        self.durable_ack_bytes = 0
        self.durable_events = 0
        self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND, 0o600)
        try:
            parent_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(parent_fd)
            finally:
                os.close(parent_fd)
        except BaseException:
            self.poisoned = True
            self.poison_reason = "creation-directory fsync failed"
            os.close(self._fd)
            self.closed = True
            raise

    def _observe_actual(self) -> None:
        self.actual_written_bytes = os.fstat(self._fd).st_size

    def append(self, event: dict) -> DurableReceipt:
        with self._lock:
            if self.poisoned or self.closed:
                raise JournalPoisoned(self.poison_reason or "journal is closed")
            try:
                self._observe_actual()
                if self.actual_written_bytes != self.durable_ack_bytes:
                    raise EvidenceError("unexpected external file-size change")
                check_metadata_budget(event, limit=self.metadata_limit)
                expected_size = 0
                expected_digest = hashlib.sha256()
                for chunk in jsonl_chunks(event, chunk_bytes=self.chunk_bytes):
                    expected_size += len(chunk)
                    if expected_size > self.event_limit:
                        raise BudgetExceeded("single JSONL event exceeds byte limit")
                    if self.actual_written_bytes + expected_size > self.total_limit:
                        raise BudgetExceeded("journal exceeds total byte limit")
                    expected_digest.update(chunk)
                start = self.actual_written_bytes
                observed_size = 0
                observed_digest = hashlib.sha256()
                for chunk in jsonl_chunks(event, chunk_bytes=self.chunk_bytes):
                    observed_size += len(chunk)
                    if observed_size > expected_size:
                        raise EvidenceError("event mutated between preflight and write")
                    observed_digest.update(chunk)
                    pending = memoryview(chunk)
                    while pending:
                        count = self._write(self._fd, pending)
                        self._observe_actual()
                        if type(count) is not int or count <= 0 or count > len(pending):
                            raise EvidenceError("write returned zero or an invalid byte count")
                        pending = pending[count:]
                if observed_size != expected_size or observed_digest.digest() != expected_digest.digest():
                    raise EvidenceError("event mutated between preflight and write")
                self._observe_actual()
                if self.actual_written_bytes != start + expected_size:
                    raise EvidenceError("actual bytes do not match acknowledged writes")
                self._fsync(self._fd)
                self.durable_ack_bytes = self.actual_written_bytes
                self.durable_events += 1
                return DurableReceipt(self.durable_events, start, self.durable_ack_bytes,
                                      observed_digest.hexdigest(), True, True)
            except BaseException as exc:
                # Even KeyboardInterrupt after some writes cannot release a retry.
                self.poisoned = True
                self.poison_reason = f"append permanently failed: {type(exc).__name__}"
                try:
                    self._observe_actual()
                except OSError:
                    pass
                raise

    def close(self) -> None:
        with self._lock:
            if not self.closed:
                self.closed = True
                os.close(self._fd)

    def __enter__(self) -> BoundedJSONLJournal:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class TinyNonpersistentDigestTestSink:
    """Explicitly TEST ONLY: no retained rows and no durability acknowledgement.

    Limited to 64 KiB total even when callers request a larger scientific budget.
    It cannot stand in for persisted scientific evidence.
    """
    persistent = False

    def __init__(self, *, total_limit: int = 16 * 1024):
        if type(total_limit) is not int or not 0 < total_limit <= CHUNK_LIMIT:
            raise ValueError("tiny test sink must stay at or below 64 KiB")
        self.total_limit = total_limit
        self.actual_written_bytes = 0
        self.durable_ack_bytes = 0
        self.durable_events = 0
        self.events = 0
        self.poisoned = False
        self._digest = hashlib.sha256()

    def append(self, event: dict) -> DurableReceipt:
        if self.poisoned:
            raise JournalPoisoned("nonpersistent test sink is poisoned")
        try:
            check_metadata_budget(event, limit=min(self.total_limit * 8, METADATA_LIMIT))
            row_digest = hashlib.sha256()
            count = 0
            for chunk in jsonl_chunks(event):
                count += len(chunk)
                if self.actual_written_bytes + count > self.total_limit:
                    raise BudgetExceeded("tiny nonpersistent test sink exhausted")
                row_digest.update(chunk)
            start = self.actual_written_bytes
            # Hash the row digest, not an invented durable JSONL byte stream.
            self._digest.update(row_digest.digest())
            self.actual_written_bytes += count
            self.events += 1
            return DurableReceipt(self.events, start, self.actual_written_bytes,
                                  row_digest.hexdigest(), False, False)
        except BaseException:
            self.poisoned = True
            raise

    @property
    def digest(self) -> str:
        return self._digest.hexdigest()


class TerminalEvidenceStore:
    """One active cell, compact terminal summaries, bounded deep Python metadata.

    The explicit active_cell_id is the failure identity; no scheduler index is
    read or inferred. Full active payload stays resident until append returns a
    durable receipt. Invocation/return flags survive eviction in compact rows.
    On failed persistence the active payload is retained and the store blocked.
    """
    def __init__(self, sink: BoundedJSONLJournal | TinyNonpersistentDigestTestSink,
                 *, metadata_limit: int = METADATA_LIMIT,
                 allow_nonpersistent_test_sink: bool = False):
        if not sink.persistent and not allow_nonpersistent_test_sink:
            raise EvidenceError("scientific evidence requires a persistent journal")
        if not 0 < metadata_limit <= METADATA_LIMIT:
            raise ValueError("metadata limit may only tighten the 32 MiB cap")
        self.sink = sink
        self.metadata_limit = metadata_limit
        self._allow_test = allow_nonpersistent_test_sink
        self._active: dict | None = None
        self.compact_terminal: dict[str, dict] = {}
        self.counts = {"started": 0, "terminal": 0, "model_invoked": 0, "model_returned": 0}
        self.blocked = False
        self._lock = threading.RLock()

    @property
    def active_cell_id(self) -> str | None:
        return None if self._active is None else self._active["cell_id"]

    @property
    def active_payload(self) -> object:
        return None if self._active is None else self._active["payload"]

    def _usable(self) -> None:
        if self.blocked or self.sink.poisoned:
            raise JournalPoisoned("evidence store is blocked; retained active evidence must not be retried")

    def _bound(self, *extra: object) -> None:
        check_metadata_budget((self._active, self.compact_terminal, self.counts, extra),
                              limit=self.metadata_limit)

    def begin_cell(self, cell_id: str, payload: object) -> None:
        with self._lock:
            self._usable()
            if type(cell_id) is not str or not 1 <= len(cell_id) <= 128:
                raise EvidenceError("cell_id must be a nonempty bounded string")
            if self._active is not None or cell_id in self.compact_terminal:
                raise EvidenceError("an active or terminal cell cannot be started again")
            active = {"cell_id": cell_id, "payload": payload,
                      "model_invoked": False, "model_returned": False}
            self._bound(active)
            self._active = active
            self.counts["started"] += 1

    def mark_model_invoked(self, cell_id: str) -> None:
        with self._lock:
            self._usable()
            if self.active_cell_id != cell_id or self._active["model_invoked"]:
                raise EvidenceError("model invocation must match the uninvoked active cell")
            self._active["model_invoked"] = True
            self.counts["model_invoked"] += 1

    def mark_model_returned(self, cell_id: str) -> None:
        with self._lock:
            self._usable()
            if (self.active_cell_id != cell_id or not self._active["model_invoked"]
                    or self._active["model_returned"]):
                raise EvidenceError("model return must match the invoked active cell")
            self._active["model_returned"] = True
            self.counts["model_returned"] += 1

    def terminal(self, cell_id: str, status: str, details: object = None) -> DurableReceipt:
        with self._lock:
            self._usable()
            if self.active_cell_id != cell_id:
                raise EvidenceError("terminal cell must explicitly match the active cell")
            if status not in ("succeeded", "failed", "rejected", "aborted"):
                raise EvidenceError("invalid terminal status")
            if status == "succeeded" and not self._active["model_returned"]:
                raise EvidenceError("model success requires an observed return")
            row = {"schema": "newly_reconstructed_terminal_v1", "cell_id": cell_id,
                   "status": status, "model_invoked": self._active["model_invoked"],
                   "model_returned": self._active["model_returned"],
                   "payload": self._active["payload"], "details": details}
            compact = {key: row[key] for key in ("cell_id", "status", "model_invoked", "model_returned")}
            # Reserve upper-bounded receipt fields and dict growth before writing.
            compact.update({"event_index": (1 << 63) - 1, "start_byte": JOURNAL_LIMIT,
                            "end_byte": JOURNAL_LIMIT, "sha256": "f" * 64,
                            "durable": True, "persistent": self.sink.persistent})
            future = dict(self.compact_terminal)
            future[cell_id] = compact
            self._bound(row, compact, future)
            try:
                receipt = self.sink.append(row)
                if not (receipt.durable and receipt.persistent) and not (
                        self._allow_test and not self.sink.persistent and not receipt.persistent):
                    raise EvidenceError("terminal row received no durable persistence acknowledgement")
            except BaseException:
                self.blocked = True
                raise
            compact.update({field.name: getattr(receipt, field.name) for field in fields(receipt)})
            # Publication/eviction comes strictly after the acknowledged terminal row.
            self.compact_terminal[cell_id] = compact
            self.counts["terminal"] += 1
            self._active = None
            return receipt

    def fail_active(self, details: object) -> DurableReceipt:
        with self._lock:
            if self._active is None:
                raise EvidenceError("there is no explicit active failure identity")
            return self.terminal(self._active["cell_id"], "failed", details)
