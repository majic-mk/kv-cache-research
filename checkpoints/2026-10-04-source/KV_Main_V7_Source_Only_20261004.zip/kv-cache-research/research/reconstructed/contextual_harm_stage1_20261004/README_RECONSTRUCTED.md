# Completed contextual first24: negative scientific screen

**STOP_NO_QUALIFYING_HARM**, independently reviewed on 2026-10-04. All 24 cells,
173 logical model calls and 4,705 network tokens completed. All answers were
correct; the required two-group confidence-harm condition failed in d05/A2.
No conditional repair expansion, fixture replacement or additional forward is
authorized. Start with `FIRST24_RESULTS.md` and `FIRST24_TERMINAL_RESULT.json`.

The independently audited raw record is
`original_stage1_attempt_02/evidence/evidence.jsonl`, with 2,305 raw FP32 artifacts
beside it, totaling 1,363,509,248 bytes. All 173 full logits and 24 pre-Q caches are
retained. The sibling guard receipt passed, with 386.226860 seconds elapsed and
7,270,248,448 bytes as the conservative maximum of sampled/terminal combined HWM.

`original_stage1_attempt_01/` preserves the earlier metadata-serialization
failure before any forward, its source snapshot and full cost. Including it,
the two original attempts cost 410.948268 seconds. The only scientific retry fix
was plain-string conversion of the caller's Torch version metadata; all science
and resource limits stayed unchanged.

`READ_ONLY_FAILURE_ANALYSIS.md` separates confidence, margin and answer accuracy,
notes fixture/candidate asymmetries without assigning causes, and recommends
closing the repair expansion in favor of a problem-first pivot review. The
historical prior-overlap warnings remain. No method novelty, publication tier,
accuracy improvement or economical serving result is claimed.

These source files are new reconstructions after environment loss, not byte-exact
recovery of the earlier lost package. Both the recovered 0.8B competence failure
and 2B BF16 numerical failure remain intact. The earlier three tiny attempts also
remain intact: two output-budget failures and a numerical child pass with an
incomplete external watchdog receipt. Current original evidence does not rewrite
those records. The recovered tracked baseline and 48 freeze files are unchanged.

The package includes the canonical plan, source-conditioned HYPIC-inspired native
adapter, immediate controls, full evidence route, owned-pidfd guard and exact
meta/assign loader. It is an eager FP32 CPU diagnostic; eventual single-card
long-context serving needs an optimized path and a distinct full-cost quality
study. The CNY100 project limit and AutoDL exclusion remain; no GPU was used.
