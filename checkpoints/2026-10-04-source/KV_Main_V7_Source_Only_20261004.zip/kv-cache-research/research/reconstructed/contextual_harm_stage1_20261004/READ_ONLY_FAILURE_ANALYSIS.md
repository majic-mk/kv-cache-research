# Interpretation and next decision after the fixed negative screen

2026-10-04. **Keep STOP_NO_QUALIFYING_HARM and stop the conditional repair path.**
Recommend a problem-first pivot review rather than expanding the observer/value-
write method on these two fixtures. A narrower confidence/measurement question
can be recorded, but this result does not yet justify a new experiment or a paper
claim. This analysis reads existing outputs and prior audits only; no additional
model call, resampling, threshold change or fitted correction is performed.

## What failed, and what did not

The competent original reference, exact split continuation and A1 self-reuse
controls all passed. Thus the screen did not stop on incompetence or a numerical
substrate defect. It stopped because the prespecified conjunctive harm condition
failed in d05/A2. All 24 greedy answers, including changed-prefix reuse, matched
the expected token sequence and EOS.

Confidence changes remain observable. The exact-control noise was orders of
magnitude smaller. The proper conclusion is that **the specified two-group
answer-relevant harm screen did not qualify**, not that contextual reuse is
exact, context-independent or safe on every task.

## Confidence versus answer behavior

These are complete gold-answer-plus-EOS sequence probabilities, computed as
`exp(saved candidate logprob)`; they are not probabilities renormalized over the
two answer candidates.

| A2 group | Fresh F32 gold probability | Hctx gold probability | Fresh margin | Hctx margin |
|---|---:|---:|---:|---:|
| d01 | 0.900783 | 0.786071 | 2.362078 | 1.475046 |
| d05 | 0.977024 | 0.960524 | 7.061474 | 6.005857 |

Both margins remain positive and both answers remain correct. In d05, the
non-gold copper sequence becomes less unlikely (logprob -7.084719 to -6.046133),
while the already-high silver probability changes only modestly. A roughly
one-nat margin change therefore coexists with only 0.017032 nat of gold loss.
This explains the metric combination descriptively; it does not invalidate or
retroactively replace the 0.1-nat conjunctive threshold.

Both fixture families are short role/occupation lookup tasks with the relevant
B sentence beyond the 32-token seam. Their A1/A2 prefixes swap assignments.
The stronger fresh d05/A2 confidence is an observed baseline property, not proof
that the semantics are inherently easier. Name/role/material wording, token
priors and candidate lengths are confounded: copper+EOS has three tokens, while
silver+EOS and the color candidates have two. These data cannot causally separate
those explanations. Counterbalancing them now to find a larger effect would be
a new experiment and must not be used to rescue this screen.

The U controls also caution against treating every margin shift as an answer
error. d01/U1 and U2 have gold losses about 0.0255/0.0260 and margin losses
0.2749/0.2229; d05/U1 and U2 slightly improve their gold scores under Hctx.
The A2 effects differ from those irrelevant-prefix controls, but two constructed
groups establish neither prevalence nor generalization.

## What the evidence cannot identify

No donor intervention or channel-specific correction was run. We cannot infer
that the effect originates mainly in layer 20 recurrent writes, that a layer 19
prefix-attention observer is sufficient, or that convolution/KV errors are
irrelevant. A correct final answer does not imply equal hidden state, and a
hidden-state discrepancy does not imply a useful repair target. Endpoint and
source traces are evidence for this completed comparison, not permission to
reverse-engineer a successful arm or select a layer post hoc.

The captured CPU system is an intentionally instrumented diagnostic. The arena
alone performs about 1.30 TB of logical casts; all setup, source capture, cache
copies, hashing, file-backed restore and failed preparation are charged. These
numbers do not establish a useful single-card serving tradeoff. An eventual
optimized attention/recurrent path needs its own complete cost and quality
comparison, and no GPU expenditure is justified by this negative screen.

## Prior overlap remains a separate obstacle

The existing source audit already separates the HYPIC tuple/seam defect from
contextual warmup and deeper conditioning loss. Fixing that source definition or
observing confidence changes is not a novelty claim. The current arm remains a
HYPIC-inspired intended-semantics reference, not an author-runtime reproduction.

The retained [prior audit](../../recurrent_response_prior_audit.md), with cutoff
2026-10-03, already flags low-rank input-response corrections (ICC), cross-prefix
cache deltas (KVCOMM/KVCMAS/Kamera), and shallow-probe-controlled correction.
Moving those ideas into a hybrid recurrent state is insufficient by itself.
The missing-information warning also remains: a recurrent boundary and finite
seam do not universally identify interior prefix-attention forcing. This report
has not refreshed that literature search or reproduced those methods.

## Bounded next action and stop rule

The useful read-only pass is now mostly complete: retain all eight variant
contrasts, distinguish sequence probability from margin/answer accuracy, inspect
fixture asymmetries without attributing causes, and reconcile the observation
with the already known overlap. Independent terminal review has now checked raw
scores/provenance and confirmed the fixed negative stop decision. This bounded
analysis is complete; do not launch a sweep, alter d05, lower the threshold or reopen the 100-cell
conditional stage.

Decision: **close this repair-expansion proposal for the present protocol.** If
research continues, prefer a separately justified practical question chosen
before new outcomes. The earlier [topic reassessment](../../topic_reassessment_20261003.md)
ranked shared-prefix retention under a unique physical-byte budget highest for a
CPU problem-first audit, but even that requires strong shared-full-prefix,
common-mask and copy-on-write controls and currently has no promoted method.
Alternatively, a distinct study of confidence-preserving versus answer-preserving
reuse would need an independently fixed workload and an explicit deployment
purpose; it is not a positive reinterpretation of these results. Neither option
is automatically authorized here or guaranteed to support a publication tier.
