"""NEW original-first24 external guard; source locked, never auto-retries.

Reuses the corrected owned-wait4 terminal truth. Current CLI only performs
stdlib preflight and returns HOLD before starting a child or creating outputs.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import contract_reconstructed as c
from original_admission_reconstructed import (ASSET_DIRECTORY,RUNTIME_DIRECTORY,
    OriginalExecutionHold,preflight,source_pins)
from guard_native_self_reuse_reconstructed import sample_or_reap,status,ProcessMetricsUnavailable


def retained_bytes(root):
    return sum(p.stat().st_size for p in Path(root).rglob('*') if p.is_file())


def descendants(pid):
    """This route admits one CPU child only; unexpected descendants fail closed."""
    parents={}
    for path in Path('/proc').glob('[0-9]*/status'):
        try:
            values={r.split(':',1)[0]:r.split(':',1)[1].strip() for r in path.read_text().splitlines() if ':' in r}
            parents[int(path.parent.name)]=int(values['PPid'])
        except (FileNotFoundError,ProcessLookupError,KeyError,ValueError):continue
    found=set();front={pid}
    while front:
        nxt={child for child,parent in parents.items() if parent in front and child not in found}
        found.update(nxt);front=nxt
    return sorted(found)


# Linux UAPI: include/uapi/linux/pidfd.h; group scope was added in Linux6.9.
# Kernel signal.c resolves the retained pidfd PID object directly to PGID, so
# a reaped/reused numeric PID cannot redirect this signal to another group.
PIDFD_SIGNAL_PROCESS_GROUP = 1 << 2
RECEIPT_RESERVE_BYTES = 256 * 1024


def host_memory(meminfo=None):
    if meminfo is None:meminfo=Path('/proc/meminfo').read_text()
    values={}
    for row in meminfo.splitlines():
        name,sep,rest=row.partition(':')
        if name in ('MemTotal','MemAvailable'):
            parts=rest.split()
            if not sep or len(parts)!=2 or parts[1]!='kB' or name in values:
                raise ProcessMetricsUnavailable('Malformed host memory field')
            try:values[name]=int(parts[0])*1024
            except ValueError as exc:raise ProcessMetricsUnavailable('Malformed host memory value') from exc
    if set(values)!={'MemTotal','MemAvailable'} or not 0<=values['MemAvailable']<=values['MemTotal'] or values['MemTotal']<=0:
        raise ProcessMetricsUnavailable('Missing/impossible host memory metrics')
    return dict(host_total_bytes=values['MemTotal'],host_available_bytes=values['MemAvailable'],
        host_unavailable_bytes=values['MemTotal']-values['MemAvailable'])


def process_identity(pid):
    text=Path('/proc',str(pid),'stat').read_text();end=text.rfind(')')
    fields=text[end+2:].split()
    if end<0 or len(fields)<20:raise ProcessMetricsUnavailable('Malformed owned process stat')
    return dict(pid=int(text.split(' ',1)[0]),pgid=int(fields[2]),sid=int(fields[3]),starttime_ticks=int(fields[19]))


def verify_group_pidfd_support():
    if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
        raise OriginalExecutionHold('Stable owned process-group signaling unavailable')
    # Signal0 is only an existence/permission probe; no signal is delivered.
    fd=os.pidfd_open(os.getpid())
    try:
        try:signal.pidfd_send_signal(fd,0,None,PIDFD_SIGNAL_PROCESS_GROUP)
        except ProcessLookupError:pass  # Calling process need not be a group leader.
        except OSError as exc:raise OriginalExecutionHold('Group-scoped pidfd support unavailable: '+str(exc)) from exc
    finally:os.close(fd)


class OwnedProcessGroup:
    def __init__(self,pid):
        self.pid=pid;self.fd=os.pidfd_open(pid);self.closed=False
        try:
            before=process_identity(pid);after=process_identity(pid)
            if before!=after or before['pid']!=pid or before['pgid']!=pid or before['sid']!=pid:
                raise ProcessMetricsUnavailable('Child is not the unchanged owned session/group leader')
            self.identity=before
        except BaseException:
            os.close(self.fd);self.closed=True;raise
    def send(self,sig):
        if self.closed:raise RuntimeError('Owned group pidfd already closed')
        try:signal.pidfd_send_signal(self.fd,sig,None,PIDFD_SIGNAL_PROCESS_GROUP);return True
        except ProcessLookupError:return False
    def close(self):
        if not self.closed:os.close(self.fd);self.closed=True


def resource_snapshot(started,out,log,samples,*,receipt_reserve=0):
    phase=None
    try:phase=c.read(out/'phase.json')['phase']
    except (FileNotFoundError,ValueError,KeyError):pass
    return dict(elapsed_seconds=time.monotonic()-started,phase=phase,**host_memory(),
        free_disk_bytes=shutil.disk_usage(c.HERE).free,retained_bytes=retained_bytes(c.HERE),
        log_and_sample_bytes=sum(p.stat().st_size for p in (log,samples) if p.exists()),
        prospective_receipt_bytes=receipt_reserve)


def resource_violations(snapshot,limits,bounds):
    reasons=[];reserve=snapshot['prospective_receipt_bytes']
    if snapshot['elapsed_seconds']>=limits['wall_seconds']:reasons.append('load_and_execution_wall_limit')
    if snapshot['elapsed_seconds']>=limits['load_seconds'] and snapshot['phase'] not in ('native_ready','executing_first24','engine_restored'):
        reasons.append('original_load_wall_limit')
    if snapshot['host_unavailable_bytes']>=limits['host_budget_bytes']:reasons.append('host_unavailable_memory_limit')
    if snapshot['free_disk_bytes']-reserve<limits['disk_floor_bytes']:reasons.append('disk_floor')
    if snapshot['retained_bytes']+reserve>=bounds['retained_artifact_cap_bytes']:reasons.append('retained_artifact_cap')
    if snapshot['log_and_sample_bytes']+reserve>=bounds['guard_log_reserve_bytes']:reasons.append('guard_log_reserve_exceeded')
    return reasons


def terminal_group_cleanup(owner,*,grace_seconds=2.):
    # Called even AFTER leader wait4. The original fd remains the authority;
    # numeric process/group IDs are never used as fallback signaling targets.
    survivor=owner.send(0)
    if not survivor:return dict(group_survived_leader=False,kill_sent=False,group_still_present=False)
    owner.send(signal.SIGKILL);deadline=time.monotonic()+grace_seconds
    while owner.send(0) and time.monotonic()<deadline:time.sleep(.02)
    return dict(group_survived_leader=True,kill_sent=True,group_still_present=owner.send(0))


def guard_once(admission, output_dir, *, started=None):
    admission.assert_execution_allowed()  # No subprocess/files before this gate.
    out=Path(output_dir).resolve()
    if out.parent != c.HERE:raise ValueError('New run and all evidence must remain in reconstructed directory')
    log=out.with_suffix('.log');receipt=out.with_name(out.name+'_guard.json')
    sample_path=out.with_name(out.name+'_guard_samples.jsonl')
    if any(p.exists() for p in (out,log,receipt,sample_path)):
        raise ValueError('Attempt/evidence already exists; no overwrite or automatic rerun')
    limits=admission.limits;bounds=admission.bounds
    started=time.monotonic() if started is None else started
    if time.monotonic()-started>=min(limits['wall_seconds'],limits['load_seconds']):
        raise OriginalExecutionHold('Initial CLI preflight exhausted the load/total deadline; child not started')
    before_retained=retained_bytes(c.HERE)
    if before_retained+bounds['new_artifact_envelope_bytes'] >= bounds['retained_artifact_cap_bytes']:
        raise OriginalExecutionHold('Prospective complete retained evidence exceeds admitted cap')
    if shutil.disk_usage(c.HERE).free < limits['disk_floor_bytes']+bounds['new_artifact_envelope_bytes']:
        raise OriginalExecutionHold('Complete retained evidence plus disk floor not available')
    if host_memory()['host_unavailable_bytes']>=limits['host_budget_bytes']:
        raise OriginalExecutionHold('Host unavailable memory already reaches9GB ceiling')
    verify_group_pidfd_support()
    pins=source_pins();reason=None;sent=None;process=None;owner=None
    usage=None;code=None;terminal_race=False;sample_count=0;failures=[];extra_children=set();host_peak=0;terminal_resources=None;cleanup=None
    env=dict(os.environ,RECONSTRUCTED_ORIGINAL_FIRST24='OWNED_EXTERNAL_GUARD',PYTHONDONTWRITEBYTECODE='1')
    if time.monotonic()-started>=min(limits['wall_seconds'],limits['load_seconds']):
        raise OriginalExecutionHold('Initial CLI checks exhausted the deadline; child not started')
    try:
        with log.open('x') as stream,sample_path.open('x') as samples:
            process=subprocess.Popen(['bash',str(RUNTIME_DIRECTORY/'cpu_python.sh'),
                str(c.HERE/'run_original_stage1_reconstructed.py'),'--execute',
                '--asset-dir',str(admission.asset_directory),'--out',str(out)],
                cwd=c.REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            owner=OwnedProcessGroup(process.pid)
            while True:
                elapsed=time.monotonic()-started
                try:
                    observation=sample_or_reap(process.pid)
                    if observation['terminal'] is not None:
                        code,usage=observation['terminal'];process.returncode=code
                        terminal_race=observation['terminal_proc_race_resolved'];break
                    child=observation['metrics'];own=status(os.getpid())
                    unexpected=descendants(process.pid);extra_children.update(unexpected)
                    # No descendants are allowed, but charge observed ones until
                    # the owned group is stopped, instead of silently omitting them.
                    extra=sum(max(status(pid).values()) for pid in unexpected)
                    peak=max(child.values())+own['VmHWM']+extra
                    resources=resource_snapshot(started,out,log,sample_path)
                    host_peak=max(host_peak,resources['host_unavailable_bytes'])
                    for violation in resource_violations(resources,limits,bounds):reason=reason or violation
                    row=dict(resources=resources,elapsed_seconds=elapsed,child=child,guard_HWM_bytes=own['VmHWM'],
                        descendant_pids=unexpected,combined_HWM_bytes=peak)
                    samples.write(json.dumps(row)+'\n');samples.flush();os.fsync(samples.fileno());sample_count+=1
                    if unexpected:reason=reason or 'unexpected_descendant_outside_single_process_envelope'
                    if peak>=limits['combined_rss_hwm_bytes']:reason=reason or 'combined_RSS_HWM_limit'
                except (ProcessMetricsUnavailable,FileNotFoundError,ProcessLookupError) as exc:
                    reason=reason or 'missing_metrics_without_terminal_wait4'
                    if len(failures)<8:failures.append(dict(type=type(exc).__name__,message=str(exc)))
                if reason and sent is None:
                    owner.send(signal.SIGTERM);sent=time.monotonic()
                elif sent is not None and time.monotonic()-sent>=2:owner.send(signal.SIGKILL)
                time.sleep(limits['sample_interval_seconds'])
    except BaseException as exc:
        reason=reason or 'guard_exception'
        failures.append(dict(type=type(exc).__name__,message=str(exc)))
    finally:
        # No path leaves an unowned running original model. Never call poll/wait
        # before wait4, which would consume the terminal resource receipt.
        if process is not None and usage is None:
            if owner is not None:owner.send(signal.SIGKILL)
            else:
                # This child has not been reaped, so its PID still belongs to
                # this Popen. Open its stable fd and stop the child itself;
                # inability to establish group ownership already prevents PASS.
                fd=os.pidfd_open(process.pid)
                try:signal.pidfd_send_signal(fd,signal.SIGKILL)
                finally:os.close(fd)
            ended,state,usage=os.wait4(process.pid,0)
            if ended!=process.pid:raise RuntimeError('Wrong owned child reaped')
            code=os.waitstatus_to_exitcode(state);process.returncode=code
        if owner is not None:
            try:
                cleanup=terminal_group_cleanup(owner)
                if cleanup['group_survived_leader']:reason=reason or 'owned_group_survived_leader'
                if cleanup['group_still_present']:reason=reason or 'owned_group_cleanup_incomplete'
            except BaseException as exc:
                reason=reason or 'owned_group_cleanup_failure'
                failures.append(dict(type=type(exc).__name__,message=str(exc)))
            finally:owner.close()
        after=source_pins()
        if pins!=after:reason=reason or 'source_changed_during_run'
        guard_peak=status(os.getpid())['VmHWM']
        child_peak=None if usage is None else usage.ru_maxrss*1024
        combined=None if child_peak is None else child_peak+guard_peak
        if combined is not None and combined>=limits['combined_rss_hwm_bytes']:
            reason=reason or 'terminal_combined_HWM_limit'
        if process is None:reason=reason or 'child_not_started'
        log_digest=c.sha(log) if log.exists() else None
        sample_digest=c.sha(sample_path) if sample_path.exists() else None
        try:
            terminal_resources=resource_snapshot(started,out,log,sample_path,receipt_reserve=RECEIPT_RESERVE_BYTES)
            host_peak=max(host_peak,terminal_resources['host_unavailable_bytes'])
            for violation in resource_violations(terminal_resources,limits,bounds):reason=reason or violation
        except BaseException as exc:
            reason=reason or 'terminal_resource_check_failure'
            failures.append(dict(type=type(exc).__name__,message=str(exc)))
        report=dict(status='PASS_ORIGINAL_FIRST24_PROCESS_GUARD' if code==0 and reason is None else 'FAIL_ORIGINAL_FIRST24_PROCESS_GUARD',
            exit_code=code,resource_stop=reason,elapsed_seconds=time.monotonic()-started,
            terminal_wait4_receipt_present=usage is not None,terminal_proc_race_resolved_by_owned_wait4=terminal_race,
            child_peak_RSS_bytes=child_peak,guard_peak_RSS_bytes=guard_peak,combined_terminal_HWM_bytes=combined,
            CPU_user_seconds=None if usage is None else usage.ru_utime,CPU_system_seconds=None if usage is None else usage.ru_stime,
            sample_count=sample_count,sampling_failures=failures,unexpected_descendant_pids=sorted(extra_children),
            host_unavailable_peak_sampled_bytes=host_peak,terminal_resources=terminal_resources,
            owned_group_identity=None if owner is None else owner.identity,owned_group_cleanup=cleanup,
            group_signal_authority='retained_pidfd_PIDFD_SIGNAL_PROCESS_GROUP_no_numeric_fallback',
            limits=limits,prospective_envelope=bounds,retained_before_bytes=before_retained,
            source_pins_before=pins,source_pins_after=after,original_admission_source_sha256=admission.source_sha256,
            log_sha256=log_digest,sample_journal_sha256=sample_digest,
            native_result_is_separate=True,no_automatic_retry=True)
        encoded=json.dumps(report,indent=2,allow_nan=False)+'\n'
        if len(encoded.encode())>RECEIPT_RESERVE_BYTES:raise RuntimeError('Guard receipt exceeds its reserved bound; no PASS receipt written')
        with receipt.open('x') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
    return report


def main(argv=None):
    started=time.monotonic()  # Includes initial CLI hashing/preflight in the one total envelope.
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--asset-dir',type=Path,default=ASSET_DIRECTORY)
    parser.add_argument('--out',type=Path,default=c.HERE/'original_stage1_attempt_01')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args(argv)
    admission=preflight(args.asset_dir,retained_before_bytes=retained_bytes(c.HERE))
    if not args.execute:
        print(json.dumps(admission.as_dict(),indent=2,allow_nan=False));return 2
    try:report=guard_once(admission,args.out,started=started)
    except OriginalExecutionHold as exc:
        print(json.dumps(dict(status='HOLD_ORIGINAL_FIRST24',reason=str(exc),child_started=False,native_model_actions=0),indent=2));return 2
    print(json.dumps(report,indent=2,allow_nan=False))
    return 0 if report['status']=='PASS_ORIGINAL_FIRST24_PROCESS_GUARD' else 1

if __name__=='__main__':raise SystemExit(main())
