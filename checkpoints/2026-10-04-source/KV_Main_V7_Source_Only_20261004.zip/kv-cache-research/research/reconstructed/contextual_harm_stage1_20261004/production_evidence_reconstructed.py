"""NEW first24 production evidence route. No import-time Torch/model activity.

Every raw artifact is created exclusively, streamed, fsynced and acknowledged
before its descriptor is published. An incomplete artifact poisons the store;
failed prefixes remain on disk. No cache reconstruction or automatic retries.
"""
from pathlib import Path
import hashlib,json,os,re,sys,time
import contract_reconstructed as c
from evidence_sink_reconstructed import BoundedJSONLJournal,TerminalEvidenceStore,check_metadata_budget,JournalPoisoned
from tiny_cost_summary_reconstructed import TinyCostSummary

class ProductionEvidenceStore:
    def __init__(self,output_dir,torch,evidence_module,*,artifact_cap_bytes,journal_cap_bytes=64*1024**2):
        self.path=Path(output_dir);self.path.mkdir(exist_ok=False)
        self.torch,self.evidence=torch,evidence_module
        self.cap=int(artifact_cap_bytes);self.raw_bytes=0;self.artifacts=0;self.poisoned=False
        self.journal=BoundedJSONLJournal(self.path/'evidence.jsonl',total_limit=journal_cap_bytes)
        self.terminal=TerminalEvidenceStore(self.journal)
        self.costs=TinyCostSummary(self.journal)
        self.pre_q={};self.raw_logit_calls=set();self.raw_logit_receipts={};self.mapped_reference_caches=0;self.source_saved=set();self.suffix_saved=set()
        self._cell_invoked=self._cell_returned=False
        self.serialization_wall_seconds=0.;self.serialization_cpu_seconds=0.
    def begin_cell(self,cell):
        self._cell_invoked=self._cell_returned=False
        self.terminal.begin_cell(cell['cell_id'],{'canonical_cell_sha256':c.digest(cell),'identity':{k:cell[k] for k in ('cell_id','pair_id','variant','arm')}})
    def emit(self,row):
        if self.poisoned:raise JournalPoisoned('Production artifact store is poisoned')
        if row.get('kind')=='root_call':
            cid=row['call_id'].split('.')[0]
            if cid!=self.terminal.active_cell_id:raise ValueError('Root call belongs to wrong active cell')
            if row['model_invoked'] and not self._cell_invoked:
                self.terminal.mark_model_invoked(cid);self._cell_invoked=True
            if row['model_returned'] and not self._cell_returned:
                self.terminal.mark_model_returned(cid);self._cell_returned=True
        try:
            self.costs.emit(row)
            if len(self.costs.operations)>1024 or len(self.costs.leases)>1024 or len(self.costs.active)>1:
                raise RuntimeError('Production aggregate key/exclusive-arena bound')
        except BaseException:self.poisoned=True;raise
    def _artifact(self,name,tensor):
        if self.poisoned or self.journal.poisoned:raise JournalPoisoned('Production artifact store is poisoned')
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,180}',name):raise ValueError('Unsafe artifact name')
        if tensor.device.type!='cpu' or tensor.dtype!=self.torch.float32 or not bool(self.torch.isfinite(tensor).all()):raise ValueError('Raw artifact must be finite CPU FP32')
        # A contiguous copy, if needed, is live only for this one tensor and is
        # included in admission's serialization scratch rather than hidden.
        count=tensor.numel()*4
        if self.raw_bytes+count>self.cap:raise RuntimeError('Raw artifact cap before create')
        start=time.monotonic();cpu=time.process_time();path=self.path/(name+'.f32');digest=hashlib.sha256()
        try:
            raw=memoryview(tensor.detach().contiguous().view(self.torch.uint8).numpy()).cast('B')
            with path.open('xb') as f:
                for offset in range(0,len(raw),65536):
                    part=raw[offset:offset+65536];f.write(part);digest.update(part)
                f.flush();os.fsync(f.fileno())
            directory=os.open(self.path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
            try:os.fsync(directory)
            finally:os.close(directory)
            if path.stat().st_size!=count:raise ValueError('Raw artifact extent mismatch')
            record={'path':path.name,'bytes':count,'sha256':digest.hexdigest(),'shape':list(tensor.shape),'dtype':'float32','byte_order':sys.byteorder}
            self.journal.append({'kind':'raw_artifact','name':name,'record':record})
            self.raw_bytes+=count;self.artifacts+=1
            return record
        except BaseException:self.poisoned=True;raise
        finally:
            self.serialization_wall_seconds+=time.monotonic()-start;self.serialization_cpu_seconds+=time.process_time()-cpu
    def raw_logits(self,call_id,tensor):
        if call_id in self.raw_logit_calls:raise ValueError('Duplicate root-logit receipt')
        if tensor.numel()!=c.VOCAB:raise ValueError('Expected one complete vocabulary vector')
        receipt=self._artifact(call_id+'.logits',tensor)
        self.raw_logit_calls.add(call_id);self.raw_logit_receipts[call_id]=receipt
        if len(self.raw_logit_calls)>308:raise ValueError('Root-logit count exceeds fixed stage')
        return receipt
    def _cache(self,name,cache):
        descriptor,tensors=self.evidence.cache_snapshot(cache,self.torch)
        fields={path:self._artifact(name+'.'+str(i),t) for i,(path,t) in enumerate(tensors.items())}
        row={'kind':'complete_cache_artifact','name':name,'descriptor':descriptor,'fields':fields}
        self.journal.append(row)
        return row
    def save_cache(self,cell_id,owner):
        if cell_id in self.pre_q:raise ValueError('Duplicate preQ artifact')
        row=self._cache(cell_id+'.preQ',owner.cache)
        self.pre_q[cell_id]={'descriptor_sha256':c.digest(row['descriptor']),'name':row['name'],'fields':row['fields']}
        check_metadata_budget(self.pre_q)
        return self.pre_q[cell_id]
    def _tensor_tree(self,name,tree):
        receipts={}
        for key,value in tree.items():
            child=name+'.'+str(key)
            if isinstance(value,self.torch.Tensor):receipts[child]=self._artifact(child,value)
            elif isinstance(value,dict):receipts.update(self._tensor_tree(child,value))
        return receipts
    def save_source(self,pair_id,source):
        if pair_id in self.source_saved:raise ValueError('Source already persisted')
        cell_id=source.provenance['cell_id'];ref=self.pre_q[cell_id]
        actual=self.evidence.cache_snapshot(source.cache,self.torch)[0]
        if c.digest(actual)!=ref['descriptor_sha256']:raise ValueError('Source preQ bytes differ from persisted source cell')
        incoming=self._cache(pair_id+'.source.incomingA',source.incoming_cache)
        layers=self._tensor_tree(pair_id+'.source.layers',source.layers)
        traces=self._tensor_tree(pair_id+'.source.traces',source.traces)
        self.journal.append({'kind':'contextual_source','pair_id':pair_id,'preQ_artifact':ref,'manifest':source.manifest,'provenance':source.provenance})
        from file_backed_evidence_reconstructed import MappedEvidence
        backing=MappedEvidence(self.path,self.torch)
        source.cache=backing.cache(source.cache,ref['fields'])
        source.incoming_cache=backing.cache(source.incoming_cache,incoming['fields'])
        source.layers=backing.tree(source.layers,layers,pair_id+'.source.layers')
        source.traces=backing.tree(source.traces,traces,pair_id+'.source.traces')
        source._evidence_backings=[backing];backing.evict()
        self.journal.append({'kind':'file_backed_source','pair_id':pair_id,**backing.summary()})
        self.source_saved.add(pair_id)
    def save_suffix(self,pair_id,source):
        if pair_id in self.suffix_saved:return
        if source.suffix is None:raise ValueError('Suffix not extracted')
        receipts=self._tensor_tree(pair_id+'.suffix',source.suffix.layers)
        self.journal.append({'kind':'source_suffix','pair_id':pair_id,'manifest':source.suffix.manifest})
        from file_backed_evidence_reconstructed import MappedEvidence
        backing=MappedEvidence(self.path,self.torch)
        source.suffix.layers=backing.tree(source.suffix.layers,receipts,pair_id+'.suffix')
        source._evidence_backings.append(backing)
        self.journal.append({'kind':'file_backed_suffix','pair_id':pair_id,**backing.summary()})
        self.suffix_saved.add(pair_id)
    def map_reference_bank(self,cell,bank):
        from file_backed_evidence_reconstructed import MappedEvidence
        from native_backend_reconstructed import NativeOwner
        backing=MappedEvidence(self.path,self.torch);mapped={}
        for label,(owner,logits) in bank.items():
            if label=='pre_Q':fields=self.pre_q[cell['cell_id']]['fields']
            else:
                row=self._cache(cell['cell_id']+'.reference.'+label,owner.cache);fields=row['fields'];self.mapped_reference_caches+=1
            cache=backing.cache(owner.cache,fields)
            call_label='Q' if label=='post_Q' else label
            mapped_logits=None if logits is None else backing.tensor(self.raw_logit_receipts[next(r['call_id'] for r in cell['calls'] if r['label']==call_label)])
            clone=NativeOwner(cache,owner.history,logits=mapped_logits)
            mapped[label]=(clone,mapped_logits)
        self.journal.append({'kind':'file_backed_reference_bank','cell_id':cell['cell_id'],**backing.summary()})
        backing.evict()
        return mapped,backing
    def summary(self):
        return {'raw_bytes':self.raw_bytes,'raw_artifacts':self.artifacts,'raw_logit_vectors':len(self.raw_logit_calls),
                'preQ_artifacts':len(self.pre_q),'additional_F32_A1_reference_cache_artifacts':self.mapped_reference_caches,'sources':len(self.source_saved),'suffixes':len(self.suffix_saved),
                'journal_written_bytes':self.journal.actual_written_bytes,'journal_durable_bytes':self.journal.durable_ack_bytes,
                'poisoned':self.poisoned or self.journal.poisoned,'serialization_wall_seconds':self.serialization_wall_seconds,
                'serialization_cpu_seconds':self.serialization_cpu_seconds,'costs':self.costs.summary(),
                'evidence_scope':'All root logits raw;24 preQ caches and2 incoming source caches raw;source factors/halos/block traces/suffix raw;F32/A1 reference endpoints additionally raw/file-backed for later exact controls;other transient candidate/greedy caches live metadata/hashes/numerical checks only'}
    def close(self):
        try:
            if not self.poisoned and not self.journal.poisoned:self.journal.append({'kind':'production_evidence_final','summary':self.summary()})
        finally:self.journal.close()

# Inclusive preparation/I/O timing. Nested values overlap and are never summed
# as serving latency; failed attempts remain covered by outer process timing.
def _charge_method(function):
    from functools import wraps
    @wraps(function)
    def wrapped(self,*args,**kwargs):
        start=time.monotonic();cpu=time.process_time();success=False
        try:
            result=function(self,*args,**kwargs);success=True;return result
        finally:
            primary=sys.exc_info()[1]
            try:self.emit({'kind':'evidence_operator_cost','operator':function.__name__,'successful':success,
                'wall_seconds':time.monotonic()-start,'CPU_seconds':time.process_time()-cpu,'inclusive_overlapping':True})
            except BaseException:
                if primary is None:raise
    return wrapped
for _name in ('raw_logits','save_cache','save_source','save_suffix','map_reference_bank'):
    setattr(ProductionEvidenceStore,_name,_charge_method(getattr(ProductionEvidenceStore,_name)))
