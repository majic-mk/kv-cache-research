"""NEW reconstructed stdlib tests. Spies are not native/model measurements."""
import copy,unittest
from types import SimpleNamespace as O
import contract_reconstructed as c
from scoring_reconstructed import ScoringFailure,score_post_q_with_backend as score,normalized_correct
from results_reconstructed import StageState
class Spy:
    def __init__(self,cell,greedy=None):
        self.cell=cell;self.calls=[];self.clones=[];self.greedy=greedy or list(cell['candidates'][cell['expected_answer']]);self.q=O(cache=[1,2],logits='Q')
    def cache(self,o):return o.cache
    def logits(self,o):return o.logits
    def signature(self,x):return repr(x)
    def clone_owned(self,s,p):
        r=list(s);self.clones.append(r);return r
    def assert_clone(self,s,r):return s==r and s is not r
    def logprob_fp32(self,l,t):return -.1  # Scripted; does not claim FP32 execution.
    def sum_fp32(self,v):return sum(v)
    def margin_fp32(self,g,o):return g-o
    def argmax_with_gap(self,l):return self.greedy[int(l.split('_')[-1]) if l.startswith('greedy_') else 0],1e-7
    def forward(self,ids,cache,label,start):
        self.calls.append((ids,label,start,id(cache)));cache.extend(ids);return O(cache=cache,logits=label)
    def decode(self,ids):return self.cell['expected_answer']
def record(p,loss=0.,wrong=False):
    gold=p['expected_answer'];other=next(a for a in p['candidates'] if a!=gold);scores={a:(-.2-loss if a==gold else -2.2) for a in p['candidates']};ids=p['candidates'][other if wrong else gold]
    return dict(**{k:p[k] for k in ('cell_id','pair_id','variant','arm')},status='completed',candidate_scores=scores,
      candidate_per_token_logprobs={a:[s/len(p['candidates'][a])]*len(p['candidates'][a]) for a,s in scores.items()},gold_logprob=scores[gold],gold_margin=scores[gold]-scores[other],
      raw_greedy_ids=ids,eos_within_cap=True,decoded_answer=other if wrong else gold,normalized_answer_correct=not wrong,strict_gold_token_equality=not wrong,native_checks_passed=True,evidence_kind='SCRIPTED_RECORD_ONLY')
class ContractTests(unittest.TestCase):
    def test_recovered_freezes_and_contexts(self):self.assertEqual(c.verify_recovered_freezes(),48);self.assertEqual(len(c.recovered_contexts()),64)
    def test_ceiling(self):
        b=c.work_bounds();self.assertEqual(tuple(b[k] for k in ('scored_cells','root_model_calls_max','network_tokens_max','mandatory_calls','greedy_continuation_calls_max','scored_vocab_vectors_max')),(24,308,4840,140,168,252))
    def test_order_source_and_EOS(self):
        plans=c.plan();self.assertEqual([(p['pair_id'],p['variant'],p['arm']) for p in plans[:16]],[(g,v,a) for g in c.GROUPS for v in c.VARIANTS for a in ('R','F32')]);self.assertEqual([p['cell_id'] for p in plans if p['source_capture_during_B']],['ch01','ch09'])
        for p in plans:
            for x in p['calls']:
                if x['label'].startswith('candidate_'):self.assertNotIn(c.EOS,x['input_ids'])
    def test_scripted_counts_173_4705(self):
        calls=tokens=0
        for p in c.plan():
            rows=[x for x in p['calls'] if not x['conditional_on_no_previous_EOS']];n=len(p['candidates'][p['expected_answer']])-1;calls+=len(rows)+n;tokens+=sum(x['network_tokens'] for x in rows)+n
        self.assertEqual((calls,tokens),(173,4705))
    def test_limits_pinned_and_execution_refused(self):
        self.assertEqual(c.numerical_limits(),c.read(c.V3/'numerical_contract.json')['bf16_exact_schedule_controls'])
        with self.assertRaisesRegex(RuntimeError,'HOLD_RECONSTRUCTED'):c.refuse_execution()
class ScoringTests(unittest.TestCase):
    def ref(self):
        p=c.plan()[0];b=Spy(p);return p,score(p,b.q,b)
    def test_unequal_candidates_and_clones(self):
        p=c.plan()[8];b=Spy(p);r=score(p,b.q,b);self.assertEqual(list(r['candidate_scores']),['copper','silver']);self.assertEqual([len(v) for v in r['candidate_per_token_logprobs'].values()],[3,2]);self.assertEqual(len({id(v) for v in b.clones}),3);self.assertEqual(b.q.cache,[1,2]);self.assertTrue(all(c.EOS not in x[0] for x in b.calls))
    def test_near_tie_wrongID_no_dependent_forward(self):
        p,ref=self.ref();b=Spy(p,[17,c.EOS])
        with self.assertRaises(ScoringFailure) as e:score(p,b.q,b,exact_reference=ref)
        self.assertEqual(e.exception.category,'numerical');self.assertFalse(any(x[1].startswith('greedy_') for x in b.calls));self.assertEqual(e.exception.partial['statuses']['decode'],'not_run_gate')
    def test_earlyEOS_stops(self):
        p,ref=self.ref();b=Spy(p,[c.EOS])
        with self.assertRaises(ScoringFailure):score(p,b.q,b,exact_reference=ref)
        self.assertEqual(len(b.calls),2)
    def test_first_candidate_stops_before_second(self):
        p,ref=self.ref();ref['candidate_scores']['red']-=.02;b=Spy(p)
        with self.assertRaises(ScoringFailure) as e:score(p,b.q,b,exact_reference=ref)
        self.assertEqual([x[1] for x in b.calls],['candidate_red_1']);self.assertEqual(e.exception.partial['statuses']['candidate:blue'],'not_run_gate')
    def test_margin_stops_before_greedy(self):
        p,ref=self.ref();ref['gold_margin']+=.02;b=Spy(p)
        with self.assertRaises(ScoringFailure):score(p,b.q,b,exact_reference=ref)
        self.assertEqual(len(b.calls),2)
    def test_bad_reference_zero_calls(self):
        p=c.plan()[0];b=Spy(p)
        with self.assertRaises(ScoringFailure):score(p,b.q,b,exact_reference={})
        self.assertEqual(b.calls,[])
    def test_noEOS_eight_token_cap(self):
        p=c.plan()[0];b=Spy(p,[1114]*8);r=score(p,b.q,b);self.assertEqual(len(r['raw_greedy_ids']),8);self.assertEqual(len(b.calls),9);self.assertFalse(r['normalized_answer_correct'])
    def test_parser(self):self.assertTrue(normalized_correct(' RED! ','red',True));self.assertFalse(normalized_correct('answer red','red',True));self.assertFalse(normalized_correct('red','red',False))
class StateTests(unittest.TestCase):
    def test_firstwrong_stops_later(self):
        s=StageState();self.assertEqual(s.accept(record(s.plan[0],wrong=True)),'STOP_COMPETENCE');self.assertTrue(all(r['status']=='not_run_gate' for r in s.records[1:]))
    def test_malformed_second_does_not_rewrite_first(self):
        s=StageState();s.accept(record(s.plan[0]));old=copy.deepcopy(s.records[0]);r=record(s.plan[1]);r['cell_id']='ch03';self.assertEqual(s.accept(r),'STOP_INTEGRITY');self.assertEqual(s.next_index,1);self.assertEqual(s.records[0],old);self.assertEqual(s.first_failure['cell_id'],'ch02')
    def test_scalar_difference_stops(self):
        s=StageState();s.accept(record(s.plan[0]));self.assertEqual(s.accept(record(s.plan[1],loss=.02)),'STOP_NUMERICAL')
    def test_partial_and_single_group_not_success(self):
        s=StageState()
        with self.assertRaises(ValueError):s.assess_harm()
        for p in s.plan:s.accept(record(p,.2 if p['arm']=='Hctx32' and p['variant']=='A2' and p['pair_id']=='d01' else 0.))
        self.assertEqual(s.status,'STOP_NO_QUALIFYING_HARM')
    def test_two_group_harm_no_method_or_accuracy_claim(self):
        s=StageState()
        for p in s.plan:s.accept(record(p,.2 if p['arm']=='Hctx32' and p['variant']=='A2' else 0.))
        r=s.assess_harm();self.assertEqual(r['status'],'PASS_STAGE1_COMPETENCE_AND_CONTEXTUAL_HARM_ONLY');self.assertFalse(r['method_benefit_established']);self.assertFalse(r['continuation_authorized']);self.assertTrue(all(not x['observed_answer_harm'] for x in r['groups']))
    def test_firstfailure_preserved(self):
        s=StageState();s.accept(record(s.plan[0],wrong=True));first=copy.deepcopy(s.first_failure);s.stop('integrity','ch02','late');self.assertEqual(s.first_failure,first)
    def test_strict_tokens_not_new_competence_filter(self):
        s=StageState();r=record(s.plan[0]);r['raw_greedy_ids']=[1114,8,c.EOS];r['strict_gold_token_equality']=False;self.assertEqual(s.accept(r),'RUNNING')
if __name__=='__main__':unittest.main(verbosity=2)
