"""NEW source-locked first24 original entry. Default is model-free preflight only.

No CLI/environment value releases execution. Future reviewed release must admit
both the checkpoint and original resource envelope; this file is not that grant.
"""
from __future__ import annotations
import argparse
from dataclasses import replace
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback
import contract_reconstructed as c
from original_admission_reconstructed import (ASSET_DIRECTORY, OriginalExecutionHold,
    RUNTIME_DIRECTORY, preflight, verify_small_assets, verify_checkpoint_layout,OriginalAdmission)


def _verified_offline_tokenizer(directory):
    """Before model construction, reproduce all64 frozen whole-prompt tokens."""
    verify_small_assets(directory)
    spec = importlib.util.spec_from_file_location('_original_frozen_validator',c.V3/'validate_protocol.py')
    validation = importlib.util.module_from_spec(spec);spec.loader.exec_module(validation)
    result = validation.validate_tokens(validation.load_fixtures(),c.read(c.V3/'template.json'),
        directory,c.V3/'tokenizer_provenance.json')
    if result['contexts'] != c.read(c.V3/'token_validation.json')['token_checks']['contexts']:
        raise ValueError('Offline all64 tokenizer/template/slice/candidate identity changed')
    from tokenizers import Tokenizer
    tokenizer = Tokenizer.from_file(str(directory/'tokenizer.json'))
    if tokenizer.token_to_id('<|im_end|>') != c.EOS:
        raise ValueError('Frozen EOS token differs')
    class VerifiedTokenizer:
        def decode(self,ids,*,skip_special_tokens=True,clean_up_tokenization_spaces=False):
            if clean_up_tokenization_spaces is not False:
                raise ValueError('Frozen decoder does not clean up tokenization spaces')
            return tokenizer.decode(list(ids),skip_special_tokens=skip_special_tokens)
    return VerifiedTokenizer()


def _source_mapped_extent(pointer,nbytes,record_offset,source_stat,maps_text):
    """Linux proof that a CPU tensor aliases this file's exact payload extent."""
    expected_dev=(os.major(source_stat.st_dev),os.minor(source_stat.st_dev))
    for line in maps_text.splitlines():
        fields=line.split(None,5)
        if len(fields)<5:continue
        lo,hi=(int(x,16) for x in fields[0].split('-'))
        if not lo<=pointer or pointer+nbytes>hi:continue
        dev=tuple(int(x,16) for x in fields[3].split(':'))
        file_offset=int(fields[2],16)+pointer-lo
        return dev==expected_dev and int(fields[4])==source_stat.st_ino and file_offset==record_offset
    return False


def _load_exact_source_once(admission,torch,config_class,model_class,source_storage):
    """Prepared zero-duplicate payload route, still behind original source lock.

    Uses the official model constructor on meta and the already verified local
    safetensors payload, assigning source storage without allocating a second
    resident weight payload. Runtime VMA/pointer assertions reject a parser or
    loader copy. This route has NOT been executed against original weights.
    """
    if type(admission) is not OriginalAdmission:raise OriginalExecutionHold('Exact locked OriginalAdmission required')
    admission.assert_execution_allowed()
    from safetensors import safe_open
    from original_admission_reconstructed import _load_contracts
    path=admission.asset_directory/'model.safetensors'
    records=_load_contracts().read_source_manifest(path,require_2b=True)
    cfg=config_class(**c.read(admission.asset_directory/'config.json')['text_config'])
    cfg._attn_implementation='eager'
    with torch.device('meta'):
        model=model_class(cfg)
    if any(p.device.type!='meta' for p in model.parameters()):
        raise ValueError('Original constructor allocated a resident weight payload')
    expected=dict(model.named_parameters())
    if set(expected)!={r.model_name for r in records}:
        raise ValueError('Meta original/source key coverage differs')
    if model.lm_head.weight is not model.model.embed_tokens.weight:
        raise ValueError('Official meta tied head identity differs')
    if set(model.state_dict())!=set(expected)|{'lm_head.weight'}:
        raise ValueError('Unexpected persistent buffers/state-dict keys')
    state={};pointers={};source_stat=path.stat()
    with safe_open(str(path),framework='pt',device='cpu') as source:
        if set(source.keys())!={r.source_name for r in records}:
            raise ValueError('Original safetensors key coverage differs')
        for record in records:
            tensor=source.get_tensor(record.source_name)
            if (tuple(tensor.shape)!=record.shape or str(tensor.dtype)!= {'BF16':'torch.bfloat16','F32':'torch.float32'}[record.dtype]
                    or tensor.device.type!='cpu' or not tensor.is_contiguous()):
                raise ValueError('Source tensor shape/dtype/device differs')
            if not _source_mapped_extent(tensor.data_ptr(),record.nbytes,record.offset,source_stat,Path('/proc/self/maps').read_text()):
                raise ValueError('Safetensors did not expose exact source file-backed storage; copied payload is not admitted')
            state[record.model_name]=tensor;pointers[record.model_name]=tensor.data_ptr()
        state['lm_head.weight']=state['model.embed_tokens.weight']
        info=model.load_state_dict(state,strict=True,assign=True)
        if info.missing_keys or info.unexpected_keys:raise ValueError('Unclean exact source assignment')
        model.tie_weights()
        for name,param in model.named_parameters():
            if param.data_ptr()!=pointers[name]:raise ValueError('Parameter assign/tie copied original storage')
    state.clear();del tensor,expected
    model.eval();model.requires_grad_(False)
    # Restores only 10,368 source F32 bytes plus official CPU RoPE buffers; all
    # 320 source parameters are independently byte-checked by this existing helper.
    audit=source_storage.restore_original_small_fp32(model,path,torch)
    if any(b.device.type!='cpu' for b in model.buffers()):
        raise ValueError('Residual meta/non-CPU model buffer after official RoPE restore')
    if model.lm_head.weight is not model.model.embed_tokens.weight:
        raise ValueError('Original tied head identity lost')
    if audit['source_exact'] is not True or audit['tensor_count']!=320:
        raise ValueError('Original mixed storage byte audit failed')
    info=dict(missing_keys=[],unexpected_keys=[],mismatched_keys=[],error_msgs=[],
        route='official_meta_constructor_then_local_safetensors_assign_true',
        source_backing_verified_before_assign=True,assigned_parameter_pointers_unchanged=True,
        source_payload_copies=1,small_original_F32_restore_bytes=10_368,
        original_loader_execution_verified=True)
    return model,info,audit


def _prepare_native(admission, store_factory, phase):
    """Prepared official loader route. This function is locked before imports."""
    if type(admission) is not OriginalAdmission:raise OriginalExecutionHold('Exact locked OriginalAdmission required')
    admission.assert_execution_allowed()
    if os.environ.get('RECONSTRUCTED_ORIGINAL_FIRST24') != 'OWNED_EXTERNAL_GUARD':
        raise OriginalExecutionHold('Owned external guard entry required')
    for name,value in {'CUDA_VISIBLE_DEVICES':'','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1',
                       'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}.items():
        if os.environ.get(name) != value: raise ValueError('Required CPU/offline environment differs: '+name)
    if Path(sys.prefix).resolve() != (RUNTIME_DIRECTORY/'.venv').resolve():
        raise ValueError('Use the existing restored CPU interpreter')
    phase('validating_assets_before_model_load')
    verify_checkpoint_layout(admission.asset_directory)
    tokenizer = _verified_offline_tokenizer(admission.asset_directory)
    admission = replace(admission,tokenizer_verified=True)
    import torch
    from transformers import Qwen3_5TextConfig,Qwen3_5ForCausalLM
    from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
    from native_backend_reconstructed import engine_support
    evidence,support = engine_support()
    from_original = importlib.import_module(support.__package__+'.source_storage')
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    if torch.__version__ != '2.9.1+cpu' or torch.version.cuda is not None:
        raise ValueError('Original CPU Torch identity differs')
    if c.sha(hf.__file__) != importlib.import_module(support.__package__+'.contracts').MODELING_SHA256:
        raise ValueError('Original official model source identity differs')
    phase('loading_original')
    model,info,audit = _load_exact_source_once(admission,torch,Qwen3_5TextConfig,Qwen3_5ForCausalLM,from_original)
    store = store_factory(torch,evidence)
    store.emit(dict(kind='original_loader_identity',loading_info=info,source_audit=audit,
        torch_version=str(torch.__version__),torch_cuda_build=torch.version.cuda,
        actual_parameter_dtypes=sorted({str(p.dtype) for p in model.parameters()}),
        torch_threads=torch.get_num_threads(),torch_interop_threads=torch.get_num_interop_threads()))
    engine = support.PagedArenaEngine(model,hf,torch,source_path=admission.asset_directory/'model.safetensors',
        synthetic=False,history_limit=16,lease_sink=lambda row:store.emit(dict(kind='arena',**row)))
    phase('native_ready')
    return model,engine,torch,hf,tokenizer,store,admission


def run_original(admission, output_dir):
    """One route owns native load, engine cleanup, terminal persistence and close."""
    if type(admission) is not OriginalAdmission:raise OriginalExecutionHold('Exact locked OriginalAdmission required')
    admission.assert_execution_allowed()  # Must precede output creation/imports.
    output_dir = Path(output_dir);output_dir.mkdir(exist_ok=False)
    phase_path = output_dir/'phase.json'
    def phase(name):
        data=json.dumps(dict(phase=name,monotonic=time.monotonic()))+'\n'
        with phase_path.open('w') as f:f.write(data);f.flush();os.fsync(f.fileno())
    # Imports do not construct a native model. None are reached in current HOLD.
    from production_evidence_reconstructed import ProductionEvidenceStore
    from first24_coordinator_reconstructed import run_first24
    def store_factory(torch,evidence):
        nonlocal store
        store = ProductionEvidenceStore(output_dir/'evidence',torch,evidence,
            artifact_cap_bytes=admission.bounds['raw_artifact_bytes_max'],
            journal_cap_bytes=admission.bounds['journal_cap_bytes'])
        return store
    store=engine=None; result=None;primary=None;secondary=[]
    try:
        model,engine,torch,hf,tokenizer,store,admission = _prepare_native(admission,store_factory,phase)
        phase('executing_first24')
        with engine:
            try:result = run_first24(model,engine,torch,hf,tokenizer,store,admission)
            except BaseException as exc:
                # Remember the actual experiment error before __exit__/remove
                # can raise an independent integrity or teardown error.
                primary=exc
                raise
        phase('engine_restored')
        store.emit(dict(kind='original_engine_teardown',report=engine.report(),
            installed=engine._installed,executing=engine._executing,arena_live=engine.arena is not None))
        if engine._installed or engine._executing or engine.arena is not None:
            raise RuntimeError('Original engine did not fully tear down')
        return result
    except BaseException as exc:
        if primary is None:primary=exc
        elif exc is not primary:secondary.append(dict(type=type(exc).__name__,message=str(exc)))
        raise primary
    finally:
        # PagedArenaEngine.__exit__ restores patches even for control/STOP errors.
        # Explicit remove covers failures between factory return and with entry.
        if engine is not None and engine._installed:
            try:engine.remove()
            except BaseException as exc:secondary.append(dict(type=type(exc).__name__,message=str(exc)))
        if store is not None:
            try:store.close()
            except BaseException as exc:secondary.append(dict(type=type(exc).__name__,message=str(exc)))
        if primary is not None or secondary:
            failure=dict(status='FAIL_ORIGINAL_FIRST24',first_failure=None if primary is None else
                dict(type=type(primary).__name__,message=str(primary)),secondary_failures=secondary)
            with (output_dir/'loader_failure.json').open('x') as f:
                json.dump(failure,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
        if secondary and primary is None:raise RuntimeError('Original teardown/evidence close failed')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--asset-dir',type=Path,default=ASSET_DIRECTORY)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--execute',action='store_true',help='Requests locked route; never releases current source')
    parser.add_argument('--validate-tokens',action='store_true',help='Offline tokenizer/template all64 validation only; no model imports')
    args=parser.parse_args(argv)
    retained=sum(p.stat().st_size for p in c.HERE.rglob('*') if p.is_file())
    admission=preflight(args.asset_dir,retained_before_bytes=retained)
    if args.validate_tokens:
        if args.execute:parser.error('--validate-tokens cannot be combined with --execute')
        if Path(sys.prefix).resolve() != (RUNTIME_DIRECTORY/'.venv').resolve():
            raise ValueError('Tokenizer-only validation requires existing restored CPU interpreter')
        _verified_offline_tokenizer(admission.asset_directory)
        admission=replace(admission,tokenizer_verified=True)
        if 'torch' in sys.modules or 'transformers' in sys.modules:
            raise RuntimeError('Tokenizer-only preflight imported a model library')
    if not args.execute:
        print(json.dumps(admission.as_dict(),indent=2,allow_nan=False))
        return 2  # HOLD is never a scientific/native PASS.
    try:
        if type(admission) is not OriginalAdmission:raise OriginalExecutionHold('Exact locked OriginalAdmission required')
        admission.assert_execution_allowed()
        if args.out is None:parser.error('--out required for separately released execution')
        run_original(admission,args.out)
    except OriginalExecutionHold as exc:
        print(json.dumps(dict(status='HOLD_ORIGINAL_FIRST24',reason=str(exc),native_model_actions=0),indent=2))
        return 2
    return 0

if __name__ == '__main__':raise SystemExit(main())
