"""NEW model-free wiring/serialization checks; no native or pretrained calls."""
import array,copy,json,struct,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as O
from unittest.mock import patch
import contract_reconstructed as c
from first24_coordinator_reconstructed import coordinate_first24,run_first24
from production_evidence_reconstructed import ProductionEvidenceStore
from evidence_sink_reconstructed import BoundedJSONLJournal,TerminalEvidenceStore
from test_contract_scoring_reconstructed import record
from native_backend_reconstructed import NativeCalls,NativeOwner
from ancestry_reconstructed import TrackedNativeOutput,VerifiedClone

class Store:
    def __init__(self,path):
        self.journal=BoundedJSONLJournal(path);self.terminal=TerminalEvidenceStore(self.journal);self.events=[]
    def begin_cell(self,cell):self.terminal.begin_cell(cell['cell_id'],{'frozen':c.digest(cell)})
    def emit(self,row):self.journal.append(row);self.events.append(row)

class Executor:
    def __init__(self,store,*,fail=None,wrong=None,malformed=None):
        self.store=store;self.fail=fail;self.wrong=wrong;self.malformed=malformed;self.visited=[];self.calls=self.tokens=0;self.aborted=False
    def execute(self,cell):
        self.visited.append(cell['cell_id']);self.store.terminal.mark_model_invoked(cell['cell_id'])
        if cell['cell_id']==self.fail:raise ValueError('scripted primary failure')
        self.store.terminal.mark_model_returned(cell['cell_id'])
        n=len(cell['candidates'][cell['expected_answer']])-1
        mandatory=[r for r in cell['calls'] if not r['conditional_on_no_previous_EOS']]
        self.calls+=len(mandatory)+n;self.tokens+=sum(r['network_tokens'] for r in mandatory)+n
        row=record(cell,.2 if cell['arm']=='Hctx32' and cell['variant']=='A2' else 0.,cell['cell_id']==self.wrong)
        if cell['cell_id']==self.malformed:row['cell_id']='ch01'
        return row
    def summary(self):return {'scripted_calls':self.calls,'scripted_tokens':self.tokens,'native_execution':False}
    def abort(self):self.aborted=True

class CoordinatorTests(unittest.TestCase):
    def test_canonical_snapshot_does_not_follow_later_plan_mutation(self):
        frozen=c.plan()[0];c.canonical_cell(frozen)
        changed=copy.deepcopy(frozen);changed['calls'][0]['input_ids'][0]+=1
        with patch.object(c,'plan',return_value=[changed]):
            self.assertEqual(c.canonical_cell(frozen),frozen)
            with self.assertRaises(ValueError):c.canonical_cell(changed)
    def test_all24_fixed_order_scripted173_4705(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'journal.jsonl');executor=Executor(store)
            result=coordinate_first24(executor,store);store.journal.close()
            self.assertEqual(executor.visited,[r['cell_id'] for r in c.plan()]);self.assertEqual((executor.calls,executor.tokens),(173,4705))
            self.assertEqual(result['status'],'PASS_STAGE1_COMPETENCE_AND_CONTEXTUAL_HARM_ONLY')
            self.assertFalse(result['continuation_authorized']);self.assertTrue(executor.aborted)
            self.assertEqual(len(store.terminal.compact_terminal),24);self.assertIsNone(store.terminal.active_payload)
    def test_firstwrong_no_second_cell(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'j');executor=Executor(store,wrong='ch01');r=coordinate_first24(executor,store);store.journal.close()
            self.assertEqual(executor.visited,['ch01']);self.assertEqual(r['status'],'STOP_COMPETENCE')
            self.assertTrue(all(x['status']=='not_run_gate' for x in r['records'][1:]))
    def test_malformed_second_terminal_identity_is_ch02(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'j');executor=Executor(store,malformed='ch02');r=coordinate_first24(executor,store);store.journal.close()
            self.assertEqual(r['first_failure']['cell_id'],'ch02');self.assertEqual(r['records'][0]['status'],'completed')
            self.assertEqual(store.terminal.compact_terminal['ch01']['status'],'succeeded');self.assertEqual(store.terminal.compact_terminal['ch02']['status'],'failed')
    def test_exception_preserves_active_identity_and_partial(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'j');executor=Executor(store,fail='ch03');r=coordinate_first24(executor,store);store.journal.close()
            self.assertEqual(executor.visited,['ch01','ch02','ch03']);self.assertEqual(r['first_failure']['cell_id'],'ch03')
            self.assertIn('scripted primary failure',r['first_failure']['detail']['message']);self.assertTrue(executor.aborted)
    def test_locked_before_production_dependencies(self):
        class Admission:
            tokenizer_verified=False
            def assert_execution_allowed(self):raise RuntimeError('HOLD original')
        with self.assertRaisesRegex(RuntimeError,'HOLD original'):run_first24(None,None,None,None,None,None,Admission())
    def test_verified_tokenizer_mandatory(self):
        with self.assertRaisesRegex(RuntimeError,'tokenizer'):run_first24(None,None,None,None,None,None,O(assert_execution_allowed=lambda:None,tokenizer_verified=False))

class Tensor:
    def __init__(self,values):self.values=array.array('f',values);self.shape=(len(values),);self.dtype='F32';self.device=O(type='cpu')
    def numel(self):return len(self.values)
    def detach(self):return self
    def contiguous(self):return self
    def view(self,unused):return self
    def numpy(self):return self.values

class SerializationTests(unittest.TestCase):
    def torch(self):return O(float32='F32',uint8='U8',Tensor=Tensor,isfinite=lambda t:O(all=lambda:True))
    def test_streamed_tensor_receipt_and_exact_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=ProductionEvidenceStore(Path(tmp)/'run',self.torch(),None,artifact_cap_bytes=64)
            receipt=store._artifact('x',Tensor([1.,2.]));store.close()
            self.assertEqual((store.path/receipt['path']).read_bytes(),struct.pack('=ff',1.,2.))
            self.assertEqual(receipt['bytes'],8);self.assertEqual(store.raw_bytes,8)
    def test_artifact_failure_poisoned_no_later_append(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=ProductionEvidenceStore(Path(tmp)/'run',self.torch(),None,artifact_cap_bytes=64)
            store._artifact('x',Tensor([1.]))
            with self.assertRaises(FileExistsError):store._artifact('x',Tensor([1.]))
            with self.assertRaisesRegex(RuntimeError,'poisoned'):store.emit({'kind':'later'})
            self.assertEqual((store.path/'x.f32').stat().st_size,4);store.close()
    def test_wrong_root_cell_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=ProductionEvidenceStore(Path(tmp)/'run',self.torch(),None,artifact_cap_bytes=64);store.begin_cell(c.plan()[0])
            with self.assertRaisesRegex(ValueError,'wrong active'):store.emit(dict(kind='root_call',call_id='ch02.n01',model_invoked=True,model_returned=False))
            store.close()

class NativeCaptureHookTests(unittest.TestCase):
    def setUp(self):
        self.backend=NativeCalls.__new__(NativeCalls);self.backend.current=None;self.backend.bind(c.plan()[0]);self.backend._owners={};self.backend._histories={}
    def test_active_requires_same_actual_cache_and_frozen_call(self):
        cache=O();self.backend._active_capture=(self.backend.current['calls'][1],cache)
        self.assertEqual(self.backend.active_capture_identity(cache)['cell_id'],'ch01')
        with self.assertRaises(ValueError):self.backend.active_capture_identity(O())
        self.backend._active_capture=(self.backend.current['calls'][0],cache)
        with self.assertRaises(ValueError):self.backend.active_capture_identity(cache)
    def test_completed_checks_live_ancestry_version(self):
        class Cache:pass
        a=tuple(self.backend.current['calls'][0]['input_ids']);b=tuple(self.backend.current['calls'][1]['input_ids'])
        root=NativeOwner(Cache(),a)
        self.backend.ancestry.register_native_root(TrackedNativeOutput(root,root.cache,0,a,True,True,True),branch='prefill',purpose='A')
        candidate=NativeOwner(Cache(),a)
        self.backend.ancestry.verified_clone(root,expected_tokens=a,branch='prefill',purpose='B',clone_callback=lambda *args:VerifiedClone(candidate,candidate.cache,0,a,True,True))
        permit=self.backend.ancestry.claim_for_forward(candidate,parent_owner=root,expected_tokens=a,appended_tokens=b,branch='prefill',purpose='B')
        candidate.history=a+b;candidate.version=1
        self.backend.ancestry.register_native_output(permit,TrackedNativeOutput(candidate,candidate.cache,1,a+b,True,True,True))
        self.backend._nodes[self.backend.current['pre_Q_producer']]=candidate
        self.assertEqual(self.backend.completed_capture_identity(candidate)['cell_id'],'ch01')
        candidate.version=2
        with self.assertRaises(RuntimeError):self.backend.completed_capture_identity(candidate)

if __name__=='__main__':unittest.main(verbosity=2)
