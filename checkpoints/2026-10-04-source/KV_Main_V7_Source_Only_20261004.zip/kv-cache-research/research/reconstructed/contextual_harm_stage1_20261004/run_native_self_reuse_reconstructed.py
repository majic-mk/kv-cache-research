"""One NEW tiny R/F32/Hctx32 self-reuse check; no pretrained loading or quality claim.
Only run through the separately authorized bounded guard. No reconstructed lost
pass is used as evidence, and this is not execution of the scientific first24.
"""
import argparse,json,os,resource,struct,sys,time,traceback
from pathlib import Path
import contract_reconstructed as c


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);args=p.parse_args()
    if os.environ.get('RECONSTRUCTED_SELF_REUSE_TINY')!='ONE_AUTHORIZED_ATTEMPT':raise RuntimeError('Guarded one-attempt entry required')
    args.out.mkdir(exist_ok=False);report_path=args.out/'report.json';start=time.monotonic()
    report=dict(reconstruction=c.RECONSTRUCTION,status='RUNNING_TINY_ENGINEERING_ONLY',seed=20261004,
        scope='Known d01/A1 R,F32,Hctx32 numerical self-reuse only; not24-cell competence/harm and no quality claim',
        selected_cell_ids=['ch01','ch02','ch17'],pretrained_loads=0,pretrained_forwards=0,checks=[],raw_artifacts={},first_failure=None)
    from evidence_sink_reconstructed import BoundedJSONLJournal
    cost_journal=BoundedJSONLJournal(args.out/'costs.jsonl',total_limit=2_800_000)
    from tiny_cost_summary_reconstructed import TinyCostSummary
    costs=TinyCostSummary(cost_journal)
    emit=costs.emit
    previous=c.HERE/'native_self_reuse_attempt_01'
    previous_report=json.loads((previous/'report.json').read_text()) if (previous/'report.json').exists() and previous!=args.out else {}
    def save():
        data=json.dumps(report,indent=2,allow_nan=False)+'\n'
        if len(data)>1_300_000:raise RuntimeError('Tiny report cap')
        retained=sum(p.stat().st_size for p in c.HERE.rglob('*') if p.is_file() and p!=report_path)
        if retained+len(data)+100000>=20*1024**2:raise RuntimeError('Total retained output cap before report')
        report_path.write_text(data)
    def progress():
        data=dict(status=report['status'],completed_arms=list(report.get('scores',{})),checks=len(report['checks']),raw_artifact_count=len(report['raw_artifacts']),elapsed_seconds=time.monotonic()-start)
        (args.out/'progress.json').write_text(json.dumps(data)+'\n')
    def artifact(name,tensor,cache_field=None):
        tensor=tensor.detach().contiguous();raw=tensor.view(torch.uint8).numpy().tobytes()
        if tensor.dtype!=torch.float32 or len(raw)>2_000_000:raise ValueError('Tiny raw artifact FP32/size cap')
        digest=__import__('hashlib').sha256(raw).hexdigest()
        old=previous_report.get('raw_artifacts',{}).get(name)
        if old and old['sha256']==digest and old['shape']==list(tensor.shape) and c.sha(c.HERE/old['path'])==digest:
            report['raw_artifacts'][name]={**old,'current_tensor_bytes_reverified':True,'storage_deduplicated_from_preserved_attempt_01':True}
            if cache_field is not None:report['raw_artifacts'][name]['cache_field']=cache_field
            cost_journal.append({'kind':'raw_artifact','name':name,'record':report['raw_artifacts'][name]})
            return
        if sum(x.stat().st_size for x in c.HERE.rglob('*') if x.is_file())+len(raw)+1300000>=20*1024**2:raise RuntimeError('Retained output cap')
        path=args.out/(name+'.f32')
        with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        report['raw_artifacts'][name]=dict(path=str(path.relative_to(c.HERE)),bytes=len(raw),sha256=c.sha(path),shape=list(tensor.shape),dtype='float32',byte_order=sys.byteorder)
        if cache_field is not None:report['raw_artifacts'][name]['cache_field']=cache_field
        cost_journal.append({'kind':'raw_artifact','name':name,'record':report['raw_artifacts'][name]})
    def raw_cache(label,owner):
        metadata,tensors=backend.evidence.cache_snapshot(owner.cache,torch)
        report.setdefault('raw_cache_metadata',{})[label]=metadata
        for i,(path,t) in enumerate(tensors.items()):
            name=f'{label}_{i:02d}';artifact(name,t,cache_field=path)
    try:
        import torch
        from transformers import Qwen3_5TextConfig,Qwen3_5ForCausalLM
        from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
        from native_backend_reconstructed import NativeCalls,TorchScoreBackend,engine_support
        from contextual_native_reconstructed import ContextualCapture,HctxAdapter
        from scoring_reconstructed import score_post_q_with_backend
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(report['seed'])
        config=Qwen3_5TextConfig(vocab_size=c.VOCAB,hidden_size=8,intermediate_size=16,tie_word_embeddings=True,
            num_hidden_layers=24,num_attention_heads=1,num_key_value_heads=1,head_dim=8,
            linear_key_head_dim=2,linear_value_head_dim=2,linear_num_key_heads=1,linear_num_value_heads=2,linear_conv_kernel_dim=4,
            layer_types=(['linear_attention']*3+['full_attention'])*6,
            rope_parameters={'rope_type':'default','rope_theta':10000.,'partial_rotary_factor':.5,'mrope_section':[1,1,0]})
        config._attn_implementation='eager';model=Qwen3_5ForCausalLM(config).eval()
        with torch.no_grad():
            for name,param in model.named_parameters():
                if name.endswith('.A_log'):param.fill_(.1234567)
                elif name.endswith('.linear_attn.norm.weight'):param.fill_(.9876543)
                else:
                    if name.endswith('norm.weight') or name.endswith('layernorm.weight'):param.fill_(.00390625)
                    param.data=param.data.to(torch.bfloat16)
        report['model_config']=config.to_dict();report['parameter_count']=sum(p.numel() for p in model.parameters())
        report['mixed_storage']={str(d):sum(p.numel() for p in model.parameters() if p.dtype==d) for d in (torch.float32,torch.bfloat16)}
        evidence,support=engine_support();engine=support.PagedArenaEngine(model,hf,torch,synthetic=True,history_limit=16,lease_sink=lambda row:emit({'kind':'arena',**row}))
        plans=c.plan();contexts=c.recovered_contexts();ctx=next(r for r in contexts if (r['pair_id'],r['variant'])==('d01','A1'))
        A,B,Q=[tuple(ctx[k]) for k in ('A_ids','B_ids','Q_ids')];report['tokens']={'A':A,'B':B,'Q':Q}
        limits=c.numerical_limits();references={};source=None
        def strip_hash(x):
            if isinstance(x,dict):return {k:strip_hash(v) for k,v in x.items() if k!='sha256'}
            if isinstance(x,list):return [strip_hash(v) for v in x]
            return x
        def compare(label,actual,ref,logits=None,ref_logits=None):
            am,at=evidence.cache_snapshot(actual.cache,torch);rm,rt=evidence.cache_snapshot(ref.cache,torch)
            if strip_hash(am)!=strip_hash(rm) or set(at)!=set(rt):raise AssertionError('Complete cache metadata differs: '+label)
            for path,x in at.items():
                y=rt[path];isR='recurrent_states' in path
                atol=limits['endpoint_recurrent_atol' if isR else 'endpoint_conv_attention_atol'];rtol=limits['endpoint_recurrent_rtol' if isR else 'endpoint_conv_attention_rtol']
                delta=float((x-y).abs().max()) if x.numel() else 0.;passed=bool(torch.isfinite(x).all() and torch.allclose(x,y,atol=atol,rtol=rtol))
                report['checks'].append(dict(label=label,field=path,max_abs=delta,atol=atol,rtol=rtol,passed=passed))
                if not passed:raise AssertionError('Cache control failed: '+label+'/'+path)
            if logits is not None:
                delta=float((logits-ref_logits).abs().max());tv=float((logits.softmax(-1)-ref_logits.softmax(-1)).abs().sum()/2)
                passed=bool(torch.allclose(logits,ref_logits,atol=limits['logit_atol'],rtol=limits['logit_rtol'])) and tv<=limits['TV_max']
                report['checks'].append(dict(label=label,field='logits',max_abs=delta,TV=tv,passed=passed))
                if not passed:raise AssertionError('Logit control failed: '+label)
        with engine:
            backend=NativeCalls(model,engine,torch,hf,tiny_testing=True,emit=emit)
            for index in (0,1,16):
                cell=plans[index];backend.bind(cell);arm=cell['arm'];references[arm]={}
                if arm=='Hctx32':
                    assembled,trace=HctxAdapter(model,backend,source).build(A,B,32)
                    preq=backend.register_hctx(assembled,trace,source)
                    report['Hctx_trace']={k:v for k,v in trace.items() if k!='fresh_seam_owner'}
                else:
                    a=backend.checked_forward(A,branch='prefill',purpose='A')
                    if arm=='R':
                        with ContextualCapture(model,backend,A,B) as capture:b=backend.checked_forward(B,a,branch='prefill',purpose='B')
                        source=capture.finish(b);preq=backend.register_pre_q(source.cache)
                        report['source_manifest']=source.manifest
                    else:
                        seam=backend.checked_forward(B[:32],a,branch='prefill',purpose='B_seam')
                        preq=backend.checked_forward(B[32:],seam,branch='prefill',purpose='B_fresh_suffix')
                preq=backend.register_pre_q(preq)
                refarm=None if arm=='R' else 'R' if arm=='F32' else 'F32'
                if refarm:compare(arm+'.pre_Q',preq,references[refarm]['pre_Q'][0])
                references[arm]['pre_Q']=(preq,None);raw_cache(arm+'_preQ',preq)
                q=backend.checked_forward(Q,preq,branch='Q_from_owned_pre_Q_clone',purpose='Q');artifact(arm+'_Q_logits',q.logits);raw_cache(arm+'_postQ',q)
                def observe(label,owner,logits):
                    if refarm:compare(arm+'.'+label,owner,references[refarm][label][0],logits,references[refarm][label][1])
                    references[arm][label]=(owner,logits)  # Native owners are immutable across cloned continuations.
                scoring=TorchScoreBackend(backend,lambda ids:' '.join(map(str,ids)))
                scored=score_post_q_with_backend(cell,q,scoring,exact_reference=None if refarm is None else references[refarm]['scores'],observe=observe)
                references[arm]['scores']=scored;report.setdefault('scores',{})[arm]=scored
                backend.finish();progress()
                if arm=='F32':references.pop('R')
                elif arm=='Hctx32':references.pop('F32')
                a=b=seam=capture=q=preq=None
            report['actual_root_calls']=backend.calls;report['actual_network_tokens']=backend.tokens
            if backend.calls>37 or backend.tokens>590:raise RuntimeError('Fixed tiny three-arm call/token cap')
            # Preserve compact source operands and first-layer factors for a
            # subsequent raw arithmetic audit, not every transient cache.
            for layer,operands in source.layers.items():
                for name in ('k','v','g','beta'):artifact(f'source_L{layer}_{name}',operands[name])
            first_layer=min(source.suffix.layers)
            artifact('source_first_T',source.suffix.layers[first_layer]['T']);artifact('source_first_U',source.suffix.layers[first_layer]['U'])
        report['engine_report']=engine.report();report['status']='PASS_NEW_TINY_SELF_REUSE_ONLY'
        report['evidence_limit']='Actual reconstructed engine; all cache fields compared live, raw pre/postQ caches andQlogits/sourceoperands retained; candidate/greedy transient caches only checks/hashes. Not quality or first24 original execution.'
    except BaseException as exc:
        report.update(status='FAIL_NEW_TINY_SELF_REUSE',first_failure={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
    finally:
        report['full_cost_summary']=costs.summary()
        try:cost_journal.append({'kind':'cost_aggregates','record':costs.summary()})
        except BaseException as evidence_error:
            report.setdefault('secondary_failures',[]).append({'type':type(evidence_error).__name__,'message':str(evidence_error)})
            if report['first_failure'] is None:report['first_failure']={'type':type(evidence_error).__name__,'message':str(evidence_error)};report['status']='FAIL_NEW_TINY_SELF_REUSE'
        cost_journal.close()
        report['actual_root_calls']=costs.root_started;report['actual_network_tokens']=costs.root_tokens
        report.update(elapsed_seconds=time.monotonic()-start,process_peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            cost_events=cost_journal.durable_events,cost_journal_bytes=cost_journal.actual_written_bytes,cost_journal_sha256=c.sha(args.out/'costs.jsonl'))
        save()
    print(json.dumps({k:report.get(k) for k in ('status','actual_root_calls','actual_network_tokens','elapsed_seconds','process_peak_RSS_bytes','first_failure')},indent=2))
    return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
