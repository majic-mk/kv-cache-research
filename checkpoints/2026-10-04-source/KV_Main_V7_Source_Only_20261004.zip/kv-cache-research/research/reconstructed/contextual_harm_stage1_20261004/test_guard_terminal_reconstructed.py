"""Stdlib terminal race faults only; never spawn/reap a real model process."""
import unittest
from types import SimpleNamespace
from guard_native_self_reuse_reconstructed import sample_or_reap,ProcessMetricsUnavailable
class Tests(unittest.TestCase):
    def wait(self,rows):
        rows=iter(rows)
        return lambda pid,options:next(rows)
    def test_live_sample(self):
        r=sample_or_reap(123,wait4=self.wait([(0,0,None)]),read_status=lambda pid:{'VmRSS':100,'VmHWM':150})
        self.assertIsNone(r['terminal']);self.assertEqual(r['metrics']['VmHWM'],150)
    def test_owned_terminal_avoids_proc_read(self):
        u=SimpleNamespace(ru_maxrss=10)
        r=sample_or_reap(123,wait4=self.wait([(123,0,u)]),read_status=lambda pid:self.fail('terminal process must not be sampled'))
        self.assertEqual(r['terminal'],(0,u))
    def test_missing_zombie_metrics_resolved_by_wait4(self):
        u=SimpleNamespace(ru_maxrss=10)
        def missing(pid):raise ProcessMetricsUnavailable('State Z')
        r=sample_or_reap(123,wait4=self.wait([(0,0,None),(123,256,u)]),read_status=missing)
        self.assertEqual(r['terminal'],(1,u));self.assertTrue(r['terminal_proc_race_resolved'])
    def test_missing_proc_resolved_by_wait4(self):
        def missing(pid):raise FileNotFoundError()
        r=sample_or_reap(123,wait4=self.wait([(0,0,None),(123,0,'rusage')]),read_status=missing)
        self.assertEqual(r['terminal'],(0,'rusage'))
    def test_missing_metrics_while_unreaped_never_invents_zero(self):
        def missing(pid):raise ProcessMetricsUnavailable('State R')
        with self.assertRaises(ProcessMetricsUnavailable):sample_or_reap(123,wait4=self.wait([(0,0,None),(0,0,None)]),read_status=missing)
    def test_wrong_reaped_pid_rejected(self):
        with self.assertRaises(RuntimeError):sample_or_reap(123,wait4=self.wait([(456,0,None)]),read_status=lambda pid:{})
if __name__=='__main__':unittest.main(verbosity=2)
