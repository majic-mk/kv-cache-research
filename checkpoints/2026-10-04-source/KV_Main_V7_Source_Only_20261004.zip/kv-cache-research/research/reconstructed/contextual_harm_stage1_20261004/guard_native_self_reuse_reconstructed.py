"""NEW fixed one-attempt tiny guard. No pretrained model/weight path exists."""
import json,os,shutil,signal,subprocess,time
from pathlib import Path
import contract_reconstructed as c
RSS_LIMIT=500_000_000;WALL_LIMIT=300;DISK_FLOOR=5_000_000_000;OUTPUT_CAP=20*1024**2

class ProcessMetricsUnavailable(RuntimeError):pass


def status(pid):
    fields={r.split(':',1)[0]:r.split(':',1)[1].strip() for r in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in r}
    if not {'VmRSS','VmHWM'}<=fields.keys():
        raise ProcessMetricsUnavailable('Missing memory metrics; State='+str(fields.get('State')))
    result={k:int(fields[k].split()[0])*1024 for k in ('VmRSS','VmHWM')}
    if any(v<=0 for v in result.values()):raise ProcessMetricsUnavailable('Invalid zero memory metrics')
    return result


def sample_or_reap(pid,*,wait4=os.wait4,read_status=status):
    """Only owned wait4 truth resolves disappeared/zombie process metrics."""
    ended,state,usage=wait4(pid,os.WNOHANG)
    if ended:
        if ended!=pid:raise RuntimeError('wait4 reaped wrong process')
        return {'terminal':(os.waitstatus_to_exitcode(state),usage),'metrics':None,'terminal_proc_race_resolved':False}
    try:metrics=read_status(pid)
    except (FileNotFoundError,ProcessMetricsUnavailable):
        ended,state,usage=wait4(pid,os.WNOHANG)
        if ended==pid:return {'terminal':(os.waitstatus_to_exitcode(state),usage),'metrics':None,'terminal_proc_race_resolved':True}
        raise ProcessMetricsUnavailable('Missing metrics without owned terminal wait4 evidence')
    return {'terminal':None,'metrics':metrics,'terminal_proc_race_resolved':False}


def source_pins():
    paths=list(c.HERE.glob('*.py'))+list((c.HERE.parent/'paged_fp32_engine_20261004').glob('*.py'))
    return {str(p.relative_to(c.REPO)):c.sha(p) for p in sorted(paths)}

def main():
    out=c.HERE/'native_self_reuse_attempt_03';log=c.HERE/'native_self_reuse_attempt_03.log';receipt=c.HERE/'native_self_reuse_guard_03.json'
    prior=[]
    for n in ('01','02'):
        name='native_self_reuse_guard_'+n+'.json';old=c.read(c.HERE/name)
        if old['status']!='FAIL_BOUNDED_NEW_TINY_PROCESS':raise RuntimeError('Preserved failed previous attempts required')
        prior.append(dict(receipt=name,sha256=c.sha(c.HERE/name),elapsed_seconds=old['elapsed_seconds'],CPU_user_seconds=old['CPU_user_seconds'],CPU_system_seconds=old['CPU_system_seconds'],combined_HWM_bytes=old['conservative_combined_HWM_bytes']))
    retained_before=sum(p.stat().st_size for p in c.HERE.rglob('*') if p.is_file())
    new_attempt_no_dedupe_cap=3_601_408+2_800_000+1_300_000+262_144
    if retained_before+new_attempt_no_dedupe_cap>=OUTPUT_CAP:raise RuntimeError('Whole no-dedup attempt does not fit newly admitted cap')
    if any(p.exists() for p in (out,log,receipt)):raise RuntimeError('One attempt already exists; no automatic rerun')
    if shutil.disk_usage(c.HERE).free<DISK_FLOOR:raise RuntimeError('5GB disk floor')
    pins=source_pins();before=time.monotonic();samples=[];reason=None;sent=None;terminal_race_resolved=False;sampling_failures=[]
    wrapper=c.HERE.parent/'runtime_recovery_20261004/cpu_python.sh'
    env=dict(os.environ,RECONSTRUCTED_SELF_REUSE_TINY='ONE_AUTHORIZED_ATTEMPT',PYTHONDONTWRITEBYTECODE='1')
    with log.open('x') as stream:
        process=subprocess.Popen(['bash',str(wrapper),str(c.HERE/'run_native_self_reuse_reconstructed.py'),'--out',str(out)],cwd=c.REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        while True:
            try:
                observation=sample_or_reap(process.pid)
                if observation['terminal'] is not None:
                    code,usage=observation['terminal'];process.returncode=code
                    terminal_race_resolved=observation['terminal_proc_race_resolved'];break
                child=observation['metrics'];own=status(os.getpid());peak=max(child.values())+own['VmHWM']
                samples.append(dict(elapsed=time.monotonic()-before,combined_RSS_HWM_bytes=peak))
                if peak>=RSS_LIMIT:reason=reason or '500MB_combined_RSS_HWM'
            except (ProcessMetricsUnavailable,FileNotFoundError) as exc:
                reason=reason or 'missing_metrics_without_terminal_wait4'
                if len(sampling_failures)<8:sampling_failures.append({'type':type(exc).__name__,'message':str(exc)})
            if time.monotonic()-before>=WALL_LIMIT:reason=reason or '300s_wall'
            if shutil.disk_usage(c.HERE).free<DISK_FLOOR:reason=reason or '5GB_disk_floor'
            if sum(p.stat().st_size for p in c.HERE.rglob('*') if p.is_file())>=OUTPUT_CAP:reason=reason or '20MiB_retained_outputs'
            if reason and sent is None:
                try:os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                sent=time.monotonic()
            elif sent is not None and time.monotonic()-sent>2:
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            time.sleep(.05)
    child_peak=usage.ru_maxrss*1024;guard_peak=status(os.getpid())['VmHWM'];combined=child_peak+guard_peak
    if combined>=RSS_LIMIT:reason=reason or 'terminal_500MB_combined_HWM'
    after=source_pins()
    if pins!=after:reason=reason or 'source_changed_during_test'
    report=dict(status='PASS_BOUNDED_NEW_TINY_PROCESS' if code==0 and reason is None else 'FAIL_BOUNDED_NEW_TINY_PROCESS',
        exit_code=code,resource_stop=reason,elapsed_seconds=time.monotonic()-before,
        terminal_proc_race_resolved_by_owned_wait4=terminal_race_resolved,sampling_failures=sampling_failures,
        child_peak_RSS_bytes=child_peak,guard_peak_RSS_bytes=guard_peak,conservative_combined_HWM_bytes=combined,
        CPU_user_seconds=usage.ru_utime,CPU_system_seconds=usage.ru_stime,limits=dict(combined_RSS_HWM=RSS_LIMIT,wall=WALL_LIMIT,disk_floor=DISK_FLOOR,retained_output=OUTPUT_CAP),
        source_pins_before=pins,source_pins_after=after,log_sha256=c.sha(log),samples=samples,
        separately_preserved_failed_attempts=prior,
        prospective_output_admission=dict(previous_cap=10_000_000,new_cap=OUTPUT_CAP,retained_before=retained_before,whole_new_attempt_without_dedup_cap=new_attempt_no_dedupe_cap,reason='Parent approved one bounded20MiB attempt from explicit full-payload arithmetic; no old result relabeled'),
        pretrained_loads=0,pretrained_forwards=0,historical_recovery_claim=False)
    receipt.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('samples','source_pins_before','source_pins_after')},indent=2))
    return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
