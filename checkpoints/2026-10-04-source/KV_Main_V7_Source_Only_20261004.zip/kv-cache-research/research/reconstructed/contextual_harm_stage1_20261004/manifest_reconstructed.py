"""Write a NEW reconstruction manifest; never execute a model or acquire assets."""
import datetime,json,shutil
from pathlib import Path
import contract_reconstructed as c

def build():
    cells=c.plan();bounds=c.work_bounds(cells)
    data={'reconstruction':c.RECONSTRUCTION,'status':'LOCKED_FIRST24_COORDINATOR_PREPARED_MODEL_FREE_ONLY_ORIGINAL_HOLD',
      'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'recovered_baseline_commit':'ecc1c87aaf0e609302f6b08023096078345f6f7a',
      'recovered_protocol_freeze_files_verified':c.verify_recovered_freezes(),'inputs':c.input_pins(),
      'fixed_work_bounds':bounds,'native_backend_qualification':False,'original_execution_admitted':False,
      'historical_lost_results':[{'claim':'Later paged FP32 eight-cell numerical pass','source':'retained conversation only','raw_proof_locally_available':False,'quality_claim':False},
          {'claim':'Corrected tiny full24 scripted integration pass,173 calls/4705tokens,424206336B combined peak','source':'retained conversation only','raw_proof_locally_available':False,'quality_claim':False}],
      'surviving_negative_results':['0.8B first-reference competence failure','2B BF16 exact-schedule numerical failure'],
      'missing_original_dependencies':['Final asset parser receipt and activation of the newly reviewed fresh checkpoint; old default partial remains unqualified',
          'Independent original execution/resource/evidence-cap admission',
          'Original loader and first24 native execution evidence'],
      'new_prepared_source':['Canonical immutable plan and actual group R/A1 producer binding',
          'Mandatory original-tokenizer first24 coordinator and raw all-call evidence',
          'File-backed needed source/reference tensors with charged restore/eviction',
          'Source-locked exact meta/assign loader and owned-wait4 external guard'],
      'current_model_free_test_count':152,'current_native_model_tests':0,
      'pre_guard_manifest_sha256':'e78aca974fa56c08c09cc264b2902cbbfef0cdd177c9ccde65919ecd71ec5d09',
      'guard_revision_source_sha256':'661628774e41efdef6e382edeaa17b5af9fe40554e5f4b5b49d64b1a0ce1290b',
      'guard_revision_model_free_tests':14,'guard_revision_independent_closure':True,
      'prior_v6_manifest_sha256':'6a704ddf1d4dc3e2af550d658db81bf61e0104b0dc0ea9e1ff10a8060064a87f',
      'current_evidence_limits':'Current source-only revision has no new native run. Third tiny child remains numerical pass with incomplete external guard; original fit is analytically estimated, not measured.',
      'new_engine_path':'research/reconstructed/paged_fp32_engine_20261004',
      'runtime_status':'New pinned runtime restoration is separate evidence; no old whole-runtime byte identity claim',
      'filesystem_free_bytes':shutil.disk_usage(c.REPO).free,'old_cleanup_question_inapplicable':True,
      'pretrained_model_loads':0,'pretrained_model_forwards':0,'new_tiny_model_constructions':3,
      'new_tiny_root_invocations':93,'new_tiny_root_returns':92,
      'new_tiny_attempts':[{'guard':'native_self_reuse_guard_01.json','status':'failed_cost_journal_cap'},
                          {'guard':'native_self_reuse_guard_02.json','status':'failed_retained_output_preflight'},
                          {'guard':'native_self_reuse_guard_03_incomplete.json','status':'numerical_child_pass_guard_terminal_receipt_missing'}],'downloads':0,'installs':0,'deletions':0,'GPU_use':0,'remote_writes':0,
      'files':{str(p.relative_to(c.HERE)):{'sha256':c.sha(p),'bytes':p.stat().st_size} for p in sorted(c.HERE.rglob('*')) if p.is_file() and p.name!='RECONSTRUCTION_MANIFEST.json' and '__pycache__' not in p.parts}}
    (c.HERE/'execution_plan_reconstructed.json').write_text(json.dumps({'status':'RECONSTRUCTED_UNRUN','bounds':bounds,'cells':cells},indent=2)+'\n')
    data['files']['execution_plan_reconstructed.json']={'sha256':c.sha(c.HERE/'execution_plan_reconstructed.json'),'bytes':(c.HERE/'execution_plan_reconstructed.json').stat().st_size}
    (c.HERE/'RECONSTRUCTION_MANIFEST.json').write_text(json.dumps(data,indent=2)+'\n')
    return {'status':data['status'],'files':len(data['files']),'bytes':sum(x['bytes'] for x in data['files'].values()),'sha256':c.sha(c.HERE/'RECONSTRUCTION_MANIFEST.json')}
if __name__=='__main__':print(json.dumps(build(),indent=2))
