"""Stdlib aggregate-cost checks; no model arithmetic or calls."""
import json,unittest
from tiny_cost_summary_reconstructed import TinyCostSummary
class Sink:
    def __init__(self):self.rows=[]
    def append(self,row):self.rows.append(row)
class Tests(unittest.TestCase):
    def test_exact_paired_leases_and_bytes(self):
        sink=Sink();c=TinyCostSummary(sink)
        for i in range(3):
            for event,t in [('acquire',1.),('release',2.5)]:c.emit(dict(kind='arena',label='linear',event=event,lease_id=i,monotonic=t,cast_bytes=100))
        self.assertEqual(c.summary()['arena_by_operation']['linear'],dict(acquires=3,releases=3,cast_bytes=300,lease_wall_seconds=4.5));self.assertEqual(sink.rows,[])
    def test_source_inclusive_counts(self):
        c=TinyCostSummary(Sink());row=dict(event='contextual_operator',operator='hash',successful=True,wall_ns=10,process_cpu_ns=8,bytes=120)
        c.emit(row);c.emit(row);self.assertEqual(c.summary()['operations']['hash:all']['explicit_bytes'],240)
    def test_first_sink_failure_no_secondary_mask(self):
        class Bad:
            def append(self,row):raise OSError('primary')
        c=TinyCostSummary(Bad())
        with self.assertRaisesRegex(OSError,'primary'):c.emit({'kind':'copy'})
        c.emit({'kind':'cleanup'});self.assertEqual(c.summary()['first_sink_failure']['message'],'primary')
    def test_unmatched_release_rejected(self):
        c=TinyCostSummary(Sink())
        with self.assertRaises(ValueError):c.emit(dict(kind='arena',label='x',event='release',lease_id=4,monotonic=1.))
if __name__=='__main__':unittest.main(verbosity=2)
