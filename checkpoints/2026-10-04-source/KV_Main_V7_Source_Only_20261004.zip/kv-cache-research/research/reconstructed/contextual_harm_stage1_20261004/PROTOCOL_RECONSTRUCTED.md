# Contextual-harm stage 1: reconstructed prospective CPU protocol

Date: 2026-10-04 UTC. Status: **DESIGN ONLY; NOT RELEASED FOR EXECUTION**.

This is a new reconstruction from recovered, tracked sources plus the historical
24-cell design supplied for recovery. It is not a byte-exact recovery of a lost
protocol, runner, freeze, approval, cache, or result. No new model result is
reported here. The recovered worktree is based on commit
`ecc1c87aaf0e609302f6b08023096078345f6f7a`; its 467 recovered tracked files are
unchanged by this document. Source claims below retain their original
2026-10-03 cutoff; this is not a fresh literature or upstream-status search.

## 1. Question, prior outcomes, and claim boundary

The bounded question is: on two fixed development groups that the reference can
answer correctly, does reuse of an A1-conditioned B under changed A2 cause
answer-relevant harm after a correctly defined 32-token seam? The first result
must be problem existence, not a new correction method, natural benchmark,
serving speedup, HYPIC reproduction, or publication claim.

Keep these evidence classes distinct:

- Recovered v2 0.8B/FP32 result: the first d01/A1 full-recompute cell answered
  blue rather than red; 1/16 completed, 15 unrun. The competence failure remains.
- Recovered v3 2B/BF16 result: d01/A1 full and exact both answered red, but their
  numerical control failed; 2/16 completed, 14 unrun. The gold-sum drift was
  -0.0133944524 nat and margin drift -0.1250469423 nat; TV was 0.0124600772.
  Equal answers did not excuse failed cache/logit/scalar controls. That failure
  remains and cannot be overwritten by a different schedule or precision.
- Later full-prior FP32 and tiny full-24 passes are **historical reports whose
  raw proof was lost**. Do not label them currently verified or use their
  reported passes as fresh admission. Targeted revalidation is required before
  relying on their specific claims. The recovered v3 84-control tiny report is
  an earlier, different experiment; it is not the later tiny full-24 proof.
- The 24-cell plan below is a separately reconstructed prospective experiment.
  Its R schedule is not the old monolithic A+B+Q schedule. No success or failure
  of this plan has been established by reconstructing it.

The HYPIC source audit establishes a source-contract issue: a cold full-B tuple
can be replayed after a fresh seam, duplicating its transition and writes.
Ordinary warmup is contextual, not isolated B. Correcting these definitions is
an engineering control, not a research contribution. Deeper conditioning loss
is already acknowledged in HYPIC. Recurrent-state transport, input-response
correction, cross-prefix KV deltas, and attention-output correction have material
prior overlap; neither this protocol nor moving a known idea into a hybrid state
establishes novelty. The broad candidates in the topic reassessment remain
unpromoted.

## 2. Fixed data and numerical substrate

Use the recovered v2/v3 fixture text and verified complete-prompt token arrays;
never recreate a prompt from a model answer or tokenize A, B, Q independently.
Keep candidate IDs, golds, template, empty-thinking suffix, parser, split, order,
and official EOS fixed. No fixture selection, rewording, rank/width search,
threshold tuning, candidate removal, or precision rescue after outcomes.

- Groups: d01, d05, in that order
- Variants: A1, A2, U1, U2, in that order
- A1/A2 exchange the relevant assignments and have different gold answers
- U1/U2 retain A1's assignments and change unrelated weather; they are controls
- All eight contexts have B length 156; d01 Q length 31, d05 Q length 33
- A is 42 tokens for A1/A2 and 49 for U1/U2; relevant B text is at [77,91)
- d01 candidates are red+EOS and blue+EOS, each two tokens
- d05 candidates are copper+EOS (three tokens) and silver+EOS (two tokens)
- EOS is token 248046; greedy output is capped at eight tokens including EOS

The proposed rebuild target is the historically discussed official 2B FP32 CPU
substrate, with identity/precision to be frozen and independently checked before
release: Qwen/Qwen3.5-2B revision
`15852e8c16360a2fea060d615a32b45270f8a8fc`, Transformers source
`02d8fb9784e8f14a1251e4c992cd82a5762417c6`, eager attention and official
PyTorch recurrence/convolution fallbacks. The recovered BF16 artifacts do not
prove FP32 fit or parity. Record actual parameter/cache dtypes, clean loading
keys, asset checksums, software versions, one-thread settings, and CPU identity.
No silent model substitution, BF16 conversion, autocast, or quantization.

The reconstruction retains the historical firststage choice of the recovered
`bf16_exact_schedule_controls` field as prospective engineering limits even for
the separately rebuilt FP32 graph: logit atol/rtol 0.01/0.01, TV <=0.0025,
recurrent endpoint atol/rtol 0.002/0.02, convolution/attention endpoint
atol/rtol 0.01/0.02, candidate-sum and margin differences strictly below 0.01,
and zero greedy-ID disagreements. `contract_reconstructed.numerical_limits()`
reads those values from surviving v3 data; it does not claim the lost later
freeze has been recovered. The field's name is not a BF16 execution instruction.
This provenance and mapping require review before new execution; do not
substitute the older separate 1e-4 tiny-FP32 control or tune limits after results.
All states, logits, derived scores and costs must be finite. Near ties are
reported but do not excuse exact-control ID disagreement.

## 3. Arms and source ancestry

Every arm begins from a fresh target A and uses the same token arrays, causal
mask convention, absolute positions, original rotary basis and nonrotary key
components. Cache channels are recurrent states R, convolution histories C, and
full-attention K/V K, together with length/position/mask metadata.

1. **R:** fresh A, one whole-B call, then Q. Save the pre-Q cache. This schedule
   supplies the fresh-context reference and all eight competence answers.
2. **F32:** independent fresh A, B[:32], B[32:], then Q. This is an exact
   split-B continuation control; it reuses no foreign-context suffix.
3. **Hctx32:** independent fresh target A, fresh B[:32], then assemble the
   pre-Q cache using the source A1-conditioned suffix, followed by fresh Q.

For each group, capture the complete B source trace inside its already-required
R/A1 whole-B call. There is **no extra source model forward** and no isolated-B
source build. All Hctx variants, including U1/U2, refer to this group's same A1
source. The older v2 planning text's isolated-B intended arms are not imported
into this reconstruction; that assumption is superseded explicitly here.

For every recurrent layer, extract a suffix-only affine tuple from the captured
whole-B source trace over [32,n), including only those suffix transitions/writes.
In the source orientation, apply H_out = H_seam T_suffix + U_suffix exactly once.
The source suffix inputs were produced within whole B under A1; do not forward
B[32:] independently, invert a possibly singular full tuple, or replay a full-B
tuple after the seam. Map state orientation and grouped heads explicitly.

The assembled attention cache contains fresh target-prefix and seam K/V plus
source suffix K/V relocated to the target B start. Preserve V, nonrotary key
components, masks, positions, and full uncompressed suffix visibility. Terminal
convolution history is the captured source end tail, in the audited raw
pre-convolution projection convention. Do not silently add an extra target
boundary-convolution repair. A1 self-reuse must meet the same numerical controls
as F32; changed-prefix residuals in A2/U1/U2 are measured rather than assumed.

Label the arm **source-conditioned, suffix-only HYPIC-inspired
intended-semantics CPU reference**. It does not reproduce the author runtime or
paper quality. Keep the author-literal source defect separate; do not exploit it
to manufacture a correction gain.

## 4. First 24 cells, dependency checks, and immediate stop rules

Execute cells 1–16 in group -> variant -> [R,F32] order. Only if all 16 qualify,
execute eight Hctx32 cells in group -> variant order. Thus the cell count is
2 groups x 4 variants x 2 exact-reference arms, followed by 2 x 4 Hctx cells.
No conditional donor, observer, wider-seam, holdout, or correction cell is
released by completing this reconstruction or by finishing the first 24.

For each R cell, require the frozen normalized answer with EOS within the cap.
Report strict gold-token equality separately; do not silently turn it into a
new competence selection criterion. **The first wrong R answer or missing EOS is
an immediate competence STOP, before its F32 or any later cell.** An exact-control
failure, numerical anomaly, clone/ancestry mismatch, integrity issue, watchdog
failure, or resource breach is also an immediate STOP. Preserve the attempted
cell and explicitly mark every remaining cell unrun with its reason.

F32 must be compared with its own variant's R, and Hctx32/A1 with that group's
F32/A1. Controls apply at every dependency boundary:

- Pre-Q: compare every cache channel and metadata before sending Q
- Post-Q: compare every cache and the full next-token logit vector, plus derived
  distribution/scalars, before any candidate or greedy continuation
- Candidate branches: start from independently verified equal, non-aliasing
  post-Q clones; compare full logits, accumulated/per-token scores, cache
  tensors, and branch IDs at every corresponding step before the next call
- Greedy branch: use an independent clone; compare full logits, top-two margin,
  all cache tensors, chosen IDs and EOS status before a dependent decode call

Source and reference caches must remain unchanged. Clone equality is bitwise;
clone storage must not alias mutable branches. Identity/shape/dtype/metadata/ID
checks are exact; numerical semantic comparisons use the frozen component
limits. A final-answer match or aggregate cache norm cannot replace these checks.
For A2/U1/U2 Hctx, record the same complete outputs even though cross-context
numeric equality is not expected.

Score both complete candidate+EOS sequences from independent post-Q clones.
The first candidate token is scored from the existing post-Q vector; forward
only the remaining required preceding candidate tokens, one at a time. Greedy's
first token likewise uses the post-Q vector and then requires at most seven
one-token continuation calls. Stop immediately at EOS; never feed EOS merely
to add a cache endpoint. Raw candidate/greedy IDs and complete logits are retained.

## 5. Decision after all 24 cells

Only after all 24 cells complete with valid controls, evaluate qualifying
changed-context harm. For each of d01/A2 and d05/A2 define:

- Gold loss = gold candidate+EOS log-probability under F32 minus that under Hctx32
- Margin loss = (gold-minus-other margin under F32) minus that under Hctx32
- Gold noise = maximum absolute paired R/F32 gold-score discrepancy across the
  eight fixed contexts; margin noise is the corresponding maximum margin drift

**Both A2 groups must satisfy both losses >= max(0.1 nat, 10 x the respective
noise).** Also report R-referenced losses descriptively, raw outcomes and U1/U2 controls;
noise definitions and aggregation cannot be selected after observing results.
If the condition fails, record no qualifying signal for this fixed screen and
stop. A state discrepancy, a single successful group, or a small confidence-only
toy effect is not success. Crossing this threshold is only a signal warranting
a separate causal decision. It does not establish accuracy loss, generality,
novelty, deployable repair quality, or economic advantage. Report answer flips
separately; a confidence loss must not be renamed an observed answer error.

## 6. Exact stage-1 work ceiling and retained evidence

The historical cap reconciles with the recovered token lengths without new
model execution:

- R: 8 x 3 prefill calls; F32: 8 x 4; Hctx32: 8 x 3 = 80 prefill calls
- R/F32: 3,736 prefill network tokens; Hctx32: 876; total 4,612
- Candidate continuation: 12 d01 cells x 2 calls plus 12 d05 x 3 = 60 calls/tokens
- Mandatory total: 140 calls; conditional greedy maximum: 24 x 7 = 168 calls
- Overall maximum: **308 model calls / 4,840 network tokens**
- Scored vocab vectors: 24 post-Q + 60 candidate + 168 greedy = **252 maximum**

Whole-B source capture happens in R/A1. Tuple extraction/application, copying,
cache comparison, trace I/O and observer arithmetic are separately measured
work, not free because they are not network tokens. Count source construction,
load, asset preparation, validation, failed attempts and any authorized retries;
these are not serving-throughput measurements. Extra diagnostic model calls are
outside this cap and require a separately authorized amendment.

Persist all 24 pre-Q caches, their manifests/hashes and ancestry, required whole-B
source traces, raw logits from every attempted root call (up to 308, including
unscored prefill outputs), IDs, per-cell metrics, complete call ledger,
resource samples, watchdog result and freeze/runner/asset identities. Store them
incrementally; do not keep all caches live merely because all must be retained.
For transient continuation caches, compare while live and persist hashes plus
per-tensor metrics, not every large tensor. A missing raw artifact is marked
missing, never reconstructed from the reported pass or replaced with a hash of
something else. Any interrupted/unrun cell has null measurements plus a reason.

Prospective guard proposal inherits the bounded probe: one CPU process, batch
one, no gradients, 30-minute load-and-execution envelope, 15-minute load maximum,
8 GiB combined model-process-tree/watchdog HWM limit, 9 GB host budget, >=5 GB free disk, and independent
one-second watchdog. Admission must include disk needed for retained evidence,
not weights alone; no silent cap increase or deletion of evidence.

## 7. Later conditional scope, deliberately not implemented or released

Historical planning mentioned a 100-cell conditional scope. Its complete
machine-readable ledger and later runner were not recovered. Do not fabricate
its exact arithmetic, treat 100 as an execution grant, or silently add 100 to
24. Reconstruct and freeze its complete ledger only if stage 1 provides the
qualifying signal and further work is explicitly authorized. Preserve these
scientific constraints:

- Compare corrected Hctx32 against cheap controls. Width 33 is the
  **nearest-more-expensive** wider-seam control, not a cost-matched control.
  Width 96 crosses the relevant B[77:91] sentence and is a diagnostic upper
  control with that advantage disclosed. Count width-specific source tuples,
  fresh seam work, and all data movement.
- Specify the contemplated layer-19 prefix-attention observer and how current
  target prefix K/V are read. Follow its forcing through source-linearized
  RMSNorm using the official (1 + weight) convention, value-write projection,
  convolution and SiLU, then a frozen-factor layer-20 recurrent propagation.
  Pin layer indexing, tangent point, signs, shapes, gates, trace ancestry and
  all operations before a run. This is a proposed observer/linearization, not
  a proven sufficient representation, implementation or novel method.
- Donor staging is Dall, D20, DR, DKC in arm -> group order across d01/A2 and
  d05/A2: complete the whole eight-cell diagnostic before making a D20 decision.
  Dall supplies the complete exact target cache; D20 supplies only layer-20
  recurrent state; DR all recurrent states; DKC attention K/V plus convolution
  histories. Keep other channels at Hctx32 and record joint interventions.
  Dall must recover the correct exact reference before causal attribution.
- Donor states come from the corresponding exact target pre-Q ancestor, never
  another prefix, post-Q state, selected successful retry, or hidden target
  trace passed off as an online observation. Record every oracle input and
  acquisition cost. A recurrent rescue does not prove an exclusively recurrent
  origin: attention forcing can create recurrent error.
- h01 and h05 are fixed holdouts; they must not select fixtures, layers, widths,
  thresholds or successful examples. No replacement if either fails. Their
  shared construction family tests different slots, not unseen-template
  generalization.
- Charge source/target forwards, observers, derivatives, factor construction,
  width-specific rebuilds, storage/live bytes, reads, copies, refreshes and
  fallback work. Compare complete cost and reuse break-even against widening
  the seam. An oracle ceiling is not a deployable cheap correction.

The prior audit's collision warning still applies: recurrent state, convolution
tails and a finite seam alone cannot represent arbitrary hybrid-prefix forcing.
A sufficiently informative online observation, actual-displacement validity,
and cost advantage require evidence. Generic Jacobians and low-rank endpoint
plots cannot substitute for any of these.

## 8. Smallest rebuild and stopping path

1. Preserve recovered tracked files and failures; reconstruct the stage-1
   runner, machine-readable 24-cell ledger, cache schema and freeze in new paths
   only. Validate fixture identities and the 308/4,840/252 accounting using
   standard-library/static checks. Independently review the reconstructed
   source semantics and dependency stop placement once.
2. Obtain explicit asset/environment and CPU-execution authorization. Restore
   only the pinned CPU environment and required official assets after provenance
   and resource admission. Check targeted tiny recurrence/attention/convolution,
   tuple slicing, RoPE relocation, clone and complete-24 scheduling contracts
   whose raw proof was lost; save the proof. Do not rerun unrelated old sweeps
   or search seeds until one passes.
3. Run the one bounded stage-1 ledger after explicit release. Its first 16
   R/F32 cells re-establish competence and the exact schedule under the actual
   substrate; do not precede them with a redundant full pretrained qualification
   matrix. Continue to the eight Hctx cells only while its gates pass. Preserve
   all proof, then apply the one frozen harm decision.
4. On failure/no qualifying signal, stop this fixed seed and state the reason.
   On a qualifying signal, decide whether the specifically scoped later causal
   study is worth authorizing; do not automatically launch 100 cells, a model
   ladder, or new research gates. An implementation defect is reported and
   independently reviewed; a separately approved correction is a new version,
   never an overwritten failure or repeated trial selected for success.

The current recovery filesystem has **31,602,778,112 bytes free (about 31.6 GB)**
as checked on 2026-10-04. The old cleanup/disk-choice question is obsolete;
additional disk does not establish memory fit. Model assets and the previous
runtime environment are missing. This reconstruction authorizes **no model
imports, loads, forwards, downloads, installations, deletion, GPU work, remote
writes, or spending**. Work stays CPU-first; the project ceiling is CNY 100 and
AutoDL is off limits. Further execution requires the specific missing approval,
not another open-ended sequence of preparatory gates.

## Recovered sources used

Paths below are relative to the repository root and remain unmodified:

- `research/topic_reassessment_20261003.md`: no topic promotion; simple controls,
  CPU-first falsification, evidence and novelty boundaries
- `research/hypic_baseline_source_review.md`: contextual warmup, full-tuple/seam
  defect, suffix-only intended reference, convolution and positional contracts
- `research/recurrent_response_prior_audit.md`: prior overlap, information
  sufficiency/collision, response object and complete cost requirements
- `research/diagnostics/hybrid_cpu_competence/RESULTS.md`: preserved v2 failure
- `research/diagnostics/hybrid_cpu_competence_v3/RESULTS.md`: preserved v3 failure
- `research/protocols/hybrid_cpu_quality_v2/{README.md,REVISION.md,protocol.json,result_contract.json}`:
  fixture continuity, original controls, scoring and evidence requirements
- `research/protocols/hybrid_cpu_quality_v3/{README.md,protocol.json,numerical_contract.json,token_validation.json}`:
  pinned 2B identity, FP32/BF16 distinctions, exact recovered tokens and extents
- Historical recovery context supplied with this task: later R/F32/Hctx32
  schedules, caps, proof-loss status and nonreleased conditional design. Those
  details are reconstructed testimony, not tracked recovered run artifacts.

## 2026-10-04 first24 production preparation amendment (unexecuted)

The source-only coordinator now implements this first24 experiment. The scientific
order, comparisons, thresholds and 308/4,840/252 ceiling are unchanged. Original
execution remains source-locked. The third tiny child result and its incomplete
external terminal receipt are preserved; this revision has no native run.

Evidence storage is refined prospectively to make exact later self-reuse checks
possible without holding both F32/A1 banks resident. Persist the 24 pre-Q caches,
two actual incoming-source A caches, and up to **21 additional F32/A1 endpoint
caches** (10 d01 and 11 d05, excluding their already retained pre-Q caches).
These particular transient endpoints have a concrete future use: the ch17/ch21
exact self-reuse controls. Other candidate/greedy cache tensors remain live-only
checks/hashes/metrics. Every returned root logit vector is retained raw, including
prefill outputs, up to 308 complete vectors. A call that fails before producing
logits has no invented output. Source factors/halos, generic decoder-block 19/20
input/output traces and extracted suffix factors are retained once. Later teacher
and seam observer traces are **unimplemented and not claimed**; first24 is
self-contained and does not promise a repair-ready later experiment.

All persistent source tensors and the two F32/A1 reference banks can be remapped
from verified raw evidence. This adds zero model forwards. Private file mappings
are never passed as mutable native branch caches; inactive clean pages are
explicitly discarded. R endpoints are consumed one by one by the immediately
following F32 control. F32/A1 mapped endpoints are consumed at ch17/ch21; each
source is released after its group's final U2 cell. All mapping, hashing,
serialization and extra reconstructed continuation-clone work is charged.
An inactive file mapping is not an automatic promise of zero RSS; the external
guard remains mandatory. Original-size memory fit is unmeasured.

The original loader/guard preparation separates source/arena/cache payload from
runtime, allocator and native-workspace allowances. A prepared meta-construction,
exact-safetensors-assignment route aims to avoid a second full checkpoint copy;
it has not been exercised with original weights. Source-level preparation and
model-free tests cannot qualify it. Raw asset identity, offline token/template
revalidation, current source pins, independent execution admission and the
unchanged resource guard must all hold before any original call. Proposed larger
production evidence caps are admission proposals, not authority to execute.
