"""NEW native call/scoring glue, prepared source; no import-time model action.

Original execution is locked. Only a bounded random/tiny-test model can be
admitted explicitly by a separately authorized caller. No model is constructed
or acquired here. Source/call-spy tests are not evidence that this native path ran.
"""
from __future__ import annotations
from contextlib import nullcontext
from dataclasses import dataclass
import importlib,sys,types,time,weakref
from pathlib import Path
import contract_reconstructed as contract
from ancestry_reconstructed import CacheAncestryRegistry,TrackedNativeOutput,VerifiedClone,DerivedCache,DerivedVerification

ENGINE_DIRECTORY=Path(__file__).resolve().parent.parent/'paged_fp32_engine_20261004'
ORIGINAL_EXECUTION_LOCKED=True


def engine_support():
    package='_firststage_reconstructed_engine'
    if package not in sys.modules:
        m=types.ModuleType(package);m.__path__=[str(ENGINE_DIRECTORY)];sys.modules[package]=m
    return importlib.import_module(package+'.evidence'),importlib.import_module(package+'.paged_fp32_engine')


@dataclass(eq=False)
class NativeOwner:
    cache:object
    history:tuple
    version:int=0
    logits:object=None
    clone_parent:object=None
    clone_purpose:str|None=None


class NativeCalls:
    def __init__(self,model,engine,torch,hf,*,tiny_testing=False,emit=None,raw_logit_sink=None,admission=None):
        if tiny_testing:
            if sum(p.numel() for p in model.parameters())>5_000_000 or any(p.device.type!='cpu' for p in model.parameters()):
                raise ValueError('Tiny CPU model envelope only')
        else:
            if admission is None:raise RuntimeError('HOLD_RECONSTRUCTED: original admission absent')
            admission.assert_execution_allowed()
            if raw_logit_sink is None:raise ValueError('Production requires every root logit vector')
            if any(p.device.type!='cpu' for p in model.parameters()):raise ValueError('CPU-only production route')
        self.model,self.engine,self.torch,self.hf=model,engine,torch,hf
        if emit is None:raise ValueError('Explicit evidence/cost sink is required, including tiny tests')
        self.emit=emit;self.raw_logit_sink=raw_logit_sink
        self.evidence,self.support=engine_support();self._histories={};self._owners=weakref.WeakValueDictionary()
        self._active_capture=None;self.current=None;self.cursor=0;self._nodes={};self._root=None;self.calls=0;self.tokens=0;self.rows=[];self.secondary_evidence_failures=[]
        self._reset_registry()
    def _reset_registry(self):
        self.ancestry=CacheAncestryRegistry(get_cache=lambda o:o.cache,get_version=lambda o:o.version)
    def installed_context(self):
        return nullcontext(self.engine) if self.engine._executing else self.engine.execution()
    def cost_event(self,row):
        self.emit({**row,'reconstruction':contract.RECONSTRUCTION})
    def remember_cache_history(self,cache,history):
        history=tuple(history);key=id(cache)
        def gone(ref):
            if self._histories.get(key,(None,None))[0] is ref:self._histories.pop(key,None)
        self._histories[key]=(weakref.ref(cache,gone),history)
    def history_of(self,value):
        if isinstance(value,NativeOwner):return value.history
        ref,history=self._histories.get(id(value),(lambda:None,None))
        if ref() is not value or history is None:raise ValueError('Unregistered actual native cache history')
        return history
    def cache_of(self,value):return value.cache if isinstance(value,NativeOwner) else value
    def owner_of(self,value):
        if isinstance(value,NativeOwner):return value
        owner=self._owners.get(id(value))
        if owner is None or owner.cache is not value:raise ValueError('Actual cache has no live tracked owner')
        return owner
    def _remember(self,owner):
        self._owners[id(owner.cache)]=owner;self.remember_cache_history(owner.cache,owner.history);return owner
    def bind(self,cell):
        canonical=contract.canonical_cell(cell)
        if self.current is not None:self.finish()
        self.current=canonical;self.cursor=0;self._nodes={};self._root=None;self._reset_registry()
    def finish(self):
        if self.current and any(not r['conditional_on_no_previous_EOS'] for r in self.current['calls'][self.cursor:]):raise ValueError('Missing mandatory call')
        self.current=None;self._nodes={};self._root=None;self.rows.clear();self._reset_registry()
    def abort_cell(self):
        # Evidence is already streamed; release failed native ancestry without
        # pretending skipped mandatory calls completed.
        self.current=None;self._nodes.clear();self._root=None;self._active_capture=None;self.rows.clear();self._reset_registry()
    def active_capture_identity(self,incoming_cache):
        if self._active_capture is None or self._active_capture[1] is not incoming_cache:
            raise ValueError('Capture did not observe the actual active native input cache')
        call=self._active_capture[0];provenance=contract.source_provenance(self.current)
        if call['call_id']!=provenance['call_id'] or call['label']!='B':raise ValueError('Not the frozen source B call')
        return provenance
    def completed_capture_identity(self,owner_or_cache):
        provenance=contract.source_provenance(self.current)
        owner=self.owner_of(owner_or_cache)
        if self._nodes.get(provenance['call_id']) is not owner:
            raise ValueError('Capture result is not the actual frozen B producer')
        node=self.ancestry.inspect(owner)
        if node.purpose!='B' or node.branch!='prefill' or node.origin!='successful_native_output' or contract.digest(list(node.token_history))!=provenance['history_ids_sha256']:
            raise ValueError('Captured B output has changed actual ancestry')
        return provenance
    def _branch(self,purpose):
        if purpose.startswith('candidate_'):return 'candidate:'+purpose.removeprefix('candidate_').rsplit('_',1)[0] if purpose.rsplit('_',1)[-1].isdigit() else 'candidate:'+purpose.removeprefix('candidate_')
        if purpose.startswith('greedy'):return 'greedy'
        if purpose in ('Q','private_Q_continuation'):return 'Q_from_owned_pre_Q_clone'
        return 'prefill'
    def clone_owner(self,source,purpose,branch=None,raw_cache=None):
        source=self.owner_of(source);branch=branch or self._branch(purpose);start=time.monotonic();cpu=time.process_time()
        def clone_callback(parent,_branch,_purpose):
            cache=self.evidence.clone_cache_checked(parent.cache,self.torch) if raw_cache is None else raw_cache
            before,tensors=self.evidence.cache_snapshot(parent.cache,self.torch);after,copied=self.evidence.cache_snapshot(cache,self.torch)
            ptrs={x.untyped_storage().data_ptr() for x in tensors.values() if x.numel()}
            if before!=after or any(x.numel() and x.untyped_storage().data_ptr() in ptrs for x in copied.values()):raise ValueError('Actual clone equality/nonalias failed')
            owner=self._remember(NativeOwner(cache,parent.history,clone_parent=parent,clone_purpose=purpose))
            return VerifiedClone(owner,cache,0,parent.history,True,True)
        with self.installed_context():clone=self.ancestry.verified_clone(source,expected_tokens=source.history,branch=branch,purpose=purpose,clone_callback=clone_callback)
        self.cost_event({'kind':'verified_complete_cache_copy','purpose':purpose,'wall_seconds':time.monotonic()-start,'CPU_seconds':time.process_time()-cpu,
            'bytes':sum(t.numel()*t.element_size() for t in self.evidence.cache_snapshot(clone.cache,self.torch)[1].values()),'extra_reconstructed_clone_per_continuation':True})
        return clone.owner
    def register_pre_q(self,value):
        planned=self.current;producer=planned['pre_Q_producer']
        owner=value if isinstance(value,NativeOwner) else self._owners.get(id(value))
        if owner is None:
            if producer.endswith('assembly'):raise ValueError('Derived Hctx cache must be explicitly verified before preQ registration')
            owner=self.clone_owner(self._nodes[producer],'source_pre_Q_clone',raw_cache=value)
        expected=next(r for r in contract.recovered_contexts() if (r['pair_id'],r['variant'])==(planned['pair_id'],planned['variant']))
        if owner.history!=tuple(expected['A_ids']+expected['B_ids']):raise ValueError('Wrong preQ history')
        self._nodes[planned['cell_id']+'.pre_Q']=owner;return owner
    def register_hctx(self,cache,trace,source):
        """Explicitly verify a non-forward assembly; never fake native output."""
        if self.current is None or self.current['arm']!='Hctx32':raise ValueError('No Hctx cell bound')
        provenance=contract.validate_hctx_source(self.current,source.A,source.B,source.provenance)
        if not contract._exact_value(source.manifest.get('capture_provenance'),provenance) or not contract._exact_value(trace.get('capture_provenance'),provenance):
            raise ValueError('Source capture provenance disagrees with frozen R/A1 producer')
        trace=dict(trace);seam=trace.pop('fresh_seam_owner')
        context=next(r for r in contract.recovered_contexts() if (r['pair_id'],r['variant'])==(self.current['pair_id'],self.current['variant']))
        expected=tuple(context['A_ids']+context['B_ids']);owner=self._remember(NativeOwner(cache,expected))
        assembly=DerivedCache(owner,cache,0,expected,trace['complete_cache'],trace)
        def verify(parent,derived,history,branch,purpose):
            if parent is not seam or parent is not self._nodes[next(r['call_id'] for r in self.current['calls'] if r['label']=='B_seam')]:raise ValueError('Wrong actual fresh seam parent')
            if (trace['history_ids']!=list(expected) or trace['width']!=32 or trace['suffix_range']!=[32,len(context['B_ids'])] or
                trace['source_history_ids']!=list(source.A+source.B) or trace['fresh_seam_applications']!=1 or trace['extra_source_model_calls']!=0 or trace['extra_conv_boundary_repair'] is not False):raise ValueError('Wrong assembly contract')
            with self.installed_context():
                desc,tensors=self.evidence.cache_snapshot(cache,self.torch)
                if desc!=trace['complete_cache'] or cache.get_seq_length()!=len(expected) or any(not bool(self.torch.isfinite(t).all()) for t in tensors.values()):raise ValueError('Derived complete cache changed/nonfinite')
                parent_tensors=self.evidence.cache_snapshot(parent.cache,self.torch)[1]
                source_tensors=self.evidence.cache_snapshot(source.cache,self.torch)[1]
                pointers={t.untyped_storage().data_ptr() for t in list(parent_tensors.values())+list(source_tensors.values()) if t.numel()}
                if any(t.numel() and t.untyped_storage().data_ptr() in pointers for t in tensors.values()):raise ValueError('Derived cache aliases parent/source')
                for actual,fresh in zip(cache.layers,parent.cache.layers):
                    if hasattr(fresh,'keys'):
                        n=len(parent.history)
                        if not self.torch.equal(actual.keys[...,:n,:],fresh.keys) or not self.torch.equal(actual.values[...,:n,:],fresh.values):raise ValueError('Fresh prefix/seam KV changed')
            return DerivedVerification(parent,parent.cache,parent.version,owner,cache,owner.version,history,branch,purpose,
                True,True,True,contract.digest(trace),'native_snapshot_prefix_and_adapter_trace')
        node=self.ancestry.register_derived(seam,assembly,expected_history=expected,branch='prefill',verifier_callback=verify)
        self._nodes[self.current['pre_Q_producer']]=owner
        self.cost_event({'kind':'verified_derived_cache','node':node.serial,'trace_sha256':contract.digest(trace),
            'model_calls_added':0,'history_ids':list(expected),'numerical_parity_claim':False})
        return owner
    def checked_forward(self,ids,parent=None,*,branch='prefill',purpose):
        if self.current is None or self.cursor>=len(self.current['calls']):raise ValueError('Unplanned native call')
        contract.canonical_cell(self.current)  # Detect accidental mutation after bind.
        p=self.current['calls'][self.cursor];ids=tuple(ids)
        if (p['label']!=purpose or p['branch_id']!=branch or len(ids)!=p['network_tokens'] or
            (p['input_ids'] is not None and ids!=tuple(p['input_ids'])) or
            (p['input_ids'] is None and (len(ids)!=1 or ids[0]==contract.EOS))):raise ValueError('Native call differs from frozen plan')
        if self.calls+1>308 or self.tokens+len(ids)>4840:raise ValueError('Call/token cap')
        prior=();candidate=None;permit=None
        if p['cache_parent'] is not None:
            expected=self._nodes[p['cache_parent']];supplied=self.owner_of(parent)
            if supplied.clone_parent is expected and supplied.clone_purpose==purpose:
                candidate=supplied
            elif supplied is expected:candidate=self.clone_owner(expected,purpose,branch)
            else:raise ValueError('Wrong actual planned parent cache')
            prior=expected.history
            permit=self.ancestry.claim_for_forward(candidate,parent_owner=expected,expected_tokens=prior,appended_tokens=ids,branch=branch,purpose=purpose)
        elif parent is not None:raise ValueError('A must start empty')
        if len(prior)!=p['absolute_start']:raise ValueError('Wrong exact native history length')
        self.cursor+=1;self.calls+=1;self.tokens+=len(ids)
        row=dict(kind='root_call',call_id=p['call_id'],purpose=purpose,history_ids=list(prior),input_ids=list(ids),absolute_start=len(prior),
                 model_invoked=False,model_returned=False,status='started',reconstruction=contract.RECONSTRUCTION,
                 invocation_semantics='Root __call__ issued; not proof of kernel completion')
        self.cost_event(row);start=time.monotonic();cpu=time.process_time();output=None
        try:
            with self.installed_context():
                with self.evidence.MaterializedMaskCapture(self.model,self.torch,prior,ids) as masks:
                    row['model_invoked']=True;self.cost_event(row)
                    self._active_capture=(p,None if candidate is None else candidate.cache)
                    output=self.model(input_ids=self.torch.tensor([ids],dtype=self.torch.long),
                        past_key_values=None if candidate is None else candidate.cache,
                        attention_mask=self.torch.ones(1,len(prior)+len(ids),dtype=self.torch.long),
                        position_ids=self.torch.arange(len(prior),len(prior)+len(ids)).unsqueeze(0),use_cache=True,logits_to_keep=1)
                    self._active_capture=None
                    row['model_returned']=True
                cache=output.past_key_values;desc,tensors=self.evidence.cache_snapshot(cache,self.torch)
                if cache.get_seq_length()!=len(prior)+len(ids) or any(not bool(self.torch.isfinite(t).all()) for t in tensors.values()):raise ValueError('Native cache length/finite check failed')
                if output.logits.dtype!=self.torch.float32 or not bool(self.torch.isfinite(output.logits).all()):raise ValueError('Native logits not finite FP32')
                owner=NativeOwner(cache,prior+ids,logits=output.logits) if candidate is None else candidate
                if candidate is not None:owner.cache=cache;owner.history=prior+ids;owner.version+=1;owner.logits=output.logits;owner.clone_parent=None;owner.clone_purpose=None
                self._remember(owner);tracked=TrackedNativeOutput(owner,cache,owner.version,owner.history,True,True,True)
                node=self.ancestry.register_native_root(tracked,branch=branch,purpose=purpose) if permit is None else self.ancestry.register_native_output(permit,tracked)
                if self._root is None:self._root=owner
                self._nodes[p['call_id']]=owner
                # Avoid retaining every transient immutable clone in the plan index.
                needed={r['cache_parent'] for r in self.current['calls'][self.cursor:]}
                needed.add(self.current['pre_Q_producer']);needed.add(p['call_id'])
                for label in tuple(self._nodes):
                    if label not in needed:self._nodes.pop(label)
                row.update(status='completed',masks=masks.summary(),cache_descriptor=desc,actual_ancestry_serial=node.serial)
                if self.raw_logit_sink is not None:self.raw_logit_sink(p['call_id'],output.logits)
                # Prefill vectors are archived but never scored. Production
                # need not retain them inside every immutable cache owner.
                if self.raw_logit_sink is not None and branch=='prefill':owner.logits=None
                return owner
        except BaseException as exc:
            row.update(status='failed',exception=repr(exc))
            if permit is not None:
                try:self.ancestry.record_native_failure(permit)
                except Exception:pass
            raise
        finally:
            self._active_capture=None
            row.update(wall_seconds=time.monotonic()-start,CPU_seconds=time.process_time()-cpu)
            primary=sys.exc_info()[1]
            try:self.cost_event(row)
            except BaseException as evidence_error:
                if primary is None:raise
                if len(self.secondary_evidence_failures)>=16:self.secondary_evidence_failures.pop(0)
                self.secondary_evidence_failures.append({'type':type(evidence_error).__name__,'message':str(evidence_error),'primary_preserved':repr(primary)})
            # Full data goes to the caller-owned sink. Retain bounded scalar totals.
            self.rows.append({k:row[k] for k in ('call_id','purpose','status','model_invoked','model_returned','wall_seconds','CPU_seconds')})


class TorchScoreBackend:
    """Real FP32 scalar arithmetic plus the planned checked native caller."""
    def __init__(self,calls,decode):self.calls=calls;self.torch=calls.torch;self.decode=decode
    def cache(self,out):return out
    def logits(self,out):return out.logits
    def signature(self,value):
        owner,logits=value
        with self.calls.installed_context():return contract.digest(self.calls.evidence.cache_snapshot(owner.cache,self.torch)[0]),self.calls.support.tensor_digest(logits.contiguous())
    def clone_owned(self,owner,purpose):
        # First candidate/greedy step's actual planned label includes _1.
        label=purpose+'_1' if purpose.startswith('candidate_') or purpose=='greedy' else purpose
        return self.calls.clone_owner(owner,label)
    def assert_clone(self,source,clone):
        with self.calls.installed_context():return self.calls.evidence.cache_snapshot(source.cache,self.torch)[0]==self.calls.evidence.cache_snapshot(clone.cache,self.torch)[0] and source.cache is not clone.cache
    def _vector(self,logits):
        if logits.dtype!=self.torch.float32 or logits.numel()!=contract.VOCAB or not bool(self.torch.isfinite(logits).all()):raise ValueError('Scoring requires original-vocabulary finite FP32 logits')
        return logits.reshape(-1)
    def logprob_fp32(self,logits,token):
        with self.calls.installed_context():return float(self.torch.log_softmax(self._vector(logits),-1,dtype=self.torch.float32)[token])
    def sum_fp32(self,values):
        with self.calls.installed_context():return float(self.torch.tensor(values,dtype=self.torch.float32).sum(dtype=self.torch.float32))
    def margin_fp32(self,gold,other):
        with self.calls.installed_context():return float(self.torch.tensor(gold,dtype=self.torch.float32)-self.torch.tensor(other,dtype=self.torch.float32))
    def argmax_with_gap(self,logits):
        with self.calls.installed_context():
            vector=self._vector(logits);top=self.torch.topk(vector,2).values
            return int(self.torch.argmax(vector)),float(top[0]-top[1])
    def forward(self,ids,cache,purpose,start):
        if len(cache.history)!=start:raise ValueError('Scoring position differs')
        return self.calls.checked_forward(ids,cache,branch=self.calls._branch(purpose),purpose=purpose)
