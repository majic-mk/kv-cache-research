"""Run the read-only hash/parser verifier on the fresh reviewed attempt."""
from pathlib import Path
import verify_restored_assets as verification

if __name__ == "__main__":
    verification.HERE = Path(__file__).resolve().parent / "attempt02_reviewed_20261004"
    verification.OUT = verification.ROOT / "outputs/model_assets_recovery_20261004_reviewed"
    verification.DEST = verification.OUT / "Qwen3.5-2B-derived-text"
    verification.main()
