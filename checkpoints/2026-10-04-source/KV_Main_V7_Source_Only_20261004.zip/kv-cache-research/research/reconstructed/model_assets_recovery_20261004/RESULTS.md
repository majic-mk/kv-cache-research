# Exact pinned text-model assets restored

**PASS, 2026-10-04 08:44 UTC.** The reviewed fresh acquisition reproduced the
historical text-only derivative byte-for-byte. The successful asset directory is:

`outputs/model_assets_recovery_20261004_reviewed/Qwen3.5-2B-derived-text`

This is asset restoration only. No model construction, pretrained loading,
forward, GPU execution or new research result is part of this work.

## Verified weights

- Official model: `Qwen/Qwen3.5-2B`
- Immutable revision: `15852e8c16360a2fea060d615a32b45270f8a8fc`
- Complete official source read and hashed: **4,548,221,488 bytes**
- Complete source SHA-256:
  `aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`
- Source header SHA-256:
  `ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d`
- Text-only derivative: **3,763,696,896 bytes**
- Derived SHA-256, equal to the recovered historical value:
  `42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`
- **320 tensors: 284 BF16 plus 36 F32**, retaining original names, shapes,
  stored dtypes and exact raw payloads

The recovered original `project_bytes.py` streamed every original source byte,
including discarded vision/MTP payloads. Its independent disk verifier reread
the derivative and compared every retained tensor to the stream-side per-tensor
hash. The historical whole-derivative SHA was required before atomic rename to
`model.safetensors` and creation of `COMPLETE.json`.

The official safetensors parser subsequently confirmed all 320 names, shapes,
dtypes and metadata without materializing payloads. This separate verifier also
rehashed the complete file to the historical SHA and rehashed all five small
assets. It imported neither Torch nor Transformers.

## Pinned config and tokenizer

The loader directory includes unchanged original pinned files, verified against
both recovered digests and official pinned Git blob/LFS identities:

- `config.json`:
  `ed1c1723241f23f7f4e23430759cbd7dcfb4103cbdfe052bfe7626b57c2615b4`
- `tokenizer_config.json`:
  `49e2b6e395f959f077f1e992b338919c0d4a9732fc6e613995e06557f843500c`
- `chat_template.jinja`:
  `273d8e0e683b885071fb17e08d71e5f2a5ddfb5309756181681de4f5a1822d80`
- `tokenizer.json`:
  `5f9e4d4901a92b997e463c1f46055088b6cca5ca61a6522d1b9f64c4bb81cb42`

The original full source index is preserved outside the derivative loader
directory. The derivative is an ordinary single-file safetensors artifact with
explicit derivative provenance in `DERIVED_ARTIFACT.json`.

## Reviewed network access and preserved failed attempt

The first ordinary request failed with an HTTPS tunnel 403 before source bytes
were available; its polling command separately reported approval-review
cancellation. That attempt's report, markers, log and preallocated `.partial`
remain unchanged under the original recovery paths.

One explicit `require_escalated` HEAD request then succeeded at the **same exact
official URL**, following the ordinary HTTPS redirect to `us.aws.cdn.hf.co`.
After a separately reviewed full-GET request was admitted, the new attempt used
a fresh output directory and completed with the hashes above. No alternative
endpoint, proxy, credentials, security setting change, bypass or deletion was
used. The old partial is still unverified and must not be used.

Successful request target:
https://huggingface.co/Qwen/Qwen3.5-2B/resolve/15852e8c16360a2fea060d615a32b45270f8a8fc/model.safetensors-00001-of-00001.safetensors?download=true

## Bounds and tests

- Original byte projector: **14/14 synthetic tests passed**
- Recovery header replay wrapper: **4/4 synthetic tests passed**
- New Python scripts compile
- Successful stream plus independent tensor verification: **132.82 seconds**
- Stream process peak RSS: **29,040,640 bytes**, under a 1 GiB virtual-memory cap
- Final parser/hash verification: **2.50 seconds**, peak RSS **36,208,640 bytes**
- Free disk at successful completion: **22,345,150,464 bytes**, above the
  unchanged 5,000,000,000-byte reserve
- 4 MiB stream chunks, 60-second socket timeout and 30-minute total acquisition
  limit; only one successful full source stream for the reviewed attempt
- No complete source shard retained; no 8B asset download or duplicate verified
  weight copy; the earlier empty preallocation remains for audit
- Existing source, research reports and model/protocol implementation unchanged;
  no commit, push or remote mutation

## Evidence locations

- Current completion: `attempt02_reviewed_20261004/COMPLETE.json`
- Current parser check: `attempt02_reviewed_20261004/official_parser_verification.json`
- Current metadata: `attempt02_reviewed_20261004/metadata_verification.json`
- Executed source hashes: `attempt02_reviewed_20261004/execution_source_hashes.json`
- Successful request/progress log: `reviewed_acquisition.log`
- Approved HEAD receipt: `escalated_head_probe.json`
- Preserved first-attempt report: `README.md`, `FAILED.json`, `stream_started.json`
- Ignored exact source header, projection plan, all-source-tensor stream manifest
  and independent per-tensor disk verification:
  `outputs/model_assets_recovery_20261004_reviewed/`

These checks restore asset provenance and storage readiness. They do not
establish a model's numerical qualification, competence, runtime fit or any
scientific benefit.
