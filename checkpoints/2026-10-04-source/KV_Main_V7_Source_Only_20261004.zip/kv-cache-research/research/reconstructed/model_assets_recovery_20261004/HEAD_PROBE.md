# Approved read-only network probe, 2026-10-04 08:40 UTC

One reviewed `require_escalated` HEAD request to the exact originally blocked
pinned official URL succeeded. It followed the ordinary HTTPS 302 redirect from
`huggingface.co` to `us.aws.cdn.hf.co` and received HTTP 200, Content-Length
4,548,221,488, and identity content encoding. No response body bytes were read.
No credentials, security setting changes, endpoint substitution or full-weight
retry were used.

Exact target:
https://huggingface.co/Qwen/Qwen3.5-2B/resolve/15852e8c16360a2fea060d615a32b45270f8a8fc/model.safetensors-00001-of-00001.safetensors?download=true

Receipt: `escalated_head_probe.json`.

This establishes that the supported reviewed network path can access the exact
source for HEAD. It does not establish successful GET/streaming, restoration,
source byte identity, or authorization for another weight-acquisition attempt.
The earlier preallocated partial remains unverified, unchanged, and unsuitable
for loading. The earlier blocked-attempt report and manifest are preserved.
