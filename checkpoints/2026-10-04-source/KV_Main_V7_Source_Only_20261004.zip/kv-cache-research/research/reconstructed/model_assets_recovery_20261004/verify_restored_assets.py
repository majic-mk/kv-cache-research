"""Read-only official safetensors parser and exact asset identity checks.

No tensor payload materialization, model construction or model execution.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import resource
import struct
import sys
import time

from safetensors import safe_open

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / "outputs/model_assets_recovery_20261004"
DEST = OUT / "Qwen3.5-2B-derived-text"
EXPECTED = "42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c"


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(4 * 1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def main():
    started = time.monotonic()
    result = json.loads((HERE / "COMPLETE.json").read_text())
    assert result["derived_sha256"] == EXPECTED
    path = DEST / "model.safetensors"
    assert path.stat().st_size == 3763696896
    assert sha(path) == EXPECTED
    with path.open("rb") as f:
        size = struct.unpack("<Q", f.read(8))[0]
        assert size == 41528
        header = json.loads(f.read(size))
    expected = set(header) - {"__metadata__"}
    assert len(expected) == 320
    dtypes = Counter()
    with safe_open(str(path), framework="np") as handle:
        assert set(handle.keys()) == expected
        assert handle.metadata() == header["__metadata__"]
        for name in handle.keys():
            tensor = handle.get_slice(name)
            assert tensor.get_shape() == header[name]["shape"]
            assert tensor.get_dtype() == header[name]["dtype"]
            dtypes[tensor.get_dtype()] += 1
    assert dtypes == {"BF16": 284, "F32": 36}
    pre = json.loads((HERE / "metadata_verification.json").read_text())
    for name, record in pre["files"].items():
        actual = ROOT / record["local_path"]
        assert actual.stat().st_size == record["bytes"]
        assert sha(actual) == record["sha256"]
    cfg = json.loads((DEST / "config.json").read_text())
    assert cfg["model_type"] == "qwen3_5"
    assert cfg["text_config"]["num_hidden_layers"] == 24
    assert cfg["text_config"]["hidden_size"] == 2048
    assert not (DEST / "model.safetensors.index.json").exists()
    assert not any(module == "torch" or module == "transformers" for module in sys.modules)
    verification = {"status": "pass", "verification": "independent full-file hash and official safetensors parser",
                    "derived_sha256": EXPECTED, "verified_tensor_count": len(expected),
                    "dtype_counts": dict(dtypes), "small_files_rehashed": len(pre["files"]),
                    "full_index_separate_from_loader_directory": True,
                    "tensor_payload_materialized": False, "model_constructed": False,
                    "model_forward_executed": False, "torch_or_transformers_imported": False,
                    "elapsed_seconds": time.monotonic() - started,
                    "peak_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024}
    with (HERE / "official_parser_verification.json").open("x") as f:
        json.dump(verification, f, indent=2)
        f.write("\n")
    print(json.dumps(verification, indent=2))


if __name__ == "__main__":
    main()
