# Pinned text-model asset recovery, 2026-10-04

## Current status: weight acquisition blocked

The exact pinned configuration, tokenizer, tokenizer configuration, chat
template and original source index were downloaded from official Hugging Face
and reverified. **The text weights have not been restored.**

The one full-source request failed before source header/weight bytes were
available, with `URLError: Tunnel connection failed: 403 Forbidden`. Polling the
underlying command subsequently returned `automatic approval review was
cancelled`. No alternative network route, automatic retry, authentication,
security change or deletion was attempted. The request is paused for the parent
to review this specific blocker.

The retained file
`outputs/model_assets_recovery_20261004/Qwen3.5-2B-derived-text/model.safetensors.partial`
is only an exact-size preallocation, **not verified model weights**. It must not
be loaded or interpreted as a restored asset. No `model.safetensors` or
`COMPLETE.json` exists for this attempt. `FAILED.json` records the terminal
failure. Free disk after failure was 26,492,035,072 bytes, above the unchanged
5,000,000,000-byte reserve.

## Frozen identities

- Official repository: `Qwen/Qwen3.5-2B`
- Revision: `15852e8c16360a2fea060d615a32b45270f8a8fc`
- Source shard: `model.safetensors-00001-of-00001.safetensors`
- Source length: 4,548,221,488 bytes
- Official source SHA-256:
  `aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`
- Required source header SHA-256:
  `ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d`
- Expected prior derivative length: 3,763,696,896 bytes
- Required prior derivative SHA-256, **not yet reproduced**:
  `42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`
- Expected selection: all and only 320 `model.language_model.*` tensors,
  retaining 284 BF16 plus 36 F32 original payloads

The official immutable API returned the exact revision, public/ungated status,
source length and source LFS hash. The four small loader files match their
recovered SHA-256 records and current official pinned Git blob/LFS identities.
The source index is kept outside the loader directory. See
`metadata_verification.json` for exact file identities and origin URLs.

## Recovery route and checks

The recovered original projector and independent disk verifier are unchanged
and pass their original recorded file hashes. The old preflight is not executed:
it would construct a meta-device model, outside this asset-only recovery scope.
The recovered admission review establishes the exact text prefix selection.

The wrapper is designed to use one full official source request, inspect and
replay its 76,648-byte header to the unchanged projector, and stream/hash all
original bytes while retaining only selected text payloads. The complete source
hash, selected tensor hashes, independent derivative reread, and exact historical
derivative hash must all pass before success is declared. This reconstruction
does not assume byte identity in advance.

- Original projector synthetic tests: **14/14 passed**
- New header replay/short-read/corruption tests: **4/4 passed**
- New script compilation: passed for the restoration wrapper
- Streaming process: 1 GiB virtual-memory cap, 4 MiB read chunks, 60-second
  socket timeout, 30-minute outer/internal deadline, exact derivative
  preallocation and sampled disk floor checks
- Official parser check script is prepared but **not run**, because verified
  weights do not exist
- No model construction or model forward, GPU, tensor conversion, full-source
  local copy, 8B download, dependency install, deletion or remote mutation

## Evidence

This directory preserves new scripts, public model API metadata, test logs,
metadata provenance, request start/failure markers and the acquisition log.
All weight-sized material and projection raw manifests belong under ignored
`outputs/model_assets_recovery_20261004/`. Previous research reports remain
unchanged. This result establishes restored small-file provenance and tested
recovery code only; it does not establish restored weights or research readiness.
