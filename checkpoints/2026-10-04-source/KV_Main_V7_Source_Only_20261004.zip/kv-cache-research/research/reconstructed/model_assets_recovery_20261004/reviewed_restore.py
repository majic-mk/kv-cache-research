"""Fresh, explicitly reviewed acquisition attempt; preserve the failed attempt.

Reuses the tested recovery implementation unchanged and hash-verified small
assets locally. The only network action is its same pinned official full GET.
"""
import json
from pathlib import Path
import shutil
import sys

import restore_assets as recovery

ORIGINAL_REPORT = Path(__file__).resolve().parent
REPORT = ORIGINAL_REPORT / "attempt02_reviewed_20261004"
OUT = recovery.ROOT / "outputs/model_assets_recovery_20261004_reviewed"
DEST = OUT / "Qwen3.5-2B-derived-text"


def prepare_locally():
    assert not REPORT.exists() and not OUT.exists(), "Refuse duplicate acquisition attempt"
    assert shutil.disk_usage(recovery.ROOT).free - recovery.DERIVED_SIZE - 20_000_000 - recovery.GUARD >= recovery.FLOOR
    REPORT.mkdir()
    DEST.mkdir(parents=True)
    pre = json.loads((ORIGINAL_REPORT / "metadata_verification.json").read_text())
    assert pre["model"] == recovery.MODEL and pre["revision"] == recovery.REV
    for name, record in pre["files"].items():
        source = recovery.ROOT / record["local_path"]
        assert source.stat().st_size == record["bytes"]
        assert recovery.hash_file(source) == record["sha256"]
        target = (OUT if name == "model.safetensors.index.json" else DEST) / name
        with source.open("rb") as inp, target.open("xb") as out:
            shutil.copyfileobj(inp, out, recovery.CHUNK)
        assert recovery.hash_file(target) == record["sha256"]
        record["prior_verified_local_path"] = record["local_path"]
        record["local_path"] = str(target.relative_to(recovery.ROOT))
        record["acquisition_this_attempt"] = "Local copy of exact hash-verified official pinned asset"
    pre["attempt"] = "attempt02_reviewed_20261004"
    pre["prior_failed_attempt_preserved"] = True
    pre["approved_head_probe_receipt"] = str((ORIGINAL_REPORT / "escalated_head_probe.json").relative_to(recovery.ROOT))
    pre["free_disk_bytes"] = shutil.disk_usage(OUT).free
    recovery.write_json(REPORT / "metadata_verification.json", pre)
    for name in ["synthetic_tests.log", "wrapper_tests.log"]:
        with (ORIGINAL_REPORT / name).open("rb") as inp, (REPORT / name).open("xb") as out:
            shutil.copyfileobj(inp, out)
    recovery.write_json(REPORT / "execution_source_hashes.json", {
        "requested_sandbox_permissions": "require_escalated",
        "source_hashes": {str(p.relative_to(recovery.ROOT)): recovery.hash_file(p)
                          for p in [Path(__file__), ORIGINAL_REPORT / "restore_assets.py",
                                    recovery.OLD / "project_bytes.py", recovery.OLD / "verify_projection.py"]},
        "prior_partial_preserved": "outputs/model_assets_recovery_20261004/Qwen3.5-2B-derived-text/model.safetensors.partial",
        "fresh_output_directory": str(OUT.relative_to(recovery.ROOT)),
        "credentials_supplied": False, "security_settings_changed": False})


if __name__ == "__main__":
    assert len(sys.argv) == 1
    prepare_locally()
    recovery.HERE = REPORT
    recovery.OUT = OUT
    recovery.DEST = DEST
    recovery.stream()
