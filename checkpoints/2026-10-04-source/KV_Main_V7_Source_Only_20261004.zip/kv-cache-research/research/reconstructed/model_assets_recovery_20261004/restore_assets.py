"""Recreate the frozen text-only asset with the recovered byte projector.

No model construction, tensor decoding, dtype cast, forward, auth, deletion or
installation. Metadata and source use public pinned official Hugging Face URLs.
One full source request is projected, fully hashed, and independently reread.
"""
import argparse
import collections
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import resource
import shutil
import struct
import sys
import time
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / "research/diagnostics/text_only_asset_projection"
OUT = ROOT / "outputs/model_assets_recovery_20261004"
DEST = OUT / "Qwen3.5-2B-derived-text"
sys.path.insert(0, str(OLD))
from project_bytes import digest, make_plan, project
from verify_projection import verify

MODEL = "Qwen/Qwen3.5-2B"
REV = "15852e8c16360a2fea060d615a32b45270f8a8fc"
SHARD = "model.safetensors-00001-of-00001.safetensors"
BASE = f"https://huggingface.co/{MODEL}/resolve/{REV}/"
SOURCE_SHA = "aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1"
SOURCE_SIZE = 4548221488
HEADER_SHA = "ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d"
HEADER_SIZE = 76648
DERIVED_SHA = "42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c"
DERIVED_SIZE = 3763696896
FLOOR = 5_000_000_000
GUARD = 128 * 1024 * 1024
CHUNK = 4 * 1024 * 1024
SECONDS = 1800


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(path, value):
    with Path(path).open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def hash_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while data := f.read(CHUNK):
            h.update(data)
    return h.hexdigest()


def request(url):
    return urllib.request.urlopen(urllib.request.Request(url, headers={
        "Accept-Encoding": "identity", "User-Agent": "official-pinned-text-asset-recovery/1"
    }), timeout=60)


def check_response(response, expected_size=None):
    assert response.status == 200, "Refuse partial or unexpected HTTP status"
    assert response.url.startswith("https://"), "Refuse HTTPS downgrade"
    assert response.headers.get("Content-Encoding", "identity") == "identity"
    if expected_size is not None and response.headers.get("Content-Length") is not None:
        assert int(response.headers["Content-Length"]) == expected_size


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    DEST.mkdir()
    # Never execute the old preflight: it constructs a meta-device model, which
    # this recovery does not authorize or need. Byte identity is the gate here.
    manifest = json.loads((OLD / "artifact_manifest.json").read_text())
    recovered = {}
    for name, item in manifest["files"].items():
        p = OLD / name
        assert p.stat().st_size == item["bytes"] and hash_file(p) == item["sha256"]
        recovered[name] = item
    api_path = HERE / "model_api.json"
    api = json.loads(api_path.read_text())
    assert api["id"] == MODEL and api["sha"] == REV
    assert api["private"] is False and api["gated"] is False
    siblings = {s["rfilename"]: s for s in api["siblings"]}
    assert siblings[SHARD]["size"] == SOURCE_SIZE
    assert siblings[SHARD]["lfs"]["sha256"] == SOURCE_SHA
    prior = json.loads((ROOT / "research/protocols/hybrid_cpu_quality_v3/tokenizer_provenance.json").read_text())
    assert prior["model_id"] == MODEL and prior["revision"] == REV
    files = {}
    for name in [*prior["files"], "model.safetensors.index.json"]:
        spec = siblings[name]
        assert 0 < spec["size"] < 20_000_000
        url = BASE + name
        with request(url) as r:
            check_response(r, spec["size"])
            data = r.read(spec["size"] + 1)
            host = urllib.parse.urlsplit(r.url).hostname
        assert len(data) == spec["size"]
        sha = digest(data)
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if "lfs" in spec:
            assert sha == spec["lfs"]["sha256"]
        else:
            assert blob == spec["blobId"]
        if name in prior["files"]:
            assert sha == prior["files"][name]["sha256"]
            assert len(data) == prior["files"][name]["bytes"]
        path = (OUT if name.endswith("index.json") else DEST) / name
        with path.open("xb") as f:
            f.write(data)
        assert hash_file(path) == sha
        files[name] = {"source_url": url, "bytes": len(data), "sha256": sha,
                       "official_git_blob_sha1": spec["blobId"], "lfs": spec.get("lfs"),
                       "final_response_host": host, "local_path": str(path.relative_to(ROOT))}
    free = shutil.disk_usage(OUT).free
    assert free - DERIVED_SIZE - GUARD >= FLOOR
    result = {"status": "metadata_verified_no_model_constructed", "utc": now(),
              "model": MODEL, "revision": REV, "public_ungated": True,
              "official_api_url": f"https://huggingface.co/api/models/{MODEL}/revision/{REV}?blobs=true",
              "official_api_sha256": hash_file(api_path), "files": files,
              "recovered_projector_files": recovered, "free_disk_bytes": free,
              "floor_bytes": FLOOR, "guard_bytes": GUARD,
              "expected_derived_sha256": DERIVED_SHA,
              "selection_basis": "Recovered admission review: all and only model.language_model.* (320); exact source/header/derivative hashes required"}
    write_json(HERE / "metadata_verification.json", result)
    print(json.dumps(result, indent=2), flush=True)


class PrefixReader:
    """Replay the inspected header to the unchanged projector, without rerequest."""
    def __init__(self, prefix, rest):
        self.prefix = io.BytesIO(prefix)
        self.rest = rest

    def read(self, n):
        prefix = self.prefix.read(n)
        return prefix if prefix else self.rest.read(n)


def exact_read(response, size):
    parts = bytearray()
    while len(parts) < size:
        data = response.read(size - len(parts))
        assert data, "Truncated source header"
        parts.extend(data)
    return bytes(parts)


def stream():
    pre = json.loads((HERE / "metadata_verification.json").read_text())
    assert pre["expected_derived_sha256"] == DERIVED_SHA
    test_log = (HERE / "synthetic_tests.log").read_text()
    assert "Ran 14 tests" in test_log and test_log.rstrip().endswith("OK")
    wrapper_log = (HERE / "wrapper_tests.log").read_text()
    assert "Ran 4 tests" in wrapper_log and wrapper_log.rstrip().endswith("OK")
    assert not (HERE / "stream_started.json").exists(), "No automatic stream retry"
    assert shutil.disk_usage(OUT).free - DERIVED_SIZE - GUARD >= FLOOR
    partial = DEST / "model.safetensors.partial"
    started = time.monotonic()
    minimum_free = shutil.disk_usage(OUT).free
    url = BASE + SHARD + "?download=true"
    write_json(HERE / "stream_started.json", {"utc": now(), "url": url,
               "source_bytes": SOURCE_SIZE, "source_sha256": SOURCE_SHA,
               "expected_derived_sha256": DERIVED_SHA, "no_automatic_retries": True})

    def budget():
        nonlocal minimum_free
        free = shutil.disk_usage(OUT).free
        minimum_free = min(minimum_free, free)
        assert free >= FLOOR + GUARD // 2, "Disk safety guard crossed"
        assert time.monotonic() - started <= SECONDS, "Acquisition deadline"

    last_report = 0

    def progress(value):
        nonlocal last_report
        if value["source_bytes_read"] - last_report >= 256 * 1024 * 1024:
            last_report = value["source_bytes_read"]
            print(json.dumps({**value, "elapsed_seconds": time.monotonic() - started,
                              "free_disk_bytes": shutil.disk_usage(OUT).free}), flush=True)

    try:
        with partial.open("x+b") as f:
            os.posix_fallocate(f.fileno(), 0, DERIVED_SIZE)
            budget()
            with request(url) as r:
                check_response(r, SOURCE_SIZE)
                assert int(r.headers["Content-Length"]) == SOURCE_SIZE
                host = urllib.parse.urlsplit(r.url).hostname
                prefix = exact_read(r, 8)
                assert struct.unpack("<Q", prefix)[0] == HEADER_SIZE
                raw = exact_read(r, HEADER_SIZE)
                assert digest(raw) == HEADER_SHA
                header = json.loads(raw)
                index = json.loads((OUT / "model.safetensors.index.json").read_text())
                assert set(header) == set(index["weight_map"])
                assert set(index["weight_map"].values()) == {SHARD}
                assert index["metadata"]["total_size"] == SOURCE_SIZE - 8 - HEADER_SIZE
                selected = [name for name in header if name.startswith("model.language_model.")]
                excluded = set(header) - set(selected)
                assert all(n.startswith("mtp.") or n.startswith("model.visual.") for n in excluded)
                assert len(header) == 632 and len(selected) == 320
                dtypes = collections.Counter(header[n]["dtype"] for n in selected)
                assert dtypes == {"BF16": 284, "F32": 36}
                assert sum(math.prod(header[n]["shape"]) for n in selected) == 1881825088
                plan = make_plan(raw, SOURCE_SIZE, selected, SOURCE_SHA)
                assert plan["derived_size"] == DERIVED_SIZE
                assert plan["derived_payload_bytes"] == 3763655360
                assert len(bytes.fromhex(plan["derived_header_hex"])) == 41528
                with (OUT / "source_header.json").open("xb") as h:
                    h.write(raw)
                write_json(OUT / "projection_plan.json", plan)
                result = project(PrefixReader(prefix + raw, r), f, plan,
                                 chunk_bytes=CHUNK, check_budget=budget, progress=progress,
                                 deadline=started + SECONDS)
            os.fsync(f.fileno())
        result.update(utc_finished=now(), source_url=url, official_revision=REV,
                      final_response_host=host, elapsed_stream_seconds=time.monotonic() - started,
                      minimum_free_disk_bytes=minimum_free)
        write_json(OUT / "stream_manifest.json", result)
        disk = verify(partial, result)
        assert disk["derived_sha256"] == DERIVED_SHA, "Historical derivative identity not reproduced"
        assert disk["derived_bytes"] == DERIVED_SIZE and disk["verified_tensor_count"] == 320
        budget()
        os.rename(partial, DEST / "model.safetensors")
        write_json(OUT / "disk_verification.json", disk)
        write_json(DEST / "DERIVED_ARTIFACT.json", {
            "artifact_kind": "derived_lossless_text_tensor_subset_not_original_checkpoint_file",
            "model": MODEL, "revision": REV, "source_sha256": SOURCE_SHA,
            "source_bytes": SOURCE_SIZE, "historical_derived_sha256_match": True,
            "derived_file": "model.safetensors", **disk,
            "original_pinned_config_tokenizer": {n: v for n, v in pre["files"].items() if n != "model.safetensors.index.json"},
            "model_constructed": False, "model_forward_executed": False})
        summary = {"status": "verified_byte_identical_restoration", "utc": now(),
                   "artifact": str((DEST / "model.safetensors").relative_to(ROOT)),
                   "source_sha256": SOURCE_SHA, "source_bytes": SOURCE_SIZE,
                   "source_header_sha256": HEADER_SHA, "derived_sha256": disk["derived_sha256"],
                   "derived_bytes": disk["derived_bytes"], "verified_tensors": 320,
                   "dtype_counts": dict(dtypes), "historical_derived_sha256_match": True,
                   "free_disk_after": shutil.disk_usage(OUT).free,
                   "minimum_free_disk_bytes": minimum_free,
                   "total_seconds": time.monotonic() - started,
                   "peak_RSS_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                   "full_source_file_written": False, "weight_source_requests": 1,
                   "model_constructed": False, "model_forward_executed": False}
        write_json(HERE / "COMPLETE.json", summary)
        print(json.dumps(summary, indent=2), flush=True)
    except BaseException as error:
        write_json(HERE / "FAILED.json", {"status": "unverified_do_not_load", "utc": now(),
                   "error_type": type(error).__name__, "error": str(error),
                   "retained_partial": str(partial.relative_to(ROOT)),
                   "minimum_free_disk_bytes": minimum_free})
        raise


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=["prepare", "stream"])
    args = p.parse_args()
    (prepare if args.stage == "prepare" else stream)()
