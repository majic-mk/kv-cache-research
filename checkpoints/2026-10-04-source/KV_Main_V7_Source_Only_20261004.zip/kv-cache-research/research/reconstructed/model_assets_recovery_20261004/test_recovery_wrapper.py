import io
import struct
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from restore_assets import PrefixReader, exact_read
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'diagnostics/text_only_asset_projection'))
from test_projection import fixture, ShortReads
from project_bytes import make_plan, project, digest

class RecoveryWrapperTests(unittest.TestCase):
    def test_header_replay_is_identical_for_all_chunk_sizes(self):
        raw, source, records = fixture()
        header_end = 8 + len(raw)
        for size in [1, 2, 3, 7, 4096]:
            out = io.BytesIO()
            plan = make_plan(raw, len(source), ['text.a', 'text.z'], digest(source))
            a = project(io.BytesIO(source), out, plan, chunk_bytes=size)
            expected = out.getvalue()
            replay = PrefixReader(source[:header_end], ShortReads(source[header_end:]))
            out = io.BytesIO()
            b = project(replay, out, plan, chunk_bytes=size)
            self.assertEqual(expected, out.getvalue())
            self.assertEqual(a, b)
    def test_header_read_short_reads(self):
        self.assertEqual(exact_read(ShortReads(b'abcdef'), 6), b'abcdef')
    def test_header_read_truncation(self):
        with self.assertRaisesRegex(AssertionError, 'Truncated'):
            exact_read(ShortReads(b'a'), 2)
    def test_replay_stream_corruption_detected(self):
        raw, source, _ = fixture()
        end = 8 + len(raw)
        plan = make_plan(raw, len(source), ['text.a','text.z'], digest(source))
        corrupt = source[end:-1] + bytes([source[-1] ^ 1])
        with self.assertRaisesRegex(ValueError, 'Whole source'):
            project(PrefixReader(source[:end], io.BytesIO(corrupt)), io.BytesIO(), plan)

if __name__ == '__main__':
    unittest.main(verbosity=2)
