# Narrow guard closure review

Date: 2026-10-04 UTC. Decision: **the three guard findings are closed for the reviewed source**. No additional blocker was found in this patch. This closes the conditions in `contextual_harm_stage1_original_source_review_20261004.md`; verified assets and the separate exact-source execution release remain required.

Reviewed files:

- `contextual_harm_stage1_20261004/guard_original_stage1_reconstructed.py`: SHA-256 `661628774e41efdef6e382edeaa17b5af9fe40554e5f4b5b49d64b1a0ce1290b`
- `contextual_harm_stage1_20261004/test_original_guard_revision_reconstructed.py`: SHA-256 `8d90129a6ef4123eb6e89d89d9d7ea1d9e639049d46aef6cc9b2cf66a1a32a94`

Host MemTotal minus MemAvailable is now checked before launch, during sampling, and at terminal accounting against the unchanged 9GB ceiling. Missing or malformed metrics fail closed. Final wall/load, disk, retained-artifact, and guard-log checks execute after owned wait4, cleanup, and source hashing. The final receipt is bounded by an explicit 256KiB reservation included in those terminal storage checks.

The guard opens and retains the owned session leader's pidfd before wait4. Cleanup is unconditional after leader termination and uses process-group scope through that descriptor, with no numeric killpg fallback. Survivor or cleanup failure prevents PASS. Linux v6.18 assigns flag4 to process-group scope, and its signal implementation passes the pidfd's retained PID object directly to group signaling. This supports the intended post-reap ownership semantics without looking up a potentially recycled numeric PID. Sources: [official pidfd UAPI](https://raw.githubusercontent.com/torvalds/linux/v6.18/include/uapi/linux/pidfd.h), [official signal implementation](https://raw.githubusercontent.com/torvalds/linux/v6.18/kernel/signal.c).

All 14 focused mocked tests passed independently in this review. No child/model was launched by those tests and all signal operations were mocked. The saved current-process signal-0 capability check establishes flag acceptance only; it is not a demonstrated real post-reap cleanup test. Source review and those focused tests suffice to close these narrow defects without another model gate.

The earlier numerical child's missing terminal receipt remains missing. This note neither changes its status nor certifies original memory fit. The prospective original run may still terminate on a resource limit under the preserved bounded-run rules.
