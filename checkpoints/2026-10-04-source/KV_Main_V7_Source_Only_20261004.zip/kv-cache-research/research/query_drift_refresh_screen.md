# Query-distribution drift and compressed-prefix refresh: focused screen

Screened 2026-10-03 UTC. Primary-source window: 2024-10-03 through 2026-10-03. This is a research decision and proposed CPU falsification protocol, not an implementation or an experiment result. No model, package, or author-code downloads, GPU work, external writes, or pushes were performed.

## Decision

**None clears promotion as a new main direction.** A narrow question remains unverified: can a genuinely cheap, online observation predict when changing a reusable compressed prefix will repay its rebuild cost under changing requests? The current proposal supplies neither an identified repair nor a validated benefit signal. Generic query-mixture adaptation, periodic refresh, runtime risk gating, and calibrated retention selection already have substantial 2025–2026 precedent.

The strongest fresh limitation is observability after destructive eviction. It is real, but it is not by itself a new method, and current literature explicitly recognizes it. Do not replace the missing signal with full-KV comparison, future attention, ground-truth answer scoring, or an oracle rebuilding decision and call the resulting controller deployable.

### First premise check: what changes when the cache is refreshed?

Let an immutable prefix P, fixed model M, fixed compressor C, and budget b produce S = C(P, M, b). Repeating this deterministic operation after the user-query mix changes produces the same S, apart from irrelevant execution nondeterminism. Query-blind reconstruction does not become aware of new traffic merely because it runs again.

There are three different proposals:

1. **Rebuild identical query-blind cache:** a no-op for the scientific objective. Reject immediately
2. **Change score distribution, query representatives, retained budget, or compressor:** a different adaptive policy. State the change precisely; past-request adaptation remains blind only to *future* requests, not query-agnostic in the same sense as the initial method
3. **Refresh mutated content, model/adapters, or causally different encodings:** a cache-validity or reuse-repair problem, outside this single-immutable-prefix screen

The second is the only relevant possibility here. It requires raw prefix tokens or a recoverable backing representation. Once entries are actually discarded, re-ranking the survivors cannot restore them. Keeping full KV on CPU changes the storage contract; regenerating it from tokens changes the compute contract. Both must be charged.

## Closest primary work and what remains different

| Work, date/version inspected | Relevant mechanism | Consequence for this candidate |
|---|---|---|
| [KVzip](https://arxiv.org/abs/2505.23416), submitted 2025-05-29; current v2 dated 2025-09-30; [author repository](https://github.com/snu-mllab/KVzip) | Context reconstruction scores a prefix for reuse across different future questions | Reusable, query-blind compression is established. Repeating the same reconstruction is not a traffic adaptation mechanism |
| [KVzap](https://arxiv.org/html/2601.07891v1), 2026-01 | Hidden-state surrogate for reconstruction importance; threshold-based adaptive retention, with recency protection | “Adaptive” retention is not new. The released scorer does not provide an observed downstream harm estimate or a cross-request rebuild scheduler |
| [EchoPress](https://arxiv.org/html/2610.00412v1), submitted 2026-09-30 | Virtual reconstruction from prefill states plus an exact first-chunk calibration | Per-context calibration is established; its map estimates reconstruction-score scale, not whether a changed user-query population is harmed |
| [Expected Attention](https://arxiv.org/html/2510.00636v1), 2025-10-01 | Ranks KV using modeled future-query moments and value magnitude | Estimating query distributions to guide KV importance is established. A recent-query moment update is not automatically a new scientific contribution |
| [AgentKV](https://arxiv.org/html/2609.14872v1), 2026-09-14; [author code](https://github.com/LiuTaowen-Tony/agentkv) | Models think/act/tool/other query mixtures; maintains per-phase query buffers and scores against their union, with persistent multi-turn eviction | Strongest recent overlap for query-distribution mismatch and cheap visible phase signals. Different from a single immutable prefix rebuilt between independent requests, but that distinction alone does not establish a useful gap |
| [RefreshKV](https://aclanthology.org/2025.acl-long.1211/), ACL July 2025 | Alternates full-context attention and subset attention, then updates the subset from the full-attention pattern | Refresh is established. Its observation explicitly pays for full attention and presumes access to the full input state; it does not solve observation after permanent deletion |
| [KeepKV](https://ojs.aaai.org/index.php/AAAI/article/download/40611/44572), AAAI 2026 version | Periodic refresh accompanies adaptive merging and attention compensation | Another close precedent against novelty from adding a refresh interval; not evidence for a free post-eviction error signal |
| [OjaKV](https://aclanthology.org/2026.findings-acl.494.pdf), ACL Findings 2026; [author code](https://github.com/zzbright1998/OjaKV) | Online low-rank subspace updates and full-rank treatment of high reconstruction-error tokens | Online adaptation to activation shifts is occupied. Its newly observed full vectors and reconstructible representation differ from discarded old tokens |
| [ParisKV](https://arxiv.org/html/2602.07721v1), 2026-02-07 | Avoids stale retrieval centroids with a data-independent index; keeps full history, including CPU-offloaded KV | Drift-robust retrieval is occupied. CPU offload is not permanent deletion and cannot be counted as eliminated total cache storage |
| [Risk-Controlled KV-Cache Eviction](https://arxiv.org/html/2609.27981v1), 2026-09-23 | Selects retention from paired full-KV/compressed calibration utilities, with full-KV fallback | Population-level risk calibration already exists; its stated guarantee does not cover distribution shift. Labels and paired references are paid offline inputs |
| [WitCert v3](https://arxiv.org/html/2607.28699v3), revised 2026-08-16 | Uses stored write-time residual witnesses for runtime quantization bounds and gating | Explicitly excludes token eviction from the cache-preserving guarantee. Section 6.4.6 identifies cheap online eviction certification as open; tested constant-size block witnesses were vacuous |
| [WitProbe v2](https://arxiv.org/html/2608.05863v2), revised 2026-08-16 | Typed update/select/read contracts, sampled corruption sentinel, observed-versus-declared coverage | Monitoring and its coverage/cost accounting are occupied. Slot corruption detection is not detection of lost evidence from intentionally deleted KV |
| [Pricing the Risk of Runtime Compression](https://arxiv.org/html/2608.15810v1), 2026-08-16 | Anytime-valid admission and physically accounted risk; explicitly separates local witnesses from served-output guarantees | A general cost/risk ledger is not a vacant contribution. Its limitations leave the deployed local-witness-to-output bridge and traffic-population transfer open |

Two very recent reuse papers were screened but excluded from the proposed scope: [ATTUNER](https://arxiv.org/html/2609.36722v1), September 29, learns query-side adaptation for independently encoded artifacts using full-prefill distillation; [ReCache](https://arxiv.org/abs/2608.19662), August 20, changes resource encoding and selective access for tool schemas. Neither warrants reopening prior multi-source or online-source projects. This screen remains one immutable offline prefix.

### Source and release checks

The already present EchoPress checkout is at `39748e9c8301944128eb2e681bfb074e9a2de860`. Read-only inspection found no working-tree changes in the three inspected files:

- [EchoPress implementation](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/echo_press.py): hooks capture prefill queries, virtual scoring consumes them layerwise, and finalization reconstructs the first chunk and applies its calibration. The context manager clears captured queries afterward. It has no persistent cross-request drift detector
- [Expected Attention implementation](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/expected_attention_press.py): computes current hidden-state-derived query mean/covariance and applies averaged future RoPE before key scoring. It does not maintain a traffic history or validate a refresh benefit
- [KVzap implementation](https://github.com/ljwljwljwljw/kvpress/blob/39748e9c8301944128eb2e681bfb074e9a2de860/kvpress/presses/kvzap_press.py): applies a model-specific hidden-state scorer; the documented intended wrapper is DMSPress. A fixed top-k scorer experiment would change the policy

SHA-256, respectively: `c1165408abec363b17201d56c4105873555b384b674819c7901df5d5c5c06b0b`, `6fbae9ab7b976e295959a53b80d145fac3687138cd91fa8fcf0e39d48f6f6c00`, `f29f8b0b31e4efb57b5a43bc9d1254a4c7333bb261ce411c77ed467d8ea25eb7`.

Fresh web reads verified the current [Expected Attention source](https://github.com/NVIDIA/kvpress/blob/main/kvpress/presses/expected_attention_press.py), paper versions, and author repository disclosures. The exact EchoPress commit could not be fetched through web in this pass; the local pinned checkout supplies that inspection instead. No claim is made that an upstream branch head was freshly resolved.

AgentKV's public README identifies phase-aware Stage-Q/SnapKV scoring and a serving-engine submodule at `254c57bc84e4a7895159ba1062bd46c83626f511`; the submodule fetch failed, so its full implementation was not audited. Its paper explicitly labels future-attention utility as an offline oracle, not an online input. [WitCert's public release](https://github.com/metask-ai/witcert-kv-certificates) and [WitProbe's release](https://github.com/metask-ai/witprobe-attention-memory) contain artifacts, mathematics, checks and proofs but exclude serving/probe-injection patches. Reproducing frozen numbers is not independently rerunning their serving experiments.

## What is actually available on the fast path?

“Already computed” and “free to observe” are different. Device reductions, hooks, extra writes, host synchronization and per-layer persistence can all cost time or memory. A deployable signal must declare which requests, layers, heads and token positions it observes.

| Signal | Available with compressed KV and fused attention? | What it can establish |
|---|---|---|
| Input tokens, token count, role/tool markers, request arrival and prefix identity | Normally available in request handling | Traffic/phase change and reuse frequency, not missing-evidence harm |
| Current query vectors, small running means or sketches | Queries exist transiently; capture/reduction has additional cost. Full covariance is O(d²) per observed vector | Change on the **compressed execution path**; later-layer queries are themselves affected by earlier compression |
| Generated-token probabilities or logit margin | Only if the serving/sampling path exposes them; extra logging/reductions may be needed | Confidence/change of the compressed model, not correctness or a full-KV counterfactual |
| Attention output and its norm | Output exists; statistics need instrumentation | Compressed readout behavior, not what discarded values would have contributed |
| Retained-set log normalizer | Supported by some low-level attention APIs, not guaranteed in an arbitrary high-level wrapper | Normalization over the entries actually read; missing entries contribute nothing to this value |
| Per-key attention entropy, top-key mass, source-region mass | Not ordinarily materialized by FlashAttention. Requires extra reductions/kernel work or explicit recomputation | Behavior inside the surviving support; still misses dropped mass |
| Full-cache lost mass, retained-mask recall against full attention, full/compressed logit distance | Unavailable after deletion without stored witnesses, backing KV, or replay | Paid diagnostic/oracle, not an already-observed online feature |
| Answer correctness, task utility, semantic failure labels | Usually unavailable during ordinary serving; feedback may be delayed and selected | Cannot serve as a free trigger; feedback acquisition and selection assumptions belong in the contract |

The inspected [FlashAttention API](https://raw.githubusercontent.com/Dao-AILab/flash-attention/main/flash_attn/flash_attn_interface.py) exposes optional `return_softmax_lse` in `flash_attn_with_kvcache`; its normal output is the attention result. Other public attention functions expose probabilities through a testing-oriented option whose scaling is not guaranteed correct. Do not enable that option and describe the detector as using free production attention weights. The inspected source is a dated main-branch read, not an immutable engine pin.

## An identifiability test before designing a detector

The following is an original elementary diagnostic derivation, not a measured language-model result or novelty claim.

For deletion-only attention with the **same query and unchanged surviving logits**, let K be the retained set and D the dropped set. With softmax partition sums Z_K and Z_D, define α = Z_D / (Z_K + Z_D). Extend the compressed distribution by zero on D. Then attention TV equals α, and

`o_full = (1 − α) o_K + α o_D`.

The compressed normalizer gives Z_K but not Z_D. Its entropy, confident output and query norm do not supply the missing term. Nor does α alone determine output error: dropped values can cancel.

### Two worlds with identical cheap observations

One retained scalar pair is `(k, v) = (0, 0)`. Two dropped keys both equal `log(9/2)`. The current scalar query is 1 and the softmax scale is 1.

- Benign world: dropped values are +1 and −1. Full attention output is 0
- Harmful world: dropped values are +1 and +1. Full attention output is 0.9
- In both worlds: compressed output is 0, retained log-normalizer is 0, retained attention entropy is 0, and current query and query-history features can be identical
- Even the dropped-key metadata, token counts, and individual dropped-value norms are identical. The omitted attention mass is 0.9 in both worlds

A policy restricted to those observations cannot choose different actions. A fixed downstream map from the identical compressed output also yields identical confidence/logits. This is a limited indistinguishability argument for the declared observer; it does not rule out informative retained witnesses, a learned predictor with distributional assumptions, or paid raw-prefix analysis. It does rule out a general guarantee from query drift plus compressed confidence alone.

### Cheap bounds are possible, but not automatically useful

If construction stores the count |D| and a valid maximum omitted-key norm R, then Cauchy–Schwarz gives

`log Z_D ≤ log |D| + ||q|| R / sqrt(d)`.

Together with the retained log-normalizer this upper-bounds α without reconstructing D. This ordinary bound illustrates why “no free exact signal” is not an impossibility proof for every summary. It also exposes the hard question: does an affordable summary make the bound selective rather than nearly one? Count amplification and worst-key geometry can make it vacuous. Grouping, directional sketches and sampling all add build/storage/read cost and need their own prior-art screen. This report proposes none as a novel solution.

## Refresh economics: the missing ledger

Track separately: initial build B₀; refresh R; per-request compressed execution C; monitoring m; paid audit A and its frequency p; fallback execution F; steady bytes; transition-peak bytes; and retained full/backing bytes. The original prefix prefill cannot be declared sunk on every refresh if it must be regenerated.

For N requests and J refreshes, a minimal compute account is

`B₀ + J R + Σ(C_i + m_i + audit_i + fallback_increment_i)`.

Compare with **one shared full prefix** as well as repeated exact-prefill service. Reusing the exact prefix can amortize its prefill too; charging it once per query while sharing the compressed prefix is an unfair baseline. If the monitor retains full CPU KV, report total host/device bytes and transfers, not just active GPU bytes. During rebuilding, the old serving cache, new full cache, score buffers and new compacted cache may overlap.

Suppose a successful refresh avoids s units of per-request fallback cost over H future requests. A necessary break-even condition is `H(s − m − pA) > R`, where s must be measured against a feasible comparator. No positive denominator means no compute break-even. If refresh changes quality but not per-request compute, report a quality/cost frontier instead of silently converting quality into money.

For scale only, EchoPress reports Qwen3-8B build-through-compaction medians of 5.15 seconds at 32K and 38.16 seconds at 128K on one A100; 128K plain prefill is 34.23 seconds and compression overhead 3.94 seconds. These are paper-specific build times, not CPU predictions or measurements here. Charging only the 3.94 seconds for a rebuild after full KV was discarded omits most of the work. [Timing source, Appendix B](https://arxiv.org/html/2610.00412v1)

Illustratively, if R were 5.15 seconds and genuine net savings only 50 ms/request, more than 103 subsequent requests are needed; R = 38.16 seconds needs more than 763.2. These are arithmetic sensitivity examples, not an observed deployment opportunity. Drift detected near the end of a prefix's useful lifetime may never amortize.

Paid audits do not become cheap by calling them calibration. With independent Bernoulli harm labels and zero observed harms, rejecting a 5% harm rate at one-sided 95% confidence needs 59 samples; a 1% rate needs 299. These are elementary binomial calculations, not proposed sequential guarantees. For repeated/adaptive selection, multiplicity, dependence and changing populations require additional treatment. A four-request spot check is not a calibrated safety statement.

## Smallest CPU decision test, only if a specific repair is supplied

No experiment was run for this report. The test below can reject a controller or identify an information requirement. It cannot establish model quality, natural query drift, serving speed, or publication novelty.

### Gate 0: refuse an unspecified action

Write down exactly how a refresh changes the mask. If it merely reruns fixed KVzip/EchoPress on unchanged input, stop at the no-op argument. If it uses the last W observed query vectors, state that policy and charge reconstructing/accessing *all candidate KV*. Recompute future request states under the new policy; a later model experiment cannot replay full-KV hidden queries as if the compressed model generated them.

### Minimal fixture

- One immutable attention layer/head, N = 1,024 keys, dimension d = 8, retained budget k = 128; T = 512 independent requests
- Four query modes; initial mixture `(0.9, 0.1, 0, 0)` and one abrupt change at request 256 to `(0.1, 0.9, 0, 0)`. Use fixed, explicitly declared finite query vectors or a finite seeded draw
- Compare stationary traffic, useful drift, harmless drift with value cancellation, a short transient that reverses before amortization, and the two-world observer alias above
- W = 32 and 64; predeclare detector thresholds on separate stationary development streams, never on held-out oracle errors
- The evaluator may retain dense arrays and compute exact reference readouts; the controller receives only its declared observations. Log every access crossing that boundary

Raw FP64 K/V occupy 128 KiB at N = 1,024 and d = 8; 512 query vectors occupy 32 KiB. Process arms sequentially. Diagnostic full attention is about 4.2 million scalar key-query products per stream before value weighting, so a small fixed grid fits comfortably on CPU without models or dependencies. No CPU time should be extrapolated to GPU serving latency.

### Required policies and oracle ceilings

1. Never refresh: initial query-blind/fixed mask, with its initial build charged
2. Fixed uniform/coverage mask at the same retained count; stable protection conventions for every arm
3. Periodic refresh at 16/32/64/128 requests using the **same repair action** as the adaptive arm; include phase offsets so a chosen change point does not favor one schedule
4. Uniform-random audit/refresh events at matched expected audit count and an exactly count-matched shuffled schedule control
5. Query-drift trigger using only tokens/phase or a specified small query sketch; a compressed-confidence variant if actually available
6. Exact-prefill/full-attention on every request; separately, shared exact-prefix service with no repeated build and full resident storage
7. Current-query exact lost-mass/error trigger, clearly marked a **paid-observation ceiling** with full observation costs
8. Hindsight scheduler restricted to the same repair action and refresh costs, plus an optional future-query optimal-mask ceiling. Neither may influence the deployable arm

The repair action should start with an ordinary recent-query scorer and a uniform/stratified query-reservoir scorer, not a newly learned optimizer. This separates detector value from ordinary sampling coverage and the already established mixture-representative idea.

### Measurements and rejection criteria

Report readout error relative to dense attention, number and timing of refreshes, false alarms on stationary/harmless drift, misses on harmful drift, detection delay, total explicit work, persistent/peak bytes, and regret to each correctly charged oracle. Sweep R in units of 1/8/32/128 compressed-request costs and audit cost independently. Plot the error/work frontier; any weighted objective must declare its exchange rate before results.

Reject the proposed main direction if:

- The specified refresh is a no-op, or cannot recover deleted entries under its stated storage contract
- It needs full attention, full-prefill logits, gold labels or future queries at every ordinary decision
- Query drift triggers equally on benign and harmful aliases and its only remedy is a costly general fallback
- Fixed periodic or uniform coverage controls match it at equal work/bytes
- The hindsight same-action scheduler has negligible advantage, showing there is little scheduling headroom even with privileged information
- Apparent gain disappears after exact-prefix reuse, audit/rebuild work, full backing storage or transition peaks are counted
- A result is only reduced scalar readout error on constructed arrays. That can justify further mechanism analysis, never a claim of improved LLM answer quality

## Stopping point

The defensible outcome of this screen is **no new main passes**. A meaningful continuation would require one precise, non-no-op repair plus one inexpensive observation that separates repairable harm from harmless drift on independent data, with visible cost headroom over periodic/uniform controls. Neither is presently established. The broad open online-eviction-witness problem is substantially harder than adding a change detector and is already explicitly posed by current work.

Searches covered query-distribution shift, refresh/recompression, reusable prefixes, phase/query representatives, online low-rank adaptation, drift-robust retrieval, risk calibration, and the current WitCert/WitProbe series. Aggregator pages were used only to locate primary papers; claims above rely on papers, author repositories, inspected official source, or explicitly identified derivations. This is not an exhaustive priority search or proof that no more recent/unindexed match exists.
