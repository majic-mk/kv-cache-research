# Independent review: pooled-full oracle control v2

Date: 2026-10-03 UTC. Scope: mathematical identifiability, score/mask invariants,
archive recomputation, historical separation, and counted execution work.

## Verdict

**The CPU/software diagnostic gate passes after one attribution defect was
fixed during review.** The original v2 draft could label a contrast clean even
when cutoff ties changed token membership inside a region while both head and
region budgets stayed identical. The final implementation conservatively flags
any ambiguous cutoff membership in either pooled or regional selection. The
reported counterexample is now a regression test and is flagged correctly.

This is a better controlled **full-information oracle intervention**, not a new
compression method or an observed model-quality improvement. The clean flag is
conditional on exact checks. A flagged raw quality difference remains descriptive;
flagging does not restore the missing identification. No pretrained-model/GPU
result, sparse-anchor estimability, deployable benefit, memory saving, speedup,
content causality, or generalization has been established.

Reviewed runtime source inventory, computed as
`canonical_hash(calibration_experiment.source_hashes())`:

`7af83c6582e34e4dff4a654b7527b59ab9a0d0f8e410b8988ec6af4535f6e3b2`

Key final source SHA-256 values:

- `research/calibration_methods/diagnostics.py`:
  `d6dcf985a1594a7850651cf39635c96ebcdf2aae06e33c1d019c6377c429d3bb`
- `echo_pilot/calibration_experiment.py`:
  `443dbb06db795aa461bed856406308ae3589941748eb09db50330fd5580302e1`
- `echo_pilot/calibration_experiment_analysis.py`:
  `859801f13ac74c76b3c3b6eb466a49354885ec0b8b935dc936637cf06b5be863`

## Finding and adversarial counterexamples

### Resolved: head-budget agreement was not enough

One layer/head, 12 tokens, four-token regions, first region fixed as anchors,
50% eviction, stable selection. Arrays below use the existing `case` fixture in
`research/calibration_methods/tests/test_pooled_oracle.py`:

```text
virtual: [-10,-9,-8,-7, 6,3,4,1, 5,7,0,2]
exact:   [-10,-9,-8,-7, 3,1,3,3, 1,0,1,2]
pooled:  [-10,-9,-8,-7, 3,1,2,1, 3,3,0,1]
regional:[-10,-9,-8,-7, 3,3,3,1, 1,2,0,1]

pooled retained:   [4,6,7,8,9,11]
regional retained:[4,5,6,8,9,11]
```

Pooled, regional, and exact mutable multisets are exactly identical. Both maps
preserve virtual weak order within each region, all fixed values, and identical
head and region budgets. Nevertheless, positions 5 and 7 exchange membership
inside the same region. The pooled map creates a plateau at score 1; stable
position-based tie selection then keeps a lower virtual-ranked token instead.
The original flag was `true` with no reasons because only cross-head cutoff
freedom was treated as a confound.

This is not restricted to signed synthetic scores or unprotected prefixes. An
independent nonnegative example with **four protected sinks**, still at 50%
eviction, uses these integer vectors divided by 16:

```text
virtual: [0,1,2,3, 5,7,4,8, 11,6,9,10] / 16
exact:   [0,1,2,3, 4,5,6,4, 4,4,6,6] / 16
pooled:  [0,1,2,3, 4,4,4,5, 6,4,6,6] / 16
regional:[0,1,2,3, 4,5,4,6, 6,4,4,6] / 16

pooled retained:   [0,1,2,3,10,11]
regional retained:[0,1,2,3,8,11]
```

Again the region counts agree. The final gate correctly sets
`pure_regional_contrast_interpretable=false` and reports
`ambiguous_cutoff_membership` in both examples. The first example is the included
test-source regression `test_cutoff_ties_can_swap_tokens_with_identical_head_and_region_counts`
(the source changes themselves remain uncommitted at this review).

### Numerical transport is correctly tested rather than assumed

The checked cases include duplicate source knots, cast-created source ties,
output-cast target ties, distinct source spacings below the mapper's `1e-12`
denominator floor, and float32 cancellation at otherwise distinct knots.
Distinct source values alone do not imply exact empirical transport. The code
compares actual sorted arrays with exact equality and records differences; it
does not replace these checks with tolerances or split a source tie by importing
exact ranks. An exact-rank tie repair would be a different intervention.

Strict equality can conservatively invalidate an otherwise tiny numerical
difference. This is a limitation on how often the frozen diagnostic will be
interpretable, not evidence against a scientific effect and not permission to
loosen the gate after observing outcomes.

## Why the final conditional interpretation is supported

Let F be the union of prefix, first-anchor, sink, and recent positions, and U its
complement. Both maps start from the same first-anchor baseline, leave F's values
unchanged, and fit only on U. The pooled map fits each layer/head's entire U;
the regional map fits each positional U-region separately. Both use the same
captured virtual/full-exact vectors, casts, interpolation, clipping, and tie
policy. Pooling labels does not change replay geometry or rerun a long-context
reconstruction.

The following chain supports only the narrow allocation interpretation:

1. Exact per-layer/head equality of the actual mutable P, R, and output-cast exact
   multisets, together with identical F scores, gives identical complete score
   histograms per layer/head
2. The protected union is identical and removed from competition. Its scores
   are identical, so the unprotected per-head score histograms also agree
3. With the same total eviction budget and **no ambiguous P or R cutoff**, the
   threshold determines membership uniquely. Head budgets and fixed-position
   membership therefore agree; there is no tie-break-driven head reallocation
4. Each map preserves the same virtual weak order and equal-source groups inside
   every mutable region. At an unambiguous cutoff, each selected regional subset
   is an upper set of that same order. P and R subsets are nested within a
   layer/head/region; changing their counts can change selected tokens, but
   arbitrary within-region swaps at equal counts cannot occur

Thus a passing gate isolates a regional allocation intervention relative to the
pooled full-label map at fixed head budgets, rather than merely comparing two
maps with different global score scales. It does not identify semantic/content
causes, distinguish position from recency, justify the full-exact scores as
downstream truth, or show that sparse anchors can estimate the oracle maps.
Equal masks or unchanged allocations can still yield a clean but uninformative
contrast. Scale/rank/reference arm deltas are not an additive decomposition.

The implementation correctly distinguishes hard invariant failures from valid
but confounded diagnostic cells. Shape/partition differences, sparse/full score
disagreement, changed fixed scores, nonfinite outputs, ordering/tie splitting,
lost protection, and wrong total budgets fail. Histogram/cutoff attribution
failures remain visible with their raw results. Singleton mutable regions stop;
empty mutable sets are explicitly uninterpretable. Stable, reverse, and seeded
random tie sensitivities run only score/mask selection, with no extra generation.

## Archive, historical, and cost review

### Strict offline recomputation

`validate_captures` reconstructs anchor policies, sparse calibrations, the pooled
and regional maps, all masks, provenance, cutoff bounds, and attribution flags
from the saved float32 captures. It checks complete NPZ inventory and exact
array/diagnostic equality. Resealing a changed pooled score, mask, or clean flag
does not bypass this recomputation. Sparse and full captures must agree exactly
on virtual vectors and observed anchor labels. `validate_results` requires every
frozen context/question/arm cell and binds queries and masks to those captures.

`validate_events` verifies the ordered start/completion sequence, including every
clone/install and generation, not just a total counter. Missing operations and
replay undercharges fail even after archive resealing. Offline quality analysis
reports paired R-minus-P scores for all frozen questions and carries recomputed
context flags through to the cohort. A failed context is not silently omitted.
Shared context-bootstrap draws are preserved; two LCC clusters remain exploratory
and one RepoBench-P cluster has no interval.

These are consistency/provenance checks, not cryptographic proof of an honest
execution. Coordinated fabrication of raw data and all supporting artifacts, or
a deliberately modified runtime, is outside what local checksums can establish.

### Historical separation

- Current schema is `echo_calibration_experiment_v2`; v1 plans are rejected rather
  than silently upgraded by the current entrypoint
- All eight tracked files in `research/diagnostics/calibration_experiment/` were
  independently compared byte-for-byte against `c96b250f40fb484077a7761c338e49300189f529`;
  all are unchanged
- Removing only the new protocol/provenance, ninth arm, and additional query
  work from the v2 canonical plans reproduces both original v1 hashes in tests
- Final v2 LCC plan:
  `23928ebbedfec715ccec8b21c9819dc5973416237b7f48b3cd8ae34573a9dc9c`
- Final v2 RepoBench-P plan:
  `c55daaf5d484aaeb6019765711b11f5d165f606767ed9334efc99542fd2e22f2`

### Work counts are not a free ninth method

The pooled arm reuses the existing full exact capture and first pristine dense
cache. It adds no scoring build, prefill, or exact replay. Each frozen question
still gets its own additional clone, mask installation, and generation. The
transform envelope includes repeated CPU map construction/audits and tie-mask
sensitivities; serialization and context wall time are also recorded. Shared
scoring costs cannot be attributed as an independent deployable build advantage.

- LCC: 8 builds, 42,232 prefill tokens, 24 sparse replays / 12,288 replay-input
  tokens, 22 full-diagnostic replays / 10,904 tokens, **18 query clones**, 252
  initial query-input tokens, at most 1,152 generated tokens
- RepoBench-P: 4 builds, 23,060 prefill tokens, 12 sparse replays / 6,144 tokens,
  12 full-diagnostic replays / 5,954 tokens, **9 query clones**, 4,032 initial
  query-input tokens, at most 576 generated tokens
- Relative to v1: +2 LCC clones/generations, +28 initial query-input tokens and
  +128 maximum generated tokens; +1 RepoBench-P clone/generation, +448 initial
  query-input tokens and +64 maximum generated tokens

Native CPU tests verify independent clones, unchanged pristine key/value tensors,
cleanup, and no oracle rescoring. Native execution emits nine arm cells with
only the original four builds per context. These remain software tests with
patched GPU timing/loader gates and a random tiny Qwen model, not real-model
benchmark or physical-memory evidence. Plans are maximum/count accounting;
they are not measured FLOPs, provider charges, or speedup results.

## Independent validation performed

All commands used `CUDA_VISIBLE_DEVICES=''`; no installation, model-weight
download, GPU use, paid resource, commit, or push was performed by this review.

```sh
python -m unittest discover -s research/calibration_methods/tests -v
# 61 tests passed after the cutoff fix

python -m unittest echo_pilot.tests.test_calibration_experiment -v
# 31 tests passed, including archive tampering and frozen-plan checks

/tmp/kv_tiny_qwen_cpu_20261003/bin/python -m unittest \
  echo_pilot.tests.test_calibration_experiment_native -v
# 5 tests passed in the already existing native CPU environment

git diff --check
# passed
```

These 97 distinct focused cases are subsets of the author's broader validation;
do not add repeated runs or subsets to that aggregate. No full GPU suite was run.

Additional independent adversarial/property checks (not extra unittest cases):

- Reproduced the original false-clean counterexample before the fix and checked
  both examples above after it
- Seed 271828: 240 small array cases across 1–3 heads, several protected counts,
  25/50/75% eviction, distinct and duplicated dyadic targets; 112 were clean and
  128 flagged. Every clean case had identical fixed membership and head budgets,
  regionwise nested P/R masks, and zero P/R tie-sensitivity changes
- Seed 271828: 120 cutoff cases, enumerating every admissible selection of tied
  candidates, confirmed the reported minimum/maximum retained counts for every
  head and every layer/head/region exactly, including protected exclusions

## Remaining decision boundary

This review approves the narrowly documented CPU control and archive safeguards,
not progression to paid experiments or a scientific claim. The existing baseline,
environment, budget, hardware/parity, and resource-isolation gates still apply.
If a future real screen is numerically/tie confounded, preserve all results and
report the intended allocation question as unresolved. A different construction,
sparse estimator, broader evaluation, or changed precision/tie policy needs its
own declared protocol before looking at outcomes.
