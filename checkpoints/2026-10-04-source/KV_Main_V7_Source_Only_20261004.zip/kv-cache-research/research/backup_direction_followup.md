# KV cache backup direction followup

Checked 2026-10-03 UTC. Literature window: 2024-10-03 through 2026-10-03. This is a replacement-backup audit following `direction_comparison.md`, `narrow_alternatives.md`, `backup_codec_audit.md`, and `calibration_novelty_followup.md`.

## Decision

**No genuinely distinct, implementation-ready research backup passed this audit. Do not spend GPU money on a replacement merely to keep the project moving.** There are plausible mathematical questions, but I did not establish a new mechanism, a natural-workload failure that it fixes, and a credible single-RTX-5090 implementation together.

The strongest remaining lead is **an independently sampled audit cache for attributing permanent-eviction error during adaptive reuse**. It is a theory-first lead, not a recommended new main or a novelty-cleared method. Ordinary sample splitting is already standard statistics; doing it inside a KV cache is not sufficient novelty. A useful contribution would require a sound, non-vacuous guarantee at a competitive total byte budget and an explicit treatment of feedback. Neither has been established here.

Keep the existing calibration study labeled as a conditional diagnostic. This report does not revive the closed multi-source/QCFuse/P3 projects, the rejected scheduler, generic RAG repair, regional-anchor policy changes, or the unsupported TensorRT NVFP4 route. No model inference or positive result is reported.

## Why the obvious replacements fail

### 1 Correct the representation rather than select different tokens

This is substantively different from regional score calibration, but the obvious mechanisms are already occupied:

- [Fast KV Compaction via Attention Matching](https://arxiv.org/abs/2602.16284), first submitted 2026-02-18, inspected current v2 dated 2026-05-26, explicitly constructs compact K/V to match attention outputs and attention mass per KV head. Adding a mass/bias term to compensate dropped tokens is therefore not an empty direction
- [MomentKV](https://arxiv.org/abs/2606.01563), 2026-06-01, maintains statistics of evicted keys and values, including cross-moments, and uses them to approximate their contribution. A small summary beside an eviction cache cannot be claimed as a new mechanism merely because it preserves output direction
- [Quantized Keys Steal Attention](https://arxiv.org/abs/2605.26266), 2026-05-25, derives quantization-noise-induced softmax mass inflation and a score correction. Its main setting is autoregressive video diffusion. Porting the same correction to text would need a new reason why the existing mathematics or implementation is insufficient; a domain transfer alone does not meet this project's bar
- [Attention-Aware Transform Coding](https://arxiv.org/html/2608.14191v1), 2026-08-14, derives an attention-output-aware distortion objective and bit allocation. [WUSH-KV](https://arxiv.org/html/2609.38121v1), 2026-09-29, uses data-adaptive transforms with separate key/value treatment. Merely changing a reconstruction-MSE target to attention sensitivity or a rotation to a calibrated transform is not a defensible gap
- [ResidualKV v2](https://arxiv.org/abs/2602.08005v2), first submitted 2026-02-08 as DeltaKV and revised 2026-09-30, already represents tokens through retrieved references and quantized residual codes, with selected-state reconstruction. The author's current linked repository still uses the DeltaKV name. Preserving every token via residual codes is occupied; the title change must not make it look like two independent works

**Important source correction:** [HeadQ](https://arxiv.org/abs/2605.03562) was withdrawn on 2026-05-19; the current record gives ethical concerns as the reason. Its older manuscript describes a query-basis residual side code, but its numerical claims must not be used as trustworthy evidence or a reproduction target. The public description is a conceptual-overlap warning, not proof that the method works. The other sources above independently block the broad representation-correction claims.

**Disposition:** reject a replacement defined as “existing compression plus a correction,” unless a concrete limitation surviving the strongest relevant existing correction is first demonstrated. No such limitation was found here.

### 2 Recover exact outputs through verification

[FAFO](https://proceedings.mlr.press/v306/le26g.html), ICML 2026, already studies lossy KV compression inside a lossless inference strategy. [VeriCache](https://arxiv.org/abs/2605.17613), submitted 2026-05-17, explicitly drafts with compressed KV and verifies with the full cache, including an offloaded-full-cache implementation strategy. The [Vegas author repository](https://github.com/platformxlab/vegas) goes further by deriving the next sparse drafting set from the verification pass itself.

These are strong counterexamples to three apparently distinct proposals: using a compressed cache as a same-model drafter, learning which entries matter from exact verification, and hiding full-cache transfer behind drafting. A shorter speculation horizon or a different eviction scorer is a parameter/policy change unless a new failure and mechanism are established.

The inspected Vegas README builds a vLLM fork with a companion FlashAttention-3 fork. That is an implementation dependency, **not evidence of an RTX 5090-compatible runnable baseline**. Porting it is not itself the desired research contribution. A small 8K single-request experiment may also lack the long-context attention/transfer bottleneck that motivates these systems.

**Disposition:** reject as the replacement. Do not rent a GPU to rediscover the already-published construction.

### 3 Certify the damage rather than predict importance

[WitCert v3](https://arxiv.org/html/2607.28699v3), first submitted 2026-07-30 and revised 2026-08-16, distinguishes a deterministic query-adaptive bound from a tighter dither-based bound whose formal scope excludes adaptive queries. It also reports that its deterministic low-bit witness becomes uninformative. These are real stated limitations, not inferred user pain. Its public release supplies proofs and frozen artifacts, while withholding the serving implementation. Those facts make it useful for a CPU mathematical audit, but not a turnkey GPU baseline.

However, the same research line's [Pricing the Risk of Runtime Compression](https://arxiv.org/html/2608.15810v1) already targets anytime-valid admission and adaptive serving-state decisions. It also tests a measured-ellipsoid tightening and reports no useful gain in its studied bound. “Replace a union bound with an e-process,” “make the certificate adaptive,” or “use covariance instead of a norm ball” cannot be asserted as new without a precise comparison to that paper's assumptions and controlled action.

[Error Certificates for KV-Cache Eviction via Randomized Design v3](https://arxiv.org/html/2607.21475v3), submitted 2026-07-23 and revised 2026-08-29, already couples permanent stochastic eviction, inclusion-probability-corrected attention, error estimation, and agent-memory gating. Its Appendix A.2 discusses an anytime construction and explicitly leaves vector-to-scalar constants and reuse of a fixed sample as open ends. Its empirical coverage is not a uniform guarantee for all future adaptive queries.

**Disposition:** generic runtime risk control and randomized audit scores are occupied. One narrower lead remains worth defining, below, but it does not pass the method gate yet.

## One narrow theory-first lead

### Separate the inference sample from the audit sample

**Question:** can a reusable compressed cache retain a small, statistically independent audit sample that gives useful attribution of current attention-output error along a free-running trajectory, without letting the same random sample both determine the query and validate it?

The operational object would be two separately accounted pieces of state:

1. An inference cache, built by the chosen ordinary compressor, determines all model outputs
2. An independently randomized audit sample, with its inclusion probabilities, is used only to estimate the difference between that inference output and the full-cache attention output for the *same realized query*

In the simplest scoped design, the audit result is hidden from the generation loop and from subsequent query selection until the evaluated trajectory finishes. Conditional on the original context and inference randomness, its queries then do not depend on the independent audit draw. This is an elementary sample-splitting observation, **not a new theorem established by this audit**. It also certifies neither the dense model's alternative trajectory nor task correctness.

The difficult part is not naming a second reservoir. One must derive and check a non-vacuous finite-sample bound for a self-normalized, vector-valued attention estimate, including a valid range/denominator treatment after unsampled KV has been discarded. If the audit is used to trigger repair, expose warnings, or influence subsequent prompts, that feedback invalidates the simple independence argument. A feedback-safe extension would need its own proof and state accounting. Retaining a full cache to refresh samples is allowed only if its storage and traffic are counted; it ceases to be permanent eviction.

### Closest work and required substantive difference

The closest eviction source is the randomized-design paper above; the adjacent certification sources are WitCert and the anytime-admission follow-up. The proposed distinction is **which random state is permitted to influence the queries being audited**, rather than an alternative importance score, calibration location, or retention percentage.

This distinction is currently a research hypothesis. I did not find an exact matching independent-audit-cache design in this focused search, but absence from search is not a priority result. More importantly, ordinary holdout/sample splitting might already solve the scoped, read-only version so directly that it is only a useful diagnostic. Merely appending that diagnostic to KVzip would be the simple stack that this project is trying to avoid.

**Acceptance requirement:** establish a nontrivial statistical/storage trade-off or a feedback-safe reusable construction that the closest methods do not already provide. A renamed reservoir, empirical error correlation, or an unproved “95% confidence” number fails.

### Cheapest falsification sequence

These are proposed gates, not experiments that were run.

1. **Proof and tiny CPU gate first.** Write the probability space, what the query can observe, the conditioning event, and the exact target. Test fixed queries, queries chosen using the inference sample, and queries chosen using the audit result. Use exhaustive small sampling masks and two-to-eight-token constructed cases before any model. If the claimed guarantee needs independence that the stated loop does not preserve, stop. Do not call a valid fixed-query theorem “wrong” because an unsupported adaptive extension fails
2. **Utility ceiling before an estimator.** On a small dense attention capture, calculate the exact local error and determine whether attribution has a useful task at all. If all important cells have negligible error, or an existing confidence signal plus a simple reference policy achieves the same decision value, stop. This is not a proposal for a general benchmark paper
3. **Equal-total-byte diagnostic.** Compare the existing same-sample corrected estimator, an independent audit sample, a no-audit compressor given all the bytes, and a full-KV offline oracle. Include stored indices/probabilities, scratch space and any backing cache. Keep the same query trajectory for local-error comparisons; separately measure the actual inference quality of each byte allocation
4. **Only then one small model capture.** Reuse the pinned Qwen3-8B and existing natural code/repository contexts for integration. Add a small independently chosen long-document retrieval slice because three code contexts cannot establish generality. Start with 8K context and at most 128 generated tokens, batch one. Capture one layer/head slice at a time or stream captures to CPU; never materialize every layer's full attention matrices
5. **Kill quickly.** Stop if the bound is essentially always wider than the effect of interest, equal-byte loss from withholding inference KV exceeds the audit's value, feedback breaks the advertised contract, or the only benefit is a conventional split-sample estimator with no additional result. Do not proceed to kernel optimization to rescue a failed statistical question

This lead is distinct from score calibration, but its first gate is mathematical. **GPU availability cannot resolve the missing contribution.**

## Single RTX 5090 resource envelope

No GPU implementation was made and no peak was measured. The following is a bounded planning estimate for the optional capture above, not a promise that the author systems run on SM120.

The [official Qwen3-8B configuration](https://huggingface.co/Qwen/Qwen3-8B/blob/main/config.json) has 36 layers, 8 KV heads, and head dimension 128. At BF16, raw KV is:

`2 × 36 × 8 × 128 × 2 = 147,456 bytes/token = 144 KiB/token`

Thus 8,192 tokens use **1.125 GiB** raw KV; 16,384 use **2.25 GiB**. One layer at 8K needs 32 MiB of K/V. An additional 128 generated tokens add 18 MiB across all layers. A 512-token audit sample across all layers is 72 MiB before probabilities, indices and buffers; 1,024 tokens is 144 MiB. Its cost must be deducted from the inference-cache allowance, not hidden beside it.

For the limited 8K capture, budget approximately **16 GiB for weights, up to 3 GiB for live/reference/audit cache buffers, and 6 GiB for runtime/workspace**, or roughly **25 GiB planned live memory**. Enforce a **28 GiB operational ceiling** to retain headroom on the 32GB device. This is an imposed stop limit, not a proven peak upper bound. A backend that allocates dense prefill attention or duplicates weights can exceed it; stop or reduce the capture rather than silently offload and report different timing. A real model capture must first pass the project's SM120 environment smoke test.

- CPU probability-space/exhaustive-mask gate: no paid GPU, proposed working-memory ceiling 1 GiB using small tensors
- Conditional model capture: at most **2 billable GPU hours / CNY10 all-in**, whichever comes first, within the existing cumulative CNY100 ceiling and only after a useful theoretical result
- At the previously verified ordinary-user planning rate of CNY2.93/hour in `gpu_budget.md`, two hours are **CNY5.86 compute only**. The actual machine quote and all ancillary charges still govern; no new quote was obtained here
- No new model training, serving-engine fork, paid disk expansion, or large benchmark sweep is justified for this gate

**Recommended spend now: CNY0.** Do not open the optional GPU gate simply because it fits the budget.

## Author code verification and status corrections

Fresh read-only GitHub checks on 2026-10-03:

- WitCert's current public artifact repository is [metask-ai/witcert-kv-certificates](https://github.com/metask-ai/witcert-kv-certificates/tree/a0ca8781a66b1f3272d9e3e95e7561a69b45d6a6), commit `a0ca8781a66b1f3272d9e3e95e7561a69b45d6a6`, dated 2026-08-19. Its [README](https://github.com/metask-ai/witcert-kv-certificates/blob/a0ca8781a66b1f3272d9e3e95e7561a69b45d6a6/README.md) distinguishes artifact/proof regeneration from live serving reruns. Its [certificate regression source](https://github.com/metask-ai/witcert-kv-certificates/blob/a0ca8781a66b1f3272d9e3e95e7561a69b45d6a6/tests/test_certificates.py) was inspected, not executed. Frozen-number reproduction is not a fresh GPU reproduction
- The v1 WitCert link `wayfind/witcert` returned 404 through the GitHub connector; the current v3 link above succeeds. Reporting “no code exists” from the old link would be wrong
- Calver's paper names [DeanoC/certified-quantized-attention](https://github.com/DeanoC/certified-quantized-attention), but the connector returned 404 in this session. That establishes unavailable access through this route, not whether the repository was deleted, renamed or made private. It was not used as an inspected-code baseline
- ResidualKV's author link redirected to [CURRENTF/DeltaKV](https://github.com/CURRENTF/DeltaKV/tree/11a837b21acfa475957210c5b2d339b89c1b7e3b). The resolved head is `11a837b21acfa475957210c5b2d339b89c1b7e3b`, dated 2026-09-02. Its [README](https://github.com/CURRENTF/DeltaKV/blob/11a837b21acfa475957210c5b2d339b89c1b7e3b/README.md) includes a sparse-serving engine and compressor tooling. No installed dependency or measured SM120 compatibility is implied by the source's existence
- Author implementations for the randomized-design paper, MomentKV, Attention Matching and the bias-correction paper were not pinned in this pass. Their primary-paper descriptions support the limited overlap conclusions; no author-code behavior or reproduced performance is asserted for them

## Search limits and final recommendation

Searches covered mass/output correction, quantization bias, residual/transform coding, RoPE-aware representations, cross-adapter reuse, exact speculative verification, runtime certificates, adaptive query dependence and independent audit sampling. Current arXiv records were checked where version/status changes mattered; the withdrawn HeadQ and renamed ResidualKV illustrate why first-result abstracts are insufficient. Secondary pages were discovery aids, not the evidence for method claims. This is a focused exclusion audit, not an exhaustive priority search.

The evidence supports a negative project decision: **there is no validated replacement backup here**. The optional independent-audit idea can be reconsidered only after a substantive mathematical result and an equal-byte utility argument. Until then, finish the already scoped calibration falsification if it remains worthwhile, or stop this line without consuming the CNY100 merely to produce another weak variant.
