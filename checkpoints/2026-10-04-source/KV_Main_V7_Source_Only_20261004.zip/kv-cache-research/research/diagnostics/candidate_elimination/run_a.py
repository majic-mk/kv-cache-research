"""Predeclared synthetic GQA invariance screen; no model/runtime dependencies."""
import csv
import hashlib
import itertools
import json
import platform
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def softmax(x):
    e = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def redundancy(k, centered):
    # Semantics independently transcribed from pinned HF utils.py cal_similarity.
    # The source's last-neighbor suppression falls back to column zero if no
    # neighbor exceeds threshold. Preserve that behavior rather than fixing it.
    z = k - k.mean(axis=0, keepdims=True) if centered else k
    z = z / (np.linalg.norm(z, axis=-1, keepdims=True) + z.dtype.type(1e-8))
    sim = z @ z.T
    np.fill_diagonal(sim, 0)
    last = np.where(sim > 0.5, np.arange(len(k))[None, :], 0).max(axis=-1)
    sim[np.arange(len(k)), last] = 0
    return softmax(sim.mean(axis=0))


def importance(logits, mode, window):
    old = logits[..., :-window]
    if mode == 'rawmax':
        x = softmax(old.max(axis=0)).mean(axis=0)
    elif mode == 'softmaxfirst':
        x = softmax(old).max(axis=0).mean(axis=0)
    elif mode == 'meanhead':
        x = softmax(old).mean(axis=(0, 1))
    else:
        raise ValueError(mode)
    return np.lib.stride_tricks.sliding_window_view(
        np.pad(x, (3, 3), constant_values=-np.inf), 7
    ).max(axis=-1)


def select(scores, budget, window):
    n_old = len(scores)
    order = np.lexsort((np.arange(n_old), -scores))
    count = budget - window
    margin = float(scores[order[count-1]] - scores[order[count]])
    chosen = np.sort(np.r_[order[:count], np.arange(n_old, n_old+window)])
    return chosen, margin


def readout(q, k, v, ids=None):
    if ids is not None:
        k, v = k[ids], v[ids]
    weights = softmax((q @ k.T) / q.dtype.type(np.sqrt(q.shape[-1])))
    return weights, weights @ v


def witness():
    out = {}
    for dtype in (np.float64, np.float32):
        q = np.array([[2], [-1]], dtype=dtype)
        k = np.array([[1], [0]], dtype=dtype)
        v = np.array([[1], [0]], dtype=dtype)
        data = []
        for shift in (0, -2):
            z = q @ (k+shift).T
            dense, y = readout(q, k+shift, v)
            raw = softmax(z.max(axis=0))
            fixed = softmax(z).max(axis=0)
            centered_logits = z-z.mean(axis=-1, keepdims=True)
            data.append({'shift': shift, 'logits': z.tolist(),
                         'dense_attention': dense.tolist(), 'dense_readout': y.tolist(),
                         'rawmax_kept_id': int(raw.argmax()),
                         'softmaxfirst_kept_id': int(fixed.argmax()),
                         'center_logits_kept_id': int(centered_logits.max(axis=0).argmax()),
                         'rawmax_compressed_readout': v[[raw.argmax()]].repeat(2, axis=0).tolist()})
        assert [x['rawmax_kept_id'] for x in data] == [0, 1]
        assert [x['softmaxfirst_kept_id'] for x in data] == [0, 0]
        out[np.dtype(dtype).name] = data
    # A nonzero-key shift of the same witness avoids any zero-vector premise.
    q = np.array([[2.], [-1.]])
    k = np.array([[1.25], [0.25]])
    out['nonzero_rawmax_ids'] = [int((q @ (k+s).T).max(0).argmax()) for s in (0, -2)]
    assert out['nonzero_rawmax_ids'] == [0, 1]
    return out


def main():
    protocol = json.loads((ROOT/'protocol.json').read_text())
    p = protocol['A']
    rows = []
    arm_names = p['arms']
    # Two dtype runs regenerate the same base draws, then cast them separately.
    for seed, h, n, d, distribution, dt in itertools.product(
            p['seeds'], p['heads'], p['keys'], p['dimensions'],
            p['distributions'], p['dtypes']):
        rng = np.random.default_rng(np.random.SeedSequence([seed, h, n, d, distribution == 'clustered']))
        window, budget = 8, max(10, n//4)
        q0 = np.clip(rng.normal(size=(h, window, d)), -3, 3)
        k0 = np.clip(rng.normal(size=(n, d)), -3, 3)
        if distribution == 'clustered':
            centers = np.clip(rng.normal(size=(4, d)), -3, 3)
            k0 = centers[np.arange(n) % 4] + 0.15 * k0
        v0 = np.clip(rng.normal(size=(n, d)), -3, 3)
        u = rng.normal(size=d)
        u /= np.sqrt(np.mean(u*u))
        dtype = np.dtype(dt).type
        q, k, v = q0.astype(dtype), k0.astype(dtype), v0.astype(dtype)
        random_ids = np.sort(np.r_[rng.choice(n-window, budget-window, replace=False), np.arange(n-window, n)])
        uniform_ids = np.sort(np.r_[np.linspace(0, n-window-1, budget-window, dtype=int), np.arange(n-window, n)])
        base_weights, base_dense = readout(q[:, -1], k, v)
        base = {}
        for alpha in (0, 0.25, 2, 8, 32):
            shifted = k + (alpha*u).astype(dtype)
            logits = (q @ shifted.T)/dtype(np.sqrt(d))
            attn, dense = readout(q[:, -1], shifted, v)
            imp = {mode: importance(logits, mode, window) for mode in ('rawmax', 'softmaxfirst', 'meanhead')}
            red = {center: redundancy(shifted, center)[:-window] for center in (False, True)}
            for arm in arm_names:
                if arm == 'dense':
                    ids, margin, score = np.arange(n), float('inf'), None
                elif arm in ('uniform', 'random'):
                    ids = uniform_ids if arm == 'uniform' else random_ids
                    margin, score = float('inf'), None
                else:
                    mode, centering = arm.split('_')
                    score = dtype(0.1)*imp[mode]-dtype(0.9)*red[centering == 'centered']
                    ids, margin = select(score, budget, window)
                _, compressed = readout(q[:, -1], shifted, v, ids)
                if alpha == 0:
                    base[arm] = (ids, compressed, score, margin)
                original_ids, original_out, original_score, original_margin = base[arm]
                score_delta = 0.0 if score is None else float(np.max(np.abs(score-original_score)))
                # A rigorous simple top-k stability sufficient condition uses
                # infinity-norm perturbation, not an arbitrary allclose cutoff.
                gap_guard = min(margin, original_margin) > 2*score_delta
                inter = len(np.intersect1d(ids, original_ids))
                row = dict(seed=seed, heads=h, keys=n, dimension=d, distribution=distribution,
                    dtype=dt, shift_scale=alpha, arm=arm, budget=len(ids),
                    dense_attention_max_abs=float(np.max(np.abs(attn-base_weights))),
                    dense_readout_max_abs=float(np.max(np.abs(dense-base_dense))),
                    retained_set_changed=not np.array_equal(ids, original_ids),
                    retained_jaccard=inter/(len(ids)+len(original_ids)-inter),
                    cutoff_margin=margin, base_cutoff_margin=original_margin,
                    cutoff_exact_tie=margin == 0 or original_margin == 0,
                    score_max_abs=score_delta, cutoff_stability_guard=bool(gap_guard),
                    compressed_readout_drift_max_abs=float(np.max(np.abs(compressed-original_out))),
                    compressed_readout_rmse=float(np.sqrt(np.mean((compressed-dense)**2))),
                    base_compressed_readout_rmse=float(np.sqrt(np.mean((original_out-base_dense)**2))))
                rows.append(row)
                # Keep the first fully specified residual failure witness for
                # each one-fix arm. No seed/range search beyond this protocol.
                if alpha and row['retained_set_changed'] and dt == 'float64' and arm in ('rawmax_centered','softmaxfirst_uncentered'):
                    dest = ROOT/f'a_counterexample_{arm}.json'
                    if not dest.exists():
                        dest.write_text(json.dumps({'row':row, 'queries':q.tolist(), 'keys':k.tolist(),
                            'values':v.tolist(), 'translation':(alpha*u).tolist(),
                            'base_kept':original_ids.tolist(), 'shifted_kept':ids.tolist()}, indent=2)+'\n')
    with (ROOT/'a_sweep.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)
    summaries = []
    for dt, arm in itertools.product(p['dtypes'], arm_names):
        group = [r for r in rows if r['dtype']==dt and r['arm']==arm and r['shift_scale']>0]
        summary = {'dtype':dt, 'arm':arm, 'comparisons':len(group),
            'changed_sets':sum(r['retained_set_changed'] for r in group),
            'mean_jaccard':float(np.mean([r['retained_jaccard'] for r in group])),
            'cutoff_exact_ties':sum(r['cutoff_exact_tie'] for r in group),
            'max_dense_attention_abs':max(r['dense_attention_max_abs'] for r in group),
            'max_dense_readout_abs':max(r['dense_readout_max_abs'] for r in group),
            'max_compressed_readout_drift':max(r['compressed_readout_drift_max_abs'] for r in group),
            'mean_original_rmse':float(np.mean([r['base_compressed_readout_rmse'] for r in group])),
            'mean_shifted_rmse':float(np.mean([r['compressed_readout_rmse'] for r in group])),
            'changed_with_stability_guard':sum(r['retained_set_changed'] and r['cutoff_stability_guard'] for r in group)}
        assert summary['max_dense_readout_abs'] < p['limits'][dt+'_dense_abs']
        assert summary['changed_with_stability_guard'] == 0
        summaries.append(summary)
    fixed64 = next(r for r in summaries if r['dtype']=='float64' and r['arm']=='softmaxfirst_centered')
    assert fixed64['changed_sets'] == 0, 'Unexpected exact-mechanism failure: inspect before expanding'
    results = {'evidence_class':protocol['evidence_class'], 'python':platform.python_version(),
        'numpy':np.__version__, 'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),
        'rows':len(rows), 'witness':witness(), 'summary':summaries,
        'conclusion':'Reject A as a new method on this gate: simple pooling and centering controls close the constructed invariance defect. Natural quality remains untested.'}
    (ROOT/'a_results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'summary':summaries}, indent=2))


if __name__ == '__main__':
    main()
