"""Exact rational online-eviction state machine and declared work counts.

This is not an R-KV or speculative-sampling implementation. It checks the
conditional serial contract on given accepted input traces, including the KV
processing of one correction/bonus input. Exact arithmetic isolates semantics.
"""
import copy
import csv
import hashlib
import itertools
import json
import math
import random
from dataclasses import dataclass, field
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent


@dataclass
class State:
    entries: list
    count: int = 0
    qcount: int = 0
    ring: list = field(default_factory=list)
    dropped: int = 0
    events: int = 0


def weights(q, entries, base=2):
    a = [F(base)**(q*k) for _, k, _ in entries]
    total = sum(a)
    return [x/total for x in a]


def attend(q, entries, ops=None):
    if ops is not None:
        ops['attention_terms'] += len(entries)
    return sum(w*v for w, (_, _, v) in zip(weights(q, entries), entries))


def record(state, pos, query, ring_size, ops):
    state.ring = (state.ring+[(pos, query)])[-ring_size:]
    state.qcount += 1
    ops['metadata_writes'] += 1


def evict(state, budget, ops):
    if len(state.entries) <= budget:
        return
    # Protect newest entry. Mean attention over all currently retained entries
    # under recorded queries; ties resolve by original id.
    scores = [F(0)]*len(state.entries)
    for _, q in state.ring:
        scores = [a+b for a, b in zip(scores, weights(q, state.entries))]
        ops['scoring_terms'] += len(state.entries)
    order = sorted(range(len(state.entries)-1), key=lambda i: (-scores[i], state.entries[i][0]))
    keep = sorted(order[:budget-1]+[len(state.entries)-1])
    state.dropped += len(state.entries)-len(keep)
    state.entries = [state.entries[i] for i in keep]
    state.events += 1
    ops['evictions'] += 1


def counters():
    return dict(attention_terms=0, scoring_terms=0, verification_calls=0,
                query_rows=0, metadata_writes=0, evictions=0)


def serial_step(state, token, cadence, ring_size, budget, ops):
    q, k, v = token
    pos = state.count
    state.entries.append((pos, k, v))
    y = attend(q, state.entries, ops)
    record(state, pos, q, ring_size, ops)
    state.count += 1
    ops['query_rows'] += 1
    ops['verification_calls'] += 1
    if state.count % cadence == 0:
        evict(state, budget, ops)
    return y


def block_forward(start, tokens, ring_size, ops):
    """Causal append-only block; snapshots permit accepted-prefix commit.

    KV/query work is evaluated token-wise here, but one verification call is
    counted. No eviction occurs inside this block. Output/state snapshots are
    gathered once, not recomputed to roll back accepted inputs.
    """
    state = copy.deepcopy(start)
    snapshots, outputs = [copy.deepcopy(state)], []
    ops['verification_calls'] += 1
    for q, k, v in tokens:
        pos = state.count
        state.entries.append((pos, k, v))
        outputs.append(attend(q, state.entries, ops))
        record(state, pos, q, ring_size, ops)
        state.count += 1
        ops['query_rows'] += 1
        snapshots.append(copy.deepcopy(state))
    return snapshots, outputs


def evaluate(start, tokens, accepted, bonus, cadence, mode):
    ring_size, budget = min(8, cadence), 4
    ops = counters()
    state = copy.deepcopy(start)
    output = []
    if mode == 'serial':
        for token in tokens[:accepted]:
            output.append(serial_step(state, token, cadence, ring_size, budget, ops))
    elif mode == 'boundary_capped_transactional':
        cursor = 0
        # Even zero acceptance evaluates its proposed segment, then rolls back.
        while cursor < len(tokens):
            width = min(len(tokens)-cursor, cadence-state.count % cadence)
            snapshots, ys = block_forward(state, tokens[cursor:cursor+width], ring_size, ops)
            take = min(width, max(0, accepted-cursor))
            output.extend(ys[:take])
            state = snapshots[take]
            if take and state.count % cadence == 0:
                evict(state, budget, ops)
            cursor += take
            if take < width:
                break
    else:
        snapshots, ys = block_forward(state, tokens, ring_size, ops)
        output = ys[:accepted]
        if mode in ('crop_only', 'metadata_restore_only'):
            state = snapshots[-1]
            if state.count//cadence > start.count//cadence:
                evict(state, budget, ops)
            # Crop rejected positions only. This cannot restore an old token
            # overwritten by tentative compaction.
            state.entries = [e for e in state.entries if e[0] < start.count+accepted]
            state.count = start.count+accepted
            if mode == 'metadata_restore_only':
                accepted_snapshot = snapshots[accepted]
                state.qcount = accepted_snapshot.qcount
                state.ring = accepted_snapshot.ring
                state.dropped, state.events = start.dropped, start.events
                # If accepted work itself crossed an event, exact replay of
                # those evictions is still absent. This intentionally isolates
                # how restoring metadata alone is insufficient.
        elif mode == 'accepted_only_deferred':
            state = snapshots[accepted]
            if state.count//cadence > start.count//cadence:
                evict(state, budget, ops)
        else:
            raise ValueError(mode)
    # Explicit convention: every block has one correction or bonus input whose
    # KV is computed next. Merely sampling it would not advance the counter.
    output.append(serial_step(state, bonus, cadence, ring_size, budget, ops))
    return state, output, ops


def state_record(s):
    return {'entries':s.entries, 'logical_count':s.count, 'query_count':s.qcount,
            'query_ring':s.ring, 'dropped':s.dropped, 'eviction_events':s.events,
            'physical_position_map':[(e[0], i) for i, e in enumerate(s.entries)]}


def sigmoid(x):
    return 1/(1+math.exp(-float(x)))


def witnesses():
    # All-accepted boundary crossing: the current query's output is computed
    # before its eviction. The following query must see the reduced cache.
    full = [('a',0,-1), ('b',1,1), ('d',0,0), ('c',0,0)]
    compressed = [full[i] for i in (1,2,3)]
    z = lambda xs: sum(w*v for w,(_,_,v) in zip(weights(-1,xs,base=3),xs))
    serial, deferred = z(compressed), z(full)
    assert serial == F(1,7) and deferred == F(-1,5)
    # Explicit rejection: rejected query at a boundary keeps b, destroys a.
    # All tentative inputs are rejected; cropping removes d but cannot restore a.
    old = [('a',0,-1), ('b',1,1)]
    after_tentative_eviction_then_crop = [('b',1,1)]
    correct = sum(w*v for w,(_,_,v) in zip(weights(-1,old,base=3),old))
    broken = sum(w*v for w,(_,_,v) in zip(weights(-1,after_tentative_eviction_then_crop,base=3),after_tentative_eviction_then_crop))
    assert correct == F(-1,2) and broken == 1
    return {
        'all_accepted_boundary':{'serial_readout':str(serial),'deferred_readout':str(deferred),
            'serial_probability0':sigmoid(serial),'deferred_probability0':sigmoid(deferred),
            'total_variation':abs(sigmoid(serial)-sigmoid(deferred)),'greedy_flips':True},
        'rejected_destructive_eviction':{'committed_before':['a','b'],'naive_after_crop':['b'],
            'correct_next_readout':str(correct),'naive_next_readout':str(broken),
            'lost_committed_token':'a','repair':'Do not destructively evict before acceptance; crop alone has no inverse.'}}


def work_counts():
    rows=[]
    # Count every canonical boundary phase, not a lucky aligned phase only.
    for cadence, width in itertools.product((16,32,128),(2,4,8,16)):
        allowed=[min(width,cadence-phase) for phase in range(cadence)]
        # Repeated all-accepted blocks starting exactly at a canonical boundary.
        remaining, count, calls, terms = 4096, 0, 0, 0
        while remaining:
            w=min(width,cadence-count % cadence,remaining)
            # Start each interval with B=4 entries; no reprocessing at its edge.
            terms += sum(4+count % cadence+i+1 for i in range(w))
            count+=w; remaining-=w; calls+=1
        serial_terms=sum(4+(i % cadence)+1 for i in range(4096))
        assert terms == serial_terms
        rows.append({'cadence':cadence,'width':width,'uniform_phases':cadence,
            'phases_clipped':sum(w<width for w in allowed),
            'uniform_phase_clip_frequency':sum(w<width for w in allowed)/cadence,
            'uniform_phase_mean_lost_slots':sum(width-w for w in allowed)/cadence,
            'uniform_phase_lost_slot_fraction':sum(width-w for w in allowed)/(cadence*width),
            'committed_input_positions':count,'aligned_capped_query_rows':count,
            'aligned_serial_query_rows':count,'aligned_capped_verification_calls':calls,
            'aligned_uncapped_verification_calls':math.ceil(count/width),
            'aligned_serial_verification_calls':count,
            'aligned_capped_attention_terms':terms,'aligned_serial_attention_terms':serial_terms,
            'aligned_eviction_events':count//cadence,'observation_window':8,
            'aligned_capped_scoring_terms':(count//cadence)*8*(4+cadence),
            'aligned_serial_scoring_terms':(count//cadence)*8*(4+cadence),
            'aligned_ungated_query_ring_writes':count,
            'aligned_window_gated_query_ring_writes':(count//cadence)*8,
            'observation_queries_needed_per_interval':8,
            'observation_fraction':8/cadence})
    return rows


def write_csv(name, rows):
    with (ROOT/name).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys())
        writer.writeheader();writer.writerows(rows)


def main():
    protocol=json.loads((ROOT/'protocol.json').read_text())
    p=protocol['C']
    rows=[]
    for seed,cadence in itertools.product(p['seeds'],p['cadences']):
        phases=range(cadence) if cadence<128 else [0,119,120,121,122,123,124,125,126,127]
        for phase in phases:
            rng=random.Random(seed*100000+cadence*1000+phase)
            draw=lambda:(rng.randint(-2,2),rng.randint(-2,2),rng.randint(-3,3))
            prompt=[(-4+i,rng.randint(-2,2),rng.randint(-3,3)) for i in range(4)]
            state=State(prompt)
            for _ in range(phase):
                serial_step(state,draw(),cadence,min(8,cadence),4,counters())
            for width in p['widths']:
                tokens=[draw() for _ in range(width)]
                bonus=draw()
                for accepted in range(width+1):
                    ref,ys,_=evaluate(state,tokens,accepted,bonus,cadence,'serial')
                    for mode in p['arms'][1:]:
                        test,zs,ops=evaluate(state,tokens,accepted,bonus,cadence,mode)
                        exact_deltas=[abs(x-y) for x,y in zip(ys,zs)]
                        row={'seed':seed,'cadence':cadence,'phase':phase,'width':width,
                            'accepted':accepted,'arm':mode,
                            'all_accepted':accepted==width,
                            'accepted_crosses_boundary':(phase+accepted)//cadence>phase//cadence,
                            'tentative_crosses_boundary':(phase+width)//cadence>phase//cadence,
                            'state_equal':test==ref,'entries_equal':test.entries==ref.entries,
                            'ring_equal':test.ring==ref.ring,'qcount_equal':test.qcount==ref.qcount,
                            'dropped_equal':test.dropped==ref.dropped,'events_equal':test.events==ref.events,
                            'outputs_exact_equal':ys==zs,'max_readout_abs':float(max(exact_deltas)),
                            'bonus_readout_abs':float(exact_deltas[-1]),
                            'max_binary_TV':max(abs(sigmoid(x)-sigmoid(y)) for x,y in zip(ys,zs)),
                            'greedy_disagreements':sum((x>=0)!=(y>=0) for x,y in zip(ys,zs)),**ops}
                        rows.append(row)
                        if mode=='boundary_capped_transactional':
                            assert ys==zs and test==ref, (seed,cadence,phase,width,accepted,row)
                        if not row['state_equal']:
                            target=ROOT/f'c_counterexample_{mode}.json'
                            if not target.exists():
                                target.write_text(json.dumps({'row':row,'initial':state_record(state),
                                    'draft_inputs':tokens,'accepted_prefix':accepted,'bonus_input':bonus,
                                    'serial_state':state_record(ref),'test_state':state_record(test),
                                    'serial_outputs':list(map(str,ys)),'test_outputs':list(map(str,zs))},indent=2)+'\n')
    write_csv('c_sweep.csv',rows)
    work=work_counts();write_csv('c_work_counts.csv',work)
    summary=[]
    for mode in p['arms'][1:]:
        g=[r for r in rows if r['arm']==mode]
        summary.append({'arm':mode,'cases':len(g),'state_mismatches':sum(not r['state_equal'] for r in g),
            'entry_mismatches':sum(not r['entries_equal'] for r in g),
            'ring_mismatches':sum(not r['ring_equal'] for r in g),
            'output_mismatches':sum(not r['outputs_exact_equal'] for r in g),
            'all_accepted_output_mismatches':sum(r['all_accepted'] and not r['outputs_exact_equal'] for r in g),
            'max_readout_abs':max(r['max_readout_abs'] for r in g),
            'max_binary_TV':max(r['max_binary_TV'] for r in g),
            'greedy_disagreements':sum(r['greedy_disagreements'] for r in g),
            'no_crossing_no_rejection_cases':sum(not r['tentative_crosses_boundary'] and r['all_accepted'] for r in g),
            'no_crossing_no_rejection_state_mismatches':sum(not r['tentative_crosses_boundary'] and r['all_accepted'] and not r['state_equal'] for r in g)})
    assert all(r['no_crossing_no_rejection_state_mismatches']==0 for r in summary)
    result={'evidence_class':protocol['evidence_class'],
        'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),
        'rows':len(rows),'summary':summary,'witness':witnesses(),'work_counts':work,
        'conclusion':'Reject C as a new method on this gate. Exact boundary-capped accepted-state transactions close the toy semantic defect. Integration costs and GPU speed remain unmeasured.'}
    (ROOT/'c_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'summary':summary,'witness':result['witness']},indent=2))


if __name__=='__main__':
    main()
