# A/C CPU elimination results

Executed 2026-10-03 UTC. **Reject both as main-method candidates at this gate. No model download or GPU expansion is justified by these results.** The known, simple controls close the proposed semantic defects. Neither downstream language-model quality nor serving speed was measured.

This is new executed evidence, distinct from a software passing-test count: a declared input factorial for A, exact rational counterexamples and state comparisons for C, plus exhaustive cadence arithmetic. [protocol.json](protocol.json) was written before execution. The bounded screen used existing Python/NumPy only. No dependencies, pretrained assets, commits, or remote mutations were made.

## A: two elementary fixes remove the constructed instability

### Executed design

The grid has 240 generated input states per precision: seeds 0–9; 2/7 query heads sharing one KV head; 16/64/128 keys; dimensions 64/128; clipped Gaussian and clustered keys. Each state has eight observation queries, eight protected recent keys, budget `max(10,N//4)`, and one seeded translation direction with RMS one. Common-key shifts have scales 0, 0.25, 2, 8, 32. Every visible key, including the current/protected keys, is shifted after the hypothetical RoPE step. Values are unchanged. Attention is evaluated for the final query, which sees every key.

The four factorial arms cross raw-logit max versus per-head softmax-first max, with uncentered versus mean-centered redundancy keys. Centering affects scoring only. Controls are centered mean-head attention, uniform positions, fixed random positions, and no eviction. All compressed arms use the same budget, recency protection, original-position tie break, and output dtype. The random and uniform masks do not change under translation.

### Measured contrast

There are 960 nonzero-shift comparisons per arm and precision, drawn from the same 240 states. These correlated artificial comparisons are **not** estimates of real-model failure prevalence.

| Arm | Changed retained sets, FP64 | Changed retained sets, FP32 | FP64 mean retained Jaccard |
|---|---:|---:|---:|
| Raw max, uncentered keys | 878 / 960 | 878 / 960 | 0.6267 |
| Raw max, centered redundancy | 678 / 960 | 678 / 960 | 0.7384 |
| Softmax first, uncentered redundancy | 849 / 960 | 849 / 960 | 0.7507 |
| Softmax first, centered redundancy | **0 / 960** | **0 / 960** | **1.0000** |
| Mean-head, centered redundancy | 0 / 960 | 0 / 960 | 1.0000 |

The result is not confined to scale-32 stress: at scale 0.25, the first three arms changed 203, 125, and 194 of 240 FP64 retained sets, respectively. The fully corrected arm changed none. The experiment does not establish whether a scale of 0.25 is representative of natural post-RoPE key means.

Across the grid, maximum dense-readout drift was 1.435e−14 in FP64 and 5.216e−6 in FP32. Maximum compressed-readout drift reached 2.668 in the softmax-first/uncentered arm. With both fixes it stayed at 1.755e−14 / 7.228e−6. There were no FP64 cutoff ties. The raw/uncentered FP32 arm had two exact-cutoff-tie comparisons; the corrected arm had none. Every changed selection failed the sufficient stability condition `cutoff gap > 2*score perturbation`, as it should.

### Counterexamples and interpretation

The scalar witness is executed in both precisions: queries `(2,−1)`, keys `(1,0)`, values `(1,0)`. A key shift of −2 leaves per-head attention unchanged but changes raw-head-max retention from the first token to the second. Its compressed readout changes from 1 to 0. A nonzero-key variant also flips. Both softmax-first and per-query logit centering remove this example.

The one-fix residual witnesses are saved with full inputs. In seed 0, heads 2, N=16, d=64, Gaussian data:

- Centering alone, shift scale 2: old-token selection changes `{2,3}` to `{3,4}`; compressed readout drift is 1.665, while dense drift is 3.539e−16
- Softmax-first alone, shift scale 0.25: old-token selection changes `{1,3}` to `{0,1}`; compressed drift is 0.291, while dense drift is 2.221e−16

The algebra needs no external theorem: adding a common key vector adds a query-specific constant to all logits, canceled by that query's softmax. Taking a maximum over heads before softmax mixes different constants. Separately, uncentered cosine similarity is not translation invariant; subtracting the common key mean removes the shift. The deterministic nonlinear redundancy and token-pooling steps then receive unchanged inputs in exact arithmetic.

**Decision:** reject the method claim. The two elementary controls explain the specified mechanism. The synthetic original-state readout RMSE is essentially tied across methods: corrected 0.2544, raw/uncentered 0.2544, random 0.2543. This is not quality evidence, particularly because values are synthetic and unrelated to a learned task. Being invariant does not establish a better quality/byte frontier. No HeadQ result or novelty premise is used.

## C: exact serial semantics need both acceptance and boundary discipline

### Executed design

The one-layer state machine uses integer queries/keys in [−2,2], values in [−3,3], and exact rational attention weights proportional to `2**(query*key)`. It retains four entries, protects the newest, and scores old entries by the last `min(8,cadence)` queries. Positions deterministically break ties. This is a deliberately simple online policy, **not** an R-KV implementation or a speculative-sampling implementation.

Four seeds, cadences 2/8/128, verification widths 2/4/8, declared boundary phases, and every accepted-prefix length give 1,360 scenarios per arm. Each scenario also processes one canonical correction/bonus input. Cadence counts KV-computed input positions; a token merely sampled but not yet forwarded does not advance it. The simulator compares outputs, retained original positions and physical positions, query-ring contents, query count, dropped-token count, and eviction events against serial execution of the same accepted input trace.

| Arm | State mismatches | Output mismatches | All-accepted output mismatches |
|---|---:|---:|---:|
| Destructive tentative compaction, then KV crop | 1,227 / 1,360 | 888 | 108 |
| Restore accepted metadata, but lost KV stays lost | 920 / 1,360 | 888 | 108 |
| Accepted-only metadata, deferred compaction | 351 / 1,360 | 356 | 108 |
| Boundary-capped accepted-state transaction | **0 / 1,360** | **0** | **0** |

All 104 no-crossing/no-rejection scenarios matched for every arm. A separate append-only block/serial control and a rejected-suffix-independence check also passed. These are exact Fraction equalities; numerical tolerances cannot explain the unsafe-arm failures.

### Two actual counterexamples

1. **All accepted:** use key/value pairs `a=(0,−1), b=(1,1), d=(0,0)`. At the boundary, query `ln(3)` retains b and protected d. The next query `−ln(3)` appends `c=(0,0)`. Serial eviction gives exactly `1/7`; deferred eviction gives `−1/5`. Mapping readout z to logits `[z,0]` gives probabilities 0.535654 versus 0.450166, TV 0.085488, and a greedy flip. The implementation uses exact base-3 rational weights rather than approximating the logarithms.
2. **Rejected tentative eviction:** committed a/b become b/d after tentative boundary scoring; d is then rejected. Cropping d leaves only b and cannot restore a. The next query `−ln(3)` gives 1 instead of the correct `−1/2`.

Boundary capping allows no eviction until a whole accepted prefix has reached the canonical event. Between events, the target is append-only and causal. Committing only accepted KV/query metadata gives the same state as serial execution; applying the same deterministic eviction then preserves equality inductively. The simulator uses ordinary snapshots to inspect this contract. Its Python copying cost is not a proposed serving implementation or a measured transaction cost.

### Operation counts and the stopping decision

For cadence 128 and width 8, enumerating every initial phase gives seven clipped phases of 128 (5.46875%). Mean lost proposed slots are 0.21875 per block, or **2.734375% of width**. This describes unused proposed parallel capacity, not measured latency or additional attention FLOPs.

For 4,096 aligned, all-accepted computed positions at cadence 128/width 8: capped verification takes 512 calls versus serial's 4,096; both compute 4,096 query rows, 280,576 attention key terms, 33,792 toy scoring terms, and 32 evictions. There is no duplicated attention/scoring work in this aligned control. Recording only the final eight observation queries per interval would require 256 ring writes instead of 4,096; that is optional accounting, not an implemented source optimization.

Short cadences matter: cadence 16/width 16 loses 46.875% of proposed slots under the same independent uniform-phase model. Actual acceptance, phase correlation, launch overhead, compaction cost, bonus-token scheduling, and multilayer execution are unmeasured. The saved row counters include rejected-work costs in the exact-state sweep; the aligned cadence example does not model rejections or the extra separately processed bonus inputs.

**Decision:** reject C as a new method at the stated 128/8 gate. The obvious exact control closes the demonstrated semantic gap, and the declared counts expose no need for a novel reversible-eviction method there. This does not prove universal negligible cost. A real integration proposal would first need a measured case where the safe control is materially inadequate. This screen does not justify acquiring models or GPUs to search for that case.

## Source boundary and reproducibility

Read-only source inspection pins R-KV at `6715468b9872442be72e5c97322e4d9c9a2abf55`; retrieved file byte counts and SHA-256 are in [source_pins.json](source_pins.json).

- [HF utilities](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/HuggingFace/rkv/utils.py): raw-head reduction and cosine redundancy, including threshold 0.5, last-neighbor suppression, column mean, and redundancy softmax
- [HF scorer](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/HuggingFace/rkv/compression/r1_kv.py): protected observation window, kernel-7 pooling, weighted score; it already flags softmax-before-head-reduction. This screen uses lambda 0.1 consistently. NumPy FP64 is a mathematical reference; FP32 is a separate numerical check. No PyTorch bit-parity claim is made, and the source's forced-FP32 softmax is deliberately not imposed on the FP64 reference
- [vLLM support record](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/docs/OPTIMIZATIONS.md): speculative/multi-token decode is explicitly rejected because irreversible compaction precedes verification. The supported implementation is not alleged to silently fail
- [vLLM integration](https://github.com/Zefan-Cai/R-KV/blob/6715468b9872442be72e5c97322e4d9c9a2abf55/vLLM/rkv/integration.py): token/query ring and logical-versus-physical state motivate the simulator's state contract. Its scoring/aggregation is not assumed identical to the HF path
- [R-KV paper v3, hyperparameters](https://arxiv.org/html/2505.24133v3): the declared reference cadence/window is 128/8. The screen does not reproduce its reported model results

From the repository root:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python research/diagnostics/candidate_elimination/run_a.py
python research/diagnostics/candidate_elimination/run_c.py
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s research/diagnostics/candidate_elimination -p 'test_*.py' -v
```

[a_results.json](a_results.json), [a_sweep.csv](a_sweep.csv), [c_results.json](c_results.json), [c_sweep.csv](c_sweep.csv), and [c_work_counts.csv](c_work_counts.csv) contain the results. Saved counterexamples include their complete inputs and mismatched outputs/states. Eight focused implementation audits are recorded in [contracts.log](contracts.log); they are not treated as experimental sample size. [reproduction.json](reproduction.json) records exact artifact hashes and the bounded deterministic rerun check. No existing project implementation was changed.
