"""Small implementation audits; test count is not scientific evidence."""
import copy
import json
import random
import unittest
from pathlib import Path

import numpy as np

import run_a as a
import run_c as c


class Contracts(unittest.TestCase):
    def test_exact_raw_pool_witness(self):
        w=a.witness()
        self.assertEqual(w['nonzero_rawmax_ids'],[0,1])

    def test_similarity_against_scalar_transcription(self):
        for centered in (False,True):
            k=np.array([[0.,0.],[1.,1.],[-1.,2.],[2.,2.],[1.,0.]])
            z=k-k.mean(0) if centered else k
            z=z/(np.sqrt((z*z).sum(1))[:,None]+1e-8)
            s=np.zeros((len(z),len(z)))
            for i in range(len(z)):
                for j in range(len(z)):
                    if i!=j:
                        s[i,j]=sum(z[i,d]*z[j,d] for d in range(z.shape[1]))
                candidates=[j for j in range(len(z)) if s[i,j]>0.5]
                s[i,max(candidates,default=0)]=0
            expected=a.softmax(np.array([sum(s[i,j] for i in range(len(z)))/len(z) for j in range(len(z))]))
            np.testing.assert_allclose(a.redundancy(k,centered),expected,rtol=1e-14,atol=1e-14)

    def test_saved_a_counterexamples_recompute(self):
        for arm in ('rawmax_centered','softmaxfirst_uncentered'):
            x=json.loads((a.ROOT/f'a_counterexample_{arm}.json').read_text())
            q,k=np.array(x['queries']),np.array(x['keys'])
            mode,center=arm.split('_')
            selected=[]
            for t in (np.zeros(k.shape[-1]),np.array(x['translation'])):
                kk=k+t
                score=.1*a.importance(q@kk.T/np.sqrt(k.shape[-1]),mode,8)-.9*a.redundancy(kk,center=='centered')[:-8]
                selected.append(a.select(score,x['row']['budget'],8)[0].tolist())
            self.assertEqual(selected,[x['base_kept'],x['shifted_kept']])
            self.assertNotEqual(*selected)

    def test_append_only_block_matches_serial(self):
        # Includes metadata and explicitly no eviction, independent of cap logic.
        start=c.State([(-2,1,-1),(-1,-1,2)])
        tokens=[(q,q//2,q) for q in [2,-2,1,0,-1,2,0,-2]]
        for width in (1,2,4,8):
            state=copy.deepcopy(start)
            ys=[c.serial_step(state,t,128,8,4,c.counters()) for t in tokens[:width]]
            snapshots,zs=c.block_forward(start,tokens[:width],8,c.counters())
            self.assertEqual(ys,zs)
            self.assertEqual(state,snapshots[-1])

    def test_rejected_suffix_cannot_affect_exact_commit(self):
        start=c.State([(-4,1,1),(-3,-1,2),(-2,2,-1),(-1,0,0)])
        c.serial_step(start,(1,0,1),8,8,4,c.counters())
        prefix=[(1,1,-1),(0,0,2)]
        for accepted in (0,1,2):
            left=prefix+[(2,2,3)]*6
            right=prefix+ [(-2,-2,-3)]*6
            l,ly,_=c.evaluate(start,left,accepted,(1,0,0),8,'boundary_capped_transactional')
            r,ry,_=c.evaluate(start,right,accepted,(1,0,0),8,'boundary_capped_transactional')
            self.assertEqual(l,r);self.assertEqual(ly,ry)

    def test_saved_c_counterexamples_recompute(self):
        for mode in ('crop_only','metadata_restore_only','accepted_only_deferred'):
            x=json.loads((c.ROOT/f'c_counterexample_{mode}.json').read_text())
            s=x['initial']
            state=c.State([tuple(e) for e in s['entries']],s['logical_count'],s['query_count'],
                [tuple(e) for e in s['query_ring']],s['dropped'],s['eviction_events'])
            test,ys,_=c.evaluate(state,x['draft_inputs'],x['accepted_prefix'],x['bonus_input'],x['row']['cadence'],mode)
            self.assertEqual(list(map(str,ys)),x['test_outputs'])
            # JSON turns tuple entries into lists; normalize the diagnostic record.
            self.assertEqual(json.loads(json.dumps(c.state_record(test))),x['test_state'])

    def test_cadence_enumeration_formula(self):
        for row in c.work_counts():
            b,w=row['cadence'],row['width']
            self.assertEqual(row['uniform_phase_clip_frequency'],(w-1)/b)
            self.assertEqual(row['uniform_phase_lost_slot_fraction'],(w-1)/(2*b))
            self.assertEqual(row['aligned_capped_attention_terms'],row['aligned_serial_attention_terms'])
            self.assertEqual(row['aligned_capped_verification_calls'],row['aligned_uncapped_verification_calls'])

    def test_exact_fraction_witnesses(self):
        x=c.witnesses()
        self.assertEqual(x['all_accepted_boundary']['serial_readout'],'1/7')
        self.assertEqual(x['rejected_destructive_eviction']['correct_next_readout'],'-1/2')


if __name__=='__main__':
    unittest.main()
