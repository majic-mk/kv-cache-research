# Pooled-full calibration control v2: CPU evidence

This revision adds the missing pooled-full-context exact-map oracle beside the
regional scale oracle. It is a predeclared diagnostic intervention, not a new
compression method or evidence of regional gain. See the
[protocol](../../calibration_pooled_control_protocol_v2.md) and
[entrypoint guide](../../calibration_experiment.md).

## Frozen plans and historical preservation

- New schema: `echo_calibration_experiment_v2`
- LCC v2: `23928ebbedfec715ccec8b21c9819dc5973416237b7f48b3cd8ae34573a9dc9c`
- RepoBench-P v2: `c55daaf5d484aaeb6019765711b11f5d165f606767ed9334efc99542fd2e22f2`
- V1 plans, safe summaries, logs and hashes under `../calibration_experiment/`
  remain unchanged. Their source is commit `c96b250`; current v2 intentionally
  rejects v1 input. Tests reconstruct and verify both original v1 plan hashes
- All scoring/prefill/reconstruction counts remain unchanged. Nine downstream
  arms mean 18 LCC and nine RepoBench-P query-cache clones, including one extra
  generation per question. The pooled oracle reuses the existing full capture

`lcc.dry_run.json` and `repobench-p.dry_run.json` are safe summaries. Private
`*.plan.json` files contain reversible benchmark tokens and remain ignored;
do not include them in a source artifact. Default `run` validated both plans
without importing model libraries, loading weights, or executing a model.

## Validation scope

Final scoped regressions:

- Full pilot in the existing native CPU environment: 171 passed
- Dependency-light pilot: 166 passed and five expected optional-native skips
- Calibration methods: 61 passed, including 20 new focused control tests
- Calibration arithmetic: 29 passed
- General harness: 46 passed
- Dedicated 31-test screen subset passed and is already included in the pilot

That is 307 distinct rerun test cases, with environment/subset repeats counted
once. This is a scoped regression total, not a refreshed whole-project aggregate.

`execution_results.json` records exact CPU commands, counts, exits, durations and
log hashes. `validation.json` records source hashes and evidence boundaries.
Dedicated screen subsets overlap the full pilot suite and must not be counted
twice. Historical 333-test aggregate results belong to the previous checkpoint;
this directory does not claim that old aggregate has been fully rerun.

Tests cover pooled/regional actual multiset comparison, source/target/output
ties, ordering and fixed-position invariants, cutoff head-budget bounds and within-head token-swap ambiguity, frozen
mask-only tie sensitivities, exact sparse/full agreement, identical paid scoring,
independent query clones, no oracle rescoring, v1 preservation/v2 rejection,
recomputed archive and claim flags, and full quality denominators even for known
confounded fixtures. Rehashing modified scores or interpretation flags does not
bypass offline validation.

The native suite uses the existing CPU Torch / Transformers environment and a
random 22,720-parameter Qwen architecture with synthetic token inputs. It patches
GPU timing and loader gates explicitly; no pretrained checkpoint or real-model
completion is produced. All rerun commands set `CUDA_VISIBLE_DEVICES` empty.
No GPU, model weight download, package installation, paid resource, commit or
push was used for this revision. The independent review found and fixed a within-head cutoff-tie token-swap
confound; the final gate conservatively flags all ambiguous P/R cutoff
membership. Native CPU model execution tests software plumbing only. There is no measured regional benefit, causal-content result,
novel method, physical memory saving, serving speedup or scientific generality.

## Later whole-project packaging verification

The scoped author results above remain unchanged. The subsequent [whole-project CPU checkpoint](../checkpoint_v2_20261003/README.md) reruns all eight distinct suite families and records the refreshed aggregate separately. Historical v1 evidence is preserved byte-for-byte.
