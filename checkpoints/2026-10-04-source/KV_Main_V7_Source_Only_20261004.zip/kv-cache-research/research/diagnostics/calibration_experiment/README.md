# Calibration experiment CPU evidence

The dry-run summaries and validation record contain safe counts, plan/source
digests, and test evidence only. `*.plan.json` is intentionally ignored: those
local generated plans embed reversible natural benchmark context/replay token IDs
and are not included in Git or the checkpoint ZIP.

Recreate private plans after [pinned data preparation](../../../data_prep/README.md)
using the [freeze and validation commands](../../calibration_experiment.md).
The recorded plan digests remain the target for the same frozen recipe.

The source review fixed and retested four defect groups. Historical validation
records describe the pre-commit snapshot; the latest aggregate software counts,
source hashes and limits are in [the checkpoint report](../checkpoint_20261003/README.md).
No real-model baseline or GPU experiment has been executed.
