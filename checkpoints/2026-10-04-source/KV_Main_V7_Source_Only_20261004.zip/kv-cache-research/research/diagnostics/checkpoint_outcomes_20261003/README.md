# Outcome checkpoint verification and boundaries

Date: 2026-10-03 UTC. This packaging pass performs **no pretrained model load,
model forward, experiment rerun, GPU action, rental or dependency installation**.
It retains completed/failing/unrun research evidence and checks saved artifacts.

## Research outcomes are separate from software tests

- A/C: saved artificial input/state sweeps close the specified main-method ideas
  against elementary controls. Independent reaggregation of all 19,200 A CSV rows
  and 5,440 C CSV rows found no summary mismatch. These correlated constructed
  comparisons do not estimate natural-model failure prevalence
- B: independent scalar recalculation of all 56,160 saved allocation rows and
  234 grouped summaries found no byte/budget mismatch. Both complete saved
  allocation sweeps are byte-identical. This is physical NumPy backing-buffer
  evidence with its stated exclusions, not downstream quality or serving latency
- HYPIC Gate 0: preserve 101 math fixtures and 32 tiny-random-HF checks as the
  earlier corrected-reference result. The reviewed source-contract defect and
  contextual warmup prevent relabeling that reference as released-code fidelity
- 0.8B/FP32: preserve one wrong full-recompute answer and 15 unrun cells, plus the
  earlier pre-forward logging failure and logging-only retry. No exact/reuse
  conclusion follows
- 2B/BF16: preserve two correct red answers but failed exact-schedule numerical
  checks; 14 cells unrun. The no-forward saved-logit audit exactly reproduced
  candidate sums, greedy IDs, TV and −0.1250469423-nat margin drift versus 0.01.
  Arithmetic scheduling versus a native cached-path implementation issue remains
  unisolated. No additional pretrained diagnostic forwards were made

No released-HYPIC comparison, held-out/reuse/donor/repair matrix, main-method
innovation, useful quality benefit, physical KV saving or serving speedup is
established. The user has paused GPU work. CNY100 remains a ceiling only, with
CNY0 attributable spend; existing AutoDL resources remain off limits. No stopped
cell, new model, precision rescue or relaxed threshold is released by packaging.

## Model-free checks rerun for this package

| Scope | Passed in the documented environment | Skipped |
|---|---:|---:|
| Standard-library harness | 46 | 0 |
| A/C implementation contracts | 8 | 0 |
| Shared-prefix buffer contracts | 13 | 0 |
| Projection synthetic byte fixtures | 14 | 0 |
| Frozen hybrid protocol v1 | 13 | 0 |
| Frozen hybrid protocol v2 | 16 | 0 |
| Frozen hybrid protocol v3 | 13 | 0 |

These are 123 distinct **model-free software cases**, not additional research
trials. The initial base-Python projection attempt had 13 passes and one error
because `safetensors` was missing. Its complete log is retained. The unchanged
14 tests then passed in the already existing `/tmp/hybrid_recurrence_cpu_env`;
no package was installed and no model instantiated. `model_free_validation.json`
records both attempts rather than silently treating the first as skipped/passed.

The earlier 360-test calibration aggregate belongs to commit `36e6705` and was
not fully rerun. Its original passed/skipped details remain historical. Its two
temporary native environments are now absent; the current hybrid environment
has different Transformers pins. Counts are not merged across those snapshots.

## Frozen files and no-forward raw verification

- `frozen_artifact_verification.json` records 72 direct current hash/size checks,
  including all protocol v1/v2/v3 frozen files, audited source/selected artifact
  manifests, raw-logit digests and admitted runner/watchdog/review identities
- A separate independent audit checked 180 preserved manifest/hash/size entries
  across those research scopes and older source provenance, and independently
  reaggregated the raw A/B/C saved outcomes as described above
- `shared_prefix_saved_output_audit.json` is the standalone saved-row byte audit
- `bf16_saved_logits_audit.json` exactly reproduces both completed cells' scores
  from saved BF16 tensors with FP32 score promotion; model loads/forwards are zero
- Historical freeze files and admitted executable sources remain unchanged;
  outcome reports are outside their immutable pre-run declarations
- Vendored HYPIC and Transformers source headers remain intact. Full pinned
  upstream licenses and attribution/provenance are under
  `../hybrid_recurrence_cpu/sources/`

Exactly four tracked files under
`outputs/hybrid_cpu_competence_v3/qualification_run/` make the unchanged no-forward
verifier portable: `cells.jsonl`, `summary.json`, and the two `*_raw_logits.pt`
files. They contain project-authored constructed fixtures and output tensors,
not checkpoint weights. The verifier uses CPU `torch.load(weights_only=True)`.
All other outputs, pretrained weights, wheelhouses, environments, external
benchmark token/text data, credential material and private user files are excluded.

To reproduce only the saved-logit audit in an appropriate CPU Torch environment:

```sh
CUDA_VISIBLE_DEVICES='' /path/to/cpu-python \
  research/diagnostics/hybrid_cpu_competence_v3/verify_saved_results.py
```

Do not invoke the stopped pretrained runners as part of verification. Raw local
weight/projection asset receipts are not asserted to have been re-downloaded or
revalidated against weights during this packaging pass.

The ZIP contains the Git-tracked tree, a complete local-history bundle, the
source commit and per-file byte/hash manifest. Bundle restoration and archive
inspection are separate delivery checks. No remote GitHub publication/grant
occurs; its prior partial remote verification remains historical.
