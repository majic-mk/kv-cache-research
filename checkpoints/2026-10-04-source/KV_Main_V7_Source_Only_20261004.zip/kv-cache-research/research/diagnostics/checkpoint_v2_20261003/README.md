# Reviewed nine-arm v2 CPU checkpoint

Date: 2026-10-03 UTC. Current protocol: `echo_calibration_experiment_v2`.
This is whole-project software verification after the pooled-full oracle review,
not model-quality evidence or release of a paid experiment.

## Current aggregate

| Suite | Passed | Skipped | Existing environment |
|---|---:|---:|---|
| General harness | 46 | 0 | Base Python |
| Pilot, dependency-light | 166 | 5 | Base Python; optional native imports unavailable |
| Pilot, native rerun | 171 | 0 | `/tmp/kv_tiny_qwen_cpu_20261003` |
| Pinned preprocessing | 15 | 0 | `data_prep/local/venv` |
| Calibration arithmetic | 29 | 0 | Base Python |
| Calibration methods/controls | 61 | 0 | Base Python + NumPy |
| Rejected backup-codec arithmetic | 6 | 0 | Base Python |
| Native tensor/archive operations | 20 | 0 | `/tmp/kv_native_cpu_20261003` |
| Tiny random-Qwen integration | 12 | 0 | `/tmp/kv_tiny_qwen_cpu_20261003` |
| Native calibration experiment subset | 5 | 0 | Native Qwen environment; already in pilot total |

**360 distinct cases passed, zero failures/errors**: 46 + 171 + 15 + 29 + 61 +
6 + 20 + 12. The light pilot's five optional skips passed in the native rerun.
The repeated pilot environment, 31 dedicated CPU screen tests, and five native
screen tests are not additional distinct cases. The review's 97 focused cases
are also subsets; its 240 array-property cases and 120 exhaustive cutoff-bound
checks are supplemental evidence, not extra unittest cases in this aggregate.

The six arithmetic cases for the previously rejected backup candidate remain
unrelated to Echo model readiness. Test counts are a software inventory, not a
statistical sample size or measure of research strength.

`execution_results.json` records exact commands, counts, exits, durations and log
hashes. Test output is retained in the adjacent `*.log` files. All reruns used
`CUDA_VISIBLE_DEVICES=''`, offline Hugging Face/Transformers settings and one
OMP/MKL thread. `native_environments.json` verifies CPU Torch 2.9.1+cpu and NumPy
2.2.6, with Transformers 5.2.0 in the Qwen environment; both passed `pip check`.
No dependency installation occurred. Native suites were rerun directly through
unittest so earlier diagnostic reports were not overwritten.

## Other verified boundaries

- Final runtime source inventory matches the independent review:
  `7af83c6582e34e4dff4a654b7527b59ab9a0d0f8e410b8988ec6af4535f6e3b2`
- `source_integrity.json` pins runtime/code/test files and records byte equality
  of all 27 tracked historical v1 and first-checkpoint evidence files against
  `c96b250f40fb484077a7761c338e49300189f529`
- Both v2 frozen private plans passed default no-execution validation; safe
  count/digest summaries are adjacent. V1 identities remain historical and
  the current entrypoint rejects v1 rather than silently upgrading it
- Offline pinned-tokenizer verification passed for all 64 planned baseline-stage
  builds. None of those GPU builds has executed
- The inert budget scenario was recomputed; its prices/durations remain invented
  assumptions, not provider offers, timing measurements or a release
- Compile checks and `git diff --check` passed
- Intended source and reachable Git history were inspected for credential/private
  note patterns, excluded paths, large files, symlinks and reversible benchmark
  arrays. Generated natural-token plans, raw data, environments and weights are
  excluded. This bounded inspection is not a formal secret-detection proof

## What the control supports

The nine-arm screen adds a pooled-full-map oracle to the regional map. A review
counterexample showed that ties can exchange tokens within a region despite
identical head and regional budgets. The final gate flags any ambiguous pooled
or regional cutoff membership, including that case. Exact histogram transport,
fixed values, protection, ordering and budgets are checked rather than assumed.

Only a passing conditional gate supports a narrow regional-allocation contrast.
Numerically/tie-confounded cells remain in the cohort; raw differences are merely
descriptive. Even a clean positive oracle result would not establish semantic
content causality, sparse-anchor estimability, practical deployment, generality
or method novelty. The three development contexts cannot establish power or a
reliable general effect. CPU tests provide no observed downstream model result.

The literature follow-up established no substantive new compression method;
the backup follow-up found no genuinely distinct implementation-ready backup.
An independent-audit-cache idea remains theory-first and unproven. At most, a
small unchanged-baseline/diagnostic pilot is a possible next research-risk check,
after all existing execution gates. A requirement for established method novelty
before spending is not met. No positive or publishable result is promised.

## Delivery and remaining gates

This checkpoint is committed locally only and includes a clean source tree and
restorable local Git history. It does not update GitHub or grant repository
access. The last verified remote remains the partial prior checkpoint at 08:59
UTC, and the GitHub App selected-repository grant is pending explicit confirmation.

No GPU use, pretrained-weight download, rental or paid action occurred. Project
spend is CNY0 within the cumulative CNY100 approval; every existing AutoDL resource
remains excluded. AutoDL login was verified. The complete installed GPU profile,
staged assets, validated real-model baseline, final dynamic checkout quote and
resource-specific external shutdown control remain separate gates. A read-only
12:33 UTC offer showed one 32GB RTX 5090, 16 CPU cores, 90GB host RAM, 30GB
system/50GB data disks, CNY2.88/hour and displayed daily fee CNY0. The create
action initially boots the resource; a shutdown timer is available afterward.
Only the listing/page/documentation was checked, not an actual project timer.
Recheck inventory, rate and all fees before any future paid action. Experiments
are deferred. Dense masks do not establish physical KV savings or serving speedup.

The ZIP excludes token-bearing v1/v2 plans. Reproduce pinned local inputs and
regenerate private v2 plans using `research/calibration_experiment.md`. The bundle
preserves historical v1 source if that version needs inspection. Source/manifest
checksums establish byte consistency, not proof that an experiment occurred.
