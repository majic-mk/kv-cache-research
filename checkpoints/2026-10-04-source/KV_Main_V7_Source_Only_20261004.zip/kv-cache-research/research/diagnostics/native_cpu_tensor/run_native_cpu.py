"""Rerunnable CPU synthetic validation/report; no model loading or remote access."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


FILES = ["echo_pilot/analysis.py", "echo_pilot/calibration_runtime.py", "echo_pilot/runtime.py",
    "echo_pilot/contracts.py", "research/calibration_methods/contracts.py",
    "research/calibration_methods/methods.py", "research/calibration_methods/selection.py",
    "research/calibration_methods/diagnostics.py",
    "echo_pilot/vendor_audit/kvpress__utils.py",
    "echo_pilot/vendor_audit/kvpress__presses__base_press.py",
    "echo_pilot/vendor_audit/kvpress__attention_patch.py",
    "research/sources/echopress_39748e9/kvpress/presses/kvzip_press.py",
    "research/sources/echopress_39748e9/kvpress/presses/echo_press.py"]


def main():
    native_files = FILES
    before_hashes = {name: digest(ROOT / name) for name in native_files}
    import test_native_cpu_tensor as tests
    source_pins = []
    for manifest, base, transform in (
        (ROOT / "research/sources/echopress_39748e9/provenance.json", ROOT / "research/sources/echopress_39748e9", lambda s: s),
        (ROOT / "echo_pilot/vendor_audit/provenance.json", ROOT / "echo_pilot/vendor_audit", lambda s: s.replace("/", "__"))):
        for item in json.loads(manifest.read_text())["files"]:
            path = base / transform(item["path"])
            if str(path.relative_to(ROOT)) in native_files:
                if digest(path) != item["local_sha256"]:
                    raise RuntimeError(f"Audited source digest mismatch: {path}")
                source_pins.append({"path": str(path.relative_to(ROOT)), "sha256": digest(path),
                                    "source_url": item["source_url"]})
    torch = tests.torch
    if torch.version.cuda is not None or torch.__version__ != "2.9.1+cpu":
        raise RuntimeError("Use exactly the proposed 2.9.1 official CPU wheel for this diagnostic")
    torch.set_num_threads(1)
    torch.manual_seed(17)
    torch.use_deterministic_algorithms(True)
    with (HERE / "tests.log").open("w") as log:
        log.write("EVIDENCE: CPU SYNTHETIC native Torch tensors; no model/GPU quality evidence\n")
        outcome = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
    print((HERE / "tests.log").read_text())
    context, replay, model, built = tests.candidate(torch.bfloat16)
    payload = {"masked_key_indices": list(built.masks),
        "logical_keep_mask": torch.from_numpy(built.keep_mask.copy()).unsqueeze(1),
        "scores_before_protection": torch.from_numpy(built.calibration.scores.copy()).unsqueeze(1),
        "scores_used_for_selection": torch.from_numpy(built.calibration.scores.copy()).unsqueeze(1)}
    # Native synthetic serialized tensor artifacts, labelled by filename and report.
    compressed = HERE / "cpu_synthetic_compressed.pt"
    full = HERE / "cpu_synthetic_full.pt"
    torch.save(payload, compressed)
    torch.save({"masked_key_indices": [None, None]}, full)
    allocation = tests.LOAD_MASKS(compressed, context, 2, 2, {"n_sink": 2, "recent_tokens": 1}, False)
    assert tests.LOAD_MASKS(full, context, 2, 2, {"n_sink": 2, "recent_tokens": 1}, True) is None
    after_hashes = {name: digest(ROOT / name) for name in native_files}
    if before_hashes != after_hashes:
        raise RuntimeError("Source files changed during native validation; rerun on stable source")
    result = {
        "schema_version": 1,
        "evidence_kind": "cpu_synthetic",
        "result_scope": "Real CPU torch tensors, native serialization, and source-executing synthetic adapter checks",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed" if outcome.wasSuccessful() else "failed",
        "tests": {"run": outcome.testsRun, "failures": len(outcome.failures), "errors": len(outcome.errors), "skipped": len(outcome.skipped)},
        "environment": {"python": platform.python_version(), "executable": sys.executable,
            "platform": platform.platform(), "torch": torch.__version__, "cuda_runtime": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(), "torch_threads": torch.get_num_threads(),
            "packages": dict(sorted((dist.metadata["Name"], dist.version) for dist in importlib.metadata.distributions()))},
        "archive_validation_entrypoint": "echo_pilot.analysis._torch_masks",
        "archive_load_options": {"map_location": "cpu", "weights_only": True},
        "archive_example": {"adapter_cache_dtype": "bfloat16", "archive_score_dtype": "float32", "logical_keep_shape": [2, 1, 2, 19],
            "original_pairs": 76, "retained_pairs": allocation["actual_retained_pairs"],
            "allocation": allocation,
            "files": {path.name: {"bytes": path.stat().st_size, "sha256": digest(path)} for path in (compressed, full)}},
        "native_adapter_dtypes_tested": ["float32", "float16", "bfloat16"],
        "native_archive_score_dtypes_tested": ["float16", "bfloat16", "float32", "float64"],
        "source_execution": "Audited source AST function/class bodies unedited; imports excluded and native torch plus synthetic type dependencies injected",
        "source_sha256": after_hashes,
        "source_stable_during_validation": True,
        "verified_author_sources": source_pins,
        "diagnostic_sha256": {name: digest(HERE / name) for name in ("test_native_cpu_tensor.py", "run_native_cpu.py", "tests.log")},
        "git_head_at_validation": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "claims": {"model_loaded": False, "model_quality_validated": False, "native_transformers_validated": False,
            "gpu_used": False, "native_gpu_validated": False, "physical_memory_savings_demonstrated": False,
            "gpu_performance_validated": False, "paid_resources_used": False},
        "limitations": [
            "Synthetic nn.Module and dense cache container; no installed Transformers or actual model architecture",
            "Qwen3 q_norm branch, HF DynamicCache behavior, full dependency imports, checkpoint compatibility, and CUDA kernels remain untested",
            "Eager CPU source math only; no Triton or torch.compile backend execution",
            "Archive validation helper tested directly; no fabricated completed real_model run or end-to-end real-model analysis",
            "Synthetic decoder sentinel validates interface/cleanup only, not answer quality",
            "Masked dense cache retains backing storage; logical pruning is not physical compaction",
            "One controlled install completed in /tmp; this is not a GPU environment or full dependency lock validation"
        ],
    }
    (HERE / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"evidence_kind": result["evidence_kind"], "status": result["status"], "tests": result["tests"]}))
    return 0 if outcome.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
