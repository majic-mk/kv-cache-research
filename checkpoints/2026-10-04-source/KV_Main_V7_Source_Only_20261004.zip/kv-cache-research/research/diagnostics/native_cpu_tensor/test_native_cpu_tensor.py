"""Native CPU Torch on tiny synthetic tensors, never model/GPU quality evidence.

Run from project root with the isolated CPU-only environment. Audited source AST
function/class bodies are unedited; imports are replaced with explicit real Torch
and synthetic type dependencies. No Transformers, checkpoint, CUDA, or network is
used by this test. The synthetic cache/model are not Transformers implementations.
"""
from __future__ import annotations

import ast
import copy
from contextlib import contextmanager
from dataclasses import dataclass, field
from functools import partial
import logging
import math
from pathlib import Path
import pickle
import sys
import tempfile
from types import MethodType, ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from echo_pilot import analysis
from echo_pilot.calibration_runtime import (
    COMMON_PROMPT, CalibrationBuildError, build_candidate,
    build_full_exact_diagnostic, clone_query_cache, install_keep_mask,
    logical_to_mask_indices, mask_indices_to_keep, prepare_common_replay,
    answer_candidate,
)
from echo_pilot.contracts import ContractError, PreparedContext
from echo_pilot.runtime import cache_bytes, independent_cache
from research.calibration_methods.contracts import AnchorPlan

# The current actual tensor archive validator is _torch_masks, not _load_masks.
LOAD_MASKS = analysis._torch_masks


def rotate_half(x):
    """Llama-form RoPE primitive; native Tensor ops, no imported model code."""
    left, right = x.chunk(2, dim=-1)
    return torch.cat((-right, left), dim=-1)


TYPE_STUBS = {name: type(name, (), {}) for name in (
    "QuantizedCache", "Gemma3Attention", "Qwen3Attention", "Phi3Attention",
    "Gemma3PreTrainedModel", "LlamaForCausalLM", "MistralForCausalLM",
    "Phi3ForCausalLM", "Qwen2ForCausalLM", "Qwen3ForCausalLM",
    "Gemma3ForConditionalGeneration")}


def load_source(name, path, **extra):
    """Execute unchanged source bodies, explicitly excluding import statements."""
    module = ModuleType(name)
    module.__dict__.update(logging=logging, math=math, contextmanager=contextmanager,
        dataclass=dataclass, field=field, partial=partial, MethodType=MethodType,
        torch=torch, nn=nn, rotate_half=rotate_half, HAS_TRITON=False,
        ALL_ATTENTION_FUNCTIONS={}, **TYPE_STUBS)
    module.__dict__.update(extra)
    tree = ast.parse(path.read_text())
    tree.body = [ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)] + [
        item for item in tree.body if not isinstance(item, (ast.Import, ast.ImportFrom))]
    ast.fix_missing_locations(tree)
    sys.modules[name] = module
    exec(compile(tree, str(path), "exec"), module.__dict__)
    return module


UTILS = load_source("_native_cpu_source_utils", ROOT / "echo_pilot/vendor_audit/kvpress__utils.py")
BASE = load_source("_native_cpu_source_base", ROOT / "echo_pilot/vendor_audit/kvpress__presses__base_press.py",
                   extract_keys_and_values=UTILS.extract_keys_and_values)
KVZIP = load_source("_native_cpu_source_kvzip", ROOT / "research/sources/echopress_39748e9/kvpress/presses/kvzip_press.py",
    BasePress=BASE.BasePress, SUPPORTED_MODELS=BASE.SUPPORTED_MODELS,
    get_query_states=UTILS.get_query_states, extract_keys_and_values=UTILS.extract_keys_and_values)
ECHO = load_source("_native_cpu_source_echo", ROOT / "research/sources/echopress_39748e9/kvpress/presses/echo_press.py",
    KVzipPress=KVZIP.KVzipPress, SUPPORTED_MODELS=BASE.SUPPORTED_MODELS,
    extract_keys_and_values=UTILS.extract_keys_and_values)
ATTENTION = load_source("_native_cpu_source_attention", ROOT / "echo_pilot/vendor_audit/kvpress__attention_patch.py")


class SyntheticCache:
    """Dense shape container only; this does not validate HF DynamicCache."""
    last = None
    def __init__(self):
        self.layers = []
        SyntheticCache.last = self
    def get_seq_length(self, index):
        return self.layers[index].keys.shape[2]


class SyntheticAttention(nn.Module):
    def __init__(self, index, config):
        super().__init__()
        self.layer_idx, self.config = index, config
        self.head_dim = 4
        self.q_proj = nn.Identity()
        self.masked_key_indices = None
        self.fail_replay = False
    def forward(self, hidden_states, past_key_values, position_embeddings):
        self.q_proj(hidden_states)  # Real PyTorch forward hooks capture this.
        b, t, _ = hidden_states.shape
        k = hidden_states.view(b, t, 2, 2, 4).mean(dim=3).transpose(1, 2)
        cos, sin = position_embeddings
        k = k * cos.unsqueeze(1) + rotate_half(k) * sin.unsqueeze(1)
        v = k.clone() + .125
        if len(past_key_values.layers) <= self.layer_idx:
            past_key_values.layers.append(SimpleNamespace(keys=k, values=v))
        else:
            layer = past_key_values.layers[self.layer_idx]
            layer.keys = torch.cat((layer.keys, k), dim=2)
            layer.values = torch.cat((layer.values, v), dim=2)
            if self.fail_replay:
                raise RuntimeError("injected native tensor replay failure")
        return hidden_states, None


class SyntheticBody(nn.Module):
    def __init__(self, config, dtype):
        super().__init__()
        self.dtype = dtype
        self.layers = nn.ModuleList([nn.Module() for _ in range(2)])
        for i, layer in enumerate(self.layers):
            layer.self_attn = SyntheticAttention(i, config)
        # Nonzero angles exercise real RoPE, in contrast to zero-angle mocks.
        self.rotary_emb = SimpleNamespace(inv_freq=torch.tensor([1., .1]))
        self.forward_ids = []
    def forward(self, input_ids, past_key_values, position_ids, **kwargs):
        self.forward_ids.append(tuple(input_ids[0].tolist()))
        hidden = ((input_ids[..., None] % 7 + torch.arange(16)[None, None, :] + 1) / 24).to(self.dtype)
        angles = position_ids[..., None] * self.rotary_emb.inv_freq
        angles = torch.cat((angles, angles), dim=-1)
        embeddings = angles.cos().to(self.dtype), angles.sin().to(self.dtype)
        for layer in self.layers:
            layer.self_attn(hidden_states=hidden, past_key_values=past_key_values, position_embeddings=embeddings)
        # A synthetic decoder sentinel, not a language prediction.
        return SimpleNamespace(logits=torch.tensor([[[0., 1.]]], dtype=self.dtype))


class SyntheticModel(nn.Module):
    def __init__(self, dtype=torch.float32):
        super().__init__()
        self.config = SimpleNamespace(num_hidden_layers=2, num_key_value_heads=2,
            num_attention_heads=4, _attn_implementation="sdpa", model_type="llama",
            max_position_embeddings=1000)
        self.dtype, self.device = dtype, torch.device("cpu")
        self.generation_config = SimpleNamespace(eos_token_id=1)
        self.model = SyntheticBody(self.config, dtype)
        self.eval()
    def forward(self, **kwargs):
        return self.model(**kwargs)


DEPS = SimpleNamespace(torch=torch, transformers=SimpleNamespace(DynamicCache=SyntheticCache),
    kvpress=SimpleNamespace(EchoPress=ECHO.EchoPress, KVzipPress=KVZIP.KVzipPress))


class SyntheticTokenizer:
    chat_template = "CPU synthetic template"
    def apply_chat_template(self, messages, **kwargs):
        return "PREFIX" + messages[0]["content"] + "SUFFIX"
    def encode(self, text, add_special_tokens=False):
        return {"PREFIX": [101, 102], "SUFFIX": [103], COMMON_PROMPT: [104, 105, 106]}[text]
    def decode(self, ids, skip_special_tokens=False):
        return "CPU synthetic decoder sentinel"


def fixture(dtype=torch.float32):
    context = PreparedContext("cpu-synthetic", "cpu-synthetic", (101, 102) + tuple(range(10, 27)),
        2, ({"region_id": "left", "start": 2, "end": 10},
            {"region_id": "right", "start": 10, "end": 19}), 19, {})
    replay = prepare_common_replay(context, SyntheticTokenizer(), microchunk_tokens=4,
        sink_tokens=2, tokenizer_id="cpu-synthetic/tokenizer", tokenizer_revision="a" * 40)
    return context, replay, SyntheticModel(dtype)


def candidate(dtype=torch.float32):
    context, replay, model = fixture(dtype)
    result = build_candidate(DEPS, model, SyntheticTokenizer(), replay,
        AnchorPlan(replay.partition, (1, 3), "random", 7), eviction_ratio=.4, recent_tokens=1)
    return context, replay, model, result


class NativeCpuArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "cpu_synthetic.pt"
        self.context, _, _ = fixture()
        self.selection = {"n_sink": 2, "recent_tokens": 1}
        self.keep = torch.ones(2, 1, 2, 19, dtype=torch.bool)
        self.keep[0, 0, 0, 3:7] = False
        self.keep[0, 0, 1, 11:13] = False
        self.keep[1, 0, :, 4:8] = False
        masks = [tuple(x.clone() for x in torch.where(~layer)) for layer in self.keep]
        self.payload = {"masked_key_indices": masks, "logical_keep_mask": self.keep,
            "scores_before_protection": torch.arange(76, dtype=torch.float32).view(2, 1, 2, 19) / 76,
            "scores_used_for_selection": torch.arange(76, dtype=torch.float32).view(2, 1, 2, 19) / 76}
    def load(self, payload=None, full=False):
        torch.save(self.payload if payload is None else payload, self.path)
        return LOAD_MASKS(self.path, self.context, 2, 2, self.selection, full)
    def test_real_archive_compressed_allocation_and_weights_only(self):
        with patch("torch.load", wraps=torch.load) as tracked:
            allocation = self.load()
        self.assertEqual(tracked.call_count, 1)
        self.assertEqual(tracked.call_args.kwargs, {"map_location": "cpu", "weights_only": True})
        self.assertEqual(allocation["actual_retained_pairs"], int(self.keep.sum()))
        self.assertEqual(allocation["retained_per_layer_head"], self.keep[:, 0].sum(-1).tolist())
        self.assertEqual(allocation["retained_prefix_pairs"], 8)
        for region in self.context.regions:
            expected = self.keep[:, 0, :, region["start"]:region["end"]]
            got = allocation["retained_per_region"][region["region_id"]]
            self.assertEqual(got["retained_pairs"], int(expected.sum()))
            self.assertEqual(got["retained_per_layer_head"], expected.sum(-1).tolist())
    def test_real_archive_compressed_native_float_dtypes(self):
        for dtype in (torch.float16, torch.bfloat16, torch.float32, torch.float64):
            with self.subTest(dtype=dtype):
                payload = copy.deepcopy(self.payload)
                for key in ("scores_before_protection", "scores_used_for_selection"):
                    payload[key] = payload[key].to(dtype)
                self.assertEqual(self.load(payload)["actual_retained_pairs"], int(self.keep.sum()))
    def test_real_archive_full_kv(self):
        self.assertIsNone(self.load({"masked_key_indices": [None, None]}, full=True))
    def test_real_archive_rejects_corrupt_keep_and_scores(self):
        changes = [
            ("keep dtype", lambda p: p.update(logical_keep_mask=p["logical_keep_mask"].float())),
            ("keep rank", lambda p: p.update(logical_keep_mask=p["logical_keep_mask"][:, 0])),
            ("keep mismatch", lambda p: p["logical_keep_mask"].fill_(True)),
            ("missing scores", lambda p: p.pop("scores_before_protection")),
            ("integer scores", lambda p: p.update(scores_before_protection=p["scores_before_protection"].long())),
            ("score rank", lambda p: p.update(scores_used_for_selection=p["scores_used_for_selection"][:, 0])),
            ("nan", lambda p: p["scores_before_protection"].fill_(float("nan"))),
            ("inf", lambda p: p["scores_used_for_selection"].fill_(float("inf"))),
        ]
        for label, change in changes:
            with self.subTest(case=label):
                payload = copy.deepcopy(self.payload)
                change(payload)
                with self.assertRaises(ContractError): self.load(payload)
    def test_real_archive_rejects_corrupt_coordinates(self):
        cases = {
            "non tuple": [torch.tensor([0]), torch.tensor([0]), torch.tensor([3])],
            "int32": tuple(torch.tensor([v], dtype=torch.int32) for v in (0, 0, 3)),
            "unequal lengths": (torch.tensor([0, 0]), torch.tensor([0]), torch.tensor([3])),
            "batch": tuple(torch.tensor([v]) for v in (1, 0, 3)),
            "head": tuple(torch.tensor([v]) for v in (0, 2, 3)),
            "negative": tuple(torch.tensor([v]) for v in (0, 0, -1)),
            "token past end": tuple(torch.tensor([v]) for v in (0, 0, 19)),
            "duplicate": (torch.tensor([0, 0]), torch.tensor([0, 0]), torch.tensor([3, 3])),
        }
        for label, coords in cases.items():
            with self.subTest(case=label):
                payload = copy.deepcopy(self.payload)
                payload["masked_key_indices"][0] = coords
                with self.assertRaises(ContractError): self.load(payload)
    def test_real_archive_rejects_evicted_protected_positions(self):
        for token in (0, 1, 18):
            with self.subTest(token=token):
                payload = copy.deepcopy(self.payload)
                payload["logical_keep_mask"][0, 0, 0, token] = False
                payload["masked_key_indices"][0] = torch.where(~payload["logical_keep_mask"][0])
                with self.assertRaisesRegex(ContractError, "Protected"): self.load(payload)
    def test_real_archive_rejects_invalid_full_kv_payloads(self):
        for payload in ({"masked_key_indices": [None]},
                        {"masked_key_indices": [None, None], "logical_keep_mask": None},
                        {"masked_key_indices": [None, None], "extra": torch.zeros(1)},
                        {"masked_key_indices": self.payload["masked_key_indices"]}):
            with self.subTest(keys=tuple(payload)):
                with self.assertRaises(ContractError): self.load(payload, full=True)
    def test_weights_only_rejects_non_allowlisted_object(self):
        torch.save({"masked_key_indices": [None, None], "object": SimpleNamespace(value=1)}, self.path)
        with self.assertRaises(pickle.UnpicklingError):
            LOAD_MASKS(self.path, self.context, 2, 2, self.selection, True)
    def test_empty_pruned_coordinates_and_none_supported(self):
        payload = {"masked_key_indices": [None, tuple(torch.empty(0, dtype=torch.int64) for _ in range(3))],
            "logical_keep_mask": torch.ones(2, 1, 2, 19, dtype=torch.bool),
            "scores_before_protection": torch.ones(2, 1, 2, 19),
            "scores_used_for_selection": torch.ones(2, 1, 2, 19)}
        self.assertEqual(self.load(payload)["actual_retained_pairs"], 76)


class NativeCpuAdapterTests(unittest.TestCase):
    def assert_clean(self, model):
        self.assertFalse(model.model._forward_pre_hooks)
        for layer in model.model.layers:
            self.assertFalse(layer.self_attn._forward_hooks)
            self.assertFalse(layer.self_attn.q_proj._forward_hooks)
    def test_sparse_full_native_tensor_scoring_and_dtype_capture(self):
        for dtype in (torch.float32, torch.float16, torch.bfloat16):
            with self.subTest(dtype=dtype):
                _, replay, model, sparse = candidate(dtype)
                full = build_full_exact_diagnostic(DEPS, SyntheticModel(dtype), SyntheticTokenizer(), replay, diagnostic_only=True)
                self.assertTrue(np.array_equal(sparse.virtual.values, full.virtual.values))
                self.assertTrue(np.array_equal(sparse.anchors.values, full.full_exact.values[..., sparse.anchors.plan.token_indices]))
                self.assertEqual(sparse.accounting["observed_forward_input_lengths"], [19, 8, 8])
                self.assertEqual(full.accounting["observed_forward_input_lengths"], [19, 8, 8, 8, 8, 5])
                self.assertEqual(sparse.accounting["exact_pre_storage_scalar_dtypes"], [str(dtype)])
                self.assertEqual(sparse.accounting["virtual_pre_storage_scalar_dtypes"], ["torch.float32"])
                self.assertEqual(sparse.virtual.values.shape, (2, 2, 19))
                self.assertEqual(sparse.anchors.values.shape, (2, 2, 8))
                self.assertEqual(sparse.keep_mask.sum(), 76-int(76*.4))
                self.assertTrue(sparse.keep_mask[..., :2].all())
                self.assertTrue(sparse.keep_mask[..., -1].all())
                self.assertEqual([sparse.cache.get_seq_length(i) for i in range(2)], [19, 19])
                self.assertFalse(sparse.accounting["physical_memory_savings_demonstrated"])
                self.assertFalse(full.accounting["deployable_cost"])
                self.assert_clean(model)
    def test_mask_device_indices_storage_and_clone_isolation(self):
        _, _, model, built = candidate(torch.bfloat16)
        keep_tensor = torch.from_numpy(built.keep_mask.copy())
        installed = install_keep_mask(torch, model, keep_tensor, built.cache)
        self.assertTrue(np.array_equal(mask_indices_to_keep(installed, (2, 2, 19)), built.keep_mask))
        self.assertTrue(all(t.dtype == torch.int64 and t.device.type == "cpu" for mask in installed for t in mask))
        for layer, mask in zip(model.model.layers, installed):
            self.assertTrue(all(a.data_ptr() != b.data_ptr() for a, b in zip(layer.self_attn.masked_key_indices, mask)))
        clone = clone_query_cache(DEPS, model, built)
        before = cache_bytes(built.cache)
        for source, copied in zip(built.cache.layers, clone.layers):
            self.assertNotEqual(source.keys.untyped_storage().data_ptr(), copied.keys.untyped_storage().data_ptr())
            self.assertTrue(torch.equal(source.keys, copied.keys))
        clone.layers[0].keys.zero_()
        self.assertTrue(bool(built.cache.layers[0].keys.abs().sum() > 0))
        self.assertEqual(cache_bytes(built.cache), before)
        self.assertEqual(before["kv_tensor_payload_bytes"], 2*2*2*19*4*2)
    def test_source_attention_patch_mutates_only_clone_and_preserves_layout(self):
        _, _, model, built = candidate(torch.float32)
        clone = clone_query_cache(DEPS, model, built)
        query = torch.linspace(.1, 1, 16).view(1, 4, 1, 4)
        original = built.cache.layers[0].keys.clone()
        bytes_before = cache_bytes(clone)
        patched = ATTENTION.attention_patch(lambda module, query, key, value, attention_mask, dropout, **kwargs: key)
        output = patched(model.model.layers[0].self_attn, query, clone.layers[0].keys, clone.layers[0].values, None, 0.)
        keep = torch.from_numpy(built.keep_mask[0].copy())
        self.assertTrue(torch.equal(output[0][keep], original[0][keep]))
        self.assertTrue(torch.equal(built.cache.layers[0].keys, original))
        for h in range(2):
            q = query[0, h*2:(h+1)*2, 0, :]
            logits = q @ output[0, h, ~keep[h]].T / math.sqrt(4)
            self.assertTrue(bool((logits.exp() == 0).all()))
        self.assertEqual(cache_bytes(clone), bytes_before)
        self.assertTrue(torch.equal(clone_query_cache(DEPS, model, built).layers[0].keys, original))
    def test_source_search_hyperplane_native_reduced_precision(self):
        for dtype in (torch.float16, torch.bfloat16, torch.float32):
            with self.subTest(dtype=dtype):
                q = torch.linspace(.1, 1, 32).view(2, 4, 4).to(dtype)
                fake = ATTENTION.search_hyperplane(q)
                self.assertEqual(fake.dtype, dtype)
                self.assertTrue(bool(torch.isfinite(fake).all()))
                self.assertTrue(bool(((q.float() @ fake.float().unsqueeze(-1)).exp() == 0).all()))
    def test_native_query_decoder_clears_masks_and_keeps_candidate_frozen(self):
        _, _, model, built = candidate()
        original = [layer.keys.clone() for layer in built.cache.layers]
        for ids in ((81, 82), (83,)):
            out = answer_candidate(DEPS, model, SyntheticTokenizer(), built, ids, max_new_tokens=4)
            self.assertEqual(out["generated_token_ids"], [1])
            self.assertTrue(out["stopped_on_eos"])
            self.assertTrue(all(layer.self_attn.masked_key_indices is None for layer in model.model.layers))
            self.assertTrue(all(torch.equal(layer.keys, old) for layer, old in zip(built.cache.layers, original)))
        self.assert_clean(model)
    def test_native_failed_replay_restores_storage_hooks_masks_and_accounting(self):
        _, replay, model = fixture()
        sentinel = (torch.tensor([0]), torch.tensor([0]), torch.tensor([5]))
        model.model.layers[0].self_attn.masked_key_indices = sentinel
        model.model.layers[1].self_attn.fail_replay = True
        with self.assertRaises(CalibrationBuildError) as caught:
            build_candidate(DEPS, model, SyntheticTokenizer(), replay,
                AnchorPlan(replay.partition, (1, 3), "random", 7), eviction_ratio=.4)
        self.assertEqual(caught.exception.accounting["observed_forward_input_lengths"], [19, 8])
        self.assertEqual(caught.exception.accounting["completed_exact_replay_passes"], 0)
        self.assertEqual(SyntheticCache.last.layers, [])
        self.assertIs(model.model.layers[0].self_attn.masked_key_indices, sentinel)
        self.assert_clean(model)
    def test_source_virtual_scoring_matches_direct_dense_softmax(self):
        torch.manual_seed(17)
        press = ECHO.EchoPress(n_sink=2, chunk_size=4, scoring_backend="torch_eager")
        press.context_length = 11
        press._inv_freq = torch.tensor([1., .1])
        module = SimpleNamespace(head_dim=4)
        for dtype in (torch.float32, torch.float16, torch.bfloat16):
            with self.subTest(dtype=dtype):
                q = torch.randn(1, 4, 11, 4).to(dtype)
                keys = torch.randn(1, 2, 11, 4).to(dtype)
                actual = press._chunk_scores(module, q, keys, 3, 7, 4)
                q1 = q[:, :, 3:7].view(1, 2, 2, 4, 4)
                q2 = press._rotate(q1.float(), 11+4-3).to(dtype)
                sink = keys[:, :, :2].unsqueeze(2).transpose(-2, -1)
                cached = keys[:, :, 3:7].unsqueeze(2).transpose(-2, -1)
                left = (q2*(1/math.sqrt(4))) @ sink
                middle = (q2*(1/math.sqrt(4))) @ cached
                right = ((q1*(1/math.sqrt(4))) @ cached).float()
                right.masked_fill_(torch.ones(4, 4, dtype=torch.bool).triu(1), float("-inf"))
                all_probs = torch.softmax(torch.cat((left.float(), middle.float(), right), dim=-1), dim=-1)
                expected = all_probs[..., 2:6].amax(dim=(0, 2, 3))
                torch.testing.assert_close(actual, expected, rtol=2e-6, atol=2e-7)
    def test_source_exact_attention_matches_dense_reference_and_causal_mask(self):
        torch.manual_seed(29)
        for dtype in (torch.float32, torch.float16, torch.bfloat16):
            with self.subTest(dtype=dtype):
                press = KVZIP.KVzipPress(n_sink=2, chunk_size=3)
                press.context_length, press.start_idx, press.end_idx = 11, 3, 6
                module = SimpleNamespace(layer_idx=0, config=SimpleNamespace(num_key_value_heads=2,
                    num_attention_heads=4), head_dim=4, q_proj=nn.Identity())
                hidden = torch.randn(1, 5, 16).to(dtype)
                keys = torch.randn(1, 2, 16, 4).to(dtype)
                angles = torch.arange(11, 16)[:, None] * torch.tensor([[1., .1]])
                angles = torch.cat((angles, angles), dim=-1).unsqueeze(0)
                cos, sin = angles.cos().to(dtype), angles.sin().to(dtype)
                actual = press._compute_cross_attention(module, hidden, keys,
                    {"position_embeddings": (cos, sin)})
                q = hidden.reshape(1, 5, 4, 4).transpose(1, 2)
                q = q * cos.unsqueeze(1) + rotate_half(q) * sin.unsqueeze(1)
                q = q.reshape(1, 2, 2, 5, 4)
                chosen = torch.cat((keys[..., :2, :], keys[..., 3:6, :], keys[..., 11:, :]), dim=2)
                logits = q @ chosen.unsqueeze(2).transpose(-2, -1) / math.sqrt(4)
                upper = torch.ones(5, 5, dtype=torch.bool).triu(1)
                logits[..., -5:].masked_fill_(upper, torch.finfo(dtype).min)
                expected = torch.softmax(logits, dim=-1)
                self.assertEqual(actual.shape, (1, 2, 2, 5, 10))
                torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                self.assertTrue(bool((actual[..., -5:][..., upper] == 0).all()))

    def test_selected_adapter_mask_roundtrips_native_analysis_archive(self):
        context, _, _, built = candidate(torch.bfloat16)
        payload = {"masked_key_indices": list(built.masks),
            "logical_keep_mask": torch.from_numpy(built.keep_mask.copy()).unsqueeze(1),
            "scores_before_protection": torch.from_numpy(built.calibration.scores.copy()).unsqueeze(1),
            "scores_used_for_selection": torch.from_numpy(built.calibration.scores.copy()).unsqueeze(1)}
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "adapter_cpu_synthetic.pt"
            torch.save(payload, path)
            allocation = LOAD_MASKS(path, context, 2, 2, {"n_sink": 2, "recent_tokens": 1}, False)
        self.assertEqual(allocation["actual_retained_pairs"], int(built.keep_mask.sum()))
        self.assertEqual(allocation["retained_per_layer_head"], built.keep_mask.sum(-1).tolist())

    def test_source_quantile_mapping_interpolation_clipping_and_ties(self):
        source = torch.tensor([[0., .25, .5, 1.], [0., .25, .25, 1.]])
        target = torch.tensor([[0., 1., 2., 4.], [0., 2., 4., 8.]])
        values = torch.tensor([[-1., .125, .75, 2.], [-1., .25, .625, 2.]])
        expected = torch.tensor([[0., .5, 3., 4.], [0., 2., 6., 8.]])
        torch.testing.assert_close(ECHO.EchoPress._quantile_map(source, target, values), expected)
    def test_adapter_native_invalid_mask_shape_and_coordinates(self):
        for keep in (torch.ones(2, 2, 19), torch.ones(2, 1, 2, 19, dtype=torch.bool)):
            with self.assertRaises(ContractError): logical_to_mask_indices(keep)
        for coords in ((torch.tensor([0, 0]), torch.tensor([0, 0]), torch.tensor([3, 3])),
                       (torch.tensor([0]), torch.tensor([0]), torch.tensor([-1]))):
            with self.assertRaises(ContractError): mask_indices_to_keep((coords,), (1, 2, 19))


if __name__ == "__main__":
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    if torch.version.cuda is not None:
        raise RuntimeError("This diagnostic is restricted to the official CPU-only wheel")
    unittest.main(verbosity=2)
