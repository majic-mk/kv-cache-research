# Native CPU tensor validation

**Evidence: CPU synthetic only. Status: 20/20 native Torch tests passed.**

This closes the narrow real-Torch serialization/tensor-operation gap left by the
NumPy-backed contract mocks. It does not reproduce a trained model or validate
CUDA, Transformers, model quality, runtime speedups, or physical KV savings.
No implementation source was changed by this validation.

## Environment and installation

- Python 3.12.14, isolated environment `/tmp/kv_native_cpu_20261003`
- Official `torch==2.9.1+cpu`, matching the proposed Torch 2.9.1 base pin
- `numpy==2.2.6`, matching the proposed NumPy pin
- `torch.version.cuda is None`, `torch.cuda.is_available() is False`
- One controlled installation from `https://download.pytorch.org/whl/cpu`
- No CUDA distributions, model weights, Transformers, paid service, or GPU
- `pip check`: no broken requirements
- Complete installed-package inventory and audited source hashes: [result.json](result.json)
- Installation transcript: [install.log](install.log)

The isolated environment is temporary and is not part of the repository. The
installed transitives are recorded, but this is not a wheel-hash-locked GPU
profile. The existing GPU installation/preflight gate remains necessary.

## What was validated

### Real tensor archives

Actual `torch.save` files are opened by the implementation's actual
`echo_pilot.analysis._torch_masks` helper with `map_location="cpu"` and
`weights_only=True`. There is no `_load_masks` helper in the inspected source.
These checks do not bypass tensor validation with JSON or NumPy shims.

- Compressed boolean keep tensor shape `[layers, 1, heads, tokens]`
- FP16, BF16, FP32 and FP64 score tensors
- Full-KV archive with all-None masks and no score tensors
- Exact native coordinate/keep-mask agreement and per-head, prefix and region counts
- Rejection of wrong ranks/dtypes, missing/nonfinite scores, malformed coordinates,
  duplicate/out-of-range coordinates, and evicted sink/recent tokens
- Rejection of invalid full-KV payloads and non-allowlisted serialized objects
- Valid zero-eviction coordinates and None layers
- End-to-end serialization of an adapter-selected native mask into the analysis helper

Rerunnable small sample archives are `cpu_synthetic_compressed.pt` and
`cpu_synthetic_full.pt`; hashes are in `result.json`. The compressed sample has
76 logical pairs and retains 46. This is a synthetic mask count, not a quality or
memory-savings result.

### Native adapter and audited source methods

The existing common-microchunk adapter runs unchanged with real PyTorch tensors,
real `nn.Module` hooks, a tiny synthetic model, and a synthetic dense cache
container. Audited EchoPress, KVzip, utility, base and attention-patch source
function/class AST bodies run unedited, with their imports replaced by explicit
native Torch and synthetic type dependencies. The runner verifies five executed
author files against the existing pinned-source SHA-256 inventories before
checking outputs and confirms source files did not change during validation.

- Sparse exact replay and independent full-reconstruction diagnostic agree on
  shared labels in FP32, FP16 and BF16
- Nonzero RoPE angles, grouped query/KV heads, absolute sparse offsets and short tail
- Sparse observed forwards `[19, 8, 8]`; full diagnostic `[19, 8, 8, 8, 8, 5]`
- Pre-storage exact scalar dtype preserved; virtual source scores remain FP32
- Native source virtual scores match a direct dense softmax reference
- Native source exact attention matches a dense reference, including causal zeros
- Native quantile interpolation, clipping and duplicate-knot behavior
- Masks are int64 on each CPU cache device and round-trip without changing selection
- Independent storage for cache clones and installed mask tensors
- Actual source fake-key search/mutation only changes pruned cloned keys, with
  exponential underflow checked on deterministic queries
- Cache shape and physical storage sizes stay unchanged after masking
- Native synthetic query decoder, EOS exit, and mask cleanup
- Injected partial-replay failure restores empty cache, prior masks, hooks and
  attempted/completed forward accounting

The synthetic model generates deterministic hidden tensors and a decoder sentinel;
it does not perform an actual pretrained model's attention or language generation.
The inspected source emits an upstream generic overhead warning during one test;
that warning is not a measured result of this diagnostic.

## Reproduce in the existing isolated environment

Run from the project root:

```sh
/tmp/kv_native_cpu_20261003/bin/python research/diagnostics/native_cpu_tensor/run_native_cpu.py
/tmp/kv_native_cpu_20261003/bin/python -m pip check
```

For a fresh environment, install the CPU-only package profile explicitly:

```sh
python -m venv /tmp/kv_native_cpu_20261003
/tmp/kv_native_cpu_20261003/bin/python -m pip install \
  --index-url https://download.pytorch.org/whl/cpu --timeout 25 --retries 0 \
  torch==2.9.1+cpu numpy==2.2.6
```

Native test output: [tests.log](tests.log). At the original diagnostic snapshot, the pilot suite also passed
135/135 tests in this CPU environment: [pilot_regression.log](pilot_regression.log).
That suite contains existing standard-library/NumPy mocks; it is separate from
these 20 native tensor tests. Counts reflect the inspected working-tree snapshot.

## Still unvalidated

- Real Transformers/Qwen model objects, Qwen q_norm path and HF DynamicCache behavior
- Full proposed Transformers/PEFT/KVPress dependency installation/import compatibility
- Actual checkpoint loading and tokenizer-to-model behavior
- CUDA kernels, BF16 GPU numerical parity, Triton and compiled scoring paths
- End-to-end completed real-model output analysis (no real-model run was fabricated)
- Language quality, performance, generalization, and any physical KV compaction

No blocker or regression was found within the tested scope. GPU experiments remain
last and require the separate baseline/smoke gates and authorization.

Latest aggregate verification is recorded in [the CPU checkpoint report](../checkpoint_20261003/README.md). It supersedes historical aggregate counts above.
