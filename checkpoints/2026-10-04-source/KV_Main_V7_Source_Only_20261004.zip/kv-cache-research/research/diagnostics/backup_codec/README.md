# NVFP4 cold-page source-equation diagnostic

**Status: synthetic CPU arithmetic only.** This is not an execution of TensorRT-LLM,
CUDA, a model, or an end-to-end page lifecycle. No upstream code is imported or
executed. It establishes a counterexample to universal numerical idempotence
for the equations used by the pinned production codec. It does not establish
how often the production lifecycle re-encodes a page or measure model quality.

## Reproduce

From this directory, using Python 3 and its standard library:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s . -v
PYTHONDONTWRITEBYTECODE=1 python nvfp4_source_equation_check.py
```

Recorded outputs are `tests.txt` (6 tests passed) and `result.json`.
The implementation replaces `rcp.approx.ftz.f32` with a binary32-rounded
reciprocal. An additional test checks all 27 combinations of adjacent binary32
reciprocal results at the three calls in each encode for this selected example.
That robustness check is not a general CUDA instruction emulator.

## Counterexample

Use FP16 **or** BF16 hot storage, identity NVFP4 global scales, and a 16-element
group with every element exactly `19/1024 = 0.0185546875`. No user or Attention
mutation is inserted between cycles.

| Cycle | E4M3 scale byte | Scale | Packed bytes | Restored hot value |
|---|---|---|---|---|
| First | `02` | `2/512` | `66` repeated 8 times | `1/64 = 0.015625` |
| Second | `01` | `1/512` | `77` repeated 8 times | `6/512 = 0.01171875` |
| Third | `01` | `1/512` | `77` repeated 8 times | `6/512 = 0.01171875` |

The first encode rounds `(19/1024)/6` to `2/512`; normalization gives `4.75`,
which rounds to E2M1 `4` (nibble `6`). The second encode recomputes the scale
from `1/64`: `(1/64)/6` rounds to `1/512`, normalization gives `8`, and E2M1
saturates to `6` (nibble `7`). All listed hot values are exact in both hot dtypes.
The third cycle is a fixed point.

This example uses **small, subnormal E4M3 block scales**. The second cycle changes
this element by `-0.00390625`; that is a 25% change relative to its first restored
value. This percentage is not model-quality evidence, a prevalence estimate, or
evidence of unbounded cumulative degradation.

## Exact production source chain

All repository links are pinned to commit
`c76f4a856447820aa1f994b053da7580d69b657d`:

- [Supported hot dtype map](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_torch/kv_cache_compression/quantization_for_cold_page/nvfp4_quantization.py#L340-L352): FP16, BF16, FP8
- [Default identity global scales and optional model globals](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/tensorrt_llm/_torch/kv_cache_compression/quantization_for_cold_page/nvfp4_quantization.py#L379-L400)
- [Production 16-bit encode call](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L643-L655)
- [Recompute absolute maximum and E4M3 scale from hot data](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/quantization.cuh#L457-L513)
- [Normalize and convert to E2M1](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/quantization.cuh#L515-L534); the helper uses [round-to-nearest, saturate-finite conversion](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/quantization.cuh#L339-L359)
- [Decode scale and values](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L550-L575), then [round the restored result into FP16/BF16 hot storage](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L466-L487)
- [FP8 hot encode has an additional FP16 restoration stage and independent global scales](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tensorrt_llm/kernels/nvfp4ColdPageKernels.cu#L490-L540). This script does **not** reproduce that path
- [Existing repeated-roundtrip test](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tests/unit_tests/kernels/nvfp4ColdPageKernelsTest.cpp#L779-L805) updates its reference by decoding and re-encoding; it does not assert second-cycle equality with the first encoding
- [Existing fixtures](https://github.com/NVIDIA/TensorRT-LLM/blob/c76f4a856447820aa1f994b053da7580d69b657d/cpp/tests/unit_tests/kernels/nvfp4ColdPageKernelsTest.cpp#L465-L505) use well-separated representable patterns and block scales 0.25, 0.5, 1, 2

The cold codec stores block scales in cold memory and reconstructs only ordinary
hot values on decode. Re-encoding therefore recomputes block scales. This is
separate from fixed per-layer global metadata. Same-format cold-byte copies
preserve the encoded representation; they do not invoke these equations.

## Scoped normal-scale fixed-point argument

A stronger claim **can** be made in a bounded case: finite FP16/BF16 hot values,
identity global scales, and a first encode whose block scale is normal E4M3.
It is a source-arithmetic argument, not a measured runtime guarantee:

1. The normal E4M3 scale spacing ensures the largest normalized magnitude is at
   least 5.625 (apart from tiny binary32 reciprocal errors), above the E2M1
   `4`/`6` midpoint of 5. Thus some encoded element has magnitude 6
2. Every E2M1 times finite E4M3 product here fits exactly into both FP16 and BF16.
   With normal E4M3 scales, nonzero magnitudes range from `1/128` to `2688`, so
   the 16-bit formats introduce neither underflow nor overflow
3. Decode therefore gives absolute maximum exactly `6*s`. Re-encoding gives
   scale `s` again, and the recovered normalized E2M1 values are separated from
   decision boundaries. NVIDIA documents at most 1 ulp reciprocal approximation
   error; this is much smaller than these margins

The accompanying test enumerates 1,904 positive dtype/normal-scale/level cases
with a max-magnitude-6 element using binary32-rounded reciprocals. The mathematical
argument explains the case beyond enumeration. It does not cover arbitrary
nonidentity globals, the FP8 hot path, NaNs, or subnormal scales. It is therefore
wrong to infer that every lossy cycle must worsen every page.

[NVIDIA reciprocal instruction specification](https://docs.nvidia.com/cuda/parallel-thread-execution/index.html#floating-point-instructions-rcp)

## Baselines, not a production fix

- Retaining and reusing the first canonical encoded bytes gives the same decoded
  value for the immutable page on every restore; this avoids re-encoding entirely
- Retaining only the first scale prevents the second-cycle change **for this
  example**, as its restored values can be encoded exactly with that scale. This
  does not prove a scale-only mitigation for all hot dtypes/global scales

These are isolated comparisons. No production codec or lifecycle was modified.
Active-NVFP4 bypass and lifecycle reachability belong to the separate audit.
