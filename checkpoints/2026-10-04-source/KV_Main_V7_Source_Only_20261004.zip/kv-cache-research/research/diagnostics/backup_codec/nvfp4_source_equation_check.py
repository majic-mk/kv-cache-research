#!/usr/bin/env python3
"""Synthetic CPU source-equation check; NOT a CUDA or TensorRT-LLM execution.

Scope: one positive, finite, 16-value FP16/BF16 group; identity global scales.
Uses stdlib only. No upstream imports, model weights, binaries, or GPU calls.
The default reciprocal is rounded binary32, not CUDA rcp.approx.ftz.f32.
The associated tests check the selected counterexample under adjacent-float
reciprocal perturbations, but do not emulate CUDA instructions generally.

Pinned source: NVIDIA/TensorRT-LLM c76f4a856447820aa1f994b053da7580d69b657d
  kernels/nvfp4ColdPageKernels.cu:467-484,552-575,654-655
  kernels/quantization.cuh:457-537
"""
from dataclasses import dataclass
import json
import math
import struct
from typing import Callable


COMMIT = 'c76f4a856447820aa1f994b053da7580d69b657d'


def f32(value: float) -> float:
    return struct.unpack('<f', struct.pack('<f', value))[0]


def fp16(value: float) -> float:
    return struct.unpack('<e', struct.pack('<e', value))[0]


def bf16(value: float) -> float:
    bits = struct.unpack('<I', struct.pack('<f', value))[0]
    bits += 0x7fff + ((bits >> 16) & 1)
    return struct.unpack('<f', struct.pack('<I', bits & 0xffff0000))[0]


# Positive finite E4M3 encodings; subnormal spacing is 2^-9.
E4M3 = tuple((code, (code % 8) * 2.0**-9 if code < 8 else
             (1 + (code % 8) / 8) * 2.0**((code // 8) - 7))
            for code in range(127))
E2M1 = tuple(enumerate((0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0)))
DTYPES = {'fp16': fp16, 'bf16': bf16}


def nearest_even(value, levels):
    return min(levels, key=lambda pair: (abs(value - pair[1]), pair[0] % 2))


def reciprocal(value):
    return f32(1.0 / value)


@dataclass(frozen=True)
class EncodedGroup:
    packed: bytes
    scale_byte: int

    def canonical_bytes(self):
        return self.packed + bytes([self.scale_byte])

    @classmethod
    def from_bytes(cls, raw):
        if len(raw) != 9:
            raise ValueError('One group has eight packed bytes and one scale byte')
        return cls(raw[:8], raw[8])


def encode_group(values, rcp: Callable[[float], float] = reciprocal, *, retained_scale=None):
    """Source-equation subset; retained_scale is a synthetic baseline only."""
    if len(values) != 16 or any(not math.isfinite(x) or x < 0 for x in values):
        raise ValueError('This diagnostic supports 16 finite nonnegative values')
    amax = max(values)
    if retained_scale is None:
        # quantization.cuh L499-503, with global orig_quant=1.
        scale_candidate = f32(amax * rcp(6.0))
        scale_byte, scale = nearest_even(scale_candidate, E4M3)
    else:
        scale_byte = retained_scale
        scale = E4M3[scale_byte][1]
    if not scale:
        if amax:
            raise ValueError('Nonzero group with underflowed scale is outside this diagnostic')
        return EncodedGroup(bytes(8), 0)
    # quantization.cuh L506, retaining the nested reciprocal with identity global.
    output_scale = rcp(f32(scale * rcp(1.0)))
    nibbles = [nearest_even(f32(x * output_scale), E2M1)[0] for x in values]
    packed = bytes(nibbles[i] | (nibbles[i + 1] << 4) for i in range(0, 16, 2))
    return EncodedGroup(packed, scale_byte)


def decode_group(encoded, dtype):
    # nvfp4ColdPageKernels.cu L552-575 and L467-484, identity global.
    scale = E4M3[encoded.scale_byte][1]
    codes = [code for byte in encoded.packed for code in (byte & 15, byte >> 4)]
    return [DTYPES[dtype](f32(E2M1[code][1] * scale)) for code in codes]


def counterexample_trace(dtype):
    values = [DTYPES[dtype](19 / 1024)] * 16
    trace = []
    for cycle in range(1, 4):
        encoded = encode_group(values)
        values = decode_group(encoded, dtype)
        trace.append({'cycle': cycle, 'scale_byte': f'0x{encoded.scale_byte:02x}',
                      'scale': E4M3[encoded.scale_byte][1],
                      'packed_hex': encoded.packed.hex(), 'hot_value': values[0]})
    return trace


def main():
    print(json.dumps({'label': 'Synthetic CPU source-equation check; NOT production execution',
                      'commit': COMMIT, 'initial_hot_value': 19 / 1024,
                      'group_size': 16, 'global_scales': [1.0, 1.0],
                      'fp16': counterexample_trace('fp16'),
                      'bf16': counterexample_trace('bf16')}, indent=2))


if __name__ == '__main__':
    main()
