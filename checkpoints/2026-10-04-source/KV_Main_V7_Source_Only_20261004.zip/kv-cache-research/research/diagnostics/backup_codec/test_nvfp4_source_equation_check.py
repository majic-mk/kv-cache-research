"""Tests of a synthetic source-equation subset, not production GPU tests."""
import itertools
import struct
import unittest

from nvfp4_source_equation_check import (
    DTYPES, E2M1, E4M3, EncodedGroup, counterexample_trace,
    decode_group, encode_group, f32,
)


class SourceEquationChecks(unittest.TestCase):
    def test_fp16_second_cycle_changes_value_and_third_is_fixed(self):
        self.check_trace('fp16')

    def test_bf16_second_cycle_changes_value_and_third_is_fixed(self):
        self.check_trace('bf16')

    def check_trace(self, dtype):
        trace = counterexample_trace(dtype)
        self.assertEqual([x['hot_value'] for x in trace], [1 / 64, 6 / 512, 6 / 512])
        self.assertEqual([x['scale_byte'] for x in trace], ['0x02', '0x01', '0x01'])
        self.assertEqual([x['packed_hex'] for x in trace], ['66' * 8, '77' * 8, '77' * 8])

    def test_counterexample_is_robust_to_adjacent_reciprocal_results(self):
        # Each encode calls rcp three times. Check all adjacent binary32 choices
        # around RN results; this is a local robustness check, not a PTX emulator.
        for dtype, cast in DTYPES.items():
            for shifts in itertools.product((-1, 0, 1), repeat=3):
                values = [cast(19 / 1024)] * 16
                for expected_scale, expected_value in ((2, 1 / 64), (1, 6 / 512), (1, 6 / 512)):
                    pending = iter(shifts)
                    def perturbed_rcp(x):
                        bits = struct.unpack('<I', struct.pack('<f', f32(1 / x)))[0]
                        return struct.unpack('<f', struct.pack('<I', bits + next(pending)))[0]
                    encoded = encode_group(values, perturbed_rcp)
                    values = decode_group(encoded, dtype)
                    self.assertEqual(encoded.scale_byte, expected_scale)
                    self.assertEqual(values, [expected_value] * 16)

    def test_retained_canonical_bytes_baseline(self):
        for dtype, cast in DTYPES.items():
            encoded = encode_group([cast(19 / 1024)] * 16)
            canonical = encoded.canonical_bytes()
            for _ in range(3):
                restored = EncodedGroup.from_bytes(canonical)
                self.assertEqual(restored.canonical_bytes(), canonical)
                self.assertEqual(decode_group(restored, dtype), [1 / 64] * 16)

    def test_retained_scale_baseline_only_for_selected_example(self):
        for dtype, cast in DTYPES.items():
            first = encode_group([cast(19 / 1024)] * 16)
            values = decode_group(first, dtype)
            second = encode_group(values, retained_scale=first.scale_byte)
            self.assertEqual(second, first)
            self.assertEqual(decode_group(second, dtype), values)

    def test_normal_scale_representations_with_six_max_are_fixed(self):
        count = 0
        for dtype, cast in DTYPES.items():
            for scale_byte, scale in E4M3[8:]:
                for nibble, value in E2M1:
                    # Every q*s is exact in both 16-bit hot formats here.
                    values = [cast(value * scale)] + [cast(6 * scale)] * 15
                    self.assertEqual(values[0], value * scale)
                    self.assertEqual(values[1], 6 * scale)
                    encoded = encode_group(values)
                    self.assertEqual(encoded.scale_byte, scale_byte)
                    self.assertEqual(encoded.packed[0] & 15, nibble)
                    self.assertEqual(decode_group(encoded, dtype), values)
                    count += 1
        self.assertEqual(count, 1904)


if __name__ == '__main__':
    unittest.main()
