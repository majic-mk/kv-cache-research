"""Download the single verified official shard only after an explicitly supplied passing token gate."""
import argparse,datetime,hashlib,json,shutil,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]; O=ROOT/'outputs/hybrid_cpu_competence'; D=O/'Qwen3.5-0.8B'
def main():
 p=argparse.ArgumentParser();p.add_argument('--token-validation',type=Path,required=True);a=p.parse_args();v=json.loads(a.token_validation.read_text());assert v['token_status']=='passed'
 provenance=json.loads((O/'asset_provenance.json').read_text()); assert not provenance['weights_downloaded']; sh=provenance['shard_index']['shards'];assert len(sh)==1;s=sh[0];name=s['rfilename']; assert not(D/name).exists()
 free=shutil.disk_usage(D).free;assert free-s['size']>=5_000_000_000
 t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();h=hashlib.sha256();n=0
 with urllib.request.urlopen(s['source_url'],timeout=120) as r, (D/(name+'.tmp')).open('wb') as f:
  while block:=r.read(4*1024*1024):f.write(block);h.update(block);n+=len(block)
 assert n==s['size'] and h.hexdigest()==s['lfs']['sha256'],(n,h.hexdigest())
 (D/(name+'.tmp')).rename(D/name);elapsed=time.monotonic()-t
 provenance.update(weights_downloaded=True,checkpoint_download_started_utc=started,checkpoint_download_finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checkpoint_download_seconds=elapsed,checkpoint_verified_sha256=h.hexdigest(),checkpoint_bytes=n,disk_after_checkpoint=shutil.disk_usage(D)._asdict(),token_validation_sha256=hashlib.sha256(a.token_validation.read_bytes()).hexdigest())
 assert provenance['disk_after_checkpoint']['free']>=5_000_000_000
 (O/'asset_provenance.json').write_text(json.dumps(provenance,indent=2)+'\n'); print(json.dumps({'status':'verified','bytes':n,'sha256':h.hexdigest(),'download_seconds':elapsed,'disk_free':shutil.disk_usage(D).free}))
if __name__=='__main__':main()
