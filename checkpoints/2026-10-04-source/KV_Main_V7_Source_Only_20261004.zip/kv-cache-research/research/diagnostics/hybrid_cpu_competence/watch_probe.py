"""External one-second RSS/load/wall watchdog for a single CPU model process."""
import argparse,datetime,json,os,signal,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]; D=Path(__file__).resolve().parent
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 p=argparse.ArgumentParser();p.add_argument('--protocol',required=True);p.add_argument('--tokens',required=True);p.add_argument('--out',required=True);p.add_argument('--execution-start-utc');a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 cap=8*1024**3;cmd=['/tmp/hybrid_recurrence_cpu_env/bin/python','-u',str(D/'run_probe.py'),'--protocol',a.protocol,'--tokens',a.tokens,'--out',a.out]
 env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',HF_ENABLE_PARALLEL_LOADING='false')
 started=utc();start=time.monotonic();peak=0;reason=None; original_start=datetime.datetime.fromisoformat(a.execution_start_utc) if a.execution_start_utc else datetime.datetime.now(datetime.timezone.utc)
 with (out/'run.log').open('w') as log,(out/'rss_samples.jsonl').open('w') as rss:
  proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   elapsed=(datetime.datetime.now(datetime.timezone.utc)-original_start).total_seconds();row={'utc':utc(),'elapsed_seconds':elapsed,'pid':proc.pid}
   try:
    lines=Path(f'/proc/{proc.pid}/status').read_text().splitlines();values={s.split(':',1)[0]:s.split(':',1)[1].strip() for s in lines if ':' in s}
    row.update(RSS_bytes=int(values.get('VmRSS','0 kB').split()[0])*1024,HWM_bytes=int(values.get('VmHWM','0 kB').split()[0])*1024,threads=int(values.get('Threads','0')));peak=max(peak,row['RSS_bytes'],row['HWM_bytes'])
    mem={s.split(':')[0]:int(s.split()[1])*1024 for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith(('MemAvailable:','MemTotal:'))};row.update(mem)
    phase=json.loads((out/'phase.json').read_text()) if (out/'phase.json').exists() else {'phase':'initializing'};row['phase']=phase['phase']
    if peak>=cap:reason='RSS safety ceiling reached'
    elif row['MemAvailable']<512*1024**2:reason='Host available memory below 512MiB safety margin'
    elif elapsed>=1800:reason='30-minute execution envelope reached'
    elif phase['phase'] in ['initializing','load_start'] and elapsed>=900:reason='15-minute model load limit reached'
   except FileNotFoundError:pass
   rss.write(json.dumps(row)+'\n');rss.flush()
   if reason:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
    break
   time.sleep(1)
  rc=proc.wait()
 result={'started_utc':started,'finished_utc':utc(),'wall_seconds_including_load':time.monotonic()-start,'original_execution_start_utc':original_start.isoformat(),'cumulative_envelope_seconds':(datetime.datetime.now(datetime.timezone.utc)-original_start).total_seconds(),'process_returncode':rc,'resource_stop_reason':reason,'external_peak_RSS_bytes':peak,'RSS_cap_bytes':cap,'wall_limit_seconds':1800,'load_limit_seconds':900,'sampling_seconds':1,'command':cmd}
 (out/'watchdog.json').write_text(json.dumps(result,indent=2)+'\n')
 if reason:
  if (out/'cells.jsonl').exists():
   cells=[json.loads(s) for s in (out/'cells.jsonl').read_text().splitlines()]
   for c in cells:
    if c['status']=='running':c.update(status='failed_implementation',reason=reason,failed_or_retried_work='Interrupted cell; partial cost appears in external logs')
    elif c['status']!='completed':c.update(status='not_run_budget',reason=reason)
   (out/'cells.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in cells))
  summary=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else {};summary.update(status='STOPPED_RESOURCE',resource_stop_reason=reason);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(result),flush=True)
if __name__=='__main__':main()
