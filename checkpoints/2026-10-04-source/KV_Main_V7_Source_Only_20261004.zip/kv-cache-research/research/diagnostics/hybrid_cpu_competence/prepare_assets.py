"""Acquire only official pinned public metadata/tokenizer; never fetch weights before integrity PASS."""
import datetime, hashlib, json, os, shutil, time, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'outputs/hybrid_cpu_competence'; DEST=OUT/'Qwen3.5-0.8B'
MODEL='Qwen/Qwen3.5-0.8B'; REV='2b48083dfa97c3cbf0220cf1a5e6cffe0a511157'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    start=time.monotonic(); manifest={'model_id':MODEL,'revision':REV,'started_utc':now(),'files':{},'download_seconds':0,'disk_before':shutil.disk_usage(DEST)._asdict(),'environment_disk_bytes':sum(x.stat().st_size for x in Path('/tmp/hybrid_recurrence_cpu_env').rglob('*') if x.is_file()),'weights_downloaded':False}
    api=json.loads((OUT/'model_api.json').read_text()); assert api['sha']==REV
    manifest['official_api_url']=f'https://huggingface.co/api/models/{MODEL}/revision/{REV}?blobs=true'
    manifest['api_sha256']=hashlib.sha256((OUT/'model_api.json').read_bytes()).hexdigest()
    manifest['license_from_official_card']=api.get('cardData',{}).get('license')
    assert manifest['license_from_official_card']=='apache-2.0'
    names=['README.md','config.json','tokenizer.json','tokenizer_config.json','chat_template.jinja','model.safetensors.index.json']
    siblings={x['rfilename']:x for x in api['siblings']}; needed=sum(siblings[x]['size'] for x in names)+sum(x['size'] for x in api['siblings'] if x['rfilename'].endswith('.safetensors'))
    manifest['planned_total_metadata_and_checkpoint_bytes']=needed
    assert manifest['disk_before']['free']-needed>=5_000_000_000, 'Insufficient 5GB disk reserve including checkpoint'
    for name in names:
        u=f'https://huggingface.co/{MODEL}/resolve/{REV}/{name}'; t=time.monotonic(); started=now()
        with urllib.request.urlopen(u,timeout=60) as r:
            data=r.read(); headers=dict(r.headers); final_url=r.url
        (DEST/name).write_bytes(data); dt=time.monotonic()-t
        h=hashlib.sha256(data).hexdigest(); expected=siblings[name].get('lfs',{}).get('sha256')
        assert len(data)==siblings[name]['size']; assert expected is None or expected==h
        manifest['files'][name]={'source_url':u,'sha256':h,'bytes':len(data),'official_lfs_sha256':expected,'official_git_blob_sha1':siblings[name]['blobId'],'started_utc':started,'download_seconds':dt,'etag':headers.get('etag'), 'resolved_revision_header':headers.get('x-repo-commit')}
        manifest['download_seconds']+=dt
        (OUT/'asset_provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
        print(name,len(data),h,dt,flush=True)
    index=json.loads((DEST/'model.safetensors.index.json').read_text()); shards=sorted(set(index['weight_map'].values()))
    manifest['shard_index']={'metadata':index['metadata'],'shards':[{**siblings[n],'source_url':f'https://huggingface.co/{MODEL}/resolve/{REV}/{n}'} for n in shards],'tensor_entries':len(index['weight_map'])}
    manifest.update(finished_utc=now(),preparation_seconds=time.monotonic()-start,disk_after_metadata=shutil.disk_usage(DEST)._asdict())
    (OUT/'asset_provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
if __name__=='__main__':main()
