"""Offline v1 integrity audit. Never downloads, loads a model, or changes fixtures."""
import datetime, hashlib, importlib.util, json, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]; D=Path(__file__).resolve().parent; P=ROOT/'research/protocols/hybrid_cpu_quality'; O=ROOT/'outputs/hybrid_cpu_competence'
spec=importlib.util.spec_from_file_location('frozen_validation',P/'validate_protocol.py'); v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
from tokenizers import Tokenizer
from jinja2.sandbox import ImmutableSandboxedEnvironment
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    manifest=json.loads((P/'freeze_manifest.json').read_text())
    assert all(sha((P/f).read_bytes())==r['sha256'] for f,r in manifest['files'].items())
    provenance=json.loads((O/'asset_provenance.json').read_text()); api=json.loads((O/'model_api.json').read_text()); siblings={r['rfilename']:r for r in api['siblings']}
    for n,r in provenance['files'].items():
        b=(O/'Qwen3.5-0.8B'/n).read_bytes(); assert sha(b)==r['sha256']
        if not siblings[n].get('lfs'):assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==siblings[n]['blobId']
    tokenizer=Tokenizer.from_file(str(O/'Qwen3.5-0.8B/tokenizer.json')); template=json.loads((P/'template.json').read_text()); tc=json.loads((O/'Qwen3.5-0.8B/tokenizer_config.json').read_text()); official=ImmutableSandboxedEnvironment(trim_blocks=True,lstrip_blocks=True).from_string(tc['chat_template'])
    summaries=[]; private=[]; lim=template['limits']
    for row in v.load_fixtures():
        cs=[]; bids=[]; qids=[]; aids=[]
        for ctx in v.contexts(row):
            full,(bc0,bc1)=v.render(row,ctx,template); enc=tokenizer.encode(full,add_special_tokens=False)
            bi=[i for i,(s,e) in enumerate(enc.offsets) if s>=bc0 and e<=bc1 and e>s]; b0,b1=bi[0],bi[-1]+1; a,b,q=enc.ids[:b0],enc.ids[b0:b1],enc.ids[b1:]
            imp0,imp1=row['important_interior_char_span']; imp=[i-b0 for i,(s,e) in enumerate(enc.offsets) if e>bc0+imp0 and s<bc0+imp1]
            content=full[len('<|im_start|>user\n'):full.index('<|im_end|>')]
            c={'variant':ctx['variant'],'A_tokens':len(a),'B_tokens':len(b),'Q_tokens':len(q),'total_tokens':len(enc.ids),'important_token_span_in_B':[min(imp),max(imp)+1],'boundary_crossing':any(s<cut<e for cut in (bc0,bc1) for s,e in enc.offsets),'official_template_equal':official.render(messages=[{'role':'user','content':content}],add_generation_prompt=True)==full,'full_ids_sha256':sha(json.dumps(enc.ids).encode()),'B_ids_sha256':sha(json.dumps(b).encode())}
            c['lengths_and_interior_pass']=(lim['B_tokens_min']<=len(b)<=lim['B_tokens_max'] and len(a)<=lim['A_tokens_max'] and len(q)<=lim['Q_tokens_max'] and len(enc.ids)<=lim['total_prompt_tokens_max'] and min(imp)>=lim['important_first_token_min_zero_based'])
            cs.append(c); bids.append(b);qids.append(q);aids.append(a);private.append({'pair_id':row['pair_id'],'variant':ctx['variant'],'input_ids':enc.ids,'A_ids':a,'B_ids':b,'Q_ids':q})
        summaries.append({'pair_id':row['pair_id'],'split':row['split'],'contexts':cs,'B_identity':all(b==bids[0] for b in bids),'Q_identity':all(q==qids[0] for q in qids),'A1_A2_lengths_equal':len(aids[0])==len(aids[1]),'U1_U2_lengths_equal':len(aids[2])==len(aids[3])})
    result={'protocol_id':manifest['protocol_id'],'status':'STOPPED_TOKEN_INTEGRITY_BEFORE_WEIGHTS_OR_MODEL','reported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_hashes_unchanged':True,'freeze_manifest_sha256':sha((P/'freeze_manifest.json').read_bytes()),'protocol_file_hashes':manifest['files'],'official_validator_exit_code':1,'official_validator_error':'AssertionError: A1/A2 position confound: revise before outcomes, never drop one case','groups':summaries,'failing_pair_ids':[s['pair_id'] for s in summaries if not s['A1_A2_lengths_equal']],'model_id':v.MODEL,'model_revision':v.REV,'pretrained_weights_downloaded':False,'model_loads':0,'model_forward_calls':0,'scientific_outcome':'not_evaluated_input_integrity_failure_is_not_a_negative_model_result','authorized_probe_cells':16,'other_design_cells_authorized':False,'disk_after_metadata':shutil.disk_usage(O)._asdict()}
    (D/'v1_integrity_failure.json').write_text(json.dumps(result,indent=2)+'\n'); (O/'v1_private_token_diagnostics.json').write_text(json.dumps(private,indent=2)+'\n')
    (D/'v1_token_validation.log').write_text((O/'token_validation.log').read_text()); (D/'asset_provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    contract=json.loads((P/'result_contract.json').read_text()); fields=sum([v for k,v in contract.items() if k.startswith('required_')],[]); records=[]
    for pid in ['d01','d05']:
      for variant in ['A1','A2','U1','U2']:
       for arm in ['full_recompute','exact_prefix']:
        rec={f:None for f in fields}; rec.update(protocol_id=manifest['protocol_id'],run_id='v1_preflight_20261003',pair_id=pid,split='development',variant=variant,arm=arm,repeat_index=0,donor_bits=None,oracle_group=None,status='not_run_gate',reason='Pinned-tokenizer integrity failed before any weights or model: unequal A1/A2 token lengths',null_reason='No model cell executed; metrics unmeasured',model_id=v.MODEL,model_revision=v.REV,protocol_file_hashes=manifest['files'],fixture_sha256=manifest['files']['fixtures.jsonl']['sha256'],source_build_seconds=None)
        records.append(rec)
    (D/'v1_probe_cells.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
    print(json.dumps({'status':result['status'],'failing_pair_ids':result['failing_pair_ids'],'not_run_cells':len(records),'all_B_identity':all(s['B_identity'] for s in summaries),'all_Q_identity':all(s['Q_identity'] for s in summaries),'all_lengths_and_interior':all(c['lengths_and_interior_pass'] for s in summaries for c in s['contexts'])}))
if __name__=='__main__':main()
