# Initial CPU competence / exact-prefix probe

## v1: stopped at input-integrity gate, 2026-10-03 UTC

The original frozen validator failed on the correct official pinned Qwen3.5 tokenizer before weights were downloaded or any model was loaded. Both probe pairs have unequal A1/A2 prefix lengths: **d01 42/43 tokens; d05 43/42 tokens**. This changes B's absolute position and violates the predeclared equal-prefix rule. All 16 planned probe cells are explicitly `not_run_gate` in `v1_probe_cells.jsonl`.

This is a construction/tokenization failure, not a model-competence failure, an exact-cache-parity result, or a HYPIC quality result. No prompt, answer, threshold, split, or frozen file was altered. No model outcome exists. Any corrected protocol must be separately versioned before model outcomes.

The complete offline diagnostic found unequal A1/A2 prefix lengths in 11/16 groups: d01, d02, d05, d07, d08, h03, h04, h05, h06, h07, h08. B and Q token identity, official-template equality, U1/U2 length equality, B/interior and prompt length caps passed for all 64 text contexts. Those checks are text-only; no held-out model cell was run.

Official public metadata, config, tokenizer and shard index were acquired from Qwen/Qwen3.5-0.8B revision `2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`. The model card declares Apache-2.0. The pinned index declares one 1,746,942,600-byte safetensors shard, official LFS SHA-256 `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`; **the weights were not downloaded for v1**. Metadata byte sizes and non-LFS Git blob hashes, and tokenizer LFS SHA-256, were verified. Acquisition times and actual disk checks are in `asset_provenance.json`; one checkpoint plus metadata would retain more than the required 5 GB disk reserve. The existing 1.1 GB CPU environment was included in the preparation audit, with no package installation by this worker.

## Artifacts

- `v1_integrity_failure.json`: full non-tokenized integrity measurements and frozen hashes
- `v1_token_validation.log`: exact failing official-validator traceback
- `v1_probe_cells.jsonl`: all 16 planned cells with reasons for non-execution
- `asset_provenance.json`: official source/hash/license/index/resource acquisition record
- `record_integrity_failure.py`: reproducible read-only offline audit
- `prepare_assets.py`: metadata/tokenizer acquisition only; never fetches weights

Downloaded assets and reversible token IDs remain under ignored `outputs/hybrid_cpu_competence/`. No weights, token arrays or private data are stored in this diagnostic directory. The independent implementation gate is recorded separately under `../hybrid_recurrence_cpu/`; the unresolved author-literal HYPIC seam/warmup semantics continue to block reuse-quality claims.
