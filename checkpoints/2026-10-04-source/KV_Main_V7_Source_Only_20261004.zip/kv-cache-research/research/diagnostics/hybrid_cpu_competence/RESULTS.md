# CPU probe result: stop at the first competence cell

**2026-10-03 UTC. No-go for this frozen task/model probe.** The first complete full-recompute cell, **d01/A1**, answered **blue** while the frozen answer is **red**. It emitted `[11855, 248046]`, decoded as `blue<|im_end|>`, within the eight-token cap. Both normalized answer accuracy and strict gold-token equality are false. The predeclared immediate competence stop applies: **1 of 16 planned cells completed; the remaining 15 are `not_run_competence`.**

There is **no exact-prefix parity result and no HYPIC quality result**. No held-out, chunked, reuse, donor or oracle cell ran. This single constructed-prompt failure does not estimate general model accuracy or disprove the recurrent-conditioning hypothesis. The author-literal HYPIC source-contract blocker remains separate and unresolved. No follow-on matrix is justified by this probe, and no prompt, gold answer, threshold or model setting was changed after the outcome.

## The observed cell

The frozen prefix assigns Alice as courier and Bruno as observer. The identical interior B sentence says the courier received the red key and the observer the blue key. Q asks the color of Alice's key. The wrong response is the other candidate, not a parser failure or missing EOS.

Candidate-plus-EOS sum log probabilities:

- red, the correct candidate: **−0.9073016769 nat**
- blue: **−0.6262624054 nat**
- correct-minus-other margin: **−0.2810392715 nat**

Teacher forcing and greedy generation started from independent, verified non-aliasing clones of the post-Q cache. The source cache remained unchanged. The model received token IDs, masks and positions only; candidate labels were used only for scoring after prefill. Generation used the frozen tokenizer's official chat EOS `<|im_end|>` (248046).

## Resources and provenance

- Official Qwen/Qwen3.5-0.8B revision `2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`, model-card license Apache-2.0
- One safetensors shard, **1,746,942,600 bytes**; verified official LFS SHA-256 `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`
- Text-only `Qwen3_5ForCausalLM`: **752,393,024 parameters**, FP32, CPU, eager full attention and the unmodified official PyTorch GDN/convolution fallbacks; no missing, unexpected, mismatched or errored loading keys
- Transformers source `02d8fb9784e8f14a1251e4c992cd82a5762417c6`, version 5.19.0.dev0; Torch 2.9.1+cpu; PyTorch intra-op and inter-op thread counts each configured to one; observed OS thread count was two during inference and briefly six during loading; no autograd/GPU
- Successful attempt load: **5.58 s**; 229-token full prefill: **3.05 s**; teacher forcing: **0.764 s**; greedy decode: **0.351 s**; cell total: **4.28 s**
- Peak RSS: **5,082,800,128 bytes = 4.734 GiB**, externally sampled every second with an 8 GiB guard
- Actual model work: **232 network tokens in four forwards**: 229 prefill, two candidate-continuation forwards, one greedy-continuation forward
- Checkpoint download: **44.47 s**, separate from execution; metadata downloads **89.18 s**, API lookup **7.91 s**
- Actual free disk after checkpoint download: **9.18 GB**, above the required 5 GB reserve; the existing environment's **1.173 GB** of files was also accounted for

There was one preserved **pre-inference logging failure**: loading completed, but JSON serialization rejected sets in Transformers' loading-info dictionary. No forward or answer occurred. Only logging serialization was corrected. Its process took **8.01 s**; the successful second process took **11.02 s**. The entire original execution envelope, including the intervening logging fix, was **98.53 s**, below the unchanged 30-minute deadline. Both attempts and all costs remain recorded; this was not a prompt retry. The successful 5.58-second load followed the first checkpoint load, so filesystem pages may be warm; it is not an independent cold-load measurement. Cached-Q and source-tuple timings were never measured, so no remaining-matrix runtime or savings estimate is offered.

## Input-integrity history

V1 stopped before weights because 11/16 fixture pairs had unequal A1/A2 token lengths, including d01 (42/43) and d05 (43/42). All v1 failure artifacts remain intact. The separately frozen v2 inserted one ASCII space in the template before A; all fixture bytes, labels, splits, cases and thresholds remained unchanged. All 64 v2 text contexts independently passed official-template, exact B/Q token identity, equal-prefix-length, interior-location and length checks before weights or model outcomes. No held-out inference was involved in those text-only checks.

V2 freeze-manifest SHA-256: `8c59ffc15e6683c37b24e828f40dbb7167810dbce77c96523f48cccda8dd77b5`. Both v1 and v2 frozen file hashes were reverified unchanged after completion.

## Files

- `v2_run_report.json`: complete result, software/source pins, attempts, preparation and resource accounting
- `v2_probe_cells.jsonl`: all 16 planned cells, raw generated answer IDs, scores and explicit unrun reasons
- `v2_failed_load_attempt.json` and `runner_preoutcome_logging_fix.json`: preserved failure and exact pre-outcome logging-only change
- `v2_run.log`, `v2_events.json`, `v2_rss_samples.jsonl`, `v2_watchdog.json`: raw runtime and external monitor evidence
- `v2_asset_provenance.json`: official metadata, index, hashes, acquisition times and disk checks
- `README.md` and `v1_*`: original integrity stop

This diagnostic directory does not duplicate weights or reversible input/candidate token arrays; its runtime copies remain in ignored `outputs/hybrid_cpu_competence/`. The separately frozen v2 protocol already contains prompt token arrays in its `token_validation.json`. No commit, push, GPU, paid service, external dataset or additional model was used. Runner scripts are preserved for audit, not an instruction to rerun the stopped probe.
