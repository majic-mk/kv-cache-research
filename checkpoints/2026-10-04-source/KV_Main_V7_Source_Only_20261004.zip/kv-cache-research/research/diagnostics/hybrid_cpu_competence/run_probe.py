"""Exactly the frozen initial 16-cell FP32 CPU competence/exact-prefix gate.
No HYPIC reuse, candidate-conditioned builder, held-out inference, or retries.
The watchdog owns wall/RSS caps. Every arm has an independently fresh target prefill.
"""
import os
os.environ.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
import argparse,copy,datetime,hashlib,importlib.util,json,platform,resource,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]; D=Path(__file__).resolve().parent; O=ROOT/'outputs/hybrid_cpu_competence'; MODEL=O/'Qwen3.5-0.8B'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(x):return hashlib.sha256(x).hexdigest()
def write(p,x):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,default=lambda value: sorted(value) if isinstance(value,set) else repr(value))+'\n');tmp.replace(p)
def main():
 p=argparse.ArgumentParser();p.add_argument('--protocol',type=Path,required=True);p.add_argument('--tokens',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
 start=time.monotonic();startcpu=time.process_time();events=[];records=[];summary={'started_utc':now(),'status':'initializing','model_id':'Qwen/Qwen3.5-0.8B','model_revision':'2b48083dfa97c3cbf0220cf1a5e6cffe0a511157','device':'cpu','dtype':'float32','threads':1,'seed':20261003,'backend':'eager attention; unmodified official torch chunk/recurrent GDN fallback','interpretation':'model competence and exact-prefix parity only; no HYPIC quality outcome','execution_order':[]}
 def event(phase,**kw):
  e={'utc':now(),'elapsed_seconds':time.monotonic()-start,'phase':phase,**kw};events.append(e);write(out/'events.json',events);write(out/'phase.json',e)
 def save():
  write(out/'summary.json',summary);(out/'cells.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
 protocol=json.loads((args.protocol/'protocol.json').read_text());template=json.loads((args.protocol/'template.json').read_text());freeze=json.loads((args.protocol/'freeze_manifest.json').read_text());contract=json.loads((args.protocol/'result_contract.json').read_text());assets=json.loads((O/'asset_provenance.json').read_text())
 assert assets['weights_downloaded'] and assets['checkpoint_verified_sha256']==assets['shard_index']['shards'][0]['lfs']['sha256']
 assert all(sha((args.protocol/f).read_bytes())==r['sha256'] for f,r in freeze['files'].items())
 tokenvalidation=json.loads(args.tokens.read_text());assert tokenvalidation['token_status']=='passed';contexts=[c for c in tokenvalidation['token_checks']['contexts'] if c['pair_id'] in ['d01','d05']];assert len(contexts)==8
 spec=importlib.util.spec_from_file_location('frozen_protocol',args.protocol/'validate_protocol.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 summary.update(protocol_id=protocol['protocol_id'],protocol_file_hashes=freeze['files'],freeze_manifest_sha256=sha((args.protocol/'freeze_manifest.json').read_bytes()),weights_checksums={s['rfilename']:s['lfs']['sha256'] for s in assets['shard_index']['shards']},tokenizer_provenance=assets['files']['tokenizer.json'],author_baseline_fidelity='blocked; no source-reuse arms run',EOS_id=template['required_special_token_ids']['<|im_end|>'])
 fields=sum([val for key,val in contract.items() if key.startswith('required_')],[])
 for c in contexts:
  for arm in ['full_recompute','exact_prefix']:
   r={f:None for f in fields};r.update(protocol_id=protocol['protocol_id'],run_id=out.name,pair_id=c['pair_id'],split='development',variant=c['variant'],arm=arm,repeat_index=0,donor_bits=None,oracle_group=None,status='not_run_gate',reason='Pending initial probe gate',expected_answer=c['expected_answer'],A_token_count=len(c['A_ids']),B_token_count=len(c['B_ids']),Q_token_count=len(c['Q_ids']),B_absolute_start=len(c['A_ids']),important_interior_token_span=c['important_token_span_zero_based_in_B'],full_input_ids_sha256=sha(json.dumps(c['input_ids']).encode()),B_input_ids_sha256=sha(json.dumps(c['B_ids']).encode()),candidate_token_ids=c['answer_candidate_ids_including_eos'],seam_width=None,cache_channel_contract='18 recurrent endpoints, 18 convolution histories, 6 full-attention K/V; explicit absolute positions; all channels cloned',model_id=summary['model_id'],model_revision=summary['model_revision'],dtype='float32',CPU_threads=1,seed=20261003,backend=summary['backend'],null_reason='Unmeasured or not applicable; see status/reason and measurement_notes')
   records.append(r)
 save();event('load_start')
 current=None
 try:
  import torch,transformers
  from tokenizers import Tokenizer
  from transformers import Qwen3_5TextConfig,Qwen3_5ForCausalLM
  torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(20261003);assert torch.version.cuda is None and not torch.cuda.is_available()
  token=Tokenizer.from_file(str(MODEL/'tokenizer.json'));assert token.token_to_id('<|im_end|>')==summary['EOS_id']
  cfg=Qwen3_5TextConfig.from_pretrained(str(MODEL),local_files_only=True)
  model,loading_info=Qwen3_5ForCausalLM.from_pretrained(str(MODEL),config=cfg,dtype=torch.float32,attn_implementation='eager',local_files_only=True,trust_remote_code=False,output_loading_info=True)
  model.eval();write(out/'loading_info.json',loading_info)
  assert not loading_info.get('missing_keys'),loading_info
  assert not loading_info.get('mismatched_keys') and not loading_info.get('error_msgs'),loading_info
  assert all(k.startswith(('model.visual.','mtp.')) for k in loading_info.get('unexpected_keys',[])),loading_info
  assert all(p.device.type=='cpu' and p.dtype==torch.float32 for p in model.parameters())
  loadsecs=time.monotonic()-start;assert loadsecs<=900;summary.update(load_seconds=loadsecs,software_versions={'python':sys.version,'torch':torch.__version__,'transformers':transformers.__version__},model_parameters=sum(p.numel() for p in model.parameters()),model_parameter_bytes=sum(p.numel()*p.element_size() for p in model.parameters()),CPU_model=next((x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'unknown'),loading_info=loading_info,status='running');event('load_complete',load_seconds=loadsecs);save()
  def tensors(cache):
   for i,l in enumerate(cache.layers):
    if hasattr(l,'recurrent_states'):
     for k,t in sorted(l.recurrent_states.items()):yield i,'recurrent',str(k),t
     for k,t in sorted(l.conv_states.items()):yield i,'conv',str(k),t
    else:
     yield i,'keys','',l.keys;yield i,'values','',l.values
  def clone(cache):
   result=copy.deepcopy(cache)
   assert result.get_seq_length()==cache.get_seq_length()
   for (_,_,_,a),(_,_,_,b) in zip(tensors(cache),tensors(result)):
    assert a.data_ptr()!=b.data_ptr() and torch.equal(a,b)
   return result
  def errors(a,b):
   rows=[]
   assert a.get_seq_length()==b.get_seq_length()
   for (i,kind,k,x),(ii,kk,sk,y) in zip(tensors(a),tensors(b)):
    assert (i,kind,k)==(ii,kk,sk) and x.shape==y.shape
    delta=(x-y).abs();tol=1e-4+1e-4*y.abs();rows.append({'layer':i,'kind':kind,'slot':k,'max_abs':float(delta.max()),'reference_max_abs':float(y.abs().max()),'max_scaled_tolerance_ratio':float((delta/tol).max()),'allclose':bool(torch.allclose(x,y,atol=1e-4,rtol=1e-4))})
   return rows
  def logmetrics(a,b):
   return {'max_abs':float((a-b).abs().max()),'TV':float((a.softmax(-1)-b.softmax(-1)).abs().sum()/2),'allclose':bool(torch.allclose(a,b,atol=1e-4,rtol=1e-4))}
  def fwd(ids,cache=None):
   n=0 if cache is None else cache.get_seq_length(); inp=torch.tensor([ids],dtype=torch.long);pos=torch.arange(n,n+len(ids),dtype=torch.long).unsqueeze(0)
   return model(input_ids=inp,past_key_values=cache,attention_mask=torch.ones((1,n+len(ids)),dtype=torch.long),position_ids=pos,use_cache=True,logits_to_keep=1)
  def score(outmodel,c,r):
   bas=outmodel.past_key_values;before=clone(bas);first=outmodel.logits[0,-1].clone();saved={};sums={};pt={};token_counts=0;ct=time.monotonic()
   for ans,ids in c['answer_candidate_ids_including_eos'].items():
    branch=clone(bas);logits=first;vals=[];candidate_logits=[]
    for idx,tid in enumerate(ids):
     candidate_logits.append(logits.clone());vals.append(float(logits.log_softmax(-1)[tid]))
     if idx<len(ids)-1:
      z=fwd([tid],branch);branch=z.past_key_values;logits=z.logits[0,-1];token_counts+=1
    saved[ans]=candidate_logits;sums[ans]=sum(vals);pt[ans]=vals
   teacher_seconds=time.monotonic()-ct;ct=time.monotonic();branch=clone(bas);logits=first;gen=[];gtokens=0;eos=False
   for idx in range(template['max_new_tokens']):
    tid=int(logits.argmax());gen.append(tid)
    if tid==summary['EOS_id']:eos=True;break
    if idx<template['max_new_tokens']-1:
     z=fwd([tid],branch);branch=z.past_key_values;logits=z.logits[0,-1];gtokens+=1
   decode_seconds=time.monotonic()-ct;assert all(e['max_abs']==0 for e in errors(bas,before));expected=c['expected_answer'];other=next(a for a in sums if a!=expected);raw=token.decode(gen[:-1] if eos else gen,skip_special_tokens=False)
   r.update(raw_generated_token_ids=gen,decoded_answer_text=raw,decoded_sequence_including_special_tokens=token.decode(gen,skip_special_tokens=False),EOS_within_cap=eos,normalized_answer_correct=v.score_answer(raw,expected,eos_within_cap=eos),strict_gold_token_sequence_equal=gen==c['answer_candidate_ids_including_eos'][expected],candidate_sum_logprobs=sums,candidate_per_token_logprobs=pt,candidate_length_normalized_logprobs={a:sums[a]/len(pt[a]) for a in sums},gold_sum_logprob=sums[expected],two_candidate_margin=sums[expected]-sums[other],teacher_force_network_tokens=token_counts,greedy_network_tokens=gtokens,teacher_forcing_seconds=teacher_seconds,greedy_decode_seconds=decode_seconds,decode_and_score_seconds=teacher_seconds+decode_seconds,cache_clone_verified=True,cached_tensor_bytes=sum(t.numel()*t.element_size() for _,_,_,t in tensors(bas)))
   return first,saved,bas
  stop_reason=None;full_results={};full_correct={};exact_checks=[]
  with torch.inference_mode():
   for c in contexts:
    ref=None
    for arm in ['full_recompute','exact_prefix']:
     if stop_reason:break
     r=next(x for x in records if x['pair_id']==c['pair_id'] and x['variant']==c['variant'] and x['arm']==arm);current=r;r.update(status='running',started_utc=now(),execution_order=len(summary['execution_order']));summary['execution_order'].append([c['pair_id'],c['variant'],arm]);save();event('cell_start',pair_id=c['pair_id'],variant=c['variant'],arm=arm)
     t=time.monotonic();cpu=time.process_time();copysecs=0
     if arm=='full_recompute':
      pref=time.monotonic();z=fwd(c['input_ids']);r['target_prefill_seconds']=time.monotonic()-pref;r['query_seconds']=None
     else:
      pref=time.monotonic();prefix=fwd(c['A_ids']+c['B_ids']);r['target_prefill_seconds']=time.monotonic()-pref;cc=time.monotonic();cache=clone(prefix.past_key_values);copysecs=time.monotonic()-cc
      qtime=time.monotonic();z=fwd(c['Q_ids'],cache);r['query_seconds']=time.monotonic()-qtime
     scored=score(z,c,r)
     r.update(status='completed',reason=None,finished_utc=now(),wall_seconds=time.monotonic()-t,CPU_seconds=time.process_time()-cpu,load_seconds=loadsecs,copy_and_IO_seconds=copysecs,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,prefill_network_tokens=len(c['input_ids']),trace_network_tokens=0,source_build_seconds=0,tuple_build_seconds=0,tuple_apply_seconds=0,seam_seconds=0,tuple_MACs=0,regenerated_endpoints=0,failed_or_retried_work=[],measurement_notes={'query_seconds':'full_recompute includes Q in monolithic prefill; exact arm reports cached Q separately','copy_and_IO_seconds':'explicit prefix clone only; scoring clones included in score time','peak_RSS_bytes':'process cumulative high-water mark; external one-second samples also recorded','null_causal_fields':'not applicable: no HYPIC reuse, donor, seam or oracle arm','load_seconds':'one shared cold load, repeated as provenance; do not sum across cells'})
     if arm=='full_recompute':
      ref=scored;refrecord=copy.deepcopy(r);full_correct[(c['pair_id'],c['variant'])]=r['normalized_answer_correct'];r.update(first_answer_token_TV_vs_full=0,maximum_absolute_logit_delta_vs_full=0)
      if not r['normalized_answer_correct']:stop_reason='not_run_competence';summary['failure']={'type':'full_recompute_incorrect','pair_id':c['pair_id'],'variant':c['variant'],'raw_answer':r['decoded_answer_text'],'EOS_within_cap':r['EOS_within_cap']}
     else:
      lm=logmetrics(scored[0],ref[0]);endpoint=errors(scored[2],ref[2]);candidate_checks={a:[logmetrics(x,y) for x,y in zip(scored[1][a],ref[1][a])] for a in scored[1]};same_tokens=r['raw_generated_token_ids']==refrecord['raw_generated_token_ids'];same_answer=r['decoded_answer_text']==refrecord['decoded_answer_text'];ok=lm['allclose'] and lm['TV']<=1e-4 and same_tokens and same_answer and all(e['allclose'] for e in endpoint) and all(m['allclose'] and m['TV']<=1e-4 for row in candidate_checks.values() for m in row)
      r.update(first_answer_token_TV_vs_full=lm['TV'],maximum_absolute_logit_delta_vs_full=lm['max_abs'],numerical_control_noise={'first_step':lm,'teacher_forced_candidate_steps':candidate_checks,'candidate_sum_logprob_delta':{a:r['candidate_sum_logprobs'][a]-refrecord['candidate_sum_logprobs'][a] for a in candidate_checks},'greedy_tokens_equal':same_tokens,'decoded_answers_equal':same_answer},per_layer_recurrent_error=[e for e in endpoint if e['kind']=='recurrent'],per_layer_conv_error=[e for e in endpoint if e['kind']=='conv'],per_layer_attention_KV_error=[e for e in endpoint if e['kind'] in ['keys','values']],exact_prefix_parity_pass=ok)
      exact_checks.append(ok)
      if not ok:stop_reason='not_run_gate';summary['failure']={'type':'exact_prefix_parity_failure','pair_id':c['pair_id'],'variant':c['variant']}
     current=None;save();event('cell_complete',pair_id=c['pair_id'],variant=c['variant'],arm=arm,correct=r['normalized_answer_correct'],raw_answer=r['decoded_answer_text'],wall_seconds=r['wall_seconds']);print(json.dumps({'pair_id':c['pair_id'],'variant':c['variant'],'arm':arm,'raw_answer':r['decoded_answer_text'],'correct':r['normalized_answer_correct'],'wall_seconds':r['wall_seconds'],'stop_reason':stop_reason}),flush=True)
    if stop_reason:break
   for r in records:
    if r['status']!='completed':r.update(status=stop_reason or 'not_run_gate',reason=summary.get('failure',{}))
   pairs=sum(all(full_correct.get((pid,var),False) for var in ['A1','A2']) for pid in ['d01','d05']);unrelated=sum(full_correct.get((pid,var),False) for pid in ['d01','d05'] for var in ['U1','U2']);competence=len(full_correct)==8 and pairs==2 and unrelated==4;parity=len(exact_checks)==8 and all(exact_checks)
   summary.update(status='PASS_INITIAL_COMPETENCE_AND_EXACT_PARITY' if competence and parity else 'STOPPED_INITIAL_GATE',competence_gate_pass=competence,parity_gate_pass=parity,full_both_correct_pairs=pairs,full_unrelated_correct=unrelated,full_contexts_completed=len(full_correct),exact_contexts_completed=len(exact_checks),completed_cells=sum(r['status']=='completed' for r in records),not_run_cells=sum(r['status']!='completed' for r in records),model_network_tokens=sum((r.get('prefill_network_tokens') or 0)+(r.get('greedy_network_tokens') or 0)+(r.get('teacher_force_network_tokens') or 0) for r in records))
 except Exception as exc:
  summary.update(status='FAILED_IMPLEMENTATION',exception=repr(exc),traceback=traceback.format_exc());print(traceback.format_exc(),flush=True)
  if current is not None:current.update(status='failed_implementation',reason=repr(exc),finished_utc=now())
  for r in records:
   if r['status']=='not_run_gate':r['reason']='Implementation/load failure before this cell'
 finally:
  summary.update(finished_utc=now(),total_wall_seconds=time.monotonic()-start,total_CPU_seconds=time.process_time()-startcpu,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024);save();event('finished',status=summary['status'])
if __name__=='__main__':main()
