# Lossless text-only checkpoint asset projection

This is asset preparation, not a model-quality experiment or an alternative
model loader. It produces a clearly labeled **derived safetensors file**, never
pretending that file is the original official checkpoint. No pretrained model
load or forward is part of these scripts.

## Immutable sources and exact selection

- Model: `Qwen/Qwen3.5-2B`, revision
  `15852e8c16360a2fea060d615a32b45270f8a8fc`
- Original single shard: `model.safetensors-00001-of-00001.safetensors`,
  4,548,221,488 bytes, official LFS SHA-256
  `aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`
- Official loader: Transformers
  `02d8fb9784e8f14a1251e4c992cd82a5762417c6`, existing installed
  `Qwen3_5ForCausalLM` / `Qwen3_5TextConfig`
- The installed model, config, conversion mapping, core loading and main model
  loading modules are byte-identical to the already-acquired official archive.
  The archive itself is rehashed against prior official provenance.
- All 632 source names exactly match the pinned original index. The source
  header's dtype/shape sizes and all offsets are checked, including no payload
  gaps or overlaps and exact whole-file length.
- The selected 320 names are established by the official text conversion
  `PrefixChange(prefix_to_remove="language_model", model_prefix="model")`.
  They match every unique parameter name and shape of an official model
  constructed solely on the `meta` device, with zero real parameter storage.
  The 321st state-dict entry is the official tied `lm_head.weight` alias.
  Each of the 312 omitted names matches the actual official loader's vision/MTP
  ignore patterns. Selection does not infer missing names from a model label.

The 320 retained tensors contain 1,881,825,088 parameters. Their exact original
payload is 3,763,655,360 bytes: 1,881,822,496 BF16 elements and 2,592 F32 elements
in 36 tensors. The projection retains all names, shapes, stored dtypes and raw
payload bytes. A subsequent ordinary `dtype=torch.bfloat16` load is a separate
operation and can cast the F32 entries; it must record actual loaded dtypes.

## Resource and byte-verification contract

`project_bytes.py` reads every source byte, including the original 8-byte length,
header, all selected payloads and all omitted payloads. It computes the original
whole-file SHA-256 and per-source-tensor hashes while writing only selected raw
payload bytes to a newly generated, valid safetensors header. No quantization,
floating-point decode/reencode, renamed tensor, full-source local file, duplicate
parameter payload, or external cache is used.

`prepare_official.py` freezes metadata preflight, then optionally makes exactly
one request to the original pinned Hugging Face HTTPS URL. Standard HTTPS
certificate verification and official redirects remain enabled. It refuses
partial/range responses, changed Content-Length, unexpected content encoding,
changed header/hash, source truncation/trailing bytes, and any automatic retry.
The exact single derivative file is preallocated before requesting bytes.

The unchanged free-disk floor is 5,000,000,000 bytes. Preflight additionally
reserves 128 MiB headroom after accounting for the full derivative and small
config/tokenizer copies. Every source chunk checks available disk, stopping
before the floor if half of that extra guard is crossed. Streaming uses at most
4 MiB per read, a 60-second socket timeout, a 1,800-second internal deadline,
and is launched under an outer 1,800-second timeout plus a 1 GiB virtual-memory
limit. No old asset is removed.

`verify_projection.py` is an independent implementation with no projector import.
After source verification and fsync, it rereads the derivative, checks every
selected name/shape/dtype/offset, compares all 320 payload hashes against the
full-source-stream hashes, and hashes the complete derived file. A successful
output is renamed atomically, without a second payload copy. Failed partials
remain explicitly unverified and cannot produce `COMPLETE.json`.

## Synthetic tests and execution

Fourteen tiny tests pass before any official source stream. They include
interleaved selected/excluded tensors, BF16/F32 literal NaN/infinity/signed-zero
bit patterns, short reads, six chunk sizes, a separate official safetensors
parser, excluded-payload corruption, selected-payload corruption, invalid
headers/shapes/offsets, duplicates, unknown selections, truncation, trailing
bytes, disk-budget interruption, and independent written-file corruption.
The admission reviewer separately reran all 14 tests successfully before the
source stream began.

From the repository root, using only the existing CPU environment:

```sh
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /tmp/hybrid_recurrence_cpu_env/bin/python -m unittest discover \
  -s research/diagnostics/text_only_asset_projection -p test_projection.py -v

# Metadata-only; refuses to overwrite an existing frozen preflight.
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1 \
  /tmp/hybrid_recurrence_cpu_env/bin/python \
  research/diagnostics/text_only_asset_projection/prepare_official.py

# The recorded successful test run must be attested by synthetic_test_result.json.
# Explicitly authorized, one-shot acquisition only. Refuses an existing destination.
ulimit -v 1048576
timeout --signal=INT --kill-after=10s 1800s \
  /tmp/hybrid_recurrence_cpu_env/bin/python \
  research/diagnostics/text_only_asset_projection/prepare_official.py --stream
```

All generated metadata, logs and weights are under ignored
`outputs/text_only_asset_projection/`. The official original config, tokenizer
configuration and chat template are unchanged and checked against their pinned
Git blob IDs. `tokenizer.json` reuses the already-present identical bytes after
checking the **2B pin's** official LFS SHA-256; this is content-addressed reuse,
not reuse of the differing 0.8B template/config. The original full index remains
in `outputs/next_cpu_probe_metadata/`, outside the derived loader directory.

The proposed later loading path is the ordinary official
`Qwen3_5ForCausalLM.from_pretrained` with explicitly extracted
`Qwen3_5TextConfig`, `local_files_only=True`, `trust_remote_code=False`, and the
separately frozen precision/backend contract. There is no custom model loader.
This preparation cannot establish runtime memory fit, numerical parity, task
competence, a repair method, or permission to run any pretrained forward.

See `RESULTS.md` for the actual terminal acquisition and validation outcome.
