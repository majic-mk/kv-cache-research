"""Lossless safetensors subset projection. No Torch/model code or dtype conversion.

The caller supplies an independently verified exact tensor allowlist, header and
whole-source digest. Every source byte is read and hashed; only selected payloads
are written. An incomplete/mismatched output is never reported as verified.
"""
import hashlib
import json
import math
import struct
import time

DTYPE_BYTES = {"F32": 4, "BF16": 2, "F16": 2, "F64": 8, "I64": 8,
               "I32": 4, "I16": 2, "I8": 1, "U8": 1, "BOOL": 1}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_header(raw, source_size):
    header = json.loads(raw, object_pairs_hook=unique_object)
    tensors = []
    for name, value in header.items():
        if name == "__metadata__":
            if not isinstance(value, dict) or not all(isinstance(x, str) for x in value.values()):
                raise ValueError("Invalid safetensors metadata")
            continue
        if not isinstance(value, dict) or set(value) != {"dtype", "shape", "data_offsets"}:
            raise ValueError("Unexpected tensor header fields")
        shape, offsets = value["shape"], value["data_offsets"]
        if not isinstance(shape, list) or any(type(x) is not int or x < 0 for x in shape):
            raise ValueError("Invalid shape")
        if not isinstance(offsets, list) or len(offsets) != 2 or any(type(x) is not int for x in offsets):
            raise ValueError("Invalid offsets")
        if value["dtype"] not in DTYPE_BYTES:
            raise ValueError("Unsupported dtype")
        start, end = offsets
        if start < 0 or end < start or end-start != math.prod(shape)*DTYPE_BYTES[value["dtype"]]:
            raise ValueError("Shape/dtype/offset size mismatch")
        tensors.append((name, value))
    tensors.sort(key=lambda x: (x[1]["data_offsets"][0], x[1]["data_offsets"][1], x[0]))
    cursor = 0
    for name, value in tensors:
        if value["data_offsets"][0] != cursor:
            raise ValueError("Source payload overlap or gap: " + name)
        cursor = value["data_offsets"][1]
    if 8+len(raw)+cursor != source_size:
        raise ValueError("Source header/file size mismatch")
    return tensors


def make_plan(raw, source_size, exact_names, source_sha256):
    tensors = validate_header(raw, source_size)
    names = set(exact_names)
    if len(names) != len(exact_names) or not names or not names.issubset({n for n, _ in tensors}):
        raise ValueError("Empty, duplicate, or unknown selection")
    out_header = {"__metadata__": {"format": "pt", "artifact_kind": "derived_lossless_tensor_subset",
                                  "source_sha256": source_sha256}}
    cursor, records = 0, []
    for name, value in tensors:
        selected = name in names
        record = {"source_name": name, "dtype": value["dtype"], "shape": value["shape"],
                  "source_data_offsets": value["data_offsets"], "selected": selected,
                  "bytes": value["data_offsets"][1]-value["data_offsets"][0]}
        if selected:
            record["derived_name"] = name
            record["derived_data_offsets"] = [cursor, cursor+record["bytes"]]
            out_header[name] = {"dtype": value["dtype"], "shape": value["shape"],
                                "data_offsets": record["derived_data_offsets"]}
            cursor += record["bytes"]
        records.append(record)
    encoded = json.dumps(out_header, separators=(",", ":"), ensure_ascii=False).encode()
    encoded += b" "*((-len(encoded)) % 8)
    return {"source_size": source_size, "source_sha256": source_sha256,
            "source_header_sha256": digest(raw), "source_header_bytes": len(raw),
            "derived_header_hex": encoded.hex(), "derived_header_sha256": digest(encoded),
            "derived_payload_bytes": cursor, "derived_size": 8+len(encoded)+cursor,
            "source_tensor_count": len(records), "selected_tensor_count": len(names),
            "tensors": records}


def project(stream, output, plan, *, chunk_bytes=4*1024*1024, check_budget=lambda: None,
            progress=lambda value: None, deadline=None):
    """Consumes exactly one source stream. Retains failed output for accounting.

    Output must be a newly created seekable binary file. Caller may preallocate
    its exact size, which guarantees no disk transient from a complete source.
    """
    if chunk_bytes <= 0:
        raise ValueError("Invalid chunk size")
    whole = hashlib.sha256()
    source_count = 0

    def take(n):
        nonlocal source_count
        if deadline is not None and time.monotonic() > deadline:
            raise TimeoutError("Source stream wall cap exceeded")
        check_budget()
        data = stream.read(n)
        if not data or len(data) > n:
            raise ValueError("Truncated or nonconforming source stream")
        whole.update(data)
        source_count += len(data)
        return data

    def exact(n):
        result = bytearray()
        while len(result) < n:
            result.extend(take(min(n-len(result), chunk_bytes)))
        return bytes(result)

    prefix = exact(8)
    if struct.unpack("<Q", prefix)[0] != plan["source_header_bytes"]:
        raise ValueError("Source header length changed")
    raw = exact(plan["source_header_bytes"])
    if digest(raw) != plan["source_header_sha256"]:
        raise ValueError("Source header digest changed")
    out_header = bytes.fromhex(plan["derived_header_hex"])
    output.write(struct.pack("<Q", len(out_header)))
    output.write(out_header)
    results = []
    for record in plan["tensors"]:
        hasher, remaining = hashlib.sha256(), record["bytes"]
        if source_count != 8+len(raw)+record["source_data_offsets"][0]:
            raise ValueError("Source stream position mismatch")
        if record["selected"] and output.tell() != 8+len(out_header)+record["derived_data_offsets"][0]:
            raise ValueError("Destination position mismatch")
        while remaining:
            data = take(min(chunk_bytes, remaining))
            hasher.update(data)
            if record["selected"]:
                output.write(data)
            remaining -= len(data)
        offset_details = {"source_file_offsets": [8+len(raw)+v for v in record["source_data_offsets"]]}
        if record["selected"]:
            offset_details["derived_file_offsets"] = [8+len(out_header)+v for v in record["derived_data_offsets"]]
        results.append({**record, **offset_details, "source_payload_sha256": hasher.hexdigest()})
        progress({"source_bytes_read": source_count, "derived_bytes_written": output.tell()})
    if stream.read(1):
        raise ValueError("Unexpected trailing source bytes")
    if source_count != plan["source_size"] or whole.hexdigest() != plan["source_sha256"]:
        raise ValueError("Whole source size or official SHA-256 mismatch")
    if output.tell() != plan["derived_size"]:
        raise ValueError("Derived size mismatch")
    output.flush()
    return {"status": "stream_source_verified_pending_disk_verification", "source_bytes_read": source_count,
            "source_sha256": whole.hexdigest(), "source_header_bytes": len(raw),
            "source_header_sha256": digest(raw), "derived_header_bytes": len(out_header),
            "derived_header_sha256": digest(out_header), "derived_size": output.tell(), "tensors": results}
