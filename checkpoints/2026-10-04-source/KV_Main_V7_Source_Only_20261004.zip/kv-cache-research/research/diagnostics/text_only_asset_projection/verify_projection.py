"""Independent disk reread: no projector import, no Torch, no model forward."""
import hashlib
import json
from pathlib import Path
import struct


def verify(path, streamed, chunk_bytes=4*1024*1024):
    path = Path(path)
    whole = hashlib.sha256()
    with path.open("rb") as f:
        while data := f.read(chunk_bytes):
            whole.update(data)
    assert path.stat().st_size == streamed["derived_size"], "Derived file size"
    with path.open("rb") as f:
        header_size = struct.unpack("<Q", f.read(8))[0]
        raw = f.read(header_size)
        header = json.loads(raw)
        selected = [r for r in streamed["tensors"] if r["selected"]]
        assert set(header)-{"__metadata__"} == {r["source_name"] for r in selected}
        assert header["__metadata__"]["artifact_kind"] == "derived_lossless_tensor_subset"
        assert header["__metadata__"]["source_sha256"] == streamed["source_sha256"]
        cursor, checked = 0, []
        for r in sorted(selected, key=lambda r: r["derived_data_offsets"][0]):
            name = r["source_name"]
            h = header[name]
            assert name == r["derived_name"]
            assert h == {"dtype":r["dtype"], "shape":r["shape"], "data_offsets":r["derived_data_offsets"]}
            start, end = h["data_offsets"]
            assert cursor == start and end-start == r["bytes"]
            f.seek(8+header_size+start)
            hasher, remaining = hashlib.sha256(), end-start
            while remaining:
                data = f.read(min(chunk_bytes, remaining))
                assert data, "Truncated payload"
                hasher.update(data)
                remaining -= len(data)
            assert hasher.hexdigest() == r["source_payload_sha256"], "Tensor byte mismatch: "+name
            checked.append({"name": name, "source_payload_sha256": r["source_payload_sha256"],
                            "derived_payload_sha256": hasher.hexdigest(), "bytes_identical": True})
            cursor = end
        assert 8+header_size+cursor == path.stat().st_size
    return {"status":"verified", "derived_sha256":whole.hexdigest(), "derived_bytes":path.stat().st_size,
            "derived_header_bytes":header_size, "derived_header_sha256":hashlib.sha256(raw).hexdigest(),
            "verified_tensor_count":len(checked), "tensors":checked}


if __name__ == "__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("artifact")
    parser.add_argument("stream_manifest")
    args=parser.parse_args()
    print(json.dumps(verify(args.artifact,json.loads(Path(args.stream_manifest).read_text())),indent=2))
