"""Prepare/stream one pinned official checkpoint's verified text-only projection.

Default is metadata-only. --stream performs one bounded official HTTPS request
after the prior preflight. Never downloads a full local source, casts a tensor,
loads pretrained weights into a model, installs anything, or evicts assets.
"""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import shutil
import sys
import tarfile
import time
import urllib.request

from project_bytes import digest, make_plan
from verify_projection import verify

ROOT=Path(__file__).resolve().parents[3]
META=ROOT/"outputs/next_cpu_probe_metadata"
OUT=ROOT/"outputs/text_only_asset_projection"
DEST=OUT/"Qwen3.5-2B-derived-text"
REV="15852e8c16360a2fea060d615a32b45270f8a8fc"
MODEL="Qwen/Qwen3.5-2B"
TRANSFORMERS_REV="02d8fb9784e8f14a1251e4c992cd82a5762417c6"
SOURCE_SHA="aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1"
SOURCE_SIZE=4548221488
SHARD="model.safetensors-00001-of-00001.safetensors"
URL=f"https://huggingface.co/{MODEL}/resolve/{REV}/{SHARD}"
FLOOR=5_000_000_000
GUARD=128*1024*1024
MAX_SECONDS=1800
CHUNK_BYTES=4*1024*1024


def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(path,data):
    path=Path(path)
    with path.open("x") as f:json.dump(data,f,indent=2);f.write("\n")


def hash_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        while data:=f.read(CHUNK_BYTES):h.update(data)
    return h.hexdigest()


def preflight():
    import torch,transformers
    from transformers import Qwen3_5TextConfig,Qwen3_5ForCausalLM
    from transformers.conversion_mapping import get_checkpoint_conversion_mapping
    OUT.mkdir(parents=True,exist_ok=True)
    assert not (OUT/"preflight.json").exists(), "Preflight already exists; do not overwrite frozen plan"
    a=json.loads((META/"model_api.json").read_text())
    meta_prov=json.loads((META/"metadata_provenance.json").read_text())
    assert hash_file(META/"model_api.json")==meta_prov["files"]["model_api.json"]["sha256"]
    assert a["id"]==MODEL and a["sha"]==REV
    siblings={s["rfilename"]:s for s in a["siblings"]}
    assert siblings[SHARD]["size"]==SOURCE_SIZE and siblings[SHARD]["lfs"]["sha256"]==SOURCE_SHA
    raw=(META/"qwen35_2b_safetensors_header.json").read_bytes()
    assert len(raw)==76648 and digest(raw)=="ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d"
    header=json.loads(raw)
    index=json.loads((META/"model.safetensors.index.json").read_text())
    assert set(header)==set(index["weight_map"])
    assert set(index["weight_map"].values())=={SHARD}
    assert index["metadata"]["total_size"]==SOURCE_SIZE-8-len(raw)

    # Verify the installed loader against the previously acquired official pin,
    # without requesting or installing any software.
    archive=Path("/tmp/hybrid_transformers_02d8.tar.gz")
    prior=json.loads((ROOT/"research/diagnostics/hybrid_recurrence_cpu/provenance.json").read_text())
    assert prior["source_pins"]["transformers"]==TRANSFORMERS_REV
    assert hash_file(archive)==prior["transformers_archive"]["sha256"]
    package=Path(transformers.__file__).parent
    relevant=["models/qwen3_5/modeling_qwen3_5.py","models/qwen3_5/configuration_qwen3_5.py",
              "conversion_mapping.py","core_model_loading.py","modeling_utils.py"]
    source_files={}
    with tarfile.open(archive,"r:gz") as tf:
        for relative in relevant:
            member=f"transformers-{TRANSFORMERS_REV}/src/transformers/{relative}"
            original=tf.extractfile(member).read()
            assert digest(original)==hash_file(package/relative), "Installed official source differs: "+relative
            source_files[relative]={"sha256":digest(original),
                "official_url":f"https://github.com/huggingface/transformers/blob/{TRANSFORMERS_REV}/src/transformers/{relative}"}

    cfg=Qwen3_5TextConfig.from_pretrained(str(META),local_files_only=True)
    with torch.device("meta"):
        model=Qwen3_5ForCausalLM(cfg)
    assert {p.device.type for p in model.parameters()}=={"meta"}
    mappings=get_checkpoint_conversion_mapping(cfg.model_type)
    assert len(mappings)==1 and type(mappings[0]).__name__=="PrefixChange"
    assert mappings[0].prefix_to_remove=="language_model" and mappings[0].model_prefix=="model"
    expected=dict(model.named_parameters())
    selected,mapped,excluded=[],{},{}
    ignored=model._keys_to_ignore_on_load_unexpected
    for name,tensor in header.items():
        target,matched=mappings[0].rename_source_key(name)
        if matched is not None:
            assert target in expected and list(expected[target].shape)==tensor["shape"]
            assert target not in mapped
            selected.append(name);mapped[target]=name
        else:
            reasons=[pattern for pattern in ignored if re.match(pattern,name)]
            assert reasons,"Unknown excluded tensor: "+name
            excluded[name]=reasons
    assert set(mapped)==set(expected)
    assert len(selected)==320 and len(header)==632
    assert sum(math.prod(header[n]["shape"])for n in selected)==1881825088
    assert model.lm_head.weight is model.model.embed_tokens.weight
    assert model._tied_weights_keys=={"lm_head.weight":"model.embed_tokens.weight"}
    plan=make_plan(raw,SOURCE_SIZE,selected,SOURCE_SHA)
    assert plan["derived_payload_bytes"]==3763655360
    assert sum(r["bytes"]//4 for r in plan["tensors"] if r["selected"] and r["dtype"]=="F32")==2592

    small={}
    for name in ["config.json","tokenizer_config.json","chat_template.jinja"]:
        data=(META/name).read_bytes();s=siblings[name]
        assert len(data)==s["size"]
        assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==s["blobId"]
        small[name]={"source_path":str(META/name),"source_url":f"https://huggingface.co/{MODEL}/resolve/{REV}/{name}",
                     "bytes":len(data),"sha256":digest(data),"official_git_blob_sha1":s["blobId"]}
    tokenizer=ROOT/"outputs/hybrid_cpu_competence/Qwen3.5-0.8B/tokenizer.json"
    ts=siblings["tokenizer.json"]
    assert tokenizer.stat().st_size==ts["size"] and hash_file(tokenizer)==ts["lfs"]["sha256"]
    small["tokenizer.json"]={"source_path":str(tokenizer),"source_url":f"https://huggingface.co/{MODEL}/resolve/{REV}/tokenizer.json",
                            "bytes":ts["size"],"sha256":ts["lfs"]["sha256"],"official_lfs_sha256":ts["lfs"]["sha256"],
                            "acquisition":"Reuse existing bytes verified against 2B official pinned LFS digest; copy small tokenizer only"}
    small_bytes=sum(s["bytes"]for s in small.values())
    free=shutil.disk_usage(OUT).free
    assert free-plan["derived_size"]-small_bytes-GUARD>=FLOOR,"Disk reservation preflight failed"
    source_provenance={"model":MODEL,"revision":REV,"source_url":URL,"source_bytes":SOURCE_SIZE,
                       "official_lfs_sha256":SOURCE_SHA,"official_api_url":meta_prov["files"]["model_api.json"]["url"],
                       "official_api_sha256":hash_file(META/"model_api.json"),"source_index_sha256":hash_file(META/"model.safetensors.index.json"),
                       "source_header_sha256":digest(raw),"source_tensor_count":len(header)}
    result={"status":"metadata_preflight_pass_no_pretrained_load_or_forward","utc":now(),
            "source":source_provenance,"small_files":small,"plan_sha256":digest(json.dumps(plan,sort_keys=True).encode()),
            "transformers_revision":TRANSFORMERS_REV,"source_code":source_files,"torch_version":torch.__version__,
            "text_class":"Qwen3_5ForCausalLM","config_class":"Qwen3_5TextConfig","meta_only":True,
            "state_dict_keys":len(model.state_dict()),"unique_parameter_keys":len(expected),
            "unique_parameters":sum(p.numel()for p in model.parameters()),"mapped_keys":mapped,
            "tied_weight_aliases":model._tied_weights_keys,"excluded_keys_with_official_loader_reason":excluded,
            "stored_dtype_policy":"Retain source payload/dtype exactly; later ordinary BF16 loading is separate and may cast F32 source entries",
            "disk":{"free_before":free,"reserve_floor":FLOOR,"headroom_guard":GUARD,
                    "small_file_bytes":small_bytes,"derived_bytes":plan["derived_size"],
                    "estimated_free_after":free-plan["derived_size"]-small_bytes,
                    "max_large_files_on_disk":1,"full_source_file_written":False,"duplicate_payload":False},
            "stream_bounds":{"chunk_bytes":CHUNK_BYTES,"wall_seconds":MAX_SECONDS,"socket_timeout_seconds":60,
                             "max_source_bytes":SOURCE_SIZE,"one_request_no_automatic_retry":True},
            "artifact_path":str(DEST/"model.safetensors")}
    write_json(OUT/"projection_plan.json",plan)
    write_json(OUT/"preflight.json",result)
    print(json.dumps({k:v for k,v in result.items()if k in ["status","disk","artifact_path"]},indent=2),flush=True)


def stream_once():
    # Torch is intentionally not imported in the streaming process.
    pre=json.loads((OUT/"preflight.json").read_text())
    plan=json.loads((OUT/"projection_plan.json").read_text())
    assert digest(json.dumps(plan,sort_keys=True).encode())==pre["plan_sha256"]
    assert plan["source_sha256"]==SOURCE_SHA and plan["source_size"]==SOURCE_SIZE
    assert not DEST.exists(),"Destination already exists: refuse duplicate/retry"
    assert not (OUT/"stream_started.json").exists(),"Prior source request recorded: refuse automatic retry"
    tests=json.loads((OUT/"synthetic_test_result.json").read_text())
    assert tests["passed"] is True and tests["tests_run"]>=14
    free=shutil.disk_usage(OUT).free
    assert free-plan["derived_size"]-pre["disk"]["small_file_bytes"]-GUARD>=FLOOR
    DEST.mkdir()
    for name,s in pre["small_files"].items():
        source=Path(s["source_path"])
        assert hash_file(source)==s["sha256"] and source.stat().st_size==s["bytes"]
        with source.open("rb") as r,(DEST/name).open("xb") as w:shutil.copyfileobj(r,w,CHUNK_BYTES)
    partial=DEST/"model.safetensors.partial"
    started=time.monotonic()
    write_json(OUT/"stream_started.json",{"utc":now(),"url":URL,"source_size":SOURCE_SIZE,
               "source_sha256":SOURCE_SHA,"partial_path":str(partial),"disk_free":shutil.disk_usage(OUT).free})
    minimum_free=shutil.disk_usage(OUT).free
    def check_budget():
        nonlocal minimum_free
        free_now=shutil.disk_usage(OUT).free;minimum_free=min(minimum_free,free_now)
        if free_now<FLOOR+GUARD//2:raise RuntimeError("Disk floor safety guard crossed; stop")
        if time.monotonic()-started>MAX_SECONDS:raise TimeoutError("Acquisition wall cap reached")
    last_report=0
    def progress(value):
        nonlocal last_report
        if value["source_bytes_read"]-last_report>=256*1024*1024:
            last_report=value["source_bytes_read"]
            print(json.dumps({**value,"elapsed_seconds":time.monotonic()-started,"disk_free":shutil.disk_usage(OUT).free}),flush=True)
    try:
        with partial.open("x+b") as w:
            # Allocate only the exact one derived file, before requesting bytes.
            os.posix_fallocate(w.fileno(),0,plan["derived_size"])
            check_budget()
            request=urllib.request.Request(URL,headers={"Accept-Encoding":"identity","User-Agent":"official-pinned-lossless-text-projection/1"})
            with urllib.request.urlopen(request,timeout=60) as response:
                assert response.status==200,"Refuse partial, unexpected status, or range-cache response"
                assert int(response.headers["Content-Length"])==SOURCE_SIZE
                assert response.headers.get("Content-Encoding","identity")=="identity"
                final_url=response.url
                assert final_url.startswith("https://"),"Refuse HTTPS downgrade"
                result=__import__("project_bytes").project(response,w,plan,chunk_bytes=CHUNK_BYTES,
                            check_budget=check_budget,progress=progress,deadline=started+MAX_SECONDS)
            os.fsync(w.fileno())
        result.update(utc_finished=now(),source_url=URL,official_revision=REV,
                      final_response_host=urllib.parse.urlsplit(final_url).hostname,
                      elapsed_stream_seconds=time.monotonic()-started,minimum_free_disk_bytes=minimum_free,
                      peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        write_json(OUT/"stream_manifest.json",result)
        verification=verify(partial,result)
        check_budget()
        os.rename(partial,DEST/"model.safetensors")
        write_json(OUT/"disk_verification.json",verification)
        descriptor={"artifact_kind":"derived_lossless_text_tensor_subset_not_original_checkpoint_file",
                    "source":pre["source"],"derived_file":"model.safetensors",**verification,
                    "original_pinned_config_tokenizer":pre["small_files"],
                    "loader":"Ordinary official Qwen3_5ForCausalLM.from_pretrained with explicit Qwen3_5TextConfig; trust_remote_code=False; local_files_only=True",
                    "pretrained_model_loaded":False,"model_forward_executed":False}
        write_json(DEST/"DERIVED_ARTIFACT.json",descriptor)
        write_json(OUT/"COMPLETE.json",{"status":"verified","utc":now(),"artifact":str(DEST/"model.safetensors"),
                   "source_sha256":SOURCE_SHA,"derived_sha256":verification["derived_sha256"],
                   "verified_tensors":verification["verified_tensor_count"],"free_disk_after":shutil.disk_usage(OUT).free,
                   "minimum_free_disk_bytes":minimum_free,"total_seconds":time.monotonic()-started,
                   "peak_RSS_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                   "no_pretrained_load_or_forward":True})
        print((OUT/"COMPLETE.json").read_text(),flush=True)
    except BaseException as error:
        write_json(OUT/"FAILED.json",{"status":"failed_unverified_do_not_load","utc":now(),
                    "type":type(error).__name__,"error":str(error),"retained_partial":str(partial),
                    "elapsed_seconds":time.monotonic()-started,"minimum_free_disk_bytes":minimum_free})
        raise


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--stream",action="store_true");args=p.parse_args()
    (stream_once if args.stream else preflight)()
