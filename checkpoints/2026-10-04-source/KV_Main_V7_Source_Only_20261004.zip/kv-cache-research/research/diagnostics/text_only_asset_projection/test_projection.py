"""Tiny synthetic byte-level checks, independent safetensors parser included."""
import hashlib
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest

from project_bytes import make_plan, project, validate_header
from verify_projection import verify


def fixture():
    # Interleaved selections, odd source order, literal BF16/F32 bit patterns,
    # NaN/infinity/signed zero included: no float conversion is allowed.
    records=[("visual.a","BF16",[2],bytes.fromhex("007f80ff")),
             ("text.z","F32",[2],bytes.fromhex("0100807f00000080")),
             ("mtp.a","U8",[3],b"xyz"),
             ("text.a","BF16",[3],bytes.fromhex("803f0100c07f"))]
    header,payload,cursor={},b"",0
    for name,dtype,shape,raw in records:
        header[name]={"dtype":dtype,"shape":shape,"data_offsets":[cursor,cursor+len(raw)]}
        cursor+=len(raw); payload+=raw
    raw=json.dumps(header,separators=(",",":")).encode()
    raw+=b" "*((-len(raw))%8)
    return raw,struct.pack("<Q",len(raw))+raw+payload,records


class ShortReads(io.BytesIO):
    def read(self,n=-1):
        return super().read(min(n,3))


class ProjectionTests(unittest.TestCase):
    def setUp(self):
        self.header,self.source,self.records=fixture()
        self.plan=make_plan(self.header,len(self.source),["text.a","text.z"],hashlib.sha256(self.source).hexdigest())

    def run_projection(self,source=None,plan=None,chunk=5):
        output=io.BytesIO()
        result=project(ShortReads(self.source if source is None else source),output,self.plan if plan is None else plan,chunk_bytes=chunk)
        return output.getvalue(),result

    def test_byte_identity_short_reads_and_independent_parser(self):
        from safetensors import safe_open
        derived,result=self.run_projection()
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"derived.safetensors";path.write_bytes(derived)
            verified=verify(path,result,chunk_bytes=1)
            self.assertEqual(verified["verified_tensor_count"],2)
            with safe_open(path,framework="pt",device="cpu") as f:
                self.assertEqual(set(f.keys()),{"text.a","text.z"})
                import torch
                for name,dtype,shape,raw in self.records:
                    if name.startswith("text."):
                        self.assertEqual(f.get_tensor(name).view(torch.uint8).numpy().tobytes(),raw)

    def test_chunk_boundaries(self):
        expected,_=self.run_projection()
        for size in (1,2,3,4,7,1024):
            self.assertEqual(self.run_projection(chunk=size)[0],expected)

    def test_whole_source_hash_includes_excluded_bytes(self):
        source=bytearray(self.source);source[-9]^=1
        with self.assertRaisesRegex(ValueError,"Whole source"):
            self.run_projection(source)

    def test_selected_corruption(self):
        source=bytearray(self.source);source[-1]^=1
        with self.assertRaisesRegex(ValueError,"Whole source"):
            self.run_projection(source)

    def test_truncation(self):
        with self.assertRaisesRegex(ValueError,"Truncated"):
            self.run_projection(self.source[:-1])

    def test_trailing_bytes(self):
        with self.assertRaisesRegex(ValueError,"trailing"):
            self.run_projection(self.source+b"x")

    def test_header_corruption(self):
        source=bytearray(self.source);source[9]^=1
        with self.assertRaisesRegex(ValueError,"header digest"):
            self.run_projection(source)

    def test_header_length_corruption(self):
        source=bytearray(self.source);source[0]^=1
        with self.assertRaisesRegex(ValueError,"header length"):
            self.run_projection(source)

    def test_unknown_or_duplicate_selection(self):
        for names in ([],["unknown"],["text.a","text.a"]):
            with self.assertRaises(ValueError):
                make_plan(self.header,len(self.source),names,self.plan["source_sha256"])

    def test_shape_size_invalid(self):
        header=json.loads(self.header);header["text.a"]["shape"]=[4]
        with self.assertRaisesRegex(ValueError,"Shape/dtype"):
            validate_header(json.dumps(header).encode(),len(self.source))

    def test_gap_or_overlap(self):
        header=json.loads(self.header);header["mtp.a"]["data_offsets"]=[13,16]
        with self.assertRaisesRegex(ValueError,"overlap or gap"):
            validate_header(json.dumps(header).encode(),len(self.source))

    def test_duplicate_json_key(self):
        with self.assertRaisesRegex(ValueError,"Duplicate JSON"):
            validate_header(b'{"x":{},"x":{}}',23)

    def test_disk_verifier_detects_written_corruption(self):
        derived,result=self.run_projection();corrupt=bytearray(derived);corrupt[-1]^=1
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"derived.safetensors";path.write_bytes(corrupt)
            with self.assertRaisesRegex(AssertionError,"Tensor byte mismatch"):
                verify(path,result)

    def test_budget_stop(self):
        def stop():raise RuntimeError("reserve failed")
        with self.assertRaisesRegex(RuntimeError,"reserve failed"):
            project(io.BytesIO(self.source),io.BytesIO(),self.plan,check_budget=stop)


if __name__=="__main__":unittest.main(verbosity=2)
