# Verified lossless text-only asset preparation

**PASS, 2026-10-03 UTC.** The authorized one-shot stream completed and produced a
byte-verified derived text checkpoint while preserving the existing 5 GB disk
reserve. This result clears asset provenance/storage only. It does not authorize
or establish pretrained-model execution, numerical qualification, competence,
runtime memory fit, or scientific benefit.

## Verified artifact

Ignored local artifact:
`outputs/text_only_asset_projection/Qwen3.5-2B-derived-text/model.safetensors`

- Artifact kind: **derived lossless text-tensor subset**, not the original file
- Size: **3,763,696,896 bytes**, including an 8-byte length and 41,528-byte header
- Payload: **3,763,655,360 bytes** in **320 tensors**
- File SHA-256:
  `42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`
- Original names, shapes, dtypes and tensor bytes retained unchanged
- Storage: **284 BF16 tensors plus 36 F32 tensors**; F32 tensors contain 2,592
  elements. A later ordinary BF16 model load can cast source F32 entries and must
  separately report its actual dtypes

The original official source was
[Qwen/Qwen3.5-2B at the immutable pin](https://huggingface.co/Qwen/Qwen3.5-2B/tree/15852e8c16360a2fea060d615a32b45270f8a8fc).
Exactly **4,548,221,488 source bytes** were read in one request and hashed,
including all vision/MTP bytes that were discarded instead of written. The
whole-stream SHA-256 equaled official LFS
`aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`.
The original source header SHA-256 remained
`ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d`.

After writing/fsync, the separate disk verifier reread **all 320 selected
payloads**, verifying their hashes against the whole-source-stream per-tensor
hashes, and hashed the complete derivative. The manifest retains source and
derived relative and absolute offsets and the source hashes for all 632 tensors.
The official safetensors parser independently opened the finished artifact and
verified all 320 names, shapes and dtypes without materializing tensor payloads.

## Official text-model equivalence at the asset/schema level

The installed official Transformers revision
`02d8fb9784e8f14a1251e4c992cd82a5762417c6` has an explicit
[Qwen3.5 text prefix conversion](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/conversion_mapping.py#L1054)
and a
[text-only causal model with tied head and vision/MTP ignore rules](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/qwen3_5/modeling_qwen3_5.py#L1668-L1684).
Five relevant installed loader/model modules were checked byte-for-byte against
the already-present official pinned archive, whose complete SHA was reverified.

An official Qwen3_5ForCausalLM constructed only on the meta device exposes
320 unique parameter names, **1,881,825,088 parameters**, and 321 state-dict keys
including the tied output-head alias. Applying the actual official conversion
to the selected original names gives exact key and shape coverage. Every omitted
name matches an actual official ignore pattern. No custom model implementation,
bespoke runtime loader, initialized parameter payload or model forward was used.

Later ordinary loading must explicitly use Qwen3_5TextConfig and
Qwen3_5ForCausalLM, local files only and no remote code. Pretrained execution
remains gated by the independently frozen BF16 numerical/resource protocol.

## Config/tokenizer provenance

The derived loader directory contains unchanged original pinned small files:

- config.json, SHA-256
  `ed1c1723241f23f7f4e23430759cbd7dcfb4103cbdfe052bfe7626b57c2615b4`
- tokenizer_config.json, SHA-256
  `49e2b6e395f959f077f1e992b338919c0d4a9732fc6e613995e06557f843500c`
- chat_template.jinja, SHA-256
  `273d8e0e683b885071fb17e08d71e5f2a5ddfb5309756181681de4f5a1822d80`
- tokenizer.json, SHA-256
  `5f9e4d4901a92b997e463c1f46055088b6cca5ca61a6522d1b9f64c4bb81cb42`

The three non-LFS files match official pinned Git blob IDs. The tokenizer payload
already existed locally under the earlier 0.8B assets, but was reused only after
matching the **2B pin's** LFS digest and length. This does not reuse or relabel the
different 0.8B tokenizer configuration/chat template. All four finished copies
were hashed again after acquisition. The original full shard index is preserved
outside the derivative loader directory; the derivative is an ordinary
single-file safetensors checkpoint and does not falsely reuse that full index.

## Resource observations and restrictions

- Metadata-preflight free disk: **9,183,096,832 bytes**
- Acquisition plus independent disk verification: **137.55 seconds**
- Streaming process peak RSS: **29,274,112 bytes** under a 1 GiB virtual-memory cap
- Lowest sampled free space during streaming/verification checks:
  **5,404,770,304 bytes**; final completion metadata free space:
  **5,404,561,408 bytes**
- Later official-parser/config verification snapshot at 17:00:37 UTC:
  **5,404,536,832 bytes free**; parser process peak RSS **229,675,008 bytes**
- The unchanged 5,000,000,000-byte reserve was preserved. Roughly 404 MB remains
  above it; this is not permission for another checkpoint or unbounded outputs
- One exact-size derivative file was preallocated; no complete source file or
  second weight payload existed locally, and no previous asset was deleted
- One official request, ordinary verified HTTPS and official CDN redirect;
  no mirror, security bypass, download cache, installation, paid resource or GPU

These are sampled observations and bounded own-write guarantees, not control
over unrelated concurrent writers. The process checked the reserve for every
read chunk and stopped safely if its extra guard would be crossed.

## Checks and retained evidence

**14/14 synthetic tests passed**, including literal BF16/F32 bit preservation,
short reads/chunk boundaries, interleaved exclusions, an official parser, and
corruption/truncation/header/disk-failure negatives. The admission reviewer
independently reran all 14 before acquisition. All new Python files compile.
No existing model/protocol implementation was edited and no commit was made.

Ignored evidence under `outputs/text_only_asset_projection/`:

- `preflight.json`, `projection_plan.json`: source pin, exact allowlist,
  official model mapping, source hashes, count/shape/resource proof
- `synthetic_test_result.json`, `synthetic_tests_final.log`: executed tests and
  script hashes before source acquisition
- `stream_started.json`, `acquisition.log`, `stream_manifest.json`: single-request
  accounting, full official source hash, per-tensor hashes and offsets
- `disk_verification.json`: independent complete derivative/tensor reread
- `official_parser_verification.json`: official parser and copied metadata checks
- `COMPLETE.json`: successful terminal artifact summary
- Loader-directory `DERIVED_ARTIFACT.json`: explicit derivative identity,
  original source/config/tokenizer provenance and verified tensor hashes

**Asset gate passes. Pretrained forward admission remains separate.**
