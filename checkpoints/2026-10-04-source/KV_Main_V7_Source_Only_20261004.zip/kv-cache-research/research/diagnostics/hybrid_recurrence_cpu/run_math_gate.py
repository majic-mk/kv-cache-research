import json,resource,time
from pathlib import Path
import numpy as np
from math_adapter import *
ROOT=Path(__file__).resolve().parent
rng=np.random.default_rng(20261003)
results={'label':'Gate0 float64 algebra only; no learned model or quality claim','tests':[]}
def record(name,error,tolerance=1e-11,**meta):
    error=float(error); assert error<=tolerance,(name,error,tolerance)
    results['tests'].append(dict(name=name,max_abs_error=error,tolerance=tolerance,**meta))
def err(a,b):return np.max(np.abs(a-b),initial=0.)
# Exact two-layer witness, including forgetting and all-seam.
for r,n,a in [(1.,12,1.7),(.93,37,-.8),(.25,11,3.)]:
    s=a; z=0.
    for _ in range(n): s=r*s; z=r*z+s
    record(f'two_layer_full_r{r}',abs(z-n*r**n*a))
    for w in [0,1,n//2,n]:
        s=a; zw=0.
        for _ in range(w): s=r*s; zw=r*zw+s
        zw=r**(n-w)*zw
        record(f'two_layer_seam_r{r}_w{w}',abs((z-zw)-(n-w)*r**n*a),full=z,reused=zw,expected_missing=(n-w)*r**n*a)
    joint=np.array([[r,0],[r,r]])
    record(f'two_layer_joint_r{r}',err(np.linalg.matrix_power(joint,n)@np.array([a,0.]),[s*r**(n-w),z]))
# GDN equal and unequal heads; 3 seeds, empty identity and multiple compositions.
for seed in range(3):
 for kh,vh,kd,vd,n in [(2,2,4,3,17),(2,4,5,3,19),(1,4,3,6,9)]:
    rg=np.random.default_rng(seed);q=rg.normal(size=(n,kh,kd));k=rg.normal(size=q.shape);v=rg.normal(size=(n,vh,vd));g=-rg.uniform(.01,.4,size=(n,vh));beta=rg.uniform(0,1,size=(n,vh));initial=rg.normal(size=(vh,kd,vd))
    _,state=recurrent(q,k,v,g,beta,initial);whole=sequence_tuple(k,v,g,beta)
    record(f'gdn_affine_seed{seed}_{kh}to{vh}',err(state,whole.apply(initial)))
    t=identity(vh,kd,vd)
    for lo,hi in [(0,3),(3,7),(7,n)]:t=compose(t,sequence_tuple(k[lo:hi],v[lo:hi],g[lo:hi],beta[lo:hi]))
    record(f'gdn_compose_seed{seed}_{kh}to{vh}',max(err(t.T,whole.T),err(t.U,whole.U)))
    q2,k2=expand_qk(q,k,vh);o1,s1=recurrent(q,k,v,g,beta,initial);o2,s2=recurrent(q2,k2,v,g,beta,initial)
    record(f'gdn_group_repeat_seed{seed}_{kh}to{vh}',max(err(o1,o2),err(s1,s2)))
    for w in [0,1,4,n]:
        _,sw=recurrent(q[:w],k[:w],v[:w],g[:w],beta[:w],initial)
        interior=sequence_tuple(k[w:],v[w:],g[w:],beta[w:])
        record(f'gdn_exclude_seam_seed{seed}_{kh}to{vh}_w{w}',err(interior.apply(sw),state))
    # Negative control: replay full tuple after seam is not exclusion.
    _,sw=recurrent(q[:4],k[:4],v[:4],g[:4],beta[:4],initial)
    bad=err(whole.apply(sw),state);assert bad>1e-5
    results['tests'].append(dict(name=f'double_count_negative_seed{seed}_{kh}to{vh}',expected_nonzero=bad))
try:expand_qk(np.zeros((2,3,4)),np.zeros((2,3,4)),4)
except ValueError:results['tests'].append(dict(name='nondivisible_heads_rejected',passed=True))
else:raise AssertionError('invalid grouping accepted')
# Conv: sequential boundaries, every seam including shorter than kernel.
x=rng.normal(size=(23,7));weight=rng.normal(size=(7,4));full,tail=causal_conv(x,weight)
for split in [1,2,3,4,7,22]:
    a,at=causal_conv(x[:split],weight);b,bt=causal_conv(x[split:],weight,at)
    record(f'conv_chunk_{split}',max(err(np.concatenate([a,b]),full),err(bt,tail)))
# Immutable isolated trace includes original source seam. Removing writes is slicing, not re-forwarding interior.
isolated,_=causal_conv(x[7:],weight)
for w in [0,1,2,3,4,8,16]:
    suffix,_=causal_conv(x[7+w:],weight)
    if w and w<len(isolated):
        assert err(suffix,isolated[w:])>1e-8
results['tests'].append(dict(name='isolated_interior_reforward_negative',passed=True))
# Rephase source keys exactly; noncontiguous absolute-position causal mask.
q=rng.normal(size=(6,2,8));k=rng.normal(size=(6,2,8));v=rng.normal(size=(6,2,5));p=np.array([0,1,3,8,9,11]);qr=rope(q,p,4);kr=rope(k,p,4)
shifted=rope(kr,np.full(6,13),4);target=rope(k,p+13,4)
record('partial_rope_rephase',err(shifted,target))
record('rope_joint_shift_invariance',err(causal_attention(qr,kr,v,p,p),causal_attention(rope(q,p+13,4),target,v,p+13,p+13)))
qa=qr[-2:];ref=causal_attention(qa,kr,v,p[-2:],p);changed=v.copy();changed[-1]+=1000
check=causal_attention(qa,kr,changed,p[-2:],p);record('future_key_causal_exclusion',err(ref[:1],check[:1]))
results.update(status='PASS',peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,numpy_version=np.__version__)
(ROOT/'math_results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
