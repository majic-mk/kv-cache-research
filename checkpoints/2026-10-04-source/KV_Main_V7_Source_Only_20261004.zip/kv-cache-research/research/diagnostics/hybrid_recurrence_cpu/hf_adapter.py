"""Intended-semantics CPU reference, NOT an executed/reproduced HYPIC runtime.
This diagnostic stores source normalized layer inputs and uncompressed K/V.
Source inputs always come from a forward of the ENTIRE isolated B with seam present.
Tuple exclusion slices whole-B source inputs; it never re-forwards B[w:] in isolation.
Hidden/raw source inputs stay frozen; up to K-1 boundary convolved k/v are repaired.
Full-seam, fresh-Q, positional relocation, and endpoint donors use actual HF modules.
The reference rebuilds tuples in Python: it is not a cheap implementation or a speed claim.
"""
import copy
import numpy as np
import torch
import torch.nn.functional as F
from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
from math_adapter import sequence_tuple

def capture(model, ids):
    traces={}; handles=[]
    for i,layer in enumerate(model.model.layers):
        if hasattr(layer,'linear_attn'):
            def hook(module,args,kwargs,index=i):
                traces[index]=kwargs.get('hidden_states',args[0] if args else None).detach().clone()
            handles.append(layer.linear_attn.register_forward_pre_hook(hook,with_kwargs=True))
    try: out=model(ids,use_cache=True)
    finally:
        for h in handles:h.remove()
    return out,traces

def project(layer,hidden,history=None):
    raw=layer.in_proj_qkv(hidden).transpose(1,2)
    joined=raw if history is None else torch.cat([history,raw],-1)
    mixed=hf.causal_conv1d_fn(joined,layer.conv1d.weight.squeeze(1),layer.conv1d.bias,activation=layer.activation)[...,-hidden.shape[1]:].transpose(1,2)
    q,k,v=torch.split(mixed,[layer.key_dim,layer.key_dim,layer.value_dim],dim=-1)
    n=hidden.shape[1]
    q=q.reshape(1,n,layer.num_k_heads,layer.head_k_dim)
    k=k.reshape(1,n,layer.num_k_heads,layer.head_k_dim)
    v=v.reshape(1,n,layer.num_v_heads,layer.head_v_dim)
    b=layer.in_proj_b(hidden).sigmoid()
    g=-layer.A_log.float().exp()*F.softplus(layer.in_proj_a(hidden).float()+layer.dt_bias)
    return q,k,v,g,b,raw

def affine_apply(k,v,g,b,incoming):
    args=[x[0].double().numpy() for x in (k,v,g,b)]
    tup=sequence_tuple(*args)
    state=tup.apply(incoming[0].double().numpy())
    return torch.from_numpy(state).unsqueeze(0).to(incoming),tup

def rephase_keys(model,keys,offset):
    # Text positions use identical T/H/W axes. Add offset to segment-anchored keys.
    n=keys.shape[2]; pos=torch.full((3,1,n),offset,dtype=torch.long)
    c,s=model.model.rotary_emb(keys,pos)
    return hf.apply_rotary_pos_emb(keys,keys,c,s)[1]

def splice_interior(model,cache,source_cache,source_traces,segment_length,seam,prefix_length,repair_conv=True,oracle_traces=None,oracle_layers=()):
    """Mutates cache ending after A+B[:w] to end after A+B.
    Oracle trace dict is captured from a full A+B forward; costly and diagnostic only.
    Full attention interior source cache stays uncompressed and is rephased by |A|.
    """
    assert 0<=seam<=segment_length
    if seam==segment_length:return cache,[]
    records=[]
    for i,block in enumerate(model.model.layers):
        dest=cache.layers[i]; source=source_cache.layers[i]
        if hasattr(block,'linear_attn'):
            layer=block.linear_attn
            if i in oracle_layers:
                assert oracle_traces is not None
                all_hidden=oracle_traces[i]
                _,k,v,g,b,raw=project(layer,all_hidden)
                start=prefix_length+seam
                k,v,g,b=(x[:,start:] for x in (k,v,g,b));raw=raw[...,start:]
                # target trace contains its true convolution history already.
                boundary_count=0; provenance='full_target_prefill_oracle'
            else:
                hidden=source_traces[i]
                _,k,v,g,b,all_raw=project(layer,hidden)
                k,v,g,b=(x[:,seam:].clone() for x in (k,v,g,b));raw=all_raw[...,seam:]
                boundary_count=min(layer.conv_kernel_size-1,segment_length-seam) if repair_conv else 0
                if boundary_count:
                    # Keep all source interior hidden inputs frozen. Repair only causal conv
                    # history using already recomputed target A+seam raw projection tail.
                    joined=torch.cat([dest.conv_states[0],raw[...,:boundary_count]],-1)
                    mixed=hf.causal_conv1d_fn(joined,layer.conv1d.weight.squeeze(1),layer.conv1d.bias,activation=layer.activation)[...,-boundary_count:].transpose(1,2)
                    _,bk,bv=torch.split(mixed,[layer.key_dim,layer.key_dim,layer.value_dim],dim=-1)
                    k[:,:boundary_count]=bk.reshape(1,boundary_count,layer.num_k_heads,layer.head_k_dim)
                    v[:,:boundary_count]=bv.reshape(1,boundary_count,layer.num_v_heads,layer.head_v_dim)
                provenance='entire_isolated_B_with_seam_present'
            new,tup=affine_apply(k,v,g,b,dest.recurrent_states[0]);dest.recurrent_states[0].copy_(new)
            # Retain source frozen interior raw inputs, with genuine target left tail if short.
            tail=torch.cat([dest.conv_states[0],raw],-1)[...,-layer.conv_kernel_size:]
            dest.conv_states[0].copy_(tail)
            records.append(dict(layer=i,source=provenance,seam_excluded_tokens=seam,interior_tokens=segment_length-seam,conv_boundary_tokens=boundary_count,tuple_bytes=tup.T.nbytes+tup.U.nbytes))
        else:
            keys=rephase_keys(model,source.keys[:,:,seam:],prefix_length)
            dest.keys=torch.cat([dest.keys,keys],2)
            dest.values=torch.cat([dest.values,source.values[:,:,seam:]],2)
    assert cache.get_seq_length()==prefix_length+segment_length
    return cache,records

def endpoint_donor(base,full,recurrent=False,attention=False,conv=False):
    cache=copy.deepcopy(base)
    for dst,src in zip(cache.layers,full.layers):
        if hasattr(dst,'recurrent_states'):
            if recurrent:dst.recurrent_states={k:v.clone() for k,v in src.recurrent_states.items()}
            if conv:dst.conv_states={k:v.clone() for k,v in src.conv_states.items()}
        elif attention:
            dst.keys=src.keys.clone();dst.values=src.values.clone()
    return cache

def cache_errors(a,b):
    out=[]
    for i,(x,y) in enumerate(zip(a.layers,b.layers)):
        if hasattr(x,'recurrent_states'):
            for name,xx,yy in [('recurrent',x.recurrent_states[0],y.recurrent_states[0]),('conv',x.conv_states[0],y.conv_states[0])]:
                out.append(dict(layer=i,kind=name,max_abs=float((xx-yy).abs().max())))
        else:
            for name in ['keys','values']:out.append(dict(layer=i,kind=name,max_abs=float((getattr(x,name)-getattr(y,name)).abs().max())))
    return out
