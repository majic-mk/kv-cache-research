"""Dependency-free audit of the pinned HYPIC seam metadata control flow.

This executes an unchanged prefix extracted from the actual metadata builder.
It does not import HYPIC, torch, GPU kernels, or any model implementation.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCES = ROOT / "sources"
PIN = "98147c01909004e66d98bcb18b886927d41b0ee5"


def source_identity(path):
    raw = path.read_bytes()
    return {
        "filename": path.name,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob_sha": hashlib.sha1(
            f"blob {len(raw)}\0".encode() + raw
        ).hexdigest(),
    }


def extract_metadata_prefix():
    source = SOURCES / "gdn_backend.py"
    tree = ast.parse(source.read_text(), filename=str(source))
    cls = next(
        n for n in tree.body
        if isinstance(n, ast.ClassDef) and n.name == "GDNAttnBackend"
    )
    fn = next(
        n for n in cls.body
        if isinstance(n, ast.FunctionDef)
        and n.name == "_build_pic_recompute_metadata"
    )
    # Tensor materialization starts with C=len(compute_seg_lengths).
    cut = next(
        i for i, node in enumerate(fn.body)
        if isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "C" for t in node.targets)
    )
    last_executed_line = fn.body[cut - 1].end_lineno
    fields = [
        "compute_seg_lengths", "compute_persist_src", "compute_persist_dst",
        "compose_plan", "phys_seg_lengths", "phys_seg_prev_slots",
        "phys_persist_src", "phys_persist_dst", "phys_persist_end_offset",
    ]
    fn.body = fn.body[:cut] + [ast.Return(ast.Dict(
        keys=[ast.Constant(n) for n in fields],
        values=[ast.Name(n, ast.Load()) for n in fields],
    ))]
    module = ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))
    namespace = {}
    exec(compile(module, str(source), "exec"), namespace)
    return namespace[fn.name], {
        "method": fn.name,
        "start_line": fn.lineno,
        "last_executed_original_line": last_executed_line,
        "modification": "Truncate before tensor allocation; append a return of metadata lists",
    }


class Scalar:
    def item(self):
        return 9


def run_case(builder, cache_hit):
    seam = {(2, 7): [2, 3]} if cache_hit else {}
    batch = SimpleNamespace(
        batch_size=1,
        pic_rope_meta=[{"seam": {"hit_seam": seam}}],
        pic_hit_segments=[[(0, 2, "sys"), (2, 7, "B")] if cache_hit else []],
        pic_miss_segments=[[(7, 9)] if cache_hit else [(0, 2), (2, 7), (7, 9)]],
        pic_hit_mamba_slots=[{"sys": 1, "B": 2} if cache_hit else {}],
        pic_miss_mamba_slots=[{} if cache_hit else {(0, 2): 1, (2, 7): 2}],
    )
    backend = SimpleNamespace(
        forward_metadata=SimpleNamespace(mamba_cache_indices=[Scalar()])
    )
    return builder(
        backend, forward_batch=batch, H_v=1, V=1, K=1,
        seq_len=4 if cache_hit else 9,
        ssm_dtype=None, qkv_dtype=None, device=None, _alloc=None,
    )


def width_contract():
    path = SOURCES / "pic_init.py"
    tree = ast.parse(path.read_text(), filename=str(path))
    fn = next(
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name == "resolve_seam_sink_tokens"
    )
    namespace = {"_math": math}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(path), "exec"), namespace)
    resolver = namespace[fn.name]
    results = []
    for length in (1, 5, 10):
        for spec in (0, 0.5, 1, 2, 8, 100):
            value = resolver(spec, length - 1)
            assert 0 <= value <= length - 1
            results.append({"segment_length": length, "spec": spec, "resolved_tokens": value})
    assert resolver(1, 9) == 9
    assert resolver(100, 9) == 9
    assert resolver(8, 0) == 0
    return results


def main():
    builder, extraction = extract_metadata_prefix()
    cold = run_case(builder, False)
    replay = run_case(builder, True)
    assert cold["compute_seg_lengths"] == [2, 5, 2]
    assert cold["compute_persist_src"] == [0, 1]
    assert cold["compose_plan"][0]["seg_order"][1] == {
        "kind": "mid_miss", "mamba_slot": 2, "sink_row": None,
        "interior_row": 1, "use_pool_interior": False,
    }
    assert replay["compute_seg_lengths"] == [2, 2]
    assert replay["compute_persist_src"] == []
    assert replay["compose_plan"][0]["seg_order"][1] == {
        "kind": "mid_hit", "mamba_slot": 2, "sink_row": 0,
        "interior_row": None, "use_pool_interior": True,
    }
    assert replay["phys_seg_prev_slots"] == [1, 2]
    assert replay["phys_persist_src"] == []
    provenance = json.loads((HERE / "provenance.json").read_text())
    for row in provenance:
        found = source_identity(SOURCES / row["local_filename"])
        assert found["git_blob_sha"] == row["github_blob_sha"], row["local_filename"]
    # Derived affine illustration, not an executed source GDN kernel:
    # five fixed token maps H -> .8H+.2 versus the same five after two extra maps.
    end5 = 1 - 0.8**5
    end7 = 1 - 0.8**7
    result = {
        "status": "PASS: expected source metadata discrepancy reproduced",
        "pin": PIN,
        "scope": "Actual metadata-builder Python prefix only; no kernels/model/torch",
        "extraction": extraction,
        "fixture": {"system": [0, 2], "B": [2, 7], "query": [7, 9], "replay_seam": [2, 3]},
        "cold": cold, "replay": replay,
        "width_contract": width_contract(),
        "derived_affine_illustration": {
            "kind": "analytical consequence if each frozen token map is H -> .8H+.2",
            "five_token_endpoint": end5,
            "two_seam_then_full_five_endpoint": end7,
            "absolute_difference": end7 - end5,
            "is_hypic_kernel_execution": False,
        },
        "conclusion": "Cold B persists all 5 tokens; hit B composes fresh 2-token sink then cached pool. No seam exclusion is encoded by this metadata path.",
        "limitations": [
            "No checkpoint, generated answers, or empirical quality/latency magnitude",
            "No full SGLang scheduler or GPU kernel execution",
            "The association between pool advancement and this plan is independently source-read at gdn_backend.py:1556-1599",
            "Expected complete/valid ordinary request metadata is supplied directly; exotic request-mode reachability is not exhaustively executed",
        ],
        "source_identities": [source_identity(p) for p in sorted(SOURCES.glob("*.py"))],
    }
    output = HERE / "metadata_results.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
