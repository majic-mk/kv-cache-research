#!/usr/bin/env bash
set -euo pipefail
# Explicit setup, no pretrained weights. All dependencies are official PyPI/PyTorch packages.
# CPU Torch is pinned with +cpu; do not replace with generic PyPI torch/CUDA dependencies.
HERE=$(cd "$(dirname "$0")" && pwd)
ENV_DIR=${HYBRID_CPU_ENV:-/tmp/hybrid_recurrence_cpu_env}
PIN=02d8fb9784e8f14a1251e4c992cd82a5762417c6
if [[ ! -x "$ENV_DIR/bin/python" ]]; then
  python -m venv "$ENV_DIR"
  "$ENV_DIR/bin/pip" install --index-url https://download.pytorch.org/whl/cpu 'torch==2.9.1+cpu' 'numpy==2.2.6'
  "$ENV_DIR/bin/pip" install "https://codeload.github.com/huggingface/transformers/tar.gz/$PIN"
fi
export CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"$ENV_DIR/bin/python" "$HERE/verify_environment.py"
"$ENV_DIR/bin/python" "$HERE/run_math_gate.py"
"$ENV_DIR/bin/python" "$HERE/run_hf_gate.py"
"$ENV_DIR/bin/python" "$HERE/source_audit/run_metadata_fixture.py"
"$ENV_DIR/bin/pip" check
