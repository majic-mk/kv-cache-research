# Hybrid recurrent conditioning: CPU Gate 0

Execution date: 2026-10-03 UTC. **No pretrained weights, GPU, paid compute, commit, or push. No novel mechanism or answer-quality claim.**

## Decision

**The clean, intended-semantics reference passes its implementation gate. Faithful pinned-HYPIC baseline reproduction is blocked by source-contract discrepancies.** These are different outcomes.

- 101 NumPy float64 fixtures pass; maximum absolute algebra error is `3.55e-15` against a predeclared `1e-11` tolerance
- 32 actual-HF numerical/structural checks pass, including equal recurrent heads and unequal 2-key/4-value heads. Largest direct parity error is `2.38e-7`; largest reported cache-coordinate error is `4.77e-7`
- All-seam repair (a full-forward/no-interior-splice bypass) and the all-full endpoint donor recover fresh-Q logits exactly in these fixtures. The nontrivial source-context w=8 tuple splice also recovers every endpoint within tolerance. Sequential chunked prefill, including a 149-token case crossing 64-token GDN chunk boundaries and a single-token decode, agrees within `1.20e-7` logit absolute error
- Peak HF-process RSS in the saved run is recorded in `hf_results.json` (about **331 MiB**). CPU-only Torch has `torch.version.cuda is None`; an 8 GiB address-space limit is installed before constructing any model, and peak RSS is checked against 8 GiB afterward
- **No claim about pretrained competence, answer harm, realistic throughput, or the 0.8B/35B checkpoint follows from random 39,117-/41,313-parameter models**

`SOURCE_AUDIT.md` and its executable AST fixture explain why this cannot yet be called a source-faithful HYPIC quality baseline. For SYS length 2, B length 5 and Q length 2, the pinned cold miss stores a full five-token B row; a hit with two fresh seam tokens then composes that seam with the cached full row. This is a concrete extracted-metadata result, not an executed SGLang end-to-end failure or a measured quality bug. The source also caps seam width at `|B|-1`; the all-token diagnostic here is an explicit reference-only extension. Its warmup attention flow can condition deep source traces on SYS/earlier segments. Do not silently equate that flow with isolated-B warmup.

## Provenance and runtime

- HYPIC: `98147c01909004e66d98bcb18b886927d41b0ee5`
- Transformers: `02d8fb9784e8f14a1251e4c992cd82a5762417c6`, built from its official GitHub archive, reporting `5.19.0.dev0`
- Torch: official CPU wheel `2.9.1+cpu`; NumPy: `2.2.6`; Python 3.12
- Isolated environment used: `/tmp/hybrid_recurrence_cpu_env/bin/python`
- `provenance.json`, `source_audit/provenance.json`, and `logs/environment_verification.json` record URLs, hashes and installed-file verification
- `requirements.freeze.txt` captures package versions; `logs/install_*.log` preserve installation output. `pip check` passed

The existing environment is ephemeral. Recreate it from official packages with `bash research/diagnostics/hybrid_recurrence_cpu/reproduce.sh`; set `HYBRID_CPU_ENV` to choose a new environment path. Existing environments are verified rather than blindly overwritten. The script fails if the installed model, config, or cache source differs from the audited copies. Python/package resolver dependencies beyond the explicitly pinned Torch/NumPy/Transformers may vary on a fresh install; use the freeze file to reconstruct the remaining package versions. It does not contain pretrained model weights. See `provenance.json` for the source-archive checksum.

From the project root, run the existing environment without setup:

```sh
PY=/tmp/hybrid_recurrence_cpu_env/bin/python
D=research/diagnostics/hybrid_recurrence_cpu
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 "$PY" "$D/verify_environment.py"
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 "$PY" "$D/run_math_gate.py"
CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 "$PY" "$D/run_hf_gate.py"
"$PY" "$D/source_audit/run_metadata_fixture.py"
```

These commands regenerate result files. Saved logs/results contain actual executed output, not dry-run or predicted results. `logs/reproduce.log` is the complete final aggregate rerun; stage logs also retain their separately executed runs. Original source snapshots are unmodified. Installation and experiments touched only this diagnostic directory and temporary environment/source paths; existing Echo implementation/reports were not edited.

## Fixed-input GDN contract

HF state orientation is `S[h,key,value]`. Given normalized key `k_t`, value `v_t`, beta `β_t`, and log decay `g_t`, the direct update is:

```text
D_t = exp(g_t)
S'_t = D_t S_(t-1)
S_t  = S'_t + β_t k_t (v_t - k_t^T S'_t)^T
     = A_t S_(t-1) + U_t
A_t  = D_t (I - β_t k_t k_t^T)
U_t  = β_t k_t v_t^T
output_t = (q_t / sqrt(d_key))^T S_t
```

Both q and k use the official normalization `x / sqrt(sum(x*x)+1e-6)`. For a tuple `(T,U)`, application is `T S_in + U`. If E executes before L:

```text
compose(E,L) = (T_L T_E, T_L U_E + U_L)
empty = (I,0)
```

HYPIC's recurrent state storage has the transposed value/key convention; see the source audit for the corresponding right-multiplication form. Do not mix orientations or reverse multiplication order. The functions here accept only integer-multiple grouped heads and repeat each key/query head contiguously to match the official model. Beta, decay, values and states remain per value head.

`math_adapter.py` independently implements direct recurrence and matrix tuples; `run_math_gate.py` compares both against each other. `run_hf_gate.py` additionally compares them against both unmodified official HF kernels. The model's own `Qwen3_5GatedDeltaNet.forward` repeats grouped heads before calling the kernels; the core-kernel test does the same explicitly.

This is affine only with fixed per-token inputs. It does not make an entire nonlinear, multilayer network an affine function of its initial cache.

## Two-layer witness and limitation

The executed scalar witness uses `s_t=r s_(t-1)`, `h_t=s_t`, `z_t=r z_(t-1)+h_t`, incoming `s_0=a`, and `z_0=0`.

```text
full z_n       = n r^n a
w-token seam   = w r^n a
missing writes = (n-w) r^n a
joint state matrix = [[r,0],[r,r]]
```

Tests include `r=1`, `r=.93`, and `r=.25`, zero/partial/full seam and exact joint composition. This verifies the elementary cross-layer input effect for a forgetting recurrence. It is not an impossibility theorem: the joint state is composable. For fixed `0<r<1`, the absolute error eventually vanishes with n. The open cross-layer issue was already acknowledged upstream; this is not a discovery claim.

## Seam, convolution, positions, and oracle semantics

`hf_adapter.capture` runs the **whole isolated B**, including its original seam, and captures each recurrent layer's normalized input. The diagnostic retains tiny traces for several layers only to permit independent tests. A scalable later implementation must build one layer's tuple at a time and discard traces.

`splice_interior` begins from an actual target prefix `A+B[:w]` computed by the official model:

1. Derive cached interior tuple inputs from those unchanged, whole-isolated-B source traces and exclude exactly positions `[0,w)` from the tuple. Never re-forward `B[w:]` as a new isolated sequence; that changes its hidden inputs. No matrix inverse or numerically unstable subtraction is used
2. Correct the first at most `K-1` interior convolution outputs using the already recomputed target raw projection tail plus frozen source interior projections. This makes convolution-boundary history explicit, including w=0/1/2 and a final interior shorter than K. Deep hidden-input differences remain; convolution repair does not erase them
3. Apply the corrected interior affine tuple to the target seam endpoint. Preserve the last K raw projections expected by HF's cache (only K-1 historical values affect the next output)
4. Append every cached full-attention interior K/V, uncompressed. Keys are partial-RoPE rephased from segment-local positions to target positions by `|A|`; the nonrotary suffix is untouched. Text uses equal T/H/W positions. Cache length after splice must be exactly `|A|+|B|`
5. Recompute Q freshly through the actual model in every arm, with official absolute position construction and causal masking

The current helper reprojects source traces and rebuilds tuples in Python for auditability. Those operations, boundary-convolution repairs, and trace storage are real work. **It is not an optimized cache implementation, and these runs do not establish lower total work than recomputation.** The corrected conv/interior policy is explicitly an intended-semantics reference, not asserted identical to the author runtime.

Endpoint donor tests independently cross recurrent state (R), uncompressed attention K/V (K), and convolution state (C); all eight combinations are executed on each tiny model. A donor cache uses freshly cloned endpoint tensors, and Q is always freshly computed. All-full must recover the full reference.

The target-input oracle uses hidden inputs captured from a full target `A+B` forward. One recurrent layer at a time recovers that layer's GDN and convolution endpoint; an all-recurrent oracle plus full K/V must recover the fresh-Q logits. **The entire target prefill cost is already paid.** This is a correctness/attribution upper bound, never a deployable repair or cheap-work claim. Random-model distribution changes in `hf_results.json` are deliberately not scored as task performance.

## Files and exact coverage

- `math_adapter.py`, `run_math_gate.py`, `math_results.json`: 101 float64 assertions and expected-failure sensitivity checks; equal/grouped heads, identity, seam exclusion, convolution histories, causal positions, partial rotary rephasing
- `hf_adapter.py`, `run_hf_gate.py`, `hf_results.json`: actual 4-layer hybrid models, two GDN head layouts, direct official-kernel parity, short and long chunking, exact-prefix/fresh-Q, all-seam, immutable isolated source traces, source-context recovery, 2×2×2 endpoint donors, and per-layer target-input oracle
- `SOURCE_AUDIT.md`, `source_audit/`: upstream source-contract findings and executed metadata extraction fixture
- `sources/`: immutable audited source snapshots; `logs/`: raw execution/setup output

HF parity thresholds were agreed before outcomes: `atol=rtol=1e-4`, per-position next-token total variation at most `1e-4`, and zero greedy-token disagreements in exact controls. Each exact control records its actual deltas. Approximate reuse arms are not required to match; they are logged without declaring quality harm or benefit. The independent float64 threshold is `1e-11`.

## Smallest next pretrained gate

The immediate next gate is **competence and exact-prefix correctness only**, using the separate frozen protocol's minimal 16-cell pilot. It does not require a HYPIC comparison. Before execution it needs:

1. Explicit authorization to fetch pinned `Qwen/Qwen3.5-0.8B` weights/config/tokenizer (`2b48083dfa97c3cbf0220cf1a5e6cffe0a511157`), verify hashes and official text-only model loading, and validate the exact chat template/token boundaries. No such weights were downloaded here
2. One text-only model, batch one, CPU fp32, inference mode, selected/final-position logits, a hard 8 GiB RSS stop, and a 30-minute pilot budget including load. The tiny 331 MiB measurement is not a 0.8B memory guarantee; checkpoint parameter/loading peak must be measured
3. The protocol's two development pairs × four prefix variants × full/exact-prefix arms; fixed prompts and complete result records, without selecting only successful examples afterward
4. Stop if resource limits are exceeded, exact-prefix parity fails, or full recomputation is insufficiently competent. Do not automatically expand into the full matrix

Before any later **HYPIC** quality claim, separately resolve/declare the author-literal seam handling, warmup conditioning and source-versus-intended baseline contract, add the required comparator before looking at answer outcomes, and account for its work. A later paper-inspired corrected-reference study may be labeled as such; it is not a reproduction of this pinned author runtime. Current Gate 0 ends at that boundary.
