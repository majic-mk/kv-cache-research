# Audited upstream source notices

Files in this directory are unmodified snapshots of the pinned source repositories,
except that selected files have descriptive local names. Original copyright and
attribution notices inside them are preserved. These licenses apply to their
respective upstream files; no license for the entire research project is asserted.

- HYPIC / SGLang: `98147c01909004e66d98bcb18b886927d41b0ee5`;
  [official license](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/LICENSE)
  is preserved as `LICENSE.HYPIC`, including its SGLang copyright notice
- Hugging Face Transformers: `02d8fb9784e8f14a1251e4c992cd82a5762417c6`;
  [official license](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/LICENSE)
  is preserved as `LICENSE.Transformers`, byte-verified against the pinned
  source archive already used for installation
- Per-file origin URLs/hashes and local filename mappings remain in
  `../provenance.json` and `../source_audit/provenance.json`

The corrected CPU reference outside this directory is project-authored and
explicitly distinguished from executing or reproducing the released HYPIC runtime.
No pretrained checkpoint weights are included in this source package.
