import os
os.environ.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import copy,hashlib,json,resource,sys,time
from pathlib import Path
import numpy as np
import torch
import transformers
from transformers import Qwen3_5TextConfig,Qwen3_5ForCausalLM
from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
from math_adapter import recurrent,sequence_tuple
from hf_adapter import capture,splice_interior,endpoint_donor,cache_errors,project
ROOT=Path(__file__).resolve().parent
torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(20261003)
assert torch.version.cuda is None,'must use CPU-only wheel';assert not torch.cuda.is_available()
# Hard address-space guard supplements maximum RSS check; no GPU/model files.
cap=8*1024**3
resource.setrlimit(resource.RLIMIT_AS,(cap,cap))
results={'label':'Gate0 random tiny actual official HF model; no pretrained quality claims; intended-semantics adapter, not HYPIC runtime','torch':torch.__version__,'transformers':transformers.__version__,'cuda_build':torch.version.cuda,'device':'cpu','thresholds':{'atol':1e-4,'rtol':1e-4,'next_token_tv':1e-4,'exact_greedy_disagreement':0},'tests':[],'arms':[]}
def check(name,a,b,tol=1e-4):
    ae=float((a-b).abs().max());assert torch.allclose(a,b,atol=tol,rtol=tol),(name,ae)
    results['tests'].append(dict(name=name,max_abs_error=ae,tolerance=tol));return ae
def logits_metrics(a,b):
    tv=float((a.float().softmax(-1)-b.float().softmax(-1)).abs().sum(-1).max()/2)
    return dict(max_abs=float((a-b).abs().max()),max_tv=tv,greedy_disagreements=int((a.argmax(-1)!=b.argmax(-1)).sum()))
def check_logits(name,a,b):
    check(name,a,b);x=logits_metrics(a,b);assert x['max_tv']<=1e-4 and x['greedy_disagreements']==0,(name,x)
    results['tests'][-1].update(x)
with torch.inference_mode():
 # Independently compare float64 affine math and both unmodified official fp32 kernels.
 for kh,vh,kd,vd in [(2,2,4,3),(2,4,5,3),(1,4,3,6)]:
    n=19;q=torch.randn(1,n,kh,kd);k=torch.randn_like(q);v=torch.randn(1,n,vh,vd);g=-torch.rand(1,n,vh)*.4;b=torch.rand(1,n,vh);s=torch.randn(1,vh,kd,vd)
    qq=q.repeat_interleave(vh//kh,2);kk=k.repeat_interleave(vh//kh,2)
    yo,so=hf.torch_recurrent_gated_delta_rule(qq,kk,v,g,b,initial_state=s,output_final_state=True,use_qk_l2norm_in_kernel=True)
    yc,sc=hf.torch_chunk_gated_delta_rule(qq,kk,v,g,b,initial_state=s,output_final_state=True,use_qk_l2norm_in_kernel=True)
    na=[x[0].double().numpy() for x in (q,k,v,g,b)]
    yn,sn=recurrent(*na,initial=s[0].double().numpy())
    check(f'official_recurrent_vs_numpy_output_{kh}to{vh}',yo,torch.from_numpy(yn).unsqueeze(0).float())
    check(f'official_recurrent_vs_numpy_state_{kh}to{vh}',so,torch.from_numpy(sn).unsqueeze(0).float())
    check(f'official_chunk_vs_recurrent_output_{kh}to{vh}',yc,yo)
    check(f'official_chunk_vs_recurrent_state_{kh}to{vh}',sc,so)
 # Actual random HF hybrid models: equal heads and unequal grouped heads.
 for vh in [2,4]:
    torch.manual_seed(20261003+vh)
    cfg=Qwen3_5TextConfig(vocab_size=97,hidden_size=32,intermediate_size=64,num_hidden_layers=4,num_attention_heads=4,num_key_value_heads=2,head_dim=8,linear_key_head_dim=4,linear_value_head_dim=3,linear_num_key_heads=2,linear_num_value_heads=vh,linear_conv_kernel_dim=4,rope_parameters={'rope_type':'default','rope_theta':10000.,'partial_rotary_factor':.5,'mrope_section':[1,1,0]},layer_types=['linear_attention','linear_attention','full_attention','linear_attention'])
    cfg._attn_implementation='eager';model=Qwen3_5ForCausalLM(cfg).eval().cpu()
    assert all(p.device.type=='cpu' for p in model.parameters())
    A=torch.tensor([[2,14,7,31,19,4,8]])
    B=torch.randint(1,96,(1,35));Q=torch.tensor([[23,11,5,17]])
    AB=torch.cat([A,B],1);ids=torch.cat([AB,Q],1)
    full=model(ids,use_cache=True)
    endpoint,traces_full=capture(model,AB)
    full_q=model(Q,past_key_values=copy.deepcopy(endpoint.past_key_values),use_cache=True)
    check_logits(f'model_{vh}_exact_prefix_continuation',full_q.logits,full.logits[:,-len(Q[0]):])
    # Sequential chunk schedule crosses conv-history and GDN chunk boundaries.
    cache=None;outs=[];lo=0
    for length in [1,2,5,1,9,7,4,17]:
        if lo>=ids.shape[1]:break
        hi=min(ids.shape[1],lo+length);part=model(ids[:,lo:hi],past_key_values=cache,use_cache=True);cache=part.past_key_values;outs.append(part.logits);lo=hi
    assert lo==ids.shape[1]
    check_logits(f'model_{vh}_sequential_chunking',torch.cat(outs,1),full.logits)
    results['tests'][-1]['endpoint_errors']=cache_errors(cache,full.past_key_values)
    # Check future input cannot change earlier logits (causal positions/mask).
    perturbed=ids.clone();perturbed[:,-2:]=(perturbed[:,-2:]+13)%96
    altered=model(perturbed,use_cache=True)
    check(f'model_{vh}_future_causality',full.logits[:,:-2],altered.logits[:,:-2])
    # Full model official chunk vs official sequential recurrent kernel control.
    original=hf.torch_chunk_gated_delta_rule;hf.torch_chunk_gated_delta_rule=hf.torch_recurrent_gated_delta_rule
    try:sequential=model(ids,use_cache=True)
    finally:hf.torch_chunk_gated_delta_rule=original
    check_logits(f'model_{vh}_chunk_vs_recurrent_kernel',sequential.logits,full.logits)
    # Context longer than two 64-token GDN chunks: carry all caches, single-token decode included.
    longids=torch.randint(1,96,(1,149));lf=model(longids,use_cache=True)
    lc=None;lout=[];start=0
    for stop in [3,64,65,128,148,149]:
        piece=model(longids[:,start:stop],past_key_values=lc,use_cache=True);lc=piece.past_key_values;lout.append(piece.logits);start=stop
    check_logits(f'model_{vh}_long_149_token_chunking',torch.cat(lout,1),lf.logits)
    results['tests'][-1]['endpoint_errors']=cache_errors(lc,lf.past_key_values)
    source,iso_traces=capture(model,B)
    saved={i:t.clone() for i,t in iso_traces.items()}
    for w in [0,1,2,3,8,16,32,34,35]:
        pre=model(torch.cat([A,B[:,:w]],1),use_cache=True)
        adapted,meta=splice_interior(model,pre.past_key_values,source.past_key_values,iso_traces,B.shape[1],w,A.shape[1])
        errors=cache_errors(adapted,endpoint.past_key_values)
        result=model(Q,past_key_values=copy.deepcopy(adapted),use_cache=True)
        row=dict(heads=f'2to{vh}',seam=w,metrics=logits_metrics(result.logits,full_q.logits),endpoint_errors=errors,tuple_records=meta)
        results['arms'].append(row)
        if w==B.shape[1]:
            check_logits(f'model_{vh}_full_seam',result.logits,full_q.logits)
            assert max(e['max_abs'] for e in errors)<=1e-4
        # First recurrent layer inputs are context independent; corrected conv + affine is exact.
        first=[e for e in errors if e['layer']==0];assert max(e['max_abs'] for e in first)<=1e-4,first
        if w==8:
            # Independent R/K/C endpoint swap controls; all-full must recover.
            for R in [0,1]:
             for K in [0,1]:
              for C in [0,1]:
                d=endpoint_donor(adapted,endpoint.past_key_values,R,K,C)
                do=model(Q,past_key_values=d,use_cache=True)
                results['arms'].append(dict(heads=f'2to{vh}',donor={'R':R,'K':K,'C':C},seam=w,metrics=logits_metrics(do.logits,full_q.logits)))
                if R and K and C:check_logits(f'model_{vh}_all_full_endpoint_donor',do.logits,full_q.logits)
            # One recurrent layer at a time, separately expose the target-input oracle cost.
            for oracle_layer in traces_full:
                one=model(torch.cat([A,B[:,:w]],1),use_cache=True)
                one,one_meta=splice_interior(model,one.past_key_values,source.past_key_values,iso_traces,B.shape[1],w,A.shape[1],oracle_traces=traces_full,oracle_layers=(oracle_layer,))
                oe=cache_errors(one,endpoint.past_key_values)
                assert max(e['max_abs'] for e in oe if e['layer']==oracle_layer)<=1e-4
                oq=model(Q,past_key_values=one,use_cache=True)
                results['arms'].append(dict(heads=f'2to{vh}',oracle_target_layer=oracle_layer,seam=w,metrics=logits_metrics(oq.logits,full_q.logits),oracle_cost='entire target A+B prefill already paid',endpoint_errors=oe))
            # Oracle target layer inputs: fixed-input affine must recover each endpoint;
            # attention donor provides true KV. This costs the entire A+B reference forward.
            op=model(torch.cat([A,B[:,:w]],1),use_cache=True)
            oracle,om=splice_interior(model,op.past_key_values,source.past_key_values,iso_traces,B.shape[1],w,A.shape[1],oracle_traces=traces_full,oracle_layers=tuple(traces_full))
            oracle=endpoint_donor(oracle,endpoint.past_key_values,attention=True)
            oo=model(Q,past_key_values=oracle,use_cache=True)
            check_logits(f'model_{vh}_target_input_oracle_plus_full_kv',oo.logits,full_q.logits)
    for i in saved:assert torch.equal(saved[i],iso_traces[i]),'source trace mutated'
    results['tests'].append(dict(name=f'model_{vh}_source_trace_immutable',passed=True))
    # Exact same B source under empty prefix: exclude seam and rebuild remaining tuple.
    w=8;pre=model(B[:,:w],use_cache=True)
    exact,_=splice_interior(model,pre.past_key_values,source.past_key_values,iso_traces,B.shape[1],w,0)
    exact_errors=cache_errors(exact,source.past_key_values)
    assert max(e['max_abs'] for e in exact_errors)<=1e-4
    results['tests'].append(dict(name=f'model_{vh}_source_context_tuple_recovery',endpoint_errors=exact_errors))
    results.setdefault('models',[]).append(dict(value_heads=vh,parameters=sum(p.numel() for p in model.parameters()),config=cfg.to_dict(),input_ids={'A':A.tolist(),'B':B.tolist(),'Q':Q.tolist(),'long_chunk_control':longids.tolist()}))
results.update(status='PASS_IMPLEMENTATION_REFERENCE_ONLY',upstream_baseline_fidelity='BLOCKED_SOURCE_SEAM_AND_WARMUP_AMBIGUITY',peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rss_cap_bytes=cap)
assert results['peak_rss_kib']*1024<cap
(ROOT/'hf_results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
