# HYPIC CPU contract audit

Audited 2026-10-03 UTC. HYPIC pin: `98147c01909004e66d98bcb18b886927d41b0ee5`. Source inspection and one dependency-free metadata-prefix execution only; no model, GPU, package installation, weights, commit, or push. This report distinguishes executed source behavior from comments and from a corrected mathematical baseline.

## Decision that changes Gate 0

**Do not label a seam-excluded CPU implementation an exact reproduction of this HYPIC pin.** Its executed cold-cache/replay metadata does not exclude the replayed seam from the stored recurrent tuple. The code also uses cross-segment full attention for forwarded cold/miss tokens despite an older isolated-attention docstring. These implementation details are confounds before evaluating deeper conditioning.

A CPU gate can still establish (1) correct frozen-input affine algebra, (2) the pinned metadata discrepancy, and (3) a separately labeled seam-excluded, source-aware mathematical baseline. Passing those tests does not validate unexecuted SGLang kernels or constitute a pretrained-model result.

## 1. Affine orientation and numerical contract

HYPIC uses per-head state `H` shaped `[V,K]`, not `[K,V]`; all heads are batched over `H_v`. Its segment contract is:

```
H_out = H_in @ T_segment + U_segment
T_segment: [H_v,K,K]
U_segment: [H_v,V,K]
```

For normalized column key `k_t`, scalar decay `alpha_t=exp(g_t)` and gate `beta_t`, the equivalent token contract is:

```
A_t = alpha_t * (I - beta_t * k_t @ k_t.T)
B_t = beta_t * v_t @ k_t.T
H_t = H_(t-1) @ A_t + B_t
T_(a then b) = T_a @ T_b
U_(a then b) = U_a @ T_b + U_b
```

The individual `A_t` matrices are symmetric, but their ordered product generally is not. Symmetric/rank-one-only fixtures can therefore miss a segment-transpose or composition-order error. Use noncommuting keys, unequal `K,V`, nonzero initial state, and nonsymmetric accumulated transitions.

Evidence:

- [State shapes, shared FP32 staging, GDN backend lines 552–591](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L552-L591)
- [Explicit right-multiply/no-transpose contract and identity/zero-write transition pass, lines 1329–1349](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1329-L1349)
- [Actual composition and seeded output pass, lines 1363–1400](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1363-L1400)
- [Recompute zero-start state/identity-start transition passes, lines 1514–1547](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1514-L1547)

The pinned Transformers fallback uses `[K,V]`, so `C=H.T`, `C_out=T_segment.T @ C_in + U_segment.T`. It explicitly computes recurrence in FP32 even when the caller provides float64 tensors. A hand-written float64 algebra fixture and an extracted fallback FP32 parity fixture are different tests. [Transformers `02d8fb...`, lines 451–485](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/qwen3_5/modeling_qwen3_5.py#L451-L485)

HYPIC applies key/query L2 normalization and query scale `K**-0.5`, and stages recurrent states, transitions and seeded states in FP32. Its comments explicitly retain lower-precision `w` for consistency with its Triton kernel. A CPU float64 fixture validates algebra, not bitwise GPU scheduling parity. [Normalization, lines 1480–1507](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1480-L1507); [buffer dtypes, lines 1078–1094](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1078-L1094)

## 2. Executed seam contract versus stale comments

The exact source path is:

1. `PICache.match_prefix` never caches/reuses the last/query segment. Recompute seams apply to nonfirst cache hits only; `x_sink_eff = resolve_seam_sink_tokens(spec, segment_length - 1)`. Cached attention slots exclude the first `x_sink_eff` positions, and those positions re-enter forward. [PICache lines 274–301](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/picache.py#L274-L301)
2. Forward metadata supplies only `req.pic_hit_seam_positions` as `seam.hit_seam`. It does not supply a cold/miss seam split. [ForwardBatch lines 812–827](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/model_executor/forward_batch_info.py#L812-L827)
3. The GDN metadata builder sets `x_sink_eff=0` for first/last segments and every miss; only `kind == "hit"` can obtain a positive seam width. Consequently a cold mid-segment persists its full row despite the nearby `interior ONLY` comment. [GDN lines 889–968](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L889-L968)
4. At replay the compose loop advances the fresh sink row and then the cached pool tuple. No inverse, subtraction, or seam removal intervenes. [GDN lines 1556–1599](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1556-L1599)

This establishes a **source-level full-tuple-after-seam discrepancy**. It is not yet an end-to-end reproduced quality bug. The method docstring at lines 1417–1424 also says sink output is Pass3-only, but the executed compose loop uses its state/transition output; prefer code over that prose.

### Dependency-free execution of the actual metadata-builder prefix

Parsed `gdn_backend.py` with Python `ast`, extracted `_build_pic_recompute_metadata`, and executed its unchanged prefix up to (but not including) tensor materialization; appended a return of the generated Python lists. Inputs were simple namespace metadata and a scalar `.item()` stub. No HYPIC module import or torch installation was needed.

Fixture: SYS positions `[0,2)`, B `[2,7)`, Q `[7,9)`; replay seam positions `[2,3]`.

```
cold compute_seg_lengths = [2, 5, 2]
cold compute_persist_src = [0, 1]
cold B = {sink_row: None, interior_row: 1, use_pool_interior: False}
hit compute_seg_lengths = [2, 2]
hit compute_persist_src = []
hit B = {sink_row: 0, interior_row: None, use_pool_interior: True}
```

Thus the stored B tuple covers five tokens, then replay applies a two-token seam before that five-token tuple. This metadata execution is deliberately narrower than executing a GDN kernel.

### Width gotchas

The environment default is `PIC_SEAM_SINK=8`. A specification `0 < x <= 1` means a ratio of `max_tokens` rounded up; `x > 1` is an integer token count; nonpositive values mean zero. In particular `1` means all of the allowed `n-1` tokens, not one token. [PIC `__init__.py` lines 8–18](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/__init__.py#L8-L18)

Source replay always leaves at least one interior token. The protocol's `w=all` is a useful CPU diagnostic but requires an explicit override or complete recomputation path, not a claim that the source's normal width setting implements it. A single-token hit has no seam.

## 3. Can the corrected CPU baseline preserve hidden states generated with the seam present?

**Yes, for the intended frozen-input seam-excluded construction; that is the correct way to avoid changing the cached interior's input-generation context.** It is not source-exact for the pin above.

For each layer, generate the complete cached segment trace once under a declared cache-generation context, with B's seam still present. Preserve the suffix's actual projected/convolved keys, values and gates from that full trace. Construct an affine tuple over only positions `B[w:]`, resetting only that tuple computation's recurrent accumulator, not the lower-layer network or convolution history that produced its inputs. On replay:

```
H_after_B = H_after_fresh_seam @ T_cached_suffix + U_cached_suffix
```

Do not simply combine a fresh seam with the complete B tuple. Do not rerun `B[w:]` as a new standalone sequence and call the resulting inputs equivalent. Either approach changes the intended comparison. Keep source-generation context and replay context explicit in the fixture metadata.

Only the supplied hidden states / convolved features are frozen. Earlier-layer seam corrections generally change the true suffix inputs, and a cached suffix tuple does not reproduce that cross-layer response. Thus exactness is layer-local under identical inputs, not full-network exactness. The original recurrence witness and this construction test different claims.

Also, the source's cold tuples are zero-start **per-layer tuple computations**, but their input traces need not be globally isolated from the warmup prefix: Pass3 seeds forwarded token outputs from the composed prefix, and the full-attention path below uses cross-segment attention. The quick example warms SYS+C1+Q and SYS+C3+Q, so even its separately warmed documents include SYS context. [GDN lines 1363–1400](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1363-L1400); [quick test lines 83–94,128–132](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/quick_test_offline.py#L83-L132)

## 4. Convolution tails are raw projected inputs

- Tail data is the last `conv_width-1` **pre-convolution `mixed_qkv` rows**, not activated conv outputs and not hidden states before the projection. GDN layout is `[slot,qkv_dim,conv_width-1]`; time runs oldest to newest. KDA uses the transposed trailing layout. [Capture contract and implementation, lines 115–180](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/conv_tails.py#L115-L180)
- Source tails are captured before any convolution call, so current-batch previous-miss tails can be loaded into subsequent segments before the batched convolution. [GDN lines 1446–1478](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L1446-L1478)
- History source is the immediately preceding segment in absolute-position order. Loading uses valid nonnegative source slots and `has_initial_state`. [Tail source lookup, lines 34–75](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/conv_tails.py#L34-L75); [load, lines 78–112](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/conv_tails.py#L78-L112)
- Recurrent seam/interior boundaries are not automatically conv boundaries. A corrected cache trace must convolve the full physical segment, then slice the recurrent suffix. Zero-padding a separately convolved suffix loses the seam's required halo.
- At a hit, fresh seam convolution loads the previous segment's tail. The hit segment's cached end tail is not recaptured from the seam; the next segment loads the cached end tail. [Physical metadata, lines 979–1013](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/linear/gdn_backend.py#L979-L1013)
- The pinned helper explicitly zero-pads a segment shorter than `conv_width-1`; it does not prepend that segment's incoming older history when persisting a tail. Consequently exact continuity across arbitrary chains of very short segments is not guaranteed by this helper alone. Test this separately or constrain segments to lengths at least `conv_width-1`; do not mistake source mirroring for general mathematical correctness.
- With `w=all`, an exact-recompute diagnostic must carry freshly computed end history. Reusing the cold end tail would retain a separate convolution confound. For near-full seams leaving fewer than `conv_width-1` untouched suffix tokens, the cached tail may overlap now-recomputed seam positions; record that source behavior explicitly.

## 5. RoPE, positions, and full-attention semantics

The four initially requested files are insufficient to establish full RoPE semantics. Following their calls revealed additional pinned primary source:

- `hybrid_linear_attn_backend.py`, Git blob `a31e9a8bfb67d5bc227b586fc2c358bffb8374fe`
- `forward_batch_info.py`, blob `7a6d4e657fa219f8a2a606db5fb137fb05108145`
- `pic/__init__.py`, blob `55df64004db3dd0478c1192d0016beaef4acacfe`
- `pic/segmenter.py`, blob `f3e7ea4a08fd6f7c4962d90bf524e95bc3241d98`
- `models/qwen3_5.py`, blob `2d5b4f0903a3e770b4f0db2b712a2162f28e0236`

These were inspected through the GitHub connector at the exact pin, then saved locally in `sources/` (aliases `pic_init.py` and `hypic_qwen3_5.py` for the two ambiguous basenames). Each additional snapshot's raw bytes were checked against the connector's Git blob SHA; URLs, blob SHAs, SHA-256 hashes and byte counts are in `source_audit/provenance.json`. `pic/pic_alloc.py` was also inspected and saved (blob `7d2f3bb74183f989f08c37ec6b4cae0529c26464`). The original four files were inspected from the local source snapshots.

**Public K is segment-relative, not completely unrotated.** For a token with local offset `j` cached from segment start `s`, source K is initially `R(s+j) k`. Phase A derotates by `R(-s)`, the same offset for every token; the public cache stores `R(j) k`. A hit moved to start `s_new` receives `R(s_new)` and ends as `R(s_new+j) k`. Comments using `pos=0` mean the segment anchor is zero. [Phase A lines 1555–1585](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1555-L1585); [Phase B lines 1606–1675](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1606-L1675)

Only the rotary prefix is derotated/rerotated; the nonrotary suffix is copied unchanged. Respect the source's rotary dimension and pairing convention. V is copied, not rotated. Fresh misses retain their already-real-position K directly in private slots, avoiding a needless lower-precision round trip. [Partial rotation helpers lines 55–72](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L55-L72); [private/public writes lines 1578–1585](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1578-L1585)

This additive-offset repair assumes one fixed rotary frequency basis. It does not prove correctness across dynamic frequency epochs or arbitrary nonuniform multimodal relocation.

Forwarded positions must be actual sorted absolute prompt indices, including fresh hit seams; `number_of_cached_tokens + packed_row_index` is wrong for noncontiguous hits. Qwen consumes `pic_rope_positions`, which prefers corrected `ForwardBatch.positions`. The text-only M-RoPE branch repeats the actual text indices across three coordinate sections. [ForwardBatch lines 942–962](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/model_executor/forward_batch_info.py#L942-L962); [text M-RoPE lines 1195–1208](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/model_executor/forward_batch_info.py#L1195-L1208); [Qwen lines 976–982](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/models/qwen3_5.py#L976-L982)

**Do not copy the stale isolated-attention docstring.** The executed path makes Phase A a KV-only writer and sends all miss Qs, hit seams, and query Qs to cross-segment Phase C. For Qwen, the causal KV view is all prior segments plus the current segment prefix through the absolute query position. Recomputed seam K/V overwrites the corresponding private hit slots; cached public slots remain unchanged. [Executed dispatch lines 1503–1523](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1503-L1523); [causal planning and seam replacement lines 1829–1893](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/layers/attention/hybrid_linear_attn_backend.py#L1829-L1893)

## 6. Quick-test interpretation and minimum CPU controls

The supplied script compares six modes, warms C1 and C3 but not C2, and uses SYS as a first segment; it intentionally creates hit-after-miss. Its final score is first divergence within 32 generated tokens relative to prefix-cache/full-recompute divergence, not an answer-quality metric or CPU parity test. [Quick test lines 128–178](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/quick_test_offline.py#L128-L178); [scoring lines 192–226](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/quick_test_offline.py#L192-L226)

`<<PIC_SEP>>` is stripped before independent per-part tokenization with `add_special_tokens=False`; baseline text is concatenated before tokenization. Those procedures need not produce identical token IDs at boundaries. A CPU comparison must use one explicitly fixed token sequence in every arm. [Segmenter lines 14–34](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/python/sglang/srt/pic/segmenter.py#L14-L34); [prompt construction lines 83–94](https://github.com/redai-studio/HYPIC/blob/98147c01909004e66d98bcb18b886927d41b0ee5/examples/pic/quick_test_offline.py#L83-L94)

Required separation for reporting:

1. Frozen-input affine parity: sequential recurrence, tuple application, tuple composition, HYPIC/HF transpose relation, grouped heads, empty identity segment, noncommuting transitions
2. Pinned metadata witness: full cold tuple followed by hit seam; reported as a source discrepancy, without quality claims
3. Corrected seam-excluded witness: preserve the original cached input trace, convolve with its seam halo, form suffix-only tuple, fresh seam exactly once
4. Convolution checks: raw-input tails, immediately prior physical segment, short-segment histories, cached versus fully recomputed endpoint tail
5. Positional checks: absolute causal positions, local-offset public K, partial rotary unchanged suffix, same frequency epoch, exact tokens/separators
6. Numerical checks: float64 algebra separately from FP32 fallback; do not claim float64 fallback execution because its inputs were float64

The remaining research question can only be attributed to deeper conditioning after these adapter/source confounds are controlled and a checkpoint can solve the examples. This audit supplies no answer-harm evidence and no novelty claim.

## Reproducible source fixture artifacts

- Run: `python research/diagnostics/hybrid_recurrence_cpu/source_audit/run_metadata_fixture.py`
- Executable fixture: `source_audit/run_metadata_fixture.py`
- Machine-readable result: `source_audit/metadata_results.json`
- Raw stdout: `source_audit/metadata_raw.log`
- Additional exact-source provenance: `source_audit/provenance.json`

Execution passed all expected metadata and width assertions. Its `PASS` means the specified metadata discrepancy was reproduced; it does not mean the pinned replay is correct. Syntax compilation of the fixture also passed. The result records all source snapshot identities and clearly separates the executed metadata from a derived scalar affine illustration.

## Review of the delivered CPU reference

Reviewed `math_adapter.py`, `hf_adapter.py`, `run_math_gate.py`, and `run_hf_gate.py` after their initial passing run. No numerical or state-orientation defect was found in that reading. The equal/grouped-head tests, independent direct recurrence, fixed whole-B trace, absolute-position attention, same-source-context recovery, and official-module continuation are useful controls. This was a source review of the adapter, not an independent rerun of its torch tests.

Important interpretation limits:

- `hf_adapter.py:73–89` keeps cached hidden states and projected raw interior inputs frozen but repairs the first `conv_width-1` interior **convolved** keys/values using fresh target seam history. It therefore reconstructs a prefix-dependent suffix tuple. This is stronger than the pinned runtime's cached-interior reuse and must be disclosed separately; prose saying all projected/convolved inputs remain fixed would be inaccurate. The adapter already disclaims speed and source reproduction.
- `splice_interior(..., seam=segment_length)` returns the already fully forwarded target cache before entering the splice loop. Its parity test validates the full-recompute/no-op boundary case, not the approximate interior machinery. `run_hf_gate.py`'s same-source-context suffix recovery at `w=8` is a stronger nontrivial positive splice control.
- Target-input oracle traces were captured from a full target `A+B` forward. They test layer-local affine implementation and attribution, not an available cheap repair. All-full endpoint donor recovery similarly validates cache replacement/continuation wiring. Their cost labels correctly state that the full target computation was paid.
- All comparison models are tiny, randomly initialized official Qwen modules. Configurable equal/grouped heads and partial text RoPE exercise architecture components; no result establishes pretrained 0.8B answer quality, 35B-A3B magnitude, multimodal relocation, or a dynamic-RoPE frequency-epoch repair.
- The original `reproduce.sh` inspected during review referenced nonexistent `source_audit/check_cold_hit_metadata.py`; the delivered filename is `source_audit/run_metadata_fixture.py`. This path issue was reported to the parent for correction. No adapter or harness file was modified by this audit.

Final integration check by the implementation owner: the reproduction path was corrected to `source_audit/run_metadata_fixture.py`, and the complete `reproduce.sh` run subsequently passed, including that metadata fixture and `pip check`. See `logs/reproduce.log`.
