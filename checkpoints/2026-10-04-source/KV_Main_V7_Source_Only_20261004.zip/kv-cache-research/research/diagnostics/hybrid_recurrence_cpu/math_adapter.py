"""CPU float64 oracle for fixed-input Gated DeltaNet; no learned weights.
State convention: S[h,key,value], S_t=A_t@S_{t-1}+U_t.
Tuple: (T,U), apply = T@incoming+U, compose later after earlier.
Every trace passed here is fixed; these functions do not claim full-network affinity.
"""
from dataclasses import dataclass
import numpy as np

@dataclass
class Tuple:
    T: np.ndarray
    U: np.ndarray
    def apply(self, state): return self.T @ state + self.U

def identity(heads, kd, vd, dtype=np.float64):
    return Tuple(np.broadcast_to(np.eye(kd,dtype=dtype),(heads,kd,kd)).copy(), np.zeros((heads,kd,vd),dtype=dtype))

def compose(earlier, later):
    return Tuple(later.T@earlier.T, later.T@earlier.U+later.U)

def expand_qk(q,k,value_heads):
    h=k.shape[-2]
    if q.shape[-2]!=h or value_heads<h or value_heads%h: raise ValueError('value heads must be positive integer multiple of query/key heads')
    return np.repeat(q,value_heads//h,axis=-2),np.repeat(k,value_heads//h,axis=-2)

def normalize(x): return x/np.sqrt(np.sum(x*x,axis=-1,keepdims=True)+1e-6)

def token_tuple(k,v,g,beta):
    h,d=k.shape
    return Tuple(np.exp(g)[:,None,None]*(np.eye(d)[None]-beta[:,None,None]*k[:,:,None]*k[:,None,:]),beta[:,None,None]*k[:,:,None]*v[:,None,:])

def sequence_tuple(k,v,g,beta,normalize_qk=True):
    _,k=expand_qk(k,k,v.shape[-2]); k=normalize(k) if normalize_qk else k
    out=identity(v.shape[-2],k.shape[-1],v.shape[-1],k.dtype)
    for kt,vt,gt,bt in zip(k,v,g,beta): out=compose(out,token_tuple(kt,vt,gt,bt))
    return out

def recurrent(q,k,v,g,beta,initial=None,normalize_qk=True):
    q,k=expand_qk(q,k,v.shape[-2]); q,k=(normalize(q),normalize(k)) if normalize_qk else (q,k)
    q=q/np.sqrt(q.shape[-1]); state=np.zeros((v.shape[-2],k.shape[-1],v.shape[-1]),dtype=v.dtype) if initial is None else initial.copy()
    ys=[]
    for qt,kt,vt,gt,bt in zip(q,k,v,g,beta):
        # Deliberately direct update, independent from token_tuple's matrix algebra.
        state=state*np.exp(gt)[:,None,None]
        mem=np.einsum('hkv,hk->hv',state,kt)
        state=state+kt[:,:,None]*(bt[:,None]*(vt-mem))[:,None,:]
        ys.append(np.einsum('hkv,hk->hv',state,qt))
    return np.stack(ys) if ys else np.empty((0,v.shape[-2],v.shape[-1])),state

def causal_conv(x,weight,history=None):
    """x[T,C], weight[C,K], ordered oldest->newest; returns output and K-1 raw inputs."""
    width=weight.shape[1]; history=np.zeros((width-1,x.shape[1]),dtype=x.dtype) if history is None else history
    assert history.shape==(width-1,x.shape[1])
    cat=np.concatenate([history,x]); y=np.stack([(cat[t:t+width]*weight.T).sum(0) for t in range(len(x))]) if len(x) else x.copy()
    return y,cat[-(width-1):].copy() if width>1 else cat[:0].copy()

def rope(x,positions,rotary_dim,theta=10000.):
    assert rotary_dim%2==0 and rotary_dim<=x.shape[-1]
    freq=theta**(-np.arange(0,rotary_dim,2)/rotary_dim)
    phase=np.asarray(positions)[:,None]*freq[None,:]; c=np.cos(phase)[:,None,:]; s=np.sin(phase)[:,None,:]
    a,b=x[...,:rotary_dim//2],x[...,rotary_dim//2:rotary_dim]
    return np.concatenate([a*c-b*s,b*c+a*s,x[...,rotary_dim:]],axis=-1)

def causal_attention(q,k,v,qpos,kpos):
    score=np.einsum('thd,shd->hts',q,k)/np.sqrt(q.shape[-1])
    allowed=np.asarray(kpos)[None,:]<=np.asarray(qpos)[:,None]
    score=np.where(allowed[None],score,-np.inf); score-=score.max(-1,keepdims=True)
    p=np.exp(score); p/=p.sum(-1,keepdims=True)
    return np.einsum('hts,shd->thd',p,v)
