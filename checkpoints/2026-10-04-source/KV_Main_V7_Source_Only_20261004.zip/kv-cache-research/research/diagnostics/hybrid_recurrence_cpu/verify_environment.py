"""Fail if the actual installed model/cache source differs from the audited pin."""
import hashlib,json, pathlib
import torch,transformers
from transformers.models.qwen3_5 import modeling_qwen3_5,configuration_qwen3_5
from transformers import cache_utils
ROOT=pathlib.Path(__file__).resolve().parent
assert torch.__version__=='2.9.1+cpu' and torch.version.cuda is None
out={'torch':torch.__version__,'transformers':transformers.__version__,'checked':[]}
for module,name in [(modeling_qwen3_5,'modeling_qwen3_5.py'),(configuration_qwen3_5,'configuration_qwen3_5.py'),(cache_utils,'cache_utils.py')]:
 actual=pathlib.Path(module.__file__).read_bytes();source=(ROOT/'sources'/name).read_bytes()
 assert actual==source, f'{name}: source mismatch'
 out['checked'].append({'file':name,'sha256':hashlib.sha256(actual).hexdigest()})
print(json.dumps(out,indent=2))
