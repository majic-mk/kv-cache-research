"""CPU lexical leakage screen; reads context IDs/tokens, never labels/predictions."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
m = json.loads((ROOT/'configs/data/longbench_pilot.manifest.json').read_text())
data=[]
for name,a in m['artifacts'].items():
    for line in (ROOT/a['contexts']['path']).read_text().splitlines():
        row=json.loads(line)
        tokens=row['context_token_ids'][len(m['template']['prefix_token_ids']):]
        shingles={tuple(tokens[i:i+5]) for i in range(len(tokens)-4)}
        data.append((name,row['context_id'],shingles))
results=[]
for name,cid,shingles in data:
    if not name.endswith('.development'):
        continue
    for other,other_id,other_shingles in data:
        if not other.endswith('.heldout'):
            continue
        intersection=len(shingles & other_shingles)
        results.append({'development_task':name,'development_context_id':cid,
            'heldout_task':other,'heldout_context_id':other_id,
            'token5_shingle_jaccard':intersection/len(shingles | other_shingles),
            'containment_of_smaller':intersection/min(len(shingles),len(other_shingles))})
results.sort(key=lambda x:x['token5_shingle_jaccard'],reverse=True)
out={'scope':'48-context frozen superset, development-vs-heldout pairs; context token IDs only, no gold/predictions inspected',
     'metric':'Set Jaccard of contiguous 5-token shingles after chat prefix; simple lexical screen, not proof of repository independence or absence of contamination',
     'pairs':len(results),'top5':results[:5],
     'pairs_jaccard_at_least_0_5':sum(x['token5_shingle_jaccard']>=.5 for x in results),
     'pairs_containment_at_least_0_8':sum(x['containment_of_smaller']>=.8 for x in results)}
print(json.dumps(out,indent=2))
