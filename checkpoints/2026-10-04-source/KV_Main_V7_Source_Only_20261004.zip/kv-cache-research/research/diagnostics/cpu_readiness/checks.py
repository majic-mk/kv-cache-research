"""Read-only CPU readiness probes. Synthetic predictions are never model evidence.

Run from repository root using data_prep/local/venv/bin/python. No package
installation, network access, weights, CUDA, or source implementation changes.
Temporary configs use an explicitly fixture-valued inventory for dry-run only;
it is not a usable/frozen GPU environment and is removed on exit.
"""
from pathlib import Path
import ast
import importlib.util
import json
import platform
import subprocess
import tempfile

from echo_pilot import BACKEND_COMMIT
from echo_pilot.configure import make_config
from echo_pilot.cli import run
from echo_pilot.contracts import validate_config, ContractError
from data_prep.metrics import evaluate, METRIC
from data_prep.prepare_longbench import load_tokenizer
from kv_harness.results import validate_result
from kv_harness.common import ValidationError

ROOT = Path(__file__).resolve().parents[3]
report = {"evidence": "CPU contract probes and deterministic workload estimates; no model experiment", "python": platform.python_version(),
          "gpu_used": False, "weights_downloaded": False, "external_spend": 0, "probes": [], "plans": []}

def probe(name, fn, expected=None):
    try:
        value = fn()
    except Exception as exc:
        if expected is None or not isinstance(exc, expected):
            raise
        report["probes"].append({"name": name, "status": "expected_rejection", "exception": type(exc).__name__, "message": str(exc)})
    else:
        if expected:
            raise AssertionError(name + " unexpectedly accepted")
        report["probes"].append({"name": name, "status": "passed", "value": value})

labels = [{"question_id": "fixture-q", "dataset": "lcc", "metric": METRIC, "reference_texts": ["return 1"]}]
raw = {"build_id": "c00000-echo-r00", "context_id": "fixture-context", "question_id": "fixture-q", "arm": "echo", "eviction_ratio": .5,
       "evidence_kind": "fixture_only", "query_token_ids_sha256": "0"*64, "cache_clone_seconds": 0, "query_generation_seconds": 0,
       "query_peak_memory": {}, "query_cache": {}, "generated_token_ids": [1], "text": "return 1", "text_with_special_tokens": "return 1", "stopped_on_eos": False, "generated_token_count": 1}
probe("raw_pilot_to_official_metric", lambda: evaluate([raw], labels), ValueError)
probe("raw_pilot_to_harness", lambda: validate_result(raw), ValidationError)
projected = {"question_id": raw["question_id"], "prediction": raw["text"]}
probe("single_arm_projection_metric", lambda: evaluate([projected], labels)["scores_percent"])
probe("unpartitioned_arms_projection_duplicate", lambda: evaluate([projected, projected], labels), ValueError)
probe("missing_predictions_fail_closed", lambda: evaluate([], labels), ValueError)

manifest_path = ROOT / "configs/data/longbench_pilot.manifest.json"
manifest = json.loads(manifest_path.read_text())
lock = json.loads((ROOT / "configs/data/longbench_sources.lock.json").read_text())
_, _, _, _, encode = load_tokenizer(lock, ROOT / "data_prep/local")
prefix = len(manifest["template"]["prefix_token_ids"])
suffix = len(manifest["template"]["suffix_token_ids"])
p0 = len(encode("\n\nRepeat the previous context exactly."))
p1 = len(encode("\n\nRepeat the part of the previous context exactly, starting with"))
report["real_tokenizer_lengths"] = {"prefix":prefix,"suffix":suffix,"first_prompt":p0,"later_prompt":p1,"first_context_anchor":2048-p0-suffix}

def replay_plan(n, echo_partition):
    remaining = n-prefix
    sizes = []
    cap = 2048-p0-suffix if echo_partition else 2048
    while remaining:
        size = min(remaining, cap)
        sizes.append(size)
        remaining -= size
        cap = 2048
    return [size + (p0 if i==0 else p1 + min(8,sizes[i-1])) + suffix for i,size in enumerate(sizes)]

rev = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
report["source_head_at_audit"] = rev
with tempfile.TemporaryDirectory(prefix="kv-readiness-") as tmp:
    tmp = Path(tmp)
    packages = tmp / "fixture-packages.json"
    packages.write_text(json.dumps({"python_version":platform.python_version(),"backend_commit":BACKEND_COMMIT,
        "packages":{n:"fixture-do-not-execute" for n in ["torch","transformers","kvpress","numpy","peft"]}}))
    for preset, split in [("smoke8k","development"),("pilot16k","development"),("pilot16k","heldout")]:
        for task in ["lcc","repobench-p"]:
            cfgpath = tmp / f"{task}-{preset}-{split}.json"
            make_config(ROOT,manifest_path,packages,rev,task,split,preset,cfgpath)
            plan = run(cfgpath,None,False)
            cfg = json.loads(cfgpath.read_text())
            artifact = manifest["presets"][preset]["artifacts"][f"{task}.{split}"]
            contexts = [json.loads(x) for x in (ROOT/artifact["contexts"]["path"]).read_text().splitlines()]
            questions = [json.loads(x) for x in (ROOT/artifact["questions"]["path"]).read_text().splitlines()]
            total_replay_tokens = total_replay_passes = 0
            k = len(cfg["selection"]["eviction_ratios"])
            for ctx in contexts:
                n = len(ctx["context_token_ids"])
                author = replay_plan(n,False)
                matched = replay_plan(n,True)
                total_replay_tokens += k*(matched[0]+sum(author)+sum(matched))
                total_replay_passes += k*(1+len(author)+len(matched))
            report["plans"].append({"preset":preset,"split":split,"task":task,"contexts":len(contexts),"questions":len(questions),
                "builds":plan["cache_builds"],"eviction_ratios":cfg["selection"]["eviction_ratios"],
                "warmup_builds":0,"repeated_measurement_builds":0,"independent_prefill_input_tokens":sum(len(c["context_token_ids"]) for c in contexts)*(1+3*k),
                "exact_replay_passes":total_replay_passes,"exact_replay_input_tokens":total_replay_tokens,
                "query_lengths":[len(q["question_token_ids"]) for q in questions],
                "max_generation_tokens":len(questions)*(1+3*k)*cfg["generation"]["max_new_tokens"]})
            if preset=="smoke8k" and task=="lcc":
                bad=dict(cfg);bad["warmups"]=1
                probe("pilot_rejects_unimplemented_warmup_knob",lambda:validate_config(bad),ContractError)
                bad2=dict(cfg);bad2["replicates"]=3
                probe("pilot_rejects_unimplemented_repeat_knob",lambda:validate_config(bad2),ContractError)
                bad3=dict(cfg);bad3["arms"]=["fullkv"]
                probe("pilot_rejects_single_arm_stage",lambda:validate_config(bad3),ContractError)
report["installed_model_dependencies"] = {n: bool(importlib.util.find_spec(n)) for n in ["torch","transformers","kvpress"]}
# No shell/model inference occurred. These counts describe current serial loops,
# not runtime, FLOPs, statistical power, speed, or score.
print(json.dumps(report, indent=2))
