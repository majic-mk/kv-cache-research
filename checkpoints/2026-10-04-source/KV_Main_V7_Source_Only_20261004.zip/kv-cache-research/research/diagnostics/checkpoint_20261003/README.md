# Reviewed CPU checkpoint verification

Date: 2026-10-03 UTC. Final implementation files were stable before these reruns.
This report supersedes historical aggregate counts in earlier review snapshots.

## Automated tests

| Suite | Passed | Skipped | Environment |
|---|---:|---:|---|
| General harness | 46 | 0 | Base Python |
| Pilot, dependency-light | 159 | 5 | Base Python; native imports unavailable |
| Pilot, native rerun | 164 | 0 | Existing `/tmp/kv_tiny_qwen_cpu_20261003` |
| Pinned data preprocessing | 15 | 0 | Existing `data_prep/local/venv` |
| Calibration arithmetic | 29 | 0 | Base Python |
| Calibration methods/controls | 41 | 0 | Base Python + NumPy |
| Rejected backup-codec arithmetic | 6 | 0 | Base Python |
| Native tensor/archive operations | 20 | 0 | Existing `/tmp/kv_native_cpu_20261003` |
| Tiny random-Qwen integration | 12 | 0 | Existing `/tmp/kv_tiny_qwen_cpu_20261003` |
| Native calibration experiment subset | 5 | 0 | Existing native Qwen environment; already in pilot count |

**333 distinct test cases passed**, with zero failures/errors. The five optional
native skips in the dependency-light pilot passed in the native environment.
Neither the second pilot run nor its 24 dedicated experiment CPU and five native
experiment subsets are added again. The tiny-Qwen runner also reruns the pilot;
that repeat is not an additional 164 distinct cases. The six backup-codec checks
remain evidence only for an already rejected candidate, not Echo model readiness.

`execution_results.json` preserves each exact command, observed unittest counts,
exit status, duration and log SHA-256. The `*.log` files are the rerun output.
`source_integrity.json` pins the final implementation/test inputs. Review-only
supplemental adversarial probes (14 experiment cases and earlier review probes)
are described in their independent reviews and are not added to the total above.

## Additional checks

- Offline stage verification with the already installed pinned tokenizer passed
- All **64 planned baseline-stage builds** remain unexecuted; verification checks
  deterministic input/replay counts only
- Both local frozen calibration plans passed default no-execution validation
- The inert admission example was recomputed; its rates and durations are
  hypothetical, not an actual quote, runtime measurement or execution release
- Compile checks and `git diff --check` passed
- Both existing native CPU environments passed `pip check`; no installation was
  performed for this checkpoint
- Tracked/intended source and reachable Git history were inspected for excluded
  data, credential patterns, oversized files and symlinks. Raw/reversible benchmark
  plan JSONs remain ignored; there are no environment, weight or private-note files
  in the checkpoint. This bounded inspection is not a formal secret-detection proof

## Evidence limits and delivery

Native packages are CPU Torch 2.9.1+cpu, NumPy 2.2.6 and, in the Qwen environment,
Transformers 5.2.0. The Qwen model is a freshly initialized 22,720-parameter random
architecture with synthetic token inputs. It tests real DynamicCache, Q/K norm
and SDPA integration, not pretrained quality or Qwen3-8B parity. Native experiment
orchestration tests explicitly patch the GPU timing/load/verification boundary;
they cannot create a real-model baseline release.

No GPU was used, pretrained weights downloaded, resource rented, paid action
performed or scientific effect established. Physical cache backing storage stays
dense. Project spend remains CNY0 within the approved cumulative CNY100, and all
existing AutoDL resources are excluded. AutoDL login was verified, but actual new
resource offer, full GPU environment/assets, real baseline and external shutdown
control remain separate gates. Experiments stay deferred.

Only local Git is committed for this checkpoint. The last GitHub verification
(08:59 UTC) described a partial prior checkpoint; it is not assurance about later
remote state. GitHub App selected-repository access remains pending explicit
confirmation, and no grant or push is performed here.

The source ZIP contains a Git-tracked source tree, local history bundle, exact
local source commit, and byte/hash manifest. It excludes local environments,
benchmark source/token inputs and generated natural replay plans. Reproduce the
pinned local data before running data-dependent suites; regenerate private plans
using `research/calibration_experiment.md`. Historical reviews accurately refer
to their original dirty pre-commit source snapshots; source clean status belongs
to the final local checkpoint, not retroactively to those runs.
