"""Load complete, hash-checked, locally audited modules with real dependencies.

The two package namespace shells deliberately do not execute kvpress.__init__,
which imports unrelated presses/PEFT. No source AST/import edits or Torch/model
shims. This is not a full pip-installed kvpress distribution smoke test.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType

ROOT = Path(__file__).resolve().parents[3]
SOURCES = ROOT / "research/sources/echopress_39748e9"
AUDIT = ROOT / "echo_pilot/vendor_audit"
MODULES = (
    ("kvpress.utils", AUDIT / "kvpress__utils.py", "kvpress/utils.py", AUDIT),
    ("kvpress.presses.base_press", AUDIT / "kvpress__presses__base_press.py", "kvpress/presses/base_press.py", AUDIT),
    ("kvpress.presses.echo_press_kernels", SOURCES / "kvpress/presses/echo_press_kernels.py", "kvpress/presses/echo_press_kernels.py", SOURCES),
    ("kvpress.presses.kvzip_press", SOURCES / "kvpress/presses/kvzip_press.py", "kvpress/presses/kvzip_press.py", SOURCES),
    ("kvpress.presses.echo_press", SOURCES / "kvpress/presses/echo_press.py", "kvpress/presses/echo_press.py", SOURCES),
    ("kvpress.attention_patch", AUDIT / "kvpress__attention_patch.py", "kvpress/attention_patch.py", AUDIT),
)


def load_audited_modules():
    if "kvpress" in sys.modules:
        raise RuntimeError("Use this diagnostic in a fresh Python process")
    pins = []
    for name, path, original, provenance_root in MODULES:
        manifest = json.loads((provenance_root / "provenance.json").read_text())
        record = next(item for item in manifest["files"] if item["path"] == original)
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        if sha != record["local_sha256"]:
            raise RuntimeError(f"Audited source changed: {path}")
        pins.append(dict(module=name, local_path=str(path.relative_to(ROOT)), sha256=sha,
                         source_url=record["source_url"], commit=manifest["commit"]))
    for name in ("kvpress", "kvpress.presses"):
        package = ModuleType(name)
        package.__path__ = []
        package.__spec__ = importlib.util.spec_from_loader(name, loader=None, is_package=True)
        sys.modules[name] = package
    loaded = {}
    for name, path, _, _ in MODULES:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        loaded[name] = module
    package = sys.modules["kvpress"]
    package.EchoPress = loaded["kvpress.presses.echo_press"].EchoPress
    package.KVzipPress = loaded["kvpress.presses.kvzip_press"].KVzipPress
    package._diagnostic_loaded_source_pins = pins
    return package, loaded["kvpress.attention_patch"]
