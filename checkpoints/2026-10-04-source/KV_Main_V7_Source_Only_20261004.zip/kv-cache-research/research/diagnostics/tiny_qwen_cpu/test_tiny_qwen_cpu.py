"""Real random Qwen3/DynamicCache/SDPA integration; CPU float32 only.

No pretrained model, real tokenizer, quality benchmark, CUDA or paid resources.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import os
import sys
import unittest
from unittest.mock import patch

os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import transformers
from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS
from source_loader import load_audited_modules
from echo_pilot import calibration_runtime as runtime
from echo_pilot.calibration_runtime import (COMMON_PROMPT, CalibrationBuildError,
    prepare_common_replay, build_candidate, build_full_exact_diagnostic,
    clone_query_cache, answer_candidate, mask_indices_to_keep)
from echo_pilot.contracts import PreparedContext
from echo_pilot.runtime import cache_bytes, clear_masks, independent_cache
from research.calibration_methods.methods import plan_anchors, plan_anchor_matrix

KVPRESS, ATTENTION = load_audited_modules()
ORIGINAL_ATTENTION = dict(ALL_ATTENTION_FUNCTIONS.items())
ATTENTION.patch_attention_functions()
PATCHED_SDPA = ALL_ATTENTION_FUNCTIONS['sdpa']
DEPS = SimpleNamespace(torch=torch, transformers=transformers, kvpress=KVPRESS)
SEED = 17
MODEL_CONFIG = dict(vocab_size=64, hidden_size=32, intermediate_size=64,
    num_hidden_layers=2, num_attention_heads=4, num_key_value_heads=2, head_dim=8,
    max_position_embeddings=128, attn_implementation='sdpa',
    eos_token_id=2, bos_token_id=1, pad_token_id=0, attention_dropout=0.0)
OBSERVATIONS = {}


class TokenizerShim:
    """Explicit synthetic encoding; the declared 'revision' is a fixture token."""
    chat_template = 'tiny random Qwen integration diagnostic template'
    def apply_chat_template(self, messages, **kwargs):
        return 'PREFIX' + messages[0]['content'] + 'SUFFIX'
    def encode(self, text, add_special_tokens=False):
        return {'PREFIX': [1, 3], 'SUFFIX': [4], COMMON_PROMPT: [5, 6, 7]}[text]
    def decode(self, ids, skip_special_tokens=False):
        return ' '.join(str(x) for x in ids if not skip_special_tokens or x not in (0, 1, 2))


def fixture():
    torch.manual_seed(SEED)
    model = transformers.Qwen3ForCausalLM(transformers.Qwen3Config(**MODEL_CONFIG)).eval()
    tokenizer = TokenizerShim()
    context = PreparedContext('tiny-random-context', 'synthetic',
                              (1, 3) + tuple(range(10, 27)), 2, (), 19, {})
    replay = prepare_common_replay(context, tokenizer, microchunk_tokens=4, sink_tokens=2,
        tokenizer_id='synthetic/tokenizer-shim-not-pretrained', tokenizer_revision='a' * 40)
    return model, tokenizer, replay


def candidate(model, tokenizer, replay, policy='uniform', seed=0, ratio=0.5):
    plan = plan_anchors(replay.partition, 2, policy, seed)
    return build_candidate(DEPS, model, tokenizer, replay, plan,
                           eviction_ratio=ratio, recent_tokens=1)


def payload(cache):
    return tuple((layer.keys.detach().clone(), layer.values.detach().clone()) for layer in cache.layers)


def hooks(model):
    return {name: (tuple(module._forward_hooks), tuple(module._forward_pre_hooks))
            for name, module in model.named_modules()}


@contextmanager
def observe_cache(model):
    events, held, handles = [], [], []
    def body(module, args, kwargs):
        held.append(kwargs['past_key_values'])
        events.append({'input_ids': kwargs['input_ids'][0].tolist(),
            'position_ids': kwargs['position_ids'][0].tolist(),
            'past_length_before': kwargs['past_key_values'].get_seq_length(), 'attention': []})
    def attention(module, args, kwargs):
        events[-1]['attention'].append({'layer': module.layer_idx,
            'cache_position': kwargs['cache_position'].tolist(),
            'keys_before': kwargs['past_key_values'].get_seq_length(module.layer_idx)})
    handles.append(model.model.register_forward_pre_hook(body, with_kwargs=True))
    for layer in model.model.layers:
        handles.append(layer.self_attn.register_forward_pre_hook(attention, with_kwargs=True))
    try:
        yield events, held
    finally:
        for handle in handles:
            handle.remove()


def explicit_mask_sdpa(module, query, key, value, attention_mask, dropout, **kwargs):
    """Independent reference: actual SDPA, boolean head masks, no fake keys."""
    mask = getattr(module, 'masked_key_indices', None)
    if query.shape[2] != key.shape[2] and mask is not None:
        bsz, heads, qlen, _ = query.shape
        klen = key.shape[2]
        if attention_mask is None:
            base = torch.ones((bsz, heads, qlen, klen), dtype=torch.bool, device=query.device)
        elif attention_mask.dtype == torch.bool:
            base = attention_mask.expand(bsz, heads, qlen, klen).clone()
        else:
            base = (attention_mask == 0).expand(bsz, heads, qlen, klen).clone()
        batch, kvhead, token = mask
        groups = heads // key.shape[1]
        for group in range(groups):
            base[batch, kvhead * groups + group, :, token] = False
        attention_mask = base
    return ORIGINAL_ATTENTION['sdpa'](module, query, key, value, attention_mask,
                                      dropout=dropout, **kwargs)


class TinyQwenIntegration(unittest.TestCase):
    def setUp(self):
        self.model, self.tokenizer, self.replay = fixture()
        self.initial_hooks = hooks(self.model)
        ALL_ATTENTION_FUNCTIONS['sdpa'] = PATCHED_SDPA
    def tearDown(self):
        ALL_ATTENTION_FUNCTIONS['sdpa'] = PATCHED_SDPA
        self.assertEqual(hooks(self.model), self.initial_hooks)
    def assert_payload_equal(self, snapshot, cache):
        self.assertEqual(len(snapshot), len(cache.layers))
        for (keys, values), layer in zip(snapshot, cache.layers, strict=True):
            self.assertTrue(torch.equal(keys, layer.keys))
            self.assertTrue(torch.equal(values, layer.values))
    def assert_masks_clear(self):
        for layer in self.model.model.layers:
            self.assertIsNone(getattr(layer.self_attn, 'masked_key_indices', None))

    def test_real_qwen_qnorm_sdpa_and_cache_positions(self):
        norm_calls, sdpa_calls = [], []
        handles = [layer.self_attn.q_norm.register_forward_hook(
            lambda module, args, output: norm_calls.append(tuple(args[0].shape)))
            for layer in self.model.model.layers]
        def sdpa(*args, **kwargs):
            sdpa_calls.append((args[0].layer_idx, list(args[1].shape), list(args[2].shape)))
            return PATCHED_SDPA(*args, **kwargs)
        ALL_ATTENTION_FUNCTIONS['sdpa'] = sdpa
        try:
            with observe_cache(self.model) as (events, held):
                built = candidate(self.model, self.tokenizer, self.replay)
        finally:
            for handle in handles: handle.remove()
        self.assertIsInstance(self.model, transformers.Qwen3ForCausalLM)
        self.assertIsInstance(built.cache, transformers.DynamicCache)
        self.assertEqual(str(self.model.dtype), 'torch.float32')
        self.assertEqual(len(sdpa_calls), 6)
        # Each layer normalizes queries once in the model and once in the
        # unedited source scorer for each prefill/exact replay.
        self.assertEqual(len(norm_calls), 12)
        self.assertIn((1, 4, 19, 8), norm_calls)
        self.assertIn((1, 19, 4, 8), norm_calls)
        self.assertEqual([len(e['input_ids']) for e in events], [19, 8, 8])
        self.assertEqual([e['past_length_before'] for e in events], [0, 19, 19])
        for index, event in enumerate(events):
            start = 0 if index == 0 else 19
            positions = list(range(start, start + len(event['input_ids'])))
            self.assertEqual(event['position_ids'], positions)
            for layer in event['attention']:
                self.assertEqual(layer['cache_position'], positions)
                self.assertEqual(layer['keys_before'], start)
        self.assertTrue(all(built.cache.get_seq_length(i) == 19 for i in range(2)))
        OBSERVATIONS['native_hooks_and_positions'] = dict(forwards=events,
            sdpa_calls=sdpa_calls, qnorm_calls=[list(x) for x in norm_calls])

    def test_common_virtual_and_sparse_exact_equal_full_diagnostic(self):
        full = build_full_exact_diagnostic(DEPS, self.model, self.tokenizer, self.replay, diagnostic_only=True)
        summaries = []
        for policy, seed in [('first', 0), ('uniform', 0), ('random', 7), ('random', 11)]:
            built = candidate(self.model, self.tokenizer, self.replay, policy, seed)
            ids = list(built.anchors.plan.token_indices)
            np.testing.assert_array_equal(built.virtual.values, full.virtual.values)
            np.testing.assert_array_equal(built.anchors.values, full.full_exact.values[..., ids])
            self.assertEqual(built.accounting['observed_forward_input_lengths'], [19, 8, 8])
            self.assertEqual(built.accounting['completed_exact_replay_passes'], 2)
            self.assertEqual(built.accounting['exact_replay_input_tokens'], 16)
            self.assertEqual(built.accounting['completed_exact_chunk_ids'], list(built.anchors.plan.chunk_ids))
            summaries.append(dict(policy=policy, seed=seed, chunk_ids=list(built.anchors.plan.chunk_ids),
                max_abs_virtual_difference=0.0, max_abs_anchor_difference=0.0))
        self.assertEqual(full.accounting['observed_forward_input_lengths'], [19, 8, 8, 8, 8, 5])
        self.assertEqual(full.accounting['exact_replay_input_tokens'], 37)
        self.assertTrue(full.accounting['diagnostic_only'])
        self.assertFalse(full.accounting['deployable_cost'])
        OBSERVATIONS['sparse_full_agreement'] = dict(arms=summaries,
            diagnostic_accounting=full.accounting)

    def test_deterministic_repeated_build_and_selected_mask(self):
        first = candidate(self.model, self.tokenizer, self.replay)
        second = candidate(self.model, self.tokenizer, self.replay)
        np.testing.assert_array_equal(first.virtual.values, second.virtual.values)
        np.testing.assert_array_equal(first.anchors.values, second.anchors.values)
        np.testing.assert_array_equal(first.calibration.scores, second.calibration.scores)
        np.testing.assert_array_equal(first.keep_mask, second.keep_mask)
        self.assertEqual(int(first.keep_mask.sum()), 38)
        self.assertTrue(first.keep_mask[..., :2].all())
        self.assertTrue(first.keep_mask[..., -1:].all())
        np.testing.assert_array_equal(mask_indices_to_keep(first.masks, (2, 2, 19)), first.keep_mask)
        OBSERVATIONS['selection'] = dict(retained_pairs=38, original_pairs=76,
            accounting=first.accounting, allocation=first.selection)

    def test_cache_equals_fresh_prefill_and_zero_eviction_logits(self):
        built = candidate(self.model, self.tokenizer, self.replay, ratio=0.0)
        clear_masks(self.model)
        ordinary = transformers.DynamicCache()
        with torch.no_grad():
            self.model(input_ids=torch.tensor([self.replay.context_token_ids]),
                       past_key_values=ordinary, use_cache=True)
        self.assert_payload_equal(payload(ordinary), built.cache)
        query = torch.tensor([[40, 41]])
        with torch.no_grad():
            cache = clone_query_cache(DEPS, self.model, built)
            actual = self.model(input_ids=query, past_key_values=cache,
                                position_ids=torch.tensor([[19, 20]])).logits
            clear_masks(self.model)
            baseline = self.model(input_ids=query, past_key_values=ordinary,
                                  position_ids=torch.tensor([[19, 20]])).logits
            full = self.model(input_ids=torch.tensor([self.replay.context_token_ids + (40, 41)]),
                              use_cache=False).logits[:, -2:]
        torch.testing.assert_close(actual, baseline, rtol=0, atol=0)
        torch.testing.assert_close(actual, full, rtol=1e-5, atol=1e-6)
        OBSERVATIONS['zero_eviction'] = dict(cache_prefill_payload_equal=True,
            cached_logits_max_abs_difference=float((actual - baseline).abs().max()),
            full_sequence_logits_max_abs_difference=float((actual - full).abs().max()))

    def test_clones_do_not_alias_or_change_source_on_mutation(self):
        built = candidate(self.model, self.tokenizer, self.replay)
        saved = payload(built.cache)
        first = clone_query_cache(DEPS, self.model, built)
        second = clone_query_cache(DEPS, self.model, built)
        for source, one, two in zip(built.cache.layers, first.layers, second.layers, strict=True):
            for name in ('keys', 'values'):
                tensors = [getattr(x, name) for x in (source, one, two)]
                self.assertEqual(len({x.untyped_storage().data_ptr() for x in tensors}), 3)
        first.layers[0].keys.fill_(0)
        self.assert_payload_equal(saved, built.cache)
        self.assert_payload_equal(saved, second)
        source_bytes, clone_bytes = cache_bytes(built.cache), cache_bytes(second)
        self.assertEqual(source_bytes['kv_tensor_payload_bytes'], 4864)
        self.assertEqual(clone_bytes['kv_tensor_payload_bytes'], 4864)
        self.assertEqual(source_bytes['kv_unique_storage_bytes'], 6912)
        self.assertEqual(clone_bytes['kv_unique_storage_bytes'], 6912)
        self.assertFalse(source_bytes['compacted'])
        OBSERVATIONS['dense_cache_bytes'] = dict(source=source_bytes, clone=clone_bytes)

    def test_author_fake_key_mask_matches_explicit_sdpa_mask(self):
        built = candidate(self.model, self.tokenizer, self.replay)
        source = payload(built.cache)
        fake_cache = clone_query_cache(DEPS, self.model, built)
        explicit_cache = clone_query_cache(DEPS, self.model, built)
        query = torch.tensor([[40, 41]])
        positions = torch.tensor([[19, 20]])
        with torch.no_grad():
            fake = self.model(input_ids=query, past_key_values=fake_cache, position_ids=positions).logits
            ALL_ATTENTION_FUNCTIONS['sdpa'] = explicit_mask_sdpa
            explicit = self.model(input_ids=query, past_key_values=explicit_cache, position_ids=positions).logits
        torch.testing.assert_close(fake, explicit, rtol=1e-5, atol=1e-6)
        self.assert_payload_equal(source, built.cache)
        self.assertTrue(any(not torch.equal(source[i][0], layer.keys[:, :, :19])
                            for i, layer in enumerate(fake_cache.layers)))
        self.assertTrue(all(torch.equal(source[i][0], layer.keys[:, :, :19])
                            for i, layer in enumerate(explicit_cache.layers)))
        OBSERVATIONS['masked_sdpa_reference'] = dict(max_abs_logit_difference=float((fake-explicit).abs().max()),
            author_mask_mutates_query_clone=True, source_unchanged=True)

    def test_repeated_query_generation_positions_and_cleanup(self):
        built = candidate(self.model, self.tokenizer, self.replay)
        source = payload(built.cache)
        # No EOS here forces exactly four forwards and exercises incremental decode.
        self.model.generation_config.eos_token_id = None
        with observe_cache(self.model) as (events, held):
            first = answer_candidate(DEPS, self.model, self.tokenizer, built, (40, 41), max_new_tokens=4)
        second = answer_candidate(DEPS, self.model, self.tokenizer, built, (40, 41), max_new_tokens=4)
        self.assertEqual(first, second)
        self.assertEqual(first['generated_token_count'], 4)
        self.assertEqual([e['position_ids'] for e in events], [[19,20], [21], [22], [23]])
        self.assertEqual([e['past_length_before'] for e in events], [19,21,22,23])
        self.assertTrue(all(not cache.layers for cache in held))
        self.assert_payload_equal(source, built.cache)
        self.assert_masks_clear()
        OBSERVATIONS['generation'] = dict(result=first, forwards=events, repeated_identical=True,
            query_clone_released=True, source_unchanged=True)

    def test_eos_stops_after_first_generated_token(self):
        built = candidate(self.model, self.tokenizer, self.replay)
        initial = answer_candidate(DEPS, self.model, self.tokenizer, built, (40,41), max_new_tokens=1)
        self.model.generation_config.eos_token_id = initial['generated_token_ids'][0]
        with observe_cache(self.model) as (events, held):
            answer = answer_candidate(DEPS, self.model, self.tokenizer, built, (40,41), max_new_tokens=4)
        self.assertEqual(len(events), 1)
        self.assertEqual(answer['generated_token_count'], 1)
        self.assertTrue(answer['stopped_on_eos'])
        self.assert_masks_clear()

    def test_prefill_failure_cleans_cache_masks_hooks_and_retry(self):
        originals = []
        for layer in self.model.model.layers:
            old = (torch.tensor([0]), torch.tensor([0]), torch.tensor([2]))
            layer.self_attn.masked_key_indices = old
            originals.append(old)
        def fail(module, args, kwargs, result):
            raise RuntimeError('injected after actual prefill cache append')
        handle = self.model.model.layers[1].self_attn.register_forward_hook(fail, with_kwargs=True)
        try:
            with observe_cache(self.model) as (events, held), self.assertRaises(CalibrationBuildError) as error:
                candidate(self.model, self.tokenizer, self.replay)
        finally:
            handle.remove()
        self.assertEqual(error.exception.accounting['observed_forward_input_lengths'], [19])
        self.assertEqual(error.exception.accounting['completed_exact_replay_passes'], 0)
        self.assertTrue(all(not cache.layers for cache in held))
        for layer, original in zip(self.model.model.layers, originals, strict=True):
            self.assertIs(layer.self_attn.masked_key_indices, original)
        retry = candidate(self.model, self.tokenizer, self.replay)
        self.assertEqual(retry.accounting['status'], 'completed')

    def test_replay_failure_cleans_cache_masks_hooks_and_retry(self):
        def fail(module, args, kwargs, result):
            if kwargs['hidden_states'].shape[1] != 19:
                raise RuntimeError('injected after actual replay cache append')
        handle = self.model.model.layers[1].self_attn.register_forward_hook(fail, with_kwargs=True)
        try:
            with observe_cache(self.model) as (events, held), self.assertRaises(CalibrationBuildError) as error:
                candidate(self.model, self.tokenizer, self.replay)
        finally:
            handle.remove()
        ledger = error.exception.accounting
        self.assertEqual(ledger['observed_forward_input_lengths'], [19,8])
        self.assertEqual(ledger['exact_chunk_ids'], [1])
        self.assertEqual(ledger['completed_exact_chunk_ids'], [])
        self.assertEqual(ledger['status'], 'failed')
        self.assertTrue(all(not cache.layers for cache in held))
        self.assert_masks_clear()
        self.assertEqual(candidate(self.model, self.tokenizer, self.replay).accounting['status'], 'completed')
        OBSERVATIONS['replay_failure_accounting'] = ledger

    def test_postscoring_failure_releases_owned_cache(self):
        with (observe_cache(self.model) as (events, held), patch.object(runtime, 'calibrate',
            side_effect=RuntimeError('injected calibration failure')),
            self.assertRaises(CalibrationBuildError) as error):
            candidate(self.model, self.tokenizer, self.replay)
        self.assertEqual(error.exception.accounting['status'], 'failed_after_scoring')
        self.assertEqual(error.exception.accounting['completed_exact_replay_passes'], 2)
        self.assertTrue(all(not cache.layers for cache in held))
        self.assert_masks_clear()

    def test_generation_failure_releases_clone_preserves_source(self):
        built = candidate(self.model, self.tokenizer, self.replay)
        source = payload(built.cache)
        def fail(module, args, kwargs, result):
            raise RuntimeError('injected generation failure after cache append')
        handle = self.model.model.layers[1].self_attn.register_forward_hook(fail, with_kwargs=True)
        try:
            with observe_cache(self.model) as (events, held), self.assertRaisesRegex(RuntimeError, 'generation failure'):
                answer_candidate(DEPS, self.model, self.tokenizer, built, (40,41), max_new_tokens=4)
        finally:
            handle.remove()
        self.assertTrue(all(not cache.layers for cache in held))
        self.assert_payload_equal(source, built.cache)
        self.assert_masks_clear()
        retry = answer_candidate(DEPS, self.model, self.tokenizer, built, (40,41), max_new_tokens=4)
        self.assertGreater(retry['generated_token_count'], 0)


if __name__ == '__main__':
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    unittest.main(verbosity=2)
