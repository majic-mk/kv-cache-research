"""Run bounded native architecture integration and save auditable synthetic evidence."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
sys.path[:0] = [str(HERE), str(ROOT)]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    return dict(sorted((dist.metadata['Name'], dist.version)
                       for dist in importlib.metadata.distributions()))


FILES = ['echo_pilot/calibration_runtime.py', 'echo_pilot/runtime.py', 'echo_pilot/contracts.py',
         'research/calibration_methods/contracts.py', 'research/calibration_methods/methods.py',
         'research/calibration_methods/selection.py', 'research/calibration_methods/diagnostics.py',
         'research/diagnostics/echo_calibration/reference.py']


def main():
    before = {name: digest(ROOT / name) for name in FILES}
    import test_tiny_qwen_cpu as tests
    torch, transformers = tests.torch, tests.transformers
    if torch.__version__ != '2.9.1+cpu' or transformers.__version__ != '5.2.0':
        raise RuntimeError('This diagnostic requires exact Torch CPU 2.9.1 and Transformers 5.2.0')
    if torch.version.cuda is not None or torch.cuda.is_available():
        raise RuntimeError('This evidence path is explicitly CPU-only')
    torch.set_num_threads(1)
    torch.manual_seed(tests.SEED)
    torch.use_deterministic_algorithms(True)
    model, _, _ = tests.fixture()
    parameter_hash = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        parameter_hash.update(name.encode())
        parameter_hash.update(tensor.detach().cpu().numpy().tobytes())
    config = model.config.to_dict()
    config['_attn_implementation'] = model.config._attn_implementation
    parameter_count = sum(p.numel() for p in model.parameters())
    with ((HERE / 'tests.log').open('w') as log,
          patch('socket.create_connection', side_effect=AssertionError('Runtime networking forbidden')),
          patch.object(transformers.PreTrainedModel, 'from_pretrained', side_effect=AssertionError('No checkpoint loading')),
          patch.object(transformers.AutoTokenizer, 'from_pretrained', side_effect=AssertionError('No tokenizer loading'))):
        log.write('EVIDENCE: cpu_synthetic_random_architecture; real Qwen3/DynamicCache/SDPA, no pretrained weights\n')
        outcome = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromModule(tests))
    for name, original in tests.ORIGINAL_ATTENTION.items():
        tests.ALL_ATTENTION_FUNCTIONS[name] = original
    assert all(tests.ALL_ATTENTION_FUNCTIONS[name] is original
               for name, original in tests.ORIGINAL_ATTENTION.items())
    with (HERE / 'pilot_regression.log').open('w') as log:
        regression = subprocess.run([sys.executable, '-m', 'unittest', 'discover',
            '-s', 'echo_pilot/tests', '-v'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    regression_log = (HERE / 'pilot_regression.log').read_text()
    regression_count = re.search(r'Ran (\d+) tests?', regression_log)
    after = {name: digest(ROOT / name) for name in FILES}
    if before != after:
        raise RuntimeError('Adapter source changed during validation; rerun on stable source')
    from source_loader import MODULES
    for pin, (_, path, _, _) in zip(tests.KVPRESS._diagnostic_loaded_source_pins, MODULES, strict=True):
        if digest(path) != pin['sha256']:
            raise RuntimeError('Author source changed during validation')
    native_report = json.loads((ROOT / 'research/diagnostics/native_cpu_tensor/result.json').read_text())
    native_python = '/tmp/kv_native_cpu_20261003/bin/python'
    native_inventory = json.loads(subprocess.check_output([native_python, '-c',
        'import importlib.metadata as m,json;print(json.dumps({d.metadata["Name"]:d.version for d in m.distributions()}))'], text=True))
    native_unchanged = native_inventory == native_report['environment']['packages']
    if not native_unchanged:
        raise RuntimeError('Original native evidence environment inventory differs from saved baseline')
    result = dict(schema_version=1, evidence_kind='cpu_synthetic_random_architecture',
        status='passed' if outcome.wasSuccessful() and regression.returncode == 0 else 'failed',
        generated_at_utc=datetime.now(timezone.utc).isoformat(),
        tests=dict(run=outcome.testsRun, failures=len(outcome.failures), errors=len(outcome.errors), skipped=len(outcome.skipped)),
        pilot_regression=dict(status='passed' if regression.returncode == 0 else 'failed',
            tests_run=int(regression_count.group(1)) if regression_count else None,
            exit_code=regression.returncode, command='python -m unittest discover -s echo_pilot/tests -v',
            log_sha256=digest(HERE / 'pilot_regression.log')),
        environment=dict(python=platform.python_version(), executable=sys.executable,
            platform=platform.platform(), packages=inventory(), torch=torch.__version__,
            transformers=transformers.__version__, numpy=tests.np.__version__, cuda_runtime=torch.version.cuda,
            cuda_available=torch.cuda.is_available(), torch_threads=torch.get_num_threads(),
            deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
            original_native_environment_package_inventory_unchanged=native_unchanged),
        random_model=dict(architecture=type(model).__name__, parameter_count=parameter_count,
            seed=tests.SEED, parameter_sha256=parameter_hash.hexdigest(), config=config,
            dtype=str(model.dtype), device=str(model.device)),
        tokenizer=dict(kind='explicit synthetic shim', pretrained=False,
            declared_revision_is_fixture_identifier=True, vocabulary_size=64),
        package_import_scope=dict(mode='full unedited local source modules with real Torch/Transformers imports',
            namespace_shells=['kvpress', 'kvpress.presses'],
            kvpress_top_level_init_executed=False, pip_installed_kvpress=False,
            peft_import_tested=False, source_ast_rewritten=False,
            attention_registration_restored_after_suite=True),
        source_sha256=after, source_stable_during_validation=True,
        verified_author_sources=tests.KVPRESS._diagnostic_loaded_source_pins,
        observations=tests.OBSERVATIONS,
        claims=dict(actual_transformers_qwen3_architecture_executed=True, actual_dynamic_cache_executed=True,
            actual_sdpa_executed=True, qwen3_qnorm_branch_executed=True,
            pretrained_weights_downloaded=False, pretrained_weights_loaded=False,
            model_quality_validated=False, qwen3_8b_parity_validated=False,
            gpu_used=False, bf16_numerical_parity_validated=False, paid_resources_used=False,
            physical_memory_savings_demonstrated=False, gpu_performance_validated=False,
            full_requirements_gpu_profile_validated=False),
        runtime_guards=dict(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
            socket_create_connection_blocked_during_suite=True,
            model_from_pretrained_blocked_during_suite=True,
            autotokenizer_from_pretrained_blocked_during_suite=True),
        limitations=[
            'Only deterministic CPU float32 on one tiny 22,720-parameter random Qwen3 configuration and synthetic token context',
            'No real Qwen3 tokenizer, chat template, checkpoint, Qwen3-8B quality or numerical parity',
            'No BF16/CUDA/Triton/torch.compile or GPU latency/memory validation',
            'Full kvpress distribution initialization, unrelated presses, PEFT and complete proposed GPU environment are untested',
            'Masked dense cache is not compacted: replay-restored tensor views can retain larger backing storage',
            'First/uniform/random agreement refers to common virtual scores and matching paid exact slices; virtual scores are approximations and need not equal exact scores',
            'Decoder is the adapter shared greedy decoder, not Transformers model.generate',
            'Fixture declaration tokens for tokenizer identity/revision are not provenance of a real downloaded tokenizer',
            'No fabricated real_model run manifest, completed quality result, deployment or scientific improvement claim'
        ],
        git_head_at_validation=subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip())
    result['diagnostic_sha256'] = {name: digest(HERE / name) for name in (
        'source_loader.py', 'test_tiny_qwen_cpu.py', 'run_tiny_qwen_cpu.py', 'tests.log', 'install.log', 'pip_check.log')}
    (HERE / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    (HERE / 'packages.freeze.txt').write_text(subprocess.check_output([sys.executable, '-m', 'pip', 'freeze', '--all'], text=True))
    print((HERE / 'tests.log').read_text())
    print(json.dumps(dict(status=result['status'], evidence_kind=result['evidence_kind'], tests=result['tests'],
        masked_sdpa=result['observations'].get('masked_sdpa_reference'),
        zero_eviction=result['observations'].get('zero_eviction'),
        original_native_environment_package_inventory_unchanged=native_unchanged)))
    return 0 if outcome.wasSuccessful() and regression.returncode == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
