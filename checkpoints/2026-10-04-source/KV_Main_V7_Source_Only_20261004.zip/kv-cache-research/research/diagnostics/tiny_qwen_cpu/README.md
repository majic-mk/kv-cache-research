# Tiny random Qwen3 CPU integration

**Result: 12/12 integration checks pass.** This is synthetic software-correctness
validation using an actual Transformers `Qwen3ForCausalLM`, `DynamicCache`, Qwen3
Q/K normalization and SDPA. It is not a pretrained-model, quality, scientific
improvement, GPU-performance, or Qwen3-8B parity result.

## Exact tested scope

- Official CPU Torch **2.9.1+cpu**, Transformers **5.2.0**, NumPy **2.2.6**
- A fresh in-memory random model: **22,720 parameters**, 2 layers, hidden size 32,
  4 query heads / 2 KV heads, head dimension 8, vocabulary 64
- Float32 CPU, seed 17, deterministic algorithms, one Torch thread
- Synthetic tokenizer shim, 19 context tokens, common 4-token replay overhead,
  four 4-token body chunks plus one 1-token tail
- No `from_pretrained`, tokenizer/model downloads, GPU, or paid resources

The exact resolved package inventory, model configuration, parameter hash,
source hashes, per-forward observations and assertions are in
[result.json](result.json). [tests.log](tests.log) records the tests.
All **164 pilot tests** also pass in this environment in the latest checkpoint rerun; see
[pilot_regression.log](pilot_regression.log).

### Passed integration checks

1. Real Qwen3 `q_norm` executes in both model and inherited author scorers;
   six actual SDPA calls cover the two-layer sparse build
2. Automatic `cache_position` and explicit RoPE positions match: prefill 0–18,
   each independent exact replay 19–26, and cache length restores to 19
3. First, uniform and random (seeds 7 and 11) two-chunk sparse anchor builds
   reproduce full-diagnostic virtual scores and their matching exact-score
   slices **bit for bit**, with the same fixed partition and denominator policy
4. Sparse builds execute `[19, 8, 8]` forward lengths and charge 16 replay tokens;
   full diagnostic executes `[19, 8, 8, 8, 8, 5]` and charges 37 replay tokens
5. Repeated builds reproduce scores and masks; exactly 38/76 logical pairs remain,
   including protected sinks and recent tokens
6. Restored candidate-cache contents equal ordinary fresh prefill; zero-eviction
   cached logits are bit-identical to ordinary cached inference, and differ from
   one-shot full-sequence logits by at most **2.98e-8**
7. Separate query clones have disjoint tensor storage; mutation and generation
   leave the frozen source unchanged
8. The unedited author fake-key mask produces **bit-identical logits** to an
   independent explicit per-head boolean SDPA mask on the tested query
9. Repeated greedy generation is identical, with correct incremental positions;
   first-token EOS stops immediately
10. Injected failures after real prefill/replay cache appends, during calibration,
    and after real generation appends release private cache references, clean
    hooks/masks and permit a subsequent successful retry

Agreement above is **between independent sparse/full executions of the same
score definition**. Virtual approximations are not asserted equal to exact scores.

### Dense storage remains dense

The masked candidate retains a 4,864-byte KV tensor payload. Its replay-sliced
views retain 6,912 bytes of backing storage. A deep query clone has a 4,864-byte
payload and also retains the 6,912-byte backing allocation. These tiny byte counts verify layout accounting;
logical 50% pruning does not demonstrate any physical KV-memory savings.

## Audited-source import route

[source_loader.py](source_loader.py) SHA-256-checks six existing local source
files against the repository's pinned provenance manifests, then imports their
**entire unedited module source, including real imports**:

- `kvpress.utils`
- `kvpress.presses.base_press`
- `kvpress.presses.echo_press_kernels`
- `kvpress.presses.kvzip_press`
- `kvpress.presses.echo_press`
- `kvpress.attention_patch`

The source pin is author commit
`39748e9c8301944128eb2e681bfb074e9a2de860`. No new remote repository is downloaded
or executed. The loader creates only the `kvpress` and `kvpress.presses` package
namespace shells and exports `EchoPress`/`KVzipPress`. It does **not** execute
`kvpress.__init__`, install a kvpress distribution, or validate PEFT/unrelated
presses. No AST/import-body rewriting or model/Torch class shims are used.
The real author's global attention registration runs for the suite and is
restored afterward. Triton is absent and scoring uses `torch_eager`.

This closes a narrower native integration gap. It does **not** certify the
complete proposed `requirements-gpu.in` profile or GPU runtime preflight.

## Environment and reproduction

The original `/tmp/kv_native_cpu_20261003` was copied into a separate venv,
`/tmp/kv_tiny_qwen_cpu_20261003`, and only the copy received Transformers 5.2.0
from the official PyPI index with binary-only wheels. The original package
inventory is checked against its prior saved report and remains unchanged.
There was no usable cached wheel, so the installed CPU packages were copied
instead of downloading Torch again. See [install.log](install.log),
[pip_check.log](pip_check.log) and [packages.freeze.txt](packages.freeze.txt).
The freeze is an installed inventory, not a hash-locked GPU dependency file.

From the repository root:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  /tmp/kv_tiny_qwen_cpu_20261003/bin/python \
  research/diagnostics/tiny_qwen_cpu/run_tiny_qwen_cpu.py
```

The report runner also blocks `socket.create_connection`, model
`from_pretrained`, and `AutoTokenizer.from_pretrained` during the test suite.
It verifies adapter/source stability before writing its report. It expects the
original native evidence environment to exist for its nonmutation check.

For a new machine, prepare a separate venv with the exact CPU Torch/NumPy pins
from the official PyTorch CPU index, then Transformers 5.2.0 from official PyPI.
Resolve/check the resulting inventory rather than assuming transitives are
identical. Do not use this CPU diagnostic as an approved GPU launch command.

## Remaining limitations

- Only one tiny random architecture/context and bounded synthetic query inputs
- No pretrained Qwen3 tokenizer, real chat template, model weights, real prompts,
  downstream answers, Qwen3-8B parity, or research-quality measurement
- CPU float32 only here; BF16/CUDA numerical behavior and actual GPU SDPA remain
  separate gates despite earlier native tensor arithmetic tests
- No Triton, `torch.compile`, FlashAttention, GPU latency or allocator validation
- Full installed kvpress initialization and complete proposed GPU dependency lock
  are not tested
- The exercised generator is the adapter's shared greedy decoder, not
  Transformers `model.generate`
- No fake successful `real_model` run/manifest or benchmark record was created
