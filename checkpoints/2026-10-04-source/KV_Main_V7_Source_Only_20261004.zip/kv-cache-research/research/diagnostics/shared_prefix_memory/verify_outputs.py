#!/usr/bin/env python3
"""Read-only, independent scalar verification and complete-run equality check."""
import csv
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def verify():
    final=HERE/'results'; initial=HERE/'results_initial_audit'
    manifest=json.loads((final/'manifest.json').read_text())
    assert digest(HERE/'screen.py')==manifest['source_sha256']
    assert digest(HERE/'protocol.json')==manifest['protocol_sha256']
    for name,h in manifest['artifacts_sha256'].items():
        assert digest(final/name)==h,name
    nrows=0
    for r in csv.DictReader((final/'allocations.csv').open()):
        n,m,k,u,p,a=[int(r[x]) for x in ['N','concurrency','kept_per_request','union_tokens','page_tokens','active_count']]
        method=r['method'];E,J=256,4
        if method=='shared_full':prefix,index,roots=n*E,0,1+2*m
        elif method=='shared_full_subset':prefix,index,roots=n*E,m*k*J,1+3*m
        elif method.startswith('common_'):prefix,index,roots=k*E,k*J,2+2*m
        elif method in ['independent','cow_parent_retained']:prefix,index,roots=m*k*E,m*k*J,4*m+(method=='cow_parent_retained')
        elif method=='union_token':prefix,index,roots=u*E,(u+m*k)*J,2+3*m
        elif method=='union_packed_pages':prefix,index,roots=((u+p-1)//p)*p*E,(u+m*k)*J,2+3*m
        elif method=='union_original_pages':
            touched=int(r['pool_tokens'])//p
            prefix,index,roots=touched*p*E,(touched+m*k)*J,2+3*m
        else:raise AssertionError(method)
        read=n if method=='shared_full' else k
        formula=prefix+index+m*32*(E+J)+(n*E if method=='cow_parent_retained' else 0)+a*(read+32)*E
        assert formula==int(r['unique_live_bytes'])==int(r['formula_bytes'])
        assert int(r['formula_delta_bytes'])==0
        assert roots+a==int(r['backing_allocations'])
        assert int(r['prefix_read_tokens_per_request'])==read
        assert a=={'zero':0,'one':1,'all':m}[r['active_mode']]
        assert (r['parent_weakref_alive']=='True')==(method in ['shared_full','shared_full_subset','cow_parent_retained'])
        for f in (.25,.5,.75,1.):
            assert (r[f'fits_budget_{f}']=='True')==(formula<=int(f*n*E)+m*32*(E+J))
        nrows+=1
    assert nrows==56160
    compared={name:digest(final/name)==digest(initial/name) for name in ['allocations.csv','group_summary.csv','lifecycle.json','quantization_accounting.json','shape_scale_estimates.csv','memory_frontiers.png','page_layout.png']}
    assert all(compared.values()),compared
    initial_manifest=json.loads((initial/'manifest.json').read_text())
    assert digest(HERE/'audit_initial_screen.py')==initial_manifest['source_sha256']
    return {'status':'PASS','independently_verified_rows':nrows,
            'two_complete_runs_same_grid':True,'byte_identical_outputs':compared,
            'reproduction_scope':'First and final full sweeps used identical storage policies and parameter grid; final source adds stronger independent validation and removes an unused lifecycle validation allocation. See failure_analysis.md.',
            'initial_source_sha256':initial_manifest['source_sha256'],'final_source_sha256':manifest['source_sha256'],
            'final_process_peak_rss_kib':manifest['process_max_rss_kib'],
            'initial_process_peak_rss_kib':initial_manifest['process_max_rss_kib']}

if __name__=='__main__':
    print(json.dumps(verify(),indent=2))
