#!/usr/bin/env python3
"""Recompute concise screen findings from raw CSV, without NumPy or model assets."""
import argparse
import csv
from collections import defaultdict
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--results',type=Path,default=HERE/'results')
    args=parser.parse_args()
    examples=[]
    seen_shapes=set()
    cells=defaultdict(list)
    budget=defaultdict(lambda:[0,0])
    rows=0
    common_le_union=True
    max_live=0
    with (args.results/'allocations.csv').open() as f:
      for row in csv.DictReader(f):
        rows+=1
        n,m,k=int(row['N']),int(row['concurrency']),int(row['kept_per_request'])
        seen_shapes.add((n,m))
        b=int(row['unique_live_bytes'])
        max_live=max(max_live,b)
        if n==8192 and float(row['retention'])==.25 and row['seed']=='17' and row['family']=='independent' and row['layout']=='permuted':
            examples.append(row)
        if row['method']=='union_token':
            if row['active_mode']=='zero':
                common_le_union &= int(row['common_direct_bytes'])<=b
            key=(row['family'],row['retention'],row['concurrency'],row['active_mode'])
            full=int(row['shared_full_direct_bytes'])
            full_subset=full+m*k*4
            cells[key].append((float(row['prefix_normalized_net_bytes']),b<full,b<full_subset))
        for f in (.25,.5,.75,1.):
            key=(row['family'],row['method'],row['page_tokens'],row['active_mode'],f)
            budget[key][0]+=row[f'fits_budget_{f}']=='True'
            budget[key][1]+=1
    frontier=[]
    for (family,r,m,mode),values in sorted(cells.items()):
        frontier.append(dict(family=family,retention=float(r),concurrency=int(m),active_mode=mode,
                             cells=len(values),below_full=sum(v[1] for v in values),
                             below_matched_read_full_subset=sum(v[2] for v in values),
                             min_prefix_normalized_bytes=min(v[0] for v in values),
                             max_prefix_normalized_bytes=max(v[0] for v in values)))
    budget_rows=[dict(family=k[0],method=k[1],page_tokens=int(k[2]),active_mode=k[3],budget_fraction=k[4],feasible_cells=v[0],cells=v[1]) for k,v in sorted(budget.items())]
    capacities=[]
    for n,m in sorted(seen_shapes):
        for f in (.25,.5,.75,1.):
            prefix_budget=int(f*n*256)
            capacities.append(dict(evidence="formula_only_capacity_not_additional_allocation",N=n,concurrency=m,
                                   prefix_budget_fraction=f,prefix_budget_bytes=prefix_budget,
                                   suffix_bytes=m*32*260,total_budget_bytes=prefix_budget+m*32*260,
                                   common_max_tokens=min(n,prefix_budget//260),
                                   independent_max_tokens_per_request=min(n,prefix_budget//(m*260)),
                                   note="Direct f16 payload plus int32 indices; equal-byte capacity changes per-request read count"))
    for name,data in [('matched_budget_capacity.csv',capacities),('example_cells.csv',examples),('token_union_boundaries.csv',frontier),('budget_feasibility.csv',budget_rows)]:
        with (args.results/name).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0])); writer.writeheader(); writer.writerows(data)
    decision={
        'decision':'Reject a new method claim. Only a conditional natural-mask/quality question remains; no model/GPU gate is opened.',
        'raw_rows_checked':rows,
        'common_direct_storage_never_exceeds_token_union_at_same_read_count':common_le_union,
        'max_actual_cache_buffers_bytes':max_live,
        'exact_token_union_direct_condition_vs_shared_full':'U*(E+J)+m*k*J < N*E',
        'exact_token_union_direct_condition_vs_matched_read_full':'U*(E+J) < N*E',
        'exact_token_union_active_condition_vs_shared_full':'U*(E+J)+m*k*J+a*(k+suffix_kept)*E < N*E',
        'fixture_constants':{'E_kv_bytes_per_token':256,'J_index_bytes':4,'suffix_kept':32},
        'quality_evidence':'None; binary constructed-mask coverage is not attention or downstream quality.',
        'independent_mask_union_reference':'E[U]/N=1-(1-r)^m; independent fixed-size samples across requests',
        'limitations':['Mask distributions are synthetic, two seeds; no natural workload frequency claim.',
                       'Page results are lower-bound contiguous representations of touched or rounded page capacities, not a serving page allocator.',
                       'COW control eagerly compacts each child while retaining a parent; not a page-COW implementation.',
                       'Byte measurements are reachable NumPy data buffers. Headers separately reported; container overhead and allocator reservation omitted.',
                       'Dense reconstruction rows measure an optional incompatible-consumer adapter cost, not an unavoidable cost for all backends.']}
    (args.results/'decision.json').write_text(json.dumps(decision,indent=2)+'\n')
    print(json.dumps(decision,indent=2))

if __name__=='__main__': main()
