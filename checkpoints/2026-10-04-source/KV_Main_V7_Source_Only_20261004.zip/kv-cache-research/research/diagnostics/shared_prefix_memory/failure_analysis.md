# Audit corrections and failure analysis

The first implementation was checked before accepting the sweep as final evidence. The parameter grid and representations were not changed after observing outputs.

1. A deterministic lifecycle snapshot kept an unused `original_right` validation copy live, outside its reported cache groups. The 65,536-byte validation buffer is now released immediately after comparison, before that snapshot. This did not change the main cache-state sweep.
2. The initial union formula reused pool.nbytes and inferred allocation counts from group lengths. It was numerically correct but not independently falsifiable. Final code uses a separate scalar formula from N, concurrency, k, union cardinality and touched-page cardinality, including closed-form owner counts. The emitted residual is measured minus predicted, rather than a hardcoded zero.
3. Protocol declarations originally duplicated fixed constants. Startup now rejects a changed fixture, page list, active-mode list, nonintegral k, or incompatible N. Configuration counts are derived from actual raw case keys rather than a hardcoded divisor.
4. The isolated 3-bit packer initially cast before range validation. Valid uint8 fixtures were unaffected, but out-of-range wide integers could wrap. It now rejects noninteger and out-of-range input before conversion; regressions include ±256 and fractional values.
5. Every persistent State field was recursively checked by an independent reviewer over 468 configurations; the reviewer found no hidden data-buffer roots, extra validation index arrays, or retained source references. Final regression tests preserve that check and confirm complete weakref release.
6. Runtime profiling identified generic NaN/Inf handling in NumPy's verbose test helper as unnecessary overhead for this deterministic finite fixture. Per-state read/reconstruction checks now use exact full-array equality; no positions or elements are sampled or skipped.

7. A reviewer corrupted a gather list by duplicating one entry and found that self-consistent data-versus-derived-position checks missed the altered requested set. Final validation also compares positions directly with the original requested mask. Suffix positions, values and reconstructed suffix slices are checked independently; deliberate gather/suffix corruption regressions must fail. The original builders were not observed producing these corruptions.

Scientific negatives are expected results, not test failures: independent masks can saturate a union, scattered selections can touch every original page, and dense active copies can outweigh the pool. The code asserts representation/readout consistency; it does not assert that a candidate must win.

Reported memory boundaries concern declared live NumPy buffers. They are not empirical serving/GPU allocation peaks. The page and eager-parent controls, common-mask utility limitations, and optional reconstruction assumptions are documented in CPU_report.md.
