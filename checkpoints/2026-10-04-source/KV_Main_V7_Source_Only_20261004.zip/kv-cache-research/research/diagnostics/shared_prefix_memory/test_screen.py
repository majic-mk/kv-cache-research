import importlib.util
from pathlib import Path
import sys
import unittest
import weakref
import gc
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('shared_prefix_screen', HERE/'screen.py')
s = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = s
spec.loader.exec_module(s)

class AllocationTests(unittest.TestCase):
    def test_disjoint_views_count_whole_owner(self):
        a = np.zeros((64, 64), dtype=np.float16)
        x, y = a[:2], a[-2:]
        self.assertFalse(np.shares_memory(x, y))
        self.assertIs(s.owned_root(x), s.owned_root(y))
        ref = weakref.ref(a)
        del a
        self.assertIsNotNone(ref())
        inv = s.inventory({'views': [x,y]})
        self.assertEqual(inv['unique_backing_bytes'], 8192)
        self.assertEqual(inv['unique_backing_count'], 1)
        del x,y
        gc.collect()
        self.assertIsNone(ref())

    def test_all_layouts_and_lifetimes(self):
        for family in ('identical','independent','core50','core90','disjoint_cyclic','clustered_shift'):
          for layout in ('ordered','permuted'):
            masks = s.masks_for(1024,8,256,family,layout,17)
            for method,page in s.methods():
                state = s.make_state(1024,masks,method,page)
                cover = s.validate_reads(state,masks,method)
                self.assertLessEqual(cover, 1)
                if method not in ('common_blind','common_visible'):
                    self.assertEqual(cover,1)
                self.assertEqual(state.parent_ref() is not None,state.parent_expected)
                dense = s.reconstruct(state,8)
                inv = s.inventory({**state.groups,'dense':dense})
                self.assertEqual(inv['unique_backing_bytes'],state.payload_formula+state.metadata_formula+8*(state.logical_read_tokens+32)*s.E)

    def test_same_sets_different_page_fragmentation(self):
        a = s.masks_for(1024,2,128,'identical','ordered',17)
        b = s.masks_for(1024,2,128,'identical','permuted',17)
        self.assertEqual(s.overlap_stats(a),s.overlap_stats(b))
        pa = s.make_state(1024,a,'union_original_pages',16)
        pb = s.make_state(1024,b,'union_original_pages',16)
        self.assertLess(pa.pool_tokens,pb.pool_tokens)

    def test_common_visible_is_optimal_binary_coverage(self):
        masks=s.masks_for(1024,8,256,'core50','permuted',17)
        ids=s.common_mask(masks,256,True)
        freq=masks.sum(0)
        self.assertEqual(freq[ids].sum(),np.sort(freq)[-256:].sum())

    def test_common_storage_beats_union_at_equal_reads(self):
        for family in ('identical','independent','core50','core90','disjoint_cyclic','clustered_shift'):
            masks=s.masks_for(1024,8,256,family,'permuted',17)
            c=s.make_state(1024,masks,'common_visible')
            u=s.make_state(1024,masks,'union_token')
            self.assertLessEqual(s.inventory(c.groups)['unique_backing_bytes'],s.inventory(u.groups)['unique_backing_bytes'])

    def test_formula_reference_and_saturation(self):
        self.assertAlmostEqual(s.expected_union(8192,8,2048,'independent')/8192,1-.75**8)
        masks=s.masks_for(1024,8,256,'disjoint_cyclic','ordered',17)
        self.assertEqual(s.overlap_stats(masks)[0],1024)
        u=s.make_state(1024,masks,'union_token')
        f=s.make_state(1024,masks,'shared_full')
        self.assertGreater(s.inventory(u.groups)['unique_backing_bytes'],s.inventory(f.groups)['unique_backing_bytes'])

    def test_three_bit_exact_padding(self):
        for count in range(1,40):
            v=np.arange(count,dtype=np.uint8)%8
            p=s.pack3(v)
            self.assertEqual(p.nbytes,(3*count+7)//8)
            np.testing.assert_array_equal(v,s.unpack3(p,count))
        with self.assertRaises(ValueError):
            s.pack3([8])

    def test_quantization_accounting_is_actual(self):
        q=s.quantization_accounting()
        self.assertEqual(q['source_nominal_counter_bytes'],90112)
        self.assertEqual(q['int8_fixture']['unique_backing_bytes'],135204)
        self.assertEqual(q['genuinely_packed_fixture']['unique_backing_bytes'],94244)
        self.assertTrue(q['roundtrip_code_bits_exact'])

    def test_recursive_state_has_no_hidden_arrays_and_releases(self):
        def arrays_in(obj):
            if isinstance(obj,np.ndarray):
                yield obj
            elif isinstance(obj,(list,tuple)):
                for child in obj:
                    yield from arrays_in(child)
            elif isinstance(obj,dict):
                for child in obj.values():
                    yield from arrays_in(child)
            elif isinstance(obj,s.State):
                yield from arrays_in(vars(obj))
        for n,m,k in ((1024,1,128),(1024,4,256),(2048,8,1024)):
          for family in ('identical','independent','core50','core90','disjoint_cyclic','clustered_shift'):
           for layout in ('ordered','permuted'):
            masks=s.masks_for(n,m,k,family,layout,17)
            for method,page in s.methods():
                state=s.make_state(n,masks,method,page)
                reachable=list(arrays_in(state))
                full=s.inventory({'all_state_arrays':reachable})
                cache=s.inventory(state.groups)
                self.assertEqual(full['unique_backing_bytes'],cache['unique_backing_bytes'])
                self.assertEqual(full['unique_backing_count'],cache['unique_backing_count'])
                refs=[weakref.ref(s.owned_root(a)) for a in reachable]
                parentref=state.parent_ref
                del reachable,state
                self.assertTrue(all(ref() is None for ref in refs))
                self.assertIsNone(parentref())

    def test_protocol_rejects_silent_fixture_changes(self):
        import json
        protocol=json.loads((HERE/'protocol.json').read_text())
        s.validate_protocol(protocol)
        for key,value in [('page_tokens',[8,16,32]),('active_reconstruction_counts',['zero','all'])]:
            changed={**protocol,key:value}
            with self.assertRaises(ValueError):s.validate_protocol(changed)
        changed={**protocol,'fixture':{**protocol['fixture'],'head_dim':128}}
        with self.assertRaises(ValueError):s.validate_protocol(changed)

    def test_pack_rejects_before_integer_cast(self):
        for bad in ([256],[-256],[1.5],[float('nan')],[8],[-1]):
            with self.assertRaises(ValueError):s.pack3(bad)

    def test_corrupt_gather_and_suffix_fail_validation(self):
        masks=s.masks_for(1024,4,256,'independent','permuted',17)
        state=s.make_state(1024,masks,'union_token')
        state.reads[0][1][:]=state.reads[0][1][0]
        with self.assertRaises(AssertionError):s.validate_reads(state,masks,'union_token')
        state=s.make_state(1024,masks,'union_token')
        state.groups['suffix_data'][0][:]=0
        with self.assertRaises(AssertionError):s.validate_reads(state,masks,'union_token')
        with self.assertRaises(AssertionError):s.reconstruct(state,1)
        state=s.make_state(1024,masks,'independent')
        state.groups['suffix_indices'][0][0]=0
        with self.assertRaises(AssertionError):s.validate_reads(state,masks,'independent')

    def test_lifecycle(self):
        t=s.lifecycle()
        self.assertTrue(t['all_assertions_passed'])
        self.assertEqual(t['events'][0]['unique_backing_bytes'],1024*s.E)
        self.assertEqual(t['events'][1]['unique_backing_bytes'],1024*s.E)
        self.assertEqual(t['events'][4]['unique_backing_bytes'],0)

if __name__=='__main__':
    unittest.main(verbosity=2)
