#!/usr/bin/env python3
"""Bounded CPU allocation screen. Independent original fixture, not author code.

All reported cache bytes are discovered from actual ndarray ownership chains.
Analytic formulas independently cross-check each row. Shape scaling is separate.
"""
from __future__ import annotations
import argparse
import csv
import gc
import hashlib
import json
import math
from pathlib import Path
import platform
import resource
import sys
import weakref
from dataclasses import dataclass
import numpy as np

HERE = Path(__file__).resolve().parent
D = 64
E = 2 * D * np.dtype(np.float16).itemsize
J = np.dtype(np.int32).itemsize
SUFFIX = 32


def owned_root(a):
    root = a
    while isinstance(root.base, np.ndarray):
        root = root.base
    if not root.flags.owndata or root.base is not None:
        raise AssertionError("Fixture encountered an unsupported externally-owned buffer")
    return root


def inventory(groups):
    roots, objects, categories = {}, {}, {}
    for category, arrays in groups.items():
        for a in arrays:
            root = owned_root(a)
            rid = id(root)
            roots[rid] = root
            objects[id(a)] = a
            objects[rid] = root
            categories.setdefault(rid, set()).add(category)
    return {
        "unique_backing_bytes": sum(int(a.nbytes) for a in roots.values()),
        "unique_backing_count": len(roots),
        "reachable_array_objects": len(objects),
        "ndarray_header_bytes": sum(sys.getsizeof(a) - (a.nbytes if a.flags.owndata else 0)
                                     for a in objects.values()),
        "visible_array_nbytes_sum": sum(int(a.nbytes) for aa in groups.values() for a in aa),
        "category_bytes": {cat: sum(int(roots[r].nbytes) for r, cats in categories.items() if cat in cats)
                           for cat in groups},
    }


def values(ids):
    """Exact, distinguishable f16 token/head coordinates; no random model states."""
    ids = np.asarray(ids, dtype=np.int64)
    a = np.empty((2, len(ids), D), dtype=np.float16)
    a[0] = ((ids[:, None] % 251) + np.arange(D)[None, :] / 64).astype(np.float16)
    a[1] = ((ids[:, None] % 241) - np.arange(D)[None, :] / 64).astype(np.float16)
    return a


def masks_for(n, m, k, family, layout, seed):
    rng = np.random.default_rng(np.random.SeedSequence([seed, n, m, k]))
    sets = []
    if family == "identical":
        sets = [np.arange(k)] * m
    elif family in ("independent", "core50", "core90"):
        frac = {"independent": 0., "core50": .5, "core90": .9}[family]
        c = int(k * frac)
        for _ in range(m):
            sets.append(np.concatenate([np.arange(c), rng.choice(np.arange(c, n), k-c, replace=False)]))
    elif family == "disjoint_cyclic":
        sets = [(np.arange(k) + i*k) % n for i in range(m)]
    elif family == "clustered_shift":
        sets = [(np.arange(k) + i*max(1, k//4)) % n for i in range(m)]
    else:
        raise ValueError(family)
    permutation = (np.random.default_rng(seed + 991).permutation(n)
                   if layout == "permuted" else np.arange(n))
    masks = np.zeros((m, n), dtype=np.bool_)
    for i, ids in enumerate(sets):
        masks[i, permutation[ids]] = True
    assert np.all(masks.sum(1) == k)
    return masks


def expected_union(n, m, k, family):
    if family == "identical":
        return float(k)
    if family in ("independent", "core50", "core90"):
        c = int(k * {"independent": 0., "core50": .5, "core90": .9}[family])
        return c + (n-c)*(1 - (1 - (k-c)/(n-c))**m)
    return None


def overlap_stats(masks):
    m = len(masks)
    u = np.any(masks, axis=0)
    intersections = [np.count_nonzero(a & b)/np.count_nonzero(a | b)
                     for i, a in enumerate(masks) for b in masks[i+1:]]
    return int(u.sum()), float(np.mean(intersections)) if intersections else 1.


def common_mask(masks, k, visible):
    n = masks.shape[1]
    if visible:
        freq = masks.sum(0)
        # Maximize current binary-mask coverage with deterministic lower-ID ties.
        return np.sort(np.lexsort((np.arange(n), -freq))[:k]).astype(np.int32)
    return np.linspace(0, n-1, k, dtype=np.int32)


def predicted_components(n, m, k, u, touched_pages, method, page):
    """Independent scalar formula: no array/group/State inspection."""
    if method == "shared_full":
        p, j, roots = n*E, 0, 1+2*m
    elif method == "shared_full_subset":
        p, j, roots = n*E, m*k*J, 1+3*m
    elif method in ("common_blind", "common_visible"):
        p, j, roots = k*E, k*J, 2+2*m
    elif method in ("independent", "cow_parent_retained"):
        p, j, roots = m*k*E, m*k*J, 4*m
        if method == "cow_parent_retained":
            roots += 1
    elif method == "union_token":
        p, j, roots = u*E, (u+m*k)*J, 2+3*m
    elif method == "union_packed_pages":
        p, j, roots = ((u+page-1)//page)*page*E, (u+m*k)*J, 2+3*m
    elif method == "union_original_pages":
        p, j, roots = touched_pages*page*E, (touched_pages+m*k)*J, 2+3*m
    else:
        raise ValueError(method)
    return dict(prefix_payload=p, prefix_metadata=j, roots=roots,
                payload=p+m*SUFFIX*E+(n*E if method=="cow_parent_retained" else 0),
                metadata=j+m*SUFFIX*J)


def validate_protocol(protocol):
    expected_fixture = {"layers":1,"kv_heads":1,"head_dim":64,"kv_dtype":"float16",
                        "index_dtype":"int32","private_suffix_original_tokens":64,
                        "private_suffix_retained_tokens":32}
    if protocol["fixture"] != expected_fixture:
        raise ValueError("Protocol fixture differs from implemented fixed allocation fixture")
    if protocol["page_tokens"] != [16,32,64] or protocol["active_reconstruction_counts"] != ["zero","one","all"]:
        raise ValueError("Protocol pages or active modes differ from implemented fixed controls")
    if any(n % p for n in protocol["N"] for p in protocol["page_tokens"]):
        raise ValueError("This fixture requires N divisible by declared original page capacities")
    if any(n*r != int(n*r) for n in protocol["N"] for r in protocol["retention"]):
        raise ValueError("Retained token counts must be integral")


@dataclass
class State:
    groups: dict
    reads: list
    method: str
    n: int
    pool_tokens: int
    page_tokens: int
    logical_read_tokens: int
    payload_formula: int
    metadata_formula: int
    root_formula: int
    parent_expected: bool
    parent_ref: object
    construction_snapshot_bytes: int
    prefix_data_bytes: int
    prefix_index_bytes: int
    suffix_data_bytes: int
    suffix_index_bytes: int


def make_state(n, masks, method, page=1):
    m, _ = masks.shape
    k = int(masks[0].sum())
    source = values(np.arange(n))
    parent_ref = weakref.ref(source)
    groups = {"prefix_data": [], "prefix_indices": [], "suffix_data": [], "suffix_indices": [], "parent": []}
    suffix_indices = [np.arange(n+32, n+64, dtype=np.int32) for _ in range(m)]
    suffix_arrays = [values(ids) for ids in suffix_indices]
    groups["suffix_data"] = suffix_arrays
    groups["suffix_indices"] = suffix_indices
    selected = [np.flatnonzero(mask).astype(np.int32) for mask in masks]
    reads = []
    pool_tokens, prefix_bytes, index_bytes = 0, 0, 0
    parent_expected = False
    if method in ("shared_full", "shared_full_subset"):
        groups["prefix_data"] = [source]
        pool_tokens, prefix_bytes = n, n*E
        parent_expected = True
        if method == "shared_full":
            reads = [(source, None)] * m
        else:
            groups["prefix_indices"] = selected
            reads = [(source, ids) for ids in selected]
            index_bytes = m*k*J
    elif method in ("common_blind", "common_visible"):
        ids = common_mask(masks, k, method == "common_visible")
        pool = np.take(source, ids, axis=1)
        groups["prefix_data"] = [pool]
        groups["prefix_indices"] = [ids]
        reads = [(pool, None)] * m
        pool_tokens, prefix_bytes, index_bytes = k, k*E, k*J
    elif method in ("independent", "cow_parent_retained"):
        copies = [np.take(source, ids, axis=1) for ids in selected]
        groups["prefix_data"], groups["prefix_indices"] = copies, selected
        reads = [(a, None) for a in copies]
        pool_tokens, prefix_bytes, index_bytes = m*k, m*k*E, m*k*J
        if method == "cow_parent_retained":
            groups["parent"] = [source]
            parent_expected = True
    elif method in ("union_token", "union_packed_pages", "union_original_pages"):
        ids = np.flatnonzero(masks.any(0)).astype(np.int32)
        if method == "union_original_pages":
            page_ids = np.unique(ids // page).astype(np.int32)
            expanded = (page_ids[:, None] * page + np.arange(page)[None, :]).reshape(-1)
            # The sweep n is divisible by every declared page size.
            assert expanded.max() < n
            pool = np.take(source, expanded, axis=1)
            lookup = np.full(n, -1, dtype=np.int32)
            lookup[expanded] = np.arange(len(expanded), dtype=np.int32)
            gathers = [lookup[x].copy() for x in selected]
            groups["prefix_indices"] = [page_ids] + gathers
            index_bytes = (len(page_ids)+m*k)*J
        else:
            cap = math.ceil(len(ids)/page)*page
            pool = np.zeros((2, cap, D), dtype=np.float16)
            pool[:, :len(ids)] = np.take(source, ids, axis=1)
            gathers = [np.searchsorted(ids, x).astype(np.int32) for x in selected]
            groups["prefix_indices"] = [ids] + gathers
            index_bytes = (len(ids)+m*k)*J
        groups["prefix_data"] = [pool]
        reads = [(pool, g) for g in gathers]
        pool_tokens, prefix_bytes = pool.shape[1], pool.nbytes
    else:
        raise ValueError(method)
    for a, gather in reads:
        assert np.shares_memory(a, groups["prefix_data"][0]) == (a is groups["prefix_data"][0]) or method in ("independent", "cow_parent_retained")
        if method in ("independent", "cow_parent_retained"):
            assert not np.shares_memory(a, source)
    # Documented transition boundary: resulting cache plus source plus supplied masks.
    # Selected temporary lists are added by identity, avoiding double-counting cached indices.
    build = inventory({**groups, "build_source": [source], "input_masks": [masks], "selection_ids": selected})
    del source
    # Parent can only stay alive through a cache reference, never a bookkeeping root table.
    assert (parent_ref() is not None) == parent_expected
    union_cardinality = int(np.count_nonzero(np.any(masks, axis=0)))
    touched_pages = len(set(int(x)//page for x in np.flatnonzero(np.any(masks, axis=0))))
    formula = predicted_components(n, m, k, union_cardinality, touched_pages, method, page)
    payload, metadata, root_count = formula["payload"], formula["metadata"], formula["roots"]
    assert prefix_bytes == formula["prefix_payload"]
    assert index_bytes == formula["prefix_metadata"]
    s = State(groups, reads, method, n, pool_tokens, page, n if method == "shared_full" else k,
              payload, metadata, root_count, parent_expected, parent_ref, build["unique_backing_bytes"],
              prefix_bytes, index_bytes, m*SUFFIX*E, m*SUFFIX*J)
    got = inventory(groups)
    assert got["unique_backing_bytes"] == payload+metadata, (method, got, payload, metadata)
    assert got["unique_backing_count"] == root_count, (method, got, root_count)
    return s


def positions(state, i):
    """Derive positions from counted metadata; never retain hidden validation IDs."""
    if state.method == "shared_full":
        return np.arange(state.n, dtype=np.int32)
    indices = state.groups["prefix_indices"]
    if state.method in ("common_blind", "common_visible"):
        return indices[0]
    if state.method in ("union_token", "union_packed_pages"):
        return indices[0][state.reads[i][1]]
    if state.method == "union_original_pages":
        gather = state.reads[i][1]
        return indices[0][gather // state.page_tokens] * state.page_tokens + gather % state.page_tokens
    return indices[i]


def validate_reads(state, masks, method):
    correct = 0
    for i, (pool, gather) in enumerate(state.reads):
        ids = positions(state, i)
        if method == "shared_full":
            desired = np.arange(state.n, dtype=np.int32)
        elif method in ("common_blind", "common_visible"):
            desired = common_mask(masks, state.logical_read_tokens, method=="common_visible")
        else:
            desired = np.flatnonzero(masks[i]).astype(np.int32)
        assert np.array_equal(ids, desired), "logical positions differ from declared mask"
        expected_suffix_ids = np.arange(state.n+32, state.n+64, dtype=np.int32)
        assert np.array_equal(state.groups["suffix_indices"][i], expected_suffix_ids), "suffix positions differ"
        assert np.array_equal(state.groups["suffix_data"][i], values(expected_suffix_ids)), "suffix values differ"
        data = pool if gather is None else np.take(pool, gather, axis=1)
        assert np.array_equal(data, values(ids)), "retained values differ"
        # Coverage is only agreement with a constructed requested mask, NOT quality.
        correct += np.count_nonzero(masks[i, ids])
    return correct / int(masks.sum())


def reconstruct(state, count):
    dense = []
    for i in range(count):
        pool, gather = state.reads[i]
        ids = positions(state, i)
        a = np.empty((2, len(ids)+SUFFIX, D), dtype=np.float16)
        a[:, :len(ids)] = pool if gather is None else np.take(pool, gather, axis=1)
        a[:, len(ids):] = state.groups["suffix_data"][i]
        assert not np.shares_memory(a, pool)
        assert np.array_equal(a[:, :len(ids)], values(ids)), "dense reconstructed values differ"
        expected_suffix_ids = np.arange(state.n+32, state.n+64, dtype=np.int32)
        assert np.array_equal(a[:, len(ids):], values(expected_suffix_ids)), "dense reconstructed suffix differs"
        dense.append(a)
    return dense


def methods():
    yield from [(m, 1) for m in ("shared_full", "shared_full_subset", "common_blind", "common_visible", "independent", "cow_parent_retained", "union_token")]
    for p in (16, 32, 64):
        yield "union_packed_pages", p
        yield "union_original_pages", p


def sweep(protocol):
    rows = []
    for n in protocol["N"]:
      print(f"Allocating and validating N={n}", flush=True)
      for m in protocol["concurrency"]:
       for r in protocol["retention"]:
        k = int(n*r)
        for seed in protocol["seeds"]:
         for family in protocol["families"]:
          for layout in protocol["layouts"]:
            masks = masks_for(n, m, k, family, layout, seed)
            union, jaccard = overlap_stats(masks)
            expected = expected_union(n, m, k, family)
            full_bytes = n*E + m*SUFFIX*(E+J)
            for method, page in methods():
                s = make_state(n, masks, method, page)
                coverage = validate_reads(s, masks, method)
                if method not in ("common_blind", "common_visible"):
                    assert coverage == 1.
                steady = inventory(s.groups)
                for mode, active in (("zero", 0), ("one", 1), ("all", m)):
                    dense = reconstruct(s, active)
                    got = inventory({**s.groups, "active_dense": dense})
                    extra = active*(s.logical_read_tokens+SUFFIX)*E
                    formula = s.payload_formula+s.metadata_formula+extra
                    assert got["unique_backing_bytes"] == formula
                    assert got["unique_backing_count"] == s.root_formula+active
                    row = dict(N=n, concurrency=m, retention=r, kept_per_request=k, seed=seed,
                               family=family, layout=layout, method=method, page_tokens=page,
                               active_mode=mode, active_count=active, union_tokens=union,
                               union_fraction=union/n, expected_union_tokens=expected,
                               pairwise_jaccard=jaccard, pool_tokens=s.pool_tokens,
                               prefix_read_tokens_per_request=s.logical_read_tokens,
                               logical_prefix_tokens=m*s.logical_read_tokens,
                               logical_prefix_kv_bytes=m*s.logical_read_tokens*E,
                               prefix_data_bytes=s.prefix_data_bytes,
                               prefix_index_bytes=s.prefix_index_bytes,
                               suffix_data_bytes=s.suffix_data_bytes,
                               suffix_index_bytes=s.suffix_index_bytes,
                               retained_parent_bytes=n*E if method=="cow_parent_retained" else 0,
                               active_dense_bytes=extra,
                               unique_live_bytes=got["unique_backing_bytes"],
                               backing_allocations=got["unique_backing_count"],
                               ndarray_header_bytes=got["ndarray_header_bytes"],
                               visible_array_nbytes_sum=got["visible_array_nbytes_sum"],
                               formula_bytes=formula, formula_delta_bytes=got["unique_backing_bytes"]-formula,
                               shared_full_direct_bytes=full_bytes,
                               bytes_over_shared_full_direct=formula/full_bytes,
                               prefix_normalized_net_bytes=(formula-m*SUFFIX*(E+J))/(n*E),
                               common_direct_bytes=k*(E+J)+m*SUFFIX*(E+J),
                               constructed_mask_coverage=coverage,
                               parent_weakref_alive=bool(s.parent_ref() is not None),
                               construction_snapshot_bytes=s.construction_snapshot_bytes,
                               input_masks_bytes=masks.nbytes)
                    for frac in protocol["prefix_budget_fractions"]:
                        limit = int(frac*n*E)+m*SUFFIX*(E+J)
                        row[f"fits_budget_{frac}"] = formula <= limit
                    rows.append(row)
                    del dense
                del s
            del masks
    return rows


def lifecycle():
    """Prove full backing survives views, COW isolation, append/read/free behavior."""
    events = []
    parent = values(np.arange(1024))
    ref = weakref.ref(parent)
    left, right = parent[:, :256], parent[:, 256:512]
    assert np.shares_memory(left, parent) and np.shares_memory(right, parent)
    assert not np.shares_memory(left, right)  # Disjoint bytes, SAME backing owner.
    events.append({"event": "fork_disjoint_views", **inventory({"children": [left, right], "parent": [parent]})})
    del parent
    assert ref() is not None
    events.append({"event": "delete_parent_name_views_retain_full_buffer", **inventory({"children": [left, right]})})
    original_right = right.copy()
    child = left.copy()
    child[0, 0, 0] = -42
    np.testing.assert_array_equal(right, original_right)
    del original_right
    assert left[0, 0, 0] != child[0, 0, 0]
    assert not np.shares_memory(child, left)
    suffix = values(np.arange(1024, 1032))
    appended = np.concatenate([child, suffix], axis=1)
    np.testing.assert_array_equal(appended[:, :256], child)
    np.testing.assert_array_equal(appended[:, 256:], suffix)
    events.append({"event": "copy_on_write_append_old_and_new_both_live", **inventory({"views": [left, right], "child": [child], "suffix": [suffix], "appended": [appended]})})
    del left, right, child, suffix
    gc.collect()
    assert ref() is None
    events.append({"event": "last_original_view_freed_parent_released", **inventory({"appended": [appended]})})
    finalref = weakref.ref(appended)
    del appended
    gc.collect()
    assert finalref() is None
    events.append({"event": "all_cache_refs_freed", **inventory({})})
    # Boolean mask and gather lists are REAL additional allocations, not free labels.
    masked = values(np.arange(1024))
    bools = np.zeros((8, 1024), dtype=np.bool_)
    bools[:, :256] = True
    ids = [np.flatnonzero(a).astype(np.int32) for a in bools]
    events.append({"event": "full_backing_plus_retained_bool_masks_and_int32_lists", **inventory({"data": [masked], "bool_masks": [bools], "indices": ids})})
    return {"all_assertions_passed": True, "events": events,
            "shares_memory_disjoint_views": False, "same_backing_for_disjoint_views": True,
            "note": "np.shares_memory alone misses shared ownership for disjoint views; chase ndarray.base."}


def pack3(codes):
    original = np.asarray(codes)
    if original.dtype.kind not in "biu" or np.any(original < 0) or np.any(original > 7):
        raise ValueError("3-bit codes must be integers in 0..7")
    flat = original.astype(np.uint8, copy=False).reshape(-1)
    bits = ((flat[:, None] >> np.arange(3, dtype=np.uint8)) & 1).reshape(-1)
    return np.packbits(bits, bitorder="little")


def unpack3(packed, count):
    bits = np.unpackbits(packed, bitorder="little")[:count*3].reshape(count, 3)
    return (bits[:, 0]+2*bits[:, 1]+4*bits[:, 2]).astype(np.uint8)


def quantization_accounting():
    # Only byte shapes derived from verified source. NOT its quantizer or model output.
    n = 1024
    rng = np.random.default_rng(91)
    codes = rng.integers(0, 8, (n, D), dtype=np.uint8)
    int8_codes = codes.astype(np.int8)
    packed = pack3(codes)
    np.testing.assert_array_equal(unpack3(packed, codes.size), codes.ravel())
    keys = np.zeros((n, D), dtype=np.int8)
    scale = np.ones((), dtype=np.float32)
    norms = np.ones((n, 1), dtype=np.float32)
    centroids = np.zeros(8, dtype=np.float32)
    nominal = n*D*(1+3/8)
    common = {"qkeys": [keys], "key_scale": [scale], "value_norms": [norms], "codebook": [centroids]}
    unpacked_inv = inventory({**common, "value_codes": [int8_codes]})
    packed_inv = inventory({**common, "value_codes": [packed]})
    rows = []
    for m in (1, 2, 4, 8, 16):
        dense = [np.zeros((2, n, D), dtype=np.float16) for _ in range(m)]
        live = inventory({**common, "value_codes": [int8_codes], "active_dense": dense})
        rows.append({"concurrency": m, "source_style_int8_pool_bytes": unpacked_inv["unique_backing_bytes"],
                     "int8_pool_plus_live_f16_cache_bytes": live["unique_backing_bytes"],
                     "live_over_nominal_pool": live["unique_backing_bytes"]/nominal,
                     "dense_reconstruction_bytes": m*n*E})
    return {"evidence": "original NumPy dtype/shape accounting fixture, not a PolyKV reproduction",
            "N": n, "D": D, "source_nominal_counter_bytes": nominal,
            "source_counter_formula": "N*D*(1+3/8)",
            "int8_pool_formula_with_fp32_metadata_and_codebook": "2*N*D+4*N+4+8*4",
            "packed_pool_formula_with_fp32_metadata_and_codebook": "N*D+ceil(3*N*D/8)+4*N+4+8*4",
            "int8_fixture": unpacked_inv, "genuinely_packed_fixture": packed_inv,
            "value_index_actual_over_nominal": 8/3,
            "int8_pool_over_nominal": unpacked_inv["unique_backing_bytes"]/nominal,
            "packed_pool_over_nominal": packed_inv["unique_backing_bytes"]/nominal,
            "roundtrip_code_bits_exact": True, "active_rows": rows,
            "limitations": "No Lloyd-Max/FWHT/model execution. Metadata is fp32 as in inspected pool construction; cache dtype assumed f16. FP32 temporaries, device copies, attention workspaces, object/container overhead and actual serving peaks omitted."}


def write_csv(path, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarize(rows):
    direct = [r for r in rows if r["active_mode"] == "zero"]
    summaries = []
    for family in sorted({r["family"] for r in rows}):
      for method, page in methods():
       for mode in ("zero", "one", "all"):
        sub = [r for r in rows if r["family"]==family and r["method"]==method and r["page_tokens"]==page and r["active_mode"]==mode]
        ratios = [r["prefix_normalized_net_bytes"] for r in sub]
        summaries.append(dict(family=family, method=method, page_tokens=page, active_mode=mode,
                             cells=len(sub), cells_below_shared_full=sum(x<1 for x in ratios),
                             min_prefix_normalized_bytes=min(ratios), max_prefix_normalized_bytes=max(ratios),
                             median_prefix_normalized_bytes=float(np.median(ratios))))
    union = [r for r in direct if r["method"]=="union_token"]
    return {"status": "PASS", "raw_row_count": len(rows), "mask_configurations": len({(r["N"],r["concurrency"],r["retention"],r["seed"],r["family"],r["layout"]) for r in rows}),
            "formula_mismatches": sum(r["formula_delta_bytes"] != 0 for r in rows),
            "max_reachable_cache_buffer_bytes": max(r["unique_live_bytes"] for r in rows),
            "max_documented_construction_snapshot_bytes": max(r["construction_snapshot_bytes"] for r in rows),
            "common_mask_storage_dominates_token_union_at_same_read_count": all(r["common_direct_bytes"] <= r["unique_live_bytes"] for r in union),
            "group_summary": summaries}


def scale_estimates():
    # Explicitly hypothetical architectures, no model run or measured GPU allocation.
    result = []
    for layers, heads, dim in ((1,1,64), (32,8,128), (36,8,128)):
      for n in (8192, 32768):
       for m in (1,8,16):
        token_bytes = 2*layers*heads*dim*2
        k = n//4
        # Analytic independent-mask expectation, not a sampled/observed union.
        u = n*(1-.75**m)
        result.append(dict(evidence="formula_only_not_allocated", layers=layers, kv_heads=heads, head_dim=dim,
                           N=n, concurrency=m, retention=.25, full_shared_kv_bytes=n*token_bytes,
                           private_compacted_kv_bytes=m*k*token_bytes,
                           expected_union_kv_bytes=u*token_bytes,
                           all_active_reconstruction_kv_bytes=m*k*token_bytes,
                           global_mask_union_index_estimate_bytes=(u+m*k)*J,
                           per_layer_head_mask_union_index_estimate_bytes=(u+m*k)*J*layers*heads,
                           note="No suffixes, pages or allocator overhead; compare both global and per-layer/head metadata assumptions"))
    return result


def plots(rows, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    def pick(family, layout, method, mode="zero", page=1):
        return [r for r in rows if r["N"]==8192 and r["retention"]==.25 and r["family"]==family and r["layout"]==layout and r["method"]==method and r["active_mode"]==mode and r["page_tokens"]==page]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for family in ("identical", "independent", "core50", "core90", "disjoint_cyclic"):
        sub = pick(family, "permuted", "union_token")
        ms = sorted({r["concurrency"] for r in sub})
        ys = [np.mean([r["prefix_normalized_net_bytes"] for r in sub if r["concurrency"]==m]) for m in ms]
        axes[0].plot(ms, ys, marker="o", label=family)
    for label, method, mode, page in (("Private compact", "independent", "zero",1), ("Shared common", "common_visible", "zero",1), ("Token union", "union_token", "zero",1), ("Union + all dense copies", "union_token", "all",1), ("Original-page union P16", "union_original_pages", "zero",16)):
        sub = pick("independent", "permuted", method, mode, page)
        ms = sorted({r["concurrency"] for r in sub})
        axes[1].plot(ms, [np.mean([r["prefix_normalized_net_bytes"] for r in sub if r["concurrency"]==m]) for m in ms], marker="o", label=label)
    for ax in axes:
        ax.axhline(1,color="black",ls="--",label="Shared full prefix")
        ax.set(xlabel="Concurrent requests", ylabel="Bytes / full shared prefix bytes", xticks=[1,2,4,8,16])
        ax.legend(fontsize=8)
        ax.grid(alpha=.2)
    axes[0].set_title("Mask diversity changes token-union storage")
    axes[1].set_title("Strong controls and reconstruction erase gains")
    fig.suptitle("CPU array screen: N=8192, r=1/4, D=64, fp16; metadata included\nCommon suffix bytes subtracted; active dense suffix buffers remain included", fontsize=10)
    fig.tight_layout()
    fig.savefig(out/"memory_frontiers.png", dpi=160)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(8, 4.7))
    for layout in ("ordered", "permuted"):
      for method,page in (("union_token",1),("union_original_pages",16),("union_original_pages",64)):
        sub = pick("clustered_shift",layout,method,page=page)
        ms = sorted({r["concurrency"] for r in sub})
        ax.plot(ms,[np.mean([r["prefix_normalized_net_bytes"] for r in sub if r["concurrency"]==m]) for m in ms],marker="o",label=f"{layout}: {method} P{page}")
    ax.axhline(1,color="black",ls="--")
    ax.set(title="Same mask overlap, different token placement",xlabel="Concurrent requests",ylabel="Bytes / shared full prefix",xticks=[1,2,4,8,16])
    ax.legend(fontsize=8); ax.grid(alpha=.2); fig.tight_layout()
    fig.savefig(out/"page_layout.png",dpi=160); plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE/"results")
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    protocol = json.loads((HERE/"protocol.json").read_text())
    validate_protocol(protocol)
    result = sweep(protocol)
    write_csv(args.output/"allocations.csv", result)
    summary = summarize(result)
    (args.output/"summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    write_csv(args.output/"group_summary.csv", summary["group_summary"])
    (args.output/"lifecycle.json").write_text(json.dumps(lifecycle(), indent=2)+"\n")
    (args.output/"quantization_accounting.json").write_text(json.dumps(quantization_accounting(), indent=2)+"\n")
    write_csv(args.output/"shape_scale_estimates.csv", scale_estimates())
    if not args.no_plots:
        plots(result, args.output)
    manifest = {"evidence_kind": protocol["evidence_kind"], "python":sys.version.split()[0],
                "numpy": np.__version__, "platform": platform.platform(),
                "process_max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "rss_scope": "Whole Python process incl. interpreter, masks, result records and plots; not a cache peak",
                "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "protocol_sha256":hashlib.sha256((HERE/"protocol.json").read_bytes()).hexdigest(),
                "artifacts_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(args.output.iterdir()) if p.is_file()},
                "no_model_no_torch_no_gpu_no_download_no_paid_compute":True}
    (args.output/"manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    print(json.dumps({k:v for k,v in summary.items() if k!="group_summary"}, indent=2))

if __name__ == "__main__":
    main()
