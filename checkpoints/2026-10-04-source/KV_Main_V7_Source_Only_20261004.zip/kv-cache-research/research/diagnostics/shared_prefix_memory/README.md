# CPU shared-prefix allocation screen

Start with [CPU_report.md](CPU_report.md). Decision: **do not promote candidate B to a new method or start a model/GPU experiment on this evidence**. Common-mask storage controls remain strong; conditional union savings provide no natural-data quality evidence.

Final evidence is in `results/`; the retained initial run is in `results_initial_audit/`. Both complete sweeps give byte-identical allocation tables and plots. The final source has stronger independently audited validation. See `failure_analysis.md` for the explicit corrections.

```sh
python research/diagnostics/shared_prefix_memory/test_screen.py
python research/diagnostics/shared_prefix_memory/verify_outputs.py
python research/diagnostics/shared_prefix_memory/screen.py --output /tmp/new-shared-prefix-run
python research/diagnostics/shared_prefix_memory/analyze.py --results /tmp/new-shared-prefix-run
```

A new output directory is required. NumPy is required; Matplotlib supplies the optional plots (`--no-plots` skips them). This is a finite CPU-only array/mask study. It does not install packages, download models, use Torch/GPU, spend money or change remote state.
