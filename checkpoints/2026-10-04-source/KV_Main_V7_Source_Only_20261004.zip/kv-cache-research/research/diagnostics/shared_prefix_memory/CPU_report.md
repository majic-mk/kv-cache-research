# Shared-prefix physical-memory screen (CPU only)

Date: 2026-10-03. Status: **complete; two full sweeps, 13 tests and independent output verification passed**.

## Decision

**Reject a new compression/sharing-method claim from this screen.** A common retained prefix is always cheaper than the tested per-request union representation at the same token-read count. Independent compaction loses to a correctly shared full prefix as concurrency grows. Scatter across original pages and active dense reconstruction can erase even ideal union savings.

There is a conditional storage question, not a positive quality result: can diverse *natural* request masks supply enough quality benefit to justify their extra unique bytes, after a common visible-query mask and a question-blind common mask are included? This experiment does not answer that. No small-model or GPU run is warranted solely by these synthetic savings, and no learned optimizer or new retention policy was built.

This conclusion does not establish quality dominance of a common mask, nor rule out every shared-union representation. It rejects promotion of the current generic method idea and identifies configurations with no storage advantage even against a simple control.

## What actually ran

The allocation fixture has one layer, one KV head, 64 dimensions, K and V in float16: E = 256 bytes per token. Each request also owns 32 retained tokens from a 64-token private suffix, with int32 original-position indices. This compressed suffix is identical across every storage control, including the shared-full-prefix baseline.

The predeclared grid in `protocol.json` covers N = 1024/2048/4096/8192, concurrency = 1/2/4/8/16, retention = 1/8, 1/4, 1/2, two seeds, six mask families and two physical token layouts. These are 1,440 parameter configurations, **not 1,440 independent trials**. Some deterministic cases duplicate across seeds. Families are identical masks; independent fixed-size masks; 50% and 90% shared-core masks; cyclic disjoint masks; and overlapping contiguous-window masks. A common permutation preserves token-level intersections while changing page fragmentation.

All consumers are held live when counted. Each method builds actual arrays, follows every ndarray.base chain to its owning allocation, deduplicates owners, checks np.shares_memory, and verifies retained values and original token positions. Weak references establish whether the source parent is actually retained or released. Dense reconstruction arrays are separately allocated, verified, and counted for zero, one, or all active consumers. NumPy indexing metadata are actual int32 arrays, not nominal discounts.

Controls:

- Shared full prefix, with implicit positions and full-prefix reads
- Shared full prefix with request-specific int32 selection lists, matching the smaller request-read count without reducing resident prefix storage
- One common question-blind mask and one common current-mask-frequency mask. The latter exactly maximizes total overlap with the currently provided binary masks under a fixed token count; it is a deliberately limited synthetic visible-query-score control
- Independently compacted requests with the source freed
- Eager compacted private copies with the full parent retained, representing the storage consequence of copy-on-write plus a live parent
- Ideal token union, with a shared original-position list and private gather lists
- Packed union rounded to 16/32/64-token capacities
- Union of original 16/32/64-token pages, with stored page IDs and private gather lists
- Genuine 3-bit packing and all declared scales/norms in a separate dtype/shape accounting fixture

The page controls use contiguous NumPy pools representing page capacities. They do not implement a serving allocator, page reference counts, alignment, or its object/page-table overhead. “Ideal union” refers to deduplicated KV payload, with an explicit generic int32 metadata scheme; it is not a minimum-entropy index encoding. Identical gather lists could themselves be shared, and compressed indices are not evaluated. The ideal token/packed-union methods require copying selected KV into a new pool; source snapshots count the old cache at a documented construction boundary. They are optimistic representation controls, not a demonstrated zero-copy serving implementation.

## Physical bytes, logical reads and lifetimes

The primary measurement is **unique live NumPy-owned data-buffer bytes reachable from the modeled cache**. ndarray object headers are reported separately. Python container overhead, allocator reservation, RSS attribution and actual engine workspaces are not included in that cache metric. Process peak RSS is recorded separately and includes Python, mask construction, result records and plotting. Construction snapshots are documented lower bounds at explicit boundaries, not complete allocator peaks. Temporary NumPy gather/sort/packing workspaces are not claimed to have been exhaustively instrumented.

Two disjoint slices can have np.shares_memory = false while retaining the same full owner. The lifecycle test proves this, deletes the parent's name while its slices retain the full allocation, makes an isolated child copy, appends a private suffix, then releases the last original view and confirms parent destruction by weak reference. It also demonstrates the extra cost of retaining both a boolean mask matrix and integer selection lists.

All steady-state compressed variants discard their selection input masks. `input_masks_bytes` records that build input separately; retaining them in a real implementation would require adding those bytes. Validation-only expected values and fixture mask generation are kept outside the cache state. Recursively auditing State confirms there are no uncounted persistent validation indices or source references.

## Exact boundary, including metadata

Let N be prefix length, m requests, k = rN retained tokens per request, U the selected-token union, E = 256 KV bytes/token, J = 4 bytes/index, and s = 32 retained suffix tokens. All controls add the same S = m s(E+J) private suffix bytes.

These formulas count NumPy data buffers. ndarray headers are reported separately; Python/container and allocator overhead are excluded:

| Representation | Prefix/cache bytes before the shared suffix term |
|---|---:|
| Full shared prefix | NE |
| Full shared prefix, request subset reads | NE + mkJ |
| One common compressed prefix | k(E+J) |
| Independent compacted requests | mk(E+J) |
| Compacted copies with retained parent | NE + mk(E+J) |
| Ideal token union | U(E+J) + mkJ |
| Packed union, page capacity P | ceil(U/P)PE + UJ + mkJ |
| Original-page union, t touched pages | tPE + tJ + mkJ |
| Optional a active dense reconstructions | add a(k+s)E for retained-prefix consumers |

For full-prefix-read consumers, the optional reconstruction instead adds a(N+s)E. Reconstruction is an explicit adapter/materialization scenario. It is unnecessary for direct consumers and is not charged to every backend as an inherent requirement.

The token-union condition for beating full sharing is exactly:

U(E+J) + mkJ + a(k+s)E < NE

For a = 0 and a matched-read full-sharing control, the common mkJ term cancels: U/N < E/(E+J) = 64/65, about 98.46%. Against the zero-index full-read control, the stricter condition is U/N < (1 - mr/64)/(65/64). A persistent full parent immediately removes the possibility of net savings over full sharing before considering any reconstruction.

For independent fixed-size request masks, E[U]/N = 1 - (1-r)^m. This is a distributional reference, not measured natural mask behavior. For a common core of c tokens, E[U] = c + (N-c)[1-(1-(k-c)/(N-c))^m]. The core count is the actual integer floor specified by the generator.

## Measured results

Each complete sweep produced 56,160 allocation rows across 1,440 declared mask configurations and 13 representations, each with zero/one/all active reconstructions. Its largest cache-buffer set was **36,177,920 bytes (34.5 MiB)**; the largest declared construction snapshot was 19,400,704 bytes. Whole-process peak RSS was 205,044 KiB (200.2 MiB) in the final run, and 210,312 KiB (205.4 MiB) in the initial run. The second full run used independently audited validation fixes with unchanged policies, grid and byte definitions. All 56,160 raw allocation rows, group tables, lifecycle results, quantization accounting, scale estimates and both plots are byte-identical across the two runs.

A concrete measured slice, N = 8192, r = 1/4, independent masks, seed 17, permuted layout follows. Entries are `(live bytes minus the identical private suffix storage) / full shared prefix bytes`; metadata is included. The shared-full reference is 1.0.

| Requests | Private compaction | Token union | Original-page union, P=16 | Common mask |
|---:|---:|---:|---:|---:|
| 1 | 0.253906 | 0.257812 | 0.991198 | 0.253906 |
| 2 | 0.507812 | 0.451777 | 1.008789 | 0.253906 |
| 4 | 1.015625 | 0.708164 | 1.016602 | 0.253906 |
| 8 | 2.031250 | 0.948065 | 1.032227 | 0.253906 |
| 16 | 4.062500 | 1.068703 | 1.063477 | 0.253906 |

At eight requests, the measured token union contains 7,395 distinct prefix tokens (90.27% of N). The direct union cache totals 2,054,796 bytes including suffixes, against 2,163,712 for shared full. One active dense reconstruction raises the total to 2,587,276 bytes, and all eight raise it to 6,314,636. Its small direct-pool advantage therefore fails under even one such materialization. The eager compacted-copy control retaining its full parent costs 6,423,552 bytes.

Across all N, seeds and layouts with independent masks:

| Retention | Direct token union beats full sharing at tested concurrency | With one dense reconstruction | With every request reconstructed |
|---|---|---|---|
| 1/8 | 1, 2, 4, 8, 16 | 1, 2, 4, 8; fails at 16 | 1 and 2 throughout; 4 only for N >= 2048; fails at 8/16 |
| 1/4 | 1, 2, 4, 8; fails at 16 | 1 and 2 throughout; 4 in 14/16 configurations; fails at 8/16 | 1 throughout; 2 only for N >= 2048; fails at 4/8/16 |
| 1/2 | 1, 2, 4; fails at 8/16 | No tested configuration | No tested configuration |

These are exact observed grid ranges against directly consumed full sharing for this E=256, J=4 fixture, not extrapolations to untested concurrency or architectures. Larger KV entries amortize index costs differently: D=128 halves the relative int32 charge, and one globally shared mask across many layer/heads amortizes it further. Per-layer/head masks need their own metadata. The scale-estimate file keeps these alternatives separate. At r = 1/4, one-reconstruction m = 4 passes all 16 configurations against the separately reported matched-read full-sharing control; its extra per-request index cost changes the boundary. The full ranges and both comparisons are in `results/token_union_boundaries.csv`.

For direct independent masks at r = 1/4, m = 8, net prefix ratios range from 0.939758 to 0.948065, leaving only 5.2–6.0% storage headroom. At m = 16 they range from 1.064240 to 1.069199. The result is not universally negative for deduplication: high-overlap masks can stay smaller than a full shared prefix. But identical-mask cases are strictly cheaper with the common-mask control, and a smaller high-overlap union alone supplies no evidence of useful request-specific quality.

The two common masks have identical storage. In the illustrative m = 8 slice, the question-blind mask covers 25.16% and the visible frequency mask covers 45.00% of the artificially requested token memberships, versus 100% for the union. **This is constructed-mask agreement, not measured task quality.** Defining each request's required content to be its generated random mask would build a private-mask utility advantage into the toy and cannot justify a new method.

Budget feasibility is reported separately at 25/50/75/100% of shared-full prefix bytes, always adding the same compressed suffix budget. `matched_budget_capacity.csv` also gives formula-only common/private token capacities at those byte limits; these alter read counts and are not silently treated as matched-read quality comparisons. At a nominal 25% byte budget, even a 25%-token common cache exceeds the allowance once its int32 indices are charged.

![Memory and reconstruction controls](results/memory_frontiers.png)

![Placement-sensitive original-page storage](results/page_layout.png)

Both figures show N = 8192, r = 1/4, and average the two declared seeds. The second uses clustered-shift masks; a common permutation changes page fragmentation without changing token-union overlap.

## Source-derived accounting issue: limited verification

The following pinned primary sources were read on 2026-10-03:

- [PolyKV value quantizer](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/turboquant.py): stores value codes as int8 and returns per-vector norms
- [PolyKV pool](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/pool.py): its counter charges 3/8 byte per value code and excludes the scale/norm buffers
- [PolyKV compressor](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/compress.py): a scalar key scale plus one norm per value vector determine the fixture metadata shape
- [PolyKV agent](https://github.com/ishan1410/PolyKV/blob/148aba6de632d043459b4d86b72d378aea770919/polykv/agents.py): creates a fresh DynamicCache and reconstructs its layers before generation

This is **not an author-code execution or a reproduction of reported model results**. No author code was copied or redistributed. The prior report records MIT metadata but an unverified standalone LICENSE file; this fixture avoids that redistribution issue entirely. It performs original NumPy dtype/shape accounting and exact code-bit packing, not the author's quantizer, attention or generation.

For N = 1024, D = 64, the source-style nominal counter is 90,112 bytes. Actual int8 key/value codes, fp32 key scale, fp32 value norms and an 8-entry fp32 codebook occupy 135,204 bytes in the fixture. True 3-bit packed values with the same metadata occupy 94,244 bytes. The int8 values alone need 8/3 times their nominal code charge. Dense f16 reconstructed KV adds 262,144 bytes per active request. Aggregate live-buffer sums may span tiers in a real system; these fixture sums are not claims about single-GPU resident memory.

This counter correction and proper packing are obvious engineering controls. They are not a research contribution by themselves, and the prior-art constraints in `research/topic_reassessment_20261003.md` remain in force.

## Evidence limits and next decision

- No language model, natural attention mask, downstream accuracy, latency, GPU kernel, paid resource, model download or remote repository operation was used
- Constructed-mask coverage describes retained-set overlap only. It does not establish attention error, answer quality, or that a shared mask is practically worse
- Common-mask storage wins are specific to equal token counts in the declared f16/int32 representations, not an equal-quality Pareto result
- Original-page saturation is conditional on layout. Structured contiguous selections can preserve page savings; scattering the same overlaps can erase them
- A custom indexed attention path could avoid dense reconstruction; this run neither implements nor times one. Reconstruction results reject that adapter configuration when it exceeds direct full sharing, not every possible union consumer
- The shape-scale CSV contains formula-only hypothetical layer/head dimensions. None of those larger model-shaped caches was allocated, and global versus per-layer/head mask metadata assumptions are explicitly separate
- There are only two synthetic seeds and no empirical frequency estimate for real workloads

A follow-on natural-data diagnostic would need evidence that useful masks are both sufficiently correlated to meet the byte inequality and meaningfully better than the two common-mask controls at matched physical bytes and matched reads. No current finding establishes that joint condition. Stop at this screen rather than inventing a common/private optimizer to manufacture a method.

## Reproduce

From the repository root:

```sh
python research/diagnostics/shared_prefix_memory/test_screen.py
python research/diagnostics/shared_prefix_memory/screen.py --output /tmp/shared-prefix-run
python research/diagnostics/shared_prefix_memory/analyze.py --results /tmp/shared-prefix-run
# Verify the retained evidence and compare the two stored complete runs:
python research/diagnostics/shared_prefix_memory/verify_outputs.py
```

The output directory must be new; the runner refuses to overwrite it. NumPy is required. Matplotlib was available for the stored plots; `--no-plots` omits only plots. No packages are installed by these scripts. Raw allocations, analytical budget feasibility, exact surviving ranges, lifecycle results, quantization accounting, separately labeled scale estimates, hashes and plots are retained with the source.

## Validation and artifact map

- `screen.py`: final audited allocator, masks, lifecycle, bit-packing fixture, scalar formula checks and plots
- `protocol.json`: parameter grid and interpretation gates recorded before the first full sweep
- `test_screen.py`, `tests.log`: 13 passing tests, including 468 recursively inspected cache states, parent release, invalid pack inputs, deliberate gather/suffix corruption and protocol mismatch guards
- `analyze.py`: regenerates concise boundaries, examples, budget feasibility and formula-only matched-budget capacities from raw CSV
- `verify_outputs.py`, `verification.json`: verifies all retained run hashes, every output byte/root/budget formula and full-run equality
- `results/allocations.csv`: 56,160 actual allocation observations; all formula residuals are zero
- `results/decision.json`, `results/token_union_boundaries.csv`, `results/budget_feasibility.csv`, `results/matched_budget_capacity.csv`: exact conditional ranges and budget accounting
- `results/lifecycle.json`, `results/quantization_accounting.json`: actual array-lifetime and source-style dtype/packing evidence
- `results/shape_scale_estimates.csv`: explicitly unallocated analytical extrapolations
- `results/manifest.json`: final source/protocol/artifact hashes, environment and separately scoped process RSS
- `source_provenance.json`, `independent_audit.json`, `failure_analysis.md`: source limits and independent correctness review
- `audit_initial_screen.py`, `results_initial_audit/`: retained first execution source and outputs, clearly superseded by the audited final source; used only for reproducibility comparison

The independent reviewer also regenerated all union/touched-page counts, verified all 56,160 output formulas and budget flags, and checked every numerical range in this report. Matplotlib emitted read-only home-cache warnings and successfully used a temporary cache; both resulting PNGs were visually inspected and were byte-identical across runs. Those warnings did not prevent plotting or any scientific check. Only this new diagnostic directory was changed by this task; no existing implementation, model asset, remote state or commit was modified.
