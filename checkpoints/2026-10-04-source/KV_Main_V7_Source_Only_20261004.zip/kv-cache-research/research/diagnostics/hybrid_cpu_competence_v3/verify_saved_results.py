"""Audit already-saved logit tensors only; never instantiate/load a model or forward."""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import hashlib
import json
import math
from pathlib import Path
import torch

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/hybrid_cpu_competence_v3/qualification_run'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    torch.set_num_threads(1)
    rows = [json.loads(line) for line in (OUT / 'cells.jsonl').read_text().splitlines()]
    assert len(rows) == 16 and sum(r['status'] == 'completed' for r in rows) == 2
    assert sum(r['status'] == 'not_run_gate' for r in rows) == 14
    complete = rows[:2]
    logits, rescored = [], []
    for row in complete:
        path = ROOT / row['raw_logits_artifact']['path']
        assert sha(path) == row['raw_logits_artifact']['sha256']
        data = torch.load(path, map_location='cpu', weights_only=True)
        assert data['actual_dtype'] == 'bfloat16'
        all_steps = [data['first']] + data['greedy_steps'] + [x for steps in data['candidate_steps'].values() for x in steps]
        assert all(x.dtype == torch.bfloat16 and bool(torch.isfinite(x).all()) for x in all_steps)
        assert [int(x.argmax()) for x in data['greedy_steps']] == row['raw_generated_token_ids'] == [1114, 248046]
        sums = {}
        for answer, ids in row['candidate_token_ids'].items():
            steps = data['candidate_steps'][answer]
            assert len(steps) == len(ids)
            values = [float(x.float().log_softmax(-1)[tid]) for x, tid in zip(steps, ids)]
            assert all(math.isfinite(x) for x in values)
            assert values == row['candidate_per_token_logprobs'][answer]
            sums[answer] = sum(values)
            assert sums[answer] == row['candidate_sum_logprobs'][answer]
        logits.append(data['first'].float())
        rescored.append(dict(arm=row['arm'], candidate_sums=sums, raw_logits_sha256=sha(path)))
    tv = float((logits[1].softmax(-1) - logits[0].softmax(-1)).abs().sum() / 2)
    max_abs = float((logits[1] - logits[0]).abs().max())
    delta = {a: rescored[1]['candidate_sums'][a] - rescored[0]['candidate_sums'][a] for a in ['red', 'blue']}
    margin_delta = delta['red'] - delta['blue']
    measured = complete[1]['numerical_control_noise']
    assert tv == measured['first_step']['TV'] and max_abs == measured['first_step']['max_abs']
    assert delta == measured['candidate_sum_deltas']
    assert abs(margin_delta - measured['candidate_margin_delta']) < 1e-12
    receipt = json.loads((HERE / 'launch_receipt.json').read_text())
    assert sha(HERE / 'run_probe.py') == receipt['runner_sha256']
    assert sha(HERE / 'watch_probe.py') == receipt['watchdog_sha256']
    assert sha(HERE / 'admission_review_pre_run.md') == receipt['review_snapshot_sha256']
    freezes = dict(receipt['historical_freezes'])
    freezes['research/protocols/hybrid_cpu_quality_v3'] = receipt['v3_freeze_manifest_sha256']
    for name, expected in freezes.items():
        directory = ROOT / name
        assert sha(directory / 'freeze_manifest.json') == expected
        manifest = json.loads((directory / 'freeze_manifest.json').read_text())
        assert all(sha(directory / name) == record['sha256'] for name, record in manifest['files'].items())
    output = dict(status='PASS_SAVED_LOGITS_AND_HISTORY_AUDIT', model_loads=0, model_forwards=0,
                  cells=16, completed=2, unrun=14, rescored=rescored, first_TV=tv,
                  first_max_abs_logit_delta=max_abs, candidate_sum_deltas=delta,
                  candidate_margin_delta=margin_delta, observed_numerical_gate_pass=False,
                  frozen_runner_watchdog_review_and_all_three_protocols_unchanged=True)
    (HERE / 'saved_results_verification.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output))

if __name__ == '__main__':
    main()
