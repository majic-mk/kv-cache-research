# Exploratory 2B/BF16 qualification: numerical gate failed

**2026-10-03 UTC. Stop this CPU qualification route under the frozen rule.** The first full-recompute and exact-prefix cells, both **d01/A1**, generated the same correct sequence: **`red<|im_end|>`**, IDs `[1114, 248046]`. Normalized and strict token scoring both passed. Nevertheless, the exact-prefix schedule failed the predeclared numerical controls. **Two of sixteen cells completed; fourteen are explicitly `not_run_gate`. No further model inference or retry occurred.**

The required overall competence screen was not completed. This is a failure of the declared monolithic-versus-split-Q scheduling admission for this pinned mixed-precision configuration. It is not observed answer degradation, a HYPIC comparison, a 2B FP32-equivalence result, or a refutation of recurrent conditioning. The historical 0.8B/FP32 competence failure remains unchanged.

## Exact schedules and limits of attribution

The only tested prompt has A=42, B=156 and Q=31 tokens. Both arms use identical complete token arrays (SHA-256 `1b3ec06ee41d12696e2e041d97eb6ac3d8ab1657fb33047156881996097ebd9d`).

- Full: a fresh monolithic **229-token A+B+Q** call, absolute positions **0–228**, all-ones input mask length229
- Exact: an independent fresh **198-token A+B** call at **0–197**, a verified non-aliasing clone of all cache channels, then **31-token Q** at **198–228**, with input mask lengths198 then229
- Both arms next make the same three one-token calls at position229, on independent post-Q cache clones: red teacher forcing, blue teacher forcing, and red greedy continuation; EOS is scored from their output logits

There is no reordered input, omitted B/Q token, foreign-prefix payload, position reset, shared mutable scoring cache or difference in requested causal semantics. Clone equality/non-aliasing, cache lengths/shapes/dtypes, untouched source caches and the complete input hashes were checked. The native causal-mask constructor is shared; materialized mask tensors were not separately retained or compared in this run.

Call boundaries nevertheless change the execution: the official GDN chunk size is64. The full schedule partitions 229 tokens as64+64+64+37; A+B partitions as64+64+64+6, then Q starts another31-token chunk with incoming recurrent state. Q also uses the official previous-convolution-history path and cached attention, and projection/attention tensor shapes differ. These are the intended exact-prefix interface differences, not identical arithmetic schedules.

The recorded discrepancy could arise from arithmetic scheduling/rounding or an implementation issue in these native cached paths. The present run does not isolate which operation causes it and does not prove the cache/mask/kernel implementation free of a model-specific defect. The justified finding is narrowly that **this pinned CPU BF16 configuration fails this frozen monolithic-versus-split-Q control**. It does not establish that BF16 or Qwen3.5-2B is generally unsuitable. The stop rule prevents extra diagnostic forwards or post-outcome rescue here.

## Decisive result

Candidate-plus-EOS sum log probabilities were computed in FP32 from actual BF16 model logits:

| Quantity | Full recompute | Exact prefix | Exact minus full |
|---|---:|---:|---:|
| Correct candidate red | −0.1284431458 | −0.1418375982 | **−0.0133944524** |
| Other candidate blue | −2.2531904355 | −2.1415379456 | **+0.1116524899** |
| Red-minus-blue margin | +2.1247472897 | +1.9997003474 | **−0.1250469423** |

Each candidate-sum difference and the margin difference had to have absolute value **strictly below 0.01 nat**. All three failed. The first-token distribution's total variation was **0.0124600772**, above the **0.0025** cap. Maximum absolute first-step logit difference was **0.3125**, and the frozen elementwise 0.01/0.01 logit allclose also failed. Candidate and greedy continuation-step logits likewise failed their component bounds.

Greedy token sequences, EOS and decoded answers were identical. Neither trajectory was a near tie: first-step top-two margins were 2.125 and 2.0 nat, with the EOS-step margin 7.625 in both. Equal answers cannot waive the numerical failure.

Post-Q endpoint comparisons also failed the fixed channel limits:

- Recurrent states: **16/18 tensors failed**; maximum absolute difference 0.0409861
- Convolution histories: **16/18 failed**; maximum absolute difference 0.25
- Full-attention K/V: **12/12 failed**; maximum absolute difference 0.1875

Corresponding greedy/candidate endpoint comparisons are retained in the ledger. No component-specific cause has been isolated; these observations do not identify which arithmetic/kernel operation caused the schedule discrepancy. All measured tensors were finite, dimensions and positions matched, clone non-aliasing was verified, and scoring reference caches remained unchanged.

## Provenance and precision

The single checkpoint is official **Qwen/Qwen3.5-2B revision `15852e8c16360a2fea060d615a32b45270f8a8fc`**, Apache-2.0. The entire 4,548,221,488-byte official source shard was streamed and hashed to **`aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`** without retaining a full copy. Its 320 language tensors were losslessly projected with original names, shapes, dtypes and exact per-tensor bytes; independent rereads verified every retained tensor.

The derivative is **3,763,696,896 bytes**, SHA-256 **`42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`**. This is a separately identified derived file, not the original shard identity.

Ordinary supported `Qwen3_5ForCausalLM.from_pretrained(dtype=torch.bfloat16)` loaded **1,881,825,088 unique parameters / 320 unique names** with zero missing, unexpected, mismatched or errored keys. The output embedding is explicitly tied to the input embedding. All loaded parameters were BF16, totaling **3,763,650,176 bytes**. Source storage had 2,592 FP32 elements and 1,881,822,496 BF16 elements; its language payload is 3,763,655,360 bytes, correctly distinguished from runtime parameter bytes.

Actual recurrent endpoints were FP32; convolution histories and attention K/V were BF16. The backend was eager full attention with unmodified official PyTorch GDN/convolution fallback, Torch 2.9.1+cpu and Transformers 5.19.0.dev0/source `02d8fb9784e8f14a1251e4c992cd82a5762417c6`. Intra-op/inter-op counts were each configured to one; sampled OS thread count reached two. No autocast, quantization, precision rescue, GPU, custom execution loader or dependency installation was used.

## Timing, work and resource guards

- Stream/projection/verification acquisition: **137.55 s**, separate from the qualification execution envelope
- Runtime admission/asset verification: **4.35 s**; ordinary BF16 load: **4.23 s**
- Full prefill: **10.14 s**; exact fresh A+B: **8.52 s**, fresh cached Q: **2.06 s**
- Full cell: **12.42 s**; exact cell: **12.69 s**
- Entire guarded execution: **35.04 s**, including admission, load, all scoring and output work
- Exactly **nine model forwards / 464 network tokens**: 458 prefill, four teacher-forced continuation, two greedy continuation
- Peak RSS/HWM: **4,479,287,296 bytes**, approximately **4.172 GiB**, below 8 GiB
- Peak sampled host unavailable memory: **2,876,076,032 bytes**, below 9 GB
- Minimum free disk during execution: **5,397,106,688 bytes**, above the 5 GB floor

The clean watchdog checked process RSS, VmHWM and final ru_maxrss, host memory, free disk, the 15-minute load limit and the 30-minute total envelope. Acquisition and verification warmed filesystem pages; the measured load is not a cold-load estimate. Fresh-prefix construction is included in exact-arm cost. These two cells are not a serving-throughput or savings experiment. No follow-on runtime projection or full matrix is justified after the gate failure.

## Audits and preserved artifacts

All 64 v3 context/token records passed before execution and were byte/token-identical to v2's task. The 84 tiny numerical controls passed, but did not predict pretrained parity. V1/v2 historical freezes and the v3 freeze, admitted runner/watchdog, immutable pre-run review snapshot and all asset receipts remain unchanged. Parent release and independent admission preceded the one load. The independent admission reviewer also confirmed the terminal numerical stop.

A separate audit reloaded only the saved logit tensors, without a model or forward, and exactly reproduced both candidate sums, greedy IDs, first-step TV, logit difference and margin drift. This rules out BF16 score-reporting granularity as the explanation: the published numbers were computed after explicit FP32 promotion.

- `run_report.json`: complete result, provenance, dtypes, timing and resource accounting
- `probe_cells.jsonl`: all sixteen planned cells, two completed outcomes and fourteen unrun reasons
- `saved_results_verification.json` and `verify_saved_results.py`: no-forward raw-logit audit
- `run.log`, `events.json`, `resource_samples.jsonl`, `watchdog.json`, `loading_info.json`: raw execution evidence
- `launch_receipt.json` and `admission_review_pre_run.md`: immutable release/review identity
- `run_probe.py` and `watch_probe.py`: reviewed executed sources, not a request to rerun

Raw BF16 first/candidate/greedy-step logits and reversible runtime token arrays remain in ignored `outputs/hybrid_cpu_competence_v3/qualification_run/`. This diagnostic directory does not duplicate model weights or reversible prompt/candidate token arrays. Separately frozen protocol files already contain their declared token records. No prior source/results were deleted, no commit/push was made, and no further model or GPU is authorized by this stopped qualification.
