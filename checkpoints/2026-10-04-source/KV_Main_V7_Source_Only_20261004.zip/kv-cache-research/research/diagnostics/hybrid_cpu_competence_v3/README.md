# One exploratory 2B/BF16 CPU substrate qualification

**Completed once and stopped at the first exact-prefix numerical gate: two cells completed, fourteen unrun.** Both observed answers were correct red; the fixed numerical parity contract failed. See `RESULTS.md` and `run_report.json` for the result and its narrow schedule-specific interpretation.

Execution required independent admission and explicit parent release. `launch_receipt_pending.json` preserves the parent-release hold; `launch_receipt.json` binds the exact reviewed runner/watchdog, immutable review snapshot, final v3 freeze, verified asset receipts, derived checkpoint digest and one output directory used by the sole run. No retry is authorized.

This experiment preserves the recorded 0.8B/FP32 competence failure. It permits one 2B checkpoint under the changed, explicit BF16-loaded/FP32-recurrence estimand. It does not establish equivalence to an unrun 2B FP32 model, a HYPIC quality result, or a research-paper contribution.

## Fixed scope

Exactly the original maximum sixteen cells: d01/d05 × A1/A2/U1/U2 × full/exact in the frozen order. All sixteen records are created before loading. First incorrect normalized full-recompute answer stops immediately before its exact arm; strict gold-token equality is reported separately. No repeats, chunked pretrained arms, held-out runs, other models, altered prompts, numerical threshold adjustment, or HYPIC reuse arms are available in this runner.

`run_probe.py` loads only through the pinned ordinary `Qwen3_5ForCausalLM.from_pretrained`, directly with `dtype=torch.bfloat16`. It verifies all 320 unique language parameter names/shapes, the 1,881,825,088 count, tied output embedding, zero missing/mismatched/errored/unexpected loading keys and actual loaded dtypes. The source stream's official digest and the derivative's distinct digest remain separately labeled. The derivative retains exact source language tensor bytes and omits only non-language tensors; it is not claimed to be the original file.

Full/exact controls use independently rebuilt target input and independently cloned caches. Every model output/cache must be finite and have the expected dtype/shape. Candidate and distribution statistics explicitly promote actual BF16 logits to FP32. All first/teacher-forced/greedy logits, post-Q endpoints, corresponding candidate endpoints and greedy endpoints are compared under the frozen numerical contract. Candidate-sum and candidate-margin differences must each be strictly below 0.01 nat, with identical complete greedy tokens, EOS and decoded answer. Near ties are flagged and never excuse disagreement. All actual BF16 step-logit tensors are retained under ignored outputs with disk checks.

`watch_probe.py` measures RSS and historical HWM every second, checks final `ru_maxrss`, enforces the 9 GB host unavailable-memory ceiling, 5 GB free-disk reserve, 15-minute model load limit and 30-minute complete execution envelope. No process or checkpoint retry is automatic. Data-verification reads, admission overhead, load, inference, scoring, serialization and failures all count in the execution envelope. Acquisition costs remain in the separately preserved projection receipts. A measured load after those reads must not be called cold.

## Preparation checks

Python syntax compilation passes. No model is instantiated by syntax checks. The external reviewer owns scientific/implementation admission; a successful subprocess exit alone never establishes a pass.

Historical v1/v2 files and outcomes are untouched. Only this new diagnostic directory is owned by the runner preparation task. Model assets remain at the separately verified ignored `outputs/text_only_asset_projection/Qwen3.5-2B-derived-text/` location; no source/results cleanup is allowed.
