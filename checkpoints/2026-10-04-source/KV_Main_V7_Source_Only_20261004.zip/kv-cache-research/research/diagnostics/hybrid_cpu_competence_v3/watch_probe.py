"""External process/host/disk watchdog; one released run, no automatic retries."""
import argparse
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
LIMITS = dict(RSS_bytes=8 * 1024**3, host_unavailable_bytes=9_000_000_000,
              free_disk_bytes=5_000_000_000, wall_seconds=1800, load_seconds=900)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(pid, elapsed):
    row = dict(utc=utc(), elapsed_seconds=elapsed, pid=pid, free_disk_bytes=shutil.disk_usage(ROOT).free)
    memory = {line.split(':')[0]: int(line.split()[1]) * 1024
              for line in Path('/proc/meminfo').read_text().splitlines()
              if line.startswith(('MemAvailable:', 'MemTotal:'))}
    row.update(host_total_bytes=memory['MemTotal'], host_available_bytes=memory['MemAvailable'],
               host_unavailable_bytes=memory['MemTotal'] - memory['MemAvailable'])
    if pid is not None:
        try:
            status = dict(line.split(':', 1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line)
            row.update(RSS_bytes=int(status.get('VmRSS', '0 kB').split()[0]) * 1024,
                       HWM_bytes=int(status.get('VmHWM', '0 kB').split()[0]) * 1024,
                       OS_threads=int(status.get('Threads', '0')))
        except FileNotFoundError:
            pass
    return row


def violation(row):
    if max(row.get('RSS_bytes', 0), row.get('HWM_bytes', 0)) >= LIMITS['RSS_bytes']:
        return '8 GiB process RSS/HWM limit reached'
    if row['host_unavailable_bytes'] >= LIMITS['host_unavailable_bytes']:
        return '9 GB host unavailable-memory limit reached'
    if row['free_disk_bytes'] < LIMITS['free_disk_bytes']:
        return '5 GB free-disk reserve breached'
    if row['elapsed_seconds'] >= LIMITS['wall_seconds']:
        return '30-minute complete execution envelope reached'
    return None


def write(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--release', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    receipt = json.loads(args.release.read_text())
    out = args.out.resolve()
    assert receipt['parent_release'] is True and receipt['reviewer_admitted'] is True
    assert receipt['watchdog_sha256'] == sha(Path(__file__))
    assert receipt['runner_sha256'] == sha(HERE / 'run_probe.py')
    assert out == Path(receipt['output_path']).resolve() and out.is_relative_to(ROOT / 'outputs')
    assert not (out / 'summary.json').exists() and not (out / 'execution_started.json').exists(), 'No automatic rerun'
    initial = snapshot(None, 0)
    assert violation(initial) is None, initial
    out.mkdir(parents=True, exist_ok=True)
    start_utc, start = utc(), time.monotonic()
    write(out / 'execution_started.json', dict(started_utc=start_utc, release_sha256=sha(args.release), initial_resources=initial,
                                              purpose='One admitted 16-cell maximum; no additional model forwards'))
    command = ['/tmp/hybrid_recurrence_cpu_env/bin/python', '-u', str(HERE / 'run_probe.py'),
               '--release', str(args.release.resolve()), '--out', str(out)]
    environment = os.environ.copy()
    environment.update(CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', HF_ENABLE_PARALLEL_LOADING='false')
    peak, host_peak, disk_min, reason, load_start, load_done = 0, 0, initial['free_disk_bytes'], None, None, False
    with (out / 'run.log').open('w') as logfile, (out / 'resource_samples.jsonl').open('w') as samples:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=logfile, stderr=subprocess.STDOUT)
        while process.poll() is None:
            row = snapshot(process.pid, time.monotonic() - start)
            peak = max(peak, row.get('RSS_bytes', 0), row.get('HWM_bytes', 0))
            host_peak = max(host_peak, row['host_unavailable_bytes'])
            disk_min = min(disk_min, row['free_disk_bytes'])
            phase_path = out / 'phase.json'
            if phase_path.exists():
                phase = json.loads(phase_path.read_text())
                row['phase'] = phase['phase']
                if phase['phase'] == 'load_start' and load_start is None:
                    load_start = phase['elapsed_seconds']
                if phase['phase'] not in ['admission_checks', 'load_start', 'initializing']:
                    load_done = True
            reason = violation(row)
            if load_start is not None and not load_done and row['elapsed_seconds'] - load_start >= LIMITS['load_seconds']:
                reason = '15-minute model load limit reached'
            samples.write(json.dumps(row) + '\n'); samples.flush()
            if reason:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
                break
            time.sleep(1)
        returncode = process.wait()
    final_resources = snapshot(None, time.monotonic() - start)
    disk_min = min(disk_min, final_resources['free_disk_bytes'])
    host_peak = max(host_peak, final_resources['host_unavailable_bytes'])
    reason = reason or violation(final_resources)
    summary_path = out / 'summary.json'
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    final_hwm = summary.get('peak_RSS_bytes', 0)
    peak = max(peak, final_hwm)
    if peak >= LIMITS['RSS_bytes']:
        reason = reason or 'Final ru_maxrss reaches 8 GiB limit (including between-sample spike)'
    if summary.get('load_seconds', 0) >= LIMITS['load_seconds']:
        reason = reason or 'Final measured model load reaches 15-minute limit'
    if returncode != 0 and reason is None:
        reason = f'Unexpected child process returncode {returncode}'
    if reason:
        summary.update(status='STOPPED_RESOURCE_OR_PROCESS', resource_stop_reason=reason)
        write(summary_path, summary)
        ledger = out / 'cells.jsonl'
        if ledger.exists():
            rows = [json.loads(line) for line in ledger.read_text().splitlines()]
            for row in rows:
                if row['status'] == 'running':
                    row.update(status='failed_implementation', reason=reason, failed_or_retried_work='Interrupted work; see per-forward ledger and external resource samples')
                elif row['status'] != 'completed':
                    row.update(status='not_run_budget', reason=reason)
            ledger.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    result = dict(started_utc=start_utc, finished_utc=utc(), wall_seconds=time.monotonic() - start,
                  returncode=returncode, resource_stop=reason, authoritative_child_status=summary.get('status'),
                  peak_RSS_or_HWM_bytes=peak, maximum_host_unavailable_bytes=host_peak,
                  minimum_free_disk_bytes=disk_min, final_resources=final_resources,
                  polling_seconds=1, limits=LIMITS, command=command,
                  note='Exit code zero is insufficient; inspect authoritative child status and all gate fields.')
    write(out / 'watchdog.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
