"""Package existing terminal evidence only. No model load, forward, download or retry."""
import collections
import datetime
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/hybrid_cpu_competence_v3/qualification_run'
ASSETS = ROOT / 'outputs/text_only_asset_projection'

def read(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    summary, watch = read(OUT / 'summary.json'), read(OUT / 'watchdog.json')
    receipt, audit = read(HERE / 'launch_receipt.json'), read(HERE / 'saved_results_verification.json')
    rows = [json.loads(line) for line in (OUT / 'cells.jsonl').read_text().splitlines()]
    assert len(rows) == 16 and sum(r['status'] == 'completed' for r in rows) == 2
    assert sum(r['status'] == 'not_run_gate' for r in rows) == 14
    assert summary['status'] == 'STOPPED_INITIAL_GATE' and watch['resource_stop'] is None
    assert summary['parity_status'] == 'failed_observed_control'
    assert audit['status'] == 'PASS_SAVED_LOGITS_AND_HISTORY_AUDIT'
    full, exact = rows[:2]
    assert all(r['raw_generated_token_ids'] == [1114, 248046] and r['normalized_answer_correct'] for r in [full, exact])
    n = exact['numerical_control_noise']
    contract = read(ROOT / 'research/protocols/hybrid_cpu_quality_v3/numerical_contract.json')
    acquisition = read(ASSETS / 'COMPLETE.json')
    metadata = read(ROOT / 'outputs/next_cpu_probe_metadata/model_api.json')
    preflight = read(ASSETS / 'preflight.json')
    assert sha(ROOT / 'outputs/next_cpu_probe_metadata/model_api.json') == preflight['source']['official_api_sha256']
    assert metadata['sha'] == summary['model_revision']
    endpoint = {channel: dict(tensors=len(exact[key]), failed=sum(not x['passed'] for x in exact[key]),
                              max_abs=max(x['max_abs'] for x in exact[key]), max_scaled_tolerance_ratio=max(x['max_scaled_tolerance_ratio'] for x in exact[key]))
                for channel, key in [('R', 'per_layer_recurrent_error'), ('C', 'per_layer_conv_error'), ('KV', 'per_layer_attention_KV_error')]}
    public = []
    for row in rows:
        copy = dict(row)
        copy['candidate_token_ids'] = None
        copy['candidate_token_ids_note'] = 'Kept in ignored execution ledger; public diagnostic does not duplicate reversible candidate/input arrays.'
        public.append(copy)
    (HERE / 'probe_cells.jsonl').write_text(''.join(json.dumps(r, allow_nan=False) + '\n' for r in public))
    for filename in ['watchdog.json', 'events.json', 'run.log', 'resource_samples.jsonl', 'loading_info.json']:
        shutil.copyfile(OUT / filename, HERE / filename)
    report = dict(status='STOPPED_FIRST_EXACT_PREFIX_NUMERICAL_GATE', reported_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  interpretation='The declared exploratory 2B/BF16 substrate fails its frozen exact-schedule numerical contract despite identical correct answers on the only tested context. Stop this CPU route. No HYPIC quality or 2B FP32-equivalence conclusion.',
                  task_scope='Exactly one released 2B checkpoint; original sixteen-cell maximum; no rescue, repeats, held-out inference, prompt changes, precision fallback or larger model',
                  protocol_id=summary['protocol_id'], planned_cells=16, completed_cells=2, unrun_cells=14,
                  cell_status_counts=dict(collections.Counter(r['status'] for r in rows)),
                  observed_contexts=['d01/A1'], observed_full_answers_correct=1, competence_status='Not established for the required two pairs/four unrelated contexts; first full context correct',
                  parity_status='Failed observed first full/exact pair', first_failure=summary['failure'],
                  observed_answers=[dict(arm=r['arm'], answer=r['decoded_answer_text'], expected=r['expected_answer'],
                                         raw_generated_token_ids=r['raw_generated_token_ids'], EOS_within_cap=r['EOS_within_cap'],
                                         normalized_correct=r['normalized_answer_correct'], strict_token_equal=r['strict_gold_token_sequence_equal'],
                                         candidate_sum_logprobs=r['candidate_sum_logprobs'], candidate_per_token_logprobs=r['candidate_per_token_logprobs'],
                                         candidate_margin=r['two_candidate_margin'], near_tie=r['near_tie_flag'], greedy_top_two_margins=r['greedy_top_two_logit_margins_nats']) for r in [full, exact]],
                  numerical_failure=dict(first_logit_metrics=n['first_step'], candidate_sum_deltas=n['candidate_sum_deltas'],
                                         candidate_margin_delta=n['candidate_margin_delta'], greedy_tokens_equal=n['same_greedy_ids'],
                                         EOS_equal=n['same_EOS'], answer_equal=n['same_decoded_answer'], endpoint_channels=endpoint,
                                         frozen_limits=contract['bf16_exact_schedule_controls']),
                  provenance=dict(model_id=summary['model_id'], revision=summary['model_revision'], license=metadata.get('cardData', {}).get('license'),
                                  official_original_shard_sha256=summary['original_shard_sha256'], official_original_shard_bytes=4_548_221_488,
                                  derived_exact_text_file_sha256=summary['derived_text_file_sha256'], derived_file_bytes=3_763_696_896,
                                  source_language_tensor_payload_bytes=3_763_655_360, verified_language_tensors=320,
                                  original_source_is_not_retained=True, derived_identity_is_not_original_file_identity=True,
                                  source_stored_parameter_counts=summary['source_storage_dtype_counts'], unique_loaded_parameters=summary['unique_parameters'],
                                  actual_loaded_parameter_bytes=summary['loaded_parameter_bytes'], actual_parameter_dtypes=summary['parameter_dtypes'],
                                  loading_info=summary['loading_info'], tied_embedding_verified=summary['tied_embedding_verified'],
                                  actual_cache_dtypes={'recurrent': 'float32', 'conv': 'bfloat16', 'attention_KV': 'bfloat16'},
                                  software_versions=summary['software_versions'], CPU_model=summary['CPU_model'], torch_thread_counts=summary['torch_thread_counts'],
                                  release_receipt_sha256=sha(HERE / 'launch_receipt.json'), admitted_review_snapshot_sha256=receipt['review_snapshot_sha256'],
                                  v3_manifest_sha256=receipt['v3_freeze_manifest_sha256'], runner_sha256=receipt['runner_sha256'], watchdog_sha256=receipt['watchdog_sha256'],
                                  historic_08_failure_preserved=True, all_frozen_protocols_and_admitted_sources_unchanged=True),
                  timing=dict(worker_assignment_utc='2026-10-03T16:58:28+00:00', execution_started_utc=watch['started_utc'],
                              preparation_wall_seconds_since_worker_assignment=(datetime.datetime.fromisoformat(watch['started_utc'])-datetime.datetime.fromisoformat('2026-10-03T16:58:28+00:00')).total_seconds(),
                              source_stream_projection_and_verification_seconds=acquisition['total_seconds'],
                              runtime_asset_verification_seconds=summary['asset_verification_seconds'], ordinary_BF16_load_seconds=summary['load_seconds'],
                              load_note='Acquisition, independent review and launch verification warmed pages; this is not cold-load time.',
                              complete_guarded_execution_seconds=watch['wall_seconds'], process_CPU_seconds=summary['total_CPU_seconds'],
                              cells=[{k:r.get(k) for k in ['arm','wall_seconds','target_prefill_seconds','query_seconds','teacher_forcing_seconds','greedy_decode_seconds','CPU_seconds']} for r in [full,exact]],
                              no_remaining_stage_projection='Gate failed; no serving performance estimate or follow-on matrix projection is justified.'),
                  work=dict(model_loads=1, model_forward_calls=summary['forward_calls_completed'], network_tokens=summary['actual_completed_network_tokens'],
                            prefill_tokens=sum(r['prefill_network_tokens'] for r in [full, exact]), teacher_force_tokens=sum(r['teacher_force_network_tokens'] for r in [full, exact]),
                            greedy_tokens=sum(r['greedy_network_tokens'] for r in [full, exact]), retries=0, HYPIC_reuse_cells=0, heldout_cells=0, other_model_forwards=0),
                  resources=dict(peak_RSS_or_HWM_bytes=watch['peak_RSS_or_HWM_bytes'], peak_RSS_GiB=watch['peak_RSS_or_HWM_bytes']/1024**3,
                                 host_unavailable_peak_bytes=watch['maximum_host_unavailable_bytes'], minimum_free_disk_during_run=watch['minimum_free_disk_bytes'],
                                 current_free_disk=shutil.disk_usage(ROOT).free, guard_limits=watch['limits'], resource_stop=None, GPU_used=False, cleanup_performed=False),
                  raw_artifacts=[r['raw_logits_artifact'] for r in [full, exact]], saved_logit_metrics_recomputed_without_forward=True)
    report['exact_schedule'] = dict(full={'tokens':229,'absolute_positions':[0,228],'mask_length':229}, exact_prefix={'AB_tokens':198,'AB_positions':[0,197],'Q_tokens':31,'Q_positions':[198,228],'mask_lengths':[198,229]}, answer_calls='Three independently cloned single-token branches at position229 per arm: red teacher-force, blue teacher-force, greedy red', input_hashes_identical=full['full_input_ids_sha256']==exact['full_input_ids_sha256'], native_GDN_chunk_size=64, full_GDN_chunks=[64,64,64,37], exact_GDN_chunks={'AB':[64,64,64,6],'Q':[31]}, source='Observed forward ledger plus pinned official model source', attribution_limit='No payload/order/position/clone-mutation mismatch found. Raw materialized masks were not compared. Arithmetic rounding versus a native cached-path implementation issue is not isolated; only this pinned full-versus-split-Q configuration failed.')
    write(HERE / 'call_schedule.json', summary['forward_calls'])
    assert report['resources']['current_free_disk'] >= 5_000_000_000
    write(HERE / 'run_report.json', report)
    print(json.dumps(dict(status=report['status'], completed=2, unrun=14, RSS_GiB=report['resources']['peak_RSS_GiB'], disk_free=report['resources']['current_free_disk'])))

if __name__ == '__main__':
    main()
