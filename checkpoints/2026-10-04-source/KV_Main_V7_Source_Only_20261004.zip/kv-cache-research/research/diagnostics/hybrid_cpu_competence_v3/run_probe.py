"""One frozen 2B/BF16 CPU qualification; never runs without an admitted release.
No alternative model, prompt, precision, repeat, chunk, HYPIC, or hidden fallback.
"""
import os
os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                  OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false',
                  HF_ENABLE_PARALLEL_LOADING='false')
import argparse
import collections
import copy
import datetime
import hashlib
import importlib.util
import json
import math
import resource
import shutil
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
PROTOCOL = ROOT / 'research/protocols/hybrid_cpu_quality_v3'
ASSETS = ROOT / 'outputs/text_only_asset_projection'
MODEL = ASSETS / 'Qwen3.5-2B-derived-text'
MODEL_ID = 'Qwen/Qwen3.5-2B'
MODEL_REV = '15852e8c16360a2fea060d615a32b45270f8a8fc'
SOURCE_SHA = 'aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1'
DERIVED_SHA = '42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c'
FLOOR = 5_000_000_000


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(4 * 1024 * 1024):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def normalize(value):
    if isinstance(value, dict):
        return {str(k): normalize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalize(v) for v in value]
    if isinstance(value, set):
        return [normalize(v) for v in sorted(value)]
    return value


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(normalize(value), indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_freeze(folder, expected_sha=None):
    manifest = folder / 'freeze_manifest.json'
    if expected_sha:
        assert sha(manifest) == expected_sha, 'Freeze manifest identity changed'
    freeze = read(manifest)
    for name, record in freeze['files'].items():
        assert sha(folder / name) == record['sha256'], f'Frozen file changed: {name}'
    return freeze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--release', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    assert out.is_relative_to(ROOT / 'outputs'), 'Raw logits/results must stay in ignored outputs'
    assert not (out / 'summary.json').exists(), 'Existing outcomes prohibit silent rerun'
    out.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    cpu_started = time.process_time()
    protocol = read(PROTOCOL / 'protocol.json')
    contract = read(PROTOCOL / 'numerical_contract.json')
    reporting = read(PROTOCOL / 'result_contract.json')
    template = read(PROTOCOL / 'template.json')
    tokens = read(PROTOCOL / 'token_validation.json')
    selected = {(c['pair_id'], c['variant']): c for c in tokens['token_checks']['contexts']
                if c['pair_id'] in ['d01', 'd05']}
    assert len(selected) == 8
    required = sum([v for k, v in reporting.items() if k.startswith('required_')], [])
    records = []
    for index, (pair_id, variant, arm) in enumerate(protocol['execution_order']):
        context = selected[(pair_id, variant)]
        row = {key: None for key in required}
        row.update(protocol_id=protocol['protocol_id'], run_id=out.name, pair_id=pair_id,
                   variant=variant, arm=arm, split='development', repeat_index=0,
                   donor_bits=None, oracle_group=None, planned_order=index,
                   status='not_run_gate', reason='Pending admission and first-cell gates',
                   expected_answer=context['expected_answer'],
                   A_token_count=len(context['A_ids']), B_token_count=len(context['B_ids']),
                   Q_token_count=len(context['Q_ids']), B_absolute_start=len(context['A_ids']),
                   important_interior_token_span=context['important_token_span_zero_based_in_B'],
                   full_input_ids_sha256=hashlib.sha256(json.dumps(context['input_ids']).encode()).hexdigest(),
                   B_input_ids_sha256=hashlib.sha256(json.dumps(context['B_ids']).encode()).hexdigest(),
                   candidate_token_ids=context['answer_candidate_ids_including_eos'],
                   model_id=MODEL_ID, model_revision=MODEL_REV, dtype='bfloat16-loaded; official FP32 recurrence',
                   CPU_threads={'torch_intra_op': 1, 'torch_inter_op': 1}, backend='eager attention / official torch GDN fallback',
                   seed=20261003, cache_channel_contract='18 FP32 recurrent, 18 BF16 conv, 6 BF16 full-attention K/V; absolute positions',
                   null_reason='Not executed, not applicable, or explicitly unmeasured; see status and measurement notes')
        records.append(row)
    assert len(records) == 16
    summary = dict(status='INITIALIZING', started_utc=now(), protocol_id=protocol['protocol_id'],
                   model_id=MODEL_ID, model_revision=MODEL_REV, execution_order=[], forward_calls=[],
                   scientific_scope='Exploratory 2B/BF16 substrate qualification after preserved 0.8B FP32 failure; no FP32-equivalence or HYPIC quality claim',
                   parity_status='not_tested', model_load_attempts=0)
    events = []
    current = None
    admission_passed = False
    load_started = None

    def save():
        write(out / 'summary.json', summary)
        temporary = out / 'cells.jsonl.tmp'
        temporary.write_text(''.join(json.dumps(normalize(r), allow_nan=False) + '\n' for r in records))
        temporary.replace(out / 'cells.jsonl')

    def event(phase, **details):
        record = dict(utc=now(), elapsed_seconds=time.monotonic() - started, phase=phase, **details)
        events.append(record)
        write(out / 'events.json', events)
        write(out / 'phase.json', record)

    save()  # All sixteen explicit records exist before any admission check or load.
    event('admission_checks')
    try:
        release = read(args.release)
        assert release['parent_release'] is True and release['reviewer_admitted'] is True
        assert out == Path(release['output_path']).resolve(), 'Receipt binds one output/run identity'
        assert release['runner_sha256'] == sha(Path(__file__))
        assert release['watchdog_sha256'] == sha(HERE / 'watch_probe.py')
        review_snapshot = Path(release['review_snapshot_path'])
        assert review_snapshot.is_file() and sha(review_snapshot) == release['review_snapshot_sha256']
        freeze = verify_freeze(PROTOCOL, release['v3_freeze_manifest_sha256'])
        for folder, expected in release['historical_freezes'].items():
            verify_freeze(ROOT / folder, expected)
        assert sha(PROTOCOL / 'fixtures.jsonl') == '05a86266cca27dbcb34d6b6e858d7030d5b01c0647ca536c72554c5d186a2350'
        assert tokens['token_status'] == 'passed' and len(tokens['token_checks']['contexts']) == 64
        tiny = read(PROTOCOL / 'tiny_gate_results.json')
        tiny_watch = read(PROTOCOL / 'tiny_watchdog.json')
        assert tiny['status'] == 'PASS_TINY_NUMERICAL_CONTROLS_ONLY'
        assert len(tiny['tests']) == 84 and all(r['passed'] is True for r in tiny['tests'])
        assert tiny_watch['returncode'] == 0 and tiny_watch['resource_stop'] is None
        assert tiny['contract_sha256'] == sha(PROTOCOL / 'numerical_contract.json')
        assert tiny['script_sha256'] == sha(PROTOCOL / 'run_tiny_gate.py')
        completion = read(ASSETS / 'COMPLETE.json')
        stream = read(ASSETS / 'stream_manifest.json')
        disk = read(ASSETS / 'disk_verification.json')
        preflight = read(ASSETS / 'preflight.json')
        for filename, digest in release['asset_receipts'].items():
            assert sha(ASSETS / filename) == digest, f'Asset receipt changed: {filename}'
        assert completion['status'] == disk['status'] == 'verified'
        assert completion['source_sha256'] == stream['source_sha256'] == SOURCE_SHA
        assert stream['source_bytes_read'] == 4_548_221_488
        assert completion['derived_sha256'] == disk['derived_sha256'] == DERIVED_SHA
        assert completion['verified_tensors'] == disk['verified_tensor_count'] == 320
        assert completion['minimum_free_disk_bytes'] >= FLOOR and completion['free_disk_after'] >= FLOOR
        assert completion['no_pretrained_load_or_forward'] is True
        assert preflight['source']['model'] == MODEL_ID and preflight['source']['revision'] == MODEL_REV
        assert len(preflight['mapped_keys']) == 320 and preflight['unique_parameters'] == 1_881_825_088
        assert preflight['tied_weight_aliases'] == {'lm_head.weight': 'model.embed_tokens.weight'}
        assert stream['source_header_sha256'] == preflight['source']['source_header_sha256']
        retained = {r['derived_name']: r for r in stream['tensors'] if r['selected']}
        assert len(stream['tensors']) == 632 and len(retained) == 320
        assert set(retained) == set(preflight['mapped_keys'].values())
        assert all(r['source_name'] == r['derived_name'] and r['source_name'].startswith('model.language_model.') for r in retained.values())
        assert sum(r['bytes'] for r in retained.values()) == 3_763_655_360
        assert release['derived_weights_sha256'] == DERIVED_SHA
        assert sha(MODEL / 'model.safetensors') == DERIVED_SHA
        for filename, entry in preflight['small_files'].items():
            assert sha(MODEL / filename) == entry['sha256'], f'Official small file changed: {filename}'
        # Revalidate every text/template against the exact admitted official local assets.
        validation = load_module(PROTOCOL / 'validate_protocol.py', 'frozen_v3_validation')
        independently_validated = validation.validate_tokens(validation.load_fixtures(PROTOCOL), template,
                                                            MODEL, PROTOCOL / 'tokenizer_provenance.json')
        assert independently_validated['contexts'] == tokens['token_checks']['contexts']
        assert shutil.disk_usage(out).free >= FLOOR + 128 * 1024**2, 'No headroom for bounded raw-logit artifacts'
        summary.update(admission_receipt_sha256=sha(args.release), review_snapshot_sha256=sha(review_snapshot),
                       protocol_file_hashes=freeze['files'], numerical_contract_sha256=sha(PROTOCOL / 'numerical_contract.json'),
                       original_shard_sha256=SOURCE_SHA, derived_text_file_sha256=DERIVED_SHA,
                       asset_verification_seconds=time.monotonic() - started, disk_before_load=shutil.disk_usage(out)._asdict(),
                       source_storage_dtype_counts=dict(collections.Counter({dtype: sum(math.prod(r['shape']) for r in retained.values() if r['dtype'] == dtype) for dtype in ['F32', 'BF16']})))
        for row in records:
            row.update(protocol_file_hashes=freeze['files'], fixture_sha256=protocol['fixture_source_sha256'],
                       weights_checksums={'official_complete_source': SOURCE_SHA, 'derived_exact_language_subset': DERIVED_SHA},
                       tokenizer_provenance=read(PROTOCOL / 'tokenizer_provenance.json'),
                       adapter_source_revision=contract['model']['transformers_git'],
                       author_semantics_mapping='No HYPIC code or segment reuse runs; independent target full/exact only')
        admission_passed = True
        save()
        event('load_start')
        load_started = time.monotonic()
        import torch
        import transformers
        from tokenizers import Tokenizer
        from transformers import Qwen3_5TextConfig, Qwen3_5ForCausalLM
        from transformers.models.qwen3_5 import modeling_qwen3_5 as hf
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        torch.manual_seed(20261003)
        assert torch.__version__ == '2.9.1+cpu' and torch.version.cuda is None and not torch.cuda.is_available()
        package = Path(transformers.__file__).resolve().parent
        for relative, entry in preflight['source_code'].items():
            assert sha(package / relative) == entry['sha256'], f'Official loader source changed: {relative}'
        tokenizer = Tokenizer.from_file(str(MODEL / 'tokenizer.json'))
        eos = template['required_special_token_ids']['<|im_end|>']
        assert tokenizer.token_to_id('<|im_end|>') == eos == 248046
        config = Qwen3_5TextConfig.from_pretrained(str(MODEL), local_files_only=True)
        summary['model_load_attempts'] = 1
        save()
        model, loading = Qwen3_5ForCausalLM.from_pretrained(
            str(MODEL), config=config, dtype=torch.bfloat16, attn_implementation='eager',
            local_files_only=True, trust_remote_code=False, output_loading_info=True)
        model.eval()
        loading = normalize(loading)
        write(out / 'loading_info.json', loading)
        assert not any(loading.get(k) for k in ['missing_keys', 'unexpected_keys', 'mismatched_keys', 'error_msgs']), loading
        named = dict(model.named_parameters())
        assert set(named) == set(preflight['mapped_keys']) and len(named) == 320
        assert sum(p.numel() for p in named.values()) == 1_881_825_088
        assert all(p.device.type == 'cpu' and p.dtype == torch.bfloat16 for p in named.values())
        assert model.lm_head.weight is model.model.embed_tokens.weight
        assert model.lm_head.weight.data_ptr() == model.model.embed_tokens.weight.data_ptr()
        assert all(list(named[dst].shape) == retained[src]['shape'] for dst, src in preflight['mapped_keys'].items())
        load_seconds = time.monotonic() - load_started
        assert load_seconds <= protocol['resources']['load_seconds_max']
        software = dict(torch=torch.__version__, transformers=transformers.__version__, python=sys.version,
                        transformers_git=contract['model']['transformers_git'], modeling_sha256=sha(Path(hf.__file__)),
                        cpu_capability=torch.backends.cpu.get_cpu_capability(), mkldnn_enabled=torch.backends.mkldnn.enabled)
        cpu_model = next(x.split(':', 1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name'))
        summary.update(status='RUNNING', loading_info=loading, load_seconds=load_seconds, software_versions=software,
                       unique_parameters=sum(p.numel() for p in named.values()), loaded_parameter_bytes=sum(p.numel() * p.element_size() for p in named.values()),
                       parameter_dtypes=sorted({str(p.dtype) for p in named.values()}), tied_embedding_verified=True,
                       CPU_model=cpu_model, torch_thread_counts={'intra_op': torch.get_num_threads(), 'inter_op': torch.get_num_interop_threads()},
                       precision_scope='BF16-loaded full recomputation with official FP32 recurrent accumulation is the reference; no 2B FP32 equivalence is assumed')
        for row in records:
            row.update(software_versions=software, CPU_model=cpu_model)
        save()
        event('load_complete', load_seconds=load_seconds)
        limits = contract['bf16_exact_schedule_controls']
        forward_id = 0

        def finite(tensor, label):
            assert bool(torch.isfinite(tensor).all()), f'Nonfinite {label}'

        def tensors(cache):
            for index, layer in enumerate(cache.layers):
                if hasattr(layer, 'recurrent_states'):
                    for slot, tensor in sorted(layer.recurrent_states.items()):
                        yield index, 'recurrent', str(slot), tensor
                    for slot, tensor in sorted(layer.conv_states.items()):
                        yield index, 'conv', str(slot), tensor
                else:
                    yield index, 'keys', '', layer.keys
                    yield index, 'values', '', layer.values

        def inventory(cache, expected_length):
            assert len(cache.layers) == 24 and cache.get_seq_length() == expected_length
            rows = []
            for index, kind, slot, tensor in tensors(cache):
                finite(tensor, f'cache {index}/{kind}')
                assert tensor.dtype == (torch.float32 if kind == 'recurrent' else torch.bfloat16)
                assert tensor.device.type == 'cpu'
                if kind == 'recurrent':
                    assert tuple(tensor.shape) == (1, 16, 128, 128)
                elif kind == 'conv':
                    assert tuple(tensor.shape) == (1, 6144, 4)
                else:
                    assert tuple(tensor.shape) == (1, 2, expected_length, 256)
                rows.append(dict(layer=index, kind=kind, slot=slot, shape=list(tensor.shape),
                                 dtype=str(tensor.dtype), bytes=tensor.numel() * tensor.element_size()))
            assert collections.Counter(r['kind'] for r in rows) == {'recurrent': 18, 'conv': 18, 'keys': 6, 'values': 6}
            return rows

        def clone(cache):
            result = copy.deepcopy(cache)
            source_items, target_items = list(tensors(cache)), list(tensors(result))
            assert len(source_items) == len(target_items) and cache.get_seq_length() == result.get_seq_length()
            for (i, k, s, a), (ii, kk, ss, b) in zip(source_items, target_items):
                assert (i, k, s) == (ii, kk, ss) and a.data_ptr() != b.data_ptr() and torch.equal(a, b)
            return result

        def cache_compare(actual, reference, bitwise=False):
            assert actual.get_seq_length() == reference.get_seq_length()
            aa, bb = list(tensors(actual)), list(tensors(reference))
            assert len(aa) == len(bb)
            result = []
            for (index, kind, slot, x), (ii, kk, ss, y) in zip(aa, bb):
                assert (index, kind, slot) == (ii, kk, ss) and x.shape == y.shape and x.dtype == y.dtype
                finite(x, 'actual cache'); finite(y, 'reference cache')
                xx, yy = x.float(), y.float()
                delta = (xx - yy).abs()
                atol = limits['endpoint_recurrent_atol'] if kind == 'recurrent' else limits['endpoint_conv_attention_atol']
                rtol = limits['endpoint_recurrent_rtol'] if kind == 'recurrent' else limits['endpoint_conv_attention_rtol']
                ok = torch.equal(x, y) if bitwise else bool((delta <= atol + rtol * yy.abs()).all())
                result.append(dict(layer=index, kind=kind, slot=slot, dtype=str(x.dtype), max_abs=float(delta.max()),
                                   max_scaled_tolerance_ratio=float((delta / (atol + rtol * yy.abs())).max()), passed=ok,
                                   comparison='bitwise' if bitwise else 'frozen_BF16_endpoint_limits'))
            return result

        def logits_compare(actual, reference):
            finite(actual, 'actual logits'); finite(reference, 'reference logits')
            a, b = actual.float(), reference.float()
            delta = (a - b).abs()
            tv = float((a.softmax(-1) - b.softmax(-1)).abs().sum() / 2)
            tol = limits['logit_atol'] + limits['logit_rtol'] * b.abs()
            return dict(max_abs=float(delta.max()), TV=tv, max_scaled_tolerance_ratio=float((delta / tol).max()),
                        passed=bool((delta <= tol).all()) and tv <= limits['TV_max'])

        def forward(ids, cache, purpose):
            nonlocal forward_id
            assert current is not None
            length = 0 if cache is None else cache.get_seq_length()
            call = dict(index=forward_id, pair_id=current['pair_id'], variant=current['variant'], arm=current['arm'],
                        purpose=purpose, tokens=len(ids), absolute_start=length, started_utc=now(), status='started')
            summary['forward_calls'].append(call)
            forward_id += 1
            save()
            timer = time.monotonic()
            output = model(input_ids=torch.tensor([ids], dtype=torch.long), past_key_values=cache,
                           attention_mask=torch.ones((1, length + len(ids)), dtype=torch.long),
                           position_ids=torch.arange(length, length + len(ids), dtype=torch.long).unsqueeze(0),
                           use_cache=True, logits_to_keep=1)
            call.update(status='completed', seconds=time.monotonic() - timer, finished_utc=now())
            finite(output.logits, 'model logits')
            assert output.logits.dtype == torch.bfloat16
            current['cache_inventory'] = inventory(output.past_key_values, length + len(ids))
            save()
            return output

        def score(output, context, row):
            base = output.past_key_values
            saved = clone(base)
            first = output.logits[0, -1].clone()
            candidates, sums, per_token = {}, {}, {}
            teacher_start = time.monotonic()
            for answer, candidate in context['answer_candidate_ids_including_eos'].items():
                branch, logits, scores, steps = clone(base), first, [], []
                for index, token_id in enumerate(candidate):
                    finite(logits, 'candidate logits')
                    steps.append(logits.clone())
                    score_value = float(logits.float().log_softmax(-1)[token_id])
                    assert math.isfinite(score_value)
                    scores.append(score_value)
                    if index < len(candidate) - 1:
                        nxt = forward([token_id], branch, 'teacher_force')
                        branch, logits = nxt.past_key_values, nxt.logits[0, -1]
                total = sum(scores)
                assert math.isfinite(total)
                sums[answer], per_token[answer] = total, scores
                candidates[answer] = dict(logits=steps, cache=branch)
            teacher_seconds = time.monotonic() - teacher_start
            greedy_start = time.monotonic()
            branch, logits, generated, margins, greedy_logits = clone(base), first, [], [], []
            eos_found = False
            for index in range(template['max_new_tokens']):
                finite(logits, 'greedy logits')
                greedy_logits.append(logits.clone())
                top = logits.float().topk(2).values
                margins.append(float(top[0] - top[1]))
                token_id = int(logits.argmax())  # Prediction uses original model logits.
                generated.append(token_id)
                row['raw_generated_token_ids'] = list(generated)
                row['greedy_top_two_logit_margins_nats'] = list(margins)
                save()
                if token_id == eos:
                    eos_found = True
                    break
                if index < template['max_new_tokens'] - 1:
                    nxt = forward([token_id], branch, 'greedy')
                    branch, logits = nxt.past_key_values, nxt.logits[0, -1]
            decode_seconds = time.monotonic() - greedy_start
            assert all(r['passed'] for r in cache_compare(base, saved, bitwise=True)), 'Scoring source cache mutated'
            expected = context['expected_answer']
            other = next(answer for answer in sums if answer != expected)
            raw = tokenizer.decode(generated[:-1] if eos_found else generated, skip_special_tokens=False)
            row.update(raw_generated_token_ids=generated, decoded_answer_text=raw,
                       decoded_sequence_including_special_tokens=tokenizer.decode(generated, skip_special_tokens=False),
                       EOS_within_cap=eos_found,
                       normalized_answer_correct=validation.score_answer(raw, expected, eos_within_cap=eos_found),
                       strict_gold_token_sequence_equal=generated == context['answer_candidate_ids_including_eos'][expected],
                       candidate_sum_logprobs=sums, candidate_per_token_logprobs=per_token,
                       candidate_length_normalized_logprobs={a: sums[a] / len(per_token[a]) for a in sums},
                       gold_sum_logprob=sums[expected], two_candidate_margin=sums[expected] - sums[other],
                       teacher_forcing_seconds=teacher_seconds, greedy_decode_seconds=decode_seconds,
                       decode_and_score_seconds=teacher_seconds + decode_seconds,
                       near_tie_flag=any(m <= contract['near_ties']['margin_threshold_nats'] for m in margins),
                       cache_clone_verified=True, scoring_source_cache_unchanged=True,
                       cached_tensor_bytes=sum(t.numel() * t.element_size() for _, _, _, t in tensors(base)))
            raw_logits = dict(first=first, candidate_steps={a: v['logits'] for a, v in candidates.items()},
                              greedy_steps=greedy_logits, greedy_ids=generated, actual_dtype='bfloat16')
            estimated_bytes = first.numel() * first.element_size() * (1 + len(greedy_logits) + sum(len(v['logits']) for v in candidates.values()))
            assert shutil.disk_usage(out).free >= FLOOR + estimated_bytes + 16 * 1024**2
            artifact = out / f"{row['pair_id']}_{row['variant']}_{row['arm']}_raw_logits.pt"
            torch.save(raw_logits, artifact)
            assert shutil.disk_usage(out).free >= FLOOR
            row['raw_logits_artifact'] = dict(path=str(artifact.relative_to(ROOT)), sha256=sha(artifact), bytes=artifact.stat().st_size,
                                             note='Actual BF16 tensors; first, all teacher-forced candidate steps, and all greedy steps. Probabilities/statistics computed in FP32.')
            return dict(first=first, cache=base, candidates=candidates, greedy_logits=greedy_logits, greedy_cache=branch)

        def parity(actual, reference, row, reference_row):
            first_metrics = logits_compare(actual['first'], reference['first'])
            candidate_metrics = {answer: [logits_compare(a, b) for a, b in zip(actual['candidates'][answer]['logits'], reference['candidates'][answer]['logits'])]
                                 for answer in actual['candidates']}
            sum_deltas = {answer: row['candidate_sum_logprobs'][answer] - reference_row['candidate_sum_logprobs'][answer]
                          for answer in row['candidate_sum_logprobs']}
            margin_delta = row['two_candidate_margin'] - reference_row['two_candidate_margin']
            same_ids = row['raw_generated_token_ids'] == reference_row['raw_generated_token_ids']
            same_text = row['decoded_answer_text'] == reference_row['decoded_answer_text']
            same_eos = row['EOS_within_cap'] == reference_row['EOS_within_cap']
            same_steps = len(actual['greedy_logits']) == len(reference['greedy_logits'])
            greedy_metrics = [logits_compare(a, b) for a, b in zip(actual['greedy_logits'], reference['greedy_logits'])]
            endpoint = cache_compare(actual['cache'], reference['cache'])
            greedy_endpoint = cache_compare(actual['greedy_cache'], reference['greedy_cache']) if same_ids else None
            candidate_endpoints = {a: cache_compare(actual['candidates'][a]['cache'], reference['candidates'][a]['cache']) for a in actual['candidates']}
            sums_pass = all(abs(delta) < limits['candidate_sum_logprob_delta_abs_strictly_below'] for delta in sum_deltas.values())
            margin_pass = abs(margin_delta) < limits['candidate_margin_delta_abs_strictly_below']
            logits_pass = first_metrics['passed'] and all(x['passed'] for rows in candidate_metrics.values() for x in rows) and all(x['passed'] for x in greedy_metrics)
            endpoint_pass = all(x['passed'] for x in endpoint) and greedy_endpoint is not None and all(x['passed'] for x in greedy_endpoint) and all(x['passed'] for rows in candidate_endpoints.values() for x in rows)
            passed = same_ids and same_text and same_eos and same_steps and sums_pass and margin_pass and logits_pass and endpoint_pass
            row.update(first_answer_token_TV_vs_full=first_metrics['TV'], maximum_absolute_logit_delta_vs_full=first_metrics['max_abs'],
                       numerical_control_noise=dict(first_step=first_metrics, candidate_steps=candidate_metrics, greedy_steps=greedy_metrics,
                                                    candidate_sum_deltas=sum_deltas, candidate_margin_delta=margin_delta,
                                                    sums_strictly_below_threshold=sums_pass, margin_strictly_below_threshold=margin_pass,
                                                    same_greedy_ids=same_ids, same_decoded_answer=same_text, same_EOS=same_eos,
                                                    greedy_endpoint=greedy_endpoint, candidate_endpoints=candidate_endpoints),
                       per_layer_recurrent_error=[x for x in endpoint if x['kind'] == 'recurrent'],
                       per_layer_conv_error=[x for x in endpoint if x['kind'] == 'conv'],
                       per_layer_attention_KV_error=[x for x in endpoint if x['kind'] in ['keys', 'values']],
                       exact_prefix_parity_pass=passed)
            return passed

        stop = None
        full_correct, parity_results = {}, []
        reference = reference_row = None
        with torch.inference_mode():
            for row in records:
                if stop:
                    break
                current = row
                context = selected[(row['pair_id'], row['variant'])]
                assert len(summary['execution_order']) == row['planned_order']
                row.update(status='running', reason=None, started_utc=now(), execution_order=len(summary['execution_order']))
                summary['execution_order'].append([row['pair_id'], row['variant'], row['arm']])
                save(); event('cell_start', pair_id=row['pair_id'], variant=row['variant'], arm=row['arm'])
                timer, cpu_timer, call_start = time.monotonic(), time.process_time(), len(summary['forward_calls'])
                if row['arm'] == 'full_recompute':
                    prefill_start = time.monotonic()
                    output = forward(context['input_ids'], None, 'full_prefill')
                    row['target_prefill_seconds'] = time.monotonic() - prefill_start
                    row['query_seconds'] = None
                else:
                    prefill_start = time.monotonic()
                    prefix = forward(context['A_ids'] + context['B_ids'], None, 'exact_prefix_build')
                    row['target_prefill_seconds'] = time.monotonic() - prefill_start
                    original = clone(prefix.past_key_values)
                    copy_start = time.monotonic()
                    branch = clone(prefix.past_key_values)
                    row['copy_and_IO_seconds'] = time.monotonic() - copy_start
                    query_start = time.monotonic()
                    output = forward(context['Q_ids'], branch, 'cached_Q')
                    row['query_seconds'] = time.monotonic() - query_start
                    assert all(x['passed'] for x in cache_compare(prefix.past_key_values, original, bitwise=True)), 'Exact-prefix source mutated'
                scored = score(output, context, row)
                calls = summary['forward_calls'][call_start:]
                counts = collections.Counter()
                for call in calls:
                    counts[call['purpose']] += call['tokens']
                row.update(status='completed', finished_utc=now(), wall_seconds=time.monotonic() - timer,
                           CPU_seconds=time.process_time() - cpu_timer, load_seconds=load_seconds,
                           peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                           prefill_network_tokens=sum(counts[k] for k in ['full_prefill', 'exact_prefix_build', 'cached_Q']),
                           greedy_network_tokens=counts['greedy'], teacher_force_network_tokens=counts['teacher_force'],
                           trace_network_tokens=0, source_build_seconds=0, tuple_build_seconds=0, tuple_apply_seconds=0,
                           seam_seconds=0, tuple_MACs=0, regenerated_endpoints=0, failed_or_retried_work=[],
                           measurement_notes={'reference_precision': 'BF16-loaded graph with FP32 recurrence; no FP32-equivalence claim',
                                              'query_seconds': 'Monolithic full includes Q; exact reports cached Q separately',
                                              'load_seconds': 'One shared load; not additive per cell. Asset verification/read caching occurred before load.',
                                              'nonapplicable': 'No HYPIC source, tuple, seam, trace, donor or oracle work',
                                              'scores': 'FP32 log_softmax on actual BF16 logits; Python sum of finite token scores'})
                if row['arm'] == 'full_recompute':
                    reference, reference_row = scored, copy.deepcopy(row)
                    full_correct[(row['pair_id'], row['variant'])] = row['normalized_answer_correct']
                    row.update(first_answer_token_TV_vs_full=0, maximum_absolute_logit_delta_vs_full=0)
                    if not row['normalized_answer_correct']:
                        stop = 'not_run_competence'
                        summary['failure'] = dict(type='full_recompute_incorrect', pair_id=row['pair_id'], variant=row['variant'],
                                                  expected=row['expected_answer'], actual=row['decoded_answer_text'], EOS=row['EOS_within_cap'])
                else:
                    passed = parity(scored, reference, row, reference_row)
                    parity_results.append(passed)
                    if not passed:
                        stop = 'not_run_gate'
                        summary['failure'] = dict(type='BF16_exact_schedule_numerical_or_greedy_failure', pair_id=row['pair_id'], variant=row['variant'])
                current = None
                save(); event('cell_complete', pair_id=row['pair_id'], variant=row['variant'], arm=row['arm'],
                              correct=row['normalized_answer_correct'], raw_answer=row['decoded_answer_text'], stop_reason=stop)
                print(json.dumps(dict(pair_id=row['pair_id'], variant=row['variant'], arm=row['arm'],
                                      answer=row['decoded_answer_text'], correct=row['normalized_answer_correct'], stop=stop)), flush=True)
                if row['arm'] == 'exact_prefix':
                    # Release current-target caches before starting the next independent target.
                    reference = reference_row = scored = output = prefix = original = branch = None
            for row in records:
                if row['status'] != 'completed':
                    row.update(status=stop or 'not_run_gate', reason=summary.get('failure', 'No further cells authorized'))
            competence = len(full_correct) == 8 and all(full_correct.values())
            parity_pass = len(parity_results) == 8 and all(parity_results)
            summary.update(status='PASS_BF16_SUBSTRATE_QUALIFICATION_ONLY' if competence and parity_pass else 'STOPPED_INITIAL_GATE',
                           competence_gate_pass=competence, full_contexts_completed=len(full_correct), exact_contexts_completed=len(parity_results),
                           parity_status=('passed_all_eight' if parity_pass else ('failed_observed_control' if parity_results and not all(parity_results) else ('not_tested' if not parity_results else 'partial_pass_not_complete'))),
                           completed_cells=sum(r['status'] == 'completed' for r in records),
                           not_run_cells=sum(r['status'] != 'completed' for r in records),
                           observed_full_answers=[dict(pair_id=k[0], variant=k[1], correct=v) for k, v in full_correct.items()])
    except Exception as error:
        summary.update(status='FAILED_ADMISSION_OR_IMPLEMENTATION_OR_NUMERICAL', exception=repr(error), traceback=traceback.format_exc(),
                       admission_passed=admission_passed)
        if current is not None:
            current.update(status='failed_implementation', reason=repr(error), finished_utc=now())
        for row in records:
            if row['status'] == 'not_run_gate':
                row['reason'] = 'Stopped by an admission, implementation, or finite/dtype/shape gate; see summary'
        print(traceback.format_exc(), flush=True)
    finally:
        final_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        if final_peak >= 8 * 1024**3:
            summary.update(status='STOPPED_RESOURCE', resource_stop_reason='Final ru_maxrss reaches 8 GiB limit')
        summary.update(finished_utc=now(), total_wall_seconds=time.monotonic() - started,
                       total_CPU_seconds=time.process_time() - cpu_started,
                       peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                       actual_completed_network_tokens=sum(c['tokens'] for c in summary['forward_calls'] if c['status'] == 'completed'),
                       attempted_network_tokens=sum(c['tokens'] for c in summary['forward_calls']),
                       forward_calls_started=len(summary['forward_calls']),
                       forward_calls_completed=sum(c['status'] == 'completed' for c in summary['forward_calls']),
                       disk_at_stop=shutil.disk_usage(out)._asdict())
        save(); event('finished', status=summary['status'])


if __name__ == '__main__':
    main()
