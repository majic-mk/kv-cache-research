# Cache-correctness research scope assessment

Review cutoff: **2026-10-03 UTC**. Primary literature window: October 2024–October 2026. This is a read-only research/source assessment, plus this report. No implementation or experiment was run, no model or dependency was downloaded, no issue was filed, and no paid work was started. Existing project experiments are explicitly distinguished from this review.

## Recommendation

**Do not promote the current collection into a main SCI-targeted research project.** A useful conformance-testing contribution is possible in principle without inventing another compression heuristic, but it has not been established here. “Unified KV/SSM correctness contracts,” “metamorphic cache testing,” “CPU-only witnesses,” and “exact-versus-cached comparisons” are individually too close to current papers or existing tests. Combining them does not supply the missing methodological contribution.

The defensible remaining research question would be: **can a precondition-aware generator and reducer expose real cache state-transition violations, with fewer false positives and materially greater unique-bug yield than existing tests and ordinary differential/property-based testing?** That would require a demonstrated testing method, rather than a new name for the current manual audits. It is a conditional software-engineering research possibility, not a selected project or publication promise. “SCI” is an indexing category, not an acceptance standard or evidence threshold.

The current record does **not** contain three independently reproduced, as-yet-unreported released-implementation failures. The strongest current item is the HYPIC cold-seam tuple defect, established by the project's source audit and executed metadata fixture, but not by executing its serving kernels or demonstrating answer-quality loss. Other items have materially different statuses. Keep their audit value; do not turn the stopped P3 metadata framework into this project under a different title.

## 1. Closest work and what it removes from the novelty claim

The following are primary-source findings, not independent reproductions of the papers' reported results. Preprints are identified as such; their public existence matters for novelty even where their experiments remain unverified.

| Work | Relevant overlap | Consequence for this proposal |
|---|---|---|
| [WitProbe, *Runtime Observability for Heterogeneous Attention Memory*, Aug 2026, v2 Aug 16](https://arxiv.org/abs/2608.05863v2) | Contracts across KV, latent cache, sparse selection, and recurrence; metric-typed composition, evidence tiers, and a served-cache diagnostic case. Its latest version also studies generation/slot-reuse correctness. Architecture-specific injection code is excluded from the released artifact | A unified contract layer, evidence labels, or state-staleness case study cannot be our principal claimed novelty. An independently executable cross-implementation test-generation method would still need a clear algorithmic and empirical difference |
| [WitCert, July–Aug 2026 preprint](https://arxiv.org/abs/2607.28699v3) | Runtime local attention-distribution bounds for cache-preserving quantizers, with deterministic and explicitly qualified probabilistic tiers | Do not rebrand approximation bounds or runtime gating as a fresh correctness oracle. Local certification does not imply end-to-end model correctness |
| [Runtime-Certified Bounded-Error Quantized Attention, May 2026 preprint](https://arxiv.org/abs/2605.20868) | Per-head/per-step error decomposition with exact-reference fallback | Another direct obstacle to a generic bounded-approximation/fallback framing |
| [GRIEF, May 2026 preprint](https://arxiv.org/abs/2605.11202) | Timed multi-request trace fuzzing of serving systems, behavioral/structural/relational oracles, and controlled logprob-assisted replay; reports developer-confirmed cache-isolation and other failures | A trace fuzzer with cache events and relational checks is already a concrete research method. Our possible difference must concern model-free, semantically constrained component-state generation and its measured additional yield |
| [Ekka, June 2026 preprint](https://arxiv.org/abs/2606.04594) | Cross-framework component mapping and intermediate-state differential diagnosis with precision-aware comparison, evaluated on real serving errors | “Compare intermediate activations and localize a mismatch” is insufficient. Unlike Ekka's model/reference-driven diagnosis, a proposed generator would need to derive valid counterexamples before loading a model and establish their released-source reachability |
| [A First Look at Bugs in LLM Inference Engines, 2025 preprint / 2026 TOSEM article](https://doi.org/10.1145/3788873) | A 929-bug, five-engine empirical study with symptom/root-cause taxonomy | A small bug catalogue is not a comparable contribution. A focused study needs a new explanatory result or a new detection method, not just another taxonomy |
| [DESIL, OOPSLA 2025](https://2025.splashcon.org/details/OOPSLA/184/DESIL-Detecting-Silent-Bugs-in-MLIR-Compiler-Infrastructure) and [XCheck, June 2026 preprint](https://arxiv.org/abs/2606.18421) | Documentation-derived validity constraints, executable differential tests, and cross-layer assumption/behavior analysis | Preconditions and legal-input generation are established testing ideas. The cache-specific challenge must be solved concretely and shown to matter |
| [Geodesia-KV, Aug 2026 preprint](https://arxiv.org/abs/2608.23599) | Separates resident storage from read traffic; explicitly treats chunked-teacher-forcing confounds and Q=1 evaluation; includes causal/GQA regression checks | Accounting distinctions and incremental-evaluation controls are necessary experimental hygiene, not a stand-alone fresh contribution. Its semantic ports are not official-kernel reproductions |
| [Stage-Replay Divergence Follows the KV Cache, July 2026 preprint](https://arxiv.org/abs/2607.28495) | Fixed-token cache construction comparisons, precision controls, and bidirectional cache transplantation | Token-identical replay need not be bit-identical live-state replay. Neither a greedy-token mismatch nor a cache donor experiment is automatically a new oracle or a software bug |
| [Leyline, May 2026 preprint](https://arxiv.org/abs/2606.01065) | Explicit separation of position-correct cache splicing from prefix-trimmed recomputation for semantic forgetting | Position correctness must not be mistaken for full-network equivalence after a context edit |
| [HeadQ, withdrawn May 19, 2026](https://arxiv.org/abs/2605.03562) | Publicly describes score-space constant-shift equivalence | A conceptual-overlap warning only. Do not rely on its experimental numbers, treat it as validated evidence, or claim the elementary softmax identity is novel |

Broader MT work, such as [LLMORPH (ASE 2025)](https://valerio-terragni.github.io/assets/pdf/cho-ase-2025.pdf), further rules out novelty based on applying metamorphic relations to LLMs in general. Its NLP-level subject differs from inference-state semantics; that difference alone is still not a method.

## 2. Existing implementations already contain substantial contracts

Inspected Transformers commit: `02d8fb9784e8f14a1251e4c992cd82a5762417c6` (Oct 2, 2026). Its [cache tests](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/tests/utils/test_cache_utils.py) include:

- Fresh-versus-reset-cache behavioral equivalence, not only length assertions
- Batched/left-padding/cache-type checks and sliding/hybrid cache update tests
- Crop restoration of KV, convolution, and indexer state with history recording
- Agreement between advertised mask width and returned KV width, including a multi-token update crossing a sliding-window boundary

Inspected vLLM commit: `4ac0d0eac25eecc98ff519887f2aa3d659dc75f3` (Oct 3, 2026). Its [CPU linear-attention tests](https://github.com/vllm-project/vllm/blob/4ac0d0eac25eecc98ff519887f2aa3d659dc75f3/tests/v1/e2e/test_cpu_linear_attn_chunked_prefix.py) compare full and chunked prefill, plus warm and cold prefix caching, on Qwen3.5-0.8B. The warm test asserts a cache hit so the comparison cannot pass vacuously. These are CPU model tests, **not model-free tests**. Its [ReplaySSM tests](https://github.com/vllm-project/vllm/blob/4ac0d0eac25eecc98ff519887f2aa3d659dc75f3/tests/v1/e2e/test_replayssm_decode.py) explicitly use logprob comparisons because floating-point near-ties can change greedy IDs. Its [core prefix-cache suite](https://github.com/vllm-project/vllm/blob/4ac0d0eac25eecc98ff519887f2aa3d659dc75f3/tests/v1/core/test_prefix_caching.py) includes hybrid/speculative boundaries, eviction, ownership, and reuse cases.

These observations do not prove complete coverage. They do mean that a new paper must compare against existing tests and their principles, not against an imagined crash-only baseline. CPU execution alone is not a novelty boundary.

## 3. What a sound oracle would have to distinguish

There should be **one declared semantic reference per comparison**, not a universal equality requirement imposed on every approximation.

### Exact state-transition refinement

For a supposedly exact optimization, compare the same accepted token/input trace, attention semantics, position convention, recurrence inputs, and policy-event order. Compare observable readouts and a canonical logical-state projection; physical tensor layout and allocation addresses may legitimately differ. Require execution counters or source-path evidence that the optimized branch actually ran.

Serial-versus-block execution is exact in mathematical arithmetic only when the relevant update/read ordering is equivalent. A lossy policy that evicts every N committed inputs need not equal one that evicts only after a verification block. Rollback includes every state component that influences later reads, not just tensor length. These are semantic requirements, not a proposal to revive the earlier transaction/metadata project.

### Conditional algebraic relations

- **Split/join for recurrence:** compose affine tuples only for the same fixed sequence of recurrence coefficients and updates. Deeper-layer inputs generally change when a segment is computed under a different prefix. The valid tuple identity does not establish isolated-segment/full-network equality
- **Position relocation:** preserve the whole supported position-dependent transformation, original visibility predicate, and any fixed anchors. Rephasing keys corrects rotary coordinates, not context-dependent deeper K/V. Dynamic RoPE frequency epochs must also match
- **Common-key translation:** the dense attention relation applies after RoPE, to every key visible to each tested query, with an unchanged mask. A scorer's retained-set change is not automatically an implementation bug: an approximate policy is allowed to use representation-dependent information unless its stated semantics forbid that dependence. Existing A results diagnose non-invariance; they do not prove quality harm or a universal correctness violation
- **Sparse/window masks:** test mask-set equality separately from retained-token choice. Keeping a distant sink and allowing it attention is a changed operator if the reference is trained sliding-window attention; it can also be an explicitly intended approximate policy. Name which claim is being tested

### Approximation and numerical effects

If selection is approximate, compare it to its declared policy/reference, and bound or measure its allowed change separately from implementation error. For fixed exact logits and values, deleting attention mass `m` and renormalizing leaves a readout deviation at most `2 m Vmax` when all value norms are bounded by `Vmax`. This elementary local bound does not survive arbitrary changed logits, changed values, later layers, or a different selector score without additional bridges. It is not a new theorem.

In floating point, compare against same-path repeat controls and high-precision/component references. Use prespecified numerical tolerances and near-tie handling; do not enlarge tolerances after observing failures. End-to-end greedy disagreement alone is not proof of a bug. Conversely, a logically duplicated segment, invalid ownership transition, or wrong visibility set cannot be excused by a floating-point tolerance.

## 4. Fake-key masking: a useful known feasibility distinction, not a research method

The current [KVpress source](https://github.com/NVIDIA/kvpress/blob/a13a1da31ab2b92671d9e26994d5bdbd69d9bd61/kvpress/attention_patch.py) groups all query heads and query positions sharing one KV head, then seeks one fake key for that group. It accepts a direction only when every query has strictly positive dot product with that direction, and negates/scales it. Its `ValueError` path explicitly admits search failure.

For query rows `Q`, a common fake key with all `Qk < 0` exists exactly when there is no nonzero `lambda >= 0` with `Q.T lambda = 0`. This is the classical strict theorem of alternatives (equivalently, the origin is outside the convex hull of the finite query set), not new mathematics. [Boyd and Vandenberghe, Example 2.21](https://www.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf) supplies the standard alternative. The pair `q, -q` has certificate `lambda=(1,1)` and is infeasible; increasing the iteration cap cannot fix it. Longer groups add constraints but do not by themselves prove infeasibility or failure prevalence on natural model states.

A better diagnostic specification separates three cases: infeasible geometry, feasible geometry with search failure, and a returned key whose finite-precision masking is inadequate. A floating-point LP residual is not itself an exact certificate without an appropriate residual/error argument.

The probability target is also stronger than “negative logits.” If a query sees `M` identical fake keys, unmasked exponential sum `Z`, and fake logit `a`, its total masked probability is `M exp(a)/(Z + M exp(a))`. Requiring this to be at most `epsilon` gives the explicit relative constraint `a <= log Z + log(epsilon/(1-epsilon)) - log M`. Add actual dtype representability and post-cast checks. Absolute exponent underflow before stable-softmax normalization is not a universal proof of zero masked probability.

This review derives that comparison on paper only. It does not execute a solver or rerun KVpress. Explicit additive masking or physical removal is the obvious correctness control. A standard feasibility check and fallback are engineering, unless a separate substantial method/result emerges.

Important upstream distinction: FP16 overflow was already reported in [#250](https://github.com/NVIDIA/kvpress/issues/250) and [#268](https://github.com/NVIDIA/kvpress/issues/268), and fixed by merged [#283](https://github.com/NVIDIA/kvpress/pull/283) on **2026-09-17**. The earlier unmerged [#281](https://github.com/NVIDIA/kvpress/pull/281) already discusses small separation margins and dtype-sensitive masking. Do not count those as new discoveries. General infeasibility is distinct from overflow, but the current function's documented rejection weakens the claim that infeasible input constitutes a silent bug.

## 5. Evidence inventory and issue-search result

| Item | Established evidence | Why it cannot currently count as a completed new research failure |
|---|---|---|
| HYPIC cold-seam tuple double application | Existing [independent source review](hypic_baseline_source_review.md), pinned source, executed metadata fixture, and mathematical witness | Strong source-level defect. No serving-kernel or answer-quality reproduction. The all-state public issue/PR collection had no matching recompute-seam report; that bounded result is not proof of global first discovery |
| KVpress fake-key geometry | Current source plus exact `q,-q` infeasibility argument | Search failure is documented; natural-state reachability and user-facing contract violation are unestablished. Related finite-precision failures and margin work are public |
| KVLens local-mask bypass under explicit retained positions | Current [attention source](https://github.com/gcgarriga/KVLens/blob/7fe02f8220275e19323379562c8873c2c09e0108/src/kvlens/attention.py#L80-L108) and the existing hand witness | A genuine comparison confound relative to unchanged local attention, but the code comments intentionally preserve sinks. Need to distinguish intended approximation from violation; no corrected-model attribution run |
| Shared-prefix stale-parent/storage audit | Existing project allocator/ownership experiments and corrected accounting | Our audit/model evidence, not an established newly discovered bug in a released serving implementation; resident/read separation already has direct recent coverage |
| Speculative metadata rollback toy | Existing exact-state simulator and serial/boundary controls | Deliberately unsafe toy strategies, not a released implementation failure. R-KV explicitly rejects the unsupported speculative path |
| R-KV score gauge sensitivity | Existing A factorial/counterexamples | Representation sensitivity rather than a proven correctness obligation, and simple controls close it; source already notes softmax-before-head reduction |

Searches on Oct 3 covered the complete returned HYPIC issue/PR collection (items 1–10), the returned KVLens collection (items 1–12), and KVpress keyword searches for hyperplane, fake/query, and mask/window, plus related PRs. No exact HYPIC recompute-seam report appeared. KVLens [#7](https://github.com/gcgarriga/KVLens/issues/7) and [#8](https://github.com/gcgarriga/KVLens/issues/8) already identify the unresolved causal interpretation of sparse-position behavior, although the inspected text does not explicitly identify this mask branch. KVpress has the public reports above. Forks, unpublished work, every discussion comment, and all historic branches were not exhausted. Use “no matching report found in this search,” never “previously unreported” as a proven fact.

For HYPIC's separate Table 4 issue, [comment 5506131951](https://github.com/redai-studio/HYPIC/issues/10#issuecomment-5506131951) was created and last updated **2026-09-02 07:35:27 UTC**, by `NephrenCake` with repository association **COLLABORATOR**. September 10 is the issue closure date, not the comment date. The comment corrects the layer aggregation and input protocol; this is already-public reporting evidence, not the cold-seam defect and not our new finding.

**Count at the required full evidence bar: fewer than three.** Do not count three differently labeled demonstrations as three independently established released-implementation failures.

## 6. Minimum evidence needed to reconsider, and kill criteria

These are project admission criteria, not journal rules. No implementation phase is authorized or recommended by this report.

Reconsider only if all of the following can be specified and then demonstrated:

1. **A distinct methodological core.** For example, executable preconditions that generate and reduce *legal* state-transition traces, with source-path witnesses and sound classification of semantic versus permitted approximate differences. Mere wrappers, a checklist, naming conventions, or existing inequalities do not qualify
2. **At least three independent source-backed failures across more than one released implementation**, each exercised in the real relevant code path and still absent from a documented issue/PR/history search. No multiplication of one root cause across dtypes, no toy-only bugs, and no conversion of documented unsupported inputs into silent failures. Maintainer confirmation would strengthen a later study, but contacting maintainers requires separate authorization
3. **Incremental discovery evidence.** Compare existing project tests, unguided legal-input/property testing, ordinary serial/differential controls, and the proposed method under matched budgets. Report unique root causes, validity rate, false positives, reduction quality, and time to first real failure. Historical bugs can measure recall, not new-discovery count
4. **Out-of-sample generalization.** Hold out an implementation or failure family while designing relations. If every relation is written after manually discovering its example, the study demonstrates regression coverage rather than discovery
5. **A legitimate reachability bridge.** Model-free witnesses must satisfy actual API/source invariants. A small CPU source-path reproduction can establish implementation correctness failures without showing model quality. If claiming quality or serving performance, it needs the corresponding natural-model or system evidence later

Kill the main-paper direction if the candidate set remains HYPIC plus documented fake-key rejection plus an intentionally changed sparse mask; if ordinary existing invariants find the same cases at similar cost; if the apparent failures vanish with legal-input/mask/position/precision controls; if testing needs handwritten per-bug adapters that do not generalize; or if the novelty pitch is primarily “all cache types in one framework.” Three bugs alone would still not rescue an absent method.

**Present stopping decision:** retain a focused reproducibility/correctness audit as a useful engineering deliverable. Do not invest in a new framework, model downloads, or GPUs merely to seek enough bugs to justify a paper. The current evidence supports a no-go on this as the main research direction, while leaving open a genuinely different, independently motivated testing contribution.
