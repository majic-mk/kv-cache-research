# Predeclared pooled-full versus regional oracle control

Date: 2026-10-03 UTC. Declaration precedes any pretrained-model or GPU result.
This is a diagnostic-control implementation, **not a novel compression method**.
No regional improvement, useful benefit, memory saving, or speedup is established.
The audit motivating it is [calibration_novelty_followup.md](calibration_novelty_followup.md).

## Version and immutable historical boundary

New screen/archive schema: `echo_calibration_experiment_v2`. The same module
entrypoint now freezes v2 and rejects v1 input rather than silently relabeling it.
New safe dry-run/test records live in `diagnostics/calibration_experiment_v2/`.
Generated private token-bearing plans are ignored by Git and never replace v1.

The historical eight-arm source is commit
`c96b250f40fb484077a7761c338e49300189f529`. Preserve these original v1 plan hashes:

- LCC: `24e7eb3b775bd1818dda9691aa58708652b2cbf3185f280cb655244baa7214d5`
- RepoBench-P: `428fde5ddeb49be1cb1fb558bc4cdf3c3d02e3971f282205cd58356e638ec7ee`

V2 embeds those predecessor identities, its complete diagnostic protocol, new
arm inventory and updated work counts in its canonical plan hash. Runtime and
analysis source hashes remain separately validated. Historical v1 dry-run and
validation records are not rewritten. Reconstructing v1 by removing only the
new protocol/provenance fields, ninth arm and extra query work must reproduce
the original hashes; tests enforce this, along with explicit v1 rejection.

## Frozen estimand and construction

The diagnostic question is whether region-dependent marginal transport changes
downstream quality relative to a pooled map given the **same full exact labels**.
It does not identify whether sparse anchors could estimate that transport.

- Keep the original three development contexts, model/revision, single seed,
  50% eviction, first/uniform/random four-by-496-token anchors plus each replay's
  16 prompt/suffix tokens, float32 captured scalar/container path and selection
  policy. No gold labels enter scoring; they enter offline quality analysis only
- Use the identical captured virtual vector `v`, exact diagnostic vector `e`,
  and first-anchor baseline `b` for both full-label maps. Original microchunk
  scoring, denominator key sets, full-cache conditioning, prompt IDs, RoPE offsets
  and backend do not change. Pooling scalar labels is **not** long-context replay
- Fixed set `F` is prefix union first anchors union sinks union recent positions.
  The current screen has four sinks and zero recent tokens. Mutable set `U` is
  its complement. Exclude `F` **before fitting**, never fit then overwrite
- `pooled_full_map_oracle` (P): initialize from `b`, fit one map per layer/head
  from independently sorted `v[U]` and `e[U]`, evaluate it on `v[U]`, and preserve
  `b[F]`. `scale_map_oracle` (R) fits the same map separately on `U ∩ region`.
  Regions are positional microchunks, not content or semantic classes
- Both maps use the same declared `author_left` interpolation, endpoint clipping,
  float32 arithmetic and `1e-12` denominator floor, with shared exact-input and
  output casts. No candidate-specific precision or exact-rank tie splitting
- Both use the same logical pair budget/protection and independent clones of
  the first build's pristine dense cache. The ninth arm installs its saved mask
  directly; it never enters the deployable anchor API or triggers rescoring

## Mandatory invariant and identifiability checks

Implementation defects fail the operation/archive: partition or shapes disagree,
nonfinite output, sparse/full captures or anchors disagree, fixed values change,
within-region virtual weak order/equal-source equality is violated, the pooled
map fails global mutable monotonicity, protection is lost, or retained counts
disagree. Singleton mutable regions remain rejected. An empty mutable set cannot
provide a meaningful regional comparison and is flagged as such.

Per layer/head, compare the **actual sorted outputs** P[U], R[U] and consistently
output-cast target e[U] with exact array equality. Distinct knots are insufficient:
the denominator floor and finite arithmetic may prevent exact marginal transport.
Record equality separately, mismatch counts/magnitudes, source duplicate knots,
exact/output tie counts, clipping/support counts, and each mutable-region size.

Preserve per-layer/head/region allocations, cutoff multiplicities and existing
region retained-count bounds. Explicit per-head cutoff allocation bounds identify
ties that permit head budgets to change, even if stable selection happens to
choose equal budgets. Cutoff ties confined to one layer/head can still swap
tokens within a region while preserving all region budgets. They also confound
pure allocation attribution; weak-order preservation alone is insufficient. Compare
stable, reverse and seeded-random tie selection using the frozen seed 20261003;
these are score/mask sensitivities, **not extra downstream evaluations**.

Flag `pure_regional_contrast_interpretable=false` if actual pooled/regional/target
multiset equality fails, head budgets differ, **either pooled or regional cutoff
has ambiguous membership** (even within a single head), or no mutable contrast
exists. Ties away from the cutoff do not by themselves fail this gate. Do not reject such valid diagnostic
data, loosen equality after seeing results, use allclose as proof, or import exact
ranks to repair ties. A different tie-aware construction requires a new protocol.
An adversarial CPU regression fixes a concrete counterexample: equal P/R/exact
multisets and equal per-region retained counts can coexist with different token
membership inside a region. This motivates the conservative untied-cutoff gate;
no model outcome was used to choose it.

## Quality reporting and stopping interpretation

The declared downstream contrast is question-paired quality(R) minus quality(P).
Report every arm against first/full KV/pooled-full and retain **all** frozen
questions/context clusters, including confounded cells. Carry each context's
recomputed attribution checks into offline output and mark the cohort contrast
confounded if any context fails. Never cherry-pick a clean subset. The raw delta
remains descriptive in that case; it is not a clean regional-mechanism estimate.

Use the existing paired context-cluster bootstrap with shared draws. LCC's two
clusters are exploratory; RepoBench-P's one cluster has no interval. No positive
signal, power, equivalence, generality or useful benefit follows from this screen.
Even a clean positive R−P contrast identifies an oracle allocation intervention,
not content causality, sparse estimability, a deployable method or novelty. Full
exact is a score reference, not a downstream upper bound; scale/rank deltas are
not an additive decomposition. Recency, fixed exact-replacement placement,
natural-context replication and strong released baselines remain later controls.

## Work and authorization boundary

Reuse the already charged full exact capture and all existing scoring builds.
No additional scoring, prefill, replay, weight loading or tokenization is needed
for P. Additional work is its CPU transform/audit/serialization plus one separate
mask installation, cache clone and generation per question:

- LCC: scoring builds 8; prefill tokens 42,232; sparse replays 24 / 12,288 tokens;
  full diagnostic replays 22 / 10,904 tokens; query clones **18**; query input
  tokens **252**; maximum generated tokens **1,152**
- RepoBench-P: scoring builds 4; prefill tokens 23,060; sparse replays 12 / 6,144
  tokens; full diagnostic replays 12 / 5,954 tokens; query clones **9**; query
  input tokens **4,032**; maximum generated tokens **576**

Counts are planned work, not measured time/FLOPs/money. Each invocation has one
model load, as before. Shared oracle costs are never represented as deployable
build cost or a free performance result. The masks retain dense physical KV
storage. The present work is CPU-only, without GPU, checkpoints, installations,
rentals, paid resources, commits or pushes. This protocol grants none of them.
