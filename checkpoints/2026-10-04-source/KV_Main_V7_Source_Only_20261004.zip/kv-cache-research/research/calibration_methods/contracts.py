"""Frozen score/partition contracts. Metadata checks do not prove scorer honesty."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import re

import numpy as np

from research.diagnostics.echo_calibration.reference import Chunk, reconstruction_ledger


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, name, minimum=0):
    require(type(value) is int and value >= minimum, f"{name} must be an integer >= {minimum}")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def score_array(value, name):
    a = np.array(value, dtype=np.float32, copy=True)
    require(a.ndim == 3 and min(a.shape) > 0, f"{name} needs nonempty [layers, heads, tokens]")
    require(bool(np.isfinite(a).all()), f"{name} must be finite after float32 conversion")
    a.setflags(write=False)
    return a


@dataclass(frozen=True)
class Microchunk:
    start: int
    end: int
    prompt_tokens: int

    def __post_init__(self):
        for key in ("start", "end", "prompt_tokens"):
            integer(getattr(self, key), key)
        require(self.end > self.start, "Microchunks must be nonempty")

    @property
    def shape(self):
        return (self.end - self.start, self.prompt_tokens)


@dataclass(frozen=True)
class Partition:
    """A common, immutable scoring plan, fixed BEFORE observing any outcomes.

    Virtual original-key denominator uses sinks union the *complete* microchunk;
    the virtual-copy term is causal within that microchunk. Exact replay uses the
    same original-key denominator, plus its causal repeated prompt/chunk keys.
    Exact replay hidden states still attend the full original cache. Changing an
    anchor set NEVER changes these boundaries or this denominator convention.

    Region IDs come only from fixed positions, context metadata or prefill-only
    features. Prefix tokens use region -1. A context hash must be from context
    tokens alone; query/gold fields have no place in this strict constructor.
    """
    context_sha256: str
    token_count: int
    prefix_length: int
    chunks: tuple[Microchunk, ...]
    region_ids: tuple[int, ...]
    region_source: str
    sink_tokens: int = 4
    prompt_convention: str = "common_context_only_replay_v1"
    denominator: str = "sinks_union_fixed_chunk_plus_causal_repeat_v1"

    def __post_init__(self):
        require(isinstance(self.context_sha256, str) and bool(re.fullmatch(r"[0-9a-f]{64}", self.context_sha256)),
                "context_sha256 must be a lowercase SHA-256")
        integer(self.token_count, "token_count", 1)
        integer(self.prefix_length, "prefix_length")
        integer(self.sink_tokens, "sink_tokens")
        require(self.prefix_length < self.token_count and self.sink_tokens <= self.token_count,
                "Invalid prefix or sink length")
        require(type(self.chunks) is tuple and self.chunks and all(type(c) is Microchunk for c in self.chunks),
                "chunks must be a nonempty immutable tuple of Microchunk")
        cursor = self.prefix_length
        for chunk in self.chunks:
            require(chunk.start == cursor, "Microchunks must cover the body once without gaps/overlaps")
            cursor = chunk.end
        require(cursor == self.token_count, "Microchunks must end at token_count")
        require(type(self.region_ids) is tuple and len(self.region_ids) == self.token_count and
                all(type(r) is int for r in self.region_ids), "region_ids must be one immutable integer per token")
        require(all(r == -1 for r in self.region_ids[:self.prefix_length]) and
                all(r >= 0 for r in self.region_ids[self.prefix_length:]), "Only prefix region IDs may be -1")
        require(self.region_source in ("fixed_position", "context_metadata", "prefill_only"),
                "Regions must not use queries, gold labels or downstream outcomes")
        require(self.prompt_convention == "common_context_only_replay_v1", "Unsupported prompt convention")
        require(self.denominator == "sinks_union_fixed_chunk_plus_causal_repeat_v1", "Unsupported denominator")

    @property
    def fingerprint(self):
        return digest(asdict(self))

    def denominator_original_keys(self, chunk_id):
        """Explicit original-key set for a future runtime adapter (deduplicated)."""
        integer(chunk_id, "chunk_id")
        require(chunk_id < len(self.chunks), "Unknown chunk_id")
        c = self.chunks[chunk_id]
        return tuple(sorted(set(range(min(self.sink_tokens, c.start))) | set(range(c.start, c.end))))


@dataclass(frozen=True)
class AnchorPlan:
    partition: Partition
    chunk_ids: tuple[int, ...]
    policy: str
    seed: int

    def __post_init__(self):
        require(type(self.partition) is Partition, "An explicit Partition is required")
        integer(self.seed, "seed")
        require(self.policy in ("first", "random", "uniform"), "Unsupported anchor policy")
        require(type(self.chunk_ids) is tuple and self.chunk_ids and
                all(type(i) is int and 0 <= i < len(self.partition.chunks) for i in self.chunk_ids),
                "Invalid anchor chunk IDs")
        require(tuple(sorted(set(self.chunk_ids))) == self.chunk_ids, "Anchor IDs must be sorted and unique")
        require(len({self.partition.chunks[i].shape for i in self.chunk_ids}) == 1,
                "All anchor replays must have the same complete input shape")

    @property
    def token_indices(self):
        return tuple(t for i in self.chunk_ids for t in range(self.partition.chunks[i].start,
                                                             self.partition.chunks[i].end))

    @property
    def fingerprint(self):
        return digest({"partition": self.partition.fingerprint, "chunk_ids": self.chunk_ids,
                       "policy": self.policy, "seed": self.seed})

    def cost(self):
        chunks = [Chunk(c.start, c.end, c.prompt_tokens) for i in self.chunk_ids
                  for c in [self.partition.chunks[i]]]
        return reconstruction_ledger(chunks, self.partition.token_count)


@dataclass(frozen=True)
class VirtualScores:
    partition: Partition
    values: np.ndarray

    def __post_init__(self):
        require(type(self.partition) is Partition, "An explicit Partition is required")
        a = score_array(self.values, "virtual scores")
        require(a.shape[-1] == self.partition.token_count, "Virtual scores must cover the fixed context")
        object.__setattr__(self, "values", a)


@dataclass(frozen=True)
class AnchorObservations:
    """Only paid-for exact anchor labels, in plan.token_indices order.

    Deliberately rejects a full-context exact-score tensor by its token dimension.
    There is no API argument for downstream questions, answers or outcomes.
    Source/process provenance remains the caller's responsibility.
    """
    plan: AnchorPlan
    values: np.ndarray

    def __post_init__(self):
        require(type(self.plan) is AnchorPlan, "An AnchorPlan is required")
        a = score_array(self.values, "anchor observations")
        require(a.shape[-1] == len(self.plan.token_indices), "Pass ONLY the selected exact anchor scores")
        object.__setattr__(self, "values", a)
