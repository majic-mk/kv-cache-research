"""Reproducible constructed controls; prints JSON and never starts model code."""
from __future__ import annotations

import json
import numpy as np

from .contracts import AnchorObservations, Microchunk, Partition, VirtualScores, digest
from .diagnostics import FullExactDiagnostic, compare_oracles
from .methods import Precision, assert_equal_budget, calibrate, plan_anchors
from .selection import select_logical


def fixture_partition(n=32, width=4):
    return Partition(digest({"synthetic_tokens": list(range(n))}), n, 0,
                     tuple(Microchunk(i, min(i + width, n), 3) for i in range(0, n, width)),
                     tuple(i // 4 for i in range(n)), "fixed_position", sink_tokens=0)


def run():
    p = fixture_partition()
    plans = [plan_anchors(p, 2, policy, 17) for policy in ("first", "random", "uniform")]
    cost = assert_equal_budget(plans)
    v = VirtualScores(p, np.tile(np.array([.01, .02, .03, .04], dtype=np.float32), (1, 2, 8)))
    # Synthetic-only data producer slices full labels. Production observes only selected replays.
    exact_values = v.values * np.repeat(np.array([1, 1, 2, 2, 3, 3, 4, 4]), 4)
    controls = {}
    for plan in plans:
        observations = AnchorObservations(plan, exact_values[..., list(plan.token_indices)])
        method = calibrate(v, observations)
        _, selected = select_logical(method.scores, p, .5, recent_tokens=2)
        controls[plan.policy] = {"chunk_ids": list(plan.chunk_ids), "plan": method.diagnostics,
                                 "selection": selected}
    p = fixture_partition(12)
    v = VirtualScores(p, np.tile([.01, .02, .03, .04], (1, 1, 3)))
    plan = plan_anchors(p, 1, "first")
    scale_shift = v.values * [1, 1, 1, 1, 10, 10, 10, 10, 1, 1, 1, 1]
    rank_failure = v.values.copy()
    rank_failure[..., 4:8] = rank_failure[..., 4:8][..., ::-1]
    cases = {}
    for name, exact in (("constructed_regional_scale_shift", scale_shift),
                        ("constructed_within_region_rank_failure", rank_failure)):
        base = calibrate(v, AnchorObservations(plan, exact[..., list(plan.token_indices)]))
        cases[name] = compare_oracles(v, base, FullExactDiagnostic(p, exact), .5)
    return {"evidence_class": "synthetic_cpu_only", "gpu_used": False, "model_loaded": False,
            "weights_downloaded": False, "model_quality_claim": False, "novelty_claim": False,
            "equal_shape_budget_proxy": cost, "anchor_controls": controls, "oracle_cases": cases,
            "precision_controls": {"float32": Precision().__dict__,
                                   "author_storage_like_bf16": Precision.author_storage_like().__dict__}}


def main():
    print(json.dumps(run(), indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
