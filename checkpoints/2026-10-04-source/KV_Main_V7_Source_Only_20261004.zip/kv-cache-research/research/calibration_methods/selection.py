"""Fixed-budget logical selection with explicit protection and cutoff-tie audits."""
from __future__ import annotations

import math
import numpy as np

from .contracts import Partition, integer, require, score_array


def protection_mask(partition, recent_tokens=0):
    require(type(partition) is Partition, "An explicit Partition is required")
    integer(recent_tokens, "recent_tokens")
    require(recent_tokens <= partition.token_count, "recent_tokens exceeds context length")
    protected = np.zeros(partition.token_count, dtype=bool)
    protected[:partition.sink_tokens] = True
    if recent_tokens:
        protected[-recent_tokens:] = True
    return protected


def select_logical(scores, partition: Partition, eviction_ratio, *, recent_tokens=0,
                   tie_break="stable", seed=0):
    """Author floor(N*r) budget; protection consumes that SAME budget.

    Protected pairs are removed from competition rather than using max+1, which
    avoids promotion overflow/rounding. Stable/reverse/random tie policies are
    sensitivity controls; none is claimed identical to torch.topk. No physical
    cache is created, compacted or freed.
    """
    s = score_array(scores, "selection scores")
    require(s.shape[-1] == partition.token_count, "Selection context length differs")
    require(type(eviction_ratio) in (float, int) and math.isfinite(eviction_ratio) and
            0 <= eviction_ratio < 1, "eviction_ratio must be finite in [0,1)")
    require(tie_break in ("stable", "reverse", "random"), "Unsupported selection tie policy")
    integer(seed, "seed")
    protected = np.broadcast_to(protection_mask(partition, recent_tokens), s.shape)
    n_pruned = math.floor(s.size * eviction_ratio)
    require(s.size - n_pruned >= int(protected.sum()), "Retained budget cannot preserve sink/recent union")
    candidates = np.flatnonzero(~protected.reshape(-1))
    if tie_break == "stable":
        secondary = candidates
    elif tie_break == "reverse":
        secondary = -candidates
    else:
        secondary = np.random.default_rng(seed).permutation(len(candidates))
    order = np.lexsort((secondary, s.reshape(-1)[candidates]))
    removed = candidates[order[:n_pruned]]
    keep = np.ones(s.size, dtype=bool)
    keep[removed] = False
    keep = keep.reshape(s.shape)
    cutoff = None
    if n_pruned:
        value = s.reshape(-1)[removed].max()
        equal = (s == value) & ~protected
        cutoff = {"value": float(value), "unprotected_equal_count": int(equal.sum()),
                  "equal_retained": int((equal & keep).sum()), "equal_pruned": int((equal & ~keep).sum()),
                  "ambiguous_membership": bool((equal & keep).any() and (equal & ~keep).any())}
    regions = np.asarray(partition.region_ids)
    by_region, tie_bounds = {}, {}
    for region in np.unique(regions):
        region_mask = np.broadcast_to(regions == region, s.shape)
        by_region[str(region)] = {"retained": int((keep & region_mask).sum()),
                                  "per_layer_head": keep[..., regions == region].sum(-1).tolist()}
        if cutoff:
            region_tied = int((equal & region_mask).sum())
            total_tied, n_tied_kept = cutoff["unprotected_equal_count"], cutoff["equal_retained"]
            fixed = int((keep & region_mask & ~equal).sum())
            tie_bounds[str(region)] = {"minimum_retained": fixed + max(0, n_tied_kept - (total_tied - region_tied)),
                                       "maximum_retained": fixed + min(region_tied, n_tied_kept)}
    report = {"total_pairs": s.size, "retained_pairs": int(keep.sum()), "pruned_pairs": n_pruned,
              "protected_pairs": int(protected.sum()), "sink_tokens": partition.sink_tokens,
              "recent_tokens": recent_tokens, "cutoff_ties": cutoff, "tie_break": tie_break,
              "tie_seed": seed, "retained_per_layer_head": keep.sum(-1).tolist(),
              "by_region": by_region, "cutoff_tie_region_bounds": tie_bounds,
              "physical_memory_measured": False}
    keep.setflags(write=False)
    return keep, report
