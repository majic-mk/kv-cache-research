"""ORACLE ONLY: full exact reconstruction labels, never deployable anchor policy.

FullExactDiagnostic must be kept outside policy construction and tuning on heldout
data. Exact reconstruction is a score reference, NOT downstream/gold importance.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import numpy as np

from .contracts import Partition, VirtualScores, require, score_array
from .methods import CalibrationResult, controlled_map, round_storage
from .selection import protection_mask, select_logical


@dataclass(frozen=True)
class FullExactDiagnostic:
    partition: Partition
    values: np.ndarray

    def __post_init__(self):
        require(type(self.partition) is Partition, "An explicit Partition is required")
        a = score_array(self.values, "diagnostic-only exact scores")
        require(a.shape[-1] == self.partition.token_count, "Oracle needs the full frozen context")
        object.__setattr__(self, "values", a)


def _tie_counts(values):
    """Exact equality after the named cast; all arrays are [layer, head]."""
    n = values.shape[-1]
    rows = values.reshape(values.shape[0] * values.shape[1], n)
    counts = [np.unique(row, return_counts=True)[1] for row in rows]
    def shaped(items):
        return np.asarray(list(items), dtype=np.int64).reshape(values.shape[:2]).tolist()
    return {"duplicate_count": shaped(n - len(c) for c in counts),
            "tied_group_count": shaped(int((c > 1).sum()) for c in counts),
            "positions_in_ties": shaped(int(c[c > 1].sum()) for c in counts),
            "maximum_multiplicity": shaped(int(c.max(initial=0)) for c in counts)}


def _order_checks(source, output, label):
    """Fail real ordering defects; never split an equal source knot by exact rank."""
    order = np.argsort(source, axis=-1, kind="stable")
    x = np.take_along_axis(source, order, axis=-1)
    y = np.take_along_axis(output, order, axis=-1)
    monotone = (y[..., 1:] >= y[..., :-1]).all(-1)
    equal_ties = ((x[..., 1:] != x[..., :-1]) | (y[..., 1:] == y[..., :-1])).all(-1)
    require(bool(monotone.all()), f"{label} reversed virtual weak order; implementation defect")
    require(bool(equal_ties.all()), f"{label} split equal source ties; implementation defect")
    return {"weak_order_preserved_per_layer_head": monotone.tolist(),
            "equal_source_ties_preserved_per_layer_head": equal_ties.tolist()}


def _multiset_check(left, right):
    """Compare actual outputs, including denominator-floor/arithmetic effects."""
    a, b = np.sort(left, axis=-1), np.sort(right, axis=-1)
    equal = (a == b).all(-1)
    return {"all_equal": bool(equal.all()), "equal_per_layer_head": equal.tolist(),
            "mismatched_sorted_values_per_layer_head": (a != b).sum(-1).tolist(),
            "max_absolute_difference_per_layer_head":
                np.abs(a.astype(np.float64) - b.astype(np.float64)).max(-1, initial=0).tolist()}


def make_oracles(virtual: VirtualScores, baseline: CalibrationResult, exact: FullExactDiagnostic,
                 *, recent_tokens=0):
    """Full-label pooled/regional marginal controls, plus a rank-only diagnostic.

    All maps use the same virtual/exact captures and storage/tie path. Fixed
    prefix, anchor, sink and recent positions are excluded BEFORE fitting. Pooled
    maps use all remaining positions per layer/head; regional maps use each
    remaining region. Equal source knots are never split using exact ranks.

    Actual sorted output multisets are checked, not assumed equal: duplicate
    knots and the audited float32 map's denominator floor/arithmetic may defeat
    exact transport. Such cells are explicitly confounded rather than repaired
    by numeric reranking. Singleton mutable regions remain unsupported.
    """
    require(type(virtual) is VirtualScores and type(baseline) is CalibrationResult and
            type(exact) is FullExactDiagnostic, "Explicit diagnostic input types required")
    p = baseline.plan.partition
    require(virtual.partition.fingerprint == p.fingerprint == exact.partition.fingerprint,
            "Oracle contexts/partitions/denominators differ")
    require(virtual.values.shape == baseline.scores.shape == exact.values.shape, "Oracle score shapes differ")
    protected = protection_mask(p, recent_tokens)
    fixed = protected.copy()
    fixed[:p.prefix_length] = True
    fixed[list(baseline.plan.token_indices)] = True
    mutable = ~fixed
    regions = np.asarray(p.region_ids)
    precision = baseline.precision
    v = round_storage(virtual.values, precision.nonanchor_virtual)
    e_native = round_storage(exact.values, precision.exact_anchor)
    e = round_storage(e_native, precision.output)
    anchor_indices = list(baseline.plan.token_indices)
    require(np.array_equal(e[..., anchor_indices], baseline.scores[..., anchor_indices]),
            "Full exact diagnostic disagrees with observed exact anchor labels")
    scale, pooled, rank, reference = (baseline.scores.copy() for _ in range(4))
    reference[..., mutable] = e[..., mutable]

    def map_indices(indices):
        source, target = v[..., indices], e_native[..., indices]
        mapped, stats = controlled_map(source.reshape(-1, len(indices)), target.reshape(-1, len(indices)),
                                      source.reshape(-1, len(indices)), baseline.tie_policy)
        return round_storage(mapped.reshape(source.shape), precision.output), stats

    def audit_indices(indices):
        return {"mutable_tokens": len(indices),
                "virtual_capture_ties": _tie_counts(virtual.values[..., indices]),
                "source_storage_ties": _tie_counts(v[..., indices]),
                "exact_capture_ties": _tie_counts(exact.values[..., indices]),
                "exact_target_storage_ties": _tie_counts(e_native[..., indices]),
                "exact_output_cast_ties": _tie_counts(e[..., indices]),
                "pooled_output_ties": _tie_counts(pooled[..., indices]),
                "regional_output_ties": _tie_counts(scale[..., indices]),
                "regional_vs_output_cast_exact_multiset": _multiset_check(scale[..., indices], e[..., indices]),
                "pooled_order_checks": _order_checks(v[..., indices], pooled[..., indices], "Pooled map"),
                "regional_order_checks": _order_checks(v[..., indices], scale[..., indices], "Regional map")}

    indices = np.flatnonzero(mutable)
    pooled_stats = {"map_evaluated": bool(len(indices)), "clipping": "clip", "tie_policy": baseline.tie_policy}
    if len(indices):
        require(len(indices) >= 2, "Pooled map has fewer than two mutable oracle knots")
        pooled[..., indices], stats = map_indices(indices)
        pooled_stats.update(stats)
    region_stats = {}
    for region in np.unique(regions):
        indices = np.flatnonzero(mutable & (regions == region))
        stats = {"map_evaluated": bool(len(indices)), "clipping": "clip", "tie_policy": baseline.tie_policy}
        if len(indices):
            require(len(indices) >= 2, f"Region {region} has fewer than two mutable oracle knots")
            scale[..., indices], mapped_stats = map_indices(indices)
            stats.update(mapped_stats)
            current, target = baseline.scores[..., indices], e_native[..., indices]
            order = np.argsort(target, axis=-1, kind="stable")
            reordered = np.empty_like(current)
            np.put_along_axis(reordered, order, np.sort(current, axis=-1), axis=-1)
            rank[..., indices] = reordered
            require(np.array_equal(np.sort(reordered, axis=-1), np.sort(current, axis=-1)),
                    "Rank-only oracle changed a regional histogram")
        region_stats[str(region)] = {**stats, **audit_indices(indices)}

    indices = np.flatnonzero(mutable)
    # A regional map need not be globally monotone. Only pooled order is tested
    # across U; both are checked separately on every U_r above.
    pooled_stats.update({"mutable_tokens": len(indices),
                         "source_storage_ties": _tie_counts(v[..., indices]),
                         "virtual_capture_ties": _tie_counts(virtual.values[..., indices]),
                         "exact_capture_ties": _tie_counts(exact.values[..., indices]),
                         "exact_target_storage_ties": _tie_counts(e_native[..., indices]),
                         "exact_output_cast_ties": _tie_counts(e[..., indices]),
                         "output_ties": _tie_counts(pooled[..., indices]),
                         "order_checks": _order_checks(v[..., indices], pooled[..., indices], "Pooled map over U")})
    multisets = {"comparison": "actual_sorted_mutable_outputs_exact_equality_no_tolerance",
                "pooled_vs_regional": _multiset_check(pooled[..., mutable], scale[..., mutable]),
                "pooled_vs_output_cast_exact": _multiset_check(pooled[..., mutable], e[..., mutable]),
                "regional_vs_output_cast_exact": _multiset_check(scale[..., mutable], e[..., mutable])}
    confounds = {name + "_multiset_mismatch": not multisets[name]["all_equal"]
                for name in ("pooled_vs_regional", "pooled_vs_output_cast_exact", "regional_vs_output_cast_exact")}
    methods = {"scale_map_oracle": scale, "pooled_full_map_oracle": pooled,
               "rank_only_oracle": rank, "full_exact_reference": reference}
    invariants = {}
    for name, values in methods.items():
        finite = bool(np.isfinite(values).all())
        fixed_equal = bool(np.array_equal(values[..., fixed], baseline.scores[..., fixed]))
        require(finite, f"{name} contains nonfinite scores; implementation defect")
        require(fixed_equal, f"{name} changed a fixed baseline value; implementation defect")
        invariants[name] = {"all_scores_finite": finite, "fixed_values_equal_baseline": fixed_equal}
    return methods, {
        "evidence_class": "diagnostic_only_full_reconstruction_labels", "deployable": False,
        "partition_sha256": p.fingerprint, "fixed_tokens": np.flatnonzero(fixed).tolist(),
        "protected_tokens": np.flatnonzero(protected).tolist(), "recent_tokens": recent_tokens,
        "mutable_tokens": int(mutable.sum()), "per_layer_head_shape": list(v.shape[:2]),
        "regions": region_stats, "pooled_full_map": pooled_stats,
        "precision": asdict(precision), "tie_policy": baseline.tie_policy, "clipping": "clip",
        "implementation_invariants": invariants, "mutable_multiset_checks": multisets,
        "confound_flags": confounds, "confounding_reasons": [k for k, value in confounds.items() if value],
        "exact_scores_are_downstream_ground_truth": False}


def _allocation_bounds(values, keep, report, partition, recent_tokens):
    """Exact marginal cutoff bounds, including per-layer/head/region groups.

    A tied boundary is not necessarily head-budget ambiguous: if all tied pairs
    share a single layer/head, that head's retained count cannot vary. Bounds use
    every admissible tie resolution, not just the sampled sensitivity policies.
    """
    cutoff = report["cutoff_ties"]
    equal = np.zeros(values.shape, dtype=bool)
    if cutoff:
        equal = (values == cutoff["value"]) & ~protection_mask(partition, recent_tokens)
    total, retained = int(equal.sum()), int((equal & keep).sum())
    def bounds(group):
        tied = (equal & group).sum(-1)
        other = (keep & ~equal & group).sum(-1)
        minimum = other + np.maximum(0, retained - (total - tied))
        maximum = other + np.minimum(tied, retained)
        return {"minimum_retained": minimum.tolist(), "maximum_retained": maximum.tolist(),
                "ambiguous_per_layer_head": (minimum != maximum).tolist()}
    head_bounds = bounds(np.ones(partition.token_count, dtype=bool))
    r = np.asarray(partition.region_ids)
    report["cutoff_tie_head_bounds"] = head_bounds
    report["cutoff_tie_layer_head_region_bounds"] = {str(region): bounds(r == region) for region in np.unique(r)}
    report["cutoff_ties_permit_different_head_allocations"] = bool(
        np.asarray(head_bounds["ambiguous_per_layer_head"]).any())


def compare_oracles(virtual, baseline, exact, eviction_ratio, *, recent_tokens=0,
                    tie_break="stable", seed=0):
    """Logical allocation audit only; tie sensitivities never run generation.

    A pure regional contrast requires actual pooled/regional/output-cast exact
    marginal equality, and no ambiguous cutoff membership in either map. Even
    when head/region counts agree, tied cutoffs can change which tokens survive
    inside a region. Observed allocation agreement under one tie-break alone is
    insufficient. Numerical/tie
    failures are flagged, never repaired by rank-based score reassignment.
    """
    scores, provenance = make_oracles(virtual, baseline, exact, recent_tokens=recent_tokens)
    scores = {"anchor_baseline": baseline.scores, **scores}
    p = baseline.plan.partition
    protected = protection_mask(p, recent_tokens)
    def select_all(policy):
        results, masks = {}, {}
        for name, values in scores.items():
            masks[name], results[name] = select_logical(values, p, eviction_ratio,
                                                       recent_tokens=recent_tokens, tie_break=policy, seed=seed)
            expected_retained = values.size - math.floor(values.size * eviction_ratio)
            require(int(masks[name].sum()) == results[name]["retained_pairs"] == expected_retained,
                    "Oracle selection violated the exact total retained budget; implementation defect")
            require(results[name]["protected_pairs"] == int(protected.sum()) * values.shape[0] * values.shape[1],
                    "Oracle selection has incorrect protection count; implementation defect")
            require(bool(masks[name][..., protected].all()), "Oracle selection lost protected pairs")
            _allocation_bounds(values, masks[name], results[name], p, recent_tokens)
        require(len({r["retained_pairs"] for r in results.values()}) == 1,
                "Oracle selections have different total retained counts; implementation defect")
        require(len({r["protected_pairs"] for r in results.values()}) == 1,
                "Oracle selections have different protection counts; implementation defect")
        reference = masks["full_exact_reference"]
        for name, mask in masks.items():
            results[name]["mask_disagreement_fraction_vs_exact_score_reference"] = float(np.mean(mask != reference))
            results[name]["exact_score_selected_pair_recall"] = float((mask & reference).sum() / reference.sum())
        return masks, results

    masks, results = select_all(tie_break)
    def ambiguous(result):
        cutoff = result["cutoff_ties"]
        return bool(cutoff and cutoff["ambiguous_membership"])
    same_allocation = results["anchor_baseline"]["by_region"] == results["rank_only_oracle"]["by_region"]
    require(same_allocation or ambiguous(results["anchor_baseline"]) or ambiguous(results["rank_only_oracle"]),
            "Rank-only changed regional allocation without a cutoff tie; implementation defect")
    pooled, regional = "pooled_full_map_oracle", "scale_map_oracle"
    head_agreement = results[pooled]["retained_per_layer_head"] == results[regional]["retained_per_layer_head"]
    ambiguous_heads = any(results[name]["cutoff_ties_permit_different_head_allocations"]
                          for name in (pooled, regional))
    multiset_checks = provenance["mutable_multiset_checks"]
    reasons = list(provenance["confounding_reasons"])
    if any(ambiguous(results[name]) for name in (pooled, regional)):
        reasons.append("ambiguous_cutoff_membership")
    if ambiguous_heads:
        reasons.append("cutoff_ties_permit_different_head_allocations")
    if not provenance["mutable_tokens"]:
        reasons.append("no_mutable_positions")
    if not head_agreement:
        reasons.append("observed_layer_head_allocations_differ")
    require(not multiset_checks["pooled_vs_regional"]["all_equal"] or ambiguous_heads or head_agreement,
            "Equal pooled/regional multisets changed head allocation without cutoff freedom; implementation defect")

    sensitivities = {}
    for policy in ("stable", "reverse", "random"):
        sensitivity_masks, sensitivity_results = (masks, results) if policy == tie_break else select_all(policy)
        # Report all methods and existing region bounds; these are mask-only
        # evaluations on identical numeric scores, not extra downstream arms.
        methods = {}
        for name, result in sensitivity_results.items():
            methods[name] = {**result, "mask_disagreement_fraction_vs_primary_tie_break":
                            float(np.mean(sensitivity_masks[name] != masks[name]))}
        agreement = methods[pooled]["retained_per_layer_head"] == methods[regional]["retained_per_layer_head"]
        require(not multiset_checks["pooled_vs_regional"]["all_equal"] or ambiguous_heads or agreement,
                "Tie sensitivity changed head allocation without cutoff freedom; implementation defect")
        sensitivities[policy] = {"score_only": True, "downstream_generation_performed": False,
                                 "tie_seed": seed, "pooled_regional_head_allocations_equal": agreement,
                                 "pooled_regional_mask_disagreement_fraction":
                                     float(np.mean(sensitivity_masks[pooled] != sensitivity_masks[regional])),
                                 "methods": methods}
    contrast = {"evidence_class": "diagnostic_only_full_reconstruction_labels", "deployable": False,
                "pure_regional_contrast_interpretable": not reasons, "confounding_reasons": reasons,
                "mutable_multiset_checks": multiset_checks,
                "pooled_regional_head_allocations_equal": head_agreement,
                "cutoff_ties_permit_different_head_allocations": ambiguous_heads,
                "cutoff_membership_ambiguity": {name: ambiguous(results[name]) for name in (pooled, regional)},
                "tie_sensitivities": sensitivities,
                "model_quality_claim": False, "content_causality_claim": False}
    return {"evidence_class": "cpu_score_diagnostic_only", "model_quality_claim": False,
            "physical_memory_measured": False, "oracle_provenance": provenance,
            "rank_only_preserved_regional_allocation": same_allocation,
            "cutoff_tie_warning": any(ambiguous(result) for result in results.values()),
            "regional_contrast": contrast, "methods": results}
