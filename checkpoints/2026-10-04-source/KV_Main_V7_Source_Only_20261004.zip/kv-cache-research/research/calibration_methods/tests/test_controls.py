"""Synthetic CPU tests only. No inference, network, credentials or paid compute."""
from dataclasses import replace
import importlib
import unittest

import numpy as np

from research.calibration_methods import (AnchorObservations, AnchorPlan, Microchunk,
                                        Partition, Precision, VirtualScores, calibrate,
                                        plan_anchor_matrix, plan_anchors, select_logical)
from research.calibration_methods.contracts import digest
from research.calibration_methods.diagnostics import FullExactDiagnostic, compare_oracles, make_oracles
from research.calibration_methods.methods import assert_equal_budget, controlled_map, round_storage
from research.calibration_methods.synthetic_smoke import fixture_partition, run


class PartitionPlanTests(unittest.TestCase):
    def test_policies_share_frozen_shape_token_and_proxy_budgets(self):
        p = fixture_partition(34)
        plans = [plan_anchors(p, 4, policy, 29) for policy in ("first", "random", "uniform")]
        cost = assert_equal_budget(plans)
        self.assertEqual(cost["passes"], 4)
        self.assertEqual(cost["context_anchor_tokens"], 16)
        self.assertEqual(cost["reconstruction_input_tokens"], 28)
        self.assertEqual(cost["pass_input_tokens"], [7] * 4)
        self.assertTrue(all(8 not in plan.chunk_ids for plan in plans))  # unmatched tail
        self.assertEqual(plans[0].chunk_ids, (0, 1, 2, 3))
        self.assertEqual(plans[2].chunk_ids, (1, 3, 5, 7))

    def test_uniform_strata_are_unique_even_when_selecting_all(self):
        p = fixture_partition()
        for k in range(1, 9):
            plan = plan_anchors(p, k, "uniform")
            self.assertEqual(len(set(plan.chunk_ids)), k)
        self.assertEqual(plan.chunk_ids, tuple(range(8)))

    def test_random_reproducible_without_replacement(self):
        p = fixture_partition(128)
        a = plan_anchors(p, 8, "random", 12)
        self.assertEqual(a, plan_anchors(p, 8, "random", 12))
        self.assertNotEqual(a.chunk_ids, plan_anchors(p, 8, "random", 13).chunk_ids)

    def test_prompt_shape_mismatch_is_excluded_not_called_matched(self):
        p = fixture_partition()
        chunks = list(p.chunks)
        chunks[0] = replace(chunks[0], prompt_tokens=4)
        p = replace(p, chunks=tuple(chunks))
        self.assertEqual(plan_anchors(p, 1, "uniform").chunk_ids, (0,))
        with self.assertRaisesRegex(ValueError, "Insufficient"):
            plan_anchors(p, 2, "first")

    def test_equal_budget_rejects_changed_partition_or_pass_count(self):
        p = fixture_partition()
        a = plan_anchors(p, 1, "first")
        for b in (plan_anchors(p, 2, "first"),
                  plan_anchors(replace(p, sink_tokens=1), 1, "first")):
            with self.assertRaises(ValueError):
                assert_equal_budget([a, b])

    def test_matrix_counts_prompt_tokens_inside_cap(self):
        p = fixture_partition(8192, 512)
        p = replace(p, chunks=tuple(replace(c, prompt_tokens=13) for c in p.chunks))
        with self.assertRaisesRegex(ValueError, "including prompt"):
            plan_anchor_matrix(p, 4, 2048)
        p = fixture_partition(8192, 499)
        p = replace(p, chunks=tuple(replace(c, prompt_tokens=13) for c in p.chunks))
        plans = plan_anchor_matrix(p, 4, 2048, (7, 11, 29))
        self.assertEqual(len(plans), 5)
        self.assertEqual(plans[0].cost()["reconstruction_input_tokens"], 2048)
        self.assertEqual(plans[0].cost()["context_anchor_tokens"], 1996)

    def test_matrix_seed_set_must_be_frozen_valid_and_unique(self):
        for seeds in ([], (), (1, 1), (True,), (-1,)):
            with self.assertRaises(ValueError):
                plan_anchor_matrix(fixture_partition(), 1, 100, seeds)

    def test_original_key_denominator_is_full_fixed_chunk_plus_sinks(self):
        p = replace(fixture_partition(), sink_tokens=4)
        self.assertEqual(p.denominator_original_keys(0), (0, 1, 2, 3))
        self.assertEqual(p.denominator_original_keys(3), (0, 1, 2, 3, 12, 13, 14, 15))
        before = [p.denominator_original_keys(i) for i in range(8)]
        for policy in ("first", "random", "uniform"):
            plan_anchors(p, 2, policy, 9)
            self.assertEqual(before, [p.denominator_original_keys(i) for i in range(8)])

    def test_invalid_partitions_rejected(self):
        p = fixture_partition()
        for kwargs in ({"token_count": True}, {"region_source": "future_query"},
                       {"region_source": "gold_answer"}, {"denominator": "selected_anchors_only"},
                       {"region_ids": list(p.region_ids)}, {"chunks": p.chunks[1:]},
                       {"prefix_length": 32}, {"context_sha256": "floating"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                replace(p, **kwargs)

    def test_invalid_plans_rejected(self):
        p = fixture_partition()
        for args in ((0, "first", 0), (10, "first", 0), (1, "gold", 0),
                     (True, "first", 0), (1, "random", -1)):
            with self.subTest(args=args), self.assertRaises(ValueError):
                plan_anchors(p, *args)
        for ids in ((0, 0), (1, 0), (-1,), (8,)):
            with self.assertRaises(ValueError):
                AnchorPlan(p, ids, "first", 0)


class AnchorOnlyCalibrationTests(unittest.TestCase):
    def setUp(self):
        self.p = fixture_partition(16)
        self.v = VirtualScores(self.p, np.tile([1, 2, 3, 4], (2, 2, 4)))
        self.plan = plan_anchors(self.p, 1, "first")
        self.exact = self.v.values[..., :4] * np.array([[2, 3], [4, 5]])[..., None]
        self.anchors = AnchorObservations(self.plan, self.exact)

    def test_per_layer_head_independence_and_exact_overrides(self):
        result = calibrate(self.v, self.anchors)
        np.testing.assert_array_equal(result.scores, np.tile(self.exact, (1, 1, 4)))
        self.assertFalse(result.diagnostics["oracle"])

    def test_scattered_anchors_overwritten_in_token_order(self):
        plan = plan_anchors(self.p, 2, "uniform")
        indices = list(plan.token_indices)
        anchors = AnchorObservations(plan, self.v.values[..., indices] * 2)
        result = calibrate(self.v, anchors)
        np.testing.assert_array_equal(result.scores[..., indices], anchors.values)
        self.assertEqual(plan.chunk_ids, (1, 3))

    def test_no_calibration_keeps_same_work_but_changes_only_anchors(self):
        result = calibrate(self.v, self.anchors, enabled=False)
        np.testing.assert_array_equal(result.scores[..., :4], self.exact)
        np.testing.assert_array_equal(result.scores[..., 4:], self.v.values[..., 4:])
        self.assertEqual(result.diagnostics["replay_cost_proxy"], self.plan.cost())

    def test_prefix_is_not_mapped(self):
        p = Partition(digest([1, 2, 3]), 10, 2, (Microchunk(2, 6, 3), Microchunk(6, 10, 3)),
                      (-1, -1, 0, 0, 0, 0, 1, 1, 1, 1), "context_metadata", sink_tokens=2)
        v = VirtualScores(p, [[[99, 88, 1, 2, 3, 4, 1, 2, 3, 4]]])
        result = calibrate(v, AnchorObservations(plan_anchors(p, 1, "first"), [[[2, 4, 6, 8]]]))
        np.testing.assert_array_equal(result.scores[..., :2], [[[99, 88]]])

    def test_wrong_partition_layer_or_full_exact_rejected(self):
        with self.assertRaises(ValueError):
            AnchorObservations(self.plan, self.v.values)
        with self.assertRaises(ValueError):
            calibrate(self.v, AnchorObservations(self.plan, self.exact[:1]))
        other = plan_anchors(replace(self.p, sink_tokens=1), 1, "first")
        with self.assertRaisesRegex(ValueError, "denominators"):
            calibrate(self.v, AnchorObservations(other, self.exact))

    def test_question_and_gold_inputs_have_no_api_slot(self):
        for key in ("question_token_ids", "gold_answers", "future_query", "downstream_outcomes"):
            with self.subTest(key=key), self.assertRaises(TypeError):
                calibrate(self.v, self.anchors, **{key: [0]})
        with self.assertRaises(ValueError):
            calibrate(self.v, FullExactDiagnostic(self.p, self.v.values))

    def test_nonanchor_exact_counterfactual_cannot_change_deployable_result(self):
        full_a, full_b = self.v.values.copy(), self.v.values.copy()
        full_b[..., 4:] = 987
        a = AnchorObservations(self.plan, full_a[..., list(self.plan.token_indices)])
        b = AnchorObservations(self.plan, full_b[..., list(self.plan.token_indices)])
        np.testing.assert_array_equal(calibrate(self.v, a).scores, calibrate(self.v, b).scores)

    def test_inputs_copied_no_mutation(self):
        raw = self.v.values.copy()
        frame = VirtualScores(self.p, raw)
        raw[:] = 999
        result = calibrate(frame, self.anchors)
        self.assertNotEqual(float(frame.values[0, 0, 0]), 999)
        self.assertFalse(result.scores.flags.writeable)
        self.assertFalse(frame.values.flags.writeable)

    def test_nonfinite_or_empty_inputs_rejected(self):
        for values in (np.empty((1, 1, 0)), [[[np.nan] * 16]], [[[np.inf] * 16]]):
            with self.assertRaises(ValueError):
                VirtualScores(self.p, values)

    def test_support_clipping_is_reported_per_region(self):
        values = self.v.values.copy()
        values[..., 4:8] = [-1, 2, 3, 10]
        result = calibrate(VirtualScores(self.p, values), self.anchors)
        stats = result.diagnostics["support_by_region"]["1"]
        self.assertEqual(stats["below_support_count"], [1] * 4)
        self.assertEqual(stats["above_support_count"], [1] * 4)
        with self.assertRaisesRegex(ValueError, "outside"):
            calibrate(VirtualScores(self.p, values), self.anchors, clipping="reject")


class PrecisionTieTests(unittest.TestCase):
    def test_author_duplicate_knots_remain_original_behavior(self):
        mapped, stats = controlled_map([[1, 2, 2]], [[10, 20, 30]], [[0, 2, 99]])
        np.testing.assert_array_equal(mapped, [[10, 20, 20]])
        self.assertEqual(stats["duplicate_anchor_count"], [1])
        self.assertEqual(stats["below_support_count"], [1])
        self.assertEqual(stats["above_support_count"], [1])

    def test_duplicate_mean_is_separate_named_ablation(self):
        mapped, stats = controlled_map([[1, 2, 2]], [[10, 20, 30]], [[0, 1.5, 2, 99]], "collapse_mean")
        np.testing.assert_array_equal(mapped, [[10, 17.5, 25, 25]])
        self.assertEqual(stats["tie_policy"], "collapse_mean")

    def test_all_tied_source_and_empty_values(self):
        mapped, _ = controlled_map([[1, 1]], [[10, 20]], [[-1, 1, 3]], "collapse_mean")
        np.testing.assert_array_equal(mapped, [[15, 15, 15]])
        mapped, stats = controlled_map([[1, 2]], [[10, 20]], np.empty((1, 0)))
        self.assertEqual(mapped.shape, (1, 0))
        self.assertEqual(stats["evaluation_count_per_row"], 0)

    def test_bfloat16_round_to_nearest_ties_even(self):
        bits = np.array([0x3f808000, 0x3f818000, 0xbf808000, 0xbf818000], dtype=np.uint32)
        out = round_storage(bits.view(np.float32), "bfloat16")
        np.testing.assert_array_equal(out.view(np.uint32), [0x3f800000, 0x3f820000, 0xbf800000, 0xbf820000])

    def test_precision_controls_create_ties_without_simulating_kernels(self):
        values = np.array([1, 1.0001, 1.0002], dtype=np.float32)
        self.assertEqual(len(np.unique(round_storage(values, "bfloat16"))), 1)
        self.assertEqual(len(np.unique(round_storage(values, "float32"))), 3)
        self.assertEqual(Precision.author_storage_like().anchor_virtual, "float32")

    def test_float16_overflow_and_unsupported_controls_rejected(self):
        for dtype in ("float16", "bfloat16"):
            with self.assertRaises(ValueError):
                round_storage([np.finfo(np.float32).max], dtype)
        with self.assertRaises(ValueError):
            Precision(output="int8")
        with self.assertRaises(ValueError):
            controlled_map([[1, 2]], [[1, 2]], [[1]], "silent_new_ties")

    def test_both_map_tie_controls_monotonic(self):
        for policy in ("author_left", "collapse_mean"):
            out, _ = controlled_map([[1, 1, 2, 3, 3]], [[5, 1, 8, 2, 9]],
                                    [np.linspace(-1, 5, 101)], policy)
            self.assertTrue((np.diff(out) >= 0).all())


class SelectionTests(unittest.TestCase):
    def test_recent_and_sinks_consume_same_total_budget(self):
        p = replace(fixture_partition(12), sink_tokens=2)
        scores = np.arange(24, dtype=np.float32).reshape(1, 2, 12)
        mask, report = select_logical(scores, p, .5, recent_tokens=2)
        self.assertEqual(mask.sum(), 12)
        self.assertEqual(report["protected_pairs"], 8)
        self.assertTrue(mask[..., :2].all() and mask[..., -2:].all())
        self.assertFalse(report["physical_memory_measured"])

    def test_protection_overlap_counted_once_and_impossible_budget_rejected(self):
        p = replace(fixture_partition(4), sink_tokens=3)
        _, report = select_logical([[[1, 2, 3, 4]]], p, 0, recent_tokens=3)
        self.assertEqual(report["protected_pairs"], 4)
        with self.assertRaisesRegex(ValueError, "union"):
            select_logical([[[1, 2, 3, 4]]], p, .5, recent_tokens=3)

    def test_all_tied_cutoff_reports_ambiguity_and_region_bounds(self):
        p = fixture_partition(8)
        a, report = select_logical(np.ones((1, 1, 8)), p, .5)
        b, _ = select_logical(np.ones((1, 1, 8)), p, .5, tie_break="reverse")
        self.assertTrue(report["cutoff_ties"]["ambiguous_membership"])
        self.assertFalse(np.array_equal(a, b))
        self.assertEqual(report["cutoff_tie_region_bounds"]["0"], {"minimum_retained": 0, "maximum_retained": 4})

    def test_tie_seed_is_reproducible_and_cannot_change_untied_order(self):
        p = fixture_partition(8)
        for values in (np.ones((1, 1, 8)), np.arange(8).reshape(1, 1, 8)):
            a, _ = select_logical(values, p, .5, tie_break="random", seed=1)
            b, _ = select_logical(values, p, .5, tie_break="random", seed=1)
            np.testing.assert_array_equal(a, b)
        stable, _ = select_logical(values, p, .5)
        np.testing.assert_array_equal(a, stable)

    def test_global_budget_floor_is_not_per_head_floor(self):
        p = fixture_partition(3, 3)
        _, report = select_logical(np.ones((1, 2, 3)), p, .3)
        self.assertEqual(report["pruned_pairs"], 1)

    def test_invalid_selection_inputs(self):
        p = fixture_partition(8)
        for kwargs in ({"eviction_ratio": 1}, {"eviction_ratio": np.nan},
                       {"eviction_ratio": True}, {"eviction_ratio": .5, "recent_tokens": 9},
                       {"eviction_ratio": .5, "tie_break": "torch"}):
            with self.assertRaises(ValueError):
                select_logical(np.ones((1, 1, 8)), p, **kwargs)


class OracleTests(unittest.TestCase):
    def setup_case(self):
        p = fixture_partition(16)
        v = VirtualScores(p, np.arange(1, 17, dtype=np.float32).reshape(1, 1, 16))
        plan = plan_anchors(p, 1, "first")
        exact = v.values.copy()
        exact[..., 4:] = exact[..., 4:][..., ::-1]
        # No-calibration baseline avoids clipping introducing ties in this test.
        base = calibrate(v, AnchorObservations(plan, exact[..., :4]), enabled=False)
        return p, v, base, FullExactDiagnostic(p, exact)

    def test_oracles_not_exported_from_deployable_interface(self):
        package = importlib.import_module("research.calibration_methods")
        self.assertNotIn("FullExactDiagnostic", package.__all__)
        self.assertFalse(hasattr(package, "make_oracles"))

    def test_rank_oracle_preserves_each_histogram_and_fixed_values(self):
        p, v, base, exact = self.setup_case()
        methods, metadata = make_oracles(v, base, exact, recent_tokens=2)
        fixed = metadata["fixed_tokens"]
        for values in methods.values():
            np.testing.assert_array_equal(values[..., fixed], base.scores[..., fixed])
        for region in set(p.region_ids):
            mask = np.array(p.region_ids) == region
            np.testing.assert_array_equal(np.sort(methods["rank_only_oracle"][..., mask]),
                                          np.sort(base.scores[..., mask]))
        report = compare_oracles(v, base, exact, .5, recent_tokens=2)
        self.assertTrue(report["rank_only_preserved_regional_allocation"])

    def test_partial_anchor_region_histogram_stays_fixed(self):
        p = fixture_partition(16, 2)
        v = VirtualScores(p, np.arange(1, 17).reshape(1, 1, 16))
        plan = plan_anchors(p, 1, "first")
        exact = v.values.copy()
        exact[..., 2:4] = [4, 3]
        base = calibrate(v, AnchorObservations(plan, exact[..., :2]), enabled=False)
        methods, _ = make_oracles(v, base, FullExactDiagnostic(p, exact))
        np.testing.assert_array_equal(np.sort(methods["rank_only_oracle"][..., :4]),
                                      np.sort(base.scores[..., :4]))

    def test_scale_oracle_preserves_virtual_order_not_exact_rank(self):
        p, v, base, exact = self.setup_case()
        methods, metadata = make_oracles(v, base, exact)
        for region in set(p.region_ids):
            indices = [i for i, r in enumerate(p.region_ids) if r == region and i not in metadata["fixed_tokens"]]
            self.assertTrue((np.diff(methods["scale_map_oracle"][..., indices]) >= 0).all())

    def test_mismatched_exact_anchors_and_partitions_fail(self):
        p, v, base, exact = self.setup_case()
        bad = exact.values.copy()
        bad[..., 0] += 1
        with self.assertRaisesRegex(ValueError, "anchor labels"):
            make_oracles(v, base, FullExactDiagnostic(p, bad))
        with self.assertRaisesRegex(ValueError, "denominators"):
            make_oracles(v, base, FullExactDiagnostic(replace(p, sink_tokens=1), exact.values))

    def test_singleton_mutable_region_is_explicitly_rejected(self):
        p, v, base, exact = self.setup_case()
        with self.assertRaisesRegex(ValueError, "fewer than two"):
            make_oracles(v, base, exact, recent_tokens=3)

    def test_constructed_mechanisms_separate_scale_from_rank(self):
        report = run()
        scale = report["oracle_cases"]["constructed_regional_scale_shift"]["methods"]
        rank = report["oracle_cases"]["constructed_within_region_rank_failure"]["methods"]
        metric = "mask_disagreement_fraction_vs_exact_score_reference"
        self.assertEqual(scale["scale_map_oracle"][metric], 0)
        self.assertGreater(scale["anchor_baseline"][metric], 0)
        self.assertEqual(rank["rank_only_oracle"][metric], 0)
        self.assertGreater(rank["scale_map_oracle"][metric], 0)
        self.assertFalse(report["gpu_used"] or report["model_loaded"] or report["model_quality_claim"])

    def test_synthetic_report_reproducible(self):
        self.assertEqual(run(), run())


if __name__ == "__main__":
    unittest.main()
