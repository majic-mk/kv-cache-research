"""CPU-only full-information controls: empirical transport is checked, not assumed."""
from dataclasses import replace
import json
import unittest
from unittest.mock import patch

import numpy as np

from research.calibration_methods import (AnchorObservations, Microchunk, Partition,
                                        Precision, VirtualScores, calibrate, plan_anchors)
from research.calibration_methods.contracts import digest
from research.calibration_methods.diagnostics import FullExactDiagnostic, compare_oracles, make_oracles
from research.calibration_methods.methods import controlled_map, round_storage
from research.calibration_methods.selection import select_logical
from research.calibration_methods.synthetic_smoke import fixture_partition


MODULE = "research.calibration_methods.diagnostics."
POOLED, REGIONAL = "pooled_full_map_oracle", "scale_map_oracle"


def case(virtual=None, exact=None, *, precision=Precision(), policy="author_left", p=None):
    p = fixture_partition(12) if p is None else p
    if virtual is None:
        virtual = np.arange(p.token_count, dtype=np.float32).reshape(1, 1, -1)
    virtual = VirtualScores(p, virtual)
    if exact is None:
        exact = virtual.values.copy()
        exact[..., 4:8], exact[..., 8:12] = virtual.values[..., 4:8] + 36, virtual.values[..., 8:12] - 4
    exact = FullExactDiagnostic(p, exact)
    plan = plan_anchors(p, 1, "first")
    baseline = calibrate(virtual, AnchorObservations(plan, exact.values[..., list(plan.token_indices)]),
                         precision=precision, tie_policy=policy, enabled=False)
    return virtual, baseline, exact


class PooledOracleTests(unittest.TestCase):
    def test_clean_multilayer_head_cell_transports_actual_exact_marginals(self):
        values = np.arange(12, dtype=np.float32)[None, None] + np.arange(4).reshape(2, 2, 1) / 4
        inputs = case(virtual=values)
        scores, provenance = make_oracles(*inputs)
        mutable = np.arange(4, 12)
        for name in (POOLED, REGIONAL):
            np.testing.assert_array_equal(np.sort(scores[name][..., mutable]),
                                          np.sort(inputs[2].values[..., mutable]))
        self.assertFalse(np.array_equal(scores[POOLED], scores[REGIONAL]))
        self.assertFalse(any(provenance["confound_flags"].values()))
        for name in ("pooled_vs_regional", "pooled_vs_output_cast_exact", "regional_vs_output_cast_exact"):
            checks = provenance["mutable_multiset_checks"][name]
            self.assertEqual(checks["equal_per_layer_head"], [[True, True], [True, True]])
            self.assertEqual(checks["mismatched_sorted_values_per_layer_head"], [[0, 0], [0, 0]])
        report = compare_oracles(*inputs, .5)
        contrast = report["regional_contrast"]
        self.assertTrue(contrast["pure_regional_contrast_interpretable"])
        self.assertTrue(contrast["pooled_regional_head_allocations_equal"])
        self.assertNotEqual(report["methods"][POOLED]["by_region"], report["methods"][REGIONAL]["by_region"])
        self.assertEqual(set(contrast["tie_sensitivities"]), {"stable", "reverse", "random"})
        json.dumps(report, allow_nan=False)

    def test_fitting_excludes_prefix_anchors_sinks_recent_before_any_map(self):
        p = Partition(digest("exclusion"), 18, 2,
                      tuple(Microchunk(i, i + 4, 3) for i in range(2, 18, 4)),
                      (-1, -1) + tuple(i // 4 for i in range(16)), "fixed_position", sink_tokens=8)
        v, baseline, exact = case(p=p, exact=np.arange(18, dtype=np.float32)[None, None] * 10)
        with patch(MODULE + "controlled_map", wraps=controlled_map) as mapper:
            scores, metadata = make_oracles(v, baseline, exact, recent_tokens=2)
        fixed, mutable = metadata["fixed_tokens"], np.array([8, 9, 10, 11, 12, 13, 14, 15])
        self.assertEqual(fixed, list(range(8)) + [16, 17])
        self.assertEqual(metadata["protected_tokens"], list(range(8)) + [16, 17])
        self.assertEqual(metadata["regions"]["1"]["mutable_tokens"], 2)
        self.assertEqual(metadata["regions"]["3"]["mutable_tokens"], 2)
        self.assertEqual(metadata["regions"]["-1"]["mutable_tokens"], 0)
        np.testing.assert_array_equal(mapper.call_args_list[0].args[0], v.values[..., mutable].reshape(1, -1))
        np.testing.assert_array_equal(mapper.call_args_list[0].args[1], exact.values[..., mutable].reshape(1, -1))
        for output in scores.values():
            np.testing.assert_array_equal(output[..., fixed], baseline.scores[..., fixed])
        report = compare_oracles(v, baseline, exact, .25, recent_tokens=2)
        for result in report["methods"].values():
            self.assertEqual(result["retained_pairs"], 14)
            self.assertEqual(result["protected_pairs"], 10)
        self.assertEqual(metadata["pooled_full_map"]["below_support_count"], [0])
        self.assertEqual(metadata["pooled_full_map"]["above_support_count"], [0])

    def test_pooled_uses_same_declared_cast_and_tie_path_as_regional(self):
        values = np.arange(12, dtype=np.float32)[None, None] / 10 + 1
        target = values * 3 + .0001
        precision = Precision("float32", "bfloat16", "float16", "bfloat16")
        for policy in ("author_left", "collapse_mean"):
            with self.subTest(policy=policy):
                inputs = case(values, target, precision=precision, policy=policy)
                outputs, provenance = make_oracles(*inputs)
                source = round_storage(values[..., 4:], precision.nonanchor_virtual)
                exact = round_storage(target[..., 4:], precision.exact_anchor)
                expected, _ = controlled_map(source.reshape(1, -1), exact.reshape(1, -1),
                                              source.reshape(1, -1), policy)
                np.testing.assert_array_equal(outputs[POOLED][..., 4:],
                                              round_storage(expected.reshape(1, 1, -1), precision.output))
                self.assertEqual(provenance["pooled_full_map"]["tie_policy"], policy)
                self.assertEqual(provenance["regions"]["1"]["tie_policy"], policy)
                self.assertEqual(provenance["precision"], precision.__dict__)

    def test_duplicate_knots_confounded_without_splitting_equal_inputs(self):
        values = np.array([0, 1, 2, 3, 4, 5, 5, 6, 4, 5, 5, 6], dtype=np.float32)[None, None]
        targets = np.arange(12, dtype=np.float32)[None, None] * 10
        for policy in ("author_left", "collapse_mean"):
            with self.subTest(policy=policy):
                inputs = case(values, targets, policy=policy)
                outputs, metadata = make_oracles(*inputs)
                for knot in (4, 5, 6):
                    equal = values[0, 0] == knot
                    self.assertEqual(len(np.unique(outputs[POOLED][..., equal])), 1)
                self.assertEqual(metadata["pooled_full_map"]["source_storage_ties"]["duplicate_count"], [[5]])
                self.assertTrue(metadata["confound_flags"]["pooled_vs_output_cast_exact_multiset_mismatch"])
                self.assertTrue(metadata["confound_flags"]["regional_vs_output_cast_exact_multiset_mismatch"])
                contrast = compare_oracles(*inputs, .5)["regional_contrast"]
                self.assertFalse(contrast["pure_regional_contrast_interpretable"])

    def test_distinct_subfloor_knots_fail_multiset_check_without_failing_map(self):
        values = np.arange(12, dtype=np.float32)[None, None]
        values[..., 4:] = np.arange(8, dtype=np.float32) * np.float32(1e-14)
        inputs = case(values, np.arange(12, dtype=np.float32)[None, None])
        _, metadata = make_oracles(*inputs)
        self.assertEqual(metadata["pooled_full_map"]["source_storage_ties"]["duplicate_count"], [[0]])
        mismatch = metadata["mutable_multiset_checks"]["pooled_vs_output_cast_exact"]
        self.assertFalse(mismatch["all_equal"])
        self.assertGreater(mismatch["mismatched_sorted_values_per_layer_head"][0][0], 0)
        self.assertGreater(mismatch["max_absolute_difference_per_layer_head"][0][0], .9)
        self.assertFalse(compare_oracles(*inputs, .5)["regional_contrast"]["pure_regional_contrast_interpretable"])

    def test_distinct_normal_knots_detect_float32_roundoff(self):
        # y0 + (y1-y0) loses a low-order bit despite w==1 and no denominator floor.
        values = np.arange(12, dtype=np.float32)[None, None]
        targets = np.array([-1, -1, -1, -1, -1e8, .1, .2, .3, .4, .5, .6, .7], dtype=np.float32)[None, None]
        _, metadata = make_oracles(*case(values, targets))
        check = metadata["mutable_multiset_checks"]["pooled_vs_output_cast_exact"]
        self.assertFalse(check["all_equal"])
        self.assertEqual(check["mismatched_sorted_values_per_layer_head"], [[1]])
        self.assertGreater(check["max_absolute_difference_per_layer_head"][0][0], 0)

    def test_actual_output_cast_target_is_used_and_output_ties_recorded(self):
        values = np.arange(12, dtype=np.float32)[None, None]
        targets = 1 + np.arange(12, dtype=np.float32)[None, None] * .00001
        _, metadata = make_oracles(*case(values, targets, precision=Precision(output="bfloat16")))
        self.assertEqual(metadata["pooled_full_map"]["exact_capture_ties"]["duplicate_count"], [[0]])
        self.assertEqual(metadata["pooled_full_map"]["exact_output_cast_ties"]["duplicate_count"], [[7]])
        self.assertTrue(metadata["mutable_multiset_checks"]["pooled_vs_output_cast_exact"]["all_equal"])
        self.assertEqual(metadata["pooled_full_map"]["output_ties"]["duplicate_count"], [[7]])

    def test_cast_created_source_ties_are_not_mistaken_for_distinct_knots(self):
        values = 1 + np.arange(12, dtype=np.float32)[None, None] * .00001
        _, metadata = make_oracles(*case(values, np.arange(12, dtype=np.float32)[None, None],
                                        precision=Precision(nonanchor_virtual="bfloat16")))
        self.assertEqual(metadata["pooled_full_map"]["virtual_capture_ties"]["duplicate_count"], [[0]])
        self.assertEqual(metadata["pooled_full_map"]["source_storage_ties"]["duplicate_count"], [[7]])
        self.assertTrue(metadata["confound_flags"]["pooled_vs_output_cast_exact_multiset_mismatch"])

    def test_cutoff_can_move_head_budgets_despite_observed_agreement(self):
        values = np.tile(np.arange(12, dtype=np.float32), (1, 2, 1))
        inputs = case(values, np.ones_like(values))
        report = compare_oracles(*inputs, .5, seed=17)
        contrast = report["regional_contrast"]
        self.assertTrue(contrast["pooled_regional_head_allocations_equal"])
        self.assertTrue(contrast["cutoff_ties_permit_different_head_allocations"])
        self.assertFalse(contrast["pure_regional_contrast_interpretable"])
        self.assertEqual(contrast["confounding_reasons"], ["ambiguous_cutoff_membership",
                                                           "cutoff_ties_permit_different_head_allocations"])
        for name in (POOLED, REGIONAL):
            bounds = report["methods"][name]["cutoff_tie_head_bounds"]
            self.assertEqual(bounds["minimum_retained"], [[0, 0]])
            self.assertEqual(bounds["maximum_retained"], [[12, 12]])
        sensitivities = contrast["tie_sensitivities"]
        self.assertEqual(sensitivities["stable"]["methods"][POOLED]["retained_per_layer_head"], [[0, 12]])
        self.assertEqual(sensitivities["reverse"]["methods"][POOLED]["retained_per_layer_head"], [[12, 0]])
        self.assertEqual(report, compare_oracles(*inputs, .5, seed=17))

    def test_single_head_cutoff_ties_keep_head_budget_but_confound_membership(self):
        for heads, ratio in ((1, .5), (2, .75)):
            values = np.tile(np.arange(12, dtype=np.float32), (1, heads, 1))
            target = np.ones_like(values) * np.arange(1, heads + 1)[None, :, None]
            report = compare_oracles(*case(values, target), ratio)
            contrast = report["regional_contrast"]
            self.assertTrue(contrast["cutoff_membership_ambiguity"][POOLED])
            self.assertFalse(contrast["cutoff_ties_permit_different_head_allocations"])
            self.assertFalse(contrast["pure_regional_contrast_interpretable"])
            self.assertIn("ambiguous_cutoff_membership", contrast["confounding_reasons"])
            self.assertTrue(report["methods"][POOLED]["cutoff_tie_region_bounds"])
            self.assertTrue(report["methods"][POOLED]["cutoff_tie_layer_head_region_bounds"])

    def test_cutoff_ties_can_swap_tokens_with_identical_head_and_region_counts(self):
        values = np.array([-10, -9, -8, -7, 6, 3, 4, 1, 5, 7, 0, 2], dtype=np.float32)[None, None]
        target = np.array([-10, -9, -8, -7, 3, 1, 3, 3, 1, 0, 1, 2], dtype=np.float32)[None, None]
        inputs = case(values, target)
        scores, _ = make_oracles(*inputs)
        pooled, _ = select_logical(scores[POOLED], inputs[0].partition, .5)
        regional, _ = select_logical(scores[REGIONAL], inputs[0].partition, .5)
        self.assertEqual(np.flatnonzero(pooled != regional).tolist(), [5, 7])
        report = compare_oracles(*inputs, .5)
        contrast = report["regional_contrast"]
        self.assertEqual(report["methods"][POOLED]["by_region"], report["methods"][REGIONAL]["by_region"])
        self.assertTrue(contrast["pooled_regional_head_allocations_equal"])
        self.assertFalse(contrast["cutoff_ties_permit_different_head_allocations"])
        for name in ("pooled_vs_regional", "pooled_vs_output_cast_exact", "regional_vs_output_cast_exact"):
            self.assertTrue(contrast["mutable_multiset_checks"][name]["all_equal"])
        self.assertFalse(contrast["pure_regional_contrast_interpretable"])
        self.assertEqual(contrast["confounding_reasons"], ["ambiguous_cutoff_membership"])

    def test_tied_values_away_from_cutoff_do_not_imply_ambiguity(self):
        values = np.tile(np.arange(12, dtype=np.float32), (1, 2, 1))
        target = np.ones_like(values) * np.array([1, 2])[None, :, None]
        contrast = compare_oracles(*case(values, target), .5)["regional_contrast"]
        self.assertFalse(contrast["cutoff_membership_ambiguity"][POOLED])
        self.assertTrue(contrast["pure_regional_contrast_interpretable"])

    def test_protected_cutoff_ties_are_excluded_from_head_bounds(self):
        p = replace(fixture_partition(12), sink_tokens=2)
        values = np.tile(np.arange(12, dtype=np.float32), (1, 2, 1))
        report = compare_oracles(*case(values, np.ones_like(values), p=p), .5, recent_tokens=2)
        bounds = report["methods"][POOLED]["cutoff_tie_head_bounds"]
        self.assertEqual(bounds["minimum_retained"], [[4, 4]])
        self.assertEqual(bounds["maximum_retained"], [[8, 8]])

    def test_empty_mutable_sets_are_explicitly_noninterpretable_without_a_map(self):
        inputs = case()
        with patch(MODULE + "controlled_map", side_effect=AssertionError("empty fit")):
            scores, metadata = make_oracles(*inputs, recent_tokens=12)
        self.assertEqual(metadata["mutable_tokens"], 0)
        self.assertFalse(metadata["pooled_full_map"]["map_evaluated"])
        for values in scores.values():
            np.testing.assert_array_equal(values, inputs[1].scores)
        contrast = compare_oracles(*inputs, 0, recent_tokens=12)["regional_contrast"]
        self.assertFalse(contrast["pure_regional_contrast_interpretable"])
        self.assertIn("no_mutable_positions", contrast["confounding_reasons"])

    def test_input_arrays_unchanged_and_bad_shapes_fail(self):
        inputs = case()
        copies = [inputs[0].values.copy(), inputs[1].scores.copy(), inputs[2].values.copy()]
        make_oracles(*inputs)
        for a, b in zip((inputs[0].values, inputs[1].scores, inputs[2].values), copies):
            np.testing.assert_array_equal(a, b)
        with self.assertRaisesRegex(ValueError, "shapes"):
            make_oracles(inputs[0], inputs[1], FullExactDiagnostic(inputs[2].partition,
                         np.repeat(inputs[2].values, 2, axis=1)))

    def test_nonfinite_map_result_is_rejected(self):
        def broken(source, target, values, *args):
            mapped, stats = controlled_map(source, target, values, *args)
            mapped[:] = np.inf
            return mapped, stats
        with patch(MODULE + "controlled_map", side_effect=broken), self.assertRaisesRegex(ValueError, "finite"):
            make_oracles(*case())

    def test_weak_order_invariant_failure_is_rejected_not_confounded(self):
        def broken(source, target, values, *args):
            mapped, stats = controlled_map(source, target, values, *args)
            return mapped[..., ::-1], stats
        with patch(MODULE + "controlled_map", side_effect=broken), self.assertRaisesRegex(ValueError, "weak order"):
            make_oracles(*case())

    def test_equal_source_split_is_rejected_even_if_output_is_nondecreasing(self):
        values = np.tile(np.arange(4, dtype=np.float32), 3)[None, None]
        values[..., 4:] = 1
        def broken(source, target, values, *args):
            _, stats = controlled_map(source, target, values, *args)
            return np.broadcast_to(np.arange(values.shape[-1], dtype=np.float32), values.shape), stats
        with patch(MODULE + "controlled_map", side_effect=broken), self.assertRaisesRegex(ValueError, "split equal"):
            make_oracles(*case(values, np.ones_like(values)))

    def test_wrong_total_budget_is_rejected(self):
        def broken(*args, **kwargs):
            keep, report = select_logical(*args, **kwargs)
            report["retained_pairs"] += 1
            return keep, report
        with patch(MODULE + "select_logical", side_effect=broken), self.assertRaisesRegex(ValueError, "exact total"):
            compare_oracles(*case(), .5)

    def test_tie_sensitivity_does_not_change_scores_or_invoke_extra_oracles(self):
        for primary in ("stable", "reverse", "random"):
            with patch(MODULE + "make_oracles", wraps=make_oracles) as build:
                report = compare_oracles(*case(), .5, tie_break=primary, seed=29)
                self.assertEqual(build.call_count, 1)
            for sensitivity in report["regional_contrast"]["tie_sensitivities"].values():
                self.assertTrue(sensitivity["score_only"])
                self.assertFalse(sensitivity["downstream_generation_performed"])
                self.assertEqual(sensitivity["tie_seed"], 29)
                # With no cutoff ties all resolutions are the exact same mask.
                self.assertEqual(sensitivity["methods"][POOLED]["mask_disagreement_fraction_vs_primary_tie_break"], 0)


if __name__ == "__main__":
    unittest.main()
