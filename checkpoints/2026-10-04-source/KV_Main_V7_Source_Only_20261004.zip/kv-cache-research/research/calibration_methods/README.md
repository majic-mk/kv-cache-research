# Regional calibration controls: CPU implementation

Status: synthetic software validation only. No model was loaded, no checkpoint was
downloaded, no GPU was used, and no rental/payment was made. No scientific
improvement, physical memory saving, or novelty is claimed.

## What was already present, and what is new

`../diagnostics/echo_calibration/reference.py` already supplies the audited
float32, independently sorted quantile map, basic oracles, clipping diagnostics,
and reconstruction-cost proxy. This package imports that implementation rather
than replacing it. `echo_pilot` already has the four author/reference arms,
context/query input separation, captures and common sink/recent protection.

Missing controls implemented here:

- A frozen common microchunk partition with explicit original-key denominator
  indices, context/region provenance and fingerprint checks
- Equal-shaped first/random-without-replacement/uniform-stratum anchor plans,
  predetermined seeds, a reconstruction-input cap including every prompt token,
  and equal-pass/input-length/attention-pair-proxy checks
- Anchor-only per-layer/head pooled mapping and no-calibration control; selected
  exact scores replace anchors in both. Unobserved exact labels cannot enter the
  deployable transform's typed interface
- Explicit float32/BF16-RNE/FP16 storage controls; separate author-left and
  duplicate-target-mean tie handling; support clipping diagnostics by region and
  an optional reject-out-of-support check
- Fixed-total logical selection with sink/recent union protection deducted from
  that total, stable/reverse/seeded tie sensitivity, layer/head/region allocations,
  and possible regional retained-count bounds at tied cutoffs
- A separately imported diagnostic-only full-exact path. The v2 pooled-full-map
  control uses all mutable exact marginals per layer/head. Its regional scale oracle retains
  virtual within-region weak ordering; its rank oracle retains each baseline
  regional histogram. Exact anchors, prefix and protected tokens are excluded
  BEFORE transforming either oracle. This fixes a subtle experimental hazard:
  permuting a whole region and then overwriting exact anchors changes histograms
  and invalidates the supposed rank-only control
- Actual pooled/regional/output-cast exact multiset checks, duplicate/tie/support
  counts, source-order checks, cutoff head-allocation bounds and score-only
  stable/reverse/seeded-random sensitivities. Numerical or tie confounds visibly
  block pure regional attribution; exact ranks never break source ties. See the
  [v2 predeclared protocol](../calibration_pooled_control_protocol_v2.md)

Complex regional/shrunk/adaptive maps, document-boundary allocation, learned
scorers, GPU kernels and model-runtime integration are intentionally absent. The
main hypothesis must survive these simple controls before those are justified.

## Run from repository root

```sh
python -m unittest discover -s research/calibration_methods/tests -v
python -m research.calibration_methods.synthetic_smoke
python -m compileall -q research/calibration_methods
```

Dependencies are the already available NumPy and Python standard library. The
package is source-tree-only, consistent with the existing diagnostics; the root
wheel configuration currently packages only `kv_harness`.

`synthetic_results.json` is historical pre-v2 output; running the second command
now emits the expanded diagnostic report. Do not overwrite the historical record
while treating its old hash as current. Its
constructed examples distinguish an imposed cross-region scale change from an
imposed within-region rank reversal. Values there are logical mask agreement
with synthetic exact scores, never benchmark accuracy.

## Minimal method-side use

```python
from research.calibration_methods import (
    AnchorObservations, Microchunk, Partition, VirtualScores,
    calibrate, plan_anchor_matrix, select_logical,
)

# Hash ONLY frozen context tokens. Region labels must be fixed/context/prefill-only.
partition = Partition(
    context_sha256=actual_context_token_hash,
    token_count=len(context_tokens), prefix_length=prefix_length,
    chunks=tuple(Microchunk(start, end, measured_prompt_tokens)
                 for start, end in frozen_microchunk_bounds),
    region_ids=tuple(context_only_region_ids), region_source="fixed_position",
    sink_tokens=4,
)
plans = plan_anchor_matrix(partition, count=4, reconstruction_token_cap=2048,
                           random_seeds=(7, 11, 29))
virtual = VirtualScores(partition, virtual_scores_float32)  # [layers, heads, tokens]
for plan in plans:
    # Perform exactly these replays; do not expose other exact labels here.
    exact = AnchorObservations(plan, selected_replay_scores_in_token_index_order)
    result = calibrate(virtual, exact)
    keep, audit = select_logical(result.scores, partition, .75, recent_tokens=128)
```

For illustrative measured overhead 13 and four passes, each anchor may have at
most 499 context tokens under a 2048 total-input cap: `4 * (499 + 13) = 2048`.
Four 512-context-token replays cost 2100 input tokens and are rejected. The actual
tokenizer and frozen replay IDs determine overhead; 13 is a synthetic example.

First-four, random-four and uniform-four use the same complete partition.
The short tail remains scored but is ineligible as an anchor if its replay shape
differs. Different prompt overhead can also exclude a chunk. These exclusions are
observable from the partition and selected IDs. Uniform means eligible-chunk
strata; it is not document stratification. One long first anchor versus four
short anchors is a separate comparison because its scoring partition and replay
costs differ. Equal token count does not prove equal compute or build latency.

## Precision, tie and oracle boundaries

- `Precision()` keeps storage float32. `Precision.author_storage_like()` keeps
  virtual anchors float32 but rounds other inputs/output to BF16. This is a named
  storage ablation, not Torch/CUDA/QK/softmax parity or recovery of lost precision
- The original `author_left` behavior is unchanged. E.g. duplicate maximum knots
  `[1,2,2]` with targets `[10,20,30]` map 2 and 99 to 20. `collapse_mean` maps them
  to 25 and is explicitly an alternative control
- No extrapolation is silently introduced. Every non-anchor region records input
  counts below/above anchor support and duplicate source knots. A positive scale
  diagnostic can still be a clipping/tie artifact and requires these ablations
- `diagnostics.FullExactDiagnostic` is not exported through the deployable API.
  Exact labels on selected anchors must match the baseline. Oracles need at least
  two mutable tokens in each nonempty region; reject unsuitable frozen regions
  rather than relabeling regions after observing results
- Oracles leave the same anchor/prefix/protected values unchanged and apply the
  same keep budget. Rank-only histograms are asserted exactly; allocation is
  invariant absent cutoff ties. Tied-cutoff allocation is explicitly flagged
- Full exact KVzip scores are not evidence/gold importance. Neither mask recall,
  correlation nor marginal agreement establishes downstream quality
- These are strict software contracts, not a security boundary or proof that a
  caller did not mislabel provenance. In particular a hash binds declared plan
  metadata, not execution of the scorer or actual replay token strings. A runtime
  must freeze/check replay IDs and verify observed forwards independently

## Smallest remaining runtime integration

Suggested ownership for the next worker: a new `echo_pilot/calibration_runtime.py`
plus `echo_pilot/tests/test_calibration_runtime.py`; only then a narrow, coordinated
extension of `echo_pilot/runtime.py` and `echo_pilot/contracts.py`. Do not edit the
concurrently owned analysis, CLI or stage modules without coordination. No GPU is
required to implement the adapter contract and mock/NumPy tests below.

1. **Prepare once from context only.** Construct common complete microchunks and
   one frozen replay-ID list per chunk from the actual pinned tokenizer. Use the
   same context-only prompt convention and overhead class for eligible anchors,
   without concatenating disjoint snippets. Hash actual prompt/replay IDs and
   preserve context SHA, boundaries, n_sink and RoPE offsets. Author first-chunk
   EchoPress must remain a separate unchanged baseline; common-microchunk first
   is explicitly a policy adaptation
2. **Virtual scores for all fixed chunks.** Subclass the pinned EchoPress prepare/
   finalize hooks, retaining all `_chunks` and `_pairs`. `_prefill_hook` and
   `_chunk_scores` already operate over those fixed bounds; capture pre-storage
   scalar outputs `[layers, 1, heads, tokens]`, then explicitly squeeze batch=1
   before constructing `VirtualScores`. Verify source-token offsets, head groups,
   n_prompt and denominator sinks plus complete chunk, not selected anchors
3. **Sparse exact replays.** For each chosen original chunk ID set both
   `start_idx` and `end_idx` to its absolute bounds; do NOT advance a cursor only
   through chosen chunks. Reuse the pinned KVzip hook for that whole replay, check
   every layer's cache length is restored, and capture native/pre-storage score
   values before assignment. The observed forward lengths must equal prefill plus
   the selected replay lengths. Return only selected labels to `AnchorObservations`
4. **Separate expensive diagnostic builder.** An explicit diagnostic mode runs
   all exact microchunks and produces `FullExactDiagnostic`; label and charge all
   replays. This path must never supply full labels to candidate construction,
   anchor selection, tuning or claimed deployable build-cost accounting. Reusing
   expensive diagnostics to prototype masks is allowed only with honest cost
   labeling; independently replay sparse anchor arms for deployable timing
5. **Apply masks, not rescoring.** Convert the selected `[L,H,N]` boolean keep
   mask to one `(batch=0, head, token)` pruned-index tuple per layer and install
   `masked_key_indices`. Do not call `compress_post()` afterwards, which would
   choose another backend-dependent mask. Copy/reinstall masks into independent
   per-query cache clones, preserve exact counts/protection, and use existing
   common greedy generation/metrics. Selection is an explicitly stable-control
   adaptation, not bit-identical author two-stage torch.topk
6. **Minimum CPU/mock tests.** Sparse noncontiguous chunks use their original
   offsets; denominator key sets remain policy-independent; replays and prompt
   token counts match the plan; leftover cache lengths are rejected; shape/device
   conversion and mask round-trip preserve every bit; impossible protected
   budgets fail; exceptions remove hooks/restore forwards; no query/gold field
   enters the builder; no diagnostic full-label object reaches deployable APIs;
   no model/dependency import or download occurs during dry-run. Verify masks
   work with the existing in-place attention patch before GPU experiments

Actual native GPU casts, scalar-scoring parity, exact-tokenizer replay semantics,
model hooks, model quality, real memory and synchronized time remain untested.
The existing capture cannot retroactively yield common-microchunk exact scores;
native-dtype scores converted to float32 cannot restore lost information.

## Can the CNY100 proposal test this hypothesis?

**It can fund a conditional screening attempt; it is not yet demonstrated that
the complete experiment fits, and it cannot promise a positive result.** The
existing plan is a maximum 28 GPU hours / CNY100 all-in, with first gate limited to
4 hours / CNY20. Those are caps from `../proposed_budget.json`, not measured work
throughput or a newly verified provider quote. No expense was incurred here.

The first three development contexts are a compatibility smoke, not evidence
for/against a two-point quality effect. After compatibility, the smallest useful
screen is one frozen natural-workload subset with full KV, author EchoPress,
common-partition baseline, scale/rank oracles and full exact reference; try one
eviction setting first. All microchunk exact labels are expensive but can be
collected once per context for offline diagnostic masks, then tested by actual
query generation from independently cloned frozen context caches. Additional
thresholds/recency/tie choices are cheap in score space but each quality evaluation
still costs generation. Three seeds, multiple retention ratios, 32–64 contexts,
strong learned baselines and a second architecture multiply work substantially.

Use measured full build/query times and setup time from gate A to project the
remaining predefined matrix before releasing another gate. Include every replay,
prompt, failed build, load and clone, plus provider time while downloading or
compiling. An inability to fit the defined matrix under the remaining cap is a
stop/reduce-scope result, never permission to exceed CNY100. Natural-context paired
uncertainty, not synthetic mask metrics or treating related questions as independent,
determines whether a two-point signal is even resolvable. Without timing and
variance observations, claim only screening feasibility, not statistical power or
completion within budget. Physical-memory usefulness additionally needs a real
compaction backend; this masked-dense-cache adapter cannot establish it.

Keep the hypothesis only if regional scale correction recovers a reproducible
natural downstream deficit that rank-only, float32 storage, recency, fixed
partitions and simpler pooled uniform anchors do not already explain. Otherwise
reject the calibration mechanism or complex-method claim as appropriate.
