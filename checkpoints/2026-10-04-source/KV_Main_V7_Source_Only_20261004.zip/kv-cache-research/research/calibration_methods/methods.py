"""Anchor-budget-feasible CPU score transforms. No region-specific learned maps."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import random

import numpy as np

from research.diagnostics.echo_calibration.reference import quantile_map
from .contracts import (AnchorObservations, AnchorPlan, Partition, VirtualScores,
                        integer, require, score_array)


def plan_anchors(partition: Partition, count: int, policy: str, seed: int = 0):
    """Choose complete equal-shaped replays from the same frozen partition.

    The first microchunk defines the eligible shape; shorter tails or different
    prompt overheads are excluded explicitly, never padded or concatenated.
    Uniform chooses one midpoint from each equal-count stratum of eligible
    chunks. Random is without replacement. None reads virtual/exact scores.
    """
    require(type(partition) is Partition, "An explicit Partition is required")
    integer(count, "count", 1)
    integer(seed, "seed")
    candidates = [i for i, c in enumerate(partition.chunks) if c.shape == partition.chunks[0].shape]
    require(count <= len(candidates), "Insufficient equal-shaped chunks for the requested anchor budget")
    if policy == "first":
        chosen = candidates[:count]
    elif policy == "random":
        chosen = random.Random(seed).sample(candidates, count)
    elif policy == "uniform":
        chosen = [candidates[(2 * k + 1) * len(candidates) // (2 * count)] for k in range(count)]
    else:
        raise ValueError("policy must be first, random or uniform")
    return AnchorPlan(partition, tuple(sorted(chosen)), policy, seed)


def assert_equal_budget(plans):
    """Token/shape/attention-pair-proxy equality, NOT measured compute equality."""
    plans = tuple(plans)
    require(plans and all(type(p) is AnchorPlan for p in plans), "Nonempty AnchorPlan collection required")
    require(len({p.partition.fingerprint for p in plans}) == 1, "Scoring partitions/denominators differ")
    require(all(p.cost() == plans[0].cost() for p in plans), "Anchor replay budgets/shapes differ")
    return plans[0].cost()


def plan_anchor_matrix(partition, count, reconstruction_token_cap, random_seeds=(0, 1, 2)):
    """Freeze first/uniform and predetermined random controls under a token cap.

    The cap counts every prompt/suffix/postfix token on every replay. E.g. four
    512-context-token chunks with a 13-token prompt do NOT fit a 2048 input-token
    cap; four 499-context-token chunks do. This is still not a wall-time cap.
    """
    integer(reconstruction_token_cap, "reconstruction_token_cap", 1)
    require(type(random_seeds) is tuple and random_seeds, "Provide a nonempty frozen random seed tuple")
    require(all(type(s) is int and s >= 0 for s in random_seeds) and
            len(set(random_seeds)) == len(random_seeds), "Random seeds must be unique nonnegative integers")
    plans = (plan_anchors(partition, count, "first"), plan_anchors(partition, count, "uniform"),
             *(plan_anchors(partition, count, "random", seed) for seed in random_seeds))
    cost = assert_equal_budget(plans)
    require(cost["reconstruction_input_tokens"] <= reconstruction_token_cap,
            "Replay inputs including prompt overhead exceed the reconstruction token cap")
    return plans


def round_storage(values, dtype):
    """CPU storage-rounding control, not a simulation of low-precision kernels.

    BF16 uses IEEE binary32 -> BF16 round-to-nearest, ties-to-even, then returns
    float32. QK products, reductions, flush-to-zero and runtime casts need GPU
    parity tests independently. Overflow introduced by rounding is rejected.
    """
    a = np.array(values, dtype=np.float32, copy=True)
    require(bool(np.isfinite(a).all()), "Precision-control input must be finite")
    if dtype == "float32":
        pass
    elif dtype == "bfloat16":
        bits = a.view(np.uint32)
        bits = (bits + np.uint32(0x7fff) + ((bits >> np.uint32(16)) & np.uint32(1))) & np.uint32(0xffff0000)
        a = bits.view(np.float32)
    elif dtype == "float16":
        with np.errstate(over="ignore", invalid="ignore"):
            a = a.astype(np.float16).astype(np.float32)
    else:
        raise ValueError("Unsupported storage dtype")
    require(bool(np.isfinite(a).all()), "Storage rounding overflowed; do not silently select infinities")
    return a


@dataclass(frozen=True)
class Precision:
    anchor_virtual: str = "float32"
    nonanchor_virtual: str = "float32"
    exact_anchor: str = "float32"
    output: str = "float32"

    def __post_init__(self):
        require(all(x in ("float32", "bfloat16", "float16") for x in asdict(self).values()),
                "Unsupported precision control")

    @classmethod
    def author_storage_like(cls, dtype="bfloat16"):
        """Generalizes author's float32 virtual anchor/native other-score storage.

        Multiple anchors and fixed microchunks remain adaptations, not author
        parity. True float32 exact inputs must have been captured before storage.
        """
        return cls("float32", dtype, dtype, dtype)


def controlled_map(source, target, values, tie_policy="author_left", clipping="clip"):
    """Audited map plus an explicitly non-author duplicate-knot ablation.

    ``collapse_mean`` averages sorted target quantiles associated with each
    duplicate source knot, then linearly interpolates unique knots. It cannot
    reverse order. Endpoint clipping remains explicit under both tie policies.
    """
    require(tie_policy in ("author_left", "collapse_mean"), "Unsupported map tie policy")
    require(clipping in ("clip", "reject"), "clipping must be clip or reject")
    # Shared audited function performs all shape/nonfinite/minimum-anchor checks.
    baseline = quantile_map(source, target, values)
    s, t, v = (np.asarray(a, dtype=np.float32) for a in (source, target, values))
    low, high = s.min(-1, keepdims=True), s.max(-1, keepdims=True)
    below, above = v < low, v > high
    if clipping == "reject":
        require(not bool(below.any() or above.any()), "Evaluation values fall outside anchor support")
    diagnostics = {"below_support_count": below.sum(-1).tolist(),
                   "above_support_count": above.sum(-1).tolist(),
                   "evaluation_count_per_row": v.shape[1],
                   "duplicate_anchor_count": [len(row) - len(np.unique(row)) for row in s],
                   "tie_policy": tie_policy, "clipping": clipping}
    if tie_policy == "author_left":
        return baseline, diagnostics
    result = np.empty_like(v)
    for row in range(len(s)):
        unique, starts, counts = np.unique(np.sort(s[row]), return_index=True, return_counts=True)
        target_sorted = np.sort(t[row])
        means = np.array([target_sorted[a:a + n].mean(dtype=np.float64) for a, n in zip(starts, counts)])
        result[row] = np.interp(v[row], unique, means)
    return result, diagnostics


@dataclass(frozen=True)
class CalibrationResult:
    plan: AnchorPlan
    scores: np.ndarray
    precision: Precision
    tie_policy: str
    diagnostics: dict

    def __post_init__(self):
        object.__setattr__(self, "scores", score_array(self.scores, "calibrated scores"))


def calibrate(virtual: VirtualScores, anchors: AnchorObservations, *, precision=Precision(),
              tie_policy="author_left", clipping="clip", enabled=True):
    """Pooled per-layer/head map using ONLY observed anchor labels.

    Exact anchor overrides are retained; prefix values are left untouched apart
    from explicitly requested storage casts. No map fitting uses any non-anchor
    exact value, region-specific target histogram, downstream query or label.
    ``enabled=False`` is the no-calibration control, with identical anchor work.
    """
    require(type(virtual) is VirtualScores and type(anchors) is AnchorObservations,
            "Deployable calibration accepts only VirtualScores and AnchorObservations")
    require(type(precision) is Precision and type(enabled) is bool, "Invalid calibration controls")
    require(tie_policy in ("author_left", "collapse_mean") and clipping in ("clip", "reject"),
            "Invalid tie/clipping controls")
    plan = anchors.plan
    require(plan.partition.fingerprint == virtual.partition.fingerprint,
            "Virtual and exact anchors have different contexts/partitions/denominators")
    require(virtual.values.shape[:2] == anchors.values.shape[:2], "Layer/head dimensions differ")
    index = np.array(plan.token_indices)
    mutable = np.arange(virtual.partition.prefix_length, virtual.partition.token_count)
    mutable = mutable[~np.isin(mutable, index)]
    source = round_storage(virtual.values[..., index], precision.anchor_virtual)
    exact = round_storage(anchors.values, precision.exact_anchor)
    out = round_storage(virtual.values, precision.nonanchor_virtual)
    diagnostics = {"evidence_class": "cpu_score_transform_only", "oracle": False,
                   "calibration_enabled": enabled, "anchor_plan_sha256": plan.fingerprint,
                   "partition_sha256": plan.partition.fingerprint, "replay_cost_proxy": plan.cost(),
                   "precision": asdict(precision), "support_by_region": {}}
    if enabled and len(mutable):
        mapped, stats = controlled_map(source.reshape(-1, len(index)), exact.reshape(-1, len(index)),
                                      out[..., mutable].reshape(-1, len(mutable)), tie_policy, clipping)
        out[..., mutable] = mapped.reshape(out[..., mutable].shape)
        diagnostics["pooled_support"] = stats
        r = np.asarray(plan.partition.region_ids)
        for region in np.unique(r[mutable]):
            indices = mutable[r[mutable] == region]
            _, region_stats = controlled_map(source.reshape(-1, len(index)), exact.reshape(-1, len(index)),
                                            round_storage(virtual.values[..., indices], precision.nonanchor_virtual)
                                            .reshape(-1, len(indices)), tie_policy, clipping)
            diagnostics["support_by_region"][str(region)] = region_stats
    out[..., index] = exact
    out = round_storage(out, precision.output)
    return CalibrationResult(plan, out, precision, tie_policy, diagnostics)
