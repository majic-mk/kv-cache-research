"""CPU-only, query-blind calibration controls; no model-quality claim.

Oracles intentionally live in the separate ``diagnostics`` module and are not
part of this deployable-method interface. Nothing here executes a model.
"""

from .contracts import AnchorObservations, AnchorPlan, Microchunk, Partition, VirtualScores
from .methods import CalibrationResult, Precision, calibrate, plan_anchor_matrix, plan_anchors
from .selection import select_logical

__all__ = ["AnchorObservations", "AnchorPlan", "Microchunk", "Partition", "VirtualScores",
           "CalibrationResult", "Precision", "calibrate", "plan_anchor_matrix", "plan_anchors", "select_logical"]
