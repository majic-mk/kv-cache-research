# Independent admission review: one exploratory 2B/BF16 CPU qualification

Date: 2026-10-03 UTC. Reviewer scope: protocol continuity, pre-outcome numerical controls, exact text-checkpoint provenance, and executable admission conditions. This is not a competence result or a compression-effect evaluation.

## Current decision

**STOP: the admitted single attempt failed pretrained numerical qualification after 2/16 cells.** The parent released the reviewed run at 17:13:20 UTC. Full and exact both answered red correctly on d01/A1, but exact-schedule answer-score, distribution and cache-state parity failed the unchanged prospective limits. Fourteen cells remain unrun. There is no qualified substrate, compression-harm result or permission for another model/precision/tolerance attempt.

The pre-run admission was legitimate and limited to one guarded attempt after all preparation gates passed. Its exact review bytes are retained in `diagnostics/hybrid_cpu_competence_v3/admission_review_pre_run.md`, SHA-256 `a9c7c5958e293c664734849bee5c2ed49eba14625ad49deb900791d3c89945b6`, bound by the release receipt. This main report now adds the observed result without altering that snapshot.

The parent explicitly bounded the numerical bridge to tiny random models/operators and the new 2B exact controls. The additional pretrained 0.8B/BF16 bridge suggested in the selection review is **not performed and is not claimed to have passed**. There is no extra outcome-based 0.8B retry.

## Already verified

- Both historical freezes remain byte-valid: v1 manifest `12a2f3c5ca34c0180814a51d8400d0163f77d2c163a7df5bbd90ef72922060df` (11 protected files) and v2 manifest `8c59ffc15e6683c37b24e828f40dbb7167810dbce77c96523f48cccda8dd77b5` (14 protected files). The reviewer independently recomputed all protected-file hashes; there were no mismatches.
- The 0.8B v2 result is a preserved failure: d01/A1 full recomputation produced blue, gold red; one of sixteen cells completed. The remaining fifteen did not run. There is no historical full/exact parity result to carry forward and no HYPIC quality result.
- The official cached 2B source header describes 632 tensors. Exactly 320 names begin `model.language_model.`; their payload is 3,763,655,360 bytes. Of 1,881,825,088 language parameters, 2,592 are stored FP32 and the rest BF16. No assumption that every original tensor is BF16 is valid.
- The installed pinned Qwen implementation explicitly promotes GDN query/key/value/gates to FP32 for chunk and recurrent computation and returns FP32 recurrent state; it casts the branch output back to the input dtype. Its no-loss language-model forward returns logits in the projection dtype without an automatic FP32 upcast.

## Admission checks and fixed constraints

1. **Prospective freeze.** The 2B/BF16 choice must be identified as exploratory selection after the 0.8B failure. The numerical contract and implementing files must be hashed before any BF16 tiny-model or pretrained outcome. A tiny test can reject those fixed thresholds, but cannot be used to tune and relabel them as pre-outcome. Record execution times and hashes.
2. **Unchanged task.** Reuse all v2 fixture bytes, labels, splits, order, scoring, EOS rule, and eight-token generation cap. Change only model-specific metadata and declared precision. Validate all 64 contexts against the actual pinned 2B tokenizer/config/template. Assert the existing text and input identities where applicable; no group or prompt may be replaced.
3. **Observable numerical requirements.** Model outputs, cache tensors, and all statistics must be finite. Compute probability/log-probability/TV/difference statistics in FP32 or higher from the actual outputs, not directly in BF16. Full/exact controls require identical complete greedy token sequences, EOS outcome and decoded answer; loose logits or endpoint allclose cannot waive an answer disagreement. Report candidate sums, candidate margin and relevant teacher-forced steps. Require scheduling noise below 0.01 nat for both candidate sums and the candidate margin, independently of any broader component tolerances. Near ties cannot excuse disagreement or support a 0.1-nat downstream effect.
4. **Component controls and repeat controls.** Predetermine FP32-reference operator tests, their bounded input distributions, error norms and limits. Distinguish BF16 input/projection rounding from FP32 accumulation. Require expected cache channel counts, dtypes, shapes, positions, finite values, independently verified clones and no mutation of the scoring reference. Compare like schedules across repeated execution as well as monolithic versus exact cached execution. All failures stop the route.
5. **Truthful, exact asset derivation.** A derived safetensors file may omit only vision and MTP. The source stream must include every official shard byte and match the pinned complete LFS SHA-256 `aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`. The original header SHA and complete key set must match the pinned header/index. For every retained tensor, verify source byte range, source name, destination name, dtype, shape, exact byte length and per-tensor SHA against reread destination bytes. Retention/renaming must be one-to-one and exhaustive over all 320 language tensors. Preserve the official source config/tokenizer bytes; explicitly label derived weight/header metadata and do not represent the derived file hash as the official shard hash. Ordinary supported `from_pretrained` loading must report no missing/mismatched/errored language keys; tied output embedding handling must be explicit. A byte projection is not permission for a special execution loader.
6. **Resources and stop semantics.** Preserve 8 GiB process RSS, 9 GB host budget, 5 GB free-disk reserve, 15-minute load cap, and 30-minute initial-probe envelope including load and any attempted work. Keep one CPU thread configuration, no GPU, no FP32 2B fallback, no cleanup or larger checkpoint. Check actual free blocks before staging and before execution, plus reserve during both. Do not retain a full 4.548 GB source shard and derived 3.764 GB output simultaneously. Stop at the first integrity, numerical, resource or full-competence failure; preserve partial/failing work and explicit status for every unrun cell.
7. **Narrow endpoint.** At most the original sixteen initial cells: d01/d05 × A1/A2/U1/U2 × full/exact in frozen order. Both changed-prefix pairs and all four unrelated contexts must be correct. A pass establishes only a usable declared mixed-precision substrate. It does not authorize a reuse matrix, repair implementation, held-out inference, paper claim, model ladder, or tolerance adjustment.

## Concrete implementation issue sent to the author

The v2 runner calls `logits.log_softmax` and `logits.softmax` directly. This was FP32 in v2 but becomes BF16 under a direct BF16 load. At ordinary log-probability magnitudes, BF16 reporting granularity can itself exceed a 0.01-nat budget. The v3 runner must explicitly upcast before these statistics; actual greedy predictions remain those of the unchanged mixed-precision model. This is a measurement-correctness issue, not evidence that any BF16 control passes or fails.

## Prospective numerical-contract review

Reviewed `protocols/hybrid_cpu_quality_v3/numerical_contract.json` before any reported BF16 forward. After a pre-outcome clarification limiting repeated/chunked tests to tiny models, its frozen SHA-256 is `34e903f80162b661eb504e26b16273e5fb5aeaa361a728dd3d69c6a26a7f88f3`, timestamped 16:51:31 UTC. The following combination is acceptable for a conservative substrate screen:

- Official FP32 chunk-versus-sequential and recurrent-state controls use 1e-4 absolute/relative limits. BF16 operator outputs allow absolute/relative 1/128 against FP32 kernels fed the same BF16-rounded inputs. This separates input rounding from the recurrent accumulation path.
- Tiny full FP32 scheduling controls retain 1e-4 logit/endpoint/TV and candidate-sum/margin limits, with zero greedy disagreement.
- BF16 exact schedules require logit allclose at 0.01/0.01, TV at most 0.0025, recurrent endpoint allclose at 0.002/0.02, and conv/KV endpoint allclose at 0.01/0.02. These component limits are relatively permissive near zero and do not alone establish parity. The additional strict candidate-sum **and margin** noise below 0.01 nat and identical complete greedy token sequences are therefore essential and must be conjunctive in the runner.
- Three bitwise repeats per tiny schedule test repeatability. The tiny tests include unequal value/key head counts, multiple GDN/full-attention layers, irregular scheduling, and positions across the official 64-token chunk boundary. Chunked/repeated tiny controls must not silently expand the pretrained qualification beyond the original sixteen full/exact cells.
- The semantic BF16-versus-FP32 tiny comparison uses BF16-rounded weights promoted back to FP32, so it measures arithmetic-path disagreement separately from checkpoint rounding. Its 0.025/0.02 logit and 0.01-TV limits are operator/graph checks, not evidence of 2B FP32 answer equivalence. Cross-dtype greedy equality is correctly descriptive rather than the exact-schedule gate.
- A top-two greedy margin at or below 0.02 nat is flagged, with no tie exemption or case removal. Finite tensors, truthful actual dtypes, independently cloned caches and unchanged scoring-source caches are required.

These are engineering limits justified by the intended 0.1-nat later sensitivity screen and BF16 precision, not a universal BF16 accuracy guarantee. They may prove too strict on the selected graph; that outcome must close this route rather than trigger post-outcome relaxation.

The first static runner review (SHA-256 `ab91d0b0be2b9d1345234e88fdf2736c24d182e505d106646be3bc4fd561825f`, no forwards yet) found that bitwise repeats compared prefill/candidate logits and prefill cache, but only greedy IDs on the greedy continuation. The contract promises bitwise logits/caches throughout. Requested pre-execution fixes: retain/compare each greedy step's logits and final greedy cache, explicitly enforce finite token log-probabilities/sums, verify the frozen runner hash before execution, and use an external timeout/resource guard. These are implementation-compliance fixes; no tolerance or input changes were authorized.

**Tiny-only execution admitted at 16:54 UTC.** Those fixes were independently verified in final runner SHA-256 `b68a345720a6d8b203fd04d3badfdd00601cb0395629692fe2b5d307e67e8398`, frozen at 16:54:20 UTC with zero BF16 forwards. The contract hash is unchanged. `watch_tiny_gate.py` polls every 0.2 seconds and stops on 8 GiB process RSS, 9 GB host unavailable memory, less than 5 GB free disk, or 1,800 seconds. Both files pass Python syntax compilation. This approval permits the single frozen random-only gate; it does **not** permit pretrained execution or imply that any numerical test passed. A caught numerical exception can leave a zero process exit code, so the authoritative outcome is the result JSON status together with the watchdog, never process success alone.

### Observed tiny result

The single run started at 16:55:42 UTC and completed at 16:55:52 UTC: **84/84 controls passed**, no second execution, no pretrained weights or forwards. Both contract and runner hashes independently match the freeze and result receipt. The original pre-run review is preserved as `protocols/hybrid_cpu_quality_v3/tiny_admission_review_pre_run.md`, SHA-256 `6b154ae6d32df3351b5fa0317eef07601a38689ca72fc620c4437ada5d14b932`.

- Tiny process wall time 9.9555 s; process high-water RSS 406,200,320 bytes. Clean external watchdog, maximum sampled host unavailable memory 2,569,637,888 bytes and minimum sampled free disk 9,182,273,536 bytes.
- Four BF16 full/exact and four BF16 full/chunked primary comparisons had zero recorded answer/greedy-logit delta, TV, candidate-sum delta, candidate-margin delta and greedy-token disagreement. All same-schedule repeats passed bitwise checks. Tiny endpoint differences remained within the fixed limits.
- FP32 full/exact candidate-sum and margin deltas reached only 4.76837158203125e-7 nat; full/chunked logit delta reached 5.960464477539063e-8. All fixed FP32 and semantic controls passed.
- Three of four tiny cases had a near-tie flag in each BF16 schedule comparison. All were retained and still required exact greedy agreement.

This establishes that the declared implementation can execute the required controls on tiny random graphs. It does not validate 2B pretrained arithmetic, task competence, wider-model peak memory, or compression quality. The 2B run must independently pass its own exact controls.

## Projection implementation review

Reviewed `diagnostics/text_only_asset_projection/{project_bytes.py,verify_projection.py,prepare_official.py,test_projection.py}` and the frozen metadata preflight. Independently reran all **14 synthetic byte-level tests** successfully; no pretrained load/forward occurred.

The projector validates contiguous source tensor offsets, exact dtype/shape byte lengths and unique JSON keys. It hashes the original 8-byte header length, raw header and all 632 payloads, including excluded tensors. It retains exactly 320 original language names and their original bytes/dtypes, while writing a newly declared derivative header. A separate no-Torch rereader checks every selected tensor against its stream-side hash and computes the derived-file hash. Corrupted selected/excluded bytes, gaps/overlaps, truncation, trailing bytes, header changes and on-disk corruption are exercised by the tests.

The preflight uses a meta-only official model to validate the actual official `PrefixChange` mapping from `model.language_model.*` to `model.*`, with all 320 unique parameter names/shapes accounted for and the 321st state-dictionary entry explicitly tied as `lm_head.weight` to `model.embed_tokens.weight`. It verifies five installed loader/model modules against the cached pinned official source archive. The source config/tokenizer/template bytes are retained and validated; the derivative is truthfully labeled, with separate original and derived hashes. This is a lossless storage projection, not a special execution loader or full-shard identity claim.

The projected file is 3,763,696,896 bytes. Preflight predicts 5,406,564,582 free bytes after the small config/tokenizer files, preserving the 5 GB reserve with a 128 MiB guard. The full source shard is never stored locally. The loader must still verify zero missing/mismatched/errored language keys when it performs the ordinary direct BF16 load.

### Observed acquisition and independent payload reread

The complete receipt at 16:58:55 UTC records all **4,548,221,488 source bytes** hashed to official LFS SHA-256 `aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1`. The independently reread derived file is exactly **3,763,696,896 bytes**, SHA-256 `42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`.

Using a separate standard-library verifier, this reviewer checked the source manifest's complete 632-record contiguous mapping against the cached official source header, selected set equality to all and only 320 `model.language_model.*` keys, preserved derived dtype/shape/name/offset declarations, every retained tensor's on-disk SHA against its stream-side source hash, the complete derived hash and exact EOF. All checks passed. No complete original shard exists on disk; its complete digest is established by the reviewed streaming implementation and retained execution receipt, not a claimed second independent re-download.

Acquisition total was 137.5458 s, including the author's full reread; peak streaming-process RSS 29,274,112 bytes. Free disk after the completion receipt was 5,404,561,408 bytes. An outer 1,800-second timeout and 1 GiB virtual-memory limit additionally bounded acquisition. The reviewer's extra complete derived reread took 7.95 s. These reads warm filesystem pages, so any later load timing must not be described as a cold-load benchmark.

## Final v3 task/token continuity

The v3 fixture bytes match v2 exactly. Template changes affect only model identity, source URL, revision and explanatory revision metadata; rendered text and generation instructions are unchanged. The validator preserves the narrow EOS-required scoring rule and all position/identity checks, adds a check that the actual 2B tokenizer configuration and standalone official template agree, and restricts authorized model cells to the original sixteen.

This reviewer independently reran the validator with the acquired 2B config/tokenizer/template. All **64 contexts passed**, and the resulting validation object exactly matches the retained v3 artifact. More strongly, the entire ordered list of 64 context records, including prompts' hashes, full input IDs, A/B/Q slices, candidate-plus-EOS IDs, gold labels, split and important-token span, is **identical to v2**. No held-out model forward was involved.

All **23 protected v3 files** verify against the final preparation freeze, SHA-256 `c549a6420d58fb94e70840466b575d1340d55fff021ffa65d1b97b22c0fcf471`. It truthfully records the known historical 0.8B failure and known tiny outcomes while distinguishing the earlier pre-tiny numerical freeze. Thirteen model-free protocol tests are recorded passing. The two historical freezes remain separately preserved; the old wrong answer is not reclassified by any new admission pass.

## Pretrained runner and release review

Reviewed all source in `diagnostics/hybrid_cpu_competence_v3/run_probe.py` (SHA-256 `1671d977f6e15c50b2facda20287186d69bea70164e7803af2464e5bb8978c8e`) and `watch_probe.py` (SHA-256 `01b2b80288660dad27f82813585ef6c07c8735ea7921d19be9224fe4d457924c`). No blocking implementation defect remains in these versions.

- The launch requires a release receipt with both parent and reviewer admission flags, bound runner/watchdog hashes, the final v3 freeze, historical freezes, asset receipts, derived-weight digest, a snapshot of this review, and one output identity. It creates all sixteen explicit cell records before admission checks or loading and refuses a silent rerun of an existing execution.
- Runtime admission verifies the tiny result's actual PASS status and clean watchdog rather than a zero exit code. It verifies full-stream/derived-disk receipts, rehashes the complete derivative and official small files, and rerenders all 64 tokenizer contexts before loading. It leaves 128 MiB additional disk headroom for bounded raw-logit artifacts.
- Loading uses ordinary official `Qwen3_5ForCausalLM.from_pretrained`, explicit text configuration, `dtype=bfloat16`, CPU/eager attention, local files only and no remote code. No special loader, FP32 staging, quantization, fallback or model choice exists. It requires no missing, unexpected, mismatched or errored loading keys, exactly 320 unique mapped names, 1,881,825,088 parameters, exact mapped shapes and a genuinely tied output head. Actual storage and loaded dtypes/bytes are separately recorded.
- Every model forward verifies finite BF16 logits and the expected 18 FP32 recurrent states `(1,16,128,128)`, 18 BF16 convolution histories `(1,6144,4)`, and six BF16 full-attention key/value pairs `(1,2,current_length,256)`. Cloning requires value equality and distinct pointers; scoring and exact-prefix source caches are checked unchanged.
- Full and exact are independently prefetched with explicit absolute positions. Scoring uses independent branches and FP32 log-softmax on actual BF16 outputs. The parity conjunction includes all first/candidate/greedy-step logits and TV, candidate sum and margin noise strictly below 0.01 nat, identical complete greedy token sequence/decoded answer/EOS, and all relevant prefill/candidate/greedy endpoint checks. Near ties are reported and cannot waive a failure.
- The first wrong normalized full answer stops before its exact arm. First parity/integrity/finite/dtype/resource failure also stops. Attempted forwards are persistently logged; remaining cells remain explicit. A pass requires all eight full contexts correct and all eight exact comparisons passing, then stops with substrate-only interpretation.
- The external watchdog checks instantaneous RSS and process high-water RSS, host unavailable memory, disk reserve, 900-second load time and the entire 1,800-second execution envelope. Final `ru_maxrss` catches a process peak missed between samples. The authoritative child status is recorded separately from process return code; interruption marks unfinished records explicitly.

Independently imported the two scripts without invoking `main` and tested the five watchdog rejection boundaries (RSS, HWM, host, disk, wall), clean boundary, serialization of Transformers' set-valued loading info, and final 23-file freeze validation. All passed; these checks perform no model loading or forward.

The runner may proceed **only after the parent explicitly releases the unchanged reviewed versions** and the receipt snapshots the exact admitted review. Any change to these source hashes requires review before execution. A runtime failure does not authorize a revised prompt, relaxed tolerance, precision rescue, checkpoint repeat, larger model, GPU, cleanup or follow-on matrix.

## Independent terminal-result review

The single reviewed run ended `STOPPED_INITIAL_GATE`; its watchdog has no resource stop. The reviewer independently inspected the cell ledger, detailed numerical checks, summary and watchdog, then notified the parent immediately.

- d01/A1 full recomputation: **red**, correct, IDs `[1114, 248046]`, EOS within cap. Candidate sums: red −0.12844314583344385 nat; blue −2.253190435527358 nat.
- d01/A1 exact prefix: **red**, correct, identical IDs and EOS. Candidate sums: red −0.14183759823208675 nat; blue −2.141537945601158 nat.
- Exact-minus-full candidate drift: **−0.013394452398642898 nat** for red and **+0.11165248992620036 nat** for blue. Gold-minus-other margin drift: **−0.12504694232484326 nat**. Both candidate checks and the margin check fail the strict 0.01-nat limit.
- First-step maximum logit delta **0.3125**, TV **0.012460077181458473** versus the fixed 0.0025 limit. All four teacher-forced candidate-step and both greedy-step logit checks fail; 16/18 recurrent, 16/18 convolution and 12/12 attention-KV prefill endpoint comparisons fail their fixed limits. Greedy and candidate endpoints also fail.
- The greedy-token equality condition itself passes. It does not waive the score/distribution/state failures. This directly demonstrates why answer identity alone was insufficient for admission.
- The correctly triggered stop retained **2 completed cells and 14 `not_run_gate` cells**. No d01/A2, unrelated-control, d05, held-out, reuse, donor or repair evaluation ran. A single correct full prompt does not establish the required eight-context competence gate.
- The process made **one ordinary load attempt and nine completed model forwards**, with 464 network-token positions. Measured ordinary load was 4.2273 s with warmed filesystem pages. External wall time was 35.0424 s; peak externally recorded RSS/HWM was 4,479,287,296 bytes, below the 8 GiB cap. Runtime key/dtype/tied-weight checks passed, and no resource rescue was needed.

The margin's scheduling drift exceeds even the unchanged future 0.1-nat sensitivity target. It therefore cannot be safely treated as negligible background error for that experiment. This conclusion does not rely only on conservative endpoint tolerances. The result establishes failure of the declared **2B/BF16 numerical substrate gate**, not a general impossibility for BF16, a new cache-compression effect, or a failure of the recurrent-conditioning hypothesis.

All three protocol freezes were independently reverified intact after the stop. Keep this negative result and the earlier 0.8B competence failure distinct and preserved. **Close this CPU route under the current authorization; no threshold relaxation, continued cells, FP32 rescue, larger model, GPU or follow-on matrix.**

## Scientific interpretation

The data are constructed mechanism fixtures, not a sampled natural benchmark. The initial two development groups are a deterministic admission screen, not a power analysis or population accuracy estimate. Full correctness and exact-control agreement are required for causal interpretability, but passing them says nothing about the size or existence of cross-prefix compression harm. BF16 full recomputation is the reference estimand; no equivalence to an unrun FP32 2B model may be claimed. The released-HYPIC comparator/source-semantics blocker remains unresolved.

## Review evidence

Read: `selection_decision_review.md`, `next_cpu_probe_decision.md`, `protocols/hybrid_cpu_quality_v2/{protocol.json,result_contract.json,template.json,validate_protocol.py,freeze_manifest.json}`, `diagnostics/hybrid_cpu_competence/{RESULTS.md,v2_run_report.json,run_probe.py,watch_probe.py}`, and the already-cached official 2B header/metadata. Inspected the installed Transformers Qwen3.5 source at pin `02d8fb9784e8f14a1251e4c992cd82a5762417c6`, specifically GDN FP32 promotion/state return and LM logits generation.

No model forward, tensor payload download, GPU operation, dependency install, cleanup, commit or push was performed by this reviewer.
