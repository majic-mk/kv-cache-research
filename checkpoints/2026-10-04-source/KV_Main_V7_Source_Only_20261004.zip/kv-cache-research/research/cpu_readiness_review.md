# Independent CPU readiness review before paid GPU

Date: 2026-10-03 UTC. Audited checkout: `ceacf572abec74cbed7a5b099d616222f9cef7ff` plus the audit files listed below. This review does not alter the existing runner, harness, preprocessing implementation, or `research/calibration_methods/`. No commit/push, package installation/upgrade, weights download, model inference, GPU allocation, or paid service was used.

## Decision

**Do not rent yet.** The source-level research and CPU contracts are useful and currently pass, but a successful dry-run is not an end-to-end analyzable experiment. Close the result-analysis bridge, freeze a smaller staged run manifest, finish asset/environment staging and establish controls for a newly created project instance before starting the paid clock. The next GPU use should be a bounded compatibility/quality diagnostic, not the whole generated `pilot16k` matrix or a memory/speed demonstration.

Current authority: cumulative project ceiling CNY100; project spend remains zero. The latest user instruction puts experiments last and expressly excludes existing AutoDL instances, which belong to other tasks. **Never start, stop, restart, modify, inspect private files on, or run workloads on those existing instances.** Use only a new resource explicitly identified with this project. Account-wide balance movement cannot be this project's cost meter because unrelated jobs may be running.

### What this audit adds beyond the existing reviews

The earlier audits already establish masked-dense memory, author partition/precision differences, pinned data, and the unproven calibration hypothesis. This review does not relabel those as new discoveries. New readiness evidence is:

1. Concrete failures at the pilot → evaluator and pilot → strict-harness interfaces, plus a minimal bridge contract
2. Exact current workload accounting from the frozen tokenizer/data: 12 smoke builds, then 130 development builds, then 250 heldout builds; no implicit warmups/repeats
3. Qwen3-specific memory/download estimates, replacing reliance on the older Qwen2.5 illustration
4. Query-length exposure of the fake-key mask: 448-token RepoBench smoke, up to 2,916 deferred query tokens in development
5. A cheap cross-split lexical screen: 512 development/heldout context pairs, maximum 5-token-shingle Jaccard 0.01315; no conspicuous lexical duplicate at the stated thresholds
6. An instance-ID-specific spend/stop design that respects other AutoDL workloads

## 1. Prioritized risks and closure evidence

### P0 — The result-analysis path is not connected

`echo_pilot/runtime.py:468–477` writes per-question records with `arm`, `eviction_ratio`, `text`, timing and cache diagnostics. `data_prep.metrics.evaluate()` requires exactly `question_id` and `prediction` for one arm/ratio. `kv_harness.results.validate_result()` expects its complete, different result schema. There is no pilot conversion/analysis entry point in the current CLI.

CPU reproduction, using a synthetic `fixture-q` / `return 1` response, produced:

- Raw pilot-shaped row → official metric: `ValueError: Expected exactly question_id and prediction text`
- Raw pilot-shaped row → harness: `ValidationError: result fields: missing=[...]`, including `cluster_id`, `metrics`, `workload`, `timing`, `resources`, `manifest_sha256`; the full exact error is saved in `diagnostics/cpu_readiness/result.json`
- Projecting one arm to `{question_id, prediction: text}` works; the synthetic perfect-match result is only a plumbing check
- Projecting multiple arms without grouping fails: `ValueError: Duplicate prediction question_id`
- Missing predictions fail closed as intended

This is an integration gap, not evidence that either component's isolated metric implementation is wrong. Without closing it, a paid run can emit `COMPLETE.json` but still require ad hoc, outcome-aware analysis code afterward.

**Smallest safe bridge, implement/test on CPU before rent:**

- Input: completed run directory, frozen data manifest, explicit task/preset/split; resolve the labels file and its hash from that manifest. Keep labels out of the scoring runtime
- First verify `COMPLETE.json`, manifest/artifact digests, no `FAILED.json`, frozen configuration, expected context/question IDs and hashes, build metadata and all required arm/ratio cells
- Use exact identity `(run, context_id, question_id, arm, eviction_ratio)`. Reject duplicates, wrong-context question IDs, extra/missing cells, mismatched context/query fingerprints, a full-KV mask, and a compressed mask with the wrong retained count
- Group by task/preset/split/arm/ratio, project `text` to `prediction`, call the pinned metric, retain unrounded per-question scores in [0,1]. Report task means in percent; never replace code similarity with raw exact match
- Pair the same question with full KV and with partition-matched KVzip; preserve `context_id` as bootstrap cluster. Full KV is one measured baseline per context, reused as a reference across ratio-specific analyses, not new independent observations
- Output auditable quality summary, per-question paired rows and bootstrap configuration, denominators, label/source/output hashes, and explicit `natural` versus `real_model` evidence dimensions
- If exporting to `kv_harness`, write its complete validated schema. Do not simply rename `natural` as the harness evidence class: in the harness, the run is `real_model`, while natural/controlled belongs in workload metadata. Only map measured quantities; unavailable memory/cost fields stay unmeasured. Do not manufacture phase timings or label cold/instrumented intervals as serving latency
- For cost export, choose and document a consistent scope. The recorded whole-arm wall interval can be apportioned over its actual observed questions, with clone/generation intervals and residual measured shared overhead, without double-counting builder/serialization time. Model load, environment setup/downloads and provider rental remain separately charged costs. The minimum release can remain quality-only rather than inventing a complete performance export

Required fixtures: two contexts, multiple questions sharing one context, all four arms, two ratios, shuffled input order, duplicate/missing cell, wrong label hash, wrong context association, tampered artifact, incomplete run, EOS/empty output, and inconsistent mask budget. A bootstrap test must not count ratios/repeats/questions as new contexts.

### P0 — The default next step expands too quickly, with no runtime spend controller

`configure.py:41` switches from one 50% eviction ratio to three ratios for `pilot16k`; `runtime.py:440–448` reconstructs every compressed cache independently per ratio. No timeout, cost cap, provider shutdown, workload admission estimate, resume, or automatic recovery is implemented. Exceptions create an incomplete run marker but do not stop provider billing.

The current schema also rejects a single-arm configuration, `warmups`, and `replicates`; those explicit rejection tests passed. Do not assume the generic harness's fixture warmups/repeats apply to this adapter.

**Closure:** freeze stage-specific context IDs and ratio sets before model outcomes; print total builds/replays/generation upper bounds; add a read-only expected-work/cost admission check plus an external, instance-scoped stop wrapper. A safe smaller configuration may retain all four mandatory arms and set `eviction_ratios=[0.75]` in a newly frozen development config. This is schema-compatible and leaves the original presets/data untouched. Do not quietly change a used config or choose the subset after inspecting model scores.

### P0 — A package version pin does not establish a Blackwell-ready executable environment

`requirements-gpu.in` is explicitly a proposal, with neither CUDA wheel variant nor complete hash-locked transitive artifacts. The environment verifier checks a complete installed version inventory, author source hashes and `cuda.is_available()`, then records device capability. It does not establish that an actual BF16 matmul/SDPA call works on the device, that deterministic kernels are available, or that the installed wheel supports SM120. Imports and the cache-hook API remain untested locally: torch, Transformers and KVPress are absent in both audit environments.

Official PyTorch documentation lists 2.9.1 CUDA 12.6, 12.8 and 13.0 wheel alternatives. Therefore `torch==2.9.1` alone is not a complete GPU build specification. PyTorch introduced Blackwell support with CUDA 12.8 wheels; this is support evidence, not proof that this exact project stack works. Choose a specific compatible wheel/driver pair and archive the distribution hashes/container digest. Do not float to the latest release to resolve an error silently. [Official wheel matrix](https://pytorch.org/get-started/previous-versions/), [Blackwell support announcement](https://pytorch.org/blog/pytorch-2-7/)

**Closure:** perform resolver/import/package checks on CPU or a prepared image first, without weights; archive `pip check`, wheel hashes, exact Python/Transformers/KVPress revisions and PEP-610 commit metadata. Once the separately authorized new GPU exists, check device count/capability, driver/runtime, installed arch support and tiny deterministic BF16 matmul/SDPA; then cache-hook behavior. `torch_eager` avoids this scorer's Triton compilation, but does not eliminate all CUDA compatibility or SDPA dispatch issues. FlashAttention/vLLM are unnecessary additions to this first quality pilot.

### P1 — Fake-key masking must be exercised on the real deferred-query shape

`attention_patch.py` gathers all query rows and grouped query heads for each KV head, then seeks one fake key whose logits underflow for all those queries. It can raise after 1,000 iterations. A single query vector and its negative cannot both have strictly negative dot product with any one fake key; increasing iteration count cannot fix that mathematical case. This is a source-level limitation, not a demonstrated failure of Qwen3 on this dataset.

The smoke's LCC deferred queries are 14 tokens, but its RepoBench query is 448 tokens. Development RepoBench queries span 347–2,916 tokens; with four query heads per KV head, the largest one presents 11,664 query vectors per KV head in the first query forward. Consequently an LCC-only or one-token decode smoke does not validate the intended RepoBench path.

**Closure:** keep the 448-token RepoBench smoke in the first all-arm test; record the exact failing context/build/stage if hyperplane search fails. Do not drop a failed row or keep increasing `max_iter`. Any alternative query chunking or explicit attention-mask backend requires a separately named common-path adaptation and full-KV/compressed equivalence checks before using it for causal claims.

### P1 — Asset staging and provenance are not complete

The runner deliberately loads only local assets and checks the resolved model config's commit. It does not verify a complete checkpoint shard index or independently hash staged weights. Locally, only tokenizer files/model metadata exist; the actual checkpoint, runtime model config and GPU environment are unstaged. The preprocessing environment uses tokenizers 0.21.4; the eventual Transformers stack may use another version. Frozen context IDs remain stable, but runtime reconstruction-prompt tokenization must be checked against the frozen tokenizer asset, not only the chat-template string.

**Closure:** prepare a revision-specific manifest of config, generation config, tokenizer and all checkpoint shards, sizes and content hashes; check complete shard/index coverage and disk space before billing. Verify tokenizer bytes and reconstruction-prompt counts across the two environments. Stage one checkpoint copy and reuse it across task invocations. A local source transfer should preserve the manifest/source hashes; the final experiment needs a clean committed runtime checkout. This audit has intentionally not committed anything.

### P1 — The existing run cannot yet settle the stated scientific mechanism

Current arms can compare Echo with exact scoring and capture diagnostics. They do not deploy scale/rank oracles or uniform/random anchors. Offline recalibration of saved tensors can test distributions/allocation, but cannot by itself establish downstream quality gain under the resulting masks. Do not claim the new arithmetic module, or source-level regional heterogeneity, settles the hypothesis.

Before later GPU stages, freeze an apply-mask/re-evaluate contract and matched partitions/prompt conventions. The exact regional-map oracle preserves virtual within-region ranks; rank-only oracle preserves the baseline regional histogram, with tie behavior recorded. Full exact scores are diagnostic labels, never future deployable inputs. Cheap common recency protection, precision/tie controls and uniform anchors precede adaptive conditional policies. Learned comparators need separately pinned predictor assets and policy-matching; their bytes/download/build costs are part of the comparison.

## 2. Exact workload size and minimal staged design

The frozen tokenizer gives chat prefix 3 tokens, suffix 9, first repeat prompt 7 and later repeat prompt 12. The Echo first exact context anchor is therefore 2,032 tokens, with 2,048 total first replay input tokens. Counts below include replay prompts/suffix/previous-chunk postfix. They are deterministic work estimates, not measured time/FLOPs.

| Current generated scope | Contexts/questions | Cache builds | Exact replay passes | Prefill input tokens across builds | Exact replay input tokens | Maximum generated tokens |
|---|---:|---:|---:|---:|---:|---:|
| `smoke8k` development, both tasks | 3/3 | 12 | 23 | 65,292 | 39,274 | 768 |
| `pilot16k` development, both tasks, 50/75/90% | 13/13 | 130 | 393 | 1,064,150 | 727,380 | 8,320 |
| `pilot16k` heldout, both tasks, 50/75/90% | 25/25 | 250 | 732 | 1,922,990 | 1,324,047 | 16,000 |
| Proposed development, one fixed 75% ratio | 13/13 | 52 | 131 | 425,660 | 242,460 | 3,328 |

For C contexts and E eviction ratios, builds = C × (1 + 3E). **Current warmups = 0; repeats = 0 additional builds.** Timings are intentionally cold/instrumented. A hypothetical full-matrix one-warmup-plus-three-measurements schedule would multiply 130 by four to 520 builds, before downloads or model loads; it is neither configured nor appropriate for a first quality screen. Repeating deterministic generation does not turn 13 contexts into a larger quality sample.

Recommended sequence, always stop the paid instance while doing prolonged analysis:

1. **CPU release gate now:** bridge/fixtures, smaller frozen stage manifests, source/asset inventories, compatibility plan, expected bytes/work, per-project billing and stop design. No GPU, no checkpoint download required for this audit
2. **Provisioning/kernel gate:** only the new project instance; record actual offer, model staging status, resource ID, billable start and shutdown deadline before workload. Tiny kernel/import/preflight checks precede weights/model load. Stop after the bounded compatibility allowance below if no useful inference succeeds
3. **Three-context compatibility smoke:** existing 12-build / 23-replay set, all four arms at 50%, including RepoBench. Verify source, hooks, exact mask/protection counts, no stale masks, independent query clones, cache lengths, complete outputs and successful offline analysis. Compare no-mask full KV with an unmodified reference using the same token sequence/cache segmentation. Repeat one fixed context only if needed to establish determinism/cache isolation, recording those extra builds explicitly
4. **Small natural existence screen:** one predeclared 75% ratio on the existing 13 development contexts, at most 52 builds/131 replays. Check measured cost and peaks after the first task, then admit the remaining task only if it fits the remaining stage allowance. This can establish whether a larger experiment is warranted; it cannot establish a 1–2 point population effect conclusively
5. **Offline diagnosis first:** use already captured partition-matched scores to inspect clipping/ties/allocation, and decide whether a scale-oracle downstream replay is worth paying for. A failure explained by partition, recency, precision, or ranking removes the case for a more elaborate calibration method
6. **Locked heldout only after a surviving method/control plan:** one selected method and frozen comparator protocol; no automated launch of the existing 250-build matrix. Preserve all 25 heldout contexts for final untouched evaluation and report the two task denominators. Choose the next architecture only if evidence survives; CNY100 is not a two-model paper budget

The 13-context screen plus smoke has at most 64 builds under this plan, with no claimed elapsed-time guarantee. If the scientific plan needs more arms or repeated model initialization, update the manifest/cost estimate before executing them.

## 3. Memory, setup/download costs and physical claims

### Actual selected model

Pinned Qwen3-8B has 36 layers, 8 KV heads and head dimension 128. BF16 raw KV per token at batch one is:

`2 (K/V) × 36 × 8 × 128 × 2 bytes = 147,456 bytes = 144 KiB`

That is 1.125 GiB at 8,192 context tokens, 2.25 GiB at 16,384, and 4.5 GiB at 32,768. The three smoke contexts themselves use about 0.602, 0.848 and 0.792 GiB of raw base KV. These are shape calculations, not measured CUDA peaks. [Pinned Qwen3 config](https://huggingface.co/Qwen/Qwen3-8B/blob/b968826d9c46dd6066d109eabc6255188de91218/config.json)

The local pinned HF metadata reports 8,190,735,360 BF16 parameters: approximately 16,381,470,720 parameter bytes / 15.256 GiB, excluding file headers and runtime overhead. This differs materially from applying `gpu_budget.md`'s explicitly illustrative Qwen2.5-7B 56-KiB/token example to this model.

### Masking is not physical savings

For every arm, the frozen cache remains dense. `physical_kv_payload_reduction_bytes=0` and `compacted=False` are correct. Each question deep-copies the full dense cache while its base remains alive. At 16K, just two KV payloads contribute roughly 4.5 GiB plus query/output growth; replay slices can retain larger backing storage. Exact reconstruction materializes attention-score intermediates, Echo eager scoring materializes query blocks, and there are model activations, CUDA workspaces, masks, allocator reservations and CPU captures. A 32GB card may fit this staged diagnostic, but no CPU test establishes that.

The CPU-captured integer mask coordinates also take space: three int64 indices per pruned pair, plus keep masks and score copies. They are not free compressed metadata. Record host peak RSS/disk high-watermark as well as `diagnostic_tensor_cpu_bytes`, which excludes much Python/storage overhead.

No causal comparison should use paper FlashAttention/physical-compaction timings alongside this SDPA/fake-key runner. Any future compaction claim needs a separately validated backend preserving per-layer/head positions and token selection, with real allocations/backing storage, compaction scratch, metadata, output equivalence and setup/serve costs measured. All masks must be restored on independent cache clones; a smaller logical count alone is not a memory result.

### Setup is billable if the GPU is running

Illustrative download-only cost for ~15.256 GiB of weight payload, using the earlier documented CNY2.93/hour estimate:

| Sustained transfer | Ideal weight download | Compute charge while downloading |
|---|---:|---:|
| 5 MiB/s | 52.1 min | CNY2.54 |
| 20 MiB/s | 13.0 min | CNY0.64 |
| 50 MiB/s | 5.2 min | CNY0.25 |

These are arithmetic scenarios, not throughput observations or current account quotes. Add package/CUDA wheel downloads, decompression, verification, install/import work, model CPU load/device transfer, retries, result serialization and shutdown delay. At 5 MiB/s the weights alone already exceed the proposed 45-minute compatibility stop. Prefer an already staged verified image/checkpoint or a separately approved low-cost preparation route. No such route is assumed free or currently configured, and no model download was performed here.

Plan roughly one 16.4GB weight copy plus dependencies/data/output headroom. Free-disk sufficiency must be checked on the chosen offer; copying HF cache blobs into another model directory can double storage. Two task invocations reload the same checkpoint independently. No disk expansion/auto-recharge/top-up/new persistent credential is implied by the existing rental ceiling.

## 4. Fairness, leakage and metrics

- All four arms share exact context/query tokens, model/tokenizer revision, BF16, SDPA, greedy EOS handling, sink treatment and zero extra recency by default. Verify this in the bridge, not only in prose
- Compare Echo against both native KVzip and `kvzip_echo_partition`. Only the latter controls the first/later scoring-boundary confound. Their reconstruction costs still differ; label a quality-versus-build-cost comparison instead of claiming equal compute
- Current source captures author-storage scores and float32 pre-storage virtual scores. Use them to quantify BF16 ties/clipping before attributing a delta to regional calibration. CPU NumPy stable ties are not torch top-k parity
- Code completion uses a chat-adapted prompt; official LongBench code tasks use raw completion. Current results can support a within-this-protocol comparison, not direct replication of a published LongBench score. No paper-quality reproduction has occurred
- The prepared split is 8 development/16 heldout contexts per task in a 48-context selected superset, narrowed to 13/25 at 16K. Both are research-created slices of official test data. Keep the exact denominator and length selection visible
- Existing gold-dependent substring checks were post-selection diagnostics; do not filter rows on whether a reference occurs in context. This review did not inspect heldout answer contents or model predictions
- New lexical screen: all 16 development × 32 heldout contexts in the superset, 512 pairs, using sets of 5-token shingles after the chat prefix. Maximum Jaccard 0.01314577; zero pairs ≥0.5 Jaccard or ≥0.8 smaller-set containment. This reduces concern about obvious near-identical text leakage under this specific test. It does not prove repository independence, semantic independence, or freedom from model-training contamination
- All current natural contexts have one question each. There is no empirical multi-query reuse, later-evidence targeting, or worst-region quality measurement yet. Per-region retained counts do not create evidence-location labels. Cache-reuse amortization at a hypothetical number of future questions is a scenario, not an observed saving
- Use pinned LongBench code-sim/difflib, unrounded paired per-example deltas and context-cluster uncertainty. Analyze LCC and RepoBench separately before any predeclared pooled summary. Do not search all ratios/variants and report only the best result
- A 13-context screen may be inconclusive about a 1-point gap; lack of significance is not equivalence. The 25-context heldout set may also be too small for a stable 2-point conclusion. It can justify stopping further spending without asserting the method has been disproved generally

## 5. Operational and scientific stop rules

### Before power-on

- Only a new project-specific instance; verify its ID/name/offer and make it the explicit target of every subsequent action
- Never operate on the user's other existing instances. Never stop every instance or infer project spend from total account balance movement
- Record the actual compute quote, billing basis, selected region/GPU/RAM/disk, applicable fees and authorized payment route; verify source transfer/checkpoint readiness and a working control route
- Current internal first-stage limit remains the earlier plan's **4 billable GPU hours or CNY20 all-in, whichever is earlier**, inside the CNY100 cumulative project cap. This report does not release another stage or enlarge authorization

### After power-on

- Set and verify provider-level shutdown immediately on **this instance**, before the workload; deadline no later than 3h55m from billable start, or earlier if the all-in cap implies it. A Python timeout is not a billing stop
- Keep an external controller/resource tag plus command-level timeout/cleanup. Both success and failure must lead to stopping this instance; preserve logs/results first where possible. A provider timer is the fallback if process cleanup fails
- Use resource-ID-specific bills and runtime events: `project_resource_id`, start/stop times, hourly quote, attributable disk/other fees, invoice/event ID, currency, status and cumulative project amount. Reconcile estimated elapsed-time cost against settled per-resource bills without double-counting
- Stop when no model load plus useful inference succeeds within 45 paid minutes; model downloads/setup consume that allowance. Permit at most one targeted retry for a diagnosed OOM/environment issue within the same cap. No looping installs or speculative version upgrades
- Stop at a conservative 95% of the stage all-in allowance, or the runtime deadline, whichever first; include lagging invoices and ancillary reserve. Stage transitions require reviewing evidence and remaining cumulative allowance
- Stop on missing source/data/asset hashes, changed pins, failed shutdown control, invalid masks/protected positions, nonfinite scores, mutated frozen cache, incomplete paired output, unrecoverable fake-key failure, deterministic-kernel failure or OOM that a single bounded scope reduction does not resolve
- After exit, verify the project instance is actually stopped and its bill recorded. Export necessary artifacts through the authorized route. Stopping or ending a Python process alone is not proof of shutdown

### Research continuation gates

Do not advance beyond compatibility unless all arms execute and the analysis bridge validates the exact paired data. Stop adaptive-method work if no useful natural deficit appears, if scale correction does not recover it while rank correction does, or if partition/precision/recency/simple uniform anchors explain the gain. A positive saved-score correlation is insufficient. Heldout usefulness/generality needs the predeclared downstream gate and uncertainty; no extra spend is justified merely because a more complex implementation exists.

## 6. CPU verification record

All existing implementation files were left unchanged. Test logs and independent probe scripts/results are under `research/diagnostics/cpu_readiness/`.

| Command | Observed outcome |
|---|---|
| `python -m unittest discover -v` | 46 passed |
| `python -m unittest discover -s echo_pilot/tests -v` | 38 passed |
| `data_prep/local/venv/bin/python -m unittest discover -s data_prep/tests -v` | 15 passed, no skips |
| `python -m unittest discover -s research/diagnostics/echo_calibration -v` | 29 passed |
| `python -m unittest discover -s research/diagnostics/backup_codec -v` | 6 passed |
| `python -m compileall -q echo_pilot kv_harness data_prep research/diagnostics/cpu_readiness` | exit 0 |
| `PYTHONPATH=. data_prep/local/venv/bin/python research/diagnostics/cpu_readiness/checks.py` | 8 probes met expected acceptance/rejection; six config/dry-run combinations passed |
| `python research/diagnostics/cpu_readiness/near_duplicate_screen.py` | 512 cross-split context pairs screened; byte-identical rerun output |
| `python -m kv_harness ledger --path records/cost_ledger.csv` | one zero-CNY no-purchase row; no external project spend recorded |

Total rerun existing tests: **134 passed**, including six unrelated already-rejected backup-codec arithmetic tests, which confer no additional Echo model readiness. The eight integration probes are separate from that test count. Their deliberately fixture-valued package lock is used only inside a temporary directory for dry-run/config checks and cannot be represented as a real installed runtime lock. No fixture metric is a model quality result.

Audit hashes for the implementation examined:

- `echo_pilot/runtime.py`: `a4092fbfc7c00ed43e108e8cf44c6d8fbb0cdc854025f1a106962ca9f3e96788`
- `echo_pilot/contracts.py`: `1bcf3321e9d37e85de24f3fe7ea9a2ecd9a8a4882468ffe8c772fd8ac801d9af`
- `echo_pilot/configure.py`: `54548d0c3a041c116d11ca5a53b709c031a1e09a89a562cd8f10c34709c079d5`
- `echo_pilot/cli.py`: `3cb025c6a3fb9bd722fe4ccf0ee1270267febc57038c084849c6212c8ab96e2e`
- `data_prep/metrics.py`: `83b10f49bc8938e12009896b478edff03cbe7b053637499557419745e4633827`
- Data manifest: `b65d04dd86d433141cc24e749caba860c5fece976130795337b1388b1b915dbf`

A web attempt to open the pinned model safetensors index returned an access/tool error. No checkpoint-completeness claim follows; only the existing pinned metadata parameter count and the successfully retrieved official model config support the arithmetic here. GPU imports, actual CUDA kernels/cache hooks, tokenizer behavior under the eventual Transformers stack, physical peaks, quality, speed, model-weight integrity, provider rate and configured shutdown remain **not verified**.

## 7. Release checklist

- [ ] CPU-tested, fail-closed result/metric/pairing bridge
- [ ] Smaller stage configurations and explicit expected work frozen
- [ ] Complete compatible distribution and model-asset inventories staged/verified without consuming an open-ended GPU session
- [ ] New project instance identified; other instances excluded from all actions and accounting
- [ ] Actual offer/all-in budget and shutdown/control path verified
- [ ] Tiny SM120 deterministic kernels and real runtime preflight pass
- [ ] Three-context all-arm smoke passes including long-query RepoBench and offline analysis
- [ ] Evidence review supports the next narrowly bounded stage; no automatic full-matrix expansion

Only the first two items are immediate corrective implementation work. No paid resources should be started while those are unresolved.
