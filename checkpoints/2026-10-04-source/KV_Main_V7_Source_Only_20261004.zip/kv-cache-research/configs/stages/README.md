# Frozen small stages and read-only admission

Date: 2026-10-03 UTC. CPU-only preparation; no model inference, resource creation,
provider control, package installation, weight download, commit or push.

## What is frozen

`frozen_stages.json` is an inert recipe, **not a runnable config or rental approval**.
It pins the existing data manifest and original development artifacts, ordered
context/question IDs and fingerprints, four-arm policy, exact ordered build IDs,
per-build reconstruction lengths, generation caps and aggregate work counts.
`echo_pilot/stages.py` independently recomputes and checks the complete recipe.
Its canonical `plan_sha256` is:

`e2769c0dfe946c868e93774ab9960666664469e58c6383ff8f770b09a731a7bf`

Only two stages are available, in this order:

1. `smoke`: original `smoke8k` development contexts, all four arms, 50% eviction.
   LCC has two contexts and RepoBench-P has one, including its 448-token query.
2. `development75`: every original `pilot16k` development context, all four arms,
   one fixed 75% eviction ratio. LCC has seven contexts; RepoBench-P has six.
   Review the validated smoke before release. After the first development task,
   review actual cost and memory peaks before admitting the second task.

Neither stage is automatically released. No heldout recipe, arbitrary subset,
new split, score-dependent selection, new ratio, warmup or repeated measurement
is exposed by this module. All 25 existing `pilot16k` heldout contexts remain
untouched for a separate future method/comparator protocol. Labels are referenced
by their existing manifest hashes for later offline analysis; stage preparation
never opens labels or heldout artifacts. Original presets and inputs are unchanged.

| Stage | Context/question invocations | Builds | Exact replays | Prefill input tokens | Exact replay input tokens | Query input tokens | Maximum generated tokens | Model loads |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Smoke | 3 / 3 | 12 | 23 | 65,292 | 39,274 | 1,904 | 768 | 2 |
| Development75 | 13 / 13 | 52 | 131 | 425,660 | 242,460 | 32,388 | 3,328 | 2 |
| Combined proposed sequence | 16 / 16 | 64 | 154 | 490,952 | 281,734 | 34,292 | 4,096 | 4 |

There are **13 distinct contexts and 13 distinct questions** in the combined
sequence. Smoke repeats three development contexts; it adds no independent
quality examples. Each context has one full-KV build reused as the reference for
that invocation and three compressed builds at the stage's sole ratio.
No implicit warmup, retry, extra repeat or baseline/reference-equivalence test is
included. Extra work must be explicitly frozen and costed before execution.
The no-mask/reference equivalence check required by the readiness review is an
additional compatibility prerequisite, not silently included in these 64 builds.

Counts include the frozen three-token chat prefix and nine-token suffix. The first
reconstruction prompt is seven tokens and the later prompt is 12 tokens. Echo's
first anchor has 2,032 context tokens, producing 2,048 replay input tokens; later
chunks have up to 2,048 context tokens plus prompt/suffix/up to eight previous
postfix tokens. KVzip uses its native 2,048-token first body chunk. Echo executes
only its first exact replay; partition-matched KVzip executes every Echo-partition
replay. These are deterministic input counts, not latency/FLOPs measurements.

## Verify or construct configs without executing

From the repository root, no installation needed:

```sh
python -m echo_pilot.stages verify
python -m unittest discover -s echo_pilot/tests -p test_stages.py -v
```

To recheck exact reconstruction prompt token IDs using the already installed,
pinned CPU tokenizer environment (no network/weights):

```sh
data_prep/local/venv/bin/python -m echo_pilot.stages verify --retokenize
```

A newly created archival copy can be produced with `freeze --output NEW_PATH`.
Creation is exclusive; existing files cannot be overwritten. Freeze/verification
read only the pinned tokenizer/context/question/source artifacts; they do not
select new data or inspect outcomes.

After a real complete runtime package inventory has been independently prepared,
freeze each ordinary runtime config with the module's separate generator:

```sh
python -m echo_pilot.stages make-config \
  --stage development75 --task lcc \
  --packages-lock /path/to/real/packages.lock.json \
  --preprocessing-revision VERIFIED_LOCAL_ORIGIN_40_HEX_COMMIT \
  --output /path/to/new/development75-lcc.json
```

Choose `--stage smoke` or `--task repobench-p` for the other invocations. The
placeholder paths/commit above are not executable inputs. The generator delegates
to the existing config construction/validation, changes only the stage's ratio,
checks all frozen common-policy fields, rebases paths and writes a new config.
It refuses known fixture/placeholder version strings and existing outputs.
Structural lock validation **cannot establish that packages are actually installed,
CUDA-compatible, or honestly inventoried**. The existing runtime preflight must
verify the full installed inventory, backend source bytes and other requirements.
Synthetic structural locks are used only in temporary unit tests and never frozen
here as deployment artifacts. No runnable configs are supplied with this change.

Configs retain the original `preset/task/development` artifacts and are directly
compatible with the separate offline result bridge; labels remain outside runtime
question inputs. The stage sidecar does not add unknown fields to the strict
runtime schema. Record returned `plan_sha256` and `config_sha256` with the run.
Before real execution, archive a clean committed actual runtime checkout and all
pins; the current working tree's CPU-only preparation is not that release.

## Read-only workload and budget scenarios

```sh
python -m echo_pilot.stages estimate \
  --scenario configs/stages/admission.example.json
```

This example contains a **hypothetical** resource ID, a CNY5/hour compute rate,
CNY0.25/hour ancillary rate, CNY0.50 one-time fee and CNY1 unbilled reserve. Its
throughputs, setup, per-build overhead and model-load durations are **invented
scenarios**, not quotes or measurements. Under those assumptions alone, the
combined sequence is 4,429.192 workload seconds, 4,740 rounded billable seconds
including shutdown reserve, and CNY8.4125 incremental all-in. Neither this number
nor `planning_admitted` establishes actual runtime, availability or authorization.
Every report explicitly returns `execution_authorized=false`, unverified identity/
quote/control flags and `paid_resource_action_performed=false`.

The estimator is arithmetic-only: no provider API, browser, shell, resource
allocation, timer installation, control command, model import or remote inspection.
Its only command-line writes are explicit local `freeze`/`make-config`; `verify`
and `estimate` are read-only and print JSON. A budget rejection has exit code 2.

For a real planning pass, supply one named **new project resource** ID (never an
existing unrelated AutoDL instance), the complete project-resource allowlist and
known off-limits IDs. An empty off-limits list in the inert example is not evidence
that no unrelated resources exist. Resource provenance is a caller declaration;
this offline tool cannot verify identities or inspect the account. That separate
verification must happen before paid actions. Every existing AutoDL resource is
entirely off limits: no starting, stopping, restarting, modification, private-file
inspection or workloads.

Select one or more exact stage/task invocations to model remaining work. No build
is duplicated by the estimator. Re-estimate only the remaining invocation after
reviewing previous outputs; do not count the completed task again. Include setup
and all independent model loads; use overhead sufficient for cache clones,
fake-key masking, score capture, reporting and serialization. Linear token-rate
assumptions omit important shape dependence and need conservative measured updates
before subsequent admission. The generated-token term uses the full output cap,
which conservatively counts every output as a decode token, including the first
output produced by the query forward.

### Resource-specific accounting and caps

- The proposed resource's named all-in budget must be positive and at most CNY20
- First gate is shared across smoke/development tasks and resources: CNY20 all-in
  or four cumulative billable hours, whichever first; it is not reset per task
- Planning stops at 95% of that CNY20 gate and 95% of the resource proposal, or the
  conservative 3h55m deadline, whichever first, within cumulative project CNY100
- At least 300 seconds shutdown reserve is required; predicted time is rounded up
  to the supplied provider billing quantum before charging rates/checking limits
- Include resource-specific disk/other hourly fees, future one-time fees and
  lagging/unbilled charge reserve. Existing fees belong in billing events and must
  not also be charged as future one-time fees
- `billing_events` contains only project-attributable resource IDs, unique event
  IDs, gate IDs, settled/unsettled-reserve amounts and attributable billed seconds
- Events must represent non-overlapping costs/runtime. On settlement, replace the
  earlier reserve with the actual amount instead of adding both. The tool rejects
  duplicate IDs but cannot detect semantic duplicate invoices under different IDs
- Account-wide balances/deltas, off-limits/unknown resource bills, missing resource
  IDs, nonfinite/negative/float amounts and extra knobs are rejected
- The separate 45-paid-minute useful-inference gate includes prior first-gate
  billed time, setup/download, one model load, the first requested invocation's
  frozen first cache build (prefill plus any exact replay), its first query,
  per-build overhead and the full output-token cap. Admission must fit a complete
  first-answer scenario before 2,700 seconds; finishing setup/load alone is
  insufficient. The report exposes those components and the exact first-answer
  build/question identity. This remains an estimate, never successful inference
- After useful inference exists, supply its same-resource evidence ID and both
  `first_success_billable_seconds` (resource-local first-gate time at success) and
  `first_success_gate_billable_seconds` (cumulative shared first-gate time at that
  same success). Both must be positive, local <= shared < 2,700, and supported by
  the target's own and all project resources' accounted first-gate time respectively
- The shared-minus-local success time cannot exceed accounted other-resource
  first-gate time. A replacement-resource success at local 900/shared 3,500 seconds
  fails; a resource-local timestamp alone cannot reset the shared deadline
- Time billed to another resource or gate cannot support the target-local evidence.
  These timestamps and their chronology require an actual evidence record supplied
  by the caller; the estimator cannot independently verify it. They do not waive
  the shared time/cost ceiling

Unsettled reservations count conservatively as project spend. Prior project bills
from other gates/resources count against CNY100; no unrelated user's workload
contributes. The first-gate time sum is conservative across resource-specific
non-overlapping billable intervals. A new resource after a failed compatibility
attempt does not restart the first-stage allowance.

### Actual operational stop controls remain mandatory

The readiness review's external, resource-scoped stop wrapper is **not implemented
by this module**, intentionally. Before an authorized future workload, verify a
provider shutdown on exactly the new project instance, with deadline no later
than 3h55m from billable start or an earlier all-in limit; retain external control
and command timeout/cleanup. A process exit is not proof that provider billing
stopped. Preserve necessary artifacts, explicitly verify stopped state and reconcile
the final per-resource bill. Stop the paid instance for prolonged offline analysis.

Stop if useful model load/inference is not established by 45 paid minutes; at most
one targeted retry for a diagnosed problem fits within the same caps. Stop for
invalid masks, nonfinite scores, source/data/asset drift, incomplete pairs,
unrecoverable fake-key/kernel errors, or ineffective shutdown control. Changes to
scope, retries, controls or ratios require reviewed updated work/budget, not an
implicit full-matrix expansion. The CPU read-only estimator is a preparation gate,
not a runtime guard, offer confirmation or evidence that GPU rental is ready.
