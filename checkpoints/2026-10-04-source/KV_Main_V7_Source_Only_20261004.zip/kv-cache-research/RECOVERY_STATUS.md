# Scientific checkpoint v7, 2026-10-04 UTC

## Current result

The completed original-size Qwen3.5-2B CPU first24 screen terminated as
**STOP_NO_QUALIFYING_HARM**. All 24 cells completed and every greedy answer was
the exact gold token sequence including EOS. Required numerical controls and
the external resource guard passed. The prospectively frozen two-group
confidence-harm gate did not pass, so the conditional repair branch remains
closed. No method-benefit or deployment result is claimed.

The native FP32 F32-minus-Hctx32 d01/A2 gold-score and margin losses were
0.1362178102 and 0.8870320320 nat. For d05/A2 they were 0.0170323327 and
1.0556178093 nat. The rule requires BOTH measures in BOTH groups to exceed
`max(0.1, 10 * exact-control noise)`; the actual thresholds remained 0.1 nat.
The d05 gold-score loss fails that rule. A large margin loss or a qualifying
single group cannot substitute. This does not prove contextual reuse universally
harmless, a repair ineffective, or another task unable to fail.

The run made 173 calls / 4,705 network tokens. Independent saved-vector review
recomputed all 173 scored full-vocabulary vectors, all 57 argmax decisions,
480 pre-Q cache-tensor comparisons and 49 exact-control logit vectors. The
arithmetic audit uses float64 standard-library reductions and is explicitly not
a bitwise reproduction of native Torch FP32 reductions. All 2,305 raw FP32
receipts reconcile with retained files. See the full terminal report and
independent review for exact numerical scope and limitations.

## Failures and real costs remain preserved

The first original-size technical attempt loaded the model but failed on
TorchVersion metadata serialization before any scientific forward. Its error,
guard receipt and exact 45-file source snapshot are retained. The one approved
technical retry changed metadata normalization and the release-file pointer,
not the scientific protocol. The completed second attempt used its frozen
release, source pins and fixed stopping rule.

The second attempt's guard records 386.226860 seconds, combined terminal HWM
7,270,092,800 bytes, no resource stop or unexpected descendants, and clean
owned-group termination. The first technical failure cost another 24.721408
seconds. These are instrumented experiment costs, not serving latency or total
project cost. No further model execution was done during archival packaging.

All older 0.8B competence and BF16 parity failures remain unchanged. The earlier
reconstructed tiny third child remains a numerical pass with a missing external
terminal guard receipt; the new original-size guard success does not retroactively
repair that missing tiny evidence. Lost historical late FP32/full24 proof is
still lost. This new completed experiment is separately identified fresh evidence.

## Exact recovery and checkpoint history

The 467 original tracked files at `ecc1c87aaf0e609302f6b08023096078345f6f7a`
remain byte-for-byte unchanged. Full local Git history retains v5
`51f35b2f4acc5d21e49cd10079b4fb6cd02d9e9f` and v6
`c8f44f2d02027b328710a37aee029fc79c11a111` before this descendant checkpoint.
The latest reconstructed source, frozen execution releases, all available failure
logs, source/runtime pins, independent reviews and terminal reports are included.

The earlier weight-recovery 403 failure remains preserved. A later authorized
restoration verified the official immutable source and exact historical text
projection, including derivative SHA-256
`42bf754d7e146bbf9c3a351b0d0da3d5a7fea89d679fc1d053e287a28b7f378c`.
Those successful identity receipts are included without the model weights.
Runtime pin/source reconstruction is documented; whole old-runtime binary
identity is still not claimed. The older paper scaffold remains prospective,
point-in-time documentation, not a paper silently revised to claim benefit.

## This is a multipart scientific archive

The main v7 ZIP contains source, reports, integrity indexes and Git history.
It is **not self-contained for scientific raw data**. All 2,355 files from both
original-size attempt directories, totaling **1,367,949,798 bytes**, are preserved
losslessly in eight private Library raw ZIPs. No raw file or failed outcome was
pruned. A ninth emergency provenance ZIP separately preserves the initial stable
source/release/runtime snapshot. All nine save operations succeeded.

For the complete restoration, use the main checkpoint plus all eight numbered
raw archives. Exact Library IDs/download links, archive and per-file SHA-256,
byte sizes, file modes and a safe restoration script are under:

`research/reconstructed/scientific_checkpoint_20261004/`

Start with `RESTORE_COMPLETE_SCIENCE.md`. The restoration script was tested
end-to-end against every original raw byte. It refuses existing attempt
directories and performs no model or project-code execution. Git contains source
and reports plus the external retrieval manifest; it does not hide the 1.37-GB
scientific payload in a giant Git object. The first attempt's frozen source is
inside its raw archive and is restored to its original path.

Weights, virtual environments, wheels/downloads, compiled caches, document QA
intermediates, credentials and private assistant notes are excluded. Their
absence is explicit and does not imply a ready-to-run pretrained environment.
No GPU, paid resource, remote repository push, new model run or expansion of
scientific scope is authorized by this checkpoint. Archive the negative result;
do not relax the decision gate or continue the conditional repair branch.
