# Consumer Blackwell low-bit KV execution audit

Date: 2026-10-04. Target: one RTX 5090 / SM120. Decision: **close the broad candidate without GPU promotion**.

## 1. Result first

The proposed gap, “consumer Blackwell cannot decode directly from packed low-bit KV, so a new layout must remove unavoidable full-cache dequantization/repacking,” is false for current official code. FlashInfer already has paged NVFP4 decode with in-kernel unpack/scaling, GQA, and no full-cache floating reconstruction. Its current FA2 prefill also accepts packed NVFP4 and implements tile-local conversion/repack. A separate official SM120 path already performs native block-scaled FP4 QK and PV with an execution-specific transposed V representation. These are three different paths, not interchangeable benchmarks. [S1]

A real representation constraint remains: per-token/channel-group KV scales do not simply become reduction-axis scales for native FP4 PV after a byte transpose. This is an exact semantic obstacle to one particular shortcut, **not evidence of an unoccupied research niche**. Existing kernels already make different storage/compute tradeoffs. A paper about merely porting, changing strides, selecting a backend, or retuning tiles would not meet the requested mechanism standard.

No supported claim of SCI Q2/Q3 publishability follows. A useful deployment investigation is possible, but the current evidence does not justify spending GPU budget or starting another broad benchmark campaign. This report is independent of the retired PIC, sparse-codec-dependency, and exact-window-cache directions.

## 2. Scope and reproducibility

Read-only official source inspection and primary-publication research only. No installs, compilation, CUDA execution, model loading, weight downloads, GPU rental, spending, or account changes. Saved source files are evidence, not executed software.

Exactly eight primary work/source groups are used below. Three official repository revisions were pinned at or before 2026-10-04 12:00 UTC:

| Source group | Audited revision / document |
|---|---|
| S1 FlashInfer | `ac30bfabfc40cca1971bea7a41ac10e6960d6bfd`, committed 2026-10-04 06:01:41Z |
| S2 FlashAttention | `e9515d5dee6ade134a33d6020d38d01ef0596996`, committed 2026-10-03 04:11:52Z |
| S3 NVIDIA CUTLASS | `0b55a2f691d69981583568fd9eb69687b1f0de8a`, committed 2026-09-23 08:49:11Z |
| S4 PyTorch SDPA | Official stable redirect resolved to 2.14 API documentation during audit |
| S5 SGLang/Qwen/NVIDIA NVFP4 | September 16, 2026 implementation report |
| S6 TurboQuant | Final ICLR 2026 paper, appendix p.22; indexed primary-PDF passage |
| S7 RotateKV | Final IJCAI 2025 paper, §§4.4, 5.1, 5.4 |
| S8 KIVI | ICML 2024 paper v2, Fig.3, §3.3, Table 9; indispensable earlier execution prior art |

Local evidence: `blackwell_kv_execution_sources_20261004/`. `code_manifest.json` records every downloaded source file, immutable raw URL, byte count, SHA-256, and repository revision. `publication_manifest.json` records successes and limitations. PyTorch and the final TurboQuant PDF returned HTTP 403 to the download client; PyTorch was read through the web tool, and the TurboQuant appendix passage was available in primary-source indexing. Do not describe those two publications as locally archived in full. No exhaustive prior-art claim is made.

## 3. What the official implementations actually do

### 3.1 FlashInfer: packed paged decode is already implemented

At S1, `flashinfer/xqa.py:223–237` specifies packed uint8 K/V with last dimension `D/2`, and uint8 scale caches with `D/16`. `:377–385` changes HND to NHD through stride-only transpose, without a contiguous copy. `:395–403` explicitly permits NVFP4 XQA on SM12x. The head ratio is `Hq/Hkv` (`:356–359`).

The actual path is packed global KV + scale bytes → shared-memory tiles → register unpack/conversion/scaling → FP16/BF16 MMA → attention output. `csrc/xqa/utils.cuh:757–813` contains E2M1-pair conversion instructions. `csrc/xqa/mha.cu:1090–1140` converts/scales K immediately before MMA; `:1310–1355` does the analogous work for V. This is **direct packed-cache consumption**, but **not native FP4 attention arithmetic**.

`flashinfer/jit/xqa.py:65–116` supports FP16/BF16 Q; page sizes 16/32/64/128; D divisible by 16 and between 16 and 512. D > 256 has additional speculative-decode/head-ratio restrictions. These are source acceptance conditions, not independently measured compatibility. The dedicated NVFP4 test (`tests/attention/test_xqa_batch_decode.py:866–935`) uses D=256, GQA ratios 2/4/8, single-token and multi-token queries, multiple pages, and independently allocated versus stacked scale caches. This is test coverage in source; tests were not run here.

Multi-block decode is not zero-workspace: `mha.cu:2701–2814` stores partial outputs and row-max/row-sum state, then merges. The grid is indexed by KV heads (`:3015–3036`); do not model the implementation as necessarily rereading an independent entire KV cache for every query head. Actual repeated tile loads, split count, and occupancy still need profiling.

The wrapper auto-selects trtllm-gen on compute-capability major 10 and XQA otherwise (`flashinfer/decode.py:3756–3759`). A concrete backend-dependent counterpoint is visible at `:3828–3843`: the trtllm-gen/Cake NVFP4 NHD route transposes and calls `.contiguous()` on K/V and block scales; its documentation recommends HND. This is a real allocation/copy for that route, removable by supplying its native layout, rather than an intrinsic SM120 penalty. The XQA route above accepts stride-only layout changes. `decode.py:4362–4364` also reserves the first 8 MiB of the provided XQA workspace for semaphores and uses the remainder as scratch; reserve and useful live state must both be recorded.

### 3.2 FlashInfer: prefill repack is tile-local, not automatically full-cache scratch

`include/flashinfer/attention/prefill.cuh:142–190` has NVFP4 scale staging and a 16-bit shared-memory repack buffer. The repack predicate includes query-tile and head-dimension conditions. K and V time-share a buffer sized to `CTA_TILE_KV * max(Dqk,Dvo)`. Other paths retain in-loop conversion. The paged mainloop calls this repack at `:4153–4157` and `:4243–4247`.

Therefore “repack” in profiler/source discussion is not sufficient evidence of a global expanded KV allocation. The relevant questions are address space, lifetime, tile size, repetition across query tiles, and reduced occupancy. Current source already explicitly co-designs these costs. Some wrapper/backend combinations may still materialize an expanded prefix, but that must be demonstrated for the selected deployment path.

### 3.3 FlashInfer: a separate native-FP4 SM120 attention path also exists

`flashinfer/nvfp4_attention_sm120.py` supports GQA-compatible head counts, independently padded Q and KV lengths, and D=64/128. The preprocessing centers K, centers Q, forms a FP32 QK correction, and quantizes Q/K/V. V is stored as `[B,Hkv,D,Npad/2]`, with scales `[B,Hkv,D,Npad/16]`; K scales instead run along D. The wrapper pads sequence lengths to multiples of 128 and accepts dense contiguous tensors, not a paged-cache descriptor.

The matching `include/flashinfer/attention/sm120/nvfp4_attention_sm120/kernel/traits.h:116–134` instantiates SM120 block-scaled NVFP4 MMA atoms for **both** QK and PV. Thus even “native FP4 attention has not reached SM120” is too broad. However, padding a one-token query, changing quantization axes, generating correction data, and handling a mutable append-only cache are distinct costs. This API is not evidence of a drop-in, same-representation paged decode kernel. Its source is SageAttention-derived, explicitly attributed in the headers.

### 3.4 FlashAttention: an actual upstream limitation, but not a market-wide absence

At S2, the CuTe interface permits only FP16/BF16/FP8 tensor inputs (`interface.py:804–810`); FP8 is restricted to compute capability 10.x (`:926–929`). SM120 uses `FlashAttentionForwardSm120`, which inherits an SM80-style MMA path and accepts FP16/BF16 (`flash_fwd_sm120.py:15–38`). The upstream SM120 branch explicitly rejects paged KV and split-KV (`interface.py:1775–1779`); its planner requires one split (`:420–421`).

These statements apply to this pinned **official CuTe path**. They are not claims about every FlashAttention fork, future PR, legacy interface, or vendor wrapper. In particular, an upstream FlashAttention feature gap does not establish novelty when FlashInfer already handles the target operation.

### 3.5 CUTLASS: hardware primitives are present; a GEMM example is not paged attention

At S3, `media/docs/cpp/blackwell_functionality.md:654–681` distinguishes SM120's `mma.sync` family from the SM100 `tcgen05.mma` family. The documented SM120 narrow-precision GEMM path supports TN layouts; GeForce cluster shape is 1×1×1 because this path lacks multicast. `include/cute/arch/mma_sm120.hpp:3185–3234` provides E2M1×E2M1 block-scaled MMA with E4M3 scale factors. Example 79b instantiates an SM120 NVFP4 GEMM.

The scale-factor layouts described at `:627–650` of the functionality document organize scales along the GEMM reduction dimension. Native FP4 capability therefore exists, but CUTLASS does not turn arbitrary scalar-codebook indices, arbitrary asymmetric INT2 groups, or an application KV layout into those operands by relabeling bytes. Do not transfer SM100-specific scheduling assumptions or binaries to SM120, and do not infer lack of TMA from an SM80-style attention fallback.

### 3.6 PyTorch SDPA: reference/integration surface, not a packed-NVFP4-cache contract

S4's public signature takes Q/K/V, masks, dropout, a softmax scale, and `enable_gqa`. It exposes neither packed-cache block scales nor page metadata. Backend-specific fused limitations apply. Its illustrative `repeat_interleave` GQA pseudocode is not proof that every fused backend physically duplicates KV. Use a dequantized reference with an explicitly selected backend; do not claim plain SDPA is a directly comparable packed-cache implementation. This audit does not cover every TorchAO/custom-operator extension.

## 4. Closest low-bit work: what is established and what is not

- **SGLang/Qwen/NVIDIA NVFP4 (S5):** Architecture-specific text documents SM120 decode using packed NVFP4, register conversion to BF16, and BF16 matrix products. Extend/chunked prefill instead gathers/dequantizes cached prefixes into a shared-across-layers FP8 workspace. It states SM12x/SM100/SM103 and GQA support. Its earlier overview says decode converts to FP8; the more specific SM120 section says BF16, consistent with audited XQA code. Report this discrepancy rather than silently merging them. These published benchmarks are not measurements on our RTX 5090. The remaining extend workspace is real in that implementation, but current FlashInfer provides a competing direct-packed prefill path. Integration must be compared before claiming new fusion.
- **TurboQuant (S6):** Final appendix describes FLUTE-derived LUT dequantization fused with matrix multiplication, avoiding reconstructed full-precision K/V in HBM. Rotation, scalar-codebook indices, norms, and the inner-product variant's residual correction are not NVFP4. The reported fused-matmul comparison does not establish full online-softmax attention fusion, GQA-aware scheduling, or SM120 support. Do not use an unofficial implementation as proof of those claims.
- **RotateKV (S7):** Uses asymmetric low-bit quantization, channel reordering/rotations, and fine-grained metadata. Its efficiency discussion includes Triton quant/dequant and CUDA rotation kernels and identifies further kernel fusion as future work. No SM120 direct packed-attention implementation was established by this audit. Grouped-head rotation alone does not prove GQA-aware execution reuse.
- **KIVI (S8):** Explicit tiled dequantization-plus-matmul fusion already precedes Blackwell. Keys use channel-wise grouping, values token-wise grouping, and recent full-precision residuals. Table 9 evaluates Mistral GQA with 32 Q heads and 8 KV heads. This defeats a general “first on-the-fly low-bit KV matmul” claim; it does not prove a native-FP4 or single fully fused attention implementation.

## 5. The real representation/axis obstacle

This section is an analytical deduction from the audited layouts, not a performance finding or novelty claim.

Let the existing token-major V decode to

`V[t,d] = global_scale * s[t,floor(d/16)] * e2m1(code[t,d])`.

For QK, the reduction axis is D, so channel-group K scales naturally follow that reduction. For PV, the reduction axis is t. A native block-scaled B operand wants scales organized over groups of reduction-axis positions, for each output channel. A stride transpose changes addresses; it does not change the meanings of `s`.

A tiny counterexample: two tokens within the same 16-token reduction block have identical nonzero E2M1 codes, with channel-group scales 1 and 2. Reusing the same codes and a single shared reduction-block scale cannot preserve both decoded values. Transposing the bytes and scale array cannot repair this. One must change codes/scales, add arithmetic, split the computation, or impose extra scale structure. This refutes only the **unchanged-code, one-scale-block transpose shortcut**, not every exact reformulation.

The separate native-FP4 FlashInfer representation already quantizes transposed V along t. Producing it from the token-major cache generally changes represented values; appending may also update a still-open temporal quantization group. Quantizing Q or softmax probabilities adds further numerical changes. Such changes cannot be hidden inside a supposedly quality-fixed layout comparison. A new quantizer or approximation would need its own quality evidence and broader prior-art audit, outside this finite lead.

## 6. IO, workspace, and lifetime accounting

Define `N = B * Hkv * T * D` for equal K/V head dimensions and live tokens. The following is our arithmetic for one layer, before padding, page tables, global scales, residuals, and allocator overhead:

| Object/path | Bytes |
|---|---:|
| FP16/BF16 K+V | `4N` |
| FP8 K+V | `2N` |
| NVFP4 codes K+V | `N` |
| NVFP4 block scales K+V | `N/8` |
| Persistent NVFP4 total | `9N/8` |
| Additional full BF16 reconstruction | `4N` |
| Additional full FP8 reconstruction | `2N` |

Thus nominal NVFP4 compression versus BF16 is 32/9 ≈ 3.56×, not 4×; versus FP8 it is 16/9 ≈ 1.78×. These ratios are representation arithmetic, not measured usable capacity or speedup.

For one idealized complete K/V read, direct packed traffic starts at `9N/8`. Separately reconstructing and then reading BF16 costs at least `9N/8 + 4N + 4N`; FP8 reconstruction costs `9N/8 + 2N + 2N`. These are lower-bound ledgers that assume no beneficial persistence/reuse and omit Q/O/softmax traffic. A reusable expanded workspace can amortize reconstruction over multiple queries; direct tiled attention can reread or reconvert data. Neither assumption may be silently granted to only one arm.

Account separately for:

1. Persistent packed cache, scale layout padding, page-table capacity, full-precision residuals, dual layouts, and any open quantization group
2. Global ephemeral expanded KV, gathered copies, partial output/LSE, semaphores, correction tensors, allocator reservation, and overlapping stream lifetimes
3. Shared-memory tile staging/repack, registers, local-memory spills, and the occupancy they consume
4. Append/quantization/rotation/scale-generation cost, initial prefill, extend, single-token decode, and speculative verification
5. GQA logical shape versus physical reuse: fixed Hkv, vary `r=Hq/Hkv`, and never grant a memory saving merely by comparing against explicit repeated KV

“No global KV reconstruction” does not mean “zero scratch”; “transpose” does not mean “copy”; “4-bit storage” does not mean “4-bit arithmetic”; and a larger supported batch does not establish a faster same-batch kernel.

## 7. Ranked disposition and falsification gates

### Rank 1: close direct-packed SM120 decode as a new mechanism

Already supplied by official FlashInfer, with source-level GQA and stride handling. Neither a CPU oracle nor a rented GPU is needed to reject the broad novelty premise. Same for the broad idea of native-FP4 SM120 attention.

### Rank 2: conditional deployment question, not a promoted paper hypothesis

Question: for a specific model-serving extend/decode workload, does retaining one fixed token-major quantized representation and selecting existing direct-packed versus expanded-workspace execution reduce total live memory and total latency?

The causal variables would be query length, GQA reuse, reconversion count, expanded-workspace lifetime, and occupancy. However, phase-aware backend selection and tile-local dequantization are already conventional mechanisms. **Close unless an additional, falsifiable cache-lifetime/representation mechanism beyond choosing or tuning existing paths is established.** Showing that an unoptimized integration allocates too much scratch is insufficient.

### Rank 3: native-FP4 PV with unchanged cache semantics

A one-transpose shortcut fails the axis counterexample. More elaborate exact reformulations are not excluded, but no new deployable one was established. Do not promote hardware porting, requantization, or a new quantizer under this label. This is a useful CPU semantic gate if a concrete construction is proposed later.

## 8. CPU-first oracle requirements before any reopening

These are preconditions, **not claimed completed experiments**. Use standard-library code and tiny synthetic arrays; no model is needed.

- Freeze an exact format contract: nibble ordering; E2M1 sign/zero; E4M3 scale decoding and rounding; global scales; scale grouping; residual policy; legal padding; page/table/stride interpretation; GQA mapping; causal offsets; tail rules
- Generate codes/scales once, then hand identical represented K/V to every execution arm. Never separately quantize random floats for each layout
- Exhaustively round-trip all 256 packed-byte values and legal scale-edge cases through pack/unpack and NHD/HND/paged address maps. Include separate versus interleaved scale allocations and nontrivial page permutations
- Use rational/integer-exponent arithmetic to verify decoded values and QK/PV matvecs exactly for tiny cases. Separately emulate BF16/FP16 rounding at the audited conversion points. A mathematically exact CPU oracle is not a promise of GPU bitwise-equal reductions
- Include the temporal-scale counterexample and an append boundary crossing 15→16→17 tokens. If a scheme updates old values or needs a second representation, charge and disclose it
- Test GQA ratios 1/2/4/8, D=64/128 and separately 256 for XQA, page sizes 16/64, T around page/tile boundaries, distinct K/V scales, masked tails, and per-request unequal lengths
- For decode references, construct the intended causal mask explicitly. PyTorch SDPA documents upper-left non-square causal alignment; blindly setting `is_causal=True` for one query over a long prefix does not express ordinary final-position decode.
- Compare full softmax attention at a predeclared tolerance after matvec/layout checks. Keep numerical correctness against the same quantized cache separate from model-quality loss versus original KV
- Produce a lifetime ledger from allocation/free events for each schedule, and a mechanism witness in which the proposed method differs from **all relevant existing direct-packed controls**, not merely dequantize-then-SDPA

Failure of the bit/layout tests, disappearance of the alleged workspace in the strongest existing control, or inability to state a distinct mechanism is a stop condition before GPU use. Passing CPU tests cannot predict occupancy, bandwidth, or speedup.

## 9. Future GPU budget envelope, only if separately justified

No GPU work is recommended now. If a concrete mechanism passes the above gates and the user later authorizes a run, constrain it to one RTX 5090 with no model weights and synthetic attention inputs. Proposed engineering envelope: up to two device-hours, including compilation/warmup/debugging, with a preverified prepaid or hard spend cap of **100 CNY total**, including provider/mandatory storage charges. This is a time-and-spend ceiling, **not a quoted rental price or assurance that the plan is affordable**. Obtain an actual provider quote first; if it cannot fit, do not start. No provider/account was selected.

A compact design could use B∈{1,4}, T∈{4096,32768}, D=128, Hkv=8, r∈{1,4,8}, and Q length∈{1,16}: 24 configurations, a small randomized-repetition latency sweep, then profiler traces only for prespecified representative cells. Charge append separately, record peak live and reserved bytes, distinguish L2-resident from cache-cold working sets, and compare against the pinned direct-packed XQA/FA2 controls at the **same representation and query math**. D=64/256 are targeted follow-ups only if required by the mechanism. Do not use large GEMM peak throughput to predict single-token GQA speed.

A full two-hour microbenchmark cannot establish end-to-end model quality, application usefulness, or journal acceptance. Native FP4 arms with different Q/P quantization belong in a separately labeled numerical experiment and cannot replace the same-representation controls.

## 10. Primary source index

- **S1:** [FlashInfer pinned source tree](https://github.com/flashinfer-ai/flashinfer/tree/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd). Key exact files: [XQA API](https://github.com/flashinfer-ai/flashinfer/blob/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd/flashinfer/xqa.py), [decode kernel](https://github.com/flashinfer-ai/flashinfer/blob/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd/csrc/xqa/mha.cu), [FA2 prefill](https://github.com/flashinfer-ai/flashinfer/blob/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd/include/flashinfer/attention/prefill.cuh), [native-FP4 API](https://github.com/flashinfer-ai/flashinfer/blob/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd/flashinfer/nvfp4_attention_sm120.py), [native-FP4 traits](https://github.com/flashinfer-ai/flashinfer/blob/ac30bfabfc40cca1971bea7a41ac10e6960d6bfd/include/flashinfer/attention/sm120/nvfp4_attention_sm120/kernel/traits.h). Historical support confirmation: [merged PR #2520, March 9, 2026](https://github.com/flashinfer-ai/flashinfer/pull/2520). PR bot summaries were not used as kernel proof.
- **S2:** [FlashAttention pinned CuTe interface](https://github.com/Dao-AILab/flash-attention/blob/e9515d5dee6ade134a33d6020d38d01ef0596996/flash_attn/cute/interface.py), [SM120 forward path](https://github.com/Dao-AILab/flash-attention/blob/e9515d5dee6ade134a33d6020d38d01ef0596996/flash_attn/cute/flash_fwd_sm120.py)
- **S3:** [CUTLASS pinned Blackwell functionality](https://github.com/NVIDIA/cutlass/blob/0b55a2f691d69981583568fd9eb69687b1f0de8a/media/docs/cpp/blackwell_functionality.md), [SM120 MMA definitions](https://github.com/NVIDIA/cutlass/blob/0b55a2f691d69981583568fd9eb69687b1f0de8a/include/cute/arch/mma_sm120.hpp), [NVFP4 GEMM example 79b](https://github.com/NVIDIA/cutlass/blob/0b55a2f691d69981583568fd9eb69687b1f0de8a/examples/79_blackwell_geforce_gemm/79b_blackwell_geforce_nvfp4_nvfp4_gemm.cu)
- **S4:** [PyTorch 2.14 SDPA API](https://docs.pytorch.org/docs/2.14/generated/torch.nn.functional.scaled_dot_product_attention.html)
- **S5:** [SGLang/Qwen/NVIDIA NVFP4 KV implementation report](https://www.lmsys.org/blog/2026-09-16-nvfp4-kv-cache)
- **S6:** [TurboQuant final ICLR 2026 paper](https://openreview.net/pdf/86df3c70aa9b7035c407e886e8238951a5d6ec23.pdf)
- **S7:** [RotateKV final IJCAI 2025 paper](https://www.ijcai.org/proceedings/2025/0690.pdf)
- **S8:** [KIVI paper v2](https://arxiv.org/html/2402.02750v2)

## 11. Review status

A second read-only review checked the strongest closure claims against the saved source, the limited V-scale counterexample, GQA/workspace caveats, and storage arithmetic. No material blocker was found. The configuration-count typo was corrected to 24. The final backend-copy paragraph was additionally checked directly against the pinned `decode.py`. No runtime validation was performed.
