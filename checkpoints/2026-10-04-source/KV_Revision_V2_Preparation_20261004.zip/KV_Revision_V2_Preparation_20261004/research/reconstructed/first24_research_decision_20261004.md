# First24 之后的研究决策

日期：2026-10-04 UTC。性质：新的结果解释与下一问题选择；不修改任何事前协议、first24 结果、论文骨架或阈值。此次仅阅读结果日志、已有研究审计和少量直接相关的一手资料，没有模型运行、安装、GPU、付费或远程修改。

## 结论与建议

**关闭这条固定 toy screen 及其自动 donor/observer/repair 推进分支。不要调整 d05、换指标、改阈值或寻找另一个能过的样例。这个结果没有否定所有实际 hybrid reuse 缺口，但也没有提供继续开发修正器的依据。**

建议下一步只做一份有终点的、无模型推理的“自然多文档复用问题与强基线清单”：以 MuSiQue 的原始文档边界为主，明确真实任务、source 构建上下文、LinearKV 对照以及完整生命周期成本。其用途是决定是否值得提出一个**新的、单独冻结的自然工作负载实验**，不是把 first24 的失败包装成继续跑的许可。如果无法形成有实际复用来源、可执行强基线和可承担计算范围的问题，就结束当前方法主线，交付这次有效负结果和可复用工程资产，不启动新一轮泛化文献筛选。

SCI 二区/三区是目标而不是事实。现在有可审计的工程和小实验资产，没有达到可以承诺论文分区的证据。一区目标同样必须由后续真实贡献决定。

## 1 新结果的准确含义

本说明直接解析 `contextual_harm_stage1_20261004/original_stage1_attempt_02/evidence/evidence.jsonl` 的 `first24_terminal`，并读取 `original_stage1_attempt_02_readback_audit.json`。readback 文件自身只覆盖终止记录与文件身份；后续[独立终止复核](contextual_harm_stage1_original_terminal_review_20261004.md)现已完成，重算 173 个词表向量、480 项 pre-Q cache 比较与 49 项 logit 控制，并核对全部 2,305 个 raw 文件，未发现推翻结论的差异。其他瞬时 continuation cache 的完整 tensor 未被重新创建，仍以保留的 live comparison/hash 证据为边界。

| 固定 A2 组 | F32 gold sum | Hctx32 gold sum | gold loss | margin loss | 两项阈值 | 结果 |
|---|---:|---:|---:|---:|---:|---|
| d01 | -0.1044906303 | -0.2407084405 | 0.1362178102 | 0.8870320320 | 均为 0.1 nat | 本组满足 |
| d05 | -0.0232442878 | -0.0402766205 | 0.0170323327 | 1.0556178093 | 均为 0.1 nat | gold 项不满足 |

- 24/24 单元完成，所有标准化答案与 strict gold token 判据都正确。前 16 个 R/F32 以及 Hctx32/A1 自复用控制在终止记录中通过
- 两组都同时满足 gold 与 margin 条件才允许推进；d05 没过，因此终态正确为 `STOP_NO_QUALIFYING_HARM`，`continuation_authorized=false`
- 最大 paired R/F32 gold 噪声为 0.000001758337 nat，margin 噪声为 0.000013351440 nat；十倍噪声均小于 0.1，因此没有阈值边界歧义
- d05 的 margin 从 7.0614743 下降到 6.0058565。主要是错误候选铜的分数上升，正确候选银仍有很大优势。这是可测分布变化，不能说“完全没有上下文效应”；也不能改成仅看 margin，然后宣布通过
- d01/U1、U2 的 gold loss 约为 0.02553、0.02603；d05/U1、U2 为负值。无关变化也会改变分数。当前结果没有做完整因果归因，更没有验证修正机制
- 实际 173 calls、4,705 network tokens；guard wall time 386.22686 秒，CPU user 374.204514 秒、system 7.968548 秒。不能把约 386 秒简单称为“算法 CPU 时间”或 serving latency
- readback 记录约 1.364 GB 原始证据、24 个 pre-Q cache 和约 7.270 GB 保守观察峰值。这包括研究验证和保留证据的开销，不能当作生产 cache pool 大小或 GPU 性能

首次 `original_stage1_attempt_01` 在 metadata JSON 的 TorchVersion 类型错误前停止，0 个 forward。它是保留的工程失败，不能算另一次成功科学试验，也不应从项目成本中抹掉。本次新的 FP32 结果不会改写历史 v1 输入完整性失败、v2 0.8B competence 失败、v3 BF16 数值失败。

### 被关闭的命题

“这个已固定的 2B/FP32、两个开发组、32-token seam、A1 contextual source 的 conjunction screen 达到了进入后续修正研究的预设信号”不成立。因此，不能运行其条件性的 donor、层 19/20 observer、holdout 或修正臂。

### 没有被证明的命题

没有证明 hybrid PIC 普遍无质量损失，也没有证明 Hctx32 与 full recompute 等价、普通长文档都安全、作者 HYPIC 已复现，或某种修正一定没用。这里是两个短构造任务、一个模型、一种 source policy 和固定输出评分；缺少自然文档、多 artifact、不同 source 生命周期以及实际部署测量。24 个臂不是 24 个独立问题，更不能当成足以做等效性检验的大样本。

这两个边界同时成立：**不把小阴性结果扩大为普遍否定，也不借“外部有效性有限”无限续跑。**

## 2 有限的一手资料复查改变了哪些决策

此次只查直接影响下一问题的来源，不重复全部历史综述。论文中的性能均为作者报告，未在本项目复现；不将论文图里的数字导入项目结果。

### 最重要的新增强对照是 LinearKV

[LinearKV, arXiv:2608.11231v1](https://arxiv.org/html/2608.11231v1) 明确讨论深层局部算子的上下文失配，比较完整状态组合与单个 cached block 初始化，并搭配 CacheBlend、EPIC、ProphetKV 的有序选择性重算。其自然 QA 与 RULER 研究覆盖不同 recurrent 架构；文中也明确未重算 token 的递推被省略，整体不是 exact-prefix continuation。

**决策影响：**“发现深层失配”“用更简单的单状态初始化”“把现有 PIC selector 接到 hybrid”都不能直接充当新贡献。未来基线不能只有 Hctx32 和自己提出的修正。此次没有验证 LinearKV 的作者代码 commit 或可直接执行 artifact，不能声称已经可复现；若采用 paper-defined 实现，要明确标注 reimplementation，并单独核对初始化、选 token、位置、卷积与序列推进语义。它不是把本项目 Hctx32 的 T 删掉就完成的对照。

### 实际任务仍然有动机，但不能沿用大机器性能预期

[HYPIC v2 §6](https://arxiv.org/html/2607.01299v2#S6) 使用自然 QA、摘要和一个 production RAG trace；其实验平台为 8 张 H20-3e，模型和长度与本次 2B 短输入不同。其问题设定支持研究多文档非前缀复用，但不提供本项目单张 5090 的成本证据，私有 production trace 也不能假定可用。

### 只改未来 query 也已经有近邻工作

[ATTUNER, arXiv:2609.36722v1](https://arxiv.org/html/2609.36722v1) 用 full-prefill 输出监督学习低秩 query 更新，保留 artifact KV，包含 MuSiQue 多文档使用研究。其 warm TTFT 明确排除离线构建、模型加载和分词。该工作提醒：读出/路由改变可能恢复行为，并非必须恢复每个状态；但本项目尚未证明这种路径对当前 hybrid 问题必要。泛称“只改 query 即可无重算修复”不是新颖空白，训练成本也不符合当前随手开展的预算。

### 转向 exact-prefix 缓存也不是空白地带

[Sparse Prefix Caching](https://arxiv.org/abs/2605.05219) 已把精确 recurrent checkpoint 放置写成 overlap-depth 分布下的优化；[SuffixReplay](https://arxiv.org/html/2609.33477v1) 研究 matched-prefix 的稀疏锚点和有限后缀回放。它们的 exact/shared-prefix 工作负载与本次 cross-prefix artifact 拼接不同，不能混为对照。

[DASC, arXiv:2608.30386v1](https://arxiv.org/html/2608.30386v1) 已研究衰减感知 recurrent checkpoint 压缩、ragged storage、完整 temporal/conv 字节和匹配 HBM 的 serving；其局限包括 GDN 粒度较粗与 TP8 实验范围。单卡部署与更细 GDN 粒度可成为外部有效性问题，但仅把这些方法移到单卡或加一种常规量化并不是现成新方法。

## 3 三个下一问题选项

以下均是备选的**新问题**，不是当前协议的续跑权限，也不是因为 d05 没过而产生的新成功判据。

| 选项 | 具体问题与实际场景 | 新颖性风险 | 最便宜的否证 | 当前建议 |
|---|---|---|---|---|
| A 自然多文档 PIC 的基线剩余空间 | 同一自然 artifact 处在不同前置文档之后时，source 构建 policy 与 hybrid 初始化/选择性重算，是否留下简单参考无法覆盖的质量–完整成本缺口 | HYPIC、LinearKV 已覆盖主要机制；source-conditioned delta 与读出修正也有先例。仅改 source policy 可能只是工程规则 | 无 forward 的数据/场景与基线语义审计；之后若经批准，固定自然样本与全套便宜参考的单次 pilot。如果问题不真实、2B 不胜任或简单基线已覆盖，停止 | **最值得保留，但先只准备一个有限输入侧包，不写修正器** |
| B 有限生命周期下是否值得建立 hybrid PIC artifact | 冷首用、少量复用、host/device pool、刷新和驱逐下，已有可用方案是否真有收益，还是 exact-prefix/full recompute 更合算 | break-even、cache admission、ski-rental 式阈值和普通 LRU 都是已知思想；纯成本曲线不足以成为方法贡献 | 用真实 artifact ID/顺序的可得 trace 和 source schema 做上界；即使乐观 hit 路径也不能回本即终止。没有 trace 就只许假设曲线，不能写生产收益 | **A 的经济性前置条件；可做部署决策，不单独承诺论文** |
| C 更细粒度 GDN checkpoint 存储与 exact-prefix 服务 | 多会话大 pool 中，完整 recurrent checkpoint 是否成为单卡瓶颈，且现有稀疏位置/回放/压缩无法解决 | Sparse Prefix Caching、SuffixReplay、DASC 已直接相邻；去掉 TP 或重写 allocator 不等于新颖机制。与已否定的 B 共享前缀布局也不能混淆 | 输入侧 overlap-depth 与字节清单；允许零重建开销的压缩 oracle 若都不改变可容纳 slot 或系统瓶颈，就无需模型测试 | **暂不启动；资源与新贡献都比 A 更不清楚** |

### A 的最小工作包和明确终点

**目标不是找另一个能让 Hctx32 答错的题，而是确定一个代表实际 artifact 使用的、新的完整 estimand。**

1. 首选 [MuSiQue 官方数据与 evaluator](https://github.com/StonyBrookNLP/musique)，使用官方 dev split、原问题/答案/文档 ID 与原始文档边界。官方说明提供多跳组合、正式评价脚本、CC BY 4.0 与 seed-question 泄漏提醒。版本、下载文件 hash、分割规则、许可证和数据最小化在运行前固定；本次未下载样本
2. 分开两个问题：完整候选文档池检验包含干扰项的实际 QA；support-only 文档检验给定证据的使用。后者是显式的 oracle-retrieval 条件，不能冒充真实 retrieval 系统。若只保留 support-only，应缩窄结论。不能删去困难的非支持文档后仍沿用 full-pool 标题
3. 准备 **12 个按固定 hash 次序选取的输入候选**，只作输入/边界/资源审计，不作显著性样本量。筛选只能按事前的输入长度、原始字段完整性、artifact 数量、重复 ID 等输入信息；不得读取模型答案后更换。若输入过长，不裁掉 supporting facts 凑短样例；记录该设备/模型范围不适用。分层与任何预设 replacement 顺序均在推理之前写出
4. 主用途是多文档 QA，备选外部核验可用 [HotpotQA 官方](https://hotpotqa.github.io/) supporting-fact 标注；它的 distractor 设置是 10 个段落，不能等同于 support-only。先不加 MultiNews/GovReport：摘要评价与生成长、任务聚合容易掩盖局部证据使用，且对 CPU 预算不友好。这是任务选择，不是声称摘要没有价值
5. source-build policy 固定为部署实际能形成的两种：先到请求的 contextual source；固定 canonical system+artifact source。不是按 target 答案挑 source。若模拟前置文档顺序，必须把它写成受控顺序干预；每个顺序有自己的 full reference，不能称为观察到的生产流量
6. 纸面基线表至少列：full recompute、适用时 exact-prefix reuse、suffix-corrected Hctx32、事前指定的更宽 seam、LinearKV 的完整 matched-selector 路径。先逐项核对 source context、初始化、token 顺序、卷积、RoPE、选择器观察范围、构建成本。不能把“同是 20% token”当作同 native compute
7. 仅在以上 12 个输入审计、基线语义和工作量估算完成后，写一次新的 pilot 提案。主要指标为官方 QA EM/F1 与全量失败率，gold 条件 NLL 仅辅助；同时保留 all-input 结果与事前定义的 full-reference competence 分层。不能通过模型结果筛选仅保留胜任题，然后把该子集当无条件模型质量
8. 具体 forward ledger、CPU guard、质量容忍和经济性门必须在任何新输出之前冻结，并单独获准。使用当前合格 2B 做 feasibility pilot 时不保证 natural multi-hop competence；若失败，报告 scope 不成立，不能自动开启更大模型梯队。CPU 长文本 eager 与本次短 first24 成本不能线性外推；单卡 GPU 仍暂停

**该准备包的终点：一份输入 ID/hash/文档边界清单、一份强基线语义差分表、一个能执行的最小成本估算和明确 go/no-go。** 不在准备中开发 layer-19 observer，不加 rank sweep，不把 first24 的两个 A2 当训练或选择集；不开展第二轮泛泛“找创新点”检索。若这些产物指出无代表性/无可公平实现对照/无资源可行性，则结案，而不是无限再准备。

### B 的经济性检查如何避免“造真实流量”

公开 QA benchmark 证明不了 artifact 会被反复查询，也通常没有到达时间、实际缓存容量和驱逐轨迹。重复同一题 128 次只能是 R=128 的敏感性场景，不能变成实测 hit 分布。固定公开请求集中的重复 artifact ID 也不自动给出生产时间顺序。没有可授权、可复核的真实顺序 trace，就把 B 留在假设性部署可行性层，不提出实际 SLO/吞吐结论。

先按真实保存对象记 B_build、h_hit、h_miss、refresh/fallback 和各 tier 的字节；C(R)=B_build+Σ单次成本。对比完整 recompute、实际 exact-prefix、Hctx seam、LinearKV，不先设计新调度器。若连 oracle 的最优合法 source/完全免费 correction 都没有剩余收益，任何昂贵修正都不值得写。反过来，乐观上界有收益也不能证明可部署方法已实现。

现有 first24 的 ledger 可以检查哪些操作被算到、共享 source 如何归因、原始证据是否完整，但当前有大量 FP32 cast、验证、文件证据和非生产调度。不能从 386 秒或 1.364 GB 直接画 GPU TTFT / 内存图。GPU 完整成本仍需要未来获准后的一次真实单卡测量，CNY100 只是总上限，不是新的支出授权。

### C 为什么暂时不选

理论与存储控制先做是便宜的，但本项目已对通用布局/共享前缀做过很强的负筛查。把“请求独立 KV 压缩”换成“recurrent checkpoint 压缩”并不能抹掉独立机制和质量证据的需要。没有真实 overlap-depth 分布、pool 压力与 DASC/稀疏 checkpoint 上界，就没法证明瓶颈在 state。GDN 单个请求的 recurrent state 规模有限，而并发 source pool 或 full-attention KV 才可能主导；必须先测所属场景，不能凭最坏尺寸图决定。

## 4 不再做什么

- 不因 d05 margin 大就去掉 gold-loss 判据；不降低 0.1；不把仅 d01 通过改称 screen 通过
- 不扩大 seam/换前缀/换答案词/换模型反复找 flip；不启动原条件 donor/observer/repair 或丢失的“100-cell”计划
- 不将本次无答错结果宣称为一般安全、lossless、或等效性证明；也不把分数变化称成实际答案损害
- 不复活已被简单控制关闭的 A/C，或用 B 的存储结果冒充自然质量结论；不重开已有被审计关闭的 generic scheduler、普通 query-drift detector、区域 calibration 主张
- 不把 LinearKV、ATTUNER、DASC 的作者报告当本项目数据；不默认它们能直接跑在 5090 或当前 pinned backend
- 不修改事前论文骨架。此次决策是事后独立文档，保留当时权重阻断与事前未知状态的真实性

## 5 现在可以写入项目结论的表述

“在预先固定的两个构造组上，24 个单元完成并保持正确答案，exact/self-reuse 控制通过；上下文复用改变候选分布，但未满足两组均达到 gold-loss 与 margin-loss 门的条件。因此停止预设修正分支。该结果不外推为自然工作负载上的零损失，也不支持修正方法收益。下一候选问题须独立来自自然多 artifact 工作负载，并纳入 LinearKV 等强基线与完整构建/复用成本。”

以上结论现有[已完成的独立科学复核](contextual_harm_stage1_original_terminal_review_20261004.md)支持；复核中的 float64 重算与原 native FP32 reduction 不要求位级一致，但停止结论与阈值均未改变。

## 6 证据与检查范围

直接读取：

- `contextual_harm_stage1_20261004/original_stage1_attempt_02/evidence/evidence.jsonl`，仅 JSON 解析终止记录与成本摘要；未加载 raw tensor、未运行 forward
- `contextual_harm_stage1_20261004/original_stage1_attempt_02_readback_audit.json`
- `contextual_harm_stage1_20261004/original_stage1_attempt_01_summary.json`
- 原 `PROTOCOL_RECONSTRUCTED.md`、已有 HYPIC source review、recurrent response audit、architecture-specific screen、selection review、A/B/C rejection review 与相关已关闭方向记录

此次直接核对的一手网页均在上文对应段落链接。范围是“下一问题是否已经被占据、应该使用什么实际任务和强基线”，不是完整 novelty 检索。没有断言不存在其他方法；未验证作者代码的来源明确保留这一缺口。此次只新建本文件，不给过去的推断补上事前性。


## 后续输入准备补记

本说明之后，已完成[MuSiQue输入与强基线准备包](musique_model_free_packet_20261004/README.md)。保留前64条的覆盖偏差结果后，单独在完整数据读取前冻结2/3/4-hop各4条的ID哈希选择，并获准对官方42,457,393B dev做一次无模型全量输入审计。全局有3,961个前置上下文改变的支持文档复用事件；固定12条有26个。它们是输入事实，不是模型阳性或生产命中率。既有first24仍关闭，新的多artifact/LinearKV接口与完整source成本尚待明确；见准备包的REPORT_zh.md。
