# Independent terminal review: original first24

Date: 2026-10-04 UTC. Verdict: **valid `STOP_NO_QUALIFYING_HARM` for the frozen two-group development screen. Do not advance or resume the conditional repair branch.** No invalidating discrepancy was found in saved provenance, raw evidence, scoring, controls, or resource receipts.

This is a completed original 2B CPU experiment, distinct from both the lost historical results and the earlier reconstructed tiny runs. All 24 planned cells completed. Every greedy answer was the exact gold token sequence with EOS; no answer-accuracy loss occurred.

## Fixed decision, independently reproduced

The native FP32 F32-minus-Hctx32 losses were:

| Changed target | Gold candidate+EOS loss, nat | Gold-minus-other margin loss, nat | Both required conditions |
|---|---:|---:|---|
| d01/A2 | 0.1362178102 | 0.8870320320 | Pass |
| d05/A2 | 0.0170323327 | 1.0556178093 | Fail |

The fixed rule requires **both losses in both groups** to reach their respective `max(0.1, 10 × exact-control noise)` thresholds. Native maximum R/F32 discrepancies were 0.000001758337 nat for gold score and 0.000013351440 nat for margin. Thus both thresholds remained exactly 0.1 nat. The large d05 margin loss cannot substitute for its insufficient gold-score loss.

I independently recomputed log-sum-exp scores from all 173 saved full-vocabulary FP32 vectors using stdlib float64 arithmetic. Recomputed d01 losses were 0.1362257511/0.8870321520; d05 losses were 0.0170357957/1.0556178901. The decision and 0.1 thresholds were unchanged. Maximum native-FP32 versus audit candidate-sum difference was 0.00001981983 nat; maximum margin difference was 0.000001762221 nat. This is an independent arithmetic audit, not a bitwise reproduction of Torch's FP32 reduction.

All 57 generated token decisions matched raw-vector argmax, including EOS. Canonical cell order, every actual call identity, complete prior token histories, candidate inputs, and greedy continuation inputs reconciled to **173 calls and 4,705 network tokens**. No extra source-only forward or later repair/holdout cell appeared.

## Controls, provenance, and retained evidence

All eight F32/R controls and both Hctx32/A1 versus F32/A1 controls passed. The live record contains 2,832 passing cache-tensor checks and 49 passing complete-logit checks. Independent saved-byte comparisons covered all **480 pre-Q cache-tensor comparisons** and **49 exact-control score-step vectors**, with maximum pre-Q absolute difference 0.00002002716, maximum logit difference 0.00003004074, and maximum float64 TV 0.000001426321. Other transient continuation caches were checked live and represented by the saved comparison/hash evidence; their full raw tensors were not independently recreated.

All **2,305 raw receipts** match exactly 2,305 retained `.f32` files, totaling **1,363,509,248 bytes**. Hashes, extents, shapes, dtype, and byte-order declarations agree, with no missing, duplicate, or unreceipted raw file. All 4,129 embedded raw references resolve. The raw scope includes 173 full logit vectors, all 24 pre-Q caches, both incoming source-A caches, source factors/traces/suffixes, and 10 additional realized F32/A1 endpoints; the prospective allowance of 21 was a maximum.

Every Hctx cell binds to its fixed contextual R/A1 producer, ch01 for d01 or ch09 for d05. Actual source-call histories, producer digests, source cache descriptors, raw factor/trace/suffix identities, tuple reuse, and target RoPE offsets 0/7 agree. All 46 source pins match the retry release and guard before/after; runtime/preflight pins also agree. The immutable retry release is SHA-256 `117c8b4e451b7eb79d76a327c93556b972336073fa84a940bbdf190513d2d921`, binding source digest `581632d5433f81f10d44433176984163dcc3bb30c44369ad2a5b6f4aa8ee3515`. The separate launch record confirms that exact release.

The terminal journal SHA-256 is `1200b92f97aff845b3308ce6786937423b591d3ab63db5d9607c0bb2ff0e9cdf`. Guard log/sample hashes match. Teardown shows no installed/executing engine or live arena, balanced 35,465 acquisitions/releases, zero unmatched leases, and no poisoned store or sink failure.

## Stop fairness and practical interpretation

The first technical attempt failed on serializing TorchVersion metadata after loading but **before any scientific forward**. Its zero-forward failure and 45 exact source snapshots remain preserved. Direct source comparison shows the retry changed only `str(torch.__version__)` at the serialization caller and the release-file pointer. It did not change prompts, schedules, arithmetic, thresholds, or scientific selection after an observed answer.

No earlier competence/control stop was triggered in the completed attempt. Assessing harm after all 24 cells, including the final unrelated-context controls, follows the frozen rule. It was correct to finish those cells rather than changing the stopping policy when d05/A2 was observed. The U1/U2 gold losses were approximately 0.02553/0.02603 nat for d01 and −0.01446/−0.00485 nat for d05; all their answers remained correct.

The resource guard passed: **386.226860 seconds**, terminal combined HWM **7,270,092,800 bytes**, sampled host unavailable-memory peak **4,726,112,256 bytes**, no resource stop, missing metrics, or unexpected descendants, and clean owned-group termination. The failed technical attempt cost another 24.721408 seconds; the two original attempts total **410.948268 seconds**. These are instrumented research costs, not serving latency or the total cost of the wider project.

The result shows measurable confidence degradation for this particular contextual reuse construction, including a qualifying d01 group, but the prospectively required two-group signal was absent. It does not establish that contextual reuse is universally harmless, that no other task can fail, or that a repair is ineffective. It also establishes no novel method, general benchmark benefit, or economical deployment result. Archive this completed negative screen; do not promote the single successful group, switch to margin-only selection, relax the threshold, or continue the conditional repair branch.

Independent machine-readable audits: [saved-vector audit](contextual_harm_stage1_original_terminal_vector_audit_20261004.json) and [saved-control audit](contextual_harm_stage1_original_terminal_control_audit_20261004.json). Existing run evidence and frozen sources were not edited; no model/native execution occurred during this review.
