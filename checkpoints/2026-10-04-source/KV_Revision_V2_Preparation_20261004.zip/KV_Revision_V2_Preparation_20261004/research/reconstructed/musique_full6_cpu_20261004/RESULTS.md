# Full6 result: STOP_COMPETENCE

2026-10-04 UTC. **All six fixed questions completed; only one was correct.** Official-rule EM and F1 are both 1/6 (16.67%), below the prospectively frozen minimum of three EOS-complete EM-correct answers. All six terminated normally with EOS, with no truncation. The three fixed exact segmentation controls passed. The original-size resource guard passed. This is a valid negative competence screen, not a numerical or memory failure.

The current Qwen3.5-2B/full20-document MuSiQue line therefore stops. No canonical32/128 cache arm, repair method, model upgrade, replacement question, support-only rescue or further forward is released. The previous first24 `STOP_NO_QUALIFYING_HARM` remains independently closed, with its costs and evidence separate.

## Complete fixed results

| Order / raw ID | Reference (additional accepted aliases) | Actual decoded answer | EM / F1 |
|---|---|---|---|
| 1 `double__121145_561444` | Dovber Schneuri | Rabbi Menachem Mendel Schneersohn | 0 / 0 |
| 2 `triple_ii__838590_831637_91775` | Sea, Air, and Land | Special Operations | 0 / 0 |
| 3 `quadruple_iii__152562_5274_458768_33632` | May 4 | May 4 | 1 / 1 |
| 4 `double__198459_61845` | Mido | Frank Lampard | 0 / 0 |
| 5 `triple_ii__354480_834494_34088` | Tucson Raceway Park (Tucson; Tucson, Arizona) | North Carolina | 0 / 0 |
| 6 `quadruple_iii__107309_457883_650651_7262` | Walter Sabo | Johnny Dare | 0 / 0 |

No subset was selected after seeing answers. The sole correct answer is a fixed four-hop question; this does not establish greater four-hop ability. Six related examples are a resource-allocation screen, not a general accuracy estimate. Author-normalized whole-answer EM/F1 used pinned primary answers and reconstructed author-rule aliases. There was no manual answer extraction, candidate likelihood substitution or LLM judge.

## Numerical and native evidence

Full recomputation used fixed consecutive chunks <=256; parity on the first question per hop used the same complete token stream segmented at the official prefix, all 20 document boundaries and final query/template tail, with long spans subdivided <=256. Both start empty and consume every input token. They are equivalent recomputation schedules, not observed prefix-cache hits.

All 576 live native cache-tensor comparisons and 12 prompt/continuation logit endpoints passed unchanged component tolerances. All native cache metadata and actual causal positions/support checks passed; the two live branches were checked for storage independence. Maximum reported cache absolute error was 8.106231689453125e-5; logit absolute error 2.8133392333984375e-5; TV 2.2274844013736583e-6. No greedy-ID disagreement occurred. The controls teacher-forced 4, 2, 3 non-EOS tokens respectively and stopped before feeding EOS.

There are 41 complete vocabulary vectors saved as raw FP32 (40,724,480 bytes): 29 Full prompt/decode selection vectors plus 12 control endpoints. The other 127 chunk-intermediate head vectors were hashed and discarded, while their compute was counted. All raw file hashes/extents and the exact call ledger passed post-run readback without model calls. Cache/mask tensors were checked live and hashed but not raw-persisted; their numerical comparisons cannot be independently recomputed from stored tensors. This limitation is explicit. Independent terminal audit is recorded separately beside this package.

## Cost and resource accounting for this one attempt

- Actual launch: 10:29:55.065153 UTC; completed approximately 10:47:08 UTC, within the proposed 90-minute limit
- Guard elapsed including initial hashes, loading and terminal checks: **1,033.463478179 seconds**
- Child CPU user 1,014.550305 + system 10.802324 = **1,025.352629 seconds**
- **168 root calls issued and returned; 24,131 network tokens**
- Prefill: 136 calls /24,099 tokens; Full continuation: 23 calls/tokens; parity continuation: 9 calls/tokens
- 29 generated Full tokens including 6 EOS; no EOS was forwarded
- 168 actual single-row head projections; 85,437,972,480 head MACs
- All Linear projection hooks: 33,210,473,250,816 MACs, excluding attention/recurrence/norm/conv arithmetic
- 34,440 matched arena acquisitions/releases; 1,264,515,022,848 logical cast bytes
- Combined process HWM: **6,828,785,664 bytes**, below 8 GiB; sampled host-unavailable peak 4,472,414,208 bytes, below 9 GB
- Final disk free 18,035,658,752 bytes; guard status `PASS_FULL6_PROCESS_GUARD`; no missing metrics, descendants, surviving owned group, source/asset drift or secondary failure
- Native teardown restored the engine, removed hooks/arena and released both cache owners. Journal was durable and unpoisoned

MACs are multiply-accumulates, not two-FLOP counts. Logical cast bytes are not measured physical memory traffic. Root, arena, hash and serialization timings overlap; outer wall/CPU already includes their actual execution. The tokenizer-only preparation and model-free tests are separate from these scientific-run costs, and earlier first24 attempts are not merged into this ledger. CPU eager diagnostic timings do not imply optimized serving latency, GPU speedup or production cache economics.

## Provenance and decision boundary

- Exact release SHA: `b0cc669592bd09a3713a0a31e8580a54526033e45a936eba780e66db4d4b1f10`
- Active 76-source-pin digest: `70746ce17d8fbcce534672cf0dcf5ef4d2e61d8d24e42d70477da9a9f405167a`
- Fixed plan SHA: `47f828985d3762b2009ddd80a9c400f32af1dfc55a4486463155dac8b79ba692`
- Result SHA: `036d40b343595d7535b81831388e2c1f95b311c29717397c266aae2d430c1fad`
- Guard SHA: `8185e0369296f7a0eaff63733944377dd467e5e50dc19f25e99e590c7a4aa718`
- Raw journal SHA: `e455d2f4efb38aa8b68d92e9198ace862ccf36359e9a26776c676844a466e7b6`

The scientific and resource receipts are `full6_attempt_01/result.json` and `full6_attempt_01_guard.json`; per-call evidence is `full6_attempt_01/evidence/evidence.jsonl`. `TERMINAL_READBACK.json` and `TERMINAL_INVENTORY.json` provide byte and cost checks. The pre-run independent source review is `../musique_full6_cpu_independent_review_20261004.md`.

This result justifies ending the fixed-model natural-task attempt before spending on cache-adaptation experiments. It does not establish whether a competent model would exhibit a useful cache-reuse deficit, explain the errors causally, refute hybrid PIC generally, or support a novel correction/publication claim. A future different question would require an independently justified prospective decision, not a threshold change or selection of the single success.
