# Tiny plain-Qwen3 native reference integration

2026-10-04. **Correctness-only PASS. No base-4B, trained-gate quality, GPU, or study-result admission.**

This finite implementation closes the small common-cache/selector correctness seam. It uses one locally random **24,832-parameter Qwen3Config** (2 layers, hidden size 32, 4 query/2 KV heads, head dimension 8, vocabulary 97). FP32 is the main correctness dtype; a same-config BF16 no-crop check is included. There is no pretrained download/loading, generation benchmark, tokenizer call, package installation, author repository import/execution, or GPU call.

## Files and final evidence

- `native_reference.py`: native decoder-layer adapter, physically compact GQA cache, independent position maps, selectors and byte/state tracing
- `verify_reference.py`: eight finite correctness groups, including independent selector/gather oracles and deliberate negative controls
- `run_bounded.py`: own CPU/RSS/disk/retained-size guard, immutable numbered attempt logs and source snapshots
- `attempt_03/verification.json`: final passing results, every logged selected index and per-array SHA-256, per-policy cost accounting
- `attempt_03/guard.json`: final measured resources; all attempts together used **12.38665 CPU seconds**, versus 120 seconds allowed
- `interface_contract.json`, `provenance.json`, `artifact_manifest.json`: ownership, supported input seam and byte provenance

The first attempt preserved a test-local variable-shadowing failure in the slack fixture. It was corrected without changing selection semantics. Attempt 02 passed. Attempt 03 added exact native-cache byte comparisons and removed unused synthetic gate references from non-TRIM engine state. All attempt code snapshots and outputs are retained.

## What passed

1. **Official native per-call parity:** Full, synthetic TRIM-no-crop, and a no-op oversized-budget TRIM arm have exactly equal logits on every identical chunk. **96 K/V byte-hash comparisons** against the official native DynamicCache are exact. Full segmented versus monolithic max error is **1.0431e-7**, below the prospectively encoded FP32 tolerance `atol=2e-6, rtol=2e-5`
2. **All eight policy configurations:** Full, last-N, prefix+recent, seeded random, declared R-KV selector port, unprotected static TRIM with trigger slack, protected static TRIM, and TRIM-no-crop. Every selected index is checked by a separate small oracle; gathered K/V/positions/gates are byte-identical to scalar reference gathers. Repeat executions and example reset yield identical complete state hashes. Crops repeat across one-token and multi-token appends and changing session labels
3. **Compressed multi-token causal masking:** each compressed arm matches tokenwise ingestion with selection frozen, max error **1.1921e-7**. Perturbing a future chunk token leaves all earlier logits exactly unchanged. Deliberately removing the mask changes earlier logits by **0.07477**, showing the negative control can detect leakage
4. **Native q_norm/k_norm and global RoPE counter:** both norms run once per layer/call. Seen count reaches 16 while last-N cache contains only positions 12–15. A deliberately wrong retained-length rebase changes logits by **0.21512**
5. **TRIM slack/protection distinction:** B=4, buffer=3 holds six tokens, triggers at seven and retains four. Constructed scores can evict the newest token without suffix protection, whereas explicit W=2 protects positions 5 and 6
6. **R-KV order sensitivity:** permuting only the old region while preserving the same key set changes next scores by **0.02979**. The implementation preserves the source's unsorted top-k order; chronological sorting would change this algorithm
7. **One-shot full-history peak:** final retained B is the same, but the one-shot test peaks at **6,912 cache-tensor bytes**, versus **3,168** online. This is a larger-ingestion-budget oracle, never a same-budget feasible serving comparison
8. **BF16 native no-crop:** same-config, per-call logits are exactly equal. This does not test a released trained gate or CPU-versus-GPU parity

## Precise ownership and interface

`NativeReference.step(ids, session, phase, freeze_at_query=True)` accepts batch-one, unpadded canonical CPU int64 IDs. It uses the official, unmodified installed Qwen3 decoder layers, q/k norms, projections, RoPE, MLP, final norm and LM head. The adapter only owns:

- Per-layer physical `[1, KV heads, resident, head_dim]` K/V, per-KV-head original int64 positions, optional retention log-beta, and an independent R-KV post-RoPE recent-Q window plus original Q positions
- A global `seen` counter advanced exactly once per chunk, independent of layers and retained length
- A per-layer/query-head additive mask based on `key_absolute_position <= query_absolute_position`. This is valid for per-head holes, R-KV's unsorted old region, and a complete multi-token append. It never guesses causal validity from retained length
- Post-chunk crop timing, after all native attention for that chunk has completed. Thus newly computed K/V are available to the current call, and selection affects the next call
- All state gathering and per-example reset. Session labels record boundaries without resetting a continuing conversation. `reset()` is required for a new example; no final answer is generated

The cap is intentionally tiny: model shape assertions, maximum 128 ingested tokens and default chunk cap 8. The one-shot peak diagnostic uses the same tiny model with chunk cap 32. Do not remove these guardrails to turn this artifact into the base-4B runner.

History-only selection is the default schedule. Crossing into `phase='query'` or `'decode'` freezes selection; appended question/decode entries still consume memory. Freezing is **not** a strict B-token post-query bound. An explicitly named continued-selection schedule can use `freeze_at_query=False`; it is a separate information regime. No packet inputs were evaluated and no outcomes influenced any input selection.

The active input packet pointer is `revision_causal_v2_20261004/LATEST_INPUTS.json`, pointing to `refinement_02_delimiter/constructed_variants.json` with SHA-256 `b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7`. This implementation exposes canonical IDs/session/query-boundary seams only; it neither retokenizes nor runs those inputs. The input packet's 128-token reference suffix is a recency-control parameter, not TRIM buffer protection.

## Policy fidelity and limits

**Native runtime:** existing official PyTorch 2.9.1+cpu and Transformers 5.19.0.dev0, official commit `02d8fb9784e8f14a1251e4c992cd82a5762417c6`. This is distinct from the archived Transformers 4.57.1 source contract. The actual installed plain-Qwen3 source hash is recorded. Numerical parity is against this installed official native model, not a claimed 4.57.1 or author FlashAttention execution.

**Recency/random:** original-position eviction controls on a non-windowed plain-Qwen3 model. Prefix+recent is not claimed as full StreamingLLM reproduction. Random selection is repeated sampling among currently resident unprotected entries using persisted seeded RNG, not uniform sampling of all historical tokens.

**R-KV:** exact supported selector math is GQA max-pooling of scaled QK logits before softmax, FP32 softmax over old candidates only, recent-query mean, cast to Q dtype, max pooling, key cosine redundancy with default `retain_direction='last'`, and source-order unsorted top-k plus protected suffix. The query window uses post-q_norm, post-RoPE Q. The bounded independent oracle checks chosen indices over repeated crops. Ties retain PyTorch backend-defined top-k behavior. Only the default `last` redundancy branch is supported; other author variants are not silently generalized. Explicit common post-chunk scheduling replaces delayed model flags and old cache APIs, making this a **declared selector port**, not author performance reproduction.

**Static TRIM:** own dimension-compatible synthetic rg gate consumes native post-input-layernorm hidden states, before QKV. It computes Linear→SiLU→Linear+bias→log-sigmoid. Per-head single-step score is `log_beta.float() * (seen + 1 - original_position)`. Trigger is `resident >= B+buffer`; retained top-k is sorted and K/V/gates/positions move together. The buffer is trigger slack. Only explicit `protected_tail` makes suffix scores infinite. The no-crop arm still computes gates. Only static, batch-one, unpadded, lookahead-one operation is supported.

The separately verified real 144-key / 94,725,981-byte static gate remains in `revision_baseline_contracts_20261004/phase2_static_gate_verification`. Its payload and synthetic-activation algebra checks are separate evidence. This tiny artifact does **not** load, resize or claim quality for that gate. DBTRIM, MInference, H2O and the old hybrid Qwen3.5 implementation are not substituted.

## Resource/cost interpretation

Final combined monitor+child sampled peak RSS: **358,535,168 bytes (341.9 MiB)**. All three attempts: **12.38665 child CPU seconds**. Final guard saw **17,613,123,584 free bytes**, above the 5 GB reserve. Retained artifact is below 2 MB before manifest overhead, below the 20 MB cap. Sampling interval is 25 ms; this is measured sampling, not a hard cgroup RSS limit. A child CPU rlimit provides an additional hard stop.

Each policy report records forward, gate, append, selector, gather and independent-reference-check wall times; calls/crops/scoring counts; payload bytes written; actual tensor-storage bytes; old/new append and crop coexistence estimates; GQA repeat/attention and R-KV quadratic score scratch estimates. Query tensors remain genuine query-head windows; resident K/V stay at two KV heads. Byte checks reject accidentally retaining a larger backing storage.

These counters are correctness-run instrumentation, **not performance rankings**. Forward includes gate and append time; these nested times should not be summed. Append-written bytes include query writes; that separate field is a subset. Tensor scratch formulas describe selected explicit tensors; they do not certify allocator-internal temporaries or all Python/list/logging memory. Those are covered only by overall RSS and remain unmeasured per operation. Control-selector tensor/list scratch is not fully instrumented; a reported score-scratch zero does not mean no selector allocation. Cold model construction is recorded separately. Shared model/gate test fixtures, independent oracle copies, and diagnostic logs coexist in the guarded process. No method-benefit or full-backbone memory-fit claim follows.

## Run

From the repository root:

```sh
python research/reconstructed/revision_native_reference_20261004/run_bounded.py
```

The guard invokes the existing `runtime_recovery_20261004/cpu_python.sh` offline/single-thread CPU wrapper, saves a new numbered attempt and refuses to exhaust the cumulative CPU allowance. No installation is necessary. Stop here for this correctness gate; a base-weight/runtime admission and separate study approval remain outstanding.
