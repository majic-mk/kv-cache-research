"""Finite CPU correctness suite; synthetic IDs/gates/random tiny model only."""
import os
import resource
import signal
import sys
import time

resource.setrlimit(resource.RLIMIT_CPU, (110, 115))
START_CPU=time.process_time(); START_WALL=time.perf_counter()
from pathlib import Path
import copy
import hashlib
import json
import traceback

import torch
import transformers
from transformers.cache_utils import DynamicCache
import transformers.models.qwen3.modeling_qwen3 as official
from native_reference import (NativeReference, Policy, Row, tiny_model, synthetic_gates,
                              object_hash, tensor_hash, choose_indices, rkv_scores)

P=Path(__file__).resolve().parent
OUT=Path(sys.argv[1])
TESTS=[]; REPORTS={}; ERRORS=[]


def check(name,fn):
    start=time.perf_counter()
    try:
        details=fn()
        TESTS.append(dict(name=name,passed=True,seconds=time.perf_counter()-start,details=details))
        print('PASS',name,flush=True)
    except Exception as e:
        ERRORS.append(name)
        TESTS.append(dict(name=name,passed=False,seconds=time.perf_counter()-start,error=repr(e),traceback=traceback.format_exc()))
        print('FAIL',name,traceback.format_exc(),flush=True)


def close(a,b,atol=2e-6,rtol=2e-5):
    torch.testing.assert_close(a,b,atol=atol,rtol=rtol)
    return float((a-b).abs().max())


cold=time.perf_counter()
model=tiny_model()
gates=synthetic_gates(model)
COLD=time.perf_counter()-cold
IDS=torch.tensor([[3,17,9,9,18,21,4,25,63,15,17,73,2,33,48,33,7,8,28,49,33,19,52,26]])
CHUNKS=[3,1,4,2,5,1,4,4]
POLICIES=[Policy(),Policy('last_n',6,protected_tail=2),Policy('prefix_recent',6,protected_tail=2,prefix=2),
          Policy('random',6,protected_tail=2),Policy('rkv_port',6,protected_tail=2,query_window=2),
          Policy('trim',6,buffer=3),Policy('trim',6,protected_tail=2,buffer=1),Policy('trim_no_crop')]


def drive(engine, ids=IDS, chunks=CHUNKS):
    result=[];offset=0
    for j,n in enumerate(chunks):
        result.append(engine.step(ids[:,offset:offset+n],session=f's{j//3}'))
        offset+=n
    assert offset==ids.shape[1]
    return torch.cat(result,dim=1)


@torch.inference_mode()
def no_crop_native():
    full=NativeReference(model,Policy(),synthetic=gates)
    trim=NativeReference(model,Policy('trim_no_crop'),synthetic=gates)
    noop=NativeReference(model,Policy('trim',128),synthetic=gates)
    native=DynamicCache(config=model.config)
    offset=0; errors=[]; ys=[]
    for j,n in enumerate(CHUNKS):
        ids=IDS[:,offset:offset+n];pos=torch.arange(offset,offset+n).unsqueeze(0)
        target=model(ids,past_key_values=native,position_ids=pos,use_cache=True).logits
        ys.append(target)
        for engine in (full,trim,noop):
            output=engine.step(ids,session=f's{j//3}')
            errors.append(close(output,target))
            for i,row in engine.rows.items():
                close(row.keys,native.layers[i].keys)
                close(row.values,native.layers[i].values)
                assert row.keys.shape[1]==2
        offset+=n
    mono=model(IDS,use_cache=False).logits
    errors.append(close(torch.cat(ys,1),mono))
    REPORTS['full']=full.report();REPORTS['trim_no_crop']=trim.report()
    return dict(max_abs_error=max(errors),official_per_call_native=True,full_segmented_monolithic=True,
                same_native_base_model=True,gate_computation_observed=trim.cost['gate_seconds']>0)


def cycles_and_byte_hashes():
    summaries=[]
    for j,p in enumerate(POLICIES):
        a=NativeReference(model,p,synthetic=gates);b=NativeReference(model,p,synthetic=gates)
        ya=drive(a);yb=drive(b)
        assert tensor_hash(ya)==tensor_hash(yb)
        assert a.state_hash()==b.state_hash()
        assert a.selection_events==b.selection_events
        assert all(e['byte_hashes']==e['reference_byte_hashes'] for e in a.selection_events)
        assert a.seen==24
        for row in a.rows.values():
            assert row.positions.max()<a.seen and row.keys.shape[1]==2
            assert row.storage_bytes()==row.bytes()
            if p.budget is not None:
                assert row.keys.shape[-2] <= p.budget+(p.buffer-1 if p.name=='trim' else 0)
        if p.name not in {'full','trim_no_crop'}:
            assert a.cost['crop_calls']>=4
        if p.protected_tail:
            for row in a.rows.values():
                for h in range(2):
                    assert set(range(24-p.protected_tail,24)).issubset(row.positions[0,h].tolist())
        old_hash=a.state_hash();a.reset();drive(a)
        assert a.state_hash()==old_hash and len(a.calls)==len(CHUNKS)
        REPORTS[f'{j}_{p.name}']=a.report()
        summaries.append(dict(policy=p.name,buffer=p.buffer,protected_tail=p.protected_tail,
                              state_hash=old_hash,crop_calls=a.cost['crop_calls']))
    return summaries


def compressed_multitoken_causality():
    details=[]
    for p in POLICIES[1:-1]:
        a=NativeReference(model,p,synthetic=gates)
        drive(a,IDS[:,:16],[3,1,4,2,5,1])
        # Clone only resident state. No Full states/backing history are used.
        b=NativeReference(model,p,synthetic=gates)
        b.rows=copy.deepcopy(a.rows);b.seen=a.seen;b.rng.setstate(a.rng.getstate())
        c=NativeReference(model,p,synthetic=gates)
        c.rows=copy.deepcopy(a.rows);c.seen=a.seen;c.rng.setstate(a.rng.getstate())
        chunk=IDS[:,16:20]
        y=a.step(chunk,phase='query')
        tok=torch.cat([b.step(chunk[:,j:j+1],phase='query') for j in range(4)],dim=1)
        err=close(y,tok)
        perturbed=chunk.clone();perturbed[:,-1]=(perturbed[:,-1]+19)%97
        z=c.step(perturbed,phase='query')
        unchanged=close(y[:,:-1],z[:,:-1],atol=0,rtol=0)
        assert (y[:,-1]-z[:,-1]).abs().max()>1e-4
        details.append(dict(policy=p.name,max_tokenwise_error=err,future_perturbation_prior_error=unchanged,
                            seen=a.seen,physical_length=a.rows[0].keys.shape[-2],
                            query_selection_frozen=a.calls[-1]['frozen_selection']))
    # Demonstrate the negative control can actually detect missing causal masking.
    a=NativeReference(model,Policy('last_n',6),synthetic=gates)
    b=NativeReference(model,Policy('last_n',6),synthetic=gates)
    drive(a,IDS[:,:16],[3,1,4,2,5,1]);drive(b,IDS[:,:16],[3,1,4,2,5,1])
    chunk=IDS[:,16:20];pert=chunk.clone();pert[:,-1]=(pert[:,-1]+19)%97
    bad=a.step(chunk,phase='query',unsafe_mask=True)
    bad2=b.step(pert,phase='query',unsafe_mask=True)
    leak=float((bad[:,:-1]-bad2[:,:-1]).abs().max())
    assert leak>1e-4
    return dict(cases=details,deliberately_unmasked_negative_control_leak=leak)


def qk_norm_and_original_positions():
    counters={'q':0,'k':0};handles=[]
    for layer in model.model.layers:
        for which in ('q','k'):
            def count(m,args,out,which=which):counters[which]+=1
            handles.append(getattr(layer.self_attn,which+'_norm').register_forward_hook(count))
    try:
        a=NativeReference(model,Policy('last_n',4),synthetic=gates)
        drive(a,IDS[:,:16],[4,4,4,4])
    finally:
        for h in handles:h.remove()
    assert counters=={'q':8,'k':8}
    assert a.seen==16 and a.rows[0].positions.tolist()==[[[12,13,14,15],[12,13,14,15]]]
    b=NativeReference(model,Policy('last_n',4),synthetic=gates)
    b.rows=copy.deepcopy(a.rows);b.seen=4  # deliberately wrong retained-length rebasing
    good=a.step(IDS[:,16:18],phase='query')
    wrong=b.step(IDS[:,16:18],phase='query')
    delta=float((good-wrong).abs().max())
    assert delta>1e-5
    return dict(norm_calls=counters,rebased_position_negative_control_delta=delta)


def slack_and_protection():
    p=Policy('trim',4,buffer=3)
    a=NativeReference(model,p,synthetic=gates)
    a.step(IDS[:,:6]);assert a.rows[0].keys.shape[-2]==6
    a.step(IDS[:,6:7]);assert a.rows[0].keys.shape[-2]==4
    # Hand scores force eviction of newest tokens in no-protection setting.
    pos=torch.arange(7).reshape(1,1,7).repeat(1,2,1)
    k=torch.arange(2*7*8,dtype=torch.float32).reshape(1,2,7,8)
    fixture_gates=torch.tensor([[[-.001,-.002,-.003,-.004,-1.,-2.,-3.]]]).repeat(1,2,1)
    row=Row(k,k+1,pos,fixture_gates)
    import random
    unprotected=choose_indices(row,p,7,random.Random(1))
    protected=choose_indices(row,Policy('trim',4,protected_tail=2,buffer=3),7,random.Random(1))
    assert 6 not in unprotected[0,0].tolist() and {5,6}.issubset(protected[0,0].tolist())
    return dict(slack_resident=6,trigger_resident=7,post_crop=4,
                no_protection_indices=unprotected.tolist(),protected_indices=protected.tolist())


def order_sensitive_rkv():
    # Duplicated similar key vectors make the index-based redundancy branch observable.
    gen=torch.Generator().manual_seed(42)
    k=torch.randn((1,2,9,8),generator=gen)
    k[:,:,2]=k[:,:,0];k[:,:,4]=k[:,:,0];k[:,:,6]=k[:,:,1]
    q=torch.randn((1,4,2,8),generator=gen)
    pos=torch.arange(9).reshape(1,1,9).repeat(1,2,1)
    row=Row(k,k.clone(),pos,queries=q,query_positions=torch.tensor([7,8]))
    p=Policy('rkv_port',6,protected_tail=2,query_window=2)
    perm=torch.tensor([4,1,2,3,0,5,6,7,8])
    shuffled=Row(k[:,:,perm],k[:,:,perm].clone(),pos[:,:,perm],queries=q,query_positions=row.query_positions)
    original=rkv_scores(row,p)
    changed=rkv_scores(shuffled,p)[:,:,torch.argsort(perm[:7])]
    delta=float((original-changed).abs().max())
    assert delta>1e-6
    return dict(same_key_set=True,permuted_only_old_region=True,next_score_max_abs_delta=delta,
                conclusion='Physical ordering is algorithmically material; port preserves topk order; ties remain backend-defined.')


def one_shot_oracle_peak():
    online=NativeReference(model,Policy('last_n',6),synthetic=gates)
    drive(online)
    one=NativeReference(model,Policy('last_n',6),chunk_cap=32,synthetic=gates)
    one.step(IDS)
    assert one.cost['peak_persistent_bytes']>online.cost['peak_persistent_bytes']
    assert one.rows[0].keys.shape[-2]==6
    return dict(online_peak_cache_bytes=online.cost['peak_persistent_bytes'],
                one_shot_peak_cache_bytes=one.cost['peak_persistent_bytes'],
                label='Larger full-history ingestion oracle, never a same-budget serving baseline',
                quality_claim=False)


@torch.inference_mode()
def bf16_native_no_crop():
    bf=tiny_model(torch.bfloat16);gs=synthetic_gates(bf)
    e=NativeReference(bf,Policy('trim_no_crop'),synthetic=gs)
    cache=DynamicCache(config=bf.config);offset=0;errs=[]
    for n in [3,1,4]:
        ids=IDS[:,offset:offset+n];pos=torch.arange(offset,offset+n).unsqueeze(0)
        expected=bf(ids,past_key_values=cache,position_ids=pos,use_cache=True).logits
        actual=e.step(ids)
        errs.append(close(actual,expected,atol=0,rtol=0))
        offset+=n
    return dict(max_abs_error=max(errs),dtype='bfloat16',synthetic_gates_only=True,
                note='Same tiny config precision check, not a model ladder or CPU quality comparison')


for name,fn in [('native_full_and_trim_no_crop_per_call',no_crop_native),
                ('all_policy_indices_cache_bytes_and_reset',cycles_and_byte_hashes),
                ('compressed_multitoken_causality',compressed_multitoken_causality),
                ('qk_norm_global_rope_counter',qk_norm_and_original_positions),
                ('trim_slack_separate_from_protection',slack_and_protection),
                ('rkv_order_sensitivity_diagnostic',order_sensitive_rkv),
                ('one_shot_full_peak_separate_budget',one_shot_oracle_peak),
                ('bf16_native_no_crop',bf16_native_no_crop)]:
    check(name,fn)

cpu=time.process_time()-START_CPU
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
result=dict(status='PASS' if not ERRORS else 'FAIL',tests=TESTS,failures=ERRORS,
            runtime=dict(python=sys.version,torch=torch.__version__,transformers=transformers.__version__,
                         official_qwen3_file=official.__file__,official_qwen3_sha256=hashlib.sha256(Path(official.__file__).read_bytes()).hexdigest(),
                         cpu_seconds=cpu,wall_seconds=time.perf_counter()-START_WALL,peak_rss_bytes=rss),
            model=dict(parameters=sum(p.numel() for p in model.parameters()),dtype='float32 primary; same-config BF16 no-crop check',
                       layers=2,hidden_size=32,query_heads=4,kv_heads=2,head_dim=8,vocab_size=97,
                       native_model_cold_build_seconds=COLD,weights='locally seeded random from Qwen3Config',
                       trained_static_gate_loaded=False,pretrained_loaded=False,gpu_used=False),
            policies=REPORTS,
            limitations=['Own selector/operator integration on official CPU eager runtime; not author GPU/backend performance reproduction.',
                         'RKV retains source topk order; exact ties are backend-defined and post-chunk schedule is a declared adaptation.',
                         'Scratch figures are explicit-tensor conservative estimates; allocator/internal operator temporaries are covered only by process RSS, not per-operation allocation profiling.',
                         'Frozen query/decode selection permits additional resident tokens and is charged; it is not a strict B-token peak.',
                         'Tiny correctness and synthetic gates do not imply base-4B feasibility, artifact quality, output quality, or a method benefit.'])
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],tests=len(TESTS),cpu_seconds=cpu,peak_rss_bytes=rss,output=str(OUT)),indent=2))
assert cpu<110 and rss<1024**3
raise SystemExit(1 if ERRORS else 0)
