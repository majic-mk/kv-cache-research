"""Bounded, own plain-Qwen3 CPU reference. No pretrained loading or upstream execution.

Native decoder layers/attention remain unchanged. This adapter owns cache storage,
absolute-position masks, post-chunk selection, and instrumentation. TRIM/R1KV
math is ported from Apache-2.0 ngocbh/trimkv at 49d2a2951ba12e6431a3986b418ee791b209d7c2.
Only synthetic tiny gates are accepted here; this is not a trained-quality study.
"""
from dataclasses import dataclass, asdict
import hashlib
import json
import math
import random
import time

import torch
from torch.nn import functional as F
from transformers import Qwen3Config, Qwen3ForCausalLM
from transformers.models.qwen3.modeling_qwen3 import rotate_half


def nbytes(t):
    return t.numel() * t.element_size() if t is not None else 0


def tensor_hash(t):
    if t is None:
        return None
    raw = t.detach().contiguous().view(torch.uint8).numpy().tobytes()
    return hashlib.sha256(str((tuple(t.shape), str(t.dtype))).encode() + raw).hexdigest()


def object_hash(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest()


@dataclass(frozen=True)
class Policy:
    name: str = 'full'
    budget: int | None = None
    protected_tail: int = 0
    prefix: int = 0
    buffer: int = 1
    seed: int = 1701
    query_window: int = 2
    kernel: int = 3
    mix_lambda: float = .07

    def __post_init__(self):
        assert self.name in {'full', 'last_n', 'prefix_recent', 'random', 'rkv_port', 'trim', 'trim_no_crop'}
        assert self.buffer >= 1 and self.protected_tail >= 0 and self.prefix >= 0
        if self.name not in {'full', 'trim_no_crop'}:
            assert self.budget is not None and self.budget > 0
            assert self.protected_tail + self.prefix <= self.budget
        if self.name == 'rkv_port':
            assert self.budget > self.query_window > 0
            assert self.protected_tail == self.query_window
            assert self.kernel > 0 and self.kernel % 2 == 1


@dataclass
class Row:
    keys: torch.Tensor
    values: torch.Tensor
    positions: torch.Tensor
    gates: torch.Tensor | None = None
    queries: torch.Tensor | None = None
    query_positions: torch.Tensor | None = None

    def tensors(self):
        return [getattr(self, k) for k in self.__dataclass_fields__]

    def digest(self):
        return {k: tensor_hash(getattr(self, k)) for k in self.__dataclass_fields__}

    def bytes(self):
        return sum(nbytes(x) for x in self.tensors())

    def storage_bytes(self):
        stores = {x.untyped_storage().data_ptr(): x.untyped_storage().nbytes()
                  for x in self.tensors() if x is not None}
        return sum(stores.values())


def tiny_model(dtype=torch.float32):
    """One fixed random tiny config, never a pretrained architecture ladder."""
    torch.manual_seed(3407)
    config = Qwen3Config(vocab_size=97, hidden_size=32, intermediate_size=64,
                         num_hidden_layers=2, num_attention_heads=4,
                         num_key_value_heads=2, head_dim=8,
                         max_position_embeddings=256, attention_dropout=0.,
                         use_sliding_window=False, tie_word_embeddings=False)
    config._attn_implementation = 'eager'
    model = Qwen3ForCausalLM(config).to(device='cpu', dtype=dtype).eval()
    assert sum(p.numel() for p in model.parameters()) < 100_000
    assert all(p.device.type == 'cpu' for p in model.parameters())
    return model


def synthetic_gates(model):
    """Deterministic dimension-compatible gates, explicitly NOT released weights."""
    gen = torch.Generator(device='cpu').manual_seed(2718)
    c = model.config
    dtype = next(model.parameters()).dtype
    result = []
    for _ in model.model.layers:
        result.append([torch.randn(shape, generator=gen, dtype=torch.float32).to(dtype) * .15
                       for shape in [(16, c.hidden_size), (16,),
                                     (c.num_key_value_heads, 16), (c.num_key_value_heads,)]])
    return result


def gate_log_beta(hidden, weights):
    w1, b1, w2, bias = weights
    return F.logsigmoid(F.linear(F.silu(F.linear(hidden, w1, b1)), w2) + bias).transpose(1, 2)


def rkv_scores(row, p):
    """Source-exact default retain_direction='last'; physical order is significant."""
    q, k = row.queries, row.keys
    b, hq, nq, d = q.shape
    hk, n = k.shape[1:3]
    logits = torch.matmul(q.reshape(b, hk, hq // hk, nq, d),
                          k.unsqueeze(2).transpose(3, 4)) / math.sqrt(d)
    logits = logits.max(dim=2).values
    attn = logits[:, :, -p.query_window:, :-p.query_window].softmax(-1, dtype=torch.float32)
    attn = attn.mean(-2).to(q.dtype)
    pooled = F.max_pool1d(attn, p.kernel, padding=p.kernel // 2, stride=1)
    kn = k[0] / (k[0].norm(dim=-1, keepdim=True) + 1e-8)
    sim = torch.matmul(kn, kn.transpose(-1, -2))
    for h in range(hk):
        sim[h].fill_diagonal_(0.)
    mask = sim > .5
    indices = torch.where(mask, torch.arange(n), torch.zeros_like(mask, dtype=torch.long))
    last = indices.max(dim=-1).values
    heads = torch.arange(hk).unsqueeze(1).repeat(1, n)
    seq = torch.arange(n).unsqueeze(0).repeat(hk, 1)
    sim[heads, seq, last] = 0
    similarity = sim.mean(dim=1).softmax(dim=-1)
    return pooled * p.mix_lambda - similarity[:, :-p.query_window] * (1 - p.mix_lambda)


def choose_indices(row, p, seen, rng):
    n = row.keys.shape[-2]
    hk = row.keys.shape[1]
    all_idx = torch.arange(n).reshape(1, 1, n).repeat(1, hk, 1)
    if p.name in {'full', 'trim_no_crop'}:
        return all_idx
    threshold = p.budget + p.buffer if p.name == 'trim' else p.budget
    if n < threshold or (n == p.budget and p.name != 'rkv_port'):
        return all_idx
    if p.name == 'trim':
        scores = row.gates.float() * (seen + 1 - row.positions)
        if p.protected_tail:
            scores[..., -p.protected_tail:] = float('inf')
        return scores.topk(p.budget, dim=-1).indices.sort(dim=-1).values
    if p.name == 'rkv_port':
        scores = rkv_scores(row, p)
        old = scores.topk(p.budget - p.query_window, dim=-1).indices
        tail = all_idx[..., -p.query_window:]
        return torch.cat((old, tail), dim=-1)  # deliberately UNSORTED
    outputs = []
    for h in range(hk):
        pos = row.positions[0, h].tolist()
        order = sorted(range(n), key=lambda j: pos[j])
        if p.name == 'last_n':
            selected = order[-p.budget:]
        elif p.name == 'prefix_recent':
            selected = order[:p.prefix] + order[-(p.budget - p.prefix):] if p.prefix < p.budget else order[:p.prefix]
        else:
            tail = order[-p.protected_tail:] if p.protected_tail else []
            eligible = [j for j in order if j not in tail]
            selected = rng.sample(eligible, p.budget - len(tail)) + tail
        outputs.append(sorted(selected, key=lambda j: pos[j]))
    return torch.tensor([outputs], dtype=torch.long)


def reference_indices(row, p, seen, rng):
    """Separate small oracle: per-head control/score loops; never imports author code."""
    hk, n = row.keys.shape[1:3]
    if p.name in {'full', 'trim_no_crop'} or n < (p.budget + p.buffer if p.name == 'trim' else p.budget):
        return torch.arange(n).reshape(1, 1, n).repeat(1, hk, 1)
    answers = []
    for h in range(hk):
        pos = row.positions[0, h].tolist()
        ordered = sorted(range(n), key=lambda j: pos[j])
        if p.name == 'last_n':
            ans = ordered[-p.budget:]
        elif p.name == 'prefix_recent':
            first = ordered[:p.prefix]
            ans = first + [i for i in ordered if i not in first][-(p.budget - p.prefix):] if p.prefix < p.budget else first
        elif p.name == 'random':
            if n == p.budget:
                ans = ordered
            else:
                tail = ordered[-p.protected_tail:] if p.protected_tail else []
                ans = rng.sample([i for i in ordered if i not in tail], p.budget - len(tail)) + tail
            ans.sort(key=lambda i: pos[i])
        elif p.name == 'trim':
            score = row.gates[0, h].float() * torch.tensor([seen + 1 - i for i in pos])
            if p.protected_tail:
                score[-p.protected_tail:] = float('inf')
            ans = score.topk(p.budget).indices.sort().values.tolist()
        else:
            q = row.queries[0]
            keys = row.keys[0, h]
            group = q.shape[0] // hk
            raw = torch.stack([q[h * group + j] @ keys.T / math.sqrt(keys.shape[-1]) for j in range(group)])
            raw = raw.max(0).values[-p.query_window:, :-p.query_window]
            importance = raw.softmax(-1, dtype=torch.float32).mean(0).to(q.dtype)
            pooled = torch.stack([importance[max(0,j-p.kernel//2):min(len(importance),j+p.kernel//2+1)].max()
                                  for j in range(len(importance))])
            normalized = keys / (keys.norm(dim=-1, keepdim=True) + 1e-8)
            matrix = normalized @ normalized.T
            for i in range(n):
                matrix[i, i] = 0.
                similar = [j for j in range(n) if matrix[i, j] > .5]
                matrix[i, max(similar) if similar else 0] = 0.
            redundancy = matrix.mean(0).softmax(-1)[:-p.query_window]
            scores = pooled * p.mix_lambda - redundancy * (1 - p.mix_lambda)
            ans = scores.topk(p.budget - p.query_window).indices.tolist() + list(range(n-p.query_window,n))
        answers.append(ans)
    return torch.tensor([answers], dtype=torch.long)


def gather_row(row, indices, scalar=False):
    result = {}
    for name in ('keys', 'values', 'positions', 'gates'):
        t = getattr(row, name)
        if t is None:
            result[name] = None
        elif scalar:
            result[name] = torch.stack([torch.stack([t[0,h,j] for j in indices[0,h].tolist()])
                                        for h in range(t.shape[1])]).unsqueeze(0).contiguous()
        else:
            ix = indices.unsqueeze(-1).expand(-1,-1,-1,t.shape[-1]) if t.ndim == 4 else indices
            result[name] = t.gather(2, ix).contiguous()
    # Queries are an independent window, not KV-aligned; never gather by KV indices.
    result['queries'] = row.queries
    result['query_positions'] = row.query_positions
    return Row(**result)


class NativeReference:
    def __init__(self, model, policy, chunk_cap=8, verify=True, synthetic=None):
        c = model.config
        assert c.hidden_size == 32 and c.num_hidden_layers == 2 and c.head_dim == 8
        assert c.num_attention_heads == 4 and c.num_key_value_heads == 2
        assert c.vocab_size == 97 and c._attn_implementation == 'eager'
        assert not model.training and all(p.device.type == 'cpu' for p in model.parameters())
        self.model, self.policy, self.chunk_cap, self.verify = model, policy, chunk_cap, verify
        self.gate_weights = synthetic if synthetic is not None else synthetic_gates(model)
        self.reset()

    def reset(self):
        self.rows = {}
        self.seen = 0
        self.rng = random.Random(self.policy.seed)
        self.calls = []
        self.selection_events = []
        self.pending = {}
        self.phase = 'history'
        self.session = None
        self.cost = dict(forward_seconds=0., gate_seconds=0., selection_seconds=0.,
                         reference_check_seconds=0., gather_seconds=0., append_seconds=0.,
                         append_written_bytes=0, gather_written_bytes=0, query_written_bytes=0,
                         peak_persistent_bytes=0, peak_cache_append_coexist_bytes=0,
                         peak_crop_coexist_bytes=0, peak_attention_scratch_estimate_bytes=0,
                         peak_selector_scratch_upper_estimate_bytes=0,
                         selection_calls=0, scoring_calls=0, crop_calls=0)

    def state_hash(self):
        return object_hash(dict(seen=self.seen, phase=self.phase, session=self.session,
                                rng=repr(self.rng.getstate()),
                                rows={i:r.digest() for i,r in self.rows.items()}))

    def persistent_bytes(self):
        return sum(r.storage_bytes() for r in self.rows.values())

    def update(self, keys, values, layer_idx, *unused, **kwargs):
        """Duck-typed native attention cache API. seen advances ONCE in step()."""
        before = self.persistent_bytes()
        start = time.perf_counter()
        pos = self.current_pos.reshape(1,1,-1).repeat(1, keys.shape[1], 1)
        gate = self.pending.get('gate')
        query = self.pending.get('query')
        qpos = self.current_pos.clone() if query is not None else None
        old = self.rows.get(layer_idx)
        if old is not None:
            keys = torch.cat((old.keys, keys), dim=2)
            values = torch.cat((old.values, values), dim=2)
            pos = torch.cat((old.positions, pos), dim=2)
            if gate is not None:
                gate = torch.cat((old.gates, gate), dim=2)
            if query is not None:
                query = torch.cat((old.queries, query), dim=2)
                qpos = torch.cat((old.query_positions, qpos))
        if query is not None:
            query = query[:, :, -self.policy.query_window:].clone().contiguous()
            qpos = qpos[-self.policy.query_window:].clone()
            self.cost['query_written_bytes'] += nbytes(query) + nbytes(qpos)
        row = Row(keys.contiguous(), values.contiguous(), pos.contiguous(),
                  gate.contiguous() if gate is not None else None, query, qpos)
        self.cost['append_written_bytes'] += row.bytes()
        self.cost['peak_cache_append_coexist_bytes'] = max(self.cost['peak_cache_append_coexist_bytes'], before + row.storage_bytes())
        self.rows[layer_idx] = row
        self.cost['append_seconds'] += time.perf_counter() - start
        self.cost['peak_persistent_bytes'] = max(self.cost['peak_persistent_bytes'], self.persistent_bytes())
        return row.keys, row.values

    def mask(self, layer_idx, positions, dtype):
        hk = self.model.config.num_key_value_heads
        new = positions.reshape(1,1,-1).repeat(1,hk,1)
        past = self.rows.get(layer_idx)
        kp = torch.cat((past.positions, new), dim=2) if past is not None else new
        allowed = kp.unsqueeze(2) <= positions.reshape(1,1,-1,1)
        allowed = allowed.repeat_interleave(self.model.config.num_attention_heads // hk, dim=1)
        mask = torch.zeros(allowed.shape, dtype=dtype).masked_fill_(~allowed, torch.finfo(dtype).min)
        q, k, h, d = len(positions), kp.shape[-1], self.model.config.num_attention_heads, self.model.config.head_dim
        size = torch.empty((), dtype=dtype).element_size()
        # Conservative explicit-tensor estimate, not allocator measurement: GQA repeats,
        # logits/probs/FP32 softmax, masks and q/output. RSS guard is measured separately.
        scratch = 2*h*k*d*size + 3*h*q*k*max(4,size) + allowed.numel() + mask.numel()*size + 2*h*q*d*size
        self.cost['peak_attention_scratch_estimate_bytes'] = max(self.cost['peak_attention_scratch_estimate_bytes'], scratch)
        return mask

    @torch.inference_mode()
    def step(self, ids, session='session0', phase='history', freeze_at_query=True, unsafe_mask=False):
        assert ids.ndim == 2 and ids.shape[0] == 1 and ids.dtype == torch.long and ids.device.type == 'cpu'
        assert 0 < ids.shape[1] <= self.chunk_cap and self.seen + ids.shape[1] <= 128
        assert phase in {'history', 'query', 'decode'}
        assert not (self.phase != 'history' and phase == 'history'), 'reset before new example'
        self.phase, self.session = phase, session
        self.current_pos = torch.arange(self.seen, self.seen + ids.shape[1])
        old_seen = self.seen
        start = time.perf_counter()
        hidden = self.model.model.embed_tokens(ids)
        cos, sin = self.model.model.rotary_emb(hidden, self.current_pos.unsqueeze(0))
        for i, layer in enumerate(self.model.model.layers):
            self.pending = {}
            handles = []
            if self.policy.name in {'trim', 'trim_no_crop'}:
                def before_attention(module, args, kwargs, i=i):
                    t0 = time.perf_counter()
                    self.pending['gate'] = gate_log_beta(kwargs['hidden_states'], self.gate_weights[i])
                    self.cost['gate_seconds'] += time.perf_counter() - t0
                handles.append(layer.self_attn.register_forward_pre_hook(before_attention, with_kwargs=True))
            if self.policy.name == 'rkv_port':
                def after_q_norm(module, args, output):
                    q = output.transpose(1,2)
                    self.pending['query'] = (q * cos.unsqueeze(1) + rotate_half(q) * sin.unsqueeze(1))
                handles.append(layer.self_attn.q_norm.register_forward_hook(after_q_norm))
            mask = self.mask(i, self.current_pos, hidden.dtype)
            if unsafe_mask:
                mask.zero_()  # test-only deliberately leaky negative control
            try:
                hidden = layer(hidden, attention_mask=mask, position_embeddings=(cos,sin),
                               position_ids=self.current_pos.unsqueeze(0), past_key_values=self,
                               use_cache=True)
            finally:
                for handle in handles:
                    handle.remove()
        logits = self.model.lm_head(self.model.model.norm(hidden))
        self.seen += ids.shape[1]
        self.pending = {}
        self.cost['forward_seconds'] += time.perf_counter() - start
        if not (freeze_at_query and phase != 'history'):
            self.compress()
        self.calls.append(dict(start=old_seen, end=self.seen, session=session, phase=phase,
                               chunk_tokens=ids.shape[1], token_ids=ids[0].tolist(),
                               frozen_selection=freeze_at_query and phase != 'history',
                               positions={i:r.positions.tolist() for i,r in self.rows.items()},
                               state_hash=self.state_hash(), persistent_bytes=self.persistent_bytes()))
        return logits

    def compress(self):
        p = self.policy
        for i in list(self.rows):
            row = self.rows[i]
            rng_state = self.rng.getstate()
            t0 = time.perf_counter()
            indices = choose_indices(row,p,self.seen,self.rng)
            self.cost['selection_seconds'] += time.perf_counter()-t0
            self.cost['selection_calls'] += 1
            n, hk = row.keys.shape[-2],row.keys.shape[1]
            trigger = p.budget is not None and n >= (p.budget+p.buffer if p.name=='trim' else p.budget)
            if trigger and p.name in {'trim','rkv_port'}:
                self.cost['scoring_calls'] += 1
                # Includes FP tensors, bool masks, int64 index matrices and pool/logit buffers.
                estimate = hk*n*n*40 + self.model.config.num_attention_heads*p.query_window*n*24 if p.name=='rkv_port' else hk*n*32
                self.cost['peak_selector_scratch_upper_estimate_bytes'] = max(self.cost['peak_selector_scratch_upper_estimate_bytes'],estimate)
            expected_row = None
            if self.verify:
                t0 = time.perf_counter()
                oracle_rng = random.Random();oracle_rng.setstate(rng_state)
                expected = reference_indices(row,p,self.seen,oracle_rng)
                assert torch.equal(indices,expected), (p.name,i,indices,expected)
                assert self.rng.getstate() == oracle_rng.getstate(), 'RNG progression'
                expected_row = gather_row(row, expected, scalar=True)
                self.cost['reference_check_seconds'] += time.perf_counter()-t0
            identity = indices.shape[-1] == n and torch.equal(indices, torch.arange(n).reshape(1,1,n).repeat(1,hk,1))
            if identity:
                after = row
            else:
                t0 = time.perf_counter()
                after = gather_row(row, indices)
                self.cost['gather_seconds'] += time.perf_counter()-t0
                self.cost['gather_written_bytes'] += sum(nbytes(getattr(after,k)) for k in ('keys','values','positions','gates'))
                self.cost['peak_crop_coexist_bytes'] = max(self.cost['peak_crop_coexist_bytes'],self.persistent_bytes()+after.storage_bytes())
                self.rows[i] = after
                self.cost['crop_calls'] += 1
            if self.verify:
                assert after.digest() == expected_row.digest(), 'per-array byte identity against scalar gather'
            assert after.storage_bytes() == after.bytes(), 'unexpected backing-store retention/alias'
            assert after.keys.shape[1] == self.model.config.num_key_value_heads
            if p.protected_tail:
                for h in range(hk):
                    assert set(range(max(0,self.seen-p.protected_tail),self.seen)).issubset(after.positions[0,h].tolist())
            event = dict(layer=i,seen=self.seen,policy=p.name,prior_tokens=n,retained_tokens=after.keys.shape[-2],
                         selected_indices=indices.tolist(),positions=after.positions.tolist(),
                         byte_hashes=after.digest(), reference_byte_hashes=expected_row.digest() if expected_row else None,
                         reference_match=self.verify,buffer_slack=p.buffer if p.name=='trim' else 0,
                         protected_tail=p.protected_tail,
                         chronological=bool((after.positions[...,1:]>after.positions[...,:-1]).all()))
            self.selection_events.append(event)

    def report(self):
        return dict(policy=asdict(self.policy),calls=self.calls,events=self.selection_events,
                    state_hash=self.state_hash(),cost=self.cost,
                    persistent_bytes=self.persistent_bytes(),
                    synthetic_gate_parameter_bytes=sum(nbytes(x) for ws in self.gate_weights for x in ws),
                    source_semantics='post-chunk selector/operator port, native official CPU eager attention')
