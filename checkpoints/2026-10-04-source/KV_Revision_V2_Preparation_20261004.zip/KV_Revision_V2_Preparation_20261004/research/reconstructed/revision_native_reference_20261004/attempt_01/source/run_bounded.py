"""Own guard: cumulative <=120 CPU seconds, combined process RSS <=1 GiB.

Preserves every attempt, including failures. No package installation/download or GPU.
RSS sampling is not a hard cgroup limit; CPU has an additional child RLIMIT_CPU.
"""
from pathlib import Path
import json,os,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
LIMIT=1024**3; DISK=5_000_000_000; RETAIN=20_000_000

def process_table():
    result={}
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            text=path.read_text();a=text[text.rindex(')')+2:].split()
            result[int(path.parent.name)]=(int(a[1]),(int(a[11])+int(a[12]))/os.sysconf('SC_CLK_TCK'),int(a[21])*os.sysconf('SC_PAGE_SIZE'))
        except (OSError,ValueError,IndexError):pass
    return result

old=[json.loads(p.read_text()) for p in P.glob('attempt_*/guard.json')]
spent=sum(r.get('child_cpu_seconds',0.) for r in old)
assert spent<110,'Prior attempts exhausted the total CPU allowance'
assert os.statvfs(P).f_bavail*os.statvfs(P).f_frsize>DISK
attempt=P/f'attempt_{len(old)+1:02d}';attempt.mkdir(exist_ok=False)
cmd=['bash',str(ROOT/'research/reconstructed/runtime_recovery_20261004/cpu_python.sh'),str(P/'verify_reference.py'),str(attempt/'verification.json')]
start=time.monotonic();peak=0;termination=None;child_cpu=0
with (attempt/'verification.log').open('w') as log:
    proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    while proc.poll() is None:
        table=process_table();children={proc.pid};previous=set()
        while children!=previous:
            previous=children.copy();children|={pid for pid,(ppid,_,_) in table.items() if ppid in children}
        cpu=sum(table[p][1] for p in children if p in table)
        child_cpu=max(child_cpu,cpu)
        rss=sum(table[p][2] for p in children|{os.getpid()} if p in table)
        peak=max(peak,rss)
        if rss>=LIMIT:termination='COMBINED_RSS_LIMIT'
        if spent+cpu>=115:termination='CUMULATIVE_CPU_LIMIT'
        if time.monotonic()-start>180:termination='WALL_LIMIT'
        if os.statvfs(P).f_bavail*os.statvfs(P).f_frsize<DISK:termination='DISK_RESERVE_LIMIT'
        if sum(p.stat().st_size for p in P.rglob('*') if p.is_file())>=RETAIN:termination='RETAINED_FILE_LIMIT'
        if termination:os.killpg(proc.pid,signal.SIGKILL);proc.wait();break
        time.sleep(.025)
rc=proc.wait()
import resource
child_cpu=max(child_cpu,resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime)
r=dict(exit_code=rc,termination=termination,combined_sampled_peak_rss_bytes=peak,rss_limit_bytes=LIMIT,
       child_cpu_seconds=child_cpu,cumulative_child_cpu_seconds=spent+child_cpu,cpu_limit_seconds=120,
       elapsed_seconds=time.monotonic()-start,wall_limit_seconds=180,monitor_interval_seconds=.025,
       retained_bytes=sum(p.stat().st_size for p in P.rglob('*') if p.is_file()),disk_free_bytes=os.statvfs(P).f_bavail*os.statvfs(P).f_frsize,
       command=cmd,guard_limit='Sampled combined RSS, not a hard cgroup; child hard RLIMIT_CPU=115 seconds')
(attempt/'guard.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2));print((attempt/'verification.log').read_text());raise SystemExit(rc)
