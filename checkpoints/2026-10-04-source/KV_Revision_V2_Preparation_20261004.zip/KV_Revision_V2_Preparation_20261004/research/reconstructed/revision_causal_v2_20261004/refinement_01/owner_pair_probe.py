"""At most three prospectively fixed owner-label pairs; tokenization only."""
from pathlib import Path
import json,hashlib,sys
from tokenizers import Tokenizer
O=Path(__file__).resolve().parent;V2=O.parent;V1=V2.parent/'revision_causal_input_packet_20261004'
pairs=[['current user','other user'],['primary user','separate user'],['this user','another user']]
plan={'authorization':'Parent 2026-10-04 13:07 UTC: bounded <=3 clear owner pairs, same cases/budgets, no model','pairs_in_order':pairs,'stop':'First pair with equal full-wrapper token counts for both fixed source quotations; at most three pairs, no extra phrase search','selection_or_labels_changed':False,'previous_v2_renderings_preserved':True,'semantic_interpretation':'First owner is the queried user; second is an entirely unrelated user and group. Original source-report dates and verbatim old quotations unchanged.'}
b=(json.dumps(plan,indent=2)+'\n').encode();(O/'prospective_refinement.json').write_bytes(b);(O/'prospective_refinement.sha256').write_text(hashlib.sha256(b).hexdigest()+'\n')
tokpath=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/data_prep/local/tokenizer/tokenizer.json');assert hashlib.sha256(tokpath.read_bytes()).hexdigest()=='aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4';t=Tokenizer.from_file(str(tokpath))
rows=json.loads((V2/'selected_semantics_reviewed.json').read_text());src={x['question_id']:x for x in json.loads((V1/'sources/longmemeval_oracle.json').read_text())}
results=[];chosen=None
for pair in pairs:
 cases=[]
 for row in rows:
  x=src[row['question_id']];date=x['haystack_dates'][row['old_quote_location']['session']]
  texts=['Archived duplicate. Original assertion date: '+date+'. Quote owner='+owner+'. This repeats that dated assertion; it is not a new event.\nQuotation: "'+row['old_quote']+'"\nNeutral margin:' for owner in pair]
  ns=[len(t.encode(s,add_special_tokens=False).ids) for s in texts]
  cases.append({'question_id':row['question_id'],'token_counts':ns,'equal':ns[0]==ns[1],'text_sha256':[hashlib.sha256(s.encode()).hexdigest() for s in texts]})
 result={'pair':pair,'cases':cases,'passes':all(x['equal'] for x in cases)};results.append(result)
 if result['passes']:chosen=pair;break
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'owner_pair_probe_result.json').write_text(json.dumps({'tested_pairs':results,'chosen_pair':chosen,'pairs_tested':len(results),'model_calls':0,'tokenizer_only':True},indent=2)+'\n');print(json.dumps({'tested_pairs':results,'chosen_pair':chosen},indent=2))
