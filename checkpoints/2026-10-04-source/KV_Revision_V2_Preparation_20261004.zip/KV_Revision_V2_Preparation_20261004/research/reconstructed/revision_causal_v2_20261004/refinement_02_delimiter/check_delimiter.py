"""Single authorized boundary-normalization diagnostic; no new label search."""
from pathlib import Path
import json,hashlib
from tokenizers import Tokenizer
O=Path(__file__).resolve().parent;V2=O.parent;V1=V2.parent/'revision_causal_input_packet_20261004'
p={'scope':'Exactly first previously tested label pair with parent-specified standard colon-space delimiter','pair':['current user','other user'],'exact_field_prefix':'Archive owner: ','authorization':'Parent 2026-10-04 13:09 UTC; diagnose possible BPE merge at owner=','no_other_pairs':True,'old_16_and_failed_probes_preserved':True,'model_outcomes_exist':False}
b=(json.dumps(p,indent=2)+'\n').encode();(O/'prospective_delimiter_check.json').write_bytes(b);(O/'prospective_delimiter_check.sha256').write_text(hashlib.sha256(b).hexdigest()+'\n')
path=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/data_prep/local/tokenizer/tokenizer.json');assert hashlib.sha256(path.read_bytes()).hexdigest()=='aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4';t=Tokenizer.from_file(str(path))
rows=json.loads((V2/'selected_semantics_reviewed.json').read_text());source={x['question_id']:x for x in json.loads((V1/'sources/longmemeval_oracle.json').read_text())};result=[]
for row in rows:
 x=source[row['question_id']];date=x['haystack_dates'][row['old_quote_location']['session']]
 texts=['Archived duplicate. Original assertion date: '+date+'. Archive owner: '+label+'. This repeats that dated assertion; it is not a new event.\nQuotation: "'+row['old_quote']+'"\nNeutral margin:' for label in p['pair']]
 counts=[len(t.encode(x,add_special_tokens=False).ids) for x in texts]
 result.append({'question_id':row['question_id'],'counts':counts,'equal':counts[0]==counts[1],'text_sha256':[hashlib.sha256(s.encode()).hexdigest() for s in texts]})
fragments={s:t.encode(s,add_special_tokens=False).tokens for s in ['Quote owner=current user','Quote owner=other user','Archive owner: current user','Archive owner: other user']}
answer={'cases':result,'all_equal':all(x['equal'] for x in result),'boundary_tokenization':fragments,'model_calls':0,'tokenizer_only':True};(O/'delimiter_check_result.json').write_text(json.dumps(answer,indent=2)+'\n');print(json.dumps(answer,indent=2))
