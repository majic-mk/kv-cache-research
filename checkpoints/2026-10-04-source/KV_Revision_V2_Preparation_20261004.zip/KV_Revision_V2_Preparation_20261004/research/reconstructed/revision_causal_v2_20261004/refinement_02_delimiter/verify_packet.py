"""Independent stdlib-only verifier for rendered metadata and immutable-source preservation."""
from pathlib import Path
import json,hashlib,re,collections
O=Path(__file__).resolve().parent;V2=O.parent;V1=V2.parent/'revision_causal_input_packet_20261004'
def sha(b):return hashlib.sha256(b).hexdigest()
raw=(V1/'sources/longmemeval_oracle.json').read_bytes();assert sha(raw)=='821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c'
source={x['question_id']:x for x in json.loads(raw)}
for name,digest in json.loads((V2/'v1_immutability_reference.json').read_text()).items():assert sha((V1/name).read_bytes())==digest
rows=json.loads((V2/'eligibility_55_final.json').read_text());assert len(rows)==55 and len({x['question_id'] for x in rows})==55
selected=json.loads((V2/'selected_families_frozen.json').read_text());assert [x['question_id'] for x in selected]==['c7dc5443','6a1eabeb']
rank=sorted([x for x in rows if x['final_disposition']=='admit'],key=lambda x:x['rank_hash']);assert [x['question_id'] for x in rank[:2]]==[x['question_id'] for x in selected]
vs=json.loads((O/'constructed_variants.json').read_text());assert len(vs)==16;assert len({x['variant_id'] for x in vs})==16
summ=[]
for qid in [x['question_id'] for x in selected]:
 vv=[x for x in vs if x['question_id']==qid];assert len(vv)==8
 assert len({v['total_input_tokens'] for v in vv})==1 and len({v['query_absolute_start'] for v in vv})==1
 assert len({len(v['online_chunk_end_indices']) for v in vv})==1
 x=source[qid];orig=[[t['content'] for t in ss] for ss in x['haystack_sessions']]
 for v in vv:
  assert v['author_answer']==x['answer']
  parsed=re.findall(r'<\|im_start\|>(system|user|assistant)\n(.*?)<\|im_end\|>\n',v['canonical_prompt'],flags=re.S)
  assert len(parsed)==len(v['message_lineage'])
  seen=[]
  for k,l in enumerate(v['message_lineage']):
   if l['kind']=='original_source':
    si,ti=l['session'],l['turn'];expected=('Session date: '+x['haystack_dates'][si]+'\n' if ti==0 else '')+orig[si][ti]
    assert parsed[k][0]==x['haystack_sessions'][si][ti]['role'] and parsed[k][1]==expected;seen.append((si,ti))
  assert seen==[(si,ti) for si,ss in enumerate(x['haystack_sessions']) for ti in range(len(ss))]
  assert 'has_answer' not in v['canonical_prompt'] and 'answer_session_ids' not in v['canonical_prompt']
  ends=v['online_chunk_end_indices'];assert ends[-1]==len(v['canonical_token_ids'])==v['total_input_tokens']
  assert all(0<b-a<=128 for a,b in zip([0]+ends[:-1],ends))
  assert v['history_tokens'] in ends
  assert sha(json.dumps(v['canonical_token_ids'],separators=(',',':')).encode())==v['canonical_ids_sha256']
  assert v['inference_authorized'] is False
 for p in ['reservoir_before','reservoir_after']:
  z=[v for v in vv if v['placement']==p];assert len(z)==4
  assert all(v['original_source_token_ranges']==z[0]['original_source_token_ranges'] for v in z)
  r=next(v for v in z if v['condition']=='high_relevant');i=next(v for v in z if v['condition']=='high_irrelevant')
  assert r['old_alias_counts']==i['old_alias_counts'] and r['new_alias_counts']==i['new_alias_counts']
  assert r['canonical_prompt']==i['canonical_prompt'].replace('Archive owner: other user. This repeats','Archive owner: current user. This repeats')
  assert all(v['new_alias_counts']==z[0]['new_alias_counts'] for v in z)
 summ.append({'question_id':qid,'variants':8,'tokens':vv[0]['total_input_tokens'],'online_chunks':len(vv[0]['online_chunk_end_indices']),'last_semantic_span_ages_after_query':{p:next(v['last_semantic_echo']['age_after_query_suffix'] for v in vv if v['placement']==p) for p in ['reservoir_before','reservoir_after']}})
result={'status':'PASS_INPUT_STRUCTURE_ONLY','v1_immutable':True,'source_hash_verified':True,'eligibility_population':55,'eligibility_counts':dict(collections.Counter(x['final_disposition'] for x in rows)),'selection_unchanged':True,'variant_count':16,'whole_original_source_verbatim_preserved':True,'exact_token_counts_and_query_positions_match':True,'source_positions_match_within_placement':True,'query_suffix_count_matches':True,'online_call_counts_match':True,'online_max_chunk_tokens':128,'relevant_irrelevant_value_counts_match':True,'current_value_counts_fixed':True,'author_answers_unchanged':True,'no_annotation_leakage':True,'families':summ,'model_calls':0,'gpu_calls':0,'new_download_bytes':0,'limitations':['This independent verifier checks saved token metadata, not numerical model execution. Tokenizer-prefix checks are in build_variants.py.','Semantic labels require rendered_semantic_review.json.','Any inference needs separate baseline/Full-parity approval.']}
(O/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
