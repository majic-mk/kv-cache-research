"""Offline input construction only; no model/runtime/network acquisition or inference."""
from pathlib import Path
import json, hashlib, re, sys, resource
from tokenizers import Tokenizer
from jinja2 import Environment
O=Path(__file__).resolve().parent;V2=O.parent;V1=V2.parent/'revision_causal_input_packet_20261004'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=(V1/'sources/longmemeval_oracle.json').read_bytes();assert sha(raw)=='821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c'
source=json.loads(raw);byid={x['question_id']:x for x in source}
localtok=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/data_prep/local/tokenizer/tokenizer.json')
assert sha(localtok.read_bytes())=='aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4'
tok=Tokenizer.from_file(str(localtok));tc=json.loads((V1/'sources/qwen3_4b__tokenizer_config.json').read_text());template=Environment().from_string(tc['chat_template'])
plan=json.loads((V2/'selected_semantics_reviewed.json').read_text());variants=[];summaries=[];failures=[]
SYSTEM=('Answer the final question about the user using the dated source conversation. Follow the time requested by the question. '
'Inserted archival quotes are clearly labeled: Archive owner: current user identifies the queried user; Archive owner: other user identifies a completely unrelated person, '
'and I/my, we/our, names, and group references inside an other-user quote identify that unrelated person and their own unrelated group. '
'Dates on archival duplicates are source-report dates, not independently asserted event dates. An archival duplicate repeats the original dated assertion and never reports a new event or reinstatement. '
'Layout samples are unrelated neutral text. A concise answer may distinguish historical and current facts when useful.')
reservoir=[
 [('user','Layout sample A, unrelated to the user history: A quiet harbor rests beneath a pale sky. Soft rain touches a stone path beside a cedar fence. A canvas awning shades an empty courtyard. Wind moves gently through dry reeds near a sheltered inlet. Smooth pebbles lie beside weathered bricks. A broad cloud drifts above distant hills. Pale light reaches the edge of a wooden doorway. The scene is a neutral descriptive passage for checking page layout.'),('assistant','Layout sample A recorded as unrelated descriptive text.')],
 [('user','Layout sample B, unrelated to the user history: A narrow path winds through a grove of silver birches. Fallen leaves cover damp soil near an old stone wall. Beyond the clearing, a meadow slopes toward a still pond. Evening light softens the outlines of the trees. Small branches cast shadows across a wooden bench. A linen curtain hangs beside an open window. The scene supplies a different neutral descriptive passage for checking page layout.'),('assistant','Layout sample B recorded as unrelated descriptive text.')]
]
neutral_low=['A margin sample describes a linen curtain near a cedar fence.','A margin sample describes soft rain beside a stone doorway.','A margin sample describes a pale cloud over a quiet meadow.']
neutral_high='A repeated margin sample describes a smooth pebble beside a wooden bench.'
padwords=['amber','moss','slate','linen','willow','cedar','canvas','marble','velvet','meadow','copper','birch']
def enc(s):return tok.encode(s,add_special_tokens=False)
def render(msgs,gen=False):return template.render(messages=msgs,tools=None,add_generation_prompt=gen)
def clean_sessions(x):return [[{'role':t['role'],'content':t['content']} for t in ss] for ss in x['haystack_sessions']]
def literal_counts(text,aliases):
 return {a:len(list(re.finditer(r'(?<!\w)'+re.escape(a)+r'(?!\w)',text,re.I))) for a in aliases}
def make_slot(x,quote,owner,neutral=None):
 owner={'user':'current user','peer':'other user'}[owner]
 header='Archived duplicate. Original assertion date: '+x+'. Archive owner: '+owner+'. This repeats that dated assertion; it is not a new event.\n'
 if neutral is not None:header='Archived neutral note. Original note date: '+x+'. Archive owner: '+owner+'. This is unrelated layout text.\n'
 return header+'Quotation: "'+(quote if neutral is None else neutral)+'"\nNeutral margin:'
def pad_to(text,n):
 s=text;i=0
 while len(enc(s).ids)<n:
  current=len(enc(s).ids); chosen=None
  # A word is not necessarily one tokenizer token. Bounded lookahead over the
  # same frozen neutral vocabulary avoids overshooting the fixed token target.
  for offset in range(len(padwords)):
   candidate=s+' '+padwords[(i+offset)%len(padwords)]
   size=len(enc(candidate).ids)
   if current<size<=n:
    chosen=candidate;i+=offset+1;break
  if chosen is None:raise ValueError('Exact neutral-token match unavailable with frozen vocabulary')
  s=chosen
  if i>1000:raise RuntimeError('bounded neutral pad limit')
 if len(enc(s).ids)!=n:raise ValueError('Exact token match failed without text repair')
 return s
for family_no,p in enumerate(plan):
 qid=p['question_id'];x=byid[qid]
 try:
  assert p['semantic_review_status']=='approved_for_input_construction'
  oldloc=p['old_quote_location'];quote=p['old_quote'];oldturn=x['haystack_sessions'][oldloc['session']][oldloc['turn']]['content']
  assert quote in oldturn
  new_session=p['new_value_location']['session'];assert oldloc['session']<new_session
  olddate=x['haystack_dates'][oldloc['session']]
  conditions=['low_zero','high_relevant','high_irrelevant','high_neutral']
  rawslots={
   'low_zero':[make_slot(olddate,quote,'user',n) for n in neutral_low],
   'high_relevant':[make_slot(olddate,quote,'user')]*3,
   'high_irrelevant':[make_slot(olddate,quote,'peer')]*3,
   'high_neutral':[make_slot(olddate,quote,'user',neutral_high)]*3}
  target=max(len(enc(s).ids) for ss in rawslots.values() for s in ss)+16
  slots={c:[pad_to(s,target) for s in ss] for c,ss in rawslots.items()}
  aliases=p['old_aliases']+p['new_aliases']
  # Relevant/irrelevant manipulate owner only; every listed answer-string count matches.
  assert literal_counts('\n'.join(slots['high_relevant']),aliases)==literal_counts('\n'.join(slots['high_irrelevant']),aliases)
  assert all(a==b.replace('Archive owner: other user','Archive owner: current user') for a,b in zip(slots['high_relevant'],slots['high_irrelevant']))
  for c in ['low_zero','high_neutral']:
   for a,n in literal_counts('\n'.join(slots[c]),aliases).items():
    # Date digits may coincide with very short aliases: these remain a documented shared nuisance.
    pass
  order=[0,1] if family_no==0 else [1,0]
  neutral_msgs=[{'role':r,'content':s} for j in order for r,s in reservoir[j]]
  famvars=[]
  for placement in ['reservoir_before','reservoir_after']:
   for condition in conditions:
    msgs=[{'role':'system','content':SYSTEM}];lineage=[{'kind':'system'}]
    if placement=='reservoir_before':
     msgs+=neutral_msgs;lineage += [{'kind':'neutral_reservoir'} for _ in neutral_msgs]
    for si,ss in enumerate(x['haystack_sessions']):
     if si==new_session:
      for k,s in enumerate(slots[condition]):
       msgs += [{'role':'user','content':s},{'role':'assistant','content':'The dated quotation has been recorded with its stated owner.'}]
       lineage += [{'kind':'insertion','copy_slot':k},{'kind':'insertion_ack','copy_slot':k}]
     for ti,t in enumerate(ss):
      content=t['content']
      if ti==0:content='Session date: '+x['haystack_dates'][si]+'\n'+content
      msgs.append({'role':t['role'],'content':content});lineage.append({'kind':'original_source','session':si,'turn':ti})
    if placement=='reservoir_after':
     msgs+=neutral_msgs;lineage += [{'kind':'neutral_reservoir'} for _ in neutral_msgs]
    history=render(msgs);history_n=len(enc(history).ids)
    msgs.append({'role':'user','content':'Current date: '+x['question_date']+'\nQuestion: '+x['question']});lineage.append({'kind':'final_query'})
    prompt=render(msgs,True);e=enc(prompt);bounds=[];ranges=[]
    prev=0
    for k in range(1,len(msgs)+1):
     pre=render(msgs[:k]);ids=enc(pre).ids;assert e.ids[:len(ids)]==ids
     bounds.append(len(ids));ranges.append((prev,len(ids)));prev=len(ids)
    assert bounds[-2]==history_n
    # Original source content remains verbatim in exactly the original source message slots.
    source_ranges=[]
    for k,l in enumerate(lineage):
     if l['kind']=='original_source':
      si,ti=l['session'],l['turn'];orig=x['haystack_sessions'][si][ti]['content']
      exp=('Session date: '+x['haystack_dates'][si]+'\n' if ti==0 else '')+orig
      assert msgs[k]['content']==exp;source_ranges.append({'session':si,'turn':ti,'token_range':ranges[k]})
    # Selected independently reviewed semantic echoes are exact source spans, including coreference where stated.
    echoes=[]
    for note in p['current_semantic_echoes']:
     si,ti=note['session'],note['turn'];snippet=note['text'];orig=x['haystack_sessions'][si][ti]['content'];assert snippet in orig
     k=next(k for k,l in enumerate(lineage) if l.get('kind')=='original_source' and l.get('session')==si and l.get('turn')==ti)
     # Locate within the canonical message via character lengths of prior rendered messages.
     prefix=render(msgs[:k]);fullmsg=render(msgs[:k+1]);local=fullmsg[len(prefix):];loc=local.find(snippet);assert loc>=0
     start=len(prefix)+loc;end=start+len(snippet)
     ix=[j for j,(a,b) in enumerate(e.offsets) if a<end and b>start];assert ix
     echoes.append({**note,'char_range':[start,end],'token_range':[min(ix),max(ix)+1],'age_at_history_end':history_n-max(ix)-1,'age_after_query_suffix':len(e.ids)-max(ix)-1})
    last=max(echoes,key=lambda z:z['token_range'][1]);W=128
    # Fixed maximum chunk size; recorded-message boundaries remain explicit.
    online_ends=[]; previous_end=0
    for message_end in bounds+[len(e.ids)]:
     if message_end>previous_end:
      online_ends.extend(range(previous_end+128,message_end,128)); online_ends.append(message_end)
     previous_end=message_end
    assert all(b-a<=128 for a,b in zip([0]+online_ends[:-1],online_ends))
    suffix_checks=[]
    for k,point in enumerate(online_ends):
     # Span coverage is symbolic for the named W-tail control only, not a runtime eviction log.
     end=last['token_range'][1]
     if point>=end:suffix_checks.append({'chunk_end_index':k,'processed_tokens':point,'echo_fully_in_reference_tail':last['token_range'][0]>=max(0,point-W),'echo_age':point-end})
    v={'variant_id':qid+'__'+placement+'__'+condition,'question_id':qid,'condition':condition,'placement':placement,'reservoir_order':'AB' if family_no==0 else 'BA','copy_slot_count':3,'added_target_relevant_old_copies':3 if condition=='high_relevant' else 0,'added_irrelevant_same_string_copies':3 if condition=='high_irrelevant' else 0,'author_answer':x['answer'],'review_current_value':p['new_value'],'review_competitor_value':p['old_value'],'canonical_prompt':prompt,'canonical_token_ids':e.ids,'canonical_ids_sha256':sha(json.dumps(e.ids,separators=(',',':')).encode()),'total_input_tokens':len(e.ids),'history_tokens':history_n,'query_absolute_start':history_n,'original_source_token_ranges':source_ranges,'message_lineage':lineage,'recorded_message_end_indices':bounds,'online_chunk_end_indices':online_ends,'online_max_chunk_tokens':128,'source_verbatim_preserved':True,'old_alias_counts':literal_counts(prompt,p['old_aliases']),'new_alias_counts':literal_counts(prompt,p['new_aliases']),'semantic_echoes':echoes,'last_semantic_echo':last,'reference_tail_W':W,'tail_checks_at_chunk_ends':suffix_checks,'tail_checks_after_generation_offsets':[{'offset':d,'echo_fully_in_reference_tail':last['token_range'][0]>=len(e.ids)+d-W,'echo_age':len(e.ids)+d-last['token_range'][1]} for d in [1,16,32]],'status':'FROZEN_CONSTRUCTED_INPUT_NOT_MODEL_RESULT','inference_authorized':False}
    famvars.append(v)
  assert len({v['total_input_tokens'] for v in famvars})==1
  assert len({v['query_absolute_start'] for v in famvars})==1
  for placement in ['reservoir_before','reservoir_after']:
   vv=[v for v in famvars if v['placement']==placement];ref=vv[0]['original_source_token_ranges']
   assert all(v['original_source_token_ranges']==ref for v in vv)
   rr=next(v for v in vv if v['condition']=='high_relevant');ir=next(v for v in vv if v['condition']=='high_irrelevant')
   assert rr['old_alias_counts']==ir['old_alias_counts'] and rr['new_alias_counts']==ir['new_alias_counts']
   assert len({json.dumps(v['new_alias_counts'],sort_keys=True) for v in vv})==1
  for c in conditions:
   aa=next(v for v in famvars if v['condition']==c and v['placement']=='reservoir_before');bb=next(v for v in famvars if v['condition']==c and v['placement']=='reservoir_after')
   assert aa['old_alias_counts']==bb['old_alias_counts'] and aa['new_alias_counts']==bb['new_alias_counts']
  variants+=famvars
  summaries.append({'question_id':qid,'variants':len(famvars),'total_tokens':famvars[0]['total_input_tokens'],'query_position_fixed':True,'source_preserved':True,'source_positions_equal_within_age':True,'old_alias_counts_high_relevant':next(v['old_alias_counts'] for v in famvars if v['condition']=='high_relevant'),'old_alias_counts_low':famvars[0]['old_alias_counts'],'new_alias_counts_all_conditions':famvars[0]['new_alias_counts'],'last_echo_ages_after_query_by_placement':{p0:next(v['last_semantic_echo']['age_after_query_suffix'] for v in famvars if v['placement']==p0) for p0 in ['reservoir_before','reservoir_after']},'reference_tail_crossed_after_query':len({next(v['tail_checks_after_generation_offsets'][0]['echo_fully_in_reference_tail'] for v in famvars if v['placement']==p0) for p0 in ['reservoir_before','reservoir_after']})>1})
 except Exception as exc:
  failures.append({'question_id':qid,'construction_failed':True,'error':repr(exc),'replacement':False})
# A failure is recorded, not silently retried with a changed semantic construction.
assert len(variants)<=16
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
dump('constructed_variants.json',variants);dump('construction_audit.json',{'families':summaries,'failures':failures,'variants':len(variants),'model_calls':0,'torch_imported':False,'transformers_imported':False,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'notes':['Online calls split recorded messages into at most 128 canonical tokens; these potential eviction points must be honored by later method adapters.','Tail coverage refers only to explicit W=128 control, not native TRIM.','Semantic echo inventory is human reviewed, not proof against latent state diffusion.']})
print(json.dumps({'families':summaries,'failures':failures,'variants':len(variants)},indent=2))
