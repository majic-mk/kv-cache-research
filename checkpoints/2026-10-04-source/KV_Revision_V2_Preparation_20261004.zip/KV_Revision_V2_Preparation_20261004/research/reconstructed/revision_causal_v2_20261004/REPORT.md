# V2 revision-causal input feasibility

Date: 2026-10-04 UTC. One final zero-weight preparation pass. This packet reuses the verified source and tokenizer; it does not modify V1, run a model, or certify a paper contribution.

## Result

Active final inputs are in `refinement_02_delimiter/`; `LATEST_INPUTS.json` identifies their hash. The original 16 renderings and failed owner-pair probes are preserved. A prospectively authorized colon-space normalization removes the original extra-padding nuisance: exact whole-prompt comparisons now differ only in the three inserted owner labels. The fixed shared interpretation text is identical across arms.

**Sixteen exact-token-matched constructed inputs were produced for the two prospectively selected source families. Structural validation passes. Model/GPU work remains blocked pending the separate baseline and inference decisions.**

The construction establishes that this narrow input contrast is feasible. It does not establish model competence, stale-answer errors, compression benefit/harm, a policy ranking change, statistical power or publication readiness. It is a constructed probe using complete oracle evidence sessions, not natural full-LongMemEval-S parity.

The [independent design review](../revision_causal_design_review_20261004.md) substantially narrows novelty. Changed-fact cache interventions, superseded-value interference, stale-aware management and online update handling already have close prior work. The residual question is a budget-driven irreversible-eviction interaction involving obsolete-copy relevance/frequency, controlled placement/age and ingestion regime. These files do not demonstrate that interaction.

## Prospective population and fixed selection

The versioned rule was frozen before V2 eligibility and family selection in `protocol_preselection_frozen.json`. It was applied to all **55** V1 latest-functional-state rows, using source content only. The original 500-record oracle, 78-row taxonomy and V1 fixed four were reused by hash and remain unchanged.

Two independent input reviews produced:

- **27 joint admissions**
- **16 joint rejections**
- **12 non-admitted review disagreements**

Disagreements are not proof of true ineligibility. In particular, the second reviewer found unmarked direct old-value statements for bike ownership and the composition of Rachel's team; initial missing-direct-value rationales were incomplete. Those corrections are recorded. Neither was quietly inserted into the cohort after ranking. This conservative feasibility subset is not a final estimate of every valid case in the corpus.

Shared source histories were grouped before ascending SHA-256 ranking with salt `revision-causal-v2-20261004`. The fixed cap was **two independent families**, without replacement:

1. `c7dc5443`: current volleyball record, old **3-2**, latest **5-2**
2. `6a1eabeb`: charity 5K personal best, old **27:12**, latest **25:50**

The two original source conversations were read completely, covering 48 turns. Both selected semantic constructions were supported. V1's two prior-state questions, lens item and abstention remain attached to their original audit; they were not replaced or counted as an independent extra dataset.

## What was constructed

Each source family has four copy conditions and two reservoir placements, yielding eight canonical inputs:

- Low exposure: no added old-value copies; three varied neutral slots
- High relevant: three dated copies of the user's old assertion
- High irrelevant: identical quotation/date/value strings, but the quote belongs to an explicitly unrelated peer and peer group
- High neutral: three repeated neutral-copy slots

All original source turns are byte-for-byte intact within their original messages. Insertions occur before the newer source session. Their dates are original **source-report timestamps**, not invented race/game dates. The fixed interpretation text resolves I/my and we/our, names and groups to the declared quote owner. A duplicate is explicitly historical, not a new event or reinstatement.

Both relevance arms retain the original old/new history. Therefore the contrast is **relevance of added obsolete copies conditional on the same original update**. It is not a no-conflict control history. The neutral branch separately controls added lexical repetition/filler effects. Literal counts are diagnostics, never semantic scores.

The first rendering had a residual nuisance: its relevant/peer branches also differed in target-free padding. That version and `control_nuisance_audit.json` remain preserved. The final delimiter-normalized rendering removes this nuisance: whole-prompt substitution checks verify that only the three inserted current-user/other-user labels differ, with identical quotations and padding. This refinement changed no cases, source facts, labels or cache budgets.

A fixed reservoir of two different neutral user/assistant exchanges is relocated before versus after the immutable history. It contributes **219 tokens** in either location. Ordering is AB for the first family and BA for the second; all conditions within a family use the same reservoir order. This limited counterbalance is a feasibility device, not a substitute for robust multi-family counterbalancing in a study.

## Exact matching results

| Fixed family | Inputs | Total input tokens in every condition | Query position | Last semantic echo age after complete query suffix |
|---|---:|---:|---|---|
| Volleyball record | 8 | 7,669 | Identical across all eight | 3,612 / 3,831 tokens |
| Charity 5K best | 8 | 8,378 | Identical across all eight | 50 / 269 tokens |

Verified properties:

- Identical total token count, query position and online-call count within each family
- Identical original-source token positions across copy conditions within each placement
- Identical competitor/current alias counts between relevant and irrelevant same-string copies
- Original old literal occurs once and rises to four occurrences under either high same-string branch
- Current literal count remains fixed: one `5-2`; five `25:50`
- Source text, author answers, speaker roles, original event order and source-report timestamps are preserved
- No answer annotations or evidence labels appear in the canonical prompts
- Each online input chunk is an exact slice of the single canonical token stream, with maximum 128 tokens; there are 82 calls for volleyball and 85 for 5K in every corresponding condition

Moving the reservoir intentionally changes evidence position and relative age while holding total context and query position fixed. It does not make absolute and relative position mathematically separable; ordinary-retrieval controls are still required for a later revision-specific claim.

## Semantic echo accounting and boundary limits

Age is measured from independently reviewed answer-bearing semantic spans, not merely the first annotated update or last exact digit string.

- **Volleyball:** one explicit current-record span occurs in the first new-session user turn. Later “Net Ninja” names and success acknowledgments identify or praise the team without specifying its record; they are separately inventoried as associated cues. Both placements remain far outside a 128-token protected suffix. **No inside/outside-tail claim is made for this family**
- **5K:** eight explicit, threshold or clearly coreferential spans were identified. The last is the final assistant's reference to beating the already established personal-best time, after the last literal `25:50`. At the completed-query boundary, placement changes its age from 50 to 269 tokens, crossing the named protected-tail control's boundary

The builder records whole-span suffix coverage at every scheduled online chunk end, at history/query completion, and at symbolic decoding offsets 1/16/32. These are structural reference-control checks, not an actual model's eviction log. The corpus can still contain distributed latent information beyond human-annotated spans. Associated cues and clear coreferences are disclosed rather than silently treated as absent.

**The 128-token suffix belongs only to the declared protected-recency control.** TRIM's `buffer_size` is trigger slack, while its separate `sliding_window_size` defaults to zero. These results do not establish that TRIM retains any selected span. Its actual capacity/peak accounting and the MInference persistent-pruning limitations are in `baseline_semantics_addendum.json` and the separate baseline certification work.

## Scoring remains semantic

A future current-state answer may be correct if it gives only the current value or clearly distinguishes the historical and current values. An old-only current answer is wrong; unqualified competing alternatives require adjudication. The complete score/units must be correct, and unsupported explanatory claims may matter. A historical value's mere appearance is not stale contamination.

The proposed primary contrast is the policy's excess stale-current error over its own same-input Full control, contrasting high/low added copies and subtracting the corresponding irrelevant-same-string contrast, then comparing online with one-shot ingestion. Keep underlying current accuracy, stale-only/mixed/other errors, abstention, termination and paired transitions visible. Full-correct conditioning is secondary; no family is selected by model correctness.

No outcomes or statistical estimates exist here. Two source families cannot establish power. The practical margin, uncertainty analysis, ordinary-retrieval controls, decoding/adjudication and primary policy still require a genuine pre-inference study decision.

## Mechanical verification and preserved failure

`build_variants.py` imports only the existing tokenizer/Jinja environment. It checks canonical prefix identity and exact tokenizer counts. `verify_packet.py` independently checks saved metadata and parses the rendered chat to compare every source message with the immutable corpus. It also verifies the fixed selection, V1 hashes, equal call counts and absence of label leakage.

The initial padding implementation incorrectly treated successive neutral words as if their token increments could not overshoot an exact target. Both families stopped before rendering. The failure is preserved in `*_attempt01.*`. One bounded mechanical correction chose a fitting word from the **same frozen neutral vocabulary**; no family, source text, semantic label, neutral vocabulary, target token length, factor or scientific threshold changed. The single permitted retry produced all 16 inputs. This was a token-padding implementation error, not a model failure or an alternate-cohort search.

After preserving the original rendering, a separately authorized bounded owner-label check tested three prospectively declared pairs in the existing `Quote owner=` wrapper: current user/other user, primary user/separate user, and this user/another user. Each differed by one token for both selected quotations. None supported identical padding in that wrapper, so no rendered prompts changed. `refinement_01/` retains the plan, exact input hashes and token counts. The three-pair limit was honored; this was not proof that no alternative wording could work.

The parent then explicitly authorized one targeted delimiter diagnosis using the exact first pair with `Archive owner: ` and a standard following space. The tokenizer showed the mechanism: `=current` fused into one token, while `=other` split; colon-space yielded equal-length owner labels and equal complete wrappers (79/79 and 80/80 tokens). Independent pre-render semantic review confirmed the unchanged queried-user versus unrelated-person/group intent, with current describing the person label rather than the archived fact. Only the same 16 conditions were rerendered under `refinement_02_delimiter/`. They passed all matching checks and a stronger whole-prompt owner-only substitution test. An independent changed-wrapper review confirmed the normalized semantics and all four paired whole-prompt comparisons; the differential-padding caveat is resolved. The shared template adds 10 tokens uniformly relative to legacy; cache and reference-tail budgets are unchanged.

Independent rendered-text review passed all 16 prompts, including owner/date interpretation, unchanged source messages, actual insertion placement and source/rendered semantic echo coordinates. The legacy review recorded the since-resolved padding nuisance; remaining caveats include the coreferential nature of the 5K inside-tail span, and late non-value entity cues in volleyball.

The initial successful construction peak RSS was **209,076 KiB**; delimiter-normalized construction reported **209,108 KiB**. No Torch or Transformers import, model forward, weight acquisition, installation, GPU use, API judge, new network download or payment occurred. The packet is below the 20 MB cap and reuses the full corpus by hash rather than duplicating it.

## Final stopping state

**V2_INPUT_CONSTRUCTION_PASS / MAIN_STUDY_NOT_APPROVED / MODEL_AND_GPU_NO_GO.**

The input feasibility question is answered at this limited scope. No additional cohort or construction loop is started. Remaining barriers are a faithful same-weight policy/runtime path, separately authorized segmented/no-op Full parity, ordinary-retrieval controls, and a prospectively justified multi-family study with uncertainty and operational effect thresholds. This packet does not authorize those steps or claim a SCI-level result.

## File map

- `protocol_preselection_frozen.json`: prospective rule, family hash and scope limits
- `initial_eligibility_55.json`, `independent_eligibility_review.json`, `eligibility_55_final.json`: complete dual-review ledger, original labels and disagreement corrections
- `selected_families_frozen.json`, `eligible_family_order_frozen.json`: immutable fixed selection
- `selected_span_review.json`, `selected_semantics_reviewed.json`: full-conversation semantic audit, exact quote/echo coordinates and aliases
- `refinement_02_delimiter/constructed_variants.json`: active 16 canonical prompts, token IDs, source ranges and chunk/echo audits; root-level file preserves legacy inputs
- `construction_audit.json`, `verification.json`: tokenizer and independent structural checks
- `rendered_semantic_review.json`: independent review of actual rendered control text
- `mechanical_padding_fix.json`, `*_attempt01.*`: retained first implementation failure and bounded correction
- `v1_immutability_reference.json`, `artifact_manifest.json`: source/version integrity
