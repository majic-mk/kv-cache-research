# Final v2 input-feasibility packet

Active final inputs are under `refinement_02_delimiter/`, identified by `LATEST_INPUTS.json`. Original renderings and failed probes remain preserved.

This directory contains constructed, zero-weight input controls. It is not a model experiment, a full LongMemEval-S benchmark reproduction, or a paper-ready claim. V1 remains unchanged; its blocked absolute-age design and original four audit anchors are retained separately.

## Frozen sources and model identity

- Reuse `../revision_causal_input_packet_20261004/sources/longmemeval_oracle.json`, SHA-256 `821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c`
- Single proposed backbone: `Qwen/Qwen3-4B-Instruct-2507`, revision `cdbee75f17c01a7cc42f958dc650907174af0554`
- Existing tokenizer hash: `aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4`; no tokenizer or model downloads
- Official chat template/configuration are reused from V1 by hash

## Scope of the contrast

Both relevance arms preserve the original supersession. The added dated quotation's owner changes between the queried user and an explicitly unrelated peer/group. In the legacy root-level renderings target-free padding also differed. The final colon-space owner normalization removes that nuisance: relevant/irrelevant prompts now differ only in the three inserted owner labels, with identical padding. This is relevant obsolete repetition versus irrelevant same-string repetition, not a revised-versus-no-conflict world. Neutral-copy controls separate lexical-frequency/filler effects.

A fixed reservoir of neutral recorded exchanges is relocated before versus after the immutable source. Total input length and final query position must match exactly. Source evidence positions intentionally move across placement conditions and must match across copy conditions within each placement. This is a controlled placement/age intervention; it does not separate every absolute-position effect.

Age uses independently reviewed semantic echoes, including clear coreference; raw lexical counts are separate. The 128-token suffix is a named protected-recency control only. TRIM's buffer_size is eviction-trigger slack, and its separate sliding_window_size defaults to zero. No span-retention statement here certifies TRIM behavior.

## Selection and reviewer disagreement

One prospective rule was applied to all 55 V1 latest-functional-state rows. Two input-only reviews produced 27 joint admissions, 16 joint rejections and 12 non-admitted disagreements. These counts are not a claim that all 28 non-admitted records are truly unusable. In particular, unmarked direct evidence corrected two initial rejection rationales; those corrections are preserved.

Shared source families were grouped before ascending version-salted family-hash selection. The fixed two are `c7dc5443` (volleyball record) and `6a1eabeb` (charity 5K personal best). A construction failure cannot trigger replacement with another rank. V1's fixed four are neither replaced nor counted as an independent second dataset.

## Structural execution contract

Canonical IDs are tokenized once. Online chunks subdivide recorded messages into at most 128 tokens while preserving absolute sequence positions; one-shot ingestion receives the whole history before the same final question suffix. These are input schedules, not an implemented model cache. Per-policy eviction triggers, state reset, protected regions and transient memory are handled by the separate baseline certification.

The input builder imports only the existing tokenizer/Jinja environment, never Torch, Transformers or a model class. It checks source preservation, same-string counts, exact token length, query position, source-position matching, chunk-prefix identity and symbolic tail coverage. A model must not be loaded merely because those checks pass.

## Scoring and remaining study requirements

Current-only and clearly temporally qualified historical-plus-current answers can both be correct. Old-only is wrong for a current query; unresolved mixed answers require semantic adjudication. Bare identifier presence is not a stale-answer score. Preserve the complete author answer, units, official compatibility score, other errors, abstention and termination.

A later study still requires a faithful same-weight policy path, segmented/no-op Full parity, a predeclared practical margin and uncertainty method, ordinary-retrieval controls, and enough independent source families. Two feasibility items do not provide statistical power. The closest-prior boundaries in `../revision_causal_design_review_20261004.md` remain binding: causal cache updates, superseded-value interference and stale-aware management already have close prior work.

This is the final bounded input preparation. No new cohort search, model ladder, weight download, inference, GPU work or paid evaluation is authorized by it.
