# Independent review: revision-sensitive online KV eviction

Date: 2026-10-04 UTC. Scope: a finite methodological and prior-art review, not an experiment or implementation release.

## Decision

**Conditional GO for one prospectively frozen v2 input-and-baseline feasibility packet. NO-GO for promoting this to the main causal study, loading a model, downloading weights, training, or GPU work now.**

There is a potentially substantive empirical question: whether **budget-driven irreversible eviction during history formation adds a revision-specific stale-answer penalty**, after controlling for ordinary interference, lexical frequency, retrieval position, and the same model's full-cache errors. This could produce an actionable boundary on when one-shot compression results transfer to persistent serving. It need not introduce a new algorithm to matter.

However, the novelty margin is smaller than the first audit established. The current packet does not supply a runnable faithful comparison or an admitted factorial cohort. Its one camera example and category counts are insufficient for a paper claim. Treat the next packet as a final feasibility gate, not another invitation to extend preparation indefinitely. If the requirements below cannot be met with small, faithful adaptations of existing code, close this direction.

## 1. New closest prior changes the claim

The existing audit correctly closes broad update-category novelty through TRIM-KV and Round Attention, and online recency/query-drift novelty through AgentKV. This review found additional, more directly relevant primary sources:

- **[Zhou et al., September 27, 2026](https://arxiv.org/html/2609.33759v1), §§2–6, A.4, A.8–A.9, D.6:** already studies changed facts using cache interventions, role-/length-matched controls, current and historical questions, downstream-state dependence, and an online policy that masks old records after replacements arrive. It also compares query-aware cache methods on LongMemEval-Oracle. Thus neither causal cache-update analysis, a finer answer taxonomy, nor contrasting online history formation with post-prefill intervention is independently new. In the inspected protocols, I did not identify the proposed **obsolete-copy frequency × post-echo age × fixed-capacity irreversible eviction** interaction. Its online mask is an update-directed access intervention, not evidence of the same budget-driven physical eviction protocol. This is a scoped distinction, not an exhaustive absence claim.
- **[PI-LLM, Wang and Sun, 2025](https://arxiv.org/html/2506.08184v1), §§3–4:** already varies superseded associations and includes fixed-length controls; stale-value retrieval despite a recent target is its central phenomenon. Therefore “old evidence interferes with new evidence beyond Lost in the Middle” is also prior work. Repeating one old value and varying many overwritten values are different manipulations, but that difference alone would be a weak contribution.
- **[SleepGate, Xie, 2026](https://arxiv.org/html/2603.14517v1), §§3, 6–7:** explicitly proposes stale-aware cache management and reports stale-retrieval rates against Full, sliding-window, H2O, and StreamingLLM. Its reported experiment uses a 793K-parameter synthetic-token transformer trained for the task, with soft attention biasing for SleepGate. It does not establish the desired result for one unchanged pretrained backbone under physically irreversible eviction. This is relevant conceptual prior, not an implementation whose reported numbers can be imported into the proposed comparison.
- **[KVEraser, Li et al., 2026](https://arxiv.org/html/2606.17034v1), §§1–2:** treats stale or retracted context and its influence in later states through learned cache editing. It reinforces that surviving token rows do not localize where information is stored. Its supplied-span editing task differs from online capacity-driven selection.

The meaningful residual is therefore a **compression-specific, serving-regime-dependent interaction**, potentially with a policy ranking reversal or a practically relevant stale-error boundary. Merely adding another current/old accuracy table, another recency curve, or showing that an old answer is mentioned is not enough.

Search bound honored: three targeted search queries total, followed by primary-source section reads and two citation-followed primary papers. No new dataset, model, or package was acquired. An OpenReview PDF returned a browser verification page; it was not used as evidence or bypassed. Search results themselves were discovery only.

## 2. What the existing packet establishes

I independently re-read the oracle bytes and taxonomy JSON using only Python's standard library. The source remains 15,388,478 bytes, SHA-256 `821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c`: 500 total records, 78 knowledge-update records, and a complete 78-row taxonomy with 55 latest-state, 9 prior-state, 6 comparison, 6 abstention, and 2 ambiguous queries. These are input annotations, not experimental results or 55 admitted update probes.

The original fixed four must remain permanently attached to the input audit. Their two prior-state questions and one abstention are valid tasks, not bad examples to replace. The camera question is a valid latest-purchase-slot query; historical purchases can remain true. It is not an established literal retraction.

The saved camera audit reports five old-identifier mentions and eight new-identifier mentions, with the last new identifier 110 tokens from the history boundary. The 128-token suffix observation invalidates a claim based only on age of the first annotated update. I did not rerun the tokenizer or model. The saved exact-token audit supports the lexical-span statement; semantic echoes and query-time retention still require separate checks.

The frozen v1 absolute-age design stays blocked. A v2 construction would be a new declared design, not a repair that silently overwrites the old failure. The oracle contains selected evidence sessions, so constructed probes cannot be called natural full-LongMemEval-S benchmark parity.

## 3. Two required changes to the proposed counterfactual

### 3.1 Source preservation does not make the control history noncontradictory

Keeping the complete original old/new history and changing only the **added copies** to another person's old value leaves the original supersession in both arms. That is a valid **target-relevant repetition versus irrelevant same-string repetition** contrast. It is not a paired world with no supersession at all.

Choose and freeze one interpretation:

1. **Recommended minimum:** preserve the natural source in both arms; manipulate whether the added dated copies concern the queried person/slot or an explicitly separate person/slot. Claim an extra effect of *relevant obsolete repetition*, conditional on the original update. Add neutral-copy controls for the lexical-frequency component.
2. **Broader alternative:** explicitly transform the complete source into paired revised/non-revised worlds, tracing every edit. This can support a true relationship factor but gives up the claim that both complete histories are unchanged natural sources. Do not pretend to achieve both guarantees simultaneously.

Do not use simple confirm-old versus replace-old worlds as the sole frequency control: changing the later target changes the frequency of the correct answer itself. Role-swapped and irrelevant-same-string controls should preserve competitor/current alias counts and balance which surface value serves each role wherever construction permits. Quoted historical statements must have unambiguous speaker and event-time scope.

For the camera construction, three copies of the identified old turn add six occurrences: **5→11 lexical mentions**, not “1→4 mentions.” Track original evidence exposures, inserted copies, and literal/alias counts separately. Dates must make copies repetitions of the old event, rather than new purchases or reinstatements.

### 3.2 Appending filler changes more than age

Offsets 0/128/512 after the complete history are feasible as a **delay/length stress test**, but also change total length, query position, and the number of online processing steps. Paired full-cache/nonconflicting controls help interpret this composite intervention; they do not make those factors identical.

For an age-focused claim, use a fixed neutral-token reservoir and move its allocation from before to after the immutable source while preserving total canonical length and the query's absolute position. Evidence positions intentionally change across ages; they must match across repetition/scope/policy conditions *within* an age. Keep the same ordering of source events. Counterbalance neutral material and insertion boundaries rather than depend on one conspicuous repeated filler phrase. Reject instances where exact matching or clear temporal interpretation fails.

Even fixed total length does not make absolute and relative position separable. Report the intervention as controlled placement/age, and use the corresponding ordinary-retrieval controls to test the revision-specific component.

Age must be measured after the **last independently annotated answer-bearing semantic echo**, including aliases and clear coreference, not simply the first tagged turn or last exact string. Measure suffix coverage at every actual eviction point, including query and decoding ingestion; 110 tokens at the history boundary is not automatically 110 at the first answer step. If no semantically unambiguous “inside protected tail” cell can be formed, retain it as an outside-tail design and withdraw the boundary-crossing claim rather than edit away echoes.

## 4. Estimand and scoring to freeze before inference

For source family i, let Y be an indicator that a generated answer **incorrectly presents the designated obsolete/competitor value as the current answer**. For the irrelevant-copy control the same competitor remains a wrong current answer, so the event has a common definition.

At each age and ingestion regime:

1. Compute each policy's paired excess Y over its own full-cache control on exactly the same input
2. Contrast high versus low added-copy count
3. Subtract that contrast for irrelevant same-string copies from the contrast for relevant old copies
4. Compare this interaction between online and one-shot operation

The neutral-copy branch separately measures length/filler and lexical-frequency effects. A later study may predeclare an inside/outside-tail interaction, but it should not multiply exploratory endpoints and choose the best afterward. Preserve each underlying rate and paired transition matrix so a higher-order contrast cannot hide broad failure.

Current-only and clearly qualified historical-plus-current answers are both correct. An old-only answer is wrong for a current query, but can be correct for a prior-state query. Listing two unresolved alternatives is a distinct mixed/ambiguous outcome requiring a frozen adjudication rule; do not infer its status from substring presence. Unsupported explanatory claims can make an otherwise current answer wrong. Score all requested fields, such as lens type or units, rather than only a distinctive token.

Keep current correctness, stale-only errors, mixed errors, other errors, abstention, and termination separately. Preserve the official LongMemEval rubric as a compatibility result. Do not force legitimate concise explanations into an artificially restrictive format just to simplify scoring. Candidate log-probability margins and token retention are diagnostics, not substitutes for complete semantic answers.

All selected families remain in the primary denominator. Full-wrong/compressed-right outcomes stay visible. Full-correct conditional results are secondary, never an eligibility or replacement rule. Cluster by independent source family/shared evidence, not by each rendering, query paraphrase, seed, or policy output. Freeze decoding, adjudication, one primary policy/contrast, the practically meaningful margin, and the uncertainty analysis before the first forward. Fifty-five candidate questions do not establish statistical power.

## 5. Prospective selection from the 55, without rescuing the old four

A new latest-state cohort is methodologically legitimate **because its target question is different and no model outcomes exist**. It requires a new versioned protocol and does not retroactively change v1 selection.

- Apply one input-only admissibility rule to all 55. Require a uniquely queried single functional slot, verifiable old and new values, consistent speaker/entity scope, supported event order no later than the query, and a complete latest answer. Require a reviewed inventory of later echoes and feasible matched insertions
- Keep literal retractions, state transitions, habits, and cumulative snapshots distinct. Admit an ordinary changing slot without demanding that its old historical statement become false. Exclude arithmetic-dependent, mismatched-window, merely planned, approximate-but-scored-exact, missing-old-value, and unresolved temporal cases from the primary two-value probe under explicit rules
- Have a second input-only reviewer adjudicate ambiguities without model outputs. Keep the original author label and the review label separately; disagreements stay in the ledger
- Group shared evidence before selection. Prefer using all eligible independent families for the planned study. If cost requires a cap, freeze N, strata, and an ascending hash rule before final cohort construction; use a new version salt. Never sample until a preferred model works
- Once that cohort is frozen, construction failures remain reported. Do not replace them with later hash ranks. A materially changed construction rule requires a new prospective decision, not hidden per-item repair
- Keep all original four as audit anchors regardless of their appearance in v2. Do not count them as an independent second dataset

This review does not admit any of the 55 or select a new cohort. It specifies the conditions under which a new selection could be defensible.

## 6. Minimum faithful plain-attention execution plan

Fix `Qwen/Qwen3-4B-Instruct-2507` at revision `cdbee75f17c01a7cc42f958dc650907174af0554`; the recovered Qwen3.5-2B hybrid is not a proxy. Keep the tokenizer/template, precision, base tensors, canonical inputs, numerical backend, and decode rule fixed. No model-size ladder or fresh training is needed or justified for this feasibility gate.

### Source/code gate, before model acquisition

1. **One shared state contract:** canonical IDs tokenized once; original absolute positions and monotonic seen count; per-layer surviving K/V; policy scores/query windows; random state; eviction timing; all per-example resets. No recovered evicted tokens, undeclared external summary, or regenerated intermediate responses. Teacher-force the recorded history
2. **Small non-model fixtures:** verify gather/order, capacity accounting, protected windows, repeated chunks, duplicate values, state reset, and deterministic RNG on toy arrays. Specify per-token or fixed maximum chunk length. If eviction occurs only after a chunk, report the transient B+chunk bound and do not call it a strict B-token peak
3. **Full-path contract:** later, under separate inference authorization, demonstrate segmented versus monolithic Full parity at prospectively chosen tolerances. Also check no-op eviction equals Full. Source inspection alone cannot certify this
4. **Controls:** Full; last-N; prefix-plus-recency; random outside the identical protected region; a verified cumulative-heavy-hitter policy; and a faithful strong selector such as the supported learned TRIM path. A recent-query policy is useful but must be named accurately
5. **TRIM certification:** pin its trained artifact/parameter manifest and base model, verify whether any backbone tensors differ, and pair it with a no-compression Full using those exact tensors. If base weights differ, it is a distinct model-policy system and cannot be pooled into a pure same-weight policy contrast. Pin gate parameters, window/buffer settings, and attention dispatch. The saved source really does call compression after the whole supplied chunk
6. **SnapKV/R-KV caution:** reconcile the documented DynamicCache issue and Qwen3 q_norm/k_norm patch if using the paper's baseline route. The packaged latest-query selector is not cumulative H2O. A newly adapted selector can be useful but must be labeled and verified as an adaptation rather than called paper reproduction
7. **Information/resource fairness:** query-agnostic history selection is a clean primary regime. A method whose native procedure requires the final query belongs in a separately labeled query-aware comparison; do not remove its required information and still claim fidelity. Report resident and peak KV, scores/query buffers, host storage, transfers, and prefill work. One-shot full-history prefill has an intrinsically different memory budget during ingestion

The existing [TRIM author warning](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/README.md) and saved `baseline_routes.json` remain valid blockers. The pinned repository also advertises a newer dynamic-budget variant; choosing a strong learned comparator needs a declared rationale, not silently treating an older static variant as the strongest available system.

Round Attention can be a valuable recoverable-cache boundary, but adapting it to this backbone is not a mandatory new engineering project for the initial irreversible-eviction question. If included, its backing cache must be charged. Pure quantization is outside this narrow first study; adding it now would dilute identifiability.

## 7. Meaningful outcomes and stopping conditions

**Potential positive contribution:** a reproducible, material extra stale-answer penalty under online eviction that survives same-string scope controls and full-cache subtraction, changes across policies or protected-window boundaries, and is tied to an auditable resource/retention history. This could tell practitioners when offline compression evaluation is misleading. Mechanism claims about cumulative scores or old-token retention require direct logs or interventions later; mere co-occurrence is not proof.

**Useful falsifications:**

- The same effect exists in Full and compressed arms, leaving no extra compression interaction: ordinary interference explains it
- The effect also appears with irrelevant same-string copies: lexical frequency or source confusion is sufficient
- Ordinary retrieval controls show the same change across placement/age: no revision-specific penalty is established
- The online/one-shot difference disappears after consistent chunking, position handling, and reset: implementation behavior explained it
- Only a weak or broken policy fails; faithful stronger methods do not show a material penalty: report that limited boundary, not a universal defect
- A precise interval excludes the predeclared practical effect: evidence against that operational claim. An imprecise null is inconclusive, not proof of safety

**Stop before inference** if matched semantic inputs cannot be constructed; too few independent families remain for the intended claim; relevant evidence never leaves protected storage; baseline fidelity requires training or open-ended backend development; or the contribution is only a known interference curve with another benchmark label. Do not add easier examples, increase model size, or relax a failed old threshold.

## Final disposition

**V2_FEASIBILITY_CONDITIONAL_GO / MAIN_STUDY_NOT_APPROVED / MODEL_AND_GPU_NO_GO.**

One final bounded v2 packet could be worth preparing, because a policy- and ingestion-specific causal boundary is more substantive than taxonomy cleanup. It must first lock the estimand, distinguish repetition-scope controls from no-conflict worlds, fix the age/length confound, complete unbiased input eligibility, and establish a small faithful baseline route. If those deliverables do not close, archive this line rather than prolong it.

No model forward, weight download, package installation, GPU use, paid judge, or experiment occurred in this review. No publication outcome or SCI quartile is promised.
