# Independent Full6 terminal review — 2026-10-04

**Verdict: accept `STOP_COMPETENCE`.** All six fixed questions completed with EOS; independently recomputed EM and F1 are both **1/6**, below the unchanged requirement of three EOS-completed exact matches. No actionable input-format, answer-grading, saved-logit, causal-position, source-integrity, or resource-accounting defect was found. This completed baseline screen does not authorize cache arms, another model, or an automatic retry.

| Fixed question | Generated answer | Frozen primary answer | EM / F1 |
|---|---|---|---|
| q01, 2-hop | Rabbi Menachem Mendel Schneersohn | Dovber Schneuri | 0 / 0 |
| q02, 3-hop | Special Operations | Sea, Air, and Land | 0 / 0 |
| q03, 4-hop | May 4 | May 4 | 1 / 1 |
| q04, 2-hop | Frank Lampard | Mido | 0 / 0 |
| q05, 3-hop | North Carolina | Tucson Raceway Park | 0 / 0 |
| q06, 4-hop | Johnny Dare | Walter Sabo | 0 / 0 |

The two additional q05 aliases, “Tucson” and “Tucson, Arizona,” also score zero. All five misses are substantive answer differences. The official author normalization and terminal-subquestion alias rule were independently reconstructed; primary-answer, alias, punctuation, article, casing, and token-overlap handling do not explain the misses. Labels remain author-rule-derived rather than byte-verified against the unavailable official release ZIP.

## Independent checks

- Rehashed all **41 complete FP32 vocabulary vectors, 40,724,480 bytes**, checked finite values, and recomputed every saved argmax. These reproduce all **29 Full generated-token choices**, including six EOS choices, and all control choices. All **168 call histories**, frozen prefill ranges, actual parent-descriptor hash chains, and greedy dependent inputs match the fixed schedule. All six results are reported in the original order; wrong answers did not trigger selection or early abandonment.
- Reconstructed all six prompts from the composed question and all **20 original title/paragraph documents**, in original order. Independent ByteLevel decoding of saved IDs matches the official non-thinking chat wrapper and each generated answer. The prompts contain the intended field and complete document context. The existing offline receipt supplies encode verification; this audit did not rerun the tokenizer.
- Reconstructed the causal FP32 mask bytes from each absolute query/key position and matched **1,008 saved full-attention mask hashes**, with the expected 18 recurrent-None layers per call. No misplaced prompt tail, position reset, skipped document, or wrong answer field was found.
- Independently recomputed all **12 Full/Segmented vocabulary comparisons**: identical argmax; maximum absolute logit difference **2.8133392333984375e-5**; maximum float64 softmax total variation **2.2158668510333697e-6**, comfortably within the frozen limits. Maximum difference from the saved native FP32 TV is **2.721903982429314e-8**. All **576 live cache comparison receipts** pass, and the 12 cache descriptor pairs match their producer hashes and metadata. Raw cache values were not serialized, so this is not a post-hoc numerical cache recomputation.
- Rehashed **76 source pins and four small model/tokenizer asset pins**; release, launch, and guard before/after identities agree. The checkpoint payload was not reread in this audit; its unchanged identity is supported by the saved before/after guard receipts. Result, log, and sample-journal hashes match their receipts.

## Costs and terminal state

The complete schedule used **136 prefill calls / 24,099 tokens, 23 Full decode calls, and nine parity decode calls**, totaling **168 returned calls / 24,131 tokens**. All 168 last-row vocabulary projections were counted, including 127 intermediate chunk vectors hashed and discarded. The head alone used **85,437,972,480 multiply-accumulates**; this is not total model FLOPs or physical memory traffic.

The external process guard passed with **1,033.463478 seconds wall time**, **1,025.352629 seconds child CPU**, and **6,828,785,664 bytes combined child-plus-guard RSS high-water**. All **1,024 samples** satisfy the fixed resource bounds, with no missing metrics, descendants, source drift, or resource stop. The host-unavailable peak was **4,472,414,208 bytes**. The engine restored cleanly, released the arena, retained zero live cache owners, and balanced **34,440 acquisition/release pairs**. Nested operation timings must not be added to outer wall/CPU totals; this receipt describes this one Full6 attempt, not prior research costs.

The evidence supports **insufficient demonstrated baseline competence on these six fixed natural MuSiQue questions under this exact non-thinking, short-answer, full-document prompt and CPU schedule**. It does not establish universal model incapability, performance under alternative prompts/thinking modes, or cache-repair harm. Segmentation controls passing supports numerical consistency of the evaluated baseline. Preserve the negative result; the earlier first24 remains closed and no conditional cache branch resumes.

## Evidence identity and audit artifacts

- Release SHA-256: `b0cc669592bd09a3713a0a31e8580a54526033e45a936eba780e66db4d4b1f10`
- Active source digest: `70746ce17d8fbcce534672cf0dcf5ef4d2e61d8d24e42d70477da9a9f405167a`
- Result SHA-256: `036d40b343595d7535b81831388e2c1f95b311c29717397c266aae2d430c1fad`
- Evidence journal SHA-256: `e455d2f4efb38aa8b68d92e9198ace862ccf36359e9a26776c676844a466e7b6`
- Guard SHA-256: `8185e0369296f7a0eaff63733944377dd467e5e50dc19f25e99e590c7a4aa718`
- Reproducible stdlib audit: [script](musique_full6_cpu_terminal_saved_audit_20261004.py), [numeric/provenance/resource receipt](musique_full6_cpu_terminal_saved_audit_20261004.json), [independent prompt/alias/mask receipt](full6_saved_prompt_review_20261004.json).

Review used saved artifacts and standard-library computation only. No model import, load, forward, protocol change, or frozen-run edit occurred.
