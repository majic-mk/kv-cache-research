"""Regression assertions about pinned source text, never import upstream code."""
import hashlib,json,unittest
from pathlib import Path
P=Path(__file__).resolve().parent; S=P/'sources'
class SourceAssertions(unittest.TestCase):
    def test_receipted_bytes(self):
        for fn in ['source_receipts.json','reused_source_receipts.json']:
            for r in json.loads((P/fn).read_text()):
                if 'sha256' in r:self.assertEqual(hashlib.sha256((S/r['file']).read_bytes()).hexdigest(),r['sha256'])
    def test_qwen_norms_present_in_trim_and_native(self):
        for f in ['trimkv_modeling_qwen3.py','transformers_4_57_1__src__transformers__models__qwen3__modeling_qwen3.py','trimkv_rkv_modeling.py']:
            s=(S/f).read_text();self.assertIn('self.q_norm(self.q_proj',s);self.assertIn('self.k_norm(self.k_proj',s)
    def test_minference_reference_still_unpatched(self):
        a=(S/'minference_current_forward.py').read_bytes();b=(S/'minference_author_referenced_forward.py').read_bytes()
        self.assertEqual(a,b);self.assertNotIn(b'q_norm',a);self.assertNotIn(b'k_norm',a)
    def test_gate_only_declared(self):
        for f in ['static_trim_config.json','dynamic_trim_config.json']:
            c=json.loads((S/f).read_text());self.assertEqual(c['trainable_params'],'self_attn.retention_gate')
            self.assertEqual(c['base_model'],'Qwen/Qwen3-4B-Instruct-2507')
        s=(S/'trimkv_modeling_qwen3.py').read_text();self.assertIn('set(trainble_gate_state_keys) != set(gate_weights.keys())',s)
    def test_cpu_loader_not_claimed(self):
        s=(S/'trimkv_load_model.py').read_text();self.assertIn('device_map="cuda"',s)
        self.assertIn("assert config.attn_implementation in ['flash_attention_2']",s)
    def test_memory_bound_is_not_hardware_certificate(self):
        m=json.loads((P/'hardware_feasibility.json').read_text());self.assertEqual(m['kv_bytes_per_token_batch1_native8heads'],147456)
        self.assertGreater(next(s['weights_plus_kv_bytes'] for s in m['scenarios'] if s['tokens']==4096),8*2**30)
    def test_no_download_budget_excess(self):
        m=json.loads((P/'acquisition_summary.json').read_text());self.assertLess(m['charged_upper_bound_bytes'],m['cap_bytes']);self.assertEqual(m['weights_bytes'],0)
if __name__=='__main__':unittest.main(verbosity=2)
