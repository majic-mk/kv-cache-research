"""Own stdlib state contracts. Not upstream execution or pretrained inference.

Supplied scalar K/V and score increments are synthetic fixtures. They do not
implement an attention kernel, trained gate, R-KV, or an author reproduction.
"""
from dataclasses import dataclass, replace
import math
import random
from typing import Optional


@dataclass(frozen=True)
class Entry:
    position: int
    key: float
    value: float
    score: float = 0.0
    log_beta: float = -1.0


class CacheContract:
    """Session-persistent immutable-position rows indexed by (layer, KV head).

    append() consumes one common chunk, updates scores on available entries,
    then evicts. Chunk size C bounds *logical* pre-eviction row occupancy at
    B+C, or B+buffer-1+C with TRIM-style trigger slack. Allocation coexistence
    is charged separately; this is not a physical memory measurement.
    """
    POLICIES = {'full', 'last_n', 'sink_recent', 'random', 'cumulative_hh', 'trim_score'}

    def __init__(self, policy='full', budget: Optional[int] = None,
                 layers=2, heads=2, prefix=0, recent=0, buffer=1,
                 max_chunk=4, seed=7, query_aware=False):
        if policy not in self.POLICIES or layers < 1 or heads < 1 or max_chunk < 1:
            raise ValueError('invalid contract')
        if policy != 'full' and (budget is None or budget < 1):
            raise ValueError('bounded policy needs a positive budget')
        if min(prefix, recent) < 0 or buffer < 1:
            raise ValueError('invalid protected allocation or trigger buffer')
        if budget is not None and prefix + recent > budget:
            raise ValueError('protected tokens count inside budget')
        if policy == 'sink_recent' and prefix + recent != budget:
            raise ValueError('sink_recent needs prefix + recent == budget')
        self.policy, self.budget = policy, budget
        self.layers, self.heads = layers, heads
        self.prefix, self.recent, self.buffer = prefix, recent, buffer
        self.max_chunk, self.seed, self.query_aware = max_chunk, seed, query_aware
        self.reset()

    def reset(self):
        self.rows = {(l, h): [] for l in range(self.layers) for h in range(self.heads)}
        self.seen = 0
        self.canonical_ids = []
        self.rng = random.Random(self.seed)
        self.events = []
        self.evicted = {k: set() for k in self.rows}
        self.peak_pre_evict_entries = 0
        self.peak_gather_coexist_entries = 0

    def append(self, ids, payloads=None, score_increments=None, log_betas=None,
               information='history', evict=True):
        if not ids or len(ids) > self.max_chunk:
            raise ValueError('empty or oversized chunk')
        if information == 'final_query' and not self.query_aware:
            raise ValueError('query-agnostic selection cannot consume final query')
        if information not in ('history', 'final_query'):
            raise ValueError('unknown information regime')
        start, end = self.seen, self.seen + len(ids)
        # Validate all input before making any state mutation.
        new_rows = {}
        for lh, row in self.rows.items():
            p = payloads[lh] if payloads is not None else [(float(t), float(t)) for t in ids]
            b = log_betas[lh] if log_betas is not None else [-1.] * len(ids)
            if len(p) != len(ids) or len(b) != len(ids):
                raise ValueError('head payload length mismatch')
            if any(not math.isfinite(x) or x > 0 for x in b):
                raise ValueError('log retention must be finite and nonpositive')
            appended = row + [Entry(start+i, float(k), float(v), log_beta=float(b[i]))
                              for i, (k, v) in enumerate(p)]
            increments = (score_increments or {}).get(lh, {})
            valid = {e.position for e in appended}
            if not set(increments) <= valid:
                raise ValueError('score references future, evicted, or unavailable entry')
            if any(not math.isfinite(s) or s < 0 for s in increments.values()):
                raise ValueError('attention mass must be finite and nonnegative')
            new_rows[lh] = [replace(e, score=e.score+increments.get(e.position, 0.)) for e in appended]
        self.rows = new_rows
        self.seen = end  # advances once per canonical chunk, never once per layer
        self.canonical_ids.extend(ids)
        pre = sum(map(len, self.rows.values()))
        self.peak_pre_evict_entries = max(self.peak_pre_evict_entries, pre)
        if evict:
            self.compress(information=information)
        self.events.append(dict(start=start, end=end, information=information,
                                post_lengths={str(k):len(v) for k,v in self.rows.items()}))
        self.validate()

    def protected(self, row):
        return {e.position for e in row
                if e.position < self.prefix or e.position >= self.seen-self.recent}

    def compress(self, information='history'):
        if information == 'final_query' and not self.query_aware:
            raise ValueError('final-query leakage')
        if self.policy == 'full':
            return
        selections = {}
        for lh, row in self.rows.items():
            if self.policy == 'trim_score':
                trigger = len(row) >= self.budget+self.buffer
            else:
                trigger = len(row) > self.budget
            if not trigger:
                selections[lh] = [e.position for e in row]
                continue
            protected = self.protected(row)
            if self.policy == 'last_n':
                keep = [e.position for e in row[-self.budget:]]
            elif self.policy == 'sink_recent':
                keep = list(protected)
            else:
                eligible = [e for e in row if e.position not in protected]
                n = self.budget-len(protected)
                if self.policy == 'random':
                    chosen = self.rng.sample(eligible, n)
                elif self.policy == 'cumulative_hh':
                    chosen = sorted(eligible, key=lambda e:(-e.score, e.position))[:n]
                else:
                    # Source equation q_idx=seen+1; deterministic ties here are
                    # a reference convention, not a guarantee from torch.topk.
                    chosen = sorted(eligible,
                                    key=lambda e:(-e.log_beta*(self.seen+1-e.position), e.position))[:n]
                keep = list(protected) + [e.position for e in chosen]
            selections[lh] = sorted(keep)
        self.gather(selections)

    def gather(self, selections):
        if set(selections) != set(self.rows):
            raise ValueError('every layer/head needs its own map')
        new_rows = {}
        for lh, positions in selections.items():
            row = self.rows[lh]
            by_pos = {e.position:e for e in row}
            if positions != sorted(set(positions)) or not set(positions) <= set(by_pos):
                raise ValueError('invalid, duplicate, nonchronological or resurrected entry')
            new_rows[lh] = [by_pos[p] for p in positions]
        before = sum(map(len, self.rows.values()))
        after = sum(map(len, new_rows.values()))
        self.peak_gather_coexist_entries = max(self.peak_gather_coexist_entries, before+after)
        for lh, row in self.rows.items():
            self.evicted[lh].update({e.position for e in row}-{e.position for e in new_rows[lh]})
        self.rows = new_rows

    def validate(self):
        assert self.seen == len(self.canonical_ids)
        for lh, row in self.rows.items():
            positions = [e.position for e in row]
            assert positions == sorted(set(positions))
            assert all(0 <= p < self.seen for p in positions)
            assert not set(positions) & self.evicted[lh]

    def causal_mask(self, lh, query_positions):
        return [[e.position <= q for e in self.rows[lh]] for q in query_positions]

    def packed(self):
        """Compact rows; no padding silently interpreted as a valid token."""
        flat, offsets = [], [0]
        for lh in sorted(self.rows):
            flat.extend(self.rows[lh]); offsets.append(len(flat))
        return flat, offsets

    def padded(self):
        n = max(map(len, self.rows.values()), default=0)
        return {lh: (row+[None]*(n-len(row)), [True]*len(row)+[False]*(n-len(row)))
                for lh,row in self.rows.items()}


def rope_pair(x, position, theta=10000.):
    """One two-dimensional RoPE pair for an original-position identity fixture."""
    a = position / theta
    return (x[0]*math.cos(a)-x[1]*math.sin(a),
            x[1]*math.cos(a)+x[0]*math.sin(a))


def storage_bytes(tokens, layers=36, kv_heads=8, head_dim=128,
                  scalar_bytes=2, score_bytes=4, position_bytes=8):
    entries = tokens*layers*kv_heads
    return dict(kv=entries*2*head_dim*scalar_bytes,
                scores=entries*score_bytes, positions=entries*position_bytes,
                total=entries*(2*head_dim*scalar_bytes+score_bytes+position_bytes))


def require_complete_costs(ledger):
    required = {'prefill', 'replay', 'score', 'gather', 'pack', 'decode',
                'persistent_state_bytes', 'transient_peak_bytes',
                'host_backing_bytes', 'transfer_bytes'}
    if not required <= ledger.keys():
        raise ValueError('incomplete cost ledger')
    # None means unmeasured, not zero; negative measurements are invalid.
    if any(v is not None and v < 0 for v in ledger.values()):
        raise ValueError('invalid cost')
    return all(ledger[k] is not None for k in required)
