import unittest
from reference_contracts import CacheContract, rope_pair, storage_bytes, require_complete_costs

class Contracts(unittest.TestCase):
    def test_full_segmented_same_fixture_as_monolithic(self):
        a=CacheContract(max_chunk=20); b=CacheContract(max_chunk=20)
        a.append(list(range(12)))
        for ids in [list(range(3)),list(range(3,7)),list(range(7,12))]: b.append(ids)
        self.assertEqual(a.rows,b.rows); self.assertEqual(a.seen,12)

    def test_noop_compression_equals_full(self):
        a=CacheContract(); b=CacheContract('last_n',20)
        for c in [[1,2,3],[4,5]]: a.append(c);b.append(c)
        self.assertEqual(a.rows,b.rows)

    def test_full_never_silently_crops(self):
        a=CacheContract(budget=2)
        for _ in range(5): a.append([7,7,7])
        self.assertEqual(len(a.rows[0,0]),15)

    def test_absolute_seen_not_retained_length(self):
        a=CacheContract('last_n',3)
        for c in [[1,2,3],[4,5,6],[7,8]]:a.append(c)
        self.assertEqual(a.seen,8)
        self.assertEqual([e.position for e in a.rows[0,0]],[5,6,7])
        self.assertNotEqual(rope_pair((1.,2.),a.seen),rope_pair((1.,2.),3))

    def test_layer_count_does_not_multiply_seen(self):
        a=CacheContract(layers=36,heads=8);a.append([9,8,7])
        self.assertEqual(a.seen,3)

    def test_prefix_recent_inside_capacity(self):
        a=CacheContract('sink_recent',4,prefix=1,recent=3)
        for _ in range(3):a.append([7]*4)
        self.assertEqual([e.position for e in a.rows[0,0]],[0,9,10,11])
        with self.assertRaises(ValueError):CacheContract('random',4,prefix=3,recent=2)

    def test_chunk_peak_is_b_plus_c(self):
        a=CacheContract('last_n',4,max_chunk=3,layers=1,heads=1)
        for _ in range(4):a.append([1]*3)
        self.assertEqual(a.peak_pre_evict_entries,7)
        self.assertEqual(a.peak_gather_coexist_entries,11)

    def test_trim_buffer_is_slack_not_protection(self):
        a=CacheContract('trim_score',2,buffer=3,layers=1,heads=1)
        a.append([1]*4,log_betas={(0,0):[-.001,-.001,-10.,-10.]})
        self.assertEqual(len(a.rows[0,0]),4)
        a.append([1],log_betas={(0,0):[-10.]})
        self.assertEqual([e.position for e in a.rows[0,0]],[0,1])

    def test_explicit_trim_tail_is_protected(self):
        a=CacheContract('trim_score',2,recent=1,layers=1,heads=1)
        a.append([1,2,3],log_betas={(0,0):[-.001,-.001,-10.]})
        self.assertIn(2,[e.position for e in a.rows[0,0]])

    def test_head_specific_gather_preserves_association(self):
        a=CacheContract(layers=1,heads=2);a.append([5,5,5,5])
        a.gather({(0,0):[0,3],(0,1):[1,2,3]});a.validate()
        self.assertNotEqual(a.rows[0,0],a.rows[0,1])
        flat,offsets=a.packed();self.assertEqual(offsets,[0,2,5])
        self.assertEqual([e.position for e in flat],[0,3,1,2,3])
        self.assertEqual(a.padded()[0,0][1],[True,True,False])

    def test_duplicate_values_are_distinct_tokens(self):
        a=CacheContract('last_n',2,layers=1,heads=1);a.append([4,4,4])
        self.assertEqual([e.position for e in a.rows[0,0]],[1,2])

    def test_reject_resurrection_and_unordered_map(self):
        a=CacheContract('last_n',2,layers=1,heads=1);a.append([1,2,3])
        for ids in [[0,2],[2,1],[1,1]]:
            with self.assertRaises(ValueError):a.gather({(0,0):ids})

    def test_causal_mask_uses_original_positions(self):
        a=CacheContract(layers=1,heads=1);a.append([1,2,3,4]);a.gather({(0,0):[0,2,3]})
        self.assertEqual(a.causal_mask((0,0),[1,2,3]),[[True,False,False],[True,True,False],[True,True,True]])

    def test_cumulative_hh_is_not_latest_query(self):
        a=CacheContract('cumulative_hh',2,layers=1,heads=1)
        a.append([1,2],score_increments={(0,0):{0:10.,1:0.}})
        a.append([3],score_increments={(0,0):{0:0.,1:1.,2:2.}})
        self.assertEqual([e.position for e in a.rows[0,0]],[0,2])
        self.assertEqual(a.rows[0,0][0].score,10.)

    def test_evicted_score_cannot_be_recovered(self):
        a=CacheContract('last_n',1,layers=1,heads=1);a.append([1,2])
        with self.assertRaises(ValueError):a.append([3],score_increments={(0,0):{0:99.}})
        self.assertEqual(a.seen,2)

    def test_future_score_information_is_rejected(self):
        a=CacheContract(layers=1,heads=1)
        with self.assertRaises(ValueError):a.append([1],score_increments={(0,0):{1:99.}})
        with self.assertRaises(ValueError):a.append([1],information='final_query')
        self.assertEqual(a.seen,0)

    def test_query_aware_regime_is_explicit(self):
        a=CacheContract(query_aware=True);a.append([1],information='final_query')
        self.assertEqual(a.events[0]['information'],'final_query')

    def test_random_reset_and_seed(self):
        a=CacheContract('random',3,recent=1,seed=42)
        chunks=[[1,2,3,4],[5,6,7,8],[9,10]]
        for c in chunks:a.append(c)
        expected=dict(a.rows);a.reset()
        for c in chunks:a.append(c)
        self.assertEqual(a.rows,expected)
        self.assertEqual(a.seen,10)

    def test_reset_clears_noncache_state(self):
        a=CacheContract('cumulative_hh',2);a.append([1,2,3]);a.reset()
        self.assertEqual(a.seen,0);self.assertEqual(a.events,[])
        self.assertFalse(any(a.evicted.values()));self.assertFalse(any(a.rows.values()))

    def test_whole_history_prefill_peak_is_not_budget(self):
        a=CacheContract('last_n',3,max_chunk=20,layers=1,heads=1);a.append(list(range(20)))
        self.assertEqual(len(a.rows[0,0]),3);self.assertEqual(a.peak_pre_evict_entries,20)

    def test_source_of_new_payload_changes_after_eviction(self):
        # Synthetic causal scalar state, not a neural model: payload of token 2
        # depends on previous available values. Presence of token 2 alone does
        # not establish equal representations. Teacher payload costs Full work.
        teacher=1.+2.; online=2.
        full=CacheContract(layers=1,heads=1); online_cache=CacheContract('last_n',2,layers=1,heads=1)
        full.append([9],payloads={(0,0):[(teacher,teacher)]})
        online_cache.append([9],payloads={(0,0):[(online,online)]})
        self.assertEqual(full.rows[0,0][0].position,online_cache.rows[0,0][0].position)
        self.assertNotEqual(full.rows,online_cache.rows)

    def test_qwen_storage_and_ledger(self):
        self.assertEqual(storage_bytes(1)['kv'],147456)
        with self.assertRaises(ValueError):require_complete_costs({'prefill':0})
        keys=['prefill','replay','score','gather','pack','decode','persistent_state_bytes','transient_peak_bytes','host_backing_bytes','transfer_bytes']
        self.assertFalse(require_complete_costs(dict.fromkeys(keys,None)))

    def test_repeated_same_chunk_is_new_positions_not_replay(self):
        a=CacheContract();a.append([1,2]);a.append([1,2])
        self.assertEqual([e.position for e in a.rows[0,0]],[0,1,2,3])

    def test_oversized_chunk_fails_before_mutation(self):
        a=CacheContract(max_chunk=2)
        with self.assertRaises(ValueError):a.append([1,2,3])
        self.assertEqual(a.seen,0)

if __name__=='__main__':unittest.main(verbosity=2)
