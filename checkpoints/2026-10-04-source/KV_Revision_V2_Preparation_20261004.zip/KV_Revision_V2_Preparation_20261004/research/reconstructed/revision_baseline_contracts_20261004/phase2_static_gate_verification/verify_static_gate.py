"""Own safe tensor-only verifier; no upstream model imports/construction."""
from pathlib import Path
import collections,hashlib,json,math,resource,sys,time,zipfile
resource.setrlimit(resource.RLIMIT_CPU,(295,300))
P=Path(__file__).resolve().parent;PACKET=P.parent;ROOT=P.parents[3]
FILE=ROOT/'outputs/revision_static_trim_gate_20261004/trimkv_weights.pth'
start=time.perf_counter()
sha=hashlib.sha256()
with FILE.open('rb') as f:
 while b:=f.read(1024*1024):sha.update(b)
assert sha.hexdigest()=='a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a'
with zipfile.ZipFile(FILE) as z:
 entries=z.infolist()
 assert sum(i.file_size for i in entries)<110000000
 assert all(i.compress_type==zipfile.ZIP_STORED for i in entries),'unexpected compressed archive'
 assert all(not i.filename.startswith('/') and '..' not in Path(i.filename).parts for i in entries)
 archive=dict(entries=len(entries),uncompressed_bytes=sum(i.file_size for i in entries),compression='ZIP_STORED',arbitrary_extraction=False)
import torch
from torch.nn import functional as F
torch.set_num_threads(1);torch.set_num_interop_threads(1)
unsafe=torch.serialization.get_unsafe_globals_in_checkpoint(FILE) if hasattr(torch.serialization,'get_unsafe_globals_in_checkpoint') else None
if unsafe:raise RuntimeError(f'Unapproved globals: {unsafe}')
state=torch.load(FILE,map_location='cpu',weights_only=True,mmap=True)
assert type(state) in (dict,collections.OrderedDict),type(state)
manifest=json.loads((PACKET/'expected_static_gate_manifest.json').read_text())
expected={x['name']:tuple(x['shape']) for x in manifest['keys']}
assert set(state)==set(expected),{'missing':sorted(set(expected)-set(state)),'extra':sorted(set(state)-set(expected))}
records=[];storage_ids={};storage_groups={};storage_spans={};param_count=0
for name in sorted(state):
 t=state[name]
 assert type(t) is torch.Tensor,(name,type(t))
 assert tuple(t.shape)==expected[name],(name,tuple(t.shape),expected[name])
 assert t.dtype==torch.bfloat16,(name,t.dtype)
 assert t.layout==torch.strided and t.device.type=='cpu' and not t.is_quantized
 assert bool(torch.isfinite(t).all()),name
 raw=t.detach().contiguous().view(torch.uint8).numpy().tobytes()
 storage=t.untyped_storage();storage_ids[storage.data_ptr()]=storage.nbytes()
 group=storage_groups.setdefault(storage.data_ptr(),len(storage_groups))
 storage_spans.setdefault(group,[]).append((t.storage_offset()*t.element_size(),(t.storage_offset()+t.numel())*t.element_size()))
 param_count+=t.numel()
 records.append(dict(name=name,shape=list(t.shape),dtype=str(t.dtype),elements=t.numel(),bytes=t.numel()*t.element_size(),raw_tensor_sha256=hashlib.sha256(raw).hexdigest(),finite=True,contiguous=t.is_contiguous(),requires_grad=t.requires_grad,storage_group=group,storage_offset_bytes=t.storage_offset()*t.element_size()))
assert param_count==manifest['expected_parameter_count']
for spans in storage_spans.values():
 spans.sort()
 assert all(b<=c for (a,b),(c,d) in zip(spans,spans[1:])), 'overlapping gate storage'
assert sum(storage_ids.values())==sum(x['bytes'] for x in records), 'unaccounted backing storage'
base=json.loads((PACKET/'sources/qwen_config.json').read_text());gate=json.loads((PACKET/'sources/static_trim_config.json').read_text())
fields=['hidden_size','intermediate_size','num_hidden_layers','num_attention_heads','num_key_value_heads','head_dim','vocab_size','hidden_act','attention_bias','rope_theta','rope_scaling','rms_norm_eps','tie_word_embeddings','use_sliding_window','sliding_window','max_position_embeddings']
assert all(base[x]==gate[x] for x in fields)
assert gate['base_model']=='Qwen/Qwen3-4B-Instruct-2507'
assert gate['trainable_params']=='self_attn.retention_gate' and gate['retention_gate']=='rg'
# Two project-authored synthetic activation vectors, not hidden states from any LLM.
# This evaluates the gate alone, using verified gate tensors; it does not test quality.
x=torch.stack([torch.zeros(2560),((torch.arange(2560,dtype=torch.float32)%17)-8)/100])
prefix='model.layers.0.self_attn.retention_gate.'
w1=state[prefix+'linear1.weight'].float();b1=state[prefix+'linear1.bias'].float()
w2=state[prefix+'linear2.weight'].float();bias=state[prefix+'bias'].float()
h=F.silu(F.linear(x,w1,b1));pre=F.linear(h,w2)+bias;out=F.logsigmoid(pre)
assert tuple(out.shape)==(2,8) and bool(torch.isfinite(out).all()) and bool((out<=0).all())
# Independent scalar output-head calculation checks projection/bias/log-sigmoid,
# while first projection is covered by its verified shape and functional formula.
max_error=0.
for i in range(2):
 for j in range(8):
  v=math.fsum(float(h[i,k])*float(w2[j,k]) for k in range(512))+float(bias[j])
  expected_log=-math.log1p(math.exp(-v)) if v>=0 else v-math.log1p(math.exp(v))
  max_error=max(max_error,abs(expected_log-float(out[i,j])))
assert max_error<1e-4,max_error
from static_gate_adapter import retention_log_beta,static_keep_indices
xbf=x.to(torch.bfloat16).unsqueeze(0)
with torch.no_grad():
 adapter_beta=retention_log_beta(xbf,0,state)
assert tuple(adapter_beta.shape)==(1,8,2) and adapter_beta.dtype==torch.bfloat16
assert bool(torch.isfinite(adapter_beta).all()) and bool((adapter_beta<=0).all())
positions=torch.tensor([17,21],dtype=torch.int64).view(1,1,2).expand(1,8,2)
kept=static_keep_indices(adapter_beta,positions,22,1,buffer_size=1)
assert tuple(kept.shape)==(1,8,1)
kept_recent=static_keep_indices(adapter_beta,positions,22,1,buffer_size=1,protected_recent=1)
assert bool((kept_recent==1).all())
no_compress=static_keep_indices(adapter_beta,positions,22,1,buffer_size=3)
assert no_compress.shape[-1]==2
r=resource.getrusage(resource.RUSAGE_SELF)
assert r.ru_maxrss*1024<1024**3
assert 'transformers' not in sys.modules
result=dict(status='STATIC_GATE_TENSOR_MANIFEST_VERIFIED',evidence_class='TRAINED_GATE_ARTIFACT_AND_GATE_ONLY_SYNTHETIC_ALGEBRA_NO_LLM',revision='89112809f83d05c3058eadcab4104abde5721b81',artifact_sha256=sha.hexdigest(),artifact_bytes=FILE.stat().st_size,keys=len(records),parameter_count=param_count,total_tensor_bytes=sum(x['bytes'] for x in records),unique_storages=len(storage_ids),nonoverlapping_storage_views=True,unique_storage_bytes=sum(storage_ids.values()),dtype='torch.bfloat16',all_finite=True,exact_keyset=True,exact_shapes=True,backbone_tensor_keys_present=False,base_config_fields_matched=fields,torch_version=torch.__version__,safe_load=dict(weights_only=True,mmap=True,map_location='cpu',unsafe_globals=unsafe,arbitrary_object_fallback=False),archive=archive,gate_adapter_smoke=dict(dtype='BF16',layers_evaluated=[0],input_shape=list(xbf.shape),output_shape=list(adapter_beta.shape),source_score_gather_shape=list(kept.shape),protected_suffix_pass=True,trigger_slack_pass=True,pretrained_LLM_forward=False),gate_only_fixture=dict(source_formula='logsigmoid(linear2(silu(linear1(x))) + bias)',input='two synthetic deterministic vectors, no LLM activation',output_shape=list(out.shape),float32_eval=True,independent_scalar_max_abs_error=max_error),elapsed_seconds=time.perf_counter()-start,cpu_seconds=r.ru_utime+r.ru_stime,peak_rss_KiB=r.ru_maxrss,base_LLM_weights_downloaded=False,model_constructed=False,LLM_forward=False,GPU=False,upstream_code_executed=False)
(P/'tensor_manifest.json').write_text(json.dumps(dict(byte_order=sys.byteorder,tensors=records),indent=2)+'\n')
(P/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
