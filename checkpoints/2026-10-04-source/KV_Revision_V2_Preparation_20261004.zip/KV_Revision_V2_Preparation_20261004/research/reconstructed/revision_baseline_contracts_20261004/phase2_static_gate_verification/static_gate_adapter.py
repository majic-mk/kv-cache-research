"""Own small static-TRIM gate/operator adapter, not a model or attention backend.

Contract transcribed from pinned Apache-2.0 ngocbh/trimkv Qwen3 rg gate and
TrimKVCache. No upstream repository imports. Caller supplies verified tensors.
"""
import torch
from torch.nn import functional as F


def retention_log_beta(hidden_states, layer_idx, gate_state):
    """[1, chunk, 2560] BF16 -> [1, 8, chunk] BF16.

    Input must later be the same post-input-layernorm hidden states used by the
    native Qwen3 attention, before QKV projections, not queries or rotated keys.
    """
    if not 0 <= layer_idx < 36:
        raise ValueError('invalid fixed-backbone layer')
    if hidden_states.ndim != 3 or hidden_states.shape[0] != 1 or hidden_states.shape[2] != 2560:
        raise ValueError('expected batch-1 Qwen3 hidden states')
    if hidden_states.dtype != torch.bfloat16:
        raise ValueError('faithful rg gate contract requires BF16 input/parameters')
    prefix=f'model.layers.{layer_idx}.self_attn.retention_gate.'
    w1,b1,w2,bias=(gate_state[prefix+s] for s in ['linear1.weight','linear1.bias','linear2.weight','bias'])
    if any(t.dtype != hidden_states.dtype or t.device != hidden_states.device for t in [w1,b1,w2,bias]):
        raise ValueError('gate dtype/device differs from supplied hidden states')
    return F.logsigmoid(F.linear(F.silu(F.linear(hidden_states,w1,b1)),w2)+bias).transpose(1,2)


def static_keep_indices(log_beta, original_positions, seen_tokens, memory_size,
                        buffer_size=1, protected_recent=0):
    """Selection seam only; caller gathers corresponding K/V/positions/gates.

    This follows the source's fixed local budget, single-step scoring, trigger
    buffer and optional suffix. It deliberately exposes trigger slack separately.
    torch.topk ties are not guaranteed stable; do not rewrite them as a new rule.
    """
    if log_beta.ndim != 3 or original_positions.shape != log_beta.shape:
        raise ValueError('expected matching [batch, KV head, resident token] arrays')
    if log_beta.shape[:2] != (1,8) or memory_size < 1 or buffer_size < 1:
        raise ValueError('invalid static contract')
    if not 0 <= protected_recent <= memory_size:
        raise ValueError('protected suffix is inside budget')
    if original_positions.dtype != torch.int64:
        raise ValueError('original positions must be int64')
    if not bool((original_positions>=0).all() & (original_positions<seen_tokens).all()):
        raise ValueError('invalid original positions')
    if original_positions.shape[-1]>1 and not bool((original_positions[...,1:]>original_positions[...,:-1]).all()):
        raise ValueError('per-head survivor order must be strictly chronological')
    n=log_beta.shape[-1]
    if n < memory_size+buffer_size:
        return torch.arange(n,device=log_beta.device).view(1,1,n).expand_as(original_positions)
    scores=log_beta.to(torch.float32)*(seen_tokens+1-original_positions)
    if protected_recent:scores[...,-protected_recent:]=float('inf')
    return torch.sort(torch.topk(scores,memory_size,dim=-1).indices,dim=-1).values
