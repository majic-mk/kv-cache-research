"""Own monitor: hard CPU timer in child, 1 GiB sampled RSS kill, 300s wall."""
from pathlib import Path
import json,os,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=P.parents[3]
cmd=['bash',str(ROOT/'research/reconstructed/runtime_recovery_20261004/cpu_python.sh'),str(P/'verify_static_gate.py')]
start=time.monotonic();peak=0;termination=None
with (P/'verification.log').open('w') as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  try:
   s=Path(f'/proc/{proc.pid}/status').read_text()
   rss=next(int(x.split()[1])*1024 for x in s.splitlines() if x.startswith('VmRSS:'))
   peak=max(peak,rss)
   if rss>=1024**3:termination='RSS_LIMIT'
  except (FileNotFoundError,StopIteration):pass
  if time.monotonic()-start>300:termination='WALL_LIMIT'
  if termination:os.killpg(proc.pid,signal.SIGKILL);proc.wait();break
  time.sleep(.05)
rc=proc.wait()
r=dict(exit_code=rc,termination=termination,sampled_peak_rss_bytes=peak,RSS_limit_bytes=1024**3,wall_limit_seconds=300,elapsed_seconds=time.monotonic()-start,monitor_interval_seconds=.05,command=cmd)
(P/'resource_guard.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print((P/'verification.log').read_text());raise SystemExit(rc)
