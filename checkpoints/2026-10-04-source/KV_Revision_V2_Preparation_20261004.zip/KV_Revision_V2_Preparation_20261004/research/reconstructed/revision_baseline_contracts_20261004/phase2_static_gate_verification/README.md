# Phase 2: static TRIM gate artifact verified

2026-10-04 UTC. **The static learned gate payload passes exact artifact, safe-format, key, shape, dtype, finite-value and base-metadata checks.** This closes the prior packet's uninspected-gate-payload uncertainty. It does not close model integration, numerical parity, model competence or hardware admission.

## Scope and phase separation

This is a separately authorized gate-artifact phase. The parent directory's README, validation and acquisition summary remain the frozen **zero-weight phase-1 evidence**, not claims about this later phase. Phase 2 downloaded and evaluated the trained retention gate alone. No base LLM weights, dynamic-budget gate, pretrained LLM construction/forward, upstream repository execution, install, GPU or paid action occurred.

The actual payload is in ignored `outputs/revision_static_trim_gate_20261004/trimkv_weights.pth`. `git check-ignore` confirmed exclusion. It is not included in this source/receipt packet or its manifest.

## Exact acquisition and license

- Official pinned source: [ngocbh/TrimKV-Qwen3-4B-Instruct-2507, revision 89112809f83d05c3058eadcab4104abde5721b81](https://huggingface.co/ngocbh/TrimKV-Qwen3-4B-Instruct-2507/tree/89112809f83d05c3058eadcab4104abde5721b81)
- License: Apache-2.0 as explicitly declared in the pinned author model card; original TRIM source is Apache-2.0
- Pre-acquisition public access: official request returned HTTP 200; pinned metadata declares public, ungated access
- Followed the official Hugging Face redirect to its `us.aws.cdn.hf.co` CDN; no alternative mirror, proxy, account action or bypass
- Received exactly **94,725,981 bytes** in 18.515 seconds
- Artifact SHA-256: `a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a`, exactly matching the pinned official LFS manifest
- Phase-2 artifact transfer: below 110,000,000-byte cap; no retries or other weight downloads
- Disk free before/after: 17,731,837,952 / 17,637,105,664 bytes; the 5 GB floor remained satisfied

Receipts retain the public source URL and final origin/path; temporary signed URL query parameters are not retained.

## Tensor verification

The already-installed official CPU Torch 2.9.1 loaded the file with `weights_only=True`, `map_location='cpu'`, and `mmap=True`. No unsafe globals were found. Only a plain tensor dictionary was accepted; no arbitrary-object fallback or upstream loader was used. The archive was inspected without extraction, rejected path traversal/compression surprises, and stayed within the uncompressed-size bound.

- **144 exact expected keys**, all under `model.layers.{0..35}.self_attn.retention_gate`
- Each layer contains `linear1.weight [512,2560]`, `linear1.bias [512]`, `linear2.weight [8,512]`, and `bias [8]`
- **47,352,096 parameters**, all BF16, dense CPU tensors and finite
- **94,704,192 tensor bytes**, exactly equal to the unique backing-storage byte total
- Two coalesced storages hold nonoverlapping tensor views; there are no overlapping aliases or unexplained backing bytes
- **No base/backbone tensor keys present**
- Per-tensor hashes over contiguous little-endian BF16 bytes, offsets and storage groups are in `tensor_manifest.json`
- The gate configuration matches the fixed official base metadata on all 17 inspected architecture, normalization and RoPE fields

This certifies the saved artifact is exactly the gate-only overlay expected by the pinned source. Applying only this verified keyset cannot overwrite a backbone parameter. The base itself has not been acquired or tensor-verified; a future integration still must bind it to revision `cdbee75f17c01a7cc42f958dc650907174af0554` and avoid the author's unversioned automatic base fetch.

## Small executable gate adapter

`static_gate_adapter.py` is a project-authored operator seam, not a model/backend port. It imports only Torch and contains:

1. `retention_log_beta`: the pinned rg formula `logsigmoid(linear2(silu(linear1(x))) + bias)`, with batch-1 BF16 shape/device checks and the source's `[1,8,chunk]` output layout
2. `static_keep_indices`: the source's single-step FP32 scoring on original positions, trigger-buffer slack, optional protected suffix, `topk`, then chronological gather indices

Inputs were two deterministic synthetic activation vectors, unrelated to any LLM output. The gate's BF16 operator shape `[1,2,2560] → [1,8,2]`, score selection, explicit protected tail and delayed-trigger behavior passed smoke checks. An additional FP32 output-head algebra check against independent scalar sums/log-sigmoid had maximum absolute discrepancy **8.72e-12**. This is gate algebra only; it does not measure language quality, retention quality, trained-model parity, or CPU/GPU equivalence. No new gate was trained.

The adapter's inputs for a future native integration must be the same post-input-layernorm hidden states that feed native Qwen3 attention, before QKV projection. It must not be fed normalized queries or rotated keys. Its `seen_tokens` is the global canonical count, and all K/V/position/gate arrays must be gathered with the returned **per-head** indices. It does not implement these surrounding operations or a complete inference harness.

## Resource checks

Two successful bounded verifier passes were retained; the second added backing-span and adapter checks. Total verifier CPU was **2.728 seconds**, far below five minutes. The final pass took 1.361 seconds internally / 1.711 seconds including launcher; reported peak RSS was **328,568 KiB** (approximately 321 MiB). The external 50 ms RSS sampler observed 336,900,096 bytes, below 1 GiB. The process also had an OS CPU timer and a 300-second wall timer. No termination or retry was needed.

The earlier phase's 31 software tests are not added to these tensor counts or described as additional model experiments.

## Exact remaining integration work

`native_adapter_contract.json` specifies the bounded next implementation seam. A complete runtime remains unimplemented and unrun:

- Materialize the fixed base only after separate authorization; instantiate native Qwen3 with its own q/k norms, RoPE and attention backend, then apply this verified gate-only state to the gate modules
- Bind Full, same-class no-crop, static TRIM and selector controls to identical canonical IDs, chunk boundaries, BF16/base tensors, attention implementation and decode rules
- Pass original global positions, preserve per-head maps and reset all per-example state; evict only after the complete chunk's layer computations
- Use `memory_size=None` for author TRIM's no-crop control. The `compress_memory` flag is insufficient
- If implementing native recency/R-KV adapters, bridge the verified Transformers 4.57.1 cache interface deliberately; do not revive the broken `.key_cache` assumption or describe a port as paper reproduction
- Validate actual segmented/monolithic Full, no-op equivalence, compact causal masks and bounded allocation before any claimed empirical comparison

The gate payload has no remaining fidelity blocker under the checked static configuration. Model/runtime/backend and resource questions remain. The old 8 GiB guard still fails even the base+4K Full-KV lower bound; this 90.3 MiB gate adds overhead. No GPU admission follows.

**Disposition: STATIC_GATE_ARTIFACT_VERIFIED / GATE_ONLY_ADAPTER_SMOKE_PASS / BASE_MODEL_AND_RUNTIME_UNRUN / MODEL_AND_GPU_NOT_AUTHORIZED.**
