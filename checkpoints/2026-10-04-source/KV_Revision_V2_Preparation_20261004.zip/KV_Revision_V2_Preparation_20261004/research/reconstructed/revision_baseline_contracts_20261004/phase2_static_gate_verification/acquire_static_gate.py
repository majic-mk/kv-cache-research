"""Authorized fixed public static gate only; never fetch base/dynamic weights."""
from pathlib import Path
import hashlib,json,shutil,time,urllib.request,urllib.parse
P=Path(__file__).resolve().parent
ROOT=P.parents[3]
DEST=ROOT/'outputs/revision_static_trim_gate_20261004/trimkv_weights.pth'
URL='https://huggingface.co/ngocbh/TrimKV-Qwen3-4B-Instruct-2507/resolve/89112809f83d05c3058eadcab4104abde5721b81/trimkv_weights.pth'
SIZE=94725981
SHA='a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a'
CAP=110000000
FLOOR=5000000000
if DEST.exists():raise RuntimeError('Existing payload: inspect receipt; do not redownload blindly')
if (P/'acquisition_receipt.json').exists():raise RuntimeError('Existing acquisition receipt: no automatic retry')
assert json.loads((P/'pre_acquisition_check.json').read_text())['status']==200
before=shutil.disk_usage(ROOT).free
assert before-SIZE>FLOOR
DEST.parent.mkdir(parents=True,exist_ok=True)
partial=DEST.with_suffix('.partial')
received=0;h=hashlib.sha256();start=time.monotonic()
receipt=dict(source_url=URL,expected_bytes=SIZE,expected_sha256=SHA,total_transfer_cap_bytes=CAP,disk_floor_bytes=FLOOR,disk_free_before_bytes=before,license='Apache-2.0 per pinned author model card',base_model_downloaded=False,dynamic_gate_downloaded=False)
try:
 with urllib.request.urlopen(urllib.request.Request(URL,headers={'User-Agent':'bounded-public-static-gate-verification'}),timeout=45) as response, partial.open('xb') as f:
  parsed=urllib.parse.urlsplit(response.url)
  receipt.update(status=response.status,final_origin=parsed.scheme+'://'+parsed.netloc,final_path=parsed.path)
  if response.headers.get('Content-Length'):assert int(response.headers['Content-Length'])==SIZE
  while True:
   if time.monotonic()-start>300:raise TimeoutError('Acquisition wall-time cap')
   b=response.read(min(1024*1024,CAP-received+1))
   if not b:break
   received+=len(b)
   if received>CAP or received>SIZE:raise RuntimeError('Transfer exceeds fixed artifact size or cap')
   if shutil.disk_usage(ROOT).free-len(b)<FLOOR:raise RuntimeError('Disk floor reached')
   f.write(b);h.update(b)
 assert received==SIZE,received
 assert h.hexdigest()==SHA,h.hexdigest()
 partial.rename(DEST)
 receipt.update(result='EXACT_HASH_AND_SIZE_VERIFIED',payload_relative_to_repo=str(DEST.relative_to(ROOT)))
except Exception as e:
 receipt.update(result='BLOCKED',error=repr(e));raise
finally:
 receipt.update(received_bytes=received,sha256=h.hexdigest(),elapsed_seconds=time.monotonic()-start,disk_free_after_bytes=shutil.disk_usage(ROOT).free)
 (P/'acquisition_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))
