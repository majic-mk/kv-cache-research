# Revision-baseline interfaces: zero-weight certification

2026-10-04 UTC. This packet answers a finite source/interface feasibility question. It does not execute a pretrained model, import upstream model code, certify numerical parity, or authorize CPU/GPU inference. The existing hybrid-2B stopping decisions are unchanged.

## Result

**A small same-backbone comparison is source-supported in principle, with bounded integration work; an immediately runnable faithful CPU baseline suite is not certified.** The strongest minimal route is native Full + original-position recency controls + the released static TRIM gate, with a clearly labeled port of the pinned R-KV selector as the attention-based comparator. A random control is cheap and should accompany these. These are not new algorithms.

The learned TRIM route is materially better specified than in v1: its released gate artifact, declared parameter scope, base identity, attention normalization and no-crop switch are now pinned. Missing numerical/runtime tests are not evidence that it fails. Conversely, toy contracts cannot confer author-reproduction status on a port.

The current CPU 8 GiB guard cannot fit Full at even 4,096 tokens: base weights plus native BF16 KV alone exceed it. This is independent of whether the semantic v2 packet succeeds. No hardware or model escalation follows automatically.

## Pins and licenses

All newly read files have URL/size/SHA-256 receipts in `source_receipts.json`; local reuse is in `reused_source_receipts.json`. Exact source text is archived in `sources/`. No source file was imported or executed. Metadata acquisitions are under the 5 MB cap (`acquisition_summary.json`).

| Component | Pinned revision | License and conclusion |
|---|---|---|
| [Qwen3-4B-Instruct-2507](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507/tree/cdbee75f17c01a7cc42f958dc650907174af0554) | `cdbee75f17c01a7cc42f958dc650907174af0554` | Apache-2.0; plain 36-layer attention, 32 query/8 KV heads, head dim 128, no native sliding layers |
| [TRIM source](https://github.com/ngocbh/trimkv/tree/49d2a2951ba12e6431a3986b418ee791b209d7c2) | `49d2a2951ba12e6431a3986b418ee791b209d7c2` | Apache-2.0; retained prior audit's exact pin |
| [Static TRIM gate](https://huggingface.co/ngocbh/TrimKV-Qwen3-4B-Instruct-2507/tree/89112809f83d05c3058eadcab4104abde5721b81) | `89112809f83d05c3058eadcab4104abde5721b81` | Apache-2.0 model card; gate-file metadata only, no weights fetched |
| [DBTRIM gate](https://huggingface.co/ngocbh/DBTrimKV-Qwen3-4B-Instruct-2507/tree/a1e870d8f2f5bf3b0921be106a0fb3feeb8a6618) | `a1e870d8f2f5bf3b0921be106a0fb3feeb8a6618` | Apache-2.0 model card; acknowledged stronger dynamic variant, not silently equated with static TRIM |
| [Current MInference](https://github.com/microsoft/MInference/tree/29ef1974fcb5a1440ccf92d7d7996900230fddcf) | `29ef1974fcb5a1440ccf92d7d7996900230fddcf` | MIT; current main was resolved read-only on this date |
| [TRIM author's referenced MInference](https://github.com/microsoft/MInference/blob/fc1c63f595a0143e47cf6af4bbb729bc31198ee9/minference/modules/forward.py) | `fc1c63f595a0143e47cf6af4bbb729bc31198ee9` | Exact forward bytes equal current main, SHA-256 `7216317f276268043358e3ce01e42796d500c1a5981206b9ee4052791673bfe3` |
| [Transformers 4.57.1](https://github.com/huggingface/transformers/tree/8cb5963cc22174954e7dca2c0a3320b7dc2f4edc) | `8cb5963cc22174954e7dca2c0a3320b7dc2f4edc` | Apache-2.0; tag resolved by `git ls-remote`; three source files archived |
| [Round Attention paper v3](https://arxiv.org/html/2502.15294v3) | paper version, not code | CC-BY-4.0; recoverable-cache comparison only |

A bounded Round Attention repository search found [ck853178967/round-attention-transformers](https://github.com/ck853178967/round-attention-transformers/tree/161060836d1c8efcc635629b3c65bf5ea4d59421), branch develop at `161060836d1c8efcc635629b3c65bf5ea4d59421`, Apache-2.0. **Its association with the paper authors was not verified.** Its README is inherited generic Transformers documentation; the inspected cache and Qwen2 files do not expose a Round Attention interface. This does not prove absence elsewhere. Do not relabel this search hit as certified author code. No Qwen3-4B watershed or faithful integration was found in the bounded inspection; the optional comparison stops there.

## Interface compatibility matrix

| Arm | Verified source contract | Small required integration / limits | Status |
|---|---|---|---|
| Native Full | Pinned official Qwen3 attention includes q_norm/k_norm; append-only DynamicCache | Fixed canonical IDs and explicit original positions; no cropping; same BF16/backend/decode rule; later segmented/monolithic and no-op parity | Source-supported, runtime untested |
| Last-N and prefix+recent | Simple selection from resident native KV; author packaged selector implements prefix/suffix | Explicit seen counter independent of resident length; gather all state; original RoPE positions; prefix+tail inside B | Reference fixtures passed; a control adapter is not paper StreamingLLM reproduction |
| Random outside protected region | Project-authored control; persisted seeded RNG | Repeated uniform eviction among currently available unprotected tokens; not claimed equivalent to uniform sampling of all historical tokens | Reference fixtures passed; no model adapter |
| R-KV selector port | Pinned vendored `R1KV.update_kv`; recent-query attention + key redundancy + protected suffix; Qwen3 branch has q/k norms | Cache API bridge, original-position maps, flag/reset/timing contract; same exact selector math, including GQA max-pooling before softmax and quadratic similarity cost | Feasible declared port; not author performance reproduction |
| Cumulative heavy hitter | Own scalar score-state fixture verifies accumulation/gather/reset | No original H2O backend certified. Packaged `h2o.py` uses the latest query, not accumulated history | Fixture only; do not report as H2O result |
| Static TRIM | Gate-only scope, native q/k norms, monotonic seen count, per-head position/gate gather, post-chunk compression | Pin base and overlay separately; batch 1/unpadded/chronological survivors; same author FlashAttention path; safe no-crop Full; gate payload validation and runtime parity later | Best minimal strong source-supported route |
| DBTRIM | New rg10 gate; global cross-head/layer budget; ragged lengths and paged storage | Different gate and allocation policy; allocated blocks grow and can exceed live-token budget; new backend/physical memory certification needed | Optional stronger extension; not required to port for this first static-policy boundary |
| MInference SnapKV | First initialization compresses; later global cache calls append; resident GQA KV expanded to query-head count | Missing q/k normalization patch, old cache API, no bounded re-pruning; final-query observation policy must be declared | One-shot diagnostic only as shipped; exact authors' patched environment not recovered |
| Round Attention | Paper keeps complete host backing; early layers full; selects/recalls rounds | Source authorship, Qwen3 watershed and integration unverified; host cache/transfers count | Optional recoverable-cache boundary, outside minimal subset |

The minimal proposed set is Full, Last-N, prefix+recent, random, **R-KV-selector port**, static author TRIM, plus a same-class no-crop TRIM control. R-KV satisfies the requested attention-based alternative; a fake cumulative-H2O label is unnecessary. Static TRIM is chosen for transparent per-head capacity and the already-published update-category comparison, not as a claim of current state-of-the-art strength. DBTRIM is explicitly acknowledged. Failure of static TRIM would support only a static-policy boundary unless stronger policies were also tested later.

### Exact source issues resolved or narrowed

1. **TRIM does normalize Q/K.** `trimkv_modeling_qwen3.py:251-276` creates/applies per-head norms. Its inference wrapper dispatches to standard attention while dropping gate weights from the attention calculation. Gates affect selection, not full inference attention. Native Full with the same base and same kernel is therefore a sensible planned control.
2. **Gate-only scope is supported, but payload not inspected.** Both released configs say `trainable_params=self_attn.retention_gate`. Training `train.py:302-312,384-389` freezes the rest and saves only those names. Loader `modeling...:493-519` loads the declared base, verifies exact overlay-key equality, then overlays. Static gate metadata: 94,725,981 bytes, SHA-256 `a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a`; DB gate: 113,361,053 bytes, SHA-256 `cf9bf411db33550b7b77accf89125f5867ecdbbf4cf7dc024d10c4fee87b0a21`. `expected_static_gate_manifest.json` contains 144 expected keys / 47,352,096 parameters derived from source, **not an actual tensor inventory**. These files remain undownloaded. The base ID in metadata is unversioned: later acquisition must resolve to the fixed base revision, rather than let the loader fetch moving main.
3. **TRIM no-crop switch:** construct `TrimKVCache(memory_size=None)` so `do_compress=False`. The model unconditionally calls `compress()` after the entire supplied chunk. Changing `model.config.compress_memory` is not a reliable no-eviction switch. A same-class gate-loaded no-crop control also keeps gate computation overhead visible.
4. **TRIM buffer is slack, not protection.** `buffer_size` delays eviction until row length reaches `B+buffer`. Post-call occupancy can be `B+buffer−1`; transient append occupancy can be `B+buffer−1+C`. The independently named `sliding_window_size` makes a suffix score infinite, and defaults to zero. The inspected loader does not pass it. Never describe its buffer as a guaranteed protected correction window. A matched-window TRIM setting must be explicit; retain native settings as a separately named control if needed.
5. **Position/offset concern is narrowed.** TRIM rotates new Q/K at original positions, sorts selected indices, and preserves all new chunk entries until attention is computed. For batch 1 without padding, an ordinary right-aligned causal mask over chronological surviving past plus the complete current suffix is logically valid despite historical holes. The layer-0 seen update makes later-layer `offset` values differ, but standard static inference does not explicitly use that offset in the inspected wrapper. This is not a demonstrated static-TRIM error. Generic eager/SDPA, padding, per-head ragged, or altered mask paths still need their own numerical validation; no CPU workaround was implemented.
6. **R-KV's bridge is concrete.** The LongMemEval loader constructs Transformers `DynamicCache`, while the Qwen3 branch writes `.key_cache/.value_cache`. Pinned Transformers 4.57.1 stores `.layers[*].keys/.values`, and `get_seq_length()` reads resident storage. A fresh cache also does not reset `model.length`, `after_think`, selection diagnostics or compression flags. The LongBench custom cache has monotonic `_seen_tokens`, but that is a distinct path. Port the selector into the common explicit contract rather than call the shipped LongMemEval script faithful. Its `topk` outputs are not sorted; reordering needs paired K/V/query/position maps and checks of later order-sensitive redundancy handling.
7. **MInference is not already patched.** Neither the author-referenced nor current `attn_forward` contains q_norm/k_norm. The documented patch must remain a named change. `BaseKVCache.update` repeats GQA KV before storing, compresses only during initialization, then concatenates later calls. There is no strict persistent B-token bound here. Also the TRIM loader supplies `first_tokens`, whereas MInference's StreamingLLM cache reads `n_init` (default 128); those options are not interchangeable. Fixing them is engineering, not a new scientific method.

## Common operation contract

- Tokenize once; every ingestion chunk is an exact prefix extension of the same canonical ID stream. Teacher-force recorded intermediate utterances. No generated-response divergence, recovered evicted entries, final-answer tags, or support-only truncation.
- Freeze chunk size cap C and session boundaries. Split long sessions into recorded subchunks; do not change chunks by method. Advance one global seen counter once per chunk, independent of number of layers and survivor length. Supply original `position_ids/cache_position`; never rebase RoPE to retained length.
- Each (layer, KV head) has a surviving-position map, K/V, valid count, policy state and any query/score history. Gathers operate atomically on corresponding arrays. Packed/ragged layouts carry explicit head offsets; padding is never valid evidence. Reset cache, counters, flags, RNG, score/query buffers, diagnostics and pending generation token per example.
- Primary selection is history-only. Recent query vectors from already-ingested recorded history are allowed; the final user question is not available before the declared query boundary. After that boundary, either freeze selection for all arms or admit the same question/decode history to all arms under a separately named schedule. Do not remove a method's native required query and call it faithful.
- Last-N/prefix+recent retain original-position KV. They are defined eviction controls on this non-windowed Qwen3 backbone, not a claim that its config has a native sliding architecture, or that the full StreamingLLM position-reindexing system was reproduced.
- A static TRIM native run can have no protected suffix. Correction age relative to the recency control's W must not be described as the learned arm's own protected age unless `sliding_window_size=W` was actually set and charged.

## One-shot, online and causal interpretation

One-shot full-history construction has a Full KV peak during ingestion and may let later history choose which earlier entries survive. Compressing at its end does not make it feasible under the same ingestion memory budget. Its role is a **diagnostic with a larger peak-memory allowance**, not a competing feasible B-budget serving baseline. The one-shot and online arms still use the exact same history/query information boundary; avoid accidental final-query access in just one arm.

Online eviction changes both retained positions and later hidden states used to form new K/V (and TRIM gates or future query scores). Retaining the correction's literal token positions does not hold its representations constant. A later mechanism intervention could take selected positions from one policy and gather **teacher Full-produced K/V** at those positions to test a controlled cache-content contrast. That is an oracle diagnostic: charge the teacher Full pass, full historical states or replay, gather/pack, and coexistence memory. Forcing teacher states during online ingestion changes the system being evaluated; it is not the operational online arm. Such interventions do not identify a unique natural mediation decomposition because selection and representations interact.

## Cost accounting and hardware lower bounds

Record separate prefill, replay, score, gather, pack, decode, persistent bytes, transient peak, host backing and transfer costs. An unmeasured entry is unknown, not zero. Preserve allocator-reserved/physical bytes as well as logical token occupancy. Concatenation can temporarily retain input and output arrays; gather can coexist with both old and selected K/V. DBTRIM additionally has block slack, sentinel blocks, block tables, free lists and expansion copies. Native GQA is 8 KV heads; MInference's expanded 32-head storage is four times the KV payload at equal nominal token count.

At batch 1, native BF16 KV costs `2 × 36 × 8 × 128 × 2 = 147,456 bytes/token` (144 KiB). Scores, positions and queries are additional. A retained entry can require int64 position + FP32 score beyond its 512 K/V bytes. R-KV's recent query cache costs `36 × 32 × W × 128 × 2` bytes, and its similarity routine materializes a KV-head × K × K matrix plus Boolean and int64 indexing temporaries. Do not charge only its final selected KV.

Official parameter count implies 8,044,936,192 BF16 bytes. The official checkpoint index reports 8,045,591,552 bytes (7.493 GiB), while three shard file sizes sum to 8,044,982,000 bytes. This small metadata discrepancy is retained; conservative estimates use the index. No tensor payload or header was fetched to reconcile it.

| Full tokens | KV only | Conservative weights + KV |
|---:|---:|---:|
| 4,096 | 0.563 GiB | 8.056 GiB |
| 7,333 | 1.007 GiB | 8.500 GiB |
| 16,384 | 2.250 GiB | 9.743 GiB |
| 32,768 | 4.500 GiB | 11.993 GiB |
| 131,072 | 18.000 GiB | 25.493 GiB |
| 262,144 | 36.000 GiB | 43.493 GiB |

These omit activations, gate parameters, full logits, query buffers, allocator/runtime and load-time duplication. Under 8 GiB, the impossible zero-overhead Full limit is only 3,691 tokens; this is not a safe admitted limit. A parent-reported approximately 10.45 GB RAM/17 GB disk cloud envelope does not establish usable free resources. A new plain BF16 CPU qualification would need a distinct guard and resource decision; the old FP32 hybrid qualification cannot be borrowed. A nominal 32 GiB 5090 could plausibly hold the raw 128K Full tensors, but actual usable VRAM, FlashAttention/Triton architecture support, peak allocation and runtime have not been tested. It cannot hold raw 256K Full KV plus weights. No GPU price, rental, installation or fit claim is made.

## Verified deliverables and disposition

`reference_contracts.py` and 24 stdlib state-machine fixtures test append/evict, original positions, score persistence, per-head gather and validity, reset, random determinism, full/no-op controls, same-information checks and resource bounds. Seven additional tests check pinned source bytes and claims. **31 tests passed in ~0.018 s, peak process RSS 14,848 KiB.** No Torch/Transformers import occurred. These are not attention/numerical/model-quality tests. A missing `/usr/bin/time` launcher attempt is preserved; the unchanged suite was measured with stdlib `resource` and `perf_counter` instead.

Re-run from repository root:

`python -m unittest discover -s research/reconstructed/revision_baseline_contracts_20261004 -p 'test_*.py' -v`

The source gate supports **a finite future same-backbone integration**, not an automatic inference release. The exact remaining work is the small common-cache bridge for controls/R-KV, faithful static TRIM/no-crop execution on an authorized compatible runtime, and measured parity/memory on the final frozen inputs. If that grows into new training or open-ended backend development, it violates this feasibility route. Round Attention, DBTRIM and quantization do not need to be engineered merely to keep this packet open.

**Disposition: SOURCE_ROUTE_CONDITIONALLY_FEASIBLE / ZERO_WEIGHT_CONTRACTS_PASS / RUNTIME_AND_NUMERICAL_CERTIFICATION_NOT_RUN / CURRENT_8GIB_FULL_NO_FIT / MODEL_AND_GPU_NOT_AUTHORIZED.**
