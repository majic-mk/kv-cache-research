"""Regenerate audit metadata from already-local source text; no network/imports."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
ROOT=P.parent
S=P/'sources'
def put(name,x): (P/name).write_text(json.dumps(x,indent=2)+'\n')
reuses={
 'qwen_config.json':ROOT/'revision_causal_input_packet_20261004/sources/qwen3_4b__config.json',
 'qwen_tree.json':ROOT/'revision_causal_input_packet_20261004/sources/qwen3_4b__tree.json',
 'qwen_model_info.json':ROOT/'revision_causal_input_packet_20261004/sources/model_info.json',
 'qwen_LICENSE':ROOT/'revision_causal_input_packet_20261004/sources/qwen3_4b__LICENSE',
 'trimkv_modeling_qwen3.py':ROOT/'revision_causal_input_packet_20261004/sources/trimkv__modeling_trimkv_qwen3.py',
 'trimkv_rkv_modeling.py':ROOT/'revision_causal_input_packet_20261004/sources/trimkv__rkv_modeling.py',
 'trimkv_cache_utils.py':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__src__trimkv__cache_utils.py',
 'trimkv_load_model.py':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__load_model.py',
 'trimkv_author_warning.md':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__README.md',
 'trimkv_packaged_h2o.py':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__rkv__compression__h2o.py',
 'trimkv_streamingllm.py':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__rkv__compression__streamingllm.py',
 'trimkv_LICENSE':ROOT/'revision_sensitive_kv_sources_20261004/trimkv__LICENSE',
}
receipts=[]
for name,src in reuses.items():
 b=src.read_bytes();(S/name).write_bytes(b)
 receipts.append(dict(file=name,reused_from=str(src.relative_to(ROOT.parent.parent)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),network_bytes=0))
put('reused_source_receipts.json',receipts)
q=json.loads((S/'qwen_config.json').read_text()); index=json.loads((S/'qwen_index.json').read_text());tree=json.loads((S/'qwen_tree.json').read_text())
info=json.loads((S/'qwen_model_info.json').read_text())
weights=index['metadata']['total_size']; param=info['safetensors']['total'];bf=param*2
kv=2*q['num_hidden_layers']*q['num_key_value_heads']*q['head_dim']*2
static=json.loads((S/'static_trim_config.json').read_text());dyn=json.loads((S/'dynamic_trim_config.json').read_text())
manifest=[]
for l in range(36):
 for suffix,shape in [('linear1.weight',[512,2560]),('linear1.bias',[512]),('linear2.weight',[8,512]),('bias',[8])]:
  manifest.append(dict(name=f'model.layers.{l}.self_attn.retention_gate.{suffix}',shape=shape))
put('expected_static_gate_manifest.json',{'status':'EXPECTED_FROM_SOURCE_NOT_WEIGHT_PAYLOAD_INSPECTION','trainable_params':static['trainable_params'],'keys':manifest,'expected_parameter_count':36*(512*2560+512+8*512+8)})
scenarios=[]
for n in [512,1024,2048,4096,7333,8192,16384,32768,65536,131072,262144]:
 scenarios.append(dict(tokens=n,kv_bytes=n*kv,weights_plus_kv_bytes=weights+n*kv,weights_plus_kv_GiB=(weights+n*kv)/2**30))
put('hardware_feasibility.json',{
 'evidence_class':'METADATA_ONLY_LOWER_BOUNDS_NOT_MEASURED_FIT','model_revision':'cdbee75f17c01a7cc42f958dc650907174af0554',
 'official_safetensors_parameter_count':param,'bf16_parameter_payload_bytes_from_parameter_count':bf,
 'official_index_total_size':weights,'sum_shard_file_sizes':sum(x['size'] for x in tree if x['path'].endswith('.safetensors')),
 'metadata_discrepancy_note':'Index total_size is 655360 bytes larger than count*2 and exceeds shard files sum. Use index conservatively; no tensor headers/payloads fetched to reconcile.',
 'conservative_base_weight_GiB':weights/2**30,'kv_bytes_per_token_batch1_native8heads':kv,
 'm_inference_expanded32heads_multiplier':4,'8GiB_zero_overhead_max_full_tokens':(8*2**30-weights)//kv,
 '8GiB_guard_disposition':'Full at 4096+ tokens exceeds guard before any runtime/activation overhead; smaller B is not a fit certificate.',
 'FP32_base_payload_bytes':param*4,
 'static_gate_file_metadata':next(x for x in json.loads((S/'static_trim_tree.json').read_text()) if x['path']=='trimkv_weights.pth'),
 'dynamic_gate_file_metadata':next(x for x in json.loads((S/'dynamic_trim_tree.json').read_text()) if x['path']=='trimkv_weights.pth'),
 'scenarios':scenarios,
 '32GiB_nominal_scenario':'131072-token Full: 25.493 GiB raw weights+KV; plausible headroom only. 262144-token Full: 43.493 GiB, cannot fit without another storage regime.',
 'cloud_10_45GB_ram_17GB_disk':'Parent-provided envelope only, not current free resources or allocation permission. 16K Full alone ~9.743 GiB; prefill/runtime exceeds that lower bound. Single base artifact ~8.045GB disk; copies/conversion/install can exhaust 17GB.',
 'unmeasured_costs':['activations','Q/K/V projections','RKV pairwise similarity and index matrices','full logits','gate buffers','gather coexistence','packing','runtime','allocator','load-time duplication','host page cache','kernel architecture support'],
 'no_weights_or_model_forward':True})
put('pins_and_licenses.json',{
 'date_utc':'2026-10-04',
 'trim_source':{'repo':'ngocbh/trimkv','revision':'49d2a2951ba12e6431a3986b418ee791b209d7c2','license':'Apache-2.0'},
 'static_trim_gate':{'repo':'ngocbh/TrimKV-Qwen3-4B-Instruct-2507','revision':'89112809f83d05c3058eadcab4104abde5721b81','license':'Apache-2.0','only_metadata_read':True},
 'dynamic_trim_gate':{'repo':'ngocbh/DBTrimKV-Qwen3-4B-Instruct-2507','revision':'a1e870d8f2f5bf3b0921be106a0fb3feeb8a6618','license':'Apache-2.0','only_metadata_read':True},
 'base':{'repo':'Qwen/Qwen3-4B-Instruct-2507','revision':'cdbee75f17c01a7cc42f958dc650907174af0554','license':'Apache-2.0'},
 'minference_current':{'repo':'microsoft/MInference','revision':'29ef1974fcb5a1440ccf92d7d7996900230fddcf','license':'MIT','commit_observation':'GitHub commits/main returned this SHA on 2026-10-04; later API archival hit rate limit'},
 'minference_author_reference':{'revision':'fc1c63f595a0143e47cf6af4bbb729bc31198ee9','forward_byte_identical_to_current':True,'qwen3_norm_patch_present':False},
 'transformers':{'repo':'huggingface/transformers','tag':'v4.57.1','revision':'8cb5963cc22174954e7dca2c0a3320b7dc2f4edc','tag_object':'a47e6666f8f9a61e44a5d149c5e3d230e6c8053c','license':'Apache-2.0','pin_method':'git ls-remote peeled annotated tag; archived source hashes'},
 'round_attention':{'paper':'https://arxiv.org/html/2502.15294v3','paper_license':'CC-BY-4.0','author_source_certified':False,
 'candidate_repo':'ck853178967/round-attention-transformers','candidate_revision':'161060836d1c8efcc635629b3c65bf5ea4d59421','candidate_license':'Apache-2.0','candidate_association':'Not verified as author release. Generic inherited README; no Round interface in two inspected files. Do not label author reproduction or claim exhaustive code absence.'},
 'reference_code':'project-authored stdlib fixture, no upstream imports/execution'})
network=json.loads((P/'source_receipts.json').read_text())
put('acquisition_summary.json',{'cap_bytes':5000000,'successful_receipted_bytes':sum(x.get('bytes',0) for x in network),'bounded_error_unarchived_metadata_reserve':100000,'charged_upper_bound_bytes':100000+sum(x.get('bytes',x.get('charged_bytes',0)) for x in network),'weights_bytes':0,'tokenizer_bytes':0,'upstream_execution':False,'installs':0,'GPU_actions':0,'paid_actions':0})
