# Revision v2 input and baseline preparation snapshot

This archive preserves the completed v2 input-feasibility packet and the completed baseline contract/source records, including phase-2 static-gate verification metadata. It is preparation evidence, not a completed native model experiment, measured revision/compression interaction, GPU performance result or validated new main method.

The active input set is revision_causal_v2_20261004/refinement_02_delimiter, identified by LATEST_INPUTS.json and SHA-256 b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7. Its 16 constructed variants across two fixed feasibility families are retained alongside the original 16 variants, failed owner-token probes, mechanical failure/fix history and frozen plans. They are constructed causal-input probes, not untouched natural benchmark examples. All source labels and stored artifacts remain unchanged.

The phase-1 receipt records 31 passing model-free contract/source checks. Phase 2 verified an acquired trained static-gate artifact: 144 tensor keys, exact shapes and finite values, plus gate-only synthetic algebra. These records include safe loading and resource receipts. They do not establish a pretrained LLM forward, integrated baseline fidelity or model quality. The active native-reference implementation was excluded because it was unfinished at snapshot time.

## Dependencies and restoration

Extract into a new directory and retain the research/ layout. PACKAGE_MANIFEST.json covers every payload file except itself; BACKUP_VERIFICATION.json identifies all 135 unchanged original files, the three original manifest scopes, and external dependencies. The 94,725,981-byte public static-gate payload is intentionally excluded, with its exact immutable URL, SHA-256 and acquisition receipt retained. Source retrieval failures and the distinction between author-certified and uncertified baseline code remain as recorded. Four supplied license files are preserved.

The official oracle corpus and older input diagnostic are in the separate Library archive identified by BACKUP_VERIFICATION.json. The v2 packet reuses that corpus by hash rather than copying it again. Environments, external tokenizer/model payloads, and active native integration are excluded. This archive is complete for its stated source/metadata scope, not a self-contained runnable LLM environment. Main scientific checkpoint version 7 remains independent. No project tests, tokenizer, tensor loads, models or benchmarks were run for packaging.
