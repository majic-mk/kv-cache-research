# KV Cache 研究进度与恢复说明 20261004

准备文件快照时间为 2026-10-04 13:26:14 UTC。截止该快照，项目已得到两项可审计的 CPU 负结果，并完成 revision 方向的有限输入和基线准备。**目前没有经过验证的新颖主方法，没有本项目 GPU 实验结果，也没有足以承诺论文分区或投稿就绪的证据。** 以下状态保留各阶段原有停止条件，不将准备工作当作模型效果。

## 已完成结果和当前边界

- **原始 first24：`STOP_NO_QUALIFYING_HARM`。** 24/24 个实验单元全部答对，但这不是 24 个独立问题。预设规则要求两个固定组的 gold loss 与 margin loss 均达到 0.1 nat；d05 的 gold loss 仅 0.0170323 nat，未通过。独立终止复核支持停止，原 donor、observer、repair 分支不推进。该结果不证明所有 contextual reuse 都无害，也不证明修正方法必然无效。见[独立复核](research/reconstructed/contextual_harm_stage1_original_terminal_review_20261004.md)
- **MuSiQue Full6：`STOP_COMPETENCE`。** 六道固定题均正常 EOS 完成，EM/F1 均为 1/6，低于事前规定的至少三题正确。三组分段控制和资源检查通过；这是该固定模型、提示与完整文档设置下的能力筛查失败，不能推广为普遍无能力。没有放行 cache 对照、换题、换模型或修正臂。见[结果](research/reconstructed/musique_full6_cpu_20261004/RESULTS.md)及[独立复核](research/reconstructed/musique_full6_cpu_terminal_review_20261004.md)
- **Revision v2：有条件的输入准备完成。** 55 个 latest-state 条目经双重审查后，27 个共同接纳、16 个共同拒绝、12 个分歧未接纳；固定选取两个独立 source family，形成 16 个输入。最终活动版本由 [LATEST_INPUTS](research/reconstructed/revision_causal_v2_20261004/LATEST_INPUTS.json)指向 `refinement_02_delimiter/`，输入 SHA-256 为 `b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7`。精确 token、原文保存、结构及渲染语义检查通过，相关/无关复制条件的整段差异仅限 owner 标签。两个 family 不足以说明效应或统计功效；原始失败和旧版均保留。见[报告](research/reconstructed/revision_causal_v2_20261004/REPORT.md)
- **基线准备：来源与接口契约已核对，完整模型比较尚未验证。** 零权重阶段的 31 个软件契约/源码断言测试通过，它们不是模型质量实验。后续 phase2 单独下载并验证了已训练的静态 TRIM gate：94,725,981 字节、144 个 tensor、47,352,096 个参数；gate-only 运算 smoke 检查通过。没有下载基础 LLM 权重，没有 LLM forward，也没有 GPU 操作。父目录零权重 README 是历史阶段记录，载荷状态以 [phase2 报告](research/reconstructed/revision_baseline_contracts_20261004/phase2_static_gate_verification/README.md)为准
- **Native reference：仅处于未完成整合阶段。** `revision_native_reference_20261004` 不纳入此次 preparation 备份，不计为完成的模型运行、数值对齐或可执行强基线

原 8 GiB 资源限制下，Qwen3-4B 的 BF16 基础权重加 4,096-token Full KV 下界已约为 8.056 GiB，尚未计入其他开销。gate 检查通过不等于模型整合或硬件准入通过。后续需要同一权重、同一输入流下的真实 Full 分段/无裁剪等价性、位置/掩码正确性和峰值资源证据；当前包不构成新一轮模型或 GPU 实验的完成证明。

## 先前工作如何约束主张

既有审计已发现强覆盖：HYPIC、LinearKV 等直接邻近 hybrid 复用问题；TRIM-KV、Round Attention、AgentKV 以及 changed-fact cache intervention、PI-LLM、SleepGate、KVEraser 等覆盖更新、旧值干扰、在线处理或 stale-aware 管理；FlashInfer 等已有 Blackwell 直接 packed-KV 路径。移植、修补接口或组合常见控制不能单独声称新方法。

仍保留的有限问题是：固定容量的不可逆驱逐，是否与旧信息相关性/重复次数、信息位置/年龄和在线摄入方式产生压缩特有的交互。**目前只有条件性输入可行性，尚无这一交互的模型结果。** 文献审计是限定来源和版本的核查，不是穷尽证明，也不支持“所有创新都不可能”。详见[revision 设计复核](research/reconstructed/revision_causal_design_review_20261004.md)与 [Blackwell 执行审计](research/reconstructed/blackwell_kv_execution_audit_20261004.md)。

## 费用与计算记录

**新增服务器/GPU租用支出0元；未执行其他购买/付费API调用；平台已含额度使用量未量化。** 本次 v2 输入准备支出为 CNY 0，phase2 gate 阶段 paid actions 为 0。没有将 CNY 100 的历史候选预算当作实际支出。

可核对的 first24 成功尝试外层 wall 为 386.226860 秒；此前零-forward 技术失败另为 24.721408 秒，两次合计 410.948268 秒。Full6 外层 wall 为 1,033.463478 秒、child CPU 为 1,025.352629 秒。它们包括加载、检查和证据开销，不能当作纯推理时间、服务延迟、GPU 性能或整个项目总工时。gate verifier 的 2.727749 CPU 秒属于 gate 验证，31 个软件测试的约 0.018281 秒属于契约测试。

工程工时未记录，不能从 CPU 时间推算；平台已含额度使用量未量化。未将平台账号费用或已含额度折算成新增项目支出，也未假定存在未获批准的额外收费。详见[结构化费用记录](CURRENT_PROJECT_EXPENSES_20261004.json)。

## 已保存的恢复入口

完整文件 ID、哈希及恢复依赖见[项目归档索引](PROJECT_ARTIFACT_INDEX_20261004.json)。

- [主仓库 v7](https://chatgpt.com/api/library/files/libfile_720dc25a6108819181ce77e9d2fadf63/download)，对应 commit `a60fac3abe9cba48105092d3e7dd792a241b3313`
- [first24 provenance](https://chatgpt.com/api/library/files/libfile_575af43c021081918073c6e022a607db/download)，以及下列 **全部八个 Raw 包**。仅恢复主仓库或 provenance 不足以恢复 first24 全量已保存 raw 证据
- [Full6 完整归档 version 2](https://chatgpt.com/api/library/files/libfile_bc699f2b72ec81918c58febc973672af/download)；[Full6 结果包](https://chatgpt.com/api/library/files/libfile_f83964ba56088191b210b2ad7ab081c2/download)不能替代完整归档
- [Revision 输入 v1](https://chatgpt.com/api/library/files/libfile_7e17df3d48348191bdac1cc82b5a73b5/download)；[Blackwell 与 revision 审计](https://chatgpt.com/api/library/files/libfile_ccad5038b0b881919fbe66478025b6b4/download)
- [此次 v2 preparation 合并快照](https://chatgpt.com/api/library/files/libfile_eb47ac747be081918af5c0edb54c6808/download)，Library ID 为 `libfile_eb47ac747be081918af5c0edb54c6808`，保存最终 v2 输入、基线契约及 phase2 元数据。快照内证据入口为 [v2 最终输入](research/reconstructed/revision_causal_v2_20261004/refinement_02_delimiter/constructed_variants.json)、[基线契约](research/reconstructed/revision_baseline_contracts_20261004/README.md)及[phase2 元数据](research/reconstructed/revision_baseline_contracts_20261004/phase2_static_gate_verification/phase2_summary.json)

- [Raw 01/08](https://chatgpt.com/api/library/files/libfile_2c9157fd07d481919c005a9c0e310456/download)
- [Raw 02/08](https://chatgpt.com/api/library/files/libfile_fb74e622076c819199afedfb18767a34/download)
- [Raw 03/08](https://chatgpt.com/api/library/files/libfile_99dacfc83cac819189c8c4e0ac104e67/download)
- [Raw 04/08](https://chatgpt.com/api/library/files/libfile_c62aa67a74408191a9f40b20c72524a9/download)
- [Raw 05/08](https://chatgpt.com/api/library/files/libfile_5d66563f2e3881918d0edc65d5e7a712/download)
- [Raw 06/08](https://chatgpt.com/api/library/files/libfile_66736a38b5b08191a64e926c6d56765b/download)
- [Raw 07/08](https://chatgpt.com/api/library/files/libfile_63df4554758c819181edc7f70c7cedbb/download)
- [Raw 08/08](https://chatgpt.com/api/library/files/libfile_7add2aee70ac8191af0cfa7fae26e787/download)

## 恢复范围与限制

本文件位于快照根目录；`research/reconstructed/...` 均为相对快照仓库根的路径。旧结果引用须结合主仓库/相应历史归档恢复；它们不意味着全部历史文件都在此次 v2 增量包内。八个 first24 Raw 包的完整性只覆盖已保存证据：部分瞬时 continuation cache 没有另存完整 tensor；Full6 的 cache tensor 也仅有 live 比较/hash，不能在事后从 raw 值重新计算。

此次 preparation 包保存 v2 输入、来源/接口、静态 gate 验证元数据及脚本；**不含静态 gate 二进制载荷和基础 LLM 权重，也不含未完成 native reference 整合。** 恢复 gate 应依 phase2 acquisition receipt 中的固定官方版本、许可及 SHA-256 校验。文档、代码和归档的恢复不等于运行环境、模型数值或实验结果已经重新复现；本次状态整理没有运行模型或重跑测试。
