"""One frozen question-only edit; tokenization/serialization only, no model."""
from pathlib import Path
import hashlib,json,sys
from tokenizers import Tokenizer
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
SOURCE=ROOT/'research/reconstructed/revision_causal_v2_20261004/refinement_02_delimiter/constructed_variants.json'
T=ROOT/'outputs/revision_cpu_model_assets_20261004/tokenizer.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ids_sha(ids):return hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
need(sha(SOURCE)=='b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7','Original frozen file changed')
need(sha(T)=='aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4','Pinned tokenizer bytes')
row=json.loads(SOURCE.read_text())[0];old=row['canonical_token_ids'];tok=Tokenizer.from_file(str(T))
need(tok.encode(row['canonical_prompt'],add_special_tokens=False).ids==old,'Independent full original tokenization mismatch')
start_id=tok.token_to_id('<|im_start|>');starts=[i for i,x in enumerate(old) if x==start_id]
need(len(starts)>=2,'Message markers')
history_boundary=starts[-2];assistant_start=starts[-1]
history=tok.decode(old[:history_boundary],skip_special_tokens=False)
user=tok.decode(old[history_boundary:assistant_start],skip_special_tokens=False)
assistant=tok.decode(old[assistant_start:],skip_special_tokens=False)
need(assistant=='<|im_start|>assistant\n','Final assistant header')
expected_prefix='<|im_start|>user\nCurrent date: 2023/07/17 (Mon) 02:55\nQuestion: '
end='<|im_end|>\n';need(user.startswith(expected_prefix) and user.endswith(end),'Final dated user-question wrapper')
old_question=user[len(expected_prefix):-len(end)]
need(old_question=='What is my current record in the recreational volleyball league?','Exact prior question')
need(history+user+assistant==row['canonical_prompt'],'Byte-for-byte original reconstruction')
need(history_boundary==row['history_tokens']==row['query_absolute_start'],'Derived boundary differs from metadata')
question='According to the provided conversation history, what is the most recently reported win-loss record of my recreational volleyball team, and on which session date was it reported?'
new_user=expected_prefix+question+end;new_prompt=history+new_user+assistant
new_ids=tok.encode(new_prompt,add_special_tokens=False).ids
history_ids=tok.encode(history,add_special_tokens=False).ids
new_user_ids=tok.encode(new_user,add_special_tokens=False).ids
assistant_ids=tok.encode(assistant,add_special_tokens=False).ids
need(new_ids==history_ids+new_user_ids+assistant_ids,'No cross-boundary token change')
need(history_ids==old[:history_boundary] and new_ids[:history_boundary]==old[:history_boundary],'History ID prefix changed')
prior=ROOT/'outputs/revision_cpu_author_budget_attempt_05'
calls=[json.loads(f.read_text()) for f in sorted((prior/'native_full/calls').glob('*.json'))]
history_calls=[c for c in calls if c['end']<=history_boundary]
need(all(c['phase']=='history' for c in history_calls),'Reference history call phase')
need([i for c in history_calls for i in c['ids']]==history_ids,'Actual prior call history differs')
history_ends=[c['end'] for c in history_calls]
need(history_ends==[e for e in row['online_chunk_end_indices'] if e<=history_boundary],'Original history chunks changed')
new_user_end=history_boundary+len(new_user_ids);new_total=len(new_ids)
query_ends=[];cursor=history_boundary
for boundary in [new_user_end,new_total]:
 while cursor<boundary:
  cursor=min(cursor+128,boundary);query_ends.append(cursor)
chunk_ends=history_ends+query_ends
new=dict(variant_id=row['variant_id']+'__latest_report_and_date_diagnostic',source_variant_id=row['variant_id'],question_id=row['question_id'],
 canonical_prompt=new_prompt,canonical_token_ids=new_ids,canonical_ids_sha256=ids_sha(new_ids),total_input_tokens=new_total,
 history_tokens=history_boundary,query_absolute_start=history_boundary,online_chunk_end_indices=chunk_ends,
 recorded_message_end_indices=[e for e in row['recorded_message_end_indices'] if e<=history_boundary]+[new_user_end],
 online_max_chunk_tokens=128,question=question,current_date_text='2023/07/17 (Mon) 02:55',
 source_history_preserved=True,expected_record='5–2',expected_session_date='2023-06-30',
 scope='One temporal-scope query-sensitivity diagnostic, not replacement or confirmation of the failed pilot')
(P/'diagnostic_input.json').write_text(json.dumps(new,indent=2,ensure_ascii=False)+'\n')
receipt=dict(status='INDEPENDENT_TOKEN_BOUNDARY_AND_QUERY_ONLY_EDIT_VERIFIED',parent_input_sha256=sha(SOURCE),tokenizer_sha256=sha(T),
 original_canonical_ids_sha256=ids_sha(old),diagnostic_input_sha256=sha(P/'diagnostic_input.json'),new_canonical_ids_sha256=ids_sha(new_ids),
 boundary_derivation='Independently retokenize complete original prompt; locate final user/assistant ChatML starts; decode exact wrappers; reconstruct bytes; cross-check actual attempt5 history calls',
 derived_history_boundary=history_boundary,history_prefix_ids_sha256=ids_sha(history_ids),history_prefix_utf8_sha256=hashlib.sha256(history.encode()).hexdigest(),
 system_and_history_bytes_unchanged=True,history_call_count=len(history_calls),history_chunk_ends=history_ends,
 old_question=old_question,new_question=question,query_date_unchanged=True,assistant_header_unchanged=True,
 old_total_tokens=len(old),new_total_tokens=new_total,old_user_message_tokens=assistant_start-history_boundary,
 new_user_message_tokens=len(new_user_ids),assistant_header_tokens=len(assistant_ids),new_query_chunk_ends=query_ends,
 new_query_suffix_ids=new_ids[history_boundary:],retokenized_original_all_ids_exact=True,model_calls=0,torch_imported='torch' in sys.modules)
(P/'boundary_verification.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','derived_history_boundary','history_call_count','old_total_tokens','new_total_tokens','new_user_message_tokens','new_query_chunk_ends','diagnostic_input_sha256','new_canonical_ids_sha256','torch_imported','model_calls']},indent=2))
