"""Own BF16 file pager: synthetic tiny admission only, no pretrained loader.

Native module forward methods are unchanged. One exclusive CPU arena supplies
Linear weights, resident tied embedding/head shares one allocation, and native
norm/RoPE operations are untouched. This does not establish 4B performance.
"""
from pathlib import Path
import hashlib
import json
import math
import os
import struct
import time

REAL_WEIGHT_EXECUTION_RELEASED = False


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_header(path):
    """Validate every range before any tensor payload is read or allocated."""
    path = Path(path)
    size = path.stat().st_size
    with path.open('rb') as f:
        raw = f.read(8)
        require(len(raw) == 8, 'Truncated header length')
        length = struct.unpack('<Q', raw)[0]
        require(2 <= length <= 16 * 1024**2 and 8 + length <= size, 'Header bounds')
        def unique(pairs):
            result = {}
            for key, value in pairs:
                require(key not in result, 'Duplicate JSON key')
                result[key] = value
            return result
        header = json.loads(f.read(length), object_pairs_hook=unique)
    result = {}; ranges = []
    for name, item in header.items():
        if name == '__metadata__':
            continue
        require(item['dtype'] == 'BF16', 'Only exact BF16 source weights')
        shape, offsets = item['shape'], item['data_offsets']
        require(all(type(x) is int and x > 0 for x in shape), 'Invalid shape')
        require(len(offsets) == 2 and all(type(x) is int for x in offsets), 'Invalid offsets')
        lo, hi = offsets
        require(0 <= lo <= hi <= size - 8 - length, 'Tensor outside source file')
        require(hi - lo == math.prod(shape) * 2, 'Tensor byte/shape mismatch')
        result[name] = dict(shape=shape, offset=8 + length + lo, bytes=hi-lo, dtype='BF16')
        ranges.append((lo, hi, name))
    cursor = 0
    for lo, hi, name in sorted(ranges):
        require(lo == cursor, 'Overlapping or gapped tensor ranges: ' + name)
        cursor = hi
    require(cursor == size - 8 - length, 'Trailing unclaimed source payload')
    return result


class FilePager:
    def __init__(self, model, source, *, synthetic, expected_sources=None):
        import torch
        require(__debug__, 'Optimized Python is unsupported')
        if synthetic is not True:
            from cpu_release import require_cpu_release
            require_cpu_release()
            require(sum(p.numel() for p in model.parameters())==4_022_468_096,'Pinned actual parameter count')
            require(expected_sources is not None,'Pinned source receipts required')
        else:
            require(sum(p.numel() for p in model.parameters()) < 100_000,
                    'Tiny admission cap; real weights are not authorized')
        require(not model.training, 'Evaluation mode required')
        require(model.config.tie_word_embeddings, 'Tied source profile required')
        require(model.lm_head.weight is model.model.embed_tokens.weight, 'Native tie missing')
        require(all(p.device.type == 'meta' for p in model.parameters()), 'Meta constructor required')
        self.t = torch; self.model = model
        self.sources = [Path(p) for p in source] if isinstance(source,(list,tuple)) else [Path(source)]
        require(len({p.resolve() for p in self.sources})==len(self.sources), 'Duplicate source shard')
        self.records = {}
        for shard,path in enumerate(self.sources):
            for name,record in read_header(path).items():
                require(name not in self.records, 'Duplicate tensor across shards')
                self.records[name] = dict(record,shard=shard)
        canonical = dict(model.named_parameters())
        require(set(canonical) == set(self.records), 'Exact source parameter coverage required')
        for name, p in canonical.items():
            r = self.records[name]
            require(list(p.shape) == r['shape'] and p.dtype == torch.bfloat16, 'Shape/dtype mismatch: '+name)
        self.source_sha256 = []
        for path in self.sources:
            digest=hashlib.sha256()
            with path.open('rb') as f:
                while block:=f.read(1024**2):digest.update(block)
            self.source_sha256.append(digest.hexdigest())
        if synthetic is not True:
            require(len(expected_sources)==len(self.sources)==3,'Pinned three-shard source')
            for path,digest,spec in zip(self.sources,self.source_sha256,expected_sources):
                require(path.name==spec['path'] and path.stat().st_size==spec['bytes'] and digest==spec['sha256'], 'Pinned source hash/size/name differs')
        self.fds = []
        try:
            for path in self.sources:self.fds.append(os.open(path, os.O_RDONLY))
        except BaseException:
            for fd in self.fds:os.close(fd)
            self.fds=[]
            raise
        self.handles = []; self.active = None; self.installed = False
        self.stats = dict(read_calls=0, read_bytes=0, read_seconds=0., bind_calls=0,
                          max_active_source_bytes=0, resident_source_bytes=0,
                          source_file_bytes=sum(p.stat().st_size for p in self.sources),
                          source_shards=len(self.sources))
        self.meta = {}; self.paged = {}
        try:
            for name, module in model.named_modules():
                if isinstance(module, torch.nn.Linear) and name != 'lm_head':
                    require(module.bias is None, 'Pinned Qwen3 Linear bias must be absent')
                    key = name+'.weight'; self.paged[key] = module; self.meta[key] = module.weight
            require(self.paged, 'No paged leaf weights')
            self.arena = torch.empty(max(self.records[k]['bytes']//2 for k in self.paged), dtype=torch.bfloat16)
            self.stats['arena_bytes'] = self.arena.numel()*2
            resident = {}
            for name, p in canonical.items():
                if name not in self.paged:
                    target = torch.empty(p.shape, dtype=torch.bfloat16)
                    self.read_into(name, target)
                    resident[name] = torch.nn.Parameter(target, requires_grad=False)
                    self.stats['resident_source_bytes'] += target.numel()*2
            for name, parameter in resident.items():
                parent, leaf = name.rsplit('.', 1)
                model.get_submodule(parent)._parameters[leaf] = parameter
            model.lm_head.weight = model.model.embed_tokens.weight
            require(all(x.dtype == torch.float32 and x.device.type == 'cpu'
                        for name,x in model.named_buffers() if 'inv_freq' in name), 'Native RoPE must remain CPU FP32')
        except BaseException:
            for fd in self.fds:os.close(fd)
            self.fds = []
            raise

    def read_into(self, name, target):
        require(target.is_contiguous() and target.device.type == 'cpu', 'Contiguous CPU destination required')
        record = self.records[name]
        require(target.dtype==self.t.bfloat16 and list(target.shape)==record['shape'],'Exact BF16 destination shape required')
        require(target.numel()*target.element_size() == record['bytes'], 'Destination byte mismatch')
        view = memoryview(target.view(self.t.uint8).reshape(-1).numpy())
        cursor = 0; started = time.perf_counter()
        try:
            while cursor < len(view):
                self.stats['read_calls'] += 1
                read = os.preadv(self.fds[record['shard']], [view[cursor:]], record['offset']+cursor)
                require(read > 0, 'Truncated tensor payload during read')
                cursor += read; self.stats['read_bytes'] += read
        finally:
            self.stats['read_seconds'] += time.perf_counter()-started

    def _before(self, key, module, args):
        require(not self.t.is_grad_enabled() and not self.t.is_autocast_enabled('cpu'), 'Inference/no-autocast contract')
        require(self.active is None, 'Reentrant arena use is forbidden')
        require(module.weight is self.meta[key], 'Unexpected parameter replacement')
        view = self.arena[:math.prod(self.records[key]['shape'])].view(self.records[key]['shape'])
        self.read_into(key, view)
        module._parameters['weight'] = self.t.nn.Parameter(view, requires_grad=False)
        self.active = key; self.stats['bind_calls'] += 1
        self.stats['max_active_source_bytes'] = max(self.stats['max_active_source_bytes'], self.records[key]['bytes'])

    def _after(self, key, module, args, output):
        if self.active == key:
            module._parameters['weight'] = self.meta[key]
            self.active = None

    def __enter__(self):
        require(not self.installed and self.fds, 'Pager lifecycle')
        try:
            for key,module in self.paged.items():
                self.handles.append(module.register_forward_pre_hook(lambda m,a,k=key:self._before(k,m,a)))
                self.handles.append(module.register_forward_hook(lambda m,a,o,k=key:self._after(k,m,a,o), always_call=True))
        except BaseException:
            self.close()
            raise
        self.installed = True
        return self

    def assert_idle(self):
        require(self.active is None, 'Arena is still leased')
        require(all(m.weight is self.meta[k] for k,m in self.paged.items()), 'Leaf did not restore exact meta Parameter')
        require(self.model.lm_head.weight is self.model.model.embed_tokens.weight, 'Tied identity changed')

    def close(self):
        for handle in self.handles:
            handle.remove()
        self.handles = []
        for key,module in self.paged.items():
            module._parameters['weight'] = self.meta[key]
        self.active = None; self.installed = False
        for fd in self.fds:os.close(fd)
        self.fds = []
        self.arena = None

    def __exit__(self, *unused):
        self.close()
