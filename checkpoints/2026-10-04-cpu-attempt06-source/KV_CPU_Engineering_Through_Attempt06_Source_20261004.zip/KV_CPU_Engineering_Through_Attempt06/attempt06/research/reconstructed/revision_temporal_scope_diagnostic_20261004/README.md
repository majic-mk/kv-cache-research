# One temporal-scope diagnostic: preparation only

This separate one-question diagnostic follows the completed native Full semantic failure. It cannot reopen the existing compressed/GPU pilot. The old 64-token and natural-EOS failures remain unchanged.

The only model-input change is the final question:

> According to the provided conversation history, what is the most recently reported win-loss record of my recreational volleyball team, and on which session date was it reported?

Independent tokenization and byte reconstruction establish the history boundary at 7,624 IDs. All 80 history calls are unchanged and each must match the attempt-5 original BF16 logit bytes and all per-layer KV append hashes. The new input contains 7,689 tokens in 82 chunks; the dated user query ends at 7,686, followed by the unchanged three-token assistant header. No equality constraint applies after the changed query begins.

Model weights, system text, native BF16 math, pager, process-local boundary trimming, author greedy stopping, and the independent watchdog remain unchanged. The author contract permits at most 800 selections, checks EOS 151645 or final index 799 before emission/feed, and therefore emits/feeds at most 799 tokens. Terminal selections and original full-vocabulary vectors are preserved. Maximum work is 881 calls and 8,488 ingested tokens.

The new scope has a fresh 3,600-second phase plus 180 seconds cleanup, 6 GiB process-tree RSS, 6 GB starting host availability, 1.5 GB running host availability, 5 GB disk floor, and 384 MB evidence cap. The conservative evidence bound is 373,986,816 bytes. Timing forecasts are advisory. A hard stop preserves partial evidence without another attempt.

The pre-output rubric requires a complete supported latest reported record of 5–2 and the June 30, 2023 session date, with natural EOS and no contradiction or unsupported abstention. Equivalent wording/date notation is allowed. A clearly distinguished historical 3–2 on June 16 is allowed. Review the complete answer, not a score substring. Failure closes this route without another prompt/model/cap variant. Success establishes query sensitivity on this history only and requires a fresh independent study before scientific claims. No-crop, compression, or GPU remain closed in every branch.

`preparation_checks.json` records model-free checks: all 80 prior raw vectors, history IDs and boundaries, raw-byte/KV/position mismatch rejection, author EOS/exhaustion fixtures, exact asset paths/inodes/hashes and all 398 tensor mappings. No Torch import or model calls occurred. `source_diff.patch` is relative to the previously audited author-budget calibration. The guard, pager, release module, and decode helper are byte-identical.

Await independent review, durable backup, and explicit parent GO. The source is runnable but has not been launched. Its exclusive claim file allows only one attempt in this directory. A future authorized command from the repository root is:

```bash
bash research/reconstructed/runtime_recovery_20261004/cpu_python.sh research/reconstructed/revision_temporal_scope_diagnostic_20261004/actual_guard.py --out outputs/revision_temporal_scope_diagnostic_attempt_06 --base outputs/revision_cpu_model_assets_20261004 --acquisition-receipt outputs/revision_cpu_model_assets_20261004/acquisition_start.json
```

The old acquisition clock is retained only as immutable asset provenance. This future separately authorized window does not extend any earlier expired window. Do not run the command before GO.
