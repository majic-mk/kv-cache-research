# Reassessment after the completed native Full failure

Date: 2026-10-04 UTC. Independent read-only design/prior-art review; no inference, server action, installation, or code change. This report is the only written artifact.

## Recommendation

**Stop the existing 16-input compressed/GPU pilot under its frozen gate. If one final cheap diagnostic is wanted, preregister exactly one query-only temporal-scope test on this same failed history, using the same Qwen3-4B checkpoint and CPU path. Do not start another model ladder.**

That diagnostic asks whether the long-history answer changes when the task explicitly requests the latest *reported* state and its report date. It is development evidence, not a replacement result or an automatic release to GPU. If it fails, close this backbone/prompt route. If it succeeds, the original packet still failed; a subsequent research proposal would need a new prospective protocol and independent evidence, not a relabeling of these sixteen prompts.

## What the observation establishes

`outputs/revision_cpu_author_budget_attempt_05/native_full/result.json` records 243 model calls, natural EOS on selection 162, 161 emitted/fed tokens, no cap hit, and 1295.36 seconds for the result's measured phase. The answer refuses to provide the current record, mentions 5–2, and attributes that record to June 16. The frozen source instead has 3–2 on June 16 and 5–2 on June 30; July 17 is the query date. The first tested condition is **low_zero**, with no added obsolete-value repetitions.

This is a completed semantic failure of this exact native Full/input/task setup. It is not merely a 64-token censoring problem, not an observed compression failure, and not evidence that this model is generally incompetent. It also is **not the proposed primary stale-current event**: the output does not incorrectly present the designated old value, 3–2, as current. Record abstention/unsupported temporal attribution separately. Mentioning 5–2 does not make the whole answer correct or establish reliable fact/date binding.

The source-bound replay checks and tiny/native operator evidence support the implemented path, but do not certify GPU parity or the still-unrun gate-loaded no-crop path. No compressed result exists, so the online-versus-deferred hypothesis remains untested.

## The gate is conservative, not an identification theorem

The earlier design review made Full-correct conditioning secondary and retained all source families in the primary denominator. The later readiness review added **all sixteen Full answers correct and normally completed** as a deliberately conservative operational admission gate. The first failure blocks that particular release, even if the remaining fifteen are unknown.

For a future study, universal Full correctness is not mathematically necessary to measure paired policy-induced corrections and losses or a relevant-copy-by-regime contrast. Because Full uses the same schedule in both regimes, its terms cancel from the final online-minus-deferred interaction. Full remains essential for attributing individual transitions and detecting ordinary interference. It is not an accuracy ceiling: eviction can also improve an answer. Selecting only Full-correct families would change the target population and suppress those corrections.

None of that permits relaxing this frozen gate after seeing the failure. Nor should the failure be called a falsification of the causal hypothesis. The truthful disposition is **operational admission failed; scientific effect not observed**.

## Bespoke prompts: strong controls with a real validity cost

The owner-only, equal-token relevant/irrelevant pairs are useful controls. Source preservation, fixed selection, unchanged within-family query positions, and complete history also matter. However, sixteen renderings are only two independent source families.

The injected archive-owner rules, neutral layout conversations, and role-separated dated sessions impose extra source/temporal-scope interpretation demands. The latest-known benchmark convention is not identical to an unconstrained question about the world's current state. The model's date error prevents reducing this result to prudent uncertainty alone, but its explicit refusal makes a task-scope diagnostic more informative than changing model size.

Matched neutral text is not guaranteed to be behaviorally neutral. Eviction of the common prefix can remove the instructions needed to interpret owner labels. Volleyball's current-value span is thousands of tokens outside a 1,024-token recency cache; the 5K's late tail cue is partly coreferential. These probes can yield a case-level interaction, but cannot alone establish a general revision-specific serving failure or a clean age mechanism.

## Prior art narrows the remaining claim further

- **TRIM-KV already studies sequential chunked-prefill eviction**, not only offline selection. Appendix B.3 uses Phi-3-mini-128K, chunks of 3,072 and budget 6,000 on LongBench/LongBench-v2; it also discusses Full differences associated with chat templates. The inspected LongMemEval runner's one-history-block schedule is a limitation of that route, not proof that TRIM lacks online experiments. [Primary paper](https://arxiv.org/html/2512.03324v2), Appendix B.3; saved `revision_sensitive_kv_sources_20261004/trimkv_paper.txt`
- **Positions Are Not Facts** already covers changed-fact interventions, online update masks, prompt/abstention sensitivity, and query-aware comparisons. Its logical masks do not establish capacity-driven physical eviction. A prompt rescue or another semantic-error taxonomy would not independently differentiate this project. [Primary paper](https://arxiv.org/html/2609.33759v1), §§2, 6, A.4, C.1.3, D.6
- **Round Attention** is a recoverable/offloaded comparison, with host backing and transfers; treating it as an equal-total-memory irreversible policy is invalid. [Primary paper](https://arxiv.org/html/2502.15294v3), §§3–4; saved source and baseline contracts

The remaining prospective claim is narrow: **does relevant obsolete repetition interact with controlled placement and physically irreversible budget pressure differently from deferred selection, beyond matched Full/irrelevant/neutral outcomes?** No current evidence establishes that interaction or its novelty/value at study scale.

## Exactly one defensible optional diagnostic

Freeze a separate protocol before any new forward:

1. Reuse the failed `c7dc5443__reservoir_before__low_zero` history prefix exactly through token 7,624, its source dates, all message/chunk boundaries before the query, model revision, BF16 CPU/native path, and the independently specified 800-selection author stop rule. Change only the final question wording; preserve the stated query date. Record new suffix IDs/length and final chunk boundaries. Do not truncate, reformat the whole history, change the system prompt, remove neutral material, or insert answer values.
2. Ask: **“According to the provided conversation history, what is the most recently reported win-loss record of my recreational volleyball team, and on which session date was it reported?”** Do not add examples or mention the desired record/date.
3. Require a complete supported answer with 5–2 and June 30, 2023, allowing an explicitly qualified prior 3–2/June 16 statement. Preserve every output and stop receipt; keep the existing actual resource guard and finite execution window. A resource stop is censored, not a semantic failure and not permission to extend it.
4. If it still abstains, misdates, contradicts the source, or fails normal completion within its declared limit, stop this route without another prompt/model/cap attempt. If correct, conclude only that this query reformulation changes the answer on this history. It does not isolate a unique internal cause, validate the other fifteen conditions, rescue the original gate, or demonstrate a compression effect.

This is a proposed diagnostic, **not authorization or a completed experiment**. Its scientific role is deciding whether a latest-reported-state task is worth a new proposal. Both families become development material if their prompts are redesigned using this feedback; later confirmatory claims need independently fixed families and must retain failures.

## Calibration versus rescue, and practical feasibility

The prior 64→800 calibration was defensible because it addressed a verified author-contract mismatch while preserving the failed run and all non-generation variables. Natural EOS now removes that specific explanation for the complete failure. Another cap increase, easier replacement case, hidden answer extraction, accepting the refusal because it contains 5–2, or a larger model would not be the same calibration.

A future causal study should preserve unconditional paired outcomes, distinguish stale/other/abstention/completion errors, and report full-correct losses as a secondary view. Static TRIM plus recency/random is a credible small pilot, not a general strong-policy ranking; DBTRIM and the certified attention-selector route remain relevant before broad claims. Deferred selection pays Full-history peak storage and cannot be presented as equal-memory online serving.

At these ~8K contexts, the repository's lower bound of roughly 8.73 GiB for base weights, gate and longest-input KV is compatible with a plausible single-32-GiB-5090 plan, but it is not measured device fit or a price/runtime estimate. GPU availability is presently not the scientific blocker. Another expensive run should follow an informative CPU diagnosis and a defensible claim, not substitute for them. No publication guarantee is warranted.
