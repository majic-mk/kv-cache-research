# Attempt6: closed single-query diagnostic

The complete answer correctly reports 5–2 and the session date June 30, 2023, 08:14. Independent whole-answer and saved-evidence audits pass. The model reached natural EOS after 50 selections, with 49 emitted/fed tokens and 131 model calls. Resource and cleanup guards passed.

This is evidence of sensitivity to the complete reformulated query on one fixed history. The new question also requests the report date, so the result does not isolate a unique temporal-scope mechanism. It does not establish cache-compression efficacy, validate the other fifteen prompts, or reopen the original compressed/GPU packet. That packet remains failed and closed. The prior 64-token failure and author-budget complete-answer failure remain preserved in the linked archives.

The predeclared success branch closes this diagnostic. Any future study needs separately frozen endpoints and resource schedules, input-only cohort selection without model-outcome filtering, held-out independent source families, and separate execution authorization. No additional inference is authorized by this archive.

## Contents and exact coverage

All 586 original runner/guard files are retained byte-for-byte: 38,006,222 bytes. These include 131 original BF16 logit vectors, 50 selection records, all call/trim/forecast/resource/guard files and 4,716 layer append descriptors. Every vector was decompressed and SHA-256 checked, totaling 39,807,232 bytes. The first80 unchanged-history vectors and K/V descriptors match attempt5 exactly. Raw K/V tensors were not persisted; their descriptors contain shapes, dtypes, byte counts and hashes.

The frozen diagnostic source, final input, complete query diff, protocol and decision branches, exclusive attempt claim, terminal reviews, owner outcome/status, reassessment and exact dependency index are included. No failed scientific or engineering outcome has been removed from the prior archives. The original pre-run payload is retained: PRE_RUN_PACKAGE_MANIFEST.json is its original manifest, renamed only to make room for the terminal MANIFEST.json. Its entries still hash to the original bytes. PRE_RUN_STATUS.json and README_REPRODUCIBILITY.md are historical preparation records; this terminal document and CURRENT_TERMINAL_STATUS.json state the latest result. Original producer metadata marked pending at write time is retained unchanged; the independent terminal review and FINAL_STATUS.json provide its final disposition.

The reassessment preserves the novelty correction: TRIM-KV Appendix B.3 already studies sequential chunked-prefill eviction. A specific LongMemEval runner schedule cannot be generalized to an offline-only prior-work claim.

## Restoration

1. Download this complete per-run archive and the exact artifacts in TERMINAL_DEPENDENCIES.json. Verify each downloaded ZIP size and SHA-256 before extraction. A Library identity can have later versions, so retrieve the pinned version rather than accepting a mismatching current download.
2. Extract into a fresh directory, rejecting absolute paths, parent traversal and duplicate names. Verify every file against MANIFEST.json. The original producer raw inventory is in research/reconstructed/revision_temporal_scope_diagnostic_results_20261004/OUTCOME.json; RAW_ATTEMPT_06_MANIFEST.json repeats the exact archived paths. RAW_VECTOR_READBACK.json documents decompressed vector hashes and the80 reference comparisons.
3. Restore the cumulative CPU v9 source/runtime/acquisition snapshot, then the complete attempt5 raw dependency and this attempt6 payload into a fresh research checkout using their repository-relative research/ and outputs/ paths. For a duplicate, require byte equality before reuse; never overwrite a differing historical file silently. Package-level status/manifests remain alongside their own archive roots.
4. Model weights, environments and download symlinks are intentionally excluded. Pinned official model revisions, byte hashes and prior acquisition/runtime receipts are in the cumulative dependency and this run's base_verified.json/runtime.json. Restoring evidence needs no model download. Executing any future study requires separate approval and reviewed path configuration; this archive is not an automatic rerun instruction.

The pre-run Library item and CPU v9 checkpoint remain unchanged. This archive is complete for attempt6 raw evidence, while prior reference evidence and full runtime provenance have explicit external dependencies. No claim of fully self-contained model reproduction is made.
