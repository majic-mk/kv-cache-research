#!/usr/bin/env python3
"""Bounded stdlib-only acquisition of the exact official plain-Qwen3 checkpoint.
No torch import, model loading, model code execution, authentication, or installs.
"""
import datetime, hashlib, json, math, os, pathlib, resource, shutil, signal, struct, subprocess, sys, time, urllib.parse, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
LOCK=ROOT/'research/reconstructed/revision_gpu_deployment_20261004/model_downloads.json'
PROTOCOL=ROOT/'research/reconstructed/revision_cpu_feasibility_20261004/prospective_cpu_protocol.json'
HEADERS=PROTOCOL.parent
FLOOR=5_000_000_000
RSS_CAP=1_073_741_824
BUFFER=1024*1024
PIN='cdbee75f17c01a7cc42f958dc650907174af0554'

def check(ok,message):
    if not ok: raise RuntimeError(message)

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def dump(path,value):
    path=pathlib.Path(path);tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value,indent=2)+'\n');os.replace(tmp,path)

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while b:=f.read(BUFFER): h.update(b)
    return h.hexdigest()

def official(url):
    u=urllib.parse.urlsplit(url)
    return u.scheme=='https' and not u.username and not u.password and u.port in (None,443) and (u.hostname=='huggingface.co' or u.hostname.endswith('.huggingface.co') or u.hostname.endswith('.hf.co'))

class OfficialRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        check(official(newurl),'Nonofficial or non-TLS redirect rejected')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def budget(start):
    check(time.monotonic()<start['acquisition_deadline_monotonic'],'Acquisition/verification 1200-second deadline reached')
    check(time.monotonic()+1980<start['overall_deadline_monotonic'],'Cannot reserve 1800-second model phase and 180-second finalization')
    check(shutil.disk_usage(OUT).free>=FLOOR,'5 GB disk reserve reached')

def digest_file(path,spec,start):
    check(path.stat().st_size==spec['bytes'],'File size mismatch: '+path.name)
    h=hashlib.sha256();g=hashlib.sha1(f"blob {spec['bytes']}\0".encode())
    with path.open('rb') as f:
        while b:=f.read(BUFFER): budget(start);h.update(b);g.update(b)
    check(h.hexdigest()==spec['sha256'] if spec.get('sha256') else g.hexdigest()==spec['git_blob_sha1'],'File identity mismatch: '+path.name)
    return {'path':path.name,'bytes':path.stat().st_size,'sha256':h.hexdigest(),'git_blob_sha1_computed':g.hexdigest(),'identity_basis':'sha256' if spec.get('sha256') else 'git_blob_sha1'}

def download(spec,start):
    budget(start);p=OUT/spec['path'];part=p.with_name(p.name+'.part')
    check(not p.exists() and not part.exists(),'Existing asset/partial is never overwritten')
    check(shutil.disk_usage(OUT).free-spec['bytes']>=FLOOR,'Insufficient free disk for complete pinned artifact')
    expected=f"https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507/resolve/{PIN}/{spec['path']}"
    check(spec['url']==expected,'Unpinned URL in download lock')
    rec={'status':'STARTED','path':str(p),'source_url':expected,'expected_bytes':spec['bytes'],'started_utc':utc(),'started_monotonic':time.monotonic(),'attempt':1,'bytes_transferred':0}
    receipt=OUT/'receipts'/(p.name+'.attempt_01.json');dump(receipt,rec)
    count=0;h=hashlib.sha256();g=hashlib.sha1(f"blob {spec['bytes']}\0".encode())
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),OfficialRedirects())
    try:
        req=urllib.request.Request(expected,headers={'User-Agent':'pinned-cpu-checkpoint-acquisition','Accept-Encoding':'identity'})
        with opener.open(req,timeout=30) as response,part.open('xb') as f:
            check(official(response.url),'Unexpected final origin')
            rec['final_origin']=urllib.parse.urlsplit(response.url).scheme+'://'+urllib.parse.urlsplit(response.url).netloc
            rec['http_status']=response.status
            rec['content_length']=response.headers.get('Content-Length')
            check(response.status==200,'Full download did not return HTTP 200')
            if rec['content_length'] is not None: check(int(rec['content_length'])==spec['bytes'],'HTTP Content-Length differs from pin')
            while True:
                budget(start);b=response.read(min(BUFFER,spec['bytes']-count+1))
                if not b:break
                count+=len(b);check(count<=spec['bytes'],'Server exceeded pinned byte size')
                check(shutil.disk_usage(OUT).free-len(b)>=FLOOR,'5 GB disk reserve would be violated')
                f.write(b);h.update(b);g.update(b)
                if count//(64*BUFFER)!=(count-len(b))//(64*BUFFER):
                    rec.update(bytes_transferred=count,elapsed_seconds=time.monotonic()-rec['started_monotonic']);dump(receipt,rec)
            f.flush();os.fsync(f.fileno())
        check(count==spec['bytes'],'Truncated official artifact')
        check(h.hexdigest()==spec['sha256'] if spec.get('sha256') else g.hexdigest()==spec['git_blob_sha1'],'Official artifact identity mismatch')
        check(not p.exists(),'Destination appeared during acquisition')
        part.rename(p)
        rec.update(status='VERIFIED_ATOMICALLY_PUBLISHED',sha256=h.hexdigest(),git_blob_sha1_computed=g.hexdigest())
        print(json.dumps({'download_verified':p.name,'bytes':count,'elapsed_seconds':time.monotonic()-rec['started_monotonic']}),flush=True)
    except BaseException as exc:
        rec.update(status='STOPPED_PARTIAL_PRESERVED',error=type(exc).__name__+': '+str(exc));raise
    finally:
        rec.update(bytes_transferred=count,ended_utc=utc(),elapsed_seconds=time.monotonic()-rec['started_monotonic']);dump(receipt,rec)
    return rec

def verify_headers(specs,start):
    official_receipt=json.loads((HEADERS/'official_header_receipt.json').read_text())
    expected={s['name']:s for s in official_receipt['shards']}
    index=json.loads((OUT/'model.safetensors.index.json').read_text())
    mapping={};records=[];parameters=payload=0
    for spec in specs:
        if not spec['path'].endswith('.safetensors'):continue
        budget(start);p=OUT/spec['path'];known=expected[p.name]
        with p.open('rb') as f:
            raw8=f.read(8);check(len(raw8)==8,'Missing header length');length=struct.unpack('<Q',raw8)[0]
            check(length==known['header_bytes'] and length<1_000_000,'Unexpected header byte length')
            raw=f.read(length)
        check(hashlib.sha256(raw).hexdigest()==known['header_sha256'],'Header byte hash differs from official range receipt')
        header=json.loads(raw);saved=json.loads((HEADERS/(p.name+'.header.json')).read_text())
        check(header==saved,'Header metadata differs from frozen official header')
        cursor=0;n=0;params=0;bytecount=0
        for key,meta in sorted(((k,v) for k,v in header.items() if k!='__metadata__'),key=lambda kv:kv[1]['data_offsets'][0]):
            check(key not in mapping,'Duplicate tensor across shard headers')
            check(meta['dtype']=='BF16','Non-BF16 tensor in official header')
            a,b=meta['data_offsets'];numel=math.prod(meta['shape'])
            check(a==cursor and b-a==numel*2 and b>a,'Tensor shape/offset/continuity mismatch')
            mapping[key]=p.name;cursor=b;n+=1;params+=numel;bytecount+=b-a
        check(8+length+cursor==spec['bytes'],'Shard header/payload extent does not equal pinned file size')
        check(n==known['tensor_count'] and params==known['parameters'] and bytecount==known['payload_bytes'],'Header counts differ from prior official receipt')
        parameters+=params;payload+=bytecount
        records.append({'path':p.name,'header_bytes':length,'header_sha256':known['header_sha256'],'tensor_count':n,'parameters':params,'payload_bytes':bytecount})
    check(mapping==index['weight_map'],'Official index key-to-shard mapping differs from actual headers')
    check(parameters==4_022_468_096 and len(mapping)==398,'Unexpected total parameter or tensor count')
    return {'status':'PASS','shards':records,'tensor_count':len(mapping),'parameters':parameters,'actual_payload_bytes':payload,'index_total_size_preserved':index['metadata']['total_size'],'index_minus_actual_payload_bytes':index['metadata']['total_size']-payload,'exact_index_key_mapping':True,'no_tensor_loaded':True}

def worker():
    resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
    start=json.loads((OUT/'acquisition_start.json').read_text());budget(start)
    lock=json.loads(LOCK.read_text());protocol=json.loads(PROTOCOL.read_text())
    check(lock['base_repo']=='Qwen/Qwen3-4B-Instruct-2507' and lock['base_revision']==PIN,'Wrong model/revision lock')
    check(protocol['model']['revision']==PIN,'Protocol revision mismatch')
    check(sum(s['bytes'] for s in lock['base'])==8_060_896_487,'Unexpected base download size')
    check([{k:s[k] for k in ('path','bytes','sha256','git_blob_sha1')} for s in lock['base']]==protocol['model']['files'],'Protocol and download lock files differ')
    specs=sorted(lock['base'],key=lambda s:(s['path'].endswith('.safetensors'),s['path']))
    check(shutil.disk_usage(OUT).free-sum(s['bytes'] for s in specs)>=FLOOR,'Not enough disk for complete assets and reserve')
    downloads=[]
    for spec in specs:downloads.append(download(spec,start))
    header=verify_headers(specs,start);dump(OUT/'verified_headers_and_index.json',header)
    verification=[digest_file(OUT/s['path'],s,start) for s in specs]
    result={'status':'ALL_PINNED_ASSETS_VERIFIED_NO_MODEL_LOAD','base_repo':lock['base_repo'],'base_revision':PIN,'base_directory':str(OUT),'started_utc':start['started_utc'],'completed_utc':utc(),'elapsed_acquisition_verification_seconds':time.monotonic()-start['started_monotonic'],'download_bytes':sum(r['bytes_transferred'] for r in downloads),'expected_complete_base_bytes':lock['base_total_bytes'],'files':verification,'headers_and_index':header,'free_disk_bytes_final':shutil.disk_usage(OUT).free,'torch_imported':False,'model_loaded':False,'inference_run':False,'overall_deadline_utc':start['overall_deadline_utc'],'overall_deadline_monotonic':start['overall_deadline_monotonic'],'lock_sha256':sha(LOCK),'protocol_sha256':sha(PROTOCOL),'downloader_sha256':sha(__file__)}
    dump(OUT/'acquisition_complete.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('files','headers_and_index')}),flush=True)

def rss(pid):
    try:return int(pathlib.Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    except (FileNotFoundError,ProcessLookupError):return 0

def main():
    if '--worker' in sys.argv:
        try:worker()
        except BaseException as exc:
            dump(OUT/'acquisition_failure.json',{'status':'STOPPED_PRESERVE_ALL_ATTEMPTS','error':type(exc).__name__+': '+str(exc),'utc':utc(),'free_disk_bytes':shutil.disk_usage(OUT).free,'model_loaded':False});raise
        return
    check(not (OUT/'acquisition_start.json').exists(),'Existing acquisition never reset or blindly repeated')
    (OUT/'receipts').mkdir()
    now=time.time();mono=time.monotonic();free=shutil.disk_usage(OUT).free
    check(free-8_060_896_487>=FLOOR,'Insufficient initial disk reserve')
    start={'started_utc':datetime.datetime.fromtimestamp(now,datetime.timezone.utc).isoformat(),'started_unix':now,'started_monotonic':mono,'acquisition_deadline_monotonic':mono+1200,'overall_deadline_monotonic':mono+3600,'overall_deadline_unix':now+3600,'overall_deadline_utc':datetime.datetime.fromtimestamp(now+3600,datetime.timezone.utc).isoformat(),'maximum_acquisition_verification_seconds':1200,'maximum_model_phase_seconds':1800,'finalization_reserve_seconds':180,'initial_free_disk_bytes':free,'minimum_disk_free_bytes':FLOOR,'maximum_acquisition_process_tree_RSS_bytes':RSS_CAP,'source_model': 'Qwen/Qwen3-4B-Instruct-2507','revision':PIN,'no_inference_authorized_by_this_script':True}
    dump(OUT/'acquisition_start.json',start);print(json.dumps(start),flush=True)
    peak=0;minfree=free;stop=None
    with (OUT/'acquisition_worker.log').open('x') as log:
        proc=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).resolve()),'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while proc.poll() is None:
            use=rss(proc.pid)+rss(os.getpid());peak=max(peak,use);free=shutil.disk_usage(OUT).free;minfree=min(minfree,free)
            if use>=RSS_CAP:stop='ACQUISITION_RSS_LIMIT'
            if free<FLOOR:stop='DISK_FLOOR'
            if time.monotonic()>=mono+1200:stop='ACQUISITION_1200_SECOND_DEADLINE'
            if stop:
                os.killpg(proc.pid,signal.SIGTERM)
                try:proc.wait(timeout=3)
                except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                break
            time.sleep(.1)
    rec={'returncode':proc.wait(),'stop_reason':stop,'peak_acquisition_process_tree_RSS_bytes':peak,'minimum_observed_free_disk_bytes':minfree,'final_free_disk_bytes':shutil.disk_usage(OUT).free,'elapsed_seconds':time.monotonic()-mono,'ended_utc':utc(),'maximum_RSS_bytes':RSS_CAP,'acquisition_deadline_monotonic':mono+1200,'overall_deadline_monotonic':mono+3600,'all_failed_attempts_preserved':True}
    dump(OUT/'acquisition_guard.json',rec);print(json.dumps(rec),flush=True);sys.exit(rec['returncode'])

if __name__=='__main__':main()
