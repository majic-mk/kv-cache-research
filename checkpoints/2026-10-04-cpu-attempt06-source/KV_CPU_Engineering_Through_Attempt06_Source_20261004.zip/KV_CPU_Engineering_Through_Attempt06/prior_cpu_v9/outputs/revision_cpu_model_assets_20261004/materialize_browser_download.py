"""Verify supported browser-download paths with streaming hashes, then symlink atomically."""
from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,sys,time
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
LOCK=ROOT/'research/reconstructed/revision_gpu_deployment_20261004/model_downloads.json'
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))

def main():
    name,source=sys.argv[1:];src=Path(source);dst=OUT/name
    start=json.loads((OUT/'acquisition_start.json').read_text())
    assert time.monotonic()<start['acquisition_deadline_monotonic'],'Original acquisition deadline reached'
    lock=json.loads(LOCK.read_text());spec=next(x for x in lock['base'] if x['path']==name)
    assert source.startswith('/opt/codex/downloads/') and src.is_file(),'Not a supported browser output path'
    assert src.stat().st_size==spec['bytes'],'Browser download size mismatch'
    assert shutil.disk_usage(src).free>=5_000_000_000 and shutil.disk_usage(OUT).free>=5_000_000_000,'Disk floor'
    assert not dst.exists() and not dst.is_symlink(),'Never replace completed file'
    begin=time.monotonic();h=hashlib.sha256();g=hashlib.sha1(f"blob {spec['bytes']}\0".encode());count=0
    with src.open('rb') as f:
        stat0=os.fstat(f.fileno())
        while b:=f.read(1024*1024):
            assert time.monotonic()<start['acquisition_deadline_monotonic'],'Original acquisition deadline reached'
            assert shutil.disk_usage(OUT).free>=5_000_000_000,'Disk floor'
            count+=len(b);h.update(b);g.update(b)
        stat1=os.fstat(f.fileno())
    assert (stat0.st_ino,stat0.st_size,stat0.st_mtime_ns)==(stat1.st_ino,stat1.st_size,stat1.st_mtime_ns),'Source changed while hashing'
    assert count==spec['bytes']
    assert h.hexdigest()==spec['sha256'] if spec.get('sha256') else g.hexdigest()==spec['git_blob_sha1'],'Pinned identity mismatch'
    part=OUT/(name+'.part');assert not part.exists() and not part.is_symlink();part.symlink_to(src);part.rename(dst)
    rec={'status':'VERIFIED_SYMLINK_ATOMICALLY_PUBLISHED','route':'supported_cloud_browser_download_path','name':name,'source_url':spec['url']+'?download=true','browser_download_path':source,'workspace_path':str(dst),'size':count,'sha256':h.hexdigest(),'git_blob_sha1_computed':g.hexdigest(),'source_inode':stat1.st_ino,'source_device':stat1.st_dev,'source_mtime_ns':stat1.st_mtime_ns,'stream_hash_seconds':time.monotonic()-begin,'samefile_no_payload_copy':os.path.samefile(src,dst),'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_disk_bytes':shutil.disk_usage(OUT).free,'max_verifier_RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'browser_backend_RSS_watchdog_enforced':False}
    receipt=OUT/'receipts'/(name+'.browser_materialization.json');assert not receipt.exists();receipt.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
if __name__=='__main__':main()
