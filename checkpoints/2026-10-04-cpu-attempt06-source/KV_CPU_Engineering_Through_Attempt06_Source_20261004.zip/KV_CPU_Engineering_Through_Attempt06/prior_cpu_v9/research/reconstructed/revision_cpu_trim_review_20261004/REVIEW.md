# Independent review: one real CPU Full-only trim validation

PASS for the narrowly scoped prepared attempt, conditional on additive durable backup and explicit parent GO. No pretrained inference, weight download, or runtime/source change was performed by this review.

Source manifest: 1748cf4371e03f8bdc4a690632ac9c55628a58b8eb3bc4a5e2fe162c447ab2d0
Protocol: 55a55cc86d0c278816d01449e30ce75667766125d69400a018b593fd432d12ab
Candidate: research/reconstructed/revision_cpu_trim_validation_20261004
Reviewer: /root/assess_next_cpu_model_gate

## Exact scope

The same pinned plain Qwen3-4B-Instruct-2507 checkpoint, first frozen 7,669-token input, 82 original chunks, native BF16 operators / FP32 internal operations, 145-call maximum, greedy 64-token cap and EOS 151645 are retained. The base pager is byte-identical. The only allocator intervention is process-local libc.malloc_trim(0) after each completed native call, saved numerical/reference evidence and pager-idle verification. No per-chunk GC, alternative attention backend, dtype conversion, cache eviction, prompt modification or other model is added. The trim return, current RSS/host reserve, and elapsed time are logged; whole-call global cost includes the trim/evidence path.

The prior 17:28:20 execution window stays closed. The new guard creates a fresh exclusive claim and launch receipt with an 1800-second model deadline on both wall and monotonic clocks, plus 180 seconds cleanup reserve. Historical acquisition timestamps are retained only as asset provenance; the inherited historical deadline-rule text is not the new operational deadline. The runner independently binds the new launch deadline. Memory/disk/evidence limits remain 6 GiB sampled process-tree RSS, 6 GB start / 1.5 GB live MemAvailable, 5 GB free disk, 256 MB evidence. Cleanup still kills/waits the owned process group on limit/exception. The watchdog is sampled and is not an OS hard RSS limit; a trim boundary cannot preempt an in-call transient.

## Bound numerical checks

The completed model-free native-operator control/trim pair has 392 identical full-output receipts per arm over 1,171,387,264 bytes, with finite outputs, identical probe/guard sources and passing guard receipts. Its measured sampled peak RSS reduction supports a candidate engineering intervention, but the single synthetic layer/constant operands omit real paging, 36-layer lifetimes, norms/RoPE/residuals and full-model behavior. Synthetic GC/full-output checks were equal across its arms; this real attempt adds no GC.

All 39 prior actual attempt-3 call JSONs, compressed vocabulary vectors, decompressed byte lengths/hashes, prior binding and terminal receipt are pinned. I independently loaded and checked all 39 references without importing Torch. The comparator accepts identical raw bytes and rejects changed raw bytes, K/V hash or original position. On each real prefix call it requires exact IDs/positions/phase/mask, direct original-BF16 logit-byte equality and complete appended K/V metadata/hash equality. A mismatch is recorded before rejection. No raw K/V byte comparator is claimed because prior evidence stores K/V hashes rather than raw K/V. All 39 must pass before a completed result can be recorded.

Local asset targets/inodes/devices/mtimes/sizes were independently rechecked. The owner’s preparation receipt also records full official-file hashes and exact index/header coverage without Torch. All source-manifest hashes and Python syntax validate; the scientific/native protocol sections match the prior reviewed implementation. No additional generic gate is required for this delta.

## Interpretation

The three prior failures remain preserved failures, with zero generated answers. A successful first 39 comparison would establish only unchanged real native-prefix output under this memory intervention. It is not no-crop parity or eviction evidence. A completed Full answer remains semantically unjudged until independent review of its complete source and answer, and wrong, unsupported, incomplete or cap-hit output cannot establish competence. No automatic retry, no-crop arm, remaining 15 inputs or GPU is authorized by this packet.

Machine-readable checks and review conditions: review_receipt.json
