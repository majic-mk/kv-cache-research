"""One synthetic native-operator attribution probe; no model/config/checkpoint."""
from pathlib import Path
import ctypes,gc,hashlib,json,os,resource,signal,time
P=Path(__file__).resolve().parent
protocol=json.loads((P/'protocol.json').read_text())
if os.getppid()!=int(os.environ['PROBE_GUARD_PID']):raise RuntimeError('Guard parent required')
signal.alarm(55)
import torch
from torch.nn import functional as F
if torch.__version__!='2.9.1+cpu' or torch.version.cuda is not None:raise RuntimeError('Pinned CPU runtime')
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.set_grad_enabled(False)
torch.use_deterministic_algorithms(True)
class MI(ctypes.Structure):
    _fields_=[(n,ctypes.c_size_t) for n in ('arena','ordblks','smblks','hblks','hblkhd','usmblks','fsmblks','uordblks','fordblks','keepcost')]
libc=ctypes.CDLL(None);libc.mallinfo2.restype=MI
state={};calls={};rows=[];started=time.monotonic();counter=0
log=(P/'memory.jsonl').open('x',buffering=1)
def send(row):
    raw=json.dumps(row,separators=(',',':'))+'\n'
    if log.tell()+len(raw.encode())>4_000_000:raise RuntimeError('Memory log 4MB cap')
    log.write(raw);log.flush()
def sizes():
    seen={};items={}
    for name,t in state.items():
        if not isinstance(t,torch.Tensor):continue
        s=t.untyped_storage();key=(s.data_ptr(),s.nbytes())
        seen[key]=s.nbytes()
        items[name]={'shape':list(t.shape),'stride':list(t.stride()),'dtype':str(t.dtype),'logical_bytes':t.numel()*t.element_size(),'storage_bytes':s.nbytes()}
    return {'unique_storage_bytes':sum(seen.values()),'buffers':items}
def snap(phase,**extra):
    global counter
    counter+=1;m=libc.mallinfo2()
    status={}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmRSS:','VmHWM:','RssAnon:','RssFile:','RssShmem:','Threads:')):status[line.split(':')[0]]=int(line.split()[1])*(1 if line.startswith('Threads:') else 1024)
    smaps={}
    for line in Path('/proc/self/smaps_rollup').read_text().splitlines():
        if ':' in line:
            k,v=line.split(':',1)
            if k in ('Rss','Pss','Private_Clean','Private_Dirty','Anonymous','Shared_Clean','Shared_Dirty','Pss_Anon','Pss_File','Pss_Shmem'):smaps[k]=int(v.split()[0])*1024
    r=resource.getrusage(resource.RUSAGE_SELF)
    send({'index':counter,'phase':phase,'elapsed_wall':time.monotonic()-started,'self_CPU_seconds':r.ru_utime+r.ru_stime,'status':status,'smaps':smaps,'mallinfo2':{n:int(getattr(m,n)) for n,_ in MI._fields_},'known_live':sizes(),**extra})
def count(name):calls[name]=calls.get(name,0)+1
def linear(name,input_name,shape):
    count('linear')
    view=state['arena'][:shape[0]*shape[1]].view(shape)
    view.fill_(0.001)
    state[name]=F.linear(state[input_name],view,None)
    del view
def layer(item):
    q=item['chunk'];n=item['end'];old=item['start'];meta={'call':item['call'],'q':q,'tokens':n}
    state['hidden']=torch.full((1,q,2560),0.01,dtype=torch.bfloat16)
    snap('layer_input',**meta)
    for name,shape in [('q_linear',(4096,2560)),('k_linear',(1024,2560)),('v_linear',(1024,2560))]:
        linear(name,'hidden',shape);snap(name,**meta)
    state['q']=state.pop('q_linear').view(1,q,32,128).transpose(1,2)
    state['new_k']=state.pop('k_linear').view(1,q,8,128).transpose(1,2)
    state['new_v']=state.pop('v_linear').view(1,q,8,128).transpose(1,2)
    for k,new in [('keys','new_k'),('values','new_v')]:
        state[k]=torch.cat([state.get(k,torch.empty(0,dtype=torch.bfloat16)),state[new]],dim=-2)
        del state[new]
    snap('cache_append',**meta)
    for dest,src in [('repeat_k','keys'),('repeat_v','values')]:
        state[dest]=state[src][:,:,None,:,:].expand(1,8,4,n,128).reshape(1,32,n,128)
    allowed=torch.arange(n).reshape(1,1,1,-1)<=torch.arange(old,n).reshape(1,1,-1,1)
    state['mask']=torch.zeros((1,1,q,n),dtype=torch.bfloat16).masked_fill_(~allowed,torch.finfo(torch.bfloat16).min)
    del allowed;snap('repeat_kv_and_mask',**meta)
    state['scores']=torch.matmul(state['q'],state['repeat_k'].transpose(2,3))*(128**-0.5);count('attention_matmul')
    state['scores']=state['scores']+state['mask'];snap('attention_QK',**meta)
    state['probabilities']=F.softmax(state.pop('scores'),dim=-1,dtype=torch.float32).to(torch.bfloat16);count('softmax');snap('softmax',**meta)
    state['attention']=torch.matmul(state['probabilities'],state['repeat_v']).transpose(1,2).contiguous().reshape(1,q,4096);count('attention_matmul');snap('attention_AV',**meta)
    for k in ('q','repeat_k','repeat_v','mask','probabilities'):del state[k]
    linear('o_linear','attention',(2560,4096));snap('o_linear',**meta)
    del state['attention'],state['o_linear']
    linear('gate_linear','hidden',(9728,2560));snap('gate_linear',**meta)
    state['activated']=F.silu(state.pop('gate_linear'))
    linear('up_linear','hidden',(9728,2560));snap('up_linear',**meta)
    state['product']=state.pop('activated')*state.pop('up_linear')
    linear('down_linear','product',(2560,9728));snap('down_linear',**meta)
    for k in ('hidden','product','down_linear'):del state[k]
    snap('layer_temporaries_released',**meta)

try:
    send({'kind':'runtime','torch':torch.__version__,'git_version':torch.version.git_version,'torch_build':torch.__config__.show(),'parallel_build':torch.__config__.parallel_info(),'mkldnn_enabled':torch.backends.mkldnn.enabled,'mkl_available':torch.backends.mkl.is_available(),'threads':[torch.get_num_threads(),torch.get_num_interop_threads()],'explicit_BF16':True,'autocast':torch.is_autocast_enabled('cpu'),'grad':torch.is_grad_enabled(),'profiler':False,'versions_source':'Torch build string plus backend verbose banners'})
    with torch.inference_mode():
        snap('baseline')
        state['arena']=torch.empty(49_807_360//2,dtype=torch.bfloat16).fill_(0.001);snap('arena_ready')
        for item in protocol['shapes']:
            layer(item);rows.append(item['call'])
        state.clear();gc.collect();snap('decoder_all_released')
        state['head_weight']=torch.full((151936,2560),0.001,dtype=torch.bfloat16)
        state['head_input']=torch.full((1,2560),0.01,dtype=torch.bfloat16);snap('synthetic_head_ready')
        for i in range(2):
            state['head_output']=F.linear(state['head_input'],state['head_weight'],None);count('head_linear');snap('synthetic_head_GEMM',head_call=i)
            del state['head_output'];snap('synthetic_head_output_released',head_call=i)
        state.clear();gc.collect();snap('all_buffers_released')
    send({'kind':'result','status':'COMPLETE','completed_shape_pairs':len(rows),'operator_counts':calls,'model_calls':0,'checkpoint_reads':0,'GPU':False})
except BaseException as e:
    send({'kind':'failure','type':type(e).__name__,'message':str(e),'completed_shape_pairs':len(rows),'operator_counts':calls})
    raise
finally:log.close()
