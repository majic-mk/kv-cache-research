# Native operator probe: launch failed

No native operator or Torch import was reached. This attempt produced no memory-attribution evidence and no fix claim. No retry was made.

The frozen source passed compilation and its nine pure guard checks, but those checks missed a process-inheritance defect. The parent guard reduced its own RLIMIT_CPU hard limit to 8 seconds before `Popen`; the forked child inherited that limit and tried to raise it to 105 seconds in `preexec_fn`. Unprivileged hard-limit increases are not allowed. The observed exception is `SubprocessError('Exception occurred in preexec_fn.')`; the exception does not retain the underlying errno. Source ordering identifies this defect without requiring another execution.

## Actual observations

- Fresh host available: 7,173,292,032 B; free disk: 9,057,128,448 B
- Guarded launch/finalization wall: 0.001739 seconds; aggregate recorded CPU: 0.101702 seconds
- Zero backend-log bytes; `memory.jsonl` was never created
- No child PID returned from Popen; no model, config, checkpoint, generation or synthetic operator ran
- Original 39-shape protocol, compilation/self-test receipt, source hashes, run-once record and failed guard receipt preserved unchanged

Three receipt fields require explicit qualification: RSS=0 means no sampling iteration occurred; `caps_passed=true` is a mechanical flag, not a successful diagnostic or memory-cap validation; `owned_process_group_absent=true` is a default because Popen returned no child PID, not an executed group-existence check. This attempt must not be reported as passed.

## Smallest correction, not applied or launched

Move the guard-only CPU-limit reduction to immediately after successful Popen, while leaving the child's hard limit in pre-exec setup. Add a launch-inheritance regression check. Preserve this failed attempt and require fresh authorization for any corrected launch, freezing its corrected sources and protocol separately. The intended native-backend question remains open.
