"""One prospectively amended actual CPU Full-only attempt; parent GO required.

No import-time Torch, downloads, GPU, retries, eviction arms or alternate inputs.
Run only through actual_guard.py. This scope has one native Full arm and makes no no-crop claim.
"""
from pathlib import Path
import argparse,gc,hashlib,json,os,resource,time,traceback
from cpu_release import require_cpu_release
from file_pager import FilePager,require
from actual_common import (ROOT,HERE,PROTOCOL,PROTOCOL_SHA256,INPUT_SHA256,GATE,GATE_SHA256,
    GATE_MANIFEST,sha_file,json_read,write_json,load_protocol,load_row,verify_base,
    acquisition_anchor,source_integrity,Evidence,semantic_review,host_available)

def main(args):
    require_cpu_release()  # before Torch import, model construction or gate load
    out=Path(args.out).resolve();launch=json_read(out/'guard_launch.json')
    require(launch['guard_pid']==os.getppid()==args.guard_pid,'Independent guard parent required')
    require(b'actual_guard.py' in Path(f'/proc/{args.guard_pid}/cmdline').read_bytes(),'Wrong guard process')
    protocol=load_protocol();source_sha=source_integrity();row=load_row(protocol)
    start,receipt_sha=acquisition_anchor(args.acquisition_receipt)
    require(launch['acquisition_receipt_sha256']==receipt_sha,'Acquisition receipt changed')
    require(launch['source_manifest_sha256']==source_sha,'Source snapshot changed after guard launch')
    deadline=min(start+3600-180,launch['model_phase_start_unix']+1800)
    require(args.deadline==deadline==launch['effective_deadline_unix'],'Deadline changed')
    binding=dict(run_id=launch['run_id'],canonical_ids_sha256=row['canonical_ids_sha256'],
                 source_manifest_sha256=source_sha,cpu_protocol_sha256=PROTOCOL_SHA256,
                 frozen_input_file_sha256=INPUT_SHA256,acquisition_receipt_sha256=receipt_sha,
                 model_phase_start_unix=launch['model_phase_start_unix'],effective_deadline_unix=deadline)
    e=Evidence(out,binding,deadline);e.json('binding.json',binding);e.check()
    require(host_available()>=6_000_000_000,'Fresh pre-load host reserve')
    ready=json_read(Path(args.base)/'acquisition_complete.json')
    require(ready['status']=='ALL_PINNED_ASSETS_VERIFIED_NO_MODEL_LOAD','Acquisition incomplete')
    began=time.perf_counter();shards,base_receipts,records=verify_base(args.base,protocol)
    e.json('base_verified.json',dict(files=base_receipts,records=records,seconds=time.perf_counter()-began))
    import torch
    import transformers
    from transformers import Qwen3Config,Qwen3ForCausalLM,AutoTokenizer
    from transformers.cache_utils import DynamicCache
    from transformers.models.qwen3 import modeling_qwen3 as qwen
    require(torch.__version__=='2.9.1+cpu' and torch.version.cuda is None,'Pinned CPU Torch only')
    require(transformers.__version__==protocol['runtime']['transformers'],'Pinned Transformers version')
    require(sha_file(qwen.__file__)==protocol['runtime']['qwen3_source_sha256'],'Pinned native Qwen3 source')
    torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.set_grad_enabled(False)
    torch.use_deterministic_algorithms(True)
    e.json('runtime.json',dict(torch=torch.__version__,transformers=transformers.__version__,
           qwen3_sha256=sha_file(qwen.__file__),intraop_threads=torch.get_num_threads(),
           interop_threads=torch.get_num_interop_threads(),device='cpu',dtype='BF16',GPU=False))
    config=Qwen3Config.from_dict(json_read(Path(args.base)/'config.json'));config._attn_implementation='eager'
    require((config.hidden_size,config.num_hidden_layers,config.num_attention_heads,
             config.num_key_value_heads,config.head_dim,config.vocab_size,config.intermediate_size)
             ==(2560,36,32,8,128,151936,9728),'Exact plain Qwen3 configuration')
    require(config.tie_word_embeddings and not config.attention_bias
            and config.rope_parameters=={'rope_theta':5000000,'rope_type':'default'},'Pinned native standardized RoPE profile')
    prior=torch.get_default_dtype();torch.set_default_dtype(torch.bfloat16)
    began=time.perf_counter()
    try:
        with torch.device('meta'):model=Qwen3ForCausalLM(config).eval()
    finally:torch.set_default_dtype(prior)
    model.model.rotary_emb=qwen.Qwen3RotaryEmbedding(config=config)
    require(all(p.device.type=='meta' for p in model.parameters()),'No eager whole-model allocation')
    require(model.lm_head.weight is model.model.embed_tokens.weight,'Native tied head identity')
    construct_seconds=time.perf_counter()-began
    tokenizer=AutoTokenizer.from_pretrained(args.base,local_files_only=True,trust_remote_code=False)
    def digest(tensor):
        h=hashlib.sha256();flat=tensor.detach().contiguous().view(torch.uint8).reshape(-1)
        for lo in range(0,flat.numel(),4*1024**2):h.update(flat[lo:lo+4*1024**2].numpy().tobytes())
        return h.hexdigest()
    def sample():
        return dict(unix_time=time.time(),self_max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                    host_available_bytes=host_available(),proc_io=Path('/proc/self/io').read_text())
    def tensor_spec(t):return dict(shape=list(t.shape),dtype=str(t.dtype),sha256=digest(t),bytes=t.numel()*t.element_size())
    # Gate remains separate and shared between both arms, never loaded into the base.
    began=time.perf_counter();require(GATE.stat().st_size==94_725_981 and sha_file(GATE)==GATE_SHA256,'Verified real gate')
    gate_specs=json_read(GATE_MANIFEST)['tensors'];gate=torch.load(GATE,weights_only=True,map_location='cpu',mmap=True)
    require(isinstance(gate,dict) and set(gate)=={x['name'] for x in gate_specs} and len(gate)==144,'Exact gate keyset')
    for spec in gate_specs:
        value=gate[spec['name']]
        require(list(value.shape)==spec['shape'] and value.dtype==torch.bfloat16 and bool(torch.isfinite(value).all()),'Gate shape/dtype/finite')
        require(digest(value)==spec['raw_tensor_sha256'],'Gate tensor bytes')
    gates=[]
    for layer in range(36):
        prefix=f'model.layers.{layer}.self_attn.retention_gate.'
        gates.append([gate[prefix+suffix] for suffix in ('linear1.weight','linear1.bias','linear2.weight','bias')])
    gate_seconds=time.perf_counter()-began
    global_cost=dict(completed_calls=0,maximum_call_seconds=0.,call_seconds=[],gate_seconds=0.,gate_written_bytes=0,maximum_total_calls=145)
    traces={}
    class Capture(DynamicCache):
        def __init__(self):
            super().__init__(config=config);self.append=[];self.written=0;self.peak_coexist=0
        def update(self,keys,values,layer_idx,*unused,**kwargs):
            self.append.append(dict(layer=layer_idx,keys=tensor_spec(keys),values=tensor_spec(values)))
            before=sum(l.keys.numel()*l.keys.element_size()+l.values.numel()*l.values.element_size()
                       for l in self.layers if getattr(l,'keys',None) is not None)
            old=self.layers[layer_idx].keys if layer_idx<len(self.layers) else None
            size=(0 if old is None else old.numel()*old.element_size())+keys.numel()*keys.element_size()
            self.written+=2*size;self.peak_coexist=max(self.peak_coexist,before+2*size)
            return super().update(keys,values,layer_idx,*unused,**kwargs)
    class Engine:
        def __init__(self,use_gate):
            self.cache=Capture();self.seen=0;self.use_gate=use_gate;self.gate_values={}
        def step(self,ids):
            self.cache.append=[]
            if not self.use_gate:
                logits=model(ids,past_key_values=self.cache,use_cache=True,logits_to_keep=1).logits
            else:
                positions=torch.arange(self.seen,self.seen+ids.shape[1]).unsqueeze(0)
                hidden=model.model.embed_tokens(ids);rope=model.model.rotary_emb(hidden,positions)
                key_positions=torch.arange(self.seen+ids.shape[1])
                allowed=key_positions.reshape(1,1,1,-1)<=positions.reshape(1,1,-1,1)
                mask=torch.zeros(allowed.shape,dtype=hidden.dtype).masked_fill_(~allowed,torch.finfo(hidden.dtype).min)
                for index,layer in enumerate(model.model.layers):
                    def gate_hook(module,a,kw,index=index):
                        from torch.nn import functional as F
                        tic=time.perf_counter();w1,b1,w2,bias=gates[index]
                        value=F.logsigmoid(F.linear(F.silu(F.linear(kw['hidden_states'],w1,b1)),w2)+bias).transpose(1,2)
                        if index in self.gate_values:value=torch.cat([self.gate_values[index],value],dim=-1)
                        self.gate_values[index]=value
                        global_cost['gate_seconds']+=time.perf_counter()-tic
                        global_cost['gate_written_bytes']+=value.numel()*value.element_size()
                    hook=layer.self_attn.register_forward_pre_hook(gate_hook,with_kwargs=True)
                    try:
                        hidden=layer(hidden,attention_mask=mask,position_embeddings=rope,position_ids=positions,
                                     past_key_values=self.cache,use_cache=True)
                    finally:hook.remove()
                logits=model.lm_head(model.model.norm(hidden)[:,-1:,:])
            self.seen+=ids.shape[1]
            require(len(self.cache.append)==36 and [x['layer'] for x in self.cache.append]==list(range(36)),'Exact native layer append schedule')
            return logits
    def integrity(pager):
        pager.assert_idle()
        require(sha_file(PROTOCOL)==PROTOCOL_SHA256 and source_integrity()==source_sha,'Source/config mutation')
        for fd,stat in zip(pager.fds,source_stats):
            current=os.fstat(fd);require((current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns)==stat,'Source file changed')
        require(model.lm_head.weight is model.model.embed_tokens.weight,'Tied head mutation')
    began=time.perf_counter()
    pager=FilePager(model,[Path(args.base)/s['path'] for s in shards],synthetic=False,expected_sources=shards)
    pager_setup_seconds=time.perf_counter()-began
    with torch.inference_mode(),pager:
        source_stats=[(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns) for s in map(os.fstat,pager.fds)]
        resident_before={n:tensor_spec(p) for n,p in model.named_parameters() if p.device.type=='cpu'}
        rope_before={n:tensor_spec(p) for n,p in model.named_buffers()}
        gate_before={n:tensor_spec(p) for n,p in gate.items()}
        e.json('loaded_identity.json',dict(meta_construct_seconds=construct_seconds,gate_load_verify_seconds=gate_seconds,pager_setup_seconds=pager_setup_seconds,
            resident_parameters=resident_before,rope_buffers=rope_before,source_files=pager.source_sha256,
            source_read_cost=pager.stats,gate_manifest_sha256=sha_file(GATE_MANIFEST),resources=sample()))
        def case(arm,use_gate,expected=None):
            engine=Engine(use_gate);calls=[];generated=[];start_time=time.perf_counter();previous=0
            def step(ids,phase):
                e.check();integrity(pager);tic=time.perf_counter();before=engine.seen
                tensor=torch.tensor([ids],dtype=torch.long);logits=engine.step(tensor);pager.assert_idle()
                raw=logits.contiguous().view(torch.uint8).numpy().tobytes()
                entry=dict(call=len(calls),phase=phase,start=before,end=engine.seen,ids=ids,
                    original_positions=[before,engine.seen],mask='absolute_key_position <= absolute_query_position',
                    logits=e.vector(f'{arm}/call_{len(calls):03d}_logits.bf16.gz',raw,dict(shape=list(logits.shape),dtype='torch.bfloat16',byte_order='little')),
                    appended_KV=engine.cache.append)
                numerical_valid=(logits.device.type=='cpu' and logits.dtype==torch.bfloat16 and list(logits.shape)==[1,1,151936]
                                 and bool(torch.isfinite(logits).all()))
                parity=True
                if expected is not None:
                    old=expected['calls'][len(calls)]
                    parity=(entry['ids']==old['ids'] and entry['logits']['sha256']==old['logits']['sha256']
                            and entry['appended_KV']==old['appended_KV'])
                entry['numerical_valid']=numerical_valid;entry['parity_passed']=parity if expected is not None else None
                elapsed=time.perf_counter()-tic;entry['seconds']=elapsed;calls.append(entry)
                global_cost['completed_calls']+=1;global_cost['call_seconds'].append(elapsed)
                global_cost['maximum_call_seconds']=max(global_cost['maximum_call_seconds'],elapsed)
                e.json(f'{arm}/calls/call_{len(calls)-1:03d}.json',entry)
                e.json('progress.json',dict(status='MODEL_ACTIVE',arm=arm,completed_calls=global_cost['completed_calls'],
                      seen_tokens=engine.seen,pager_cost=pager.stats,global_cost=global_cost,resources=sample()))
                require(numerical_valid,'Logit dtype/shape/device/finiteness failed; raw evidence preserved')
                require(parity,'Exact native/no-crop append or logit parity failed; raw evidence preserved')
                if global_cost['completed_calls']>=3:
                    remaining=global_cost['maximum_total_calls']-global_cost['completed_calls']
                    require(2*global_cost['maximum_call_seconds']*remaining<deadline-time.time(),'Measured call-time projection cannot fit fixed pair deadline')
                return logits
            for end in row['online_chunk_end_indices']:
                phase='history' if end<=row['history_tokens'] else 'query'
                logits=step(row['canonical_token_ids'][previous:end],phase);previous=end
            eos=False
            for i in range(64):
                token=int(logits.argmax(-1).item());generated.append(token)
                e.json(f'{arm}/answer_progress.json',dict(generated_ids=generated,
                    raw_answer=tokenizer.decode(generated,skip_special_tokens=False),sampled_answer_tokens=len(generated)))
                if token==151645:eos=True;break
                if i<63:logits=step([token],'decode')
            result=dict(arm=arm,run_id=binding['run_id'],canonical_ids_sha256=row['canonical_ids_sha256'],
                execution_kind='real_authorized_cpu_first_input_smoke',model_calls=len(calls),calls=calls,
                generated_ids=generated,eos_reached=eos,cap_hit=not eos,
                raw_answer=tokenizer.decode(generated,skip_special_tokens=False),answer=tokenizer.decode(generated,skip_special_tokens=True),
                sampled_answer_tokens=len(generated),ingested_tokens=engine.seen,seconds=time.perf_counter()-start_time,
                cache_append_written_bytes=engine.cache.written,peak_cache_append_coexist_bytes=engine.cache.peak_coexist,
                final_KV=[dict(layer=i,keys=tensor_spec(l.keys),values=tensor_spec(l.values)) for i,l in enumerate(engine.cache.layers)],
                gate_state=[dict(layer=i,**tensor_spec(v)) for i,v in engine.gate_values.items()],resources=sample())
            if expected is not None:require(generated==expected['generated_ids'] and len(calls)==len(expected['calls']),'Answer/call schedule parity')
            e.json(f'{arm}/result.json',result)
            del engine,logits;gc.collect();integrity(pager)
            require(eos,'Native/adapter answer missing EOS at unchanged 64-token cap')
            return result
        full=case('native_full',False);traces['native_full']=full
        require(resident_before=={n:tensor_spec(p) for n,p in model.named_parameters() if p.device.type=='cpu'},'Resident parameters mutated')
        require(rope_before=={n:tensor_spec(p) for n,p in model.named_buffers()},'Native RoPE changed')
        require(gate_before=={n:tensor_spec(p) for n,p in gate.items()},'Gate bytes changed')
        began=time.perf_counter()
        for spec in shards:require(sha_file(Path(args.base)/spec['path'])==spec['sha256'],'Post-run source bytes changed')
        global_cost['post_run_shard_rehash_seconds']=time.perf_counter()-began
        e.json('result.json',dict(status='NATIVE_FULL_GENERATION_COMPLETE_SEMANTIC_REVIEW_PENDING',binding=binding,
            native_result_sha256=sha_file(out/'native_full/result.json'),source_read_cost=pager.stats,global_cost=global_cost,
            no_crop_run=False,no_crop_parity_established=False,semantic_competence_established=False,
            other_15_inputs_run=False,eviction_arms_run=False,GPU=False,resources=sample(),
            prior_actual_attempt=protocol['prior_actual_attempt']))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);parser.add_argument('--base',required=True)
    parser.add_argument('--acquisition-receipt',required=True);parser.add_argument('--guard-pid',required=True,type=int)
    parser.add_argument('--deadline',required=True,type=float);args=parser.parse_args()
    try:main(args)
    except BaseException as error:
        path=Path(args.out)
        if path.is_dir():write_json(path/'failure.json',dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),unix_time=time.time()))
        raise
