# Native-operator trim comparison: both arms complete

## Finding

Chunk-boundary process-local `malloc_trim(0)` substantially lowered RSS in this synthetic native-operator workload, with **392/392 full-output records matching exactly**. Every output element was finite in both arms. This is evidence that much of the observed native-execution heap retention was reclaimable. It is not proof that the actual Qwen3-4B runner fits, completes, or preserves its full-model outputs.

The control and trim arms each completed the same frozen 39 query/KV shape pairs, 273 synthetic Linears, 78 eager attention matmuls, 39 softmaxes, and two separately marked synthetic head GEMMs. Both processes exited successfully, with their owned process groups explicitly checked absent. No retries occurred in this comparison.

## Memory result

All numbers below are bytes, except the approximate decimal GB summaries:

- Sampled combined guard/child peak RSS: control **1,978,138,624**; trim **1,090,801,664**; difference **887,336,960** (about 0.887 GB)
- Last completed chunk, after boundary action: control **1,238,253,568**; trim **349,351,936**
- After decoder tensors were released: control **1,188,442,112**; trim **299,540,480**
- After every tracked buffer, including the synthetic head, was released: control **1,188,454,400**; trim **301,064,192**; difference **887,390,208**
- Final chunk's trim directly reduced RSS from **481,361,920** to **349,351,936**, reclaiming **132,009,984**
- Largest direct boundary reduction: **144,797,696**, at 3,618 tokens. All 39 trim calls returned 1

The final tracked live-storage ledger was zero in both arms. Glibc still reported roughly 855 MB free heap after the trim arm, despite its much lower RSS; allocator free-space totals therefore must not be equated to resident physical pages. Trim can discard physical backing while address ranges remain available to the allocator.

The same native descriptors and matmul execution order were observed in both arms: 353 oneDNN `brg_matmul:avx512_core_bf16` executions with user scratchpads, 164 primitive cache misses and 189 cache hits. This comparison did not disable primitive caching or change attention implementation, precision, thread count or weights.

## Exact synthetic output comparison

Both arms use the identical probe source, deterministic construction and operation order. Each BF16 arena weight view is filled with 0.001 before its Linear; each synthetic hidden/input tensor is filled with 0.01. The synthetic head is a 151,936-by-2,560 BF16 matrix filled with 0.001 and an input filled with 0.01. Constants are rounded to BF16 identically. No source model weights, model/config objects, learned retention gate, generation, checkpoint reads, norms/RoPE/residuals or 36-layer model execution are present.

The compared outputs are seven Linear outputs, scaled/masked QK scores, BF16 softmax probabilities and AV output for each chunk, plus the two head outputs: **392 full outputs per arm**. SHA256 covers every byte of every declared output, **1,171,387,264 bytes per arm**. Corresponding shape, dtype, byte count, full digest and finite flag all match. This is a complete comparison of the declared output set, not sampled element parity. Every BF16 element was also explicitly checked for finiteness in bounded chunks; zero nonfinite outputs were found.

Hashing uses zero-copy contiguous uint8 memoryviews sliced at <=4 MiB. Finite scans use <=4 MiB BF16 chunks. No output-tensor history or raw-output archive is retained. Full-output checks and boundary `gc.collect()` are identical in both arms and may change allocation behavior compared with the preceding unhashed probe; this is why the fresh hashed control was necessary.

## Safety and accounting

- Cumulative recorded CPU, including the prior failed launch, stdlib inheritance test, successful native probe, and both new arms: **88.023078 seconds**, below the 100-second proactive and 120-second hard totals
- New pair CPU: **63.321352 seconds**
- Control child/guard CPU: **31.195847 / 0.999117 seconds**; trim: **30.145061 / 0.981327 seconds**. Each satisfies 36/5-second caps
- Control/trim wall: **11.818958 / 11.116926 seconds**, each below 45 seconds
- Fresh host available: **7,188,836,352 / 7,154,642,944**, each >=6 GB
- Lowest sampled host available: **5,288,308,736 / 6,127,050,752**, each above 1.5 GB
- Lowest sampled free disk: **9,036,079,104 / 9,034,891,264**, each above 5 GB
- Last sampled aggregate artifacts, including prior probe directories: **3,723,272**, below 16 MB; final report/manifest totals are recorded separately
- No observed resource-cap deviation or guard error. Child CPU-limit inheritance was asserted as 36/36 in both processes. Each fresh guard lowered its own limit only after spawning its child

CPU accounting includes the named guarded runs, their guards and the stdlib launch regression; source preparation and post-run analysis commands are outside this probe-process accounting. External sampled RSS can miss between-sample transient peaks. Timings are safety receipts from one sequential pair, not evidence of a throughput benefit.

## Interpretation and stopping point

The earlier allocation-only replay omitted native matmul execution and did not reproduce the large gap. The native probe supplied that missing component and observed large free-heap retention. This controlled native comparison now establishes a reclaimable portion **for its own workload** while its declared outputs remain identical.

Differences in real 36-layer lifetimes, real-weight paging, fixed resident data, actual activations, evidence hashing and host state prevent extrapolating this ~0.887 GB reduction to the failed model's ~3.9 GB excess. There is still no complete 4B answer, competence result, no-crop parity or eviction result. Process-local trim is now a measured engineering candidate for separately authorized model work. No further execution is included or started here.

## Evidence

- `comparison_protocol.json`: frozen shapes, construction, intended limits and hash costs
- `control/` and `trim/`: identical frozen sources, arm protocols/manifests, prelaunch checks, one-shot launch receipts, resource samples, backend logs, full-output digests and memory samples
- `COMPARISON.json`: exact matched records, all 39 pre/post-trim deltas, library/build receipts, per-arm guards and summary metrics
- `artifact_manifest.json`: frozen deliverable paths, sizes and SHA256 hashes; generated bytecode explicitly excluded
