"""Stdlib-only admission/evidence helpers for the prospective one-case CPU run."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,time
from file_pager import read_header,require
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PROTOCOL=HERE/'protocol.json'
PROTOCOL_SHA256='2fcb6ba25b81596c947dad805f520bbe8291d6908ab43a4e27f0c6d4345552ae'
INPUT_SHA256='b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7'
GATE_SHA256='a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a'
GATE=ROOT/'outputs/revision_static_trim_gate_20261004/trimkv_weights.pth'
GATE_MANIFEST=ROOT/'research/reconstructed/revision_baseline_contracts_20261004/phase2_static_gate_verification/tensor_manifest.json'

def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while b:=f.read(1024**2):h.update(b)
    return h.hexdigest()

def json_read(path):return json.loads(Path(path).read_text())
def write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');os.replace(temporary,path)

def host_available():
    rows=Path('/proc/meminfo').read_text().splitlines()
    return next(int(x.split()[1])*1024 for x in rows if x.startswith('MemAvailable:'))

def load_protocol():
    require(sha_file(PROTOCOL)==PROTOCOL_SHA256,'CPU protocol changed since review')
    return json_read(PROTOCOL)

def source_integrity():
    manifest=json_read(HERE/'source_manifest.json')
    for row in manifest['files']:
        require(sha_file(HERE/row['path'])==row['sha256'],'Frozen CPU source changed: '+row['path'])
    return sha_file(HERE/'source_manifest.json')

def load_row(protocol):
    path=ROOT/protocol['parent_input_file'];require(sha_file(path)==INPUT_SHA256,'Frozen input file changed')
    data=json_read(path);rows=data['variants'] if isinstance(data,dict) else data
    require(len(rows)==16,'Fixed sixteen-row input universe')
    for row in rows:
        digest=hashlib.sha256(json.dumps(row['canonical_token_ids'],separators=(',',':')).encode()).hexdigest()
        require(digest==row['canonical_ids_sha256'],'Canonical token IDs changed')
    row=rows[0];spec=protocol['inputs']
    require(row['variant_id']==spec['variant_id']=='c7dc5443__reservoir_before__low_zero','Fixed first input')
    require(row['canonical_ids_sha256']==spec['canonical_ids_sha256'],'First IDs hash')
    require(len(row['canonical_token_ids'])==7669 and row['online_chunk_end_indices']==spec['original_chunk_ends'],'Exact input/chunk schedule')
    return row

def acquisition_anchor(receipt):
    require(Path(receipt).resolve()==(ROOT/'outputs/revision_cpu_model_assets_20261004/acquisition_start.json').resolve(),'Fixed acquisition receipt path')
    require(sha_file(receipt)=='762c9e848d19073fcf297e115e95d917f9a2257e1003defb391eb5860c3cb700','Fixed acquisition receipt bytes')
    data=json_read(receipt)
    spec=load_protocol()['acquisition_anchor']
    require(all(data.get(k)==v for k,v in spec['required_exact_fields'].items()),'Acquisition receipt fields changed')
    value=data.get('started_unix')
    if value is None:
        value=data.get('started_utc')
        require(isinstance(value,str),'Missing acquisition start anchor')
        value=datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
    require(isinstance(value,(int,float)) and 0<value<=time.time()+1,'Invalid acquisition start')
    require(data.get('overall_deadline_unix')==value+3600,'Original absolute acquisition deadline')
    require(value==1791131300.31698,'Fixed acquisition attempt start; no reset')
    return float(value),sha_file(receipt)

def verify_base(base,protocol):
    base=Path(base);specs=protocol['model']['files']
    verify_asset_identities(base,protocol)
    expected={s['path'] for s in specs}
    require(base.resolve()==(ROOT/'outputs/revision_cpu_model_assets_20261004').resolve(),'Exact acquired asset directory required')
    for path in base.iterdir():
        if path.suffix in ('.safetensors','.bin','.pth','.pt','.h5','.msgpack') or path.name=='adapter_config.json':
            require(path.name in expected,'Unexpected model weight/adapter file')
    receipts=[]
    for spec in specs:
        path=base/spec['path'];require(path.is_file() and path.stat().st_size==spec['bytes'],'Pinned file missing/size')
        digest=sha_file(path)
        if spec['sha256']:
            require(digest==spec['sha256'],'Pinned file SHA256 mismatch')
        else:
            h=hashlib.sha1();h.update(f"blob {spec['bytes']}\0".encode())
            with path.open('rb') as f:
                while block:=f.read(1024**2):h.update(block)
            require(h.hexdigest()==spec['git_blob_sha1'],'Pinned Git metadata blob differs')
        receipts.append(dict(path=spec['path'],bytes=spec['bytes'],sha256=digest))
    index=json_read(base/'model.safetensors.index.json')['weight_map']
    shards=[s for s in specs if s['path'].endswith('.safetensors')]
    require(set(index.values())=={s['path'] for s in shards},'Exact indexed shard set')
    records={}
    for spec in shards:
        for key,value in read_header(base/spec['path']).items():
            require(key not in records and index.get(key)==spec['path'],'Index/header key mapping mismatch')
            records[key]=dict(value,file=spec['path'])
    require(set(index)==set(records),'Exact index/header tensor coverage')
    return shards,receipts,records

def verify_asset_identities(base,protocol):
    spec=protocol['asset_identity_receipt'];path=ROOT/spec['path']
    require(sha_file(path)==spec['sha256'],'Original asset materialization receipt changed')
    records=json_read(path)['files'];result=[]
    for row in records:
        file=Path(base)/row['path'];stat=file.stat()
        require(str(file.resolve())==row['actual_read_path'] and file.is_symlink()==row['symlink'], 'Asset source target changed')
        require((stat.st_ino,stat.st_dev,stat.st_mtime_ns,stat.st_size)==(row['inode'],row['device'],row['mtime_ns'],row['bytes']), 'Asset inode/device/mtime/size changed')
        result.append(dict(path=row['path'],resolved_path=str(file.resolve()),inode=stat.st_ino,device=stat.st_dev,mtime_ns=stat.st_mtime_ns,bytes=stat.st_size))
    return result

def load_reference_prefix(protocol):
    spec=protocol['reference_prefix'];directory=ROOT/spec['directory']
    require(sha_file(directory/'binding.json')==spec['binding_sha256'],'Prior binding changed')
    require(sha_file(directory/'guard_result.json')==spec['guard_result_sha256'],'Prior terminal receipt changed')
    require(len(spec['files'])==spec['completed_calls']==145,'Exactly145 frozen reference calls')
    require(sha_file(directory/'native_full/result.json')==spec['result_sha256'],'Prior64-token result changed')
    prior_result=json_read(directory/'native_full/result.json')
    require(prior_result['generated_ids']==spec['prior_selected_ids'] and len(spec['prior_selected_ids'])==64,'Exactly64 frozen prior selected IDs')
    require(prior_result['cap_hit'] is True and prior_result['eos_reached'] is False,'Prior failed smoke must remain unchanged')
    require(json_read(directory/'guard_result.json')['owned_process_group_absence_verified'] is True,'Prior model process group is not confirmed closed')
    output=[]
    for index,row in enumerate(spec['files']):
        require(row['call']==index,'Reference call order')
        file=directory/row['call_path'];require(sha_file(file)==row['call_sha256'],'Reference call record changed')
        entry=json_read(file);payload=(directory/row['vector_path']).read_bytes()
        require(hashlib.sha256(payload).hexdigest()==row['vector_sha256'],'Reference compressed vector changed')
        raw=gzip.decompress(payload)
        require(len(raw)==row['raw_vector_bytes']==entry['logits']['bytes'],'Reference vector size differs')
        require(hashlib.sha256(raw).hexdigest()==row['raw_vector_sha256']==entry['logits']['sha256'],'Reference raw vector changed')
        output.append(dict(spec=row,entry=entry,vector_path=str(directory/row['vector_path'])))
    return output

def compare_reference_prefix(entry,raw,reference):
    spec=reference['spec'];old=reference['entry'];payload=Path(reference['vector_path']).read_bytes()
    frozen=hashlib.sha256(payload).hexdigest()==spec['vector_sha256']
    expected=gzip.decompress(payload) if frozen else b''
    descriptors=all(entry[k]==old[k] for k in ('call','phase','start','end','ids','original_positions','mask'))
    logits=frozen and raw==expected
    kv=entry['appended_KV']==old['appended_KV']
    return dict(reference_call_sha256=spec['call_sha256'],reference_vector_sha256=spec['vector_sha256'],
                reference_still_frozen=frozen,descriptors_equal=descriptors,raw_logit_bytes_equal=logits,
                all_layer_KV_appends_equal=kv,passed=bool(frozen and descriptors and logits and kv))

class Evidence:
    def __init__(self,out,binding,deadline):
        self.out=Path(out);self.binding=binding;self.deadline=deadline;self.bytes=0
    def check(self,size=0):
        require(time.time()<self.deadline,'Fixed compute deadline with overall finalization reserve')
        require(shutil.disk_usage(self.out).free-size>=5_000_000_000,'Free disk reserve')
        require(sum(p.stat().st_size for p in self.out.rglob('*') if p.is_file())+size<=384_000_000,'Evidence allowance')
        require(host_available()>=1_500_000_000,'Host available-memory reserve')
    def json(self,name,data):
        encoded=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
        bounds={'/calls/':32768,'/trim/':4096,'/forecasts/':512,'/selections/':1024}
        for marker,maximum in bounds.items():
            if marker in name:require(len(encoded)<=maximum,'Declared metadata envelope exceeded: '+name)
        if name=='native_full/result.json':require(len(encoded)<=len(data['calls'])*49152+4*1024**2,'Aggregate result metadata envelope')
        self.check(len(encoded)+4096)
        mutable=name=='progress.json' or name.endswith('/answer_progress.json')
        require(mutable or not (self.out/name).exists(),'Immutable evidence already exists: '+name)
        write_json(self.out/name,data)
    def vector(self,name,raw,meta):
        self.check(len(raw)+4096);path=self.out/name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as fileobj:
            with gzip.GzipFile(fileobj=fileobj,mode='wb',compresslevel=1) as f:f.write(raw)
        result=dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),**meta)
        return result

def semantic_review(path,full_result,binding):
    review=json_read(path)
    require(review.get('method')=='independent_researcher_or_agent_semantic_source_review','Honest reviewer method')
    require(isinstance(review.get('reviewer'),str) and review['reviewer'].strip(),'Named researcher/agent required')
    require(isinstance(review.get('rationale'),str) and len(review['rationale'].strip())>=20,'Source-based rationale required')
    require(review.get('frozen_input_file_sha256')==INPUT_SHA256 and review.get('native_full_result_sha256')==sha_file(full_result),'Review source/result binding')
    require(review.get('cpu_protocol_sha256')==PROTOCOL_SHA256,'Review protocol binding')
    require(isinstance(review.get('source_reference'),str) and review['source_reference'].strip(),'Review source reference required')
    require(review.get('run_id')==binding['run_id'] and review.get('canonical_ids_sha256')==binding['canonical_ids_sha256'],'Review same-run binding')
    require(review.get('full_semantically_correct') is True and review.get('complete_and_supported') is True
            and review.get('eos_reached') is True and review.get('cap_hit') is False,'Native competence gate failed')
    return review
