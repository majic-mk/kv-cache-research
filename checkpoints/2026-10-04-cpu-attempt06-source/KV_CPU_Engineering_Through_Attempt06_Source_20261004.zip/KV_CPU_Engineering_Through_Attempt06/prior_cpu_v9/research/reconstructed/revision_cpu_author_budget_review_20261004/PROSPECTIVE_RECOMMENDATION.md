# Prospective author-budget baseline-generation calibration

Recommendation: one separately labeled and authorized Full-only calibration on the unchanged frozen CPU input is defensible to address the demonstrated output-budget mismatch. It cannot retrospectively pass attempt 4 or establish the author benchmark. No new run is authorized by this document.

## Exact pinned author contract

Source: ngocbh/trimkv commit 49d2a2951ba12e6431a3986b418ee791b209d7c2; local revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__run_longmemeval.py, SHA256 815c8924ae49207b1152a1309fb9eae55636634382e32e65c4037a836f86f7f1. Config.gen_length=None and Config.cot=True resolve to 800 at lines 43, 49, 250–252. Active decode selects argmax at line 155, then checks EOS or the last iteration BEFORE append at lines 156–160. Config sampling flags do not control this path.

The exact maximum is 800 selected/audited tokens, 799 appended/emitted tokens and 799 generated tokens fed into subsequent calls. With EOS at selection k, only k−1 tokens are emitted/fed. EOS is not emitted or fed. If selection 800 is non-EOS, retain it as audit evidence but discard it from returned text/input; if it is EOS, record the actual EOS. The effective EOS set is {151645}, from tokenizer and model config. Additional 151643 in generation_config is not consulted by this custom decode. Return only the generated suffix, decode with skip_special_tokens=True (line 202), then strip whitespace (line 306); retain raw selected/emitted lists separately.

Our unchanged 82 prefill calls imply at most 881 native calls and 8,468 ingested tokens. Simply changing the current loop's cap to 800 would not reproduce the author stop contract because the current loop emits its final capped token. Distinguish selected, emitted and fed tokens explicitly.

## Bounded resource recommendation

Use one fresh attempt after review, durable backup and parent GO: at most 3,600 seconds model phase plus 180 seconds cleanup; 6 GiB sampled process-tree RSS; 6 GB start / 1.5 GB running host available memory; 5 GB free disk; 384 MB evidence. Preserve historical receipts and failures. No automatic retry or window extension; predictions remain advisory, actual wall/monotonic/resource limits bind.

At most 881 raw BF16 vectors require 267,711,232 bytes before compression/metadata. Maximum live full KV is 1,248,657,408 bytes; parameter reads could reach 6,402,680,814,592 bytes. The 384 MB evidence cap leaves room for call records and traces but must be enforced against actual usage.

Completion is not guaranteed. Attempt 4's 63 decode calls averaged 3.967306591 seconds. At a constant rate, 736 additional calls project 3,739.14 seconds total (62.3 minutes), exceeding 60 minutes. Earlier EOS may finish sooner. A hard-time stop is time-censored, not a competence failure or permission to enlarge the window.

## Predeclared semantic rubric

Retain the existing whole-answer source review. A qualifying output must naturally EOS within the 800-selection limit, be complete and supported, and give the queried team's latest reported 5–2 record. “Last reported on June 30; no later update is provided” is acceptable. A correct distinction between historical June 16's 3–2 and June 30's 5–2 is acceptable. Equivalent words/number formatting are acceptable. Judge the entire answer, not a score substring or an ungenerated continuation. Wrong current attribution, invented events or unresolved contradictory assertions do not qualify.

Budget exhaustion without EOS retains the qualification failure even if a correct partial fact appears; separately describe any complete/correct information in the observed text. Actual resource/time censoring remains inconclusive. This is the existing acceptance standard, fixed before new output, not the author's scoring pipeline.

Keep model/revision, all 7,669 input IDs, 82 chunks, CPU BF16 native operators, boundary trim policy and source facts fixed. Compare all 145 recorded attempt-4 outputs/KV metadata and its first 64 selected IDs before interpreting extension beyond that prefix. No new prompts, alternate cases, compressed arms, no-crop arm or GPU.

## Limits of the author comparison

Use the label “author-budget baseline-generation calibration on the frozen CPU input.” Author defaults use CUDA/FlashAttention2, Torch 2.8.0 / Transformers 4.57.1, JSON history inside one user message, and history/query block prefill. Our path uses CPU eager/file paging, Torch 2.9.1+cpu / Transformers 5.19.0.dev0, a custom system plus role-separated dated turns/neutral controls, and message-aligned chunks. The author loader does not pin a model revision. Its bool-versus-string prompt checks also mean literal default bool True values select non-CoT/both-role history while retaining the 800-step budget. Matching budget/stopping semantics is not full prompt/runtime/benchmark reproduction.

Attempt 4 remains the 64-token, no-EOS/incomplete admission failure containing a correct 5–2 fragment and contradictory opening. It is not overwritten, and future success is not assumed.

Reviewer: /root/assess_next_cpu_model_gate
