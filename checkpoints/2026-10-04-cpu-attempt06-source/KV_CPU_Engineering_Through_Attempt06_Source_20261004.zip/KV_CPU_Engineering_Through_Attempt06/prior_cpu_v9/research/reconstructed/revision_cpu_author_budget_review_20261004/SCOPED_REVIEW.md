# Independent scoped calibration implementation review

PASS for the prepared source/protocol below, conditional on durable additive backup and explicit parent GO. No model, Torch import, weight download or source modification was performed by this review.

Source manifest: 2c88f62e91533987b0e0c122c3ddb49800f43831025165ba0a47142ee4fb391f
Protocol: 2fcb6ba25b81596c947dad805f520bbe8291d6908ab43a4e27f0c6d4345552ae
Candidate: research/reconstructed/revision_cpu_author_budget_calibration_20261004

The code implements the pinned author ordering exactly: select greedy argmax, record the selection, stop before append/feed if EOS or final selection index 799, otherwise append and feed. Selected, emitted and fed quantities are separate. Final non-EOS token 800 is preserved as audit evidence and omitted from returned output/input; EOS is also not appended/fed. EOS on selection 800 is classified as an actual EOS. Returned text decodes only emitted suffix and strips whitespace. The pinned effective EOS set is explicitly checked as {151645}.

I independently compared the pure-stdlib state machine against the author's literal loop for exhaustion and EOS at indices 0, 100 and 799. Outcomes are respectively 800/799/799, 1/0/0, 101/100/100 and 800/799/799 selected/emitted/fed tokens. All 145 prior raw-vector bindings and K/V metadata/hash references verify, as do the 64 selected-token prefix IDs. Perturbed raw bytes, K/V hashes and selected IDs are rejected. Mismatch evidence is written before refusal. The actual prior 64-token capped result and cleanup receipt are hash-bound and remain failed.

Model, revision, first frozen input, all original chunks, native CPU BF16/eager operations and boundary trim are unchanged. The pager is byte-identical. There is no no-crop or compressed arm. Source hashes and Python syntax validate. The owner's stdlib-only preparation also revalidated full local checkpoint hashes/index and recorded all off-by-one fixtures without importing Torch.

The new phase limit is exactly 3,600 seconds, enforced independently by wall and monotonic clocks, with a separate 180-second cleanup reserve. RSS, live/start host reserve and disk floor are unchanged. Evidence limit increases to 384 MB, with actual serialized JSON lengths and per-record limits checked. The declared serialized envelope is 373,986,816 bytes, below the cap. The guard also caps the diagnostic log and resource-record size. These checks can conservatively stop the run; they cannot silently enlarge it. The single fresh claim prevents automatic repetition.

The 881-call worst-case completion forecast remains slightly longer than the 60-minute phase at attempt-4's mean decode rate, so timeout is a disclosed possible censoring outcome. This review does not promise that every non-EOS trajectory can exhaust all 800 selections. The plan is an author-budget baseline-generation calibration on the frozen CPU input, not full author prompt/runtime/benchmark reproduction.

The semantic rubric remains the predeclared whole-answer standard in PROSPECTIVE_RECOMMENDATION.md: complete, supported latest-known 5–2 with acceptable source-based temporal qualifications, and natural EOS within the declared limit. Retain correct partial facts in any failed/censored answer. Do not infer an ungenerated continuation or relabel the old short-cap failure. All earlier resource and qualification failures remain preserved.

Review details: scoped_review_receipt.json
Reviewer: /root/assess_next_cpu_model_gate
