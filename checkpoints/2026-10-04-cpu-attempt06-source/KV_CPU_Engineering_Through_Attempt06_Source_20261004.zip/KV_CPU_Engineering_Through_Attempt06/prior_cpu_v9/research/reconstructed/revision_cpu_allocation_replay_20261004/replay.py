"""Synthetic allocation/lifetime replay only. No model, config, weights or matmul."""
from pathlib import Path
import argparse,ctypes,gc,hashlib,json,os,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
import torch

class Mallinfo(ctypes.Structure):
    _fields_=[(n,ctypes.c_size_t) for n in ('arena','ordblks','smblks','hblks','hblkhd','usmblks','fsmblks','uordblks','fordblks','keepcost')]
libc=ctypes.CDLL(None);libc.mallinfo2.restype=Mallinfo
libc.malloc_trim.argtypes=[ctypes.c_size_t];libc.malloc_trim.restype=ctypes.c_int

def sample():
    status=Path('/proc/self/status').read_text().splitlines();m=libc.mallinfo2()
    return dict(rss_bytes=next(int(x.split()[1])*1024 for x in status if x.startswith('VmRSS:')),
        highwater_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        mallinfo2={n:int(getattr(m,n)) for n,_ in Mallinfo._fields_})

def run(args):
    if torch.__version__!='2.9.1+cpu' or torch.version.cuda is not None:raise ValueError('Pinned CPU runtime only')
    torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.set_grad_enabled(False)
    root=Path(__file__).resolve().parents[3]
    actual=root/'outputs/revision_cpu_deadline_attempt_03/native_full/calls'
    calls=[json.loads(p.read_text()) for p in sorted(actual.glob('*.json'))]
    if len(calls)!=39:raise ValueError('Exactly39 observed chunk shapes')
    records=[{'call':c['call'],'start':c['start'],'end':c['end'],'chunk':len(c['ids'])} for c in calls]
    out=Path(args.out);out.mkdir(exist_ok=False);start=time.perf_counter()
    protocol=dict(kind='MODEL_FREE_SYNTHETIC_ALLOCATION_REPLAY',mode=args.mode,model_construction=False,
        config_construction=False,weights_loaded=False,LLM_forwards=0,matmul_calls=0,GPU=False,
        shapes=records,KV_layers=36,KV_heads=8,query_heads=32,head_dim=128,dtype='BF16',softmax_scratch='FP32',
        fixed_resident_source_floor_omitted_bytes=922816064,
        limitation='Own touched tensor allocation/lifetime pattern; excludes native kernel workspaces/packing and does not prove actual model memory cause or remedy',
        torch=torch.__version__,threads=4,malloc_trim_scope='Current child process only, no persistent allocator/OS settings')
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    rows=[None]*36;completed=0
    def make(shape,dtype=torch.bfloat16):return torch.empty(shape,dtype=dtype).zero_()
    def append(index,newk,newv):
        old=rows[index]
        if old is None:
            keys=torch.cat([torch.empty(0,dtype=torch.bfloat16),newk],dim=-2)
            values=torch.cat([torch.empty(0,dtype=torch.bfloat16),newv],dim=-2)
        else:
            keys=torch.cat([old[0],newk],dim=-2);values=torch.cat([old[1],newv],dim=-2)
        rows[index]=(keys,values)
        return keys,values
    def layer(index,c,n):
        hidden=make((1,c,2560));query=make((1,32,c,128))
        newk=make((1,c,8,128)).transpose(1,2);newv=make((1,c,8,128)).transpose(1,2)
        keys,values=append(index,newk,newv)
        repeated_k=keys[:,:,None,:,:].expand(1,8,4,n,128).reshape(1,32,n,128)
        repeated_v=values[:,:,None,:,:].expand(1,8,4,n,128).reshape(1,32,n,128)
        mask=make((1,1,c,n));allowed=make((1,1,c,n),torch.bool)
        raw=make((1,32,c,n));scaled=make(raw.shape);del raw
        added=make(scaled.shape);del scaled
        cast_input=make(added.shape,torch.float32);softmax_result=make(added.shape,torch.float32);del cast_input
        probabilities=make(added.shape);del softmax_result,added
        attention_output=make((1,c,4096));projected=make((1,c,2560))
        del repeated_k,repeated_v,probabilities,mask,allowed,attention_output,query,newk,newv
        gate=make((1,c,9728));up=make((1,c,9728));activated=make((1,c,9728));product=make((1,c,9728))
        down=make((1,c,2560))
    with (out/'samples.jsonl').open('w') as log,torch.inference_mode():
        log.write(json.dumps(dict(kind='baseline',sample=sample()))+'\n');log.flush()
        for c in records:
            for index in range(36):layer(index,c['chunk'],c['end'])
            before=sample();collected=gc.collect();after_gc=sample()
            trim_return=libc.malloc_trim(0) if args.mode=='trim' else None
            after=sample();completed+=1
            item=dict(kind='chunk_boundary',call=c['call'],tokens=c['end'],live_KV_bytes=c['end']*36*2*8*128*2,
                pre_gc=before,post_gc=after_gc,post_trim_or_control=after,gc_collected=collected,
                malloc_trim_return=trim_return,elapsed_seconds=time.perf_counter()-start)
            log.write(json.dumps(item)+'\n');log.flush()
    rows.clear();gc.collect();released=sample();ret=libc.malloc_trim(0);trimmed=sample()
    (out/'result.json').write_text(json.dumps(dict(status='COMPLETE',completed_chunks=completed,
        elapsed_seconds=time.perf_counter()-start,after_all_cache_release=released,
        final_diagnostic_trim_return=ret,after_final_trim=trimmed),indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['control','trim'],required=True);parser.add_argument('--out',required=True)
    run(parser.parse_args())
