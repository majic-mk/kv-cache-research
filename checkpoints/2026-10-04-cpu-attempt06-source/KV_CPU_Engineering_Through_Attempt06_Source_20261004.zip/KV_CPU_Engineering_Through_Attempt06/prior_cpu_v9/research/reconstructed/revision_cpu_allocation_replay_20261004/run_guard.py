"""Exactly two bounded fresh synthetic processes; no automatic retries."""
from pathlib import Path
import hashlib,json,os,resource,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
def available():return next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
def table():
    out={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            a=p.read_text().rsplit(')',1)[1].split();out[int(p.parent.name)]=(int(a[1]),int(a[21])*os.sysconf('SC_PAGE_SIZE'))
        except (FileNotFoundError,PermissionError):pass
    return out
def stop(proc):
    if proc is None:return
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait()
if not __debug__:raise RuntimeError('Optimized Python refused')
with (P/'RUN_ONCE.json').open('x') as f:json.dump({'started_unix':time.time(),'source_sha256':hashlib.sha256((P/'replay.py').read_bytes()).hexdigest()},f)
receipts=[];total_start=time.monotonic()
for mode in ['control','trim']:
    if available()<3_000_000_000 or shutil.disk_usage(P).free<5_000_000_000:raise RuntimeError('Initial resource reserve')
    proc=None;start=time.monotonic();peak=0;reason=None;error=None
    command=['bash',str(ROOT/'research/reconstructed/runtime_recovery_20261004/cpu_python.sh'),str(P/'replay.py'),'--mode',mode,'--out',str(P/mode)]
    try:
        with (P/(mode+'.log')).open('w') as log:
            proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            while proc.poll() is None:
                t=table();ids={proc.pid};old=set()
                if proc.pid not in t and proc.poll() is None:raise RuntimeError('Live child absent')
                while old!=ids:
                    old=ids.copy();ids|={pid for pid,(parent,_) in t.items() if parent in ids}
                rss=sum(t[i][1] for i in ids|{os.getpid()} if i in t);peak=max(peak,rss)
                if rss>=2*1024**3:reason='RSS_2GIB'
                elif available()<3_000_000_000:reason='HOST_AVAILABLE_3GB'
                elif shutil.disk_usage(P).free<5_000_000_000:reason='DISK_5GB'
                elif sum(p.stat().st_size for p in P.rglob('*') if p.is_file())>=5_000_000:reason='LOGS_5MB'
                elif time.monotonic()-start>=30 or time.monotonic()-total_start>=60:reason='WALL_LIMIT'
                if reason:stop(proc);break
                time.sleep(.02)
            proc.wait()
    except BaseException as e:error=repr(e);raise
    finally:
        stop(proc)
        receipt={'mode':mode,'exit_code':None if proc is None else proc.returncode,'termination':reason,'guard_error':error,
            'wall_seconds':time.monotonic()-start,'combined_peak_rss_bytes':peak,'command':command,'maximum_wall_seconds':30,
            'maximum_child_CPU_seconds':60,'maximum_combined_RSS_bytes':2*1024**3}
        receipts.append(receipt);(P/(mode+'_guard.json')).write_text(json.dumps(receipt,indent=2)+'\n')
r=resource.getrusage(resource.RUSAGE_CHILDREN)
(P/'guard_summary.json').write_text(json.dumps({'attempts':receipts,'total_wall_seconds':time.monotonic()-total_start,
    'total_child_CPU_seconds':r.ru_utime+r.ru_stime,'model_calls':0,'GPU':False},indent=2)+'\n')
print((P/'guard_summary.json').read_text())
