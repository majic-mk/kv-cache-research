"""Independent, finite tiny-only guard. Preserves failed and successful attempts."""
from pathlib import Path
import hashlib,json,os,resource,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent; ROOT=P.parents[2]
def table():
    result={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=p.read_text().rsplit(')',1)[1].split()
            result[int(p.parent.name)]=(int(fields[1]),int(fields[21])*os.sysconf('SC_PAGE_SIZE'))
        except (OSError,ValueError,IndexError):pass
    return result
if not __debug__:raise RuntimeError('Optimized Python refused')
old=list(P.glob('attempt_*/guard.json'))
spent=sum(json.loads(p.read_text()).get('cpu_seconds',0) for p in old)
if spent>=100:raise RuntimeError('Cumulative 120-second tiny CPU budget exhausted')
if shutil.disk_usage(P).free<5_000_000_000:raise RuntimeError('Disk reserve')
out=P/f'attempt_{len(old)+1:02d}';out.mkdir();(out/'source').mkdir()
for name in ('file_pager.py','verify_tiny.py','run_guard.py','cpu_release.py'):shutil.copyfile(P/name,out/'source'/name)
cmd=['bash',str(ROOT/'research/reconstructed/runtime_recovery_20261004/cpu_python.sh'),str(P/'verify_tiny.py'),str(out)]
start=time.monotonic();peak=0;stop=None
with (out/'run.log').open('w') as log:
    proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    while proc.poll() is None:
        records=table();ids={proc.pid};prior=set()
        while ids!=prior:
            prior=ids.copy();ids|={i for i,(parent,rss) in records.items() if parent in ids}
        rss=sum(records[i][1] for i in ids|{os.getpid()} if i in records);peak=max(peak,rss)
        if rss>=1024**3:stop='COMBINED_RSS_1GIB'
        if time.monotonic()-start>=120:stop='WALL_120_SECONDS'
        if shutil.disk_usage(P).free<5_000_000_000:stop='DISK_5GB_RESERVE'
        if sum(p.stat().st_size for p in P.rglob('*') if p.is_file())>20_000_000:stop='RETAINED_20MB'
        if stop:os.killpg(proc.pid,signal.SIGKILL);proc.wait();break
        time.sleep(.025)
rc=proc.wait();r=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt=dict(exit_code=rc,termination=stop,wall_seconds=time.monotonic()-start,cpu_seconds=r.ru_utime+r.ru_stime,
             combined_sampled_peak_rss_bytes=peak,rss_limit_bytes=1024**3,
             cumulative_cpu_seconds=spent+r.ru_utime+r.ru_stime,child_rlimit_cpu_seconds=90,
             disk_free_bytes=shutil.disk_usage(P).free,command=cmd,
             source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'source').iterdir()})
(out/'guard.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print((out/'run.log').read_text());raise SystemExit(rc)
