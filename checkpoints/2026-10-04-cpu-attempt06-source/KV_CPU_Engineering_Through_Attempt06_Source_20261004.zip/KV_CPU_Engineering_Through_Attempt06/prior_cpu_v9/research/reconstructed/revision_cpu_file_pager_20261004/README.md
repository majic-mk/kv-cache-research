# CPU file-pager correctness preparation

Status: **tiny correctness and model-free contract tests passed; actual inference remains closed pending independent source review and parent launch GO**.
This is a separate prospective CPU path. The frozen GPU packet and its inputs are unchanged.
Pinned checkpoint acquisition is separately owned and authorized; this packet never downloads anything.

`file_pager.py` leaves the installed official `torch.nn.Linear.forward`, Qwen3 layers,
attention, q_norm/k_norm, RMSNorm and RoPE methods unchanged. A leaf pre-hook reads its
exact BF16 weight from a validated safetensors offset into one exclusive BF16 arena.
An always-call post-hook restores that leaf's original meta Parameter, including when
the native forward or a later pre-hook raises. The tied embedding/output head shares
one resident allocation; native norm parameters are resident BF16, and the constructor's
FP32 RoPE is rebuilt using the same official native rotary constructor on CPU.
No model-wide `.to(dtype=...)` cast, quantization, whole-model state dictionary,
memory-mapped residency assumption, or OS swap is involved.

The source header checks byte extents, shape/dtype agreement, exact parameter coverage,
duplicate keys/shards, tensor overlap/gaps and trailing data before allocating payloads.
The reader supports multiple shards and short reads, charges partial failed reads, and
unwinds a partly installed hook set. The tiny path has a fewer-than-100,000-parameter cap.
The actual path requires `cpu_release.py` to be explicitly released after review, exact
4,022,468,096 parameter count and all three pinned shard names, sizes and hashes.
`actual_common.py` also verifies every metadata/tokenizer file and index/header mapping.
Ordinary symlinks to the exact owned browser downloads are supported; hashes are streamed
through the target, and open target inode/size/mtime identities are checked between calls.

## Observed evidence

The preserved first attempt used one synthetic shard and passed seven groups. Later attempts
added three-shard addressing and failure cleanup. The final fourth attempt passed ten
groups, using the actual runner's last-token-only head shape. It compared a fixed
21,728-parameter, tied-embedding random tiny Qwen3 with its own serialized BF16 bytes:

- Resident native, file-paged native, and file-paged gate/no-crop paths had exact logits
  and all layer K/V bytes across five multi-token/single-token chunks plus four decode inputs
- Every paged weight matched its source tensor's byte hash, including three-shard addressing
- Native methods, tied identity, CPU FP32 rotary bytes and idle meta storage were preserved
- Forward-error and later-pre-hook-error paths both restored the exact meta Parameter
- Context exit released file descriptors, hooks and the arena
- Negative offsets, duplicate shard inputs and actual-weight admission were refused
- Failed partial reads preserved charged bytes/time; wrong destination dtype was refused
- A hook-registration failure released hooks and descriptors already acquired

Final run: 4.0183 seconds wall, 3.9870 seconds child CPU, 354,349,056 bytes sampled combined
monitor/child peak RSS. All four attempts used 14.5589 CPU seconds total. The final proof used
one 4,096-byte arena per paged path. Native paged reads, including explicit tensor-byte
verification and failure tests, totaled 379,336 bytes in 0.000578 seconds. The no-crop
path read 338,368 bytes in 0.000542 seconds. These are tiny, buffered, likely cached reads;
they are **not** measured cold-disk throughput or a projection of 4B performance.

All attempt sources, logs, synthetic tensors, range maps, byte hashes, per-call traces
and guard receipts are retained. The test invokes only installed official runtime code
and this own source. It does not load the real trained gate or any pretrained backbone.

Run the same finite tiny proof with:

```sh
python research/reconstructed/revision_cpu_file_pager_20261004/run_guard.py
```

The guard samples the process tree, enforces a 1 GiB tiny RSS ceiling, 120-second wall,
90-second child CPU limit, 5 GB free disk and 20 MB retained evidence. Its RSS guard is
sampled; this host exposes no usable hard memory cgroup. It preserves every attempt.

## Concrete actual-case proposal, not executed

The companion [`prospective_cpu_protocol_v2.json`](../revision_cpu_feasibility_20261004/prospective_cpu_protocol_v2.json)
freezes the exact first existing variant, `c7dc5443__reservoir_before__low_zero`, all 7,669
canonical IDs and their original 82 chunk boundaries. A future run would execute native
Full then trained-gate-loaded no-crop, sequentially, with at most 64 output tokens each.
Only one Full cache may exist at a time; first-pass evidence is logits plus append hashes,
not a retained cache clone. Qualification requires native answer competence from the full
source and exact no-crop chunk-logit/KV-append/answer/EOS parity. No eviction arm is included.

The pinned model's steady source storage is 778,304,512 resident embedding/norm bytes plus
a 49,807,360-byte arena. Worst allowed Full KV is 1,140,129,792 bytes. The real gate adds
94,704,192 bytes. Explicit eager attention repeats, softmax scratch, per-layer cache append
coexistence and runtime allocations must be measured, but this leaves substantial margin
under the proposed 6 GiB process-tree ceiling. Available host memory must remain >=1.5 GB;
free disk must remain >=5 GB. A second copy of checkpoint shards is forbidden.

Time is the unresolved limitation. Every chunk or ingested decode token reads
7,266,631,680 decoder bytes. The unchanged pair requests between roughly 1.19 TB (immediate
EOS) and 2.11 TB (maximum decode allowance), plus initial resident loading and hashing.
The worst pair needs approximately 1.17 GB/s logical read throughput just to spend its
entire 1,800-second model window on reads, leaving no compute time. Current evidence
neither demonstrates that bandwidth nor proves the window impossible. A 4B speed claim
cannot be inferred from the tiny read timer or standalone operator benchmarks.

After reviewed parent launch GO, the minimum real next step is one guarded attempt of this
fixed pair. Measure actual read/copy time, `/proc`
I/O counters, RSS, host availability and complete call time; stop after the first three
calls if the protocol's conservative projection cannot fit the remaining 1,800-second
combined-pair window. Recheck at every call. Preserve partial evidence, do not silently
retry, enlarge the wall, change chunks, shorten the prompt, quantize or substitute a model.
Layer-major prefill could reduce reads but is a separate scheduling adaptation and is
not part of this proposal.

## Prepared actual runner and guard

`actual_runner.py` and `actual_guard.py` are prepared and source-hard-locked. Seven
stdlib contract groups passed in 0.47 seconds without importing Torch or calling a model.
They cover exact input/protocol/acquisition bindings, normal and optimized-Python refusal,
semantic reviewer/result/source/EOS bindings, immutable results/vectors, expired deadlines,
missing-process refusal and termination of a harmless owned test process group.

The actual guard uses a fresh output directory and an exclusive one-attempt claim. It
checks process-tree RSS <=6 GiB, start host availability >=6 GB and running availability
>=1.5 GB, free disk >=5 GB, evidence <=256 MB and the absolute deadline every 0.1 seconds.
Any watchdog exception also terminates the owned process group; group disappearance is
reported only when verified. No hard cgroup is available. It cannot replace the browser
download process's separate accounting; concurrent memory pressure is covered by the
host-available-memory threshold.

The one acquisition clock started at **2026-10-04 16:28:20.316980 UTC**. The compute cutoff
is `min(actual guard start + 1800 seconds, 17:28:20.316980 UTC - 180 seconds)`.
There is no reset on acquisition retries, semantic review or arm transition. The reviewer
must atomically publish `semantic_review.json` inside the run output directory after
`progress.json` reports `awaiting_semantic_review`. Native result/cache evidence is
immutable; the Full cache is released while the one resident model, pager and gate stay
loaded. Required semantic fields are specified in protocol v2. Qualified historical plus
current answers are accepted; an old-name substring is not a failure rule.

Both arms save original BF16 full-vocabulary vectors for every supplied chunk and ingested
decode call, all generated IDs and raw answers, per-layer appended K/V hashes, mask/position
metadata, gate state hashes, timings and resource samples. Cap-hit answers and offending
numerical/parity vectors are saved before stopping. Mutable progress files are separate
from immutable case records. No-crop starts only after valid semantic approval, and exact
parity failures stop without tolerance changes or retries.

Future launch, only after the lock is explicitly released by the reviewed parent action:

```sh
python research/reconstructed/revision_cpu_file_pager_20261004/actual_guard.py \
  --base outputs/revision_cpu_model_assets_20261004 \
  --acquisition-receipt outputs/revision_cpu_model_assets_20261004/acquisition_start.json \
  --out outputs/revision_cpu_first_input_attempt_01
```

This command has not been executed. The old GPU lock/config remain unchanged. Neither tiny
nor source-contract evidence establishes pretrained answer quality, 4B runtime feasibility,
eviction effects or any GPU benefit.
