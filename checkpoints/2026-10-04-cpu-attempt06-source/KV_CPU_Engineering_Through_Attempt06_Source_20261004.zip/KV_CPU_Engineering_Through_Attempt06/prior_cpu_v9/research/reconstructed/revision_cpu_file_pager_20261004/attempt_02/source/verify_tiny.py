"""Random tiny file-I/O correctness only. No downloaded or pretrained tensors."""
from pathlib import Path
import copy
import hashlib
import json
import os
import resource
import struct
import sys
import time
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
import torch
from safetensors.torch import save_file
from transformers import Qwen3Config, Qwen3ForCausalLM
from transformers.cache_utils import DynamicCache
from transformers.models.qwen3 import modeling_qwen3 as qwen
from file_pager import FilePager, read_header, require


def rawhash(value):
    return hashlib.sha256(value.detach().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()


def build(config, meta=False):
    prior = torch.get_default_dtype(); torch.set_default_dtype(torch.bfloat16)
    try:
        with torch.device('meta' if meta else 'cpu'):
            model = Qwen3ForCausalLM(copy.deepcopy(config)).eval()
    finally:
        torch.set_default_dtype(prior)
    if meta:
        model.model.rotary_emb = qwen.Qwen3RotaryEmbedding(config=model.config)
    return model


class NoCrop:
    """Minimal own no-crop loop, with native layers and causal absolute positions."""
    def __init__(self, model, gates):
        self.model = model; self.gates = gates; self.cache = DynamicCache(config=model.config)
        self.seen = 0; self.gate_values = {}

    def step(self, ids):
        from torch.nn import functional as F
        positions = torch.arange(self.seen, self.seen+ids.shape[1]).unsqueeze(0)
        hidden = self.model.model.embed_tokens(ids)
        rope = self.model.model.rotary_emb(hidden, positions)
        keys = torch.arange(self.seen+ids.shape[1])
        allow = keys.reshape(1,1,1,-1) <= positions.reshape(1,1,-1,1)
        mask = torch.zeros(allow.shape, dtype=hidden.dtype).masked_fill_(~allow, torch.finfo(hidden.dtype).min)
        for i,layer in enumerate(self.model.model.layers):
            def gate_hook(module,args,kwargs,index=i):
                x = kwargs['hidden_states']; w1,b1,w2,bias = self.gates[index]
                gate = F.logsigmoid(F.linear(F.silu(F.linear(x,w1,b1)),w2)+bias).transpose(1,2)
                self.gate_values[index] = torch.cat([self.gate_values[index],gate],dim=-1) if index in self.gate_values else gate
            handle = layer.self_attn.register_forward_pre_hook(gate_hook,with_kwargs=True)
            try:
                hidden = layer(hidden, attention_mask=mask, position_embeddings=rope,
                               position_ids=positions, past_key_values=self.cache, use_cache=True)
            finally:
                handle.remove()
        self.seen += ids.shape[1]
        return self.model.lm_head(self.model.model.norm(hidden))


def run(out):
    started = time.perf_counter(); torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.manual_seed(3407)
    c = Qwen3Config(vocab_size=97, hidden_size=32, intermediate_size=64,
        num_hidden_layers=2, num_attention_heads=4, num_key_value_heads=2, head_dim=8,
        max_position_embeddings=256, attention_dropout=0., tie_word_embeddings=True)
    c._attn_implementation = 'eager'
    resident = build(c)
    tensors=list(resident.named_parameters());sources=[];records={}
    for index in range(3):
        source=out/f'synthetic_tiny-{index+1:05d}-of-00003.safetensors'
        save_file({name:p.detach().contiguous() for name,p in tensors[index::3]},source)
        sources.append(source)
        records.update({key:dict(value,shard=index) for key,value in read_header(source).items()})
    original_source_hash = [hashlib.sha256(path.read_bytes()).hexdigest() for path in sources]
    tensor_hashes = {name:rawhash(p) for name,p in resident.named_parameters()}
    paged = build(c,meta=True); adapter_model = build(c,meta=True)
    generator = torch.Generator().manual_seed(2718)
    gates = [[torch.randn(shape,generator=generator).to(torch.bfloat16)*.15
              for shape in ((16,32),(16,),(2,16),(2,))] for _ in range(2)]
    canonical = [3,17,9,9,18,21,4,25,63,15,17,73,11,14,55]
    bounds = [(0,3),(3,4),(4,8),(8,10),(10,15)]
    trace = []; checks = []; snapshots = []
    original_linear_forward = torch.nn.Linear.forward
    with FilePager(paged,sources,synthetic=True) as pager, FilePager(adapter_model,sources,synthetic=True) as adapter_pager, torch.inference_mode():
        adapter = NoCrop(adapter_model,gates)
        native_cache = DynamicCache(config=c); paged_cache = DynamicCache(config=c)
        for iteration in range(len(bounds)+4):
            ids = torch.tensor([canonical[bounds[iteration][0]:bounds[iteration][1]]]) if iteration < len(bounds) else next_ids
            expected = resident(ids,past_key_values=native_cache,use_cache=True).logits
            observed = paged(ids,past_key_values=paged_cache,use_cache=True).logits
            no_crop = adapter.step(ids)
            require(torch.equal(expected,observed), 'Paged native logit mismatch')
            require(torch.equal(expected,no_crop), 'Paged no-crop logit mismatch')
            layer_hashes = []
            for index in range(2):
                hashes = {}
                for name in ('keys','values'):
                    value = getattr(native_cache.layers[index],name)
                    require(torch.equal(value,getattr(paged_cache.layers[index],name)), 'Native paged KV mismatch')
                    require(torch.equal(value,getattr(adapter.cache.layers[index],name)), 'No-crop KV mismatch')
                    hashes[name] = rawhash(value)
                layer_hashes.append(hashes)
            pager.assert_idle(); adapter_pager.assert_idle()
            trace.append(dict(call=iteration,ids=ids.tolist(),logits_sha256=rawhash(expected),cache_hashes=layer_hashes))
            next_ids = expected[:,-1].argmax(-1).reshape(1,1)
        checks.append('native_resident_vs_file_paged_and_gate_no_crop_exact_logits_and_KV_every_call')
        require(torch.nn.Linear.forward is original_linear_forward, 'Native forward was replaced')
        require(all(p.device.type=='meta' for p in pager.meta.values()), 'Unexpected retained paged source')
        require(paged.lm_head.weight is paged.model.embed_tokens.weight, 'Tie identity')
        require(rawhash(paged.model.rotary_emb.inv_freq)==rawhash(resident.model.rotary_emb.inv_freq), 'RoPE bytes changed')
        checks.append('unchanged_native_methods_tied_identity_FP32_RoPE_and_idle_meta_storage')
        for key,module in pager.paged.items():
            view = pager.arena[:module.weight.numel()].view(module.weight.shape)
            pager.read_into(key,view)
            require(rawhash(view)==tensor_hashes[key], 'Source offset tensor bytes mismatch')
        checks.append('every_paged_tensor_exact_file_offset_bytes_across_three_shards')
        target = paged.model.layers[0].self_attn.q_proj
        try:
            target(torch.ones((1,1,31),dtype=torch.bfloat16))
            raise RuntimeError('Expected invalid-matmul failure')
        except RuntimeError as error:
            require('Expected invalid-matmul' not in str(error),str(error))
        pager.assert_idle()
        def fail_after_bind(module,args):
            raise RuntimeError('injected prehook exception')
        h = target.register_forward_pre_hook(fail_after_bind)
        try:
            try:
                target(torch.ones((1,1,32),dtype=torch.bfloat16))
                raise ValueError('Missing injected exception')
            except RuntimeError as error:
                require(str(error)=='injected prehook exception','Wrong injected failure')
        finally:
            h.remove()
        pager.assert_idle()
        checks.append('leaf_forward_and_later_prehook_exception_restore_exact_meta_parameter')
        snapshots = [dict(pager.stats),dict(adapter_pager.stats)]
    require(not pager.handles and not pager.fds and pager.arena is None,'Close did not release resources')
    require(not adapter_pager.handles and not adapter_pager.fds,'Adapter close did not release resources')
    checks.append('context_exit_closes_descriptors_arena_and_hooks')
    payload = sources[0].read_bytes(); length = struct.unpack('<Q',payload[:8])[0]
    header = json.loads(payload[8:8+length]); first = next(k for k in header if k!='__metadata__')
    header[first]['data_offsets'][0] = -1
    raw = json.dumps(header,separators=(',',':')).encode()
    corrupt = out/'malformed_negative_offset.safetensors'
    corrupt.write_bytes(struct.pack('<Q',len(raw))+raw+payload[8+length:])
    try:
        read_header(corrupt)
        raise RuntimeError('Malformed range accepted')
    except ValueError:
        pass
    checks.append('malformed_negative_source_offset_refused_before_payload_read')
    try:
        FilePager(build(c,meta=True),sources,synthetic=False)
        raise RuntimeError('Real-weight admission unexpectedly open')
    except ValueError as error:
        require('hard-locked' in str(error),'Wrong refusal reason')
    checks.append('real_weight_admission_remains_closed')
    try:
        FilePager(build(c,meta=True),sources+[sources[0]],synthetic=True)
        raise RuntimeError('Duplicate shard accepted')
    except ValueError as error:
        require('Duplicate source shard' in str(error),'Wrong duplicate refusal reason')
    checks.append('duplicate_source_shard_refused')
    require([hashlib.sha256(path.read_bytes()).hexdigest() for path in sources]==original_source_hash,'Source file mutated')
    report=dict(status='PASS',scope='RANDOM_TINY_FILE_PAGING_CORRECTNESS_ONLY',groups=checks,
        model_parameters=sum(p.numel() for p in resident.parameters()),calls_per_path=len(trace),
        dtype='BF16',native_exact_parity=True,synthetic_gate_quality_claim=False,
        torch=torch.__version__,transformers=__import__('transformers').__version__,
        qwen3_source_sha256=hashlib.sha256(Path(qwen.__file__).read_bytes()).hexdigest(),
        source_sha256=original_source_hash,source_records=records,tensor_sha256=tensor_hashes,
        native_append_and_logits_trace=trace,pager_cost=snapshots,
        elapsed_seconds=time.perf_counter()-started,cpu_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
        peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        actual_4b_weights=False,model_download=False,GPU=False,
        read_timing_interpretation='Tiny local buffered reads, likely page-cache hits; not cold disk throughput or 4B runtime prediction')
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','groups','model_parameters','calls_per_path','elapsed_seconds','cpu_seconds','peak_rss_bytes','pager_cost')},indent=2))


if __name__=='__main__':
    out=Path(sys.argv[1]); out.mkdir(exist_ok=True)
    run(out)
