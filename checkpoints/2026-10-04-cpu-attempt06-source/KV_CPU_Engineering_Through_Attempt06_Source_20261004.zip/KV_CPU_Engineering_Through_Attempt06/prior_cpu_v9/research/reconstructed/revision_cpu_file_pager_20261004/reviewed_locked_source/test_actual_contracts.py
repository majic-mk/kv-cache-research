"""Stdlib-only negative fixtures. Never release/import an actual model backend."""
from pathlib import Path
import copy,json,subprocess,sys,tempfile,time
from actual_common import (HERE,ROOT,PROTOCOL_SHA256,INPUT_SHA256,load_protocol,load_row,
    acquisition_anchor,semantic_review,sha_file,write_json,Evidence)
from actual_guard import process_tree_rss,stop_group
from file_pager import require

def rejected(fn,message):
    try:fn()
    except (ValueError,RuntimeError,FileExistsError):return
    raise AssertionError(message)

def main():
    groups=[];start=time.perf_counter()
    protocol=load_protocol();row=load_row(protocol)
    anchor=ROOT/'outputs/revision_cpu_model_assets_20261004/acquisition_start.json'
    stamp,digest=acquisition_anchor(anchor)
    require(stamp==1791131300.31698 and len(row['online_chunk_end_indices'])==82,'Fixed protocol/input/start')
    groups.append('pinned_protocol_input_ids_chunks_and_actual_acquisition_anchor')
    for optimize in ([],['-O']):
        for script,extra in (('actual_guard.py',[]),('actual_runner.py',['--guard-pid','1','--deadline','1'])):
            command=[sys.executable,*optimize,str(HERE/script),'--out','/tmp/never_cpu_smoke','--base','/tmp/never_base',
                     '--acquisition-receipt','/tmp/never_receipt',*extra]
            result=subprocess.run(command,capture_output=True,text=True,timeout=5)
            require(result.returncode!=0 and ('hard-locked' in result.stderr or 'Optimized Python' in result.stderr),'Entry point did not refuse')
    groups.append('both_real_entry_points_refuse_normal_and_optimized_python')
    with tempfile.TemporaryDirectory(prefix='contracts_',dir=HERE) as directory:
        folder=Path(directory);result=folder/'result.json';write_json(result,{'fixture_only':True})
        binding={'run_id':'fixture','canonical_ids_sha256':row['canonical_ids_sha256']}
        valid=dict(method='independent_researcher_or_agent_semantic_source_review',reviewer='fixture-reviewer',
            rationale='Fixture tests binding only and do not admit a real run.',source_reference='frozen source fixture',
            frozen_input_file_sha256=INPUT_SHA256,native_full_result_sha256=sha_file(result),cpu_protocol_sha256=PROTOCOL_SHA256,
            run_id='fixture',canonical_ids_sha256=row['canonical_ids_sha256'],full_semantically_correct=True,
            complete_and_supported=True,eos_reached=True,cap_hit=False)
        review=folder/'review.json';write_json(review,valid);semantic_review(review,result,binding)
        for key,value in [('run_id','other'),('native_full_result_sha256','0'*64),('cpu_protocol_sha256','0'*64),
                          ('frozen_input_file_sha256','0'*64),('canonical_ids_sha256','0'*64),('reviewer',''),
                          ('rationale',''),('source_reference',''),('full_semantically_correct',False),
                          ('complete_and_supported',False),('eos_reached',False),('cap_hit',True)]:
            changed=dict(valid);changed[key]=value;write_json(review,changed)
            rejected(lambda:semantic_review(review,result,binding),'Wrong semantic binding admitted: '+key)
        groups.append('semantic_review_exact_run_source_result_protocol_EOS_and_named_judgment_bindings')
        e=Evidence(folder,binding,time.time()+60)
        e.json('immutable.json',{'a':1});rejected(lambda:e.json('immutable.json',{'a':2}),'Result overwritten')
        e.vector('tensor.bin.gz',b'123',{'shape':[3]});rejected(lambda:e.vector('tensor.bin.gz',b'456',{'shape':[3]}),'Raw vector overwritten')
        e.json('progress.json',{'a':1});e.json('progress.json',{'a':2})
        groups.append('immutable_results_and_vectors_separate_from_mutable_progress')
        rejected(lambda:Evidence(folder,binding,time.time()-1).check(),'Expired evidence deadline accepted')
        groups.append('expired_compute_deadline_refused')
    rejected(lambda:process_tree_rss({},999999),'Missing live child treated as zero RSS')
    require(process_tree_rss({17:(1,100),18:(17,200)},17)==300,'Child tree accounting')
    groups.append('process_tree_children_counted_missing_live_leader_refused')
    child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],start_new_session=True)
    require(stop_group(child) and child.poll() is not None,'Owned child group remained alive')
    groups.append('owned_process_group_cleanup_verified_on_harmless_stdlib_child')
    require('torch' not in sys.modules,'Model-free contracts imported Torch')
    report=dict(status='PASS',groups=groups,torch_imported=False,model_calls=0,GPU=False,elapsed_seconds=time.perf_counter()-start)
    path=HERE/'actual_contracts_result.json';require(not path.exists(),'Preserve prior contract receipt')
    write_json(path,report);print(json.dumps(report,indent=2))

if __name__=='__main__':main()
