"""Parent launch authorization still required after independent actual-code review."""
CPU_EXECUTION_RELEASED = False
def require_cpu_release():
    if not __debug__:
        raise ValueError('Optimized Python is unsupported')
    if not CPU_EXECUTION_RELEASED:
        raise ValueError('Actual CPU weights/inference remain hard-locked pending reviewed parent launch GO')
