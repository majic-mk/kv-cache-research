"""Read-only asset/prefix checks and stdlib mismatch fixtures. No Torch import."""
from pathlib import Path
import copy,gzip,hashlib,json,sys,time
from actual_common import (HERE,ROOT,load_protocol,load_row,load_reference_prefix,compare_reference_prefix,
                           verify_base,verify_asset_identities,write_json,source_integrity,host_available)
from file_pager import require

started=time.perf_counter();p=load_protocol();row=load_row(p);references=load_reference_prefix(p)
positive=0
for reference in references:
    raw=gzip.decompress(Path(reference['vector_path']).read_bytes())
    require(compare_reference_prefix(reference['entry'],raw,reference)['passed'],'Identical raw reference rejected')
    positive+=1
reference=references[0];entry=copy.deepcopy(reference['entry']);raw=gzip.decompress(Path(reference['vector_path']).read_bytes())
changed=bytearray(raw);changed[-1]^=1
require(not compare_reference_prefix(entry,bytes(changed),reference)['passed'],'Changed raw vector accepted')
entry=copy.deepcopy(reference['entry']);entry['appended_KV'][0]['keys']['sha256']='0'*64
require(not compare_reference_prefix(entry,raw,reference)['passed'],'Changed KV hash accepted')
entry=copy.deepcopy(reference['entry']);entry['start']+=1
require(not compare_reference_prefix(entry,raw,reference)['passed'],'Changed original position accepted')
require(p['engineering_window']['old_window_extended'] is False and p['engineering_window']['model_phase_max_seconds']==1800
        and p['engineering_window']['cleanup_reserve_seconds']==180,'Explicit new budget contract')
base=ROOT/'outputs/revision_cpu_model_assets_20261004';identity=verify_asset_identities(base,p)
hash_started=time.perf_counter();shards,receipts,records=verify_base(base,p);hash_seconds=time.perf_counter()-hash_started
require('torch' not in sys.modules,'Preparation check unexpectedly imported Torch')
receipt=dict(status='READ_ONLY_PREPARATION_CHECKS_PASS',source_manifest_sha256=source_integrity(),protocol_sha256=hashlib.sha256((HERE/'protocol.json').read_bytes()).hexdigest(),
    prefix_files_verified=39,positive_full_raw_comparisons=positive,negative_raw_byte_KV_hash_position_fixtures_passed=True,
    old_window_extended=False,new_model_phase_seconds=1800,cleanup_reserve_seconds=180,
    asset_identity=identity,all_pinned_files=receipts,index_tensor_count=len(records),full_file_hash_seconds=hash_seconds,
    elapsed_seconds=time.perf_counter()-started,host_available_bytes=host_available(),torch_imported=False,model_calls=0,GPU=False)
target=HERE/'preparation_checks.json';require(not target.exists(),'Preserve the prior check receipt');write_json(target,receipt)
print(json.dumps({k:receipt[k] for k in ['status','source_manifest_sha256','prefix_files_verified','index_tensor_count','full_file_hash_seconds','elapsed_seconds','host_available_bytes','torch_imported','model_calls']},indent=2))
