"""Independent process-tree watchdog; every exceptional exit kills its child group."""
from pathlib import Path
import argparse,json,os,resource,shutil,signal,subprocess,sys,time,traceback
from cpu_release import require_cpu_release
from actual_common import (HERE,ROOT,PROTOCOL_SHA256,acquisition_anchor,host_available,
    load_protocol,source_integrity,write_json,json_read)
from file_pager import require

def process_table():
    result={}
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=path.read_text().rsplit(')',1)[1].split()
            result[int(path.parent.name)]=(int(fields[1]),int(fields[21])*os.sysconf('SC_PAGE_SIZE'))
        except FileNotFoundError:pass  # process exited between list and read
        except PermissionError:pass   # unrelated OS processes may be inaccessible
    return result

def process_tree_rss(records,pid):
    require(pid in records,'Live model child missing from process inventory')
    children={pid};previous=set()
    while children!=previous:
        previous=children.copy();children|={i for i,(parent,rss) in records.items() if parent in children}
    return sum(records[i][1] for i in children|{os.getpid()} if i in records)

def stop_group(proc):
    if proc is None:return True
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait()
    for _ in range(5):
        try:os.killpg(proc.pid,0)
        except ProcessLookupError:return True
        time.sleep(.05)
    return False  # do not claim a vanished group without observed evidence

def main(args):
    require_cpu_release()  # before child launch, source payload read or model import
    protocol=load_protocol();source_sha=source_integrity()
    start,receipt_sha=acquisition_anchor(args.acquisition_receipt)
    require(time.time()>start+3600,'Prior execution window must already be closed')
    now=time.time();deadline=now+1800;cleanup_deadline=deadline+180
    monotonic_start=time.monotonic();monotonic_deadline=monotonic_start+1800
    require(host_available()>=6_000_000_000,'Start host MemAvailable below 6GB')
    base=Path(args.base).resolve();out=Path(args.out).resolve()
    require(base==(ROOT/'outputs/revision_cpu_model_assets_20261004').resolve(),'Fixed acquired asset directory')
    require(json_read(base/'acquisition_complete.json')['status']=='ALL_PINNED_ASSETS_VERIFIED_NO_MODEL_LOAD','Assets not ready')
    acquisition_guard=json_read(base/'acquisition_guard.json')
    require(acquisition_guard.get('returncode')==0 and not acquisition_guard.get('stop_reason'),'Acquisition guard did not succeed')
    require(not out.exists(),'Fresh evidence directory required; no hidden retry')
    require(out.parent.resolve()==(ROOT/'outputs').resolve(),'Evidence must be directly under outputs')
    require(shutil.disk_usage(out.parent).free>=5_256_000_000,'Disk reserve plus full evidence allowance')
    claim=HERE/'ACTUAL_ATTEMPT_CLAIM.json'
    with claim.open('x') as f:json.dump(dict(run_id=out.name,out=str(out),started_unix=now,source_sha256=source_sha),f)
    out.mkdir()
    launch=dict(run_id=out.name,guard_pid=os.getpid(),out=str(out),base=str(base),
        acquisition_receipt_sha256=receipt_sha,historical_acquisition_start_unix=start,
        historical_window_deadline_unix=start+3600,overall_deadline_unix=cleanup_deadline,
        new_engineering_budget=True,old_window_extended=False,monotonic_model_deadline=monotonic_deadline,
        model_phase_start_unix=now,effective_deadline_unix=deadline,source_manifest_sha256=source_sha,
        cpu_protocol_sha256=PROTOCOL_SHA256,limits=protocol['limits'])
    write_json(out/'guard_launch.json',launch)
    command=[str(ROOT/protocol['runtime']['python_executable']),str(HERE/'actual_runner.py'),
             '--out',str(out),'--base',str(base),'--acquisition-receipt',str(Path(args.acquisition_receipt).resolve()),
             '--guard-pid',str(os.getpid()),'--deadline',str(deadline)]
    environment=os.environ.copy();environment.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        HF_HUB_DISABLE_TELEMETRY='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    proc=None;stop=None;peak=0;minimum_available=host_available();exception=None;rc=None
    try:
        with (out/'runner.log').open('w') as log,(out/'resource_samples.jsonl').open('w') as samples:
            proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=environment)
            while proc.poll() is None:
                records=process_table()
                if proc.pid not in records and proc.poll() is not None:break
                rss=process_tree_rss(records,proc.pid)
                available=host_available();free=shutil.disk_usage(out).free
                retained=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
                peak=max(peak,rss);minimum_available=min(minimum_available,available)
                sample=dict(unix_time=time.time(),tree_rss_bytes=rss,host_available_bytes=available,free_disk_bytes=free,evidence_bytes=retained)
                samples.write(json.dumps(sample)+'\n');samples.flush()
                if rss>=6*1024**3:stop='PROCESS_TREE_RSS_6GIB'
                elif available<1_500_000_000:stop='HOST_AVAILABLE_BELOW_1_5GB'
                elif free<5_000_000_000:stop='FREE_DISK_BELOW_5GB'
                elif retained>=256_000_000:stop='EVIDENCE_256MB'
                elif time.time()>=deadline or time.monotonic()>=monotonic_deadline:stop='NEW_ENGINEERING_MODEL_DEADLINE'
                if stop:stop_group(proc);break
                time.sleep(.1)
            rc=proc.wait()
    except BaseException as error:
        exception=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
        stop='WATCHDOG_EXCEPTION'
        raise
    finally:
        group_gone=stop_group(proc)
        if proc is not None:rc=proc.returncode
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        write_json(out/'guard_result.json',dict(exit_code=rc,termination=stop,watchdog_exception=exception,
            sampled_peak_process_tree_rss_bytes=peak,minimum_host_available_bytes=minimum_available,
            elapsed_seconds=time.time()-now,child_cpu_seconds=usage.ru_utime+usage.ru_stime,
            effective_deadline_unix=deadline,overall_deadline_unix=cleanup_deadline,
            new_engineering_budget=True,old_window_extended=False,command=command,
            source_manifest_sha256=source_sha,owned_process_group_absence_verified=group_gone,
            owned_process_group_termination_attempted=proc is not None,GPU=False))
    require(rc==0 and stop is None,'Actual pair stopped or failed; preserve partial evidence')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);parser.add_argument('--base',required=True)
    parser.add_argument('--acquisition-receipt',required=True);main(parser.parse_args())
