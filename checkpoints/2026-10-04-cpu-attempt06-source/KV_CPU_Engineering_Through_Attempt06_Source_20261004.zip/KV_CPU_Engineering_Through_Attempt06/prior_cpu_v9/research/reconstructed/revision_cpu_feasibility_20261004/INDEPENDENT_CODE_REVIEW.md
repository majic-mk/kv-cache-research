# Independent review: first-input CPU pair

**2026-10-04 16:43 UTC — PASS for prospective admission, not an execution result.** The reviewed actual-runner source can be released for the one declared CPU pair once the pinned acquisition is complete and the parent explicitly authorizes launch. No additional generic admission suite is requested. This review downloaded no tensor payload and ran no pretrained model.

Reviewed source manifest: **`c6029de34fed6ba8a278cc7e59bdc2b0feaa1d5087cc7c9acb9fdc0af366ae1e`**, in `../revision_cpu_file_pager_20261004/source_manifest.json`.

CPU protocol v2: **`fcd31bee078df11d2178438ca4018e7457c06378b850c2b17e98fb392c78ca1d`**. Acquisition-start receipt: **`762c9e848d19073fcf297e115e95d917f9a2257e1003defb391eb5860c3cb700`**. The receipt anchors the attempt at **16:28:20.316980 UTC**, with the original overall deadline **17:28:20.316980 UTC**. Waiting does not reset either the overall or 1,800-second model-phase clock.

## Checks accepted

- **Arithmetic and storage:** native Qwen3 decoder, eager attention, RMSNorm, BF16 `nn.Linear.forward`, and FP32 RoPE remain in use. One exclusive BF16 arena obtains the exact source bytes via bounded `preadv`; no quantization, whole-model copy or implicit precision fallback. The original tied embedding/head remains one resident Parameter throughout both arms
- **Pinned mapping:** all eleven required base files have exact sizes and official SHA-256/Git blob checks. The three shard headers must cover exactly the index's key-to-file mapping and match the native model's 398 parameter names/shapes/dtypes. The source reader rejects duplicate shards/tensors/JSON keys, invalid ranges, overlap/gaps and unclaimed payload. The stale index `total_size` is not used as authority over actual header extents
- **Read failures and cleanup:** partial reads are accumulated and charged as they happen; zero/failed reads cannot bind an incomplete arena. Native forward/pre-hook failures restore metadata-only weights. Partial hook installation cleans up already installed hooks/descriptors. The final tiny proof exercises these cases and exact source-offset values
- **Fixed scientific scope:** the complete 16-input file is hash-verified. Only its already-first variant is executed, with all 7,669 saved IDs and 82 exact chunks, unchanged 64-token greedy/EOS limit, and a final-token-only output-head call in both arms. Native Full and gate-loaded no-crop run sequentially, using the same model and real separate gate. No eviction arm or alternate input is reachable
- **Evidence and semantic admission:** raw vectors and call/KV records are retained before numerical/parity failure. Generated-ID progress and cap-hit answers are saved before stopping. Results/vectors are immutable; progress is separate. Full cache/transients are released before the independent source-based review checkpoint. No-crop requires a named, explicit positive review bound to the exact run, Full result, input and CPU protocol; no substring-only scoring is used
- **Guard:** independent process-tree accounting includes the watchdog, rejects a missing live child, and terminates the owned process group on ordinary limits and watchdog exceptions. It enforces 6 GiB sampled RSS, 6 GB starting/1.5 GB continuing host availability, 5 GB free disk, 256 MB evidence, the original acquisition deadline and the 1,800-second phase limit. The overall 180-second finalization reserve is applied once. A permanent exclusive attempt claim and fresh output directory prevent silent reruns

The frozen GPU source manifest and all 16 input-ID hashes were independently verified unchanged. The actual CPU source manifest and Python syntax were also reverified.

## Concrete corrections completed before outcomes

Review identified and resolved whole-file hashing unsuitable for large shards, incomplete failed-read accounting, partial hook-install cleanup, result loss on EOS-cap failure, evidence loss on parity failure, inconsistent final-token head shapes, mismatched acquisition receipt field names, and fail-open watchdog exception cleanup. Protocol v2 explicitly bound the semantic checkpoint and actual acquisition anchor while preserving v1.

An independent **config-only** check found one additional startup blocker: installed Transformers normalizes the source's `rope_scaling=None` into `{'rope_theta': 5000000, 'rope_type': 'default'}`. The runner now checks that exact native normalized representation instead of rejecting it or modifying RoPE.

## Proof inspected and limits

The owner's final `attempt_04` preserves the exact reviewed pager source and passes **10 focused tiny groups**, including three-shard source mapping, native/paged/no-crop final-token logits and every-layer KV equality, partial-read failure accounting, and cleanup. Its guard reports **4.018 s wall, 3.987 s CPU, 354,349,056 B sampled combined RSS**. Seven separate stdlib actual-contract groups cover source/input/anchor binding, ordinary/optimized hard locks, semantic approval, immutable evidence, deadline rejection and process cleanup. These are implementation checks, not 4B competence evidence.

Actual 4B memory, latency and answers remain unmeasured. RSS enforcement is sampled because this host exposes no usable hard memory cgroup. Up to approximately 2.108 TB of decoder-weight reads remains possible; the frozen measured-call projection and deadlines must stop a slow attempt. A first-input pass would not establish the other 15 inputs, GPU parity, eviction effects or method benefit.

## Release conditions

1. Require the successful `acquisition_complete.json` and `acquisition_guard.json`, then independently revalidate pinned local assets as the runner already does
2. Require the parent's explicit launch GO and current host/disk admission checks
3. Release may change only `CPU_EXECUTION_RELEASED` in `cpu_release.py`, with the corresponding manifest/release receipt updated and the reviewed manifest preserved. Any other runtime/protocol change requires review before launch
4. Parent supplies the atomic, hash-bound semantic judgment when Full completes. Stop on any declared failure; do not retry an answer, change inputs, relax tolerances or reset deadlines

**No remaining code blocker was found in the reviewed source. Acquisition readiness and launch authorization are separate prerequisites.**

## Minimal release delta rechecked

At 16:45 UTC the prepared release manifest is `73e133d2fca88e3b381527b48ec402a0d2da7b15d0c30b5829a9b05e6bc93e99`. Every reviewed source file is byte-identical to the preserved locked source except the explicitly permitted `CPU_EXECUTION_RELEASED = False` to `True` change. The manifest/status and source-release receipt record that preparation. This does not replace verified acquisition, durable backup or the parent's launch GO. The prepared release retains the same review PASS.
