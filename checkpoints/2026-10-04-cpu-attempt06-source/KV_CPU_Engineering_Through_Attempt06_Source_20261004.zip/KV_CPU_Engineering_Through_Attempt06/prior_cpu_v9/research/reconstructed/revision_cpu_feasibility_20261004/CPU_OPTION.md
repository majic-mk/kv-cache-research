# Current revision-sensitive direction: bounded CPU option

**2026-10-04 UTC. Conditional GO for one prospective actual-backbone CPU smoke; acquisition and inference remain unreleased pending parent review.** This concerns plain Qwen3-4B and the current fixed revision-sensitive inputs, not the stopped hybrid Qwen3.5 project. A successful smoke would establish first-input competence and CPU native/no-crop equality only. It would not validate eviction effects, all 16 inputs, GPU numerical behavior, or a new method.

## Actual host and assets

- AMD EPYC 9V74; nine exposed logical CPUs; **10,451,464,192 B total RAM**, roughly **7.60 GB initially available**, no swap. `/proc/self/cgroup` reports `0::/`, but `/sys/fs/cgroup` is not exposed. A hidden lower limit cannot be ruled out. **A 16 GB RSS allowance is not valid here.** Raw observations are in `host_snapshot.json`
- Worktree filesystem initially had **17,371,262,976 B free**. `/tmp` is a 5.23 GB tmpfs, so weights must use worktree disk, not `/tmp`
- Existing interpreter: `research/reconstructed/runtime_recovery_20261004/.venv/bin/python`; Torch **2.9.1+cpu**, Transformers **5.19.0.dev0**, Safetensors **0.8.0**. Actual installed plain-Qwen3 source SHA-256 is **`2b768b0eb0aacf1478bba1dc84318126c6c68fecb0ac9465f70154f24da4a80d`**, matching the frozen pilot. No installation is needed
- Native AVX512-BF16 and oneDNN support were verified. A model-free BF16 Linear of shape `128×2560` by `2560×9728` produced the exact expected values; warm median was **33.56 ms at one thread / 9.15 ms at four**. BF16/FP32-softmax round trip also passed. This is operator evidence, not a model or end-to-end latency result
- Existing-file sequential reading measured **3,763,696,896 B in 0.609 s (6.18 GB/s)**. Cache state is unknown; **do not treat this as cold disk bandwidth or a completion promise**. The operator/read probe peaked at 290,213,888 B RSS and loaded/ran no model. See `model_free_runtime_checks.json`
- The frozen TRIM gate is already local. The actual plain-Qwen3 backbone shards are absent. Existing hybrid weights are not substitutes

## Exact backbone and disk cost

Use only [Qwen/Qwen3-4B-Instruct-2507 at `cdbee75f17c01a7cc42f958dc650907174af0554`](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507/tree/cdbee75f17c01a7cc42f958dc650907174af0554). Bounded range reads fetched **only the three safetensors headers**, no tensor payload. The 398 header entries confirm **4,022,468,096 BF16 parameters / 8,044,936,192 payload bytes**; all three files including headers total **8,044,982,000 B**. Complete frozen base files total **8,060,896,487 B**. At the initial disk snapshot this leaves **9,310,366,489 B**, comfortably above the **5 GB floor plus 256 MB evidence cap**, without deleting existing assets or making an offload copy. Recheck immediately before acquisition.

Pinned shard SHA-256 values:

1. 3,957,900,840 B: `75311d91bb08cf0b882913da464a1e722a31fb44db35208663487efb7a3d8ed6`
2. 3,987,450,520 B: `0b48adbb1f60e901153d91907ba11ce63bd4b8b584482e730f48808d055dfba1`
3. 99,630,640 B: `7dd39ccca5e4de123c74c14af44c9bf2eb75df33b4614382af0134528e060d5d`

The official index's `metadata.total_size=8,045,591,552` differs from the actual header payload sum by 655,360 B. Preserve the pinned index; record the discrepancy rather than silently using its total as a parameter count. Header names, shapes, dtypes, offsets, file lengths and official shard hashes are the acquisition/loading authorities. `official_header_receipt.json` and the saved header JSONs make this check reproducible.

## Why ordinary loading is not the proposal

Resident BF16 weights alone are 8.045 GB. Full cache through the first input and at most 63 ingested answer tokens adds **1,140,129,792 B**; across all frozen inputs the maximum would be **1,244,676,096 B**. Runtime, attention temporaries and the gate add more. Ordinary resident loading therefore cannot safely satisfy the actual host reserve, and FP32 is still larger.

The pinned HF loader supports lazy safetensors mmap, but lazy mapping does not bound residency as every layer is touched. Relying on OS reclaim would turn this into an uncontrolled paging experiment. The existing `paged_fp32_engine_20261004` is also insufficient: it keeps source BF16 weights resident and borrows a cast arena. It is not a validated disk pager for plain Qwen3.

## Narrow executable design

The implementation owner is preparing a separate `revision_cpu_file_pager_20261004` path, leaving the frozen GPU harness untouched:

- Keep the original tied embedding/head (**777,912,320 B**) and small native norm tensors (**392,192 B**) resident; preserve native FP32 RoPE and native norm arithmetic
- Read each decoder Linear's exact original BF16 bytes into **one exclusive 49,807,360 B arena**, using verified safetensors offsets. Scoped pre-hooks bind the arena view, unchanged native `nn.Linear.forward` executes, and always-call post-hooks restore metadata-only storage. No quantization, dtype fallback, alternate model, whole-checkpoint copy, layer-major scheduling change, or reliance on mmap reclamation
- Retain only one arm's complete Full KV cache at a time. Base resident tensors + arena + maximum first-input KV + actual gate payload total approximately **2.063 GB**, before runtime/activations/scratch. That is a plausible design margin under **6 GiB**, not a measured 4B peak
- A separately reviewed, bounded tiny correctness/exception-cleanup proof must pass before real weights are used. It must establish native call/KV/logit equivalence and exclusive arena lifetime, not merely random-model accuracy

Disk traffic is the trade-off. Each forward rereads approximately **7,266,631,680 B** of decoder Linear parameters. With 82 canonical input calls and at most 63 decode calls per arm, two arms can request **2,108,101,491,712 B (~2.108 TB)** including the initial resident parameter reads. Charge all reads/copies, and stop a slow attempt; do not claim CPU serving efficiency from this diagnostic.

## Frozen prospective scope and stopping rule

`prospective_cpu_protocol_v2.json` and its SHA-256 freeze the current proposal; v1 remains unchanged. V2 adds the explicit semantic-review checkpoint, keeps the same model/pager/gate resident while releasing only Full cache/transients, and binds acquisition start **16:28:20.316980 UTC** / overall cutoff **17:28:20.316980 UTC**. Review waiting counts inside both existing wall limits. It verifies the entire unchanged 16-input file, then selects **the first input by its existing order**, `c7dc5443__reservoir_before__low_zero`, before outcomes: **7,669 tokens, 7,624 history +45 query**, its original **82 message-aware chunks**, and at most **64 greedy output tokens**. Two arms only: native Full and real-gate-loaded no-crop, sequentially. All other variants remain explicitly unrun.

Use four intra-op threads and one inter-op thread. Require exact original-BF16 chunk-end vocabulary vectors, per-layer appended-KV bytes, generated IDs and EOS equality. Preserve all raw answers/logits and an independent source-based competence judgment; qualified historical-plus-current answers remain allowed. Wrong/incomplete Full answers, missing EOS, a cap hit, nonfinite values, parity/shape/identity failure or a resource breach stop the smoke. No changed prompt, replacement input, relaxed tolerance, or answer retry.

Hard declared ceilings: **6 GiB process-tree RSS**, **≥6 GB MemAvailable before loading / ≥1.5 GB while running**, **≥5 GB free disk**, **256 MB evidence**, **3,600 s total including acquisition**, at most **1,200 s acquisition/verification**, **1,800 s model phase**, and **180 s finalization reserve**. External 100 ms RSS/MemAvailable monitoring is required; sampling is not an OS-enforced memory guarantee. Reproject after three actual input calls and each subsequent call: if twice the maximum observed whole-call latency times the remaining call allowance exceeds the remaining budget, stop with partial evidence. This conservative stop heuristic is not a proven runtime bound; the external deadline remains authoritative.

**Next decision:** parent can approve exact pinned acquisition only after reviewing this evidence and the independent pager proof. Actual 4B execution needs a separate release. A pass authorizes no automatic continuation to the other 15 inputs, compressed arms or GPU. This assessment changed no frozen input or GPU-pilot file, downloaded no weight payload, ran no model, installed nothing and used no paid resource.
