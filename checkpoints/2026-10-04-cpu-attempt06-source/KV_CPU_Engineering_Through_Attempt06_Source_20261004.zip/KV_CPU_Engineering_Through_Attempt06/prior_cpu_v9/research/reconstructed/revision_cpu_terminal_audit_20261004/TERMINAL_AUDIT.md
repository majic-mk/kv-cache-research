# Independent terminal audit: first-input CPU attempt

Verdict: valid prospective resource-feasibility stop; no answer, competence score, or no-crop parity result.

The frozen plain Qwen/Qwen3-4B-Instruct-2507 checkpoint (revision cdbee75f17c01a7cc42f958dc650907174af0554) executed three native BF16 calls on exactly the first 128, 7, and 98 frozen input tokens. Cumulative input was 233 of 7,669 tokens. The target source assertion and final query were never reached. Zero answer tokens were generated. The second arm never started.

## Stop and resources

The frozen projection correctly stopped after call 3: 2 × 4.847722630 seconds maximum observed whole-call time × 287 remaining allowed calls = 2,782.592790 seconds, above the 1,769.298554 seconds remaining at the final progress record. This conservative early projection is not an observed full-run duration. It cannot establish that the pair would actually require more than 30 minutes, but continuing would violate this attempt’s prospective admission rule. Do not retrospectively relax that rule or retry this attempt.

Guard: 31.505298 seconds wall; 62.693804 seconds child CPU; 2,224,586,752 bytes sampled peak process-tree RSS; 4,326,797,312 bytes minimum host available memory; 9,165,418,496 bytes minimum free disk. The 312 watchdog samples remained within the frozen reserve limits. Final raw evidence totals 937,205 bytes. Parameter paging read 22,578,199,552 bytes in 6.025496 seconds across setup and the three model calls; this excludes separately recorded whole-file verification I/O.

The runner exited 1 via the declared timing requirement. The watchdog reports no watchdog exception or resource-triggered termination and confirms its owned process group is absent. A separate process listing showed no actual runner/guard remaining. The progress file’s MODEL_ACTIVE status is the last preserved progress snapshot, not a live-status claim; failure.json and guard_result.json are authoritative terminal records.

## Independent raw checks

- Frozen CPU source manifest 73e133d2fca88e3b381527b48ec402a0d2da7b15d0c30b5829a9b05e6bc93e99 and every listed source file still match
- CPU protocol fcd31bee078df11d2178438ca4018e7457c06378b850c2b17e98fb392c78ca1d and frozen input b41e4b4fe7e1f10083a5f79d510a79df6282f57b15de3147ada1a1ec582f01b7 match the same-run bindings
- All 16 canonical input hashes and the untouched GPU harness source manifest validate
- Every recorded call uses the exact first-input token slice and original chunk end
- All three saved 303,872-byte BF16 logit vectors decompress, match their recorded SHA256, and independently contain only finite BF16 values
- Each call records 36 ordered layers of correctly shaped BF16 appended K/V hash metadata; raw K/V bytes are not stored, so this audit does not independently reproduce those hashes
- Loaded-identity evidence records exact official shard hashes, a shared embedding/head route and native FP32 RoPE buffers; no full resident checkpoint comparator was run
- No Full answer/result, semantic review/approval, no-crop directory, or pair-level result exists

## Scientific scope

This is evidence that the pinned native CPU backbone and file-read pager execute bounded early prefill calls within the measured memory/disk reserves. It does not establish full-context memory fit, task competence, native/no-crop parity, eviction efficacy, or GPU behavior. No semantic review file was written because there was no answer to judge. Preserve this first attempt and its negative feasibility outcome. Any changed schedule or budget would require an explicitly separate prospective decision, not a reinterpretation of this run.

Raw evidence: outputs/revision_cpu_first_input_attempt_01. File-level hashes and numeric checks: independent_terminal_audit.json in this directory. Review used only standard-library read/hash/decompression checks; no model calls, weight downloads, source edits, or runtime changes.
