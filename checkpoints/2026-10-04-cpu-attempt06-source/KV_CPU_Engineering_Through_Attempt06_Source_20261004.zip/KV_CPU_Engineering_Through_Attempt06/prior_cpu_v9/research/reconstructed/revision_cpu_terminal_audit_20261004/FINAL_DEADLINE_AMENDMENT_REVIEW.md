# Final deadline-bound CPU amendment: independent minimal review

PASS, conditional on additive durable backup and explicit parent GO for this one final attempt. No concrete hard-stop safety blocker was found. No model or real entry point was run during review.

Reviewed source manifest: 5e9a3b8aa2a13f59e2c4c29ab93735b287f92d295ea4842580dac5869650b1ab
Reviewed protocol: 5bf36b992087744e069fc192b86ed0e8d001b6846ead6c7cafdc2f9156ced0c2
Source directory: research/reconstructed/revision_cpu_deadline_attempt_20261004
Reviewer: /root/assess_next_cpu_model_gate

The exact operational delta replaces the early-abort 2× runtime forecast with immutable per-call advisory forecast evidence. The forecast still reports its factor, remaining allowed calls, largest observed call latency, predicted remaining seconds, remaining actual seconds, and whether the prediction exceeds the remaining hard window. The common helper changes only its protocol binding.

All listed source hashes and Python syntax verify. The independent watchdog, file pager, and release file are byte-identical to the previously reviewed Full-only implementation. Model, native CPU BF16 arithmetic, first fixed 7,669-token input, all original chunks, one-arm scope, maximum 145 native calls, greedy maximum 64 sampled tokens, EOS151645, and source-based correctness requirements are unchanged. No output answer has been observed in either prior attempt.

Hard deadline remains min(original acquisition start +3600 −180 finalization reserve, fresh phase start +1800), hence no later than 17:25:20.316980 UTC. Runner Evidence.check still rejects time at or beyond this deadline; the independent 100ms watchdog still kills the owned process group when its deadline is reached, including during a blocking model call. Finally/exception cleanup and process-group absence verification are unchanged. The original 17:28:20.316980 UTC total window is not restarted. All RSS, available-memory, disk, and evidence guards remain unchanged and fail closed. This is sampled external enforcement, not an OS hard RSS limit or a zero-latency wall-clock guarantee.

This is explicitly a resource-policy amendment made after observing runtime. It must not be described as passing the original forecast gate. Both prior attempts remain preserved timing failures with zero answers, 11 native calls, 809 ingested tokens including repeated prefixes, 82.553157 guarded wall seconds and 200.240400 child CPU seconds. The protocol records these costs, forbids a further attempt in the original window, and makes no no-crop parity claim. The inherited prospective_projection numeric estimate is the historical first-attempt estimate (4.8477 seconds), not a newly measured global maximum; runtime forecasts correctly use this final attempt’s observed calls.

A predictive completion bound is not required for resource safety when the independent actual deadline/resources remain enforced. There is no scientific outcome-based input or score selection here, but the engineering amendment history must accompany any eventual result. A completed Full answer still needs independent semantic review; cap-hit, incomplete, wrong or unsupported output cannot establish competence. This amendment cannot produce no-crop parity or eviction efficacy evidence.
