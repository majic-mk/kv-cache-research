# Final CPU attempt: independent terminal audit

Verdict: actual host-memory-reserve stop, with no answer. This differs from the two preserved early forecast stops.

The final attempt completed 39 exact native prefill calls /3,718 of 7,669 frozen tokens and was killed during the next call. The latest source assertion and final query were not reached. It generated zero answer tokens. No semantic-review file exists, no no-crop arm ran, and no competence, routing-parity, or eviction result can be claimed.

## Verified termination

The unchanged watchdog observed MemAvailable=1,329,688,576 bytes, below its 1,500,000,000-byte reserve, and killed its child (exit −9). Peak sampled process-tree RSS was 5,384,413,184 bytes, below the 6 GiB RSS ceiling; the binding condition was host available memory. There was no watchdog exception. The guard records owned-process-group absence verified after cleanup, and the owning command completed. A separate observer-visible process listing found no actual runner, but that separate /proc view is not an independent global-process absence proof. This qualification also applies to process-list statements in the earlier audit notes.

Original compute/overall deadlines remained 17:25:20.316980/17:28:20.316980 UTC. All 37 forecast records are correctly advisory and exceed the remaining budget; none is a claim that the original predictive gate passed. The stop occurred before the actual deadline because the host reserve was crossed.

Guard wall=241.160941s; child CPU=809.949248s;2,373 resource samples; minimum free disk=9,133,260,800 bytes; frozen raw evidence=10,386,597 bytes. Pager evidence through the last completed call records284,176,940,032 bytes and78.700809s of reads; it omits any additional reads during the interrupted call and is a lower bound.

## Raw integrity

All 39 compressed BF16 vocabulary vectors decompress, match their recorded hashes, and independently contain only finite values. The call token slices, original positions and chunk ends exactly match the frozen first input. All1,404 layer-append records have correct shape/dtype/hash metadata; raw K/V bytes are not stored for independent hash recomputation. Overlapping completed native calls match the first3 and first8 prior-attempt logit/KV hashes exactly; that is limited repeated-prefix reproducibility, not no-crop parity. Every prior raw-output hash, all16 canonical input hashes, final CPU source/protocol and the untouched GPU harness validate.

## Cumulative actual-model work

Three attempts:50 completed native calls plus one interrupted call;4,527 completed ingested tokens including repeated prefixes (largest unique prefix3,718);zero generated tokens;323.714097s guarded wall;1010.189648s child CPU;at least365,666,497,536 pager-read bytes. Acquisition and separate whole-file verification I/O are additional. Both earlier attempts retain their original forecast-failure outcomes. No further attempt is authorized.

The resource stop does not establish hardware-wide inability to run this checkpoint. The explicit tensor ledger is smaller than observed RSS and is not an RSS guarantee. Read-only source/trace diagnosis and uncertainty are in MEMORY_DIAGNOSIS.md.

Raw output:outputs/revision_cpu_deadline_attempt_03
Exact file-level receipt:final_deadline_terminal_audit.json
Reviewer:/root/assess_next_cpu_model_gate
