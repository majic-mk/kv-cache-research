# CPU memory stop: read-only diagnosis

## Finding

The final run crossed the actual host available-memory reserve. The data does not establish a hardware-wide inability to run Qwen3-4B, a proven tensor leak, or a single identified allocator fault. It establishes that this specific native BF16/eager/paged path, with the observed host state and frozen guards, did not complete the fixed input. No model rerun or implementation change was made for this diagnosis.

At the last completed chunk, exact persistent payload is approximately 1.471 GB:

- Tied embedding/head plus small norms: 778,304,512 bytes
- One exclusive BF16 weight arena: 49,807,360 bytes
- Loaded but unused retention gate: 94,704,192 bytes
- All36 layers’ BF16 K/V at3,718 tokens: 548,241,408 bytes

At the next chunk endpoint3,734 the ledger would be1,473,416,768 bytes. The sampled peak process-tree RSS was5,384,413,184 bytes, roughly3.91 GB above that explicit persistent tensor ledger. The original2,062,945,856-byte estimate described persistent payload at the full input plus maximum decode length; it did not account for all temporaries, runtime, allocator retention or native workspaces and must not be treated as an RSS upper bound.

## What the source establishes

1. Cache growth and allocation churn are real. Native DynamicLayer.update replaces keys and values with torch.cat at every layer/chunk (cache_utils.py:145–146). Old/new buffers temporarily coexist, and allocation sizes change with sequence length. The persistent cache itself is only about548 MB at the last completed chunk; it does not explain the whole RSS gap.

2. Native eager attention expands8 K/V heads to32 query heads and materializes score/FP32-softmax buffers (modeling_qwen3.py:169–204). At the last completed100-token chunk/T=3,718, repeated K/V together are60,915,712 bytes, BF16 scores23,795,200 bytes, and the FP32 softmax tensor47,590,400 bytes. A layer’s entire K/V pair is15,228,928 bytes. Several temporaries can overlap; these are shape-derived individual-buffer sizes, not a measured peak or complete backend-memory inventory. They do not by themselves account for a multi-GB gap. The interrupted next chunk has only16 query tokens, so a larger query chunk is not the immediate explanation.

3. The Python evidence path does not intentionally retain tensor history. Capture.append, calls, resident_before and gate_before store shapes/bytes/hash strings and token IDs. The per-call raw vocabulary vector is303,872 bytes and written to disk. Per-append digest copies at most the new chunk, not the complete KV history. Full-vocabulary output is computed only for the last hidden token. The no-crop gate-state branch is never executed.

4. Autograd retention is not supported by the reviewed path. torch.set_grad_enabled(False), torch.inference_mode, requires_grad=False arena/resident parameters and pager prehook checks are active. Native hidden-state/attention output capture defaults are false, absent from checkpoint overrides, and not requested by this runner (configuration_utils.py:303/369; output_capturing.py:258–290). The native decoder discards attention output weights after its layer call. No source evidence of accumulating autograd graphs or all-layer attention histories was found. This is code/lifecycle evidence, not a live heap inventory.

5. The pager does not intentionally accumulate decoder weight copies. It allocates one49,807,360-byte arena, reads into it with preadv, binds a view temporarily, and restores the original meta parameter using an always-call hook. Every completed call passed assert_idle before its evidence record. The cumulative9,828 binds equal39 calls ×36 layers ×7 Linear modules. The loaded source-resident payload stays778,304,512 bytes. There is no full-shard mmap used by the base pager; file reads do warm the OS page cache. The final interrupted call cannot execute Python cleanup after SIGKILL, but the process-group termination releases its address space.

## Plausible but unproven contributors

Changing-size torch.cat, repeat-K/V, attention and hashing allocations can leave CPU allocator arenas/reserved or fragmented blocks resident after tensors are freed. Native BF16 matmul/oneDNN/BLAS may allocate packing/workspace or cached primitives outside the explicit Python tensor ledger. Either can produce RSS that exceeds simultaneously live payloads. The saved aggregate traces cannot distinguish these hypotheses from an unobserved live native tensor/cache allocation, and they do not prove a PyTorch or pager leak. Backend workspace sizes were not profiled; do not assign the unexplained3.9 GB to one library by assumption.

Host-wide effects also matter. From first to terminal watchdog sample, process-tree RSS rose5,369,864,192 bytes while MemAvailable fell5,840,850,944 bytes. The difference is not a direct measure of unrelated-process growth: MemAvailable is an OS estimate involving cache/reclaimable memory, and RSS/shared memory are not a conservation equation. The observations show substantial run-process growth plus host/cache variability. We lack a simultaneous host-wide process/smaps inventory. After termination, available memory recovered to roughly7 GB; this is consistent with address-space release, not a precise attribution.

## Limits and next decision

The watchdog’s own namespace verified its owned process group absent, and the owning command terminated. A separate observer-visible ps listing is not an independent cross-namespace process census. No live-model allocator, smaps, unique-storage inventory or backend workspace snapshot survived the kill. The root cause therefore remains unresolved.

No more model attempt is authorized in this window. If later work is separately approved, the informative next engineering step would be allocation attribution at fixed phase/layer boundaries: current/peak RSS plus smaps_rollup, allocator allocated-versus-retained statistics, unique persistent storage sizes, and backend-workspace profiling. Such measurements would distinguish excess live storage from allocator/native retention before changing models, guards, cache semantics, or recommending more hardware. This is a diagnosis plan, not an implemented or launched experiment.

Scientific state remains unchanged: no complete answer, no competence judgment, no no-crop parity, and no eviction result.

Source paths/hashes, exact ledger and observer memory snapshot:memory_diagnosis_evidence.json
Raw terminal evidence:outputs/revision_cpu_deadline_attempt_03
Reviewer:/root/assess_next_cpu_model_gate
