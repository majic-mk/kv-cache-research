# Full-only attempt 2: independent terminal audit

Verdict: the fixed timing projection stopped the run before an answer. No competence or no-crop parity outcome exists.

Eight native calls ingested the exact first 576 of 7,669 frozen input tokens. The first seven calls passed admission; call 8 increased the maximum whole-call latency to 5.275051365 seconds. The unchanged rule then projected 2 × maximum latency × 137 remaining allowed calls = 1445.364074 seconds against 1436.456016 seconds remaining to the original 17:25:20.316980 UTC compute cutoff. This is a conservative projection stop, not a measured full-run duration or an incorrect-answer outcome.

The latest target assertion and final query were not reached. Zero answer tokens were generated; no semantic-review file was created and the no-crop arm was never invoked. The old wording “pair deadline” in the exception is a retained message string; actual source and bound protocol correctly use the 145-call Full-only envelope and unchanged absolute cutoff.

## Resource and cleanup evidence

- Guard wall: 51.047858 seconds; child CPU: 137.546596 seconds
- Sampled peak process-tree RSS: 2,410,582,016 bytes
- Minimum host available memory: 4,185,722,880 bytes
- Minimum free disk: 9,155,379,200 bytes
- Frozen raw evidence: 2,233,428 bytes
- Parameter-pager reads: 58,911,357,952 bytes in 15.233482 seconds; full-file verification reads are separate
- Guard exit 1, no watchdog exception or resource-triggered termination, owned process group absence verified; independent process listing shows no actual guard/runner remaining

All eight saved BF16 vocabulary vectors independently decompress, hash correctly, and contain finite BF16 values. Each call’s IDs, absolute positions, and original chunk endpoint match the frozen first input. All 288 layer-append records have correct shape/dtype/hash metadata; raw K/V bytes were not retained for an independent hash recomputation. Final source/protocol and all 16 canonical input hashes verify. Every prior attempt-1 raw hash still matches. The frozen GPU harness is unchanged.

Cumulative actual-model work across both preserved attempts: 11 native calls, 809 ingested tokens including repeated prefixes (576 unique-prefix tokens), zero generated tokens, 82.553157 guarded wall seconds, 200.240400 child CPU seconds, and 81,489,557,504 pager-read bytes. These totals exclude acquisition and separate hash/verification I/O.

This confirms bounded early native execution with memory/disk reserves; it does not establish full-context memory fit, answer competence, CPU no-crop parity, eviction benefit, or GPU behavior. Preserve both resource-stop outcomes. No new inference or relaxed threshold was authorized or performed by this audit.

Source manifest: 7cc53a6043833d71c266f04c9db605ed1c7aa699fcc23a1ee132f8b9af7f5ce8
Protocol: 2bf44eedde0e6a12e4bc778a4cec70aae848c68325296b0c8126a56091bfbf44
Raw outputs: outputs/revision_cpu_full_only_attempt_02
Review receipt and file hashes: full_only_terminal_audit.json
Reviewer: /root/assess_next_cpu_model_gate
