# Allocation-only replay: independent read-only supplement

This supplements the frozen MEMORY_DIAGNOSIS.md after the implementation owner completed a separately approved synthetic diagnostic. No replay, model or new test was run by this review.

Reviewed evidence: research/reconstructed/revision_cpu_allocation_replay_20261004/ANALYSIS.json
Final SHA256: 80659d401bbb48ee44cd5afd94da2559153fd23932d3b30184f60bb5f51bb1ca
Final status: PARTIAL_DIAGNOSTIC_CPU_BUDGET_OVERRUN_NO_FULL_PASS

The replay source imports pinned CPU Torch and allocates/zeros shaped tensors, cache concatenations and repeated-head views matching observed chunk sizes. It does not construct a model/config, load checkpoint tensors, perform matmul, or execute an LLM forward. It deliberately excludes the 922,816,064-byte fixed model/gate/arena payload and native kernel packing/workspaces. This is an allocation-pattern surrogate, not an exact memory execution of the actual model.

I independently checked the JSONL boundaries: control completed 39 chunks; trim completed 38. Their common comparison is chunk 38 /3,618 tokens. At that boundary control RSS was 847,228,928 bytes. Trim RSS was 844,677,120 bytes both before and after GC, then 755,564,544 bytes after malloc_trim, an 89,112,576-byte observed decrease after trimming. The report’s maximum recorded boundary decrease is 239,714,304 bytes. Peak combined sampled RSS was about 1.10 GB for each mode, excluding the fixed payload.

This replay did not recreate the actual 5.384 GB process-tree peak or its multi-GB excess over the explicit payload ledger. It therefore weakens a claim that the modeled cache/attention allocation churn alone explains the real gap. It does not prove that allocator behavior is irrelevant under the real native kernels, nor identify backend packing/workspace as the cause. The omitted operations and different lifetimes remain important limitations.

The trim process ended with SIGKILL during its 39th chunk. A per-child 60-second RLIMIT_CPU is consistent with that termination, but the exact signal issuer was not separately recorded. Aggregate child CPU was 123.096495 seconds against an approved 120 seconds, an overrun of 3.096495 seconds. The owner records this as a guard failure/limitation, not a fully compliant diagnostic. No retry occurred. A future separately authorized multi-process diagnostic would need an aggregate CPU sampler and advance margin.

The memory diagnosis remains unresolved. There is still no actual-model complete answer, competence judgment, no-crop parity or eviction evidence. The original model-window stop and all prior outcomes remain unchanged.

Reviewer: /root/assess_next_cpu_model_gate
