# Native CPU backend review, 2026-10-04

## Result

The unexplained RSS is still unattributed. The useful new lead is **native GEMM execution**, including eager attention's changing-shape batched GEMMs, which the allocation-only replay explicitly omitted. Source supports oneDNN dispatch, packing/scratchpad and primitive-cache hypotheses; it does not establish a 3.9 GB oneDNN or MKL leak, or a packed copy of every paged weight. CPU SDPA is a plausible later mitigation, not a measured remedy.

No Torch import, model construction, operator execution, model rerun, benchmark, implementation edit, installation or environment change was performed for this review. Existing JSON/source/header files and official upstream sources/docs were read. Only this report was written.

## Exact scope and versions

- Actual evidence: `outputs/revision_cpu_deadline_attempt_03`; runner/pager: `research/reconstructed/revision_cpu_deadline_attempt_20261004/{actual_runner,file_pager}.py`
- Installed runtime prefix: `research/reconstructed/runtime_recovery_20261004/.venv/lib/python3.12/site-packages/`
- Torch `2.9.1+cpu`; installed `torch/version.py` records commit `5811a8d7da873dd699ff6687092c225caffcf1bb`
- Transformers `5.19.0.dev0`, installed from commit `02d8fb9784e8f14a1251e4c992cd82a5762417c6`; local `transformers/models/qwen3/modeling_qwen3.py` SHA256 `2b768b0eb0aacf1478bba1dc84318126c6c68fecb0ac9465f70154f24da4a80d`
- Installed `torch/include/ATen/Config.h` enables MKLDNN, MKL, BLAS and OpenMP; ACL is disabled. Installed `torch/include/oneapi/dnnl/dnnl_version.h` says oneDNN **3.7.1**. This establishes build support, not which kernels executed. No saved backend verbose log, runtime ISA report or exact linked MKL version was found in the reviewed run evidence
- Actual runner uses 4 intra-op / 1 inter-op threads, explicit BF16, no autocast, inference mode, deterministic algorithms and eager attention
- Last completed endpoint: 3,718 tokens. Explicit persistent ledger 1,471,057,472 B; terminal sampled process-tree RSS 5,384,413,184 B. See `MEMORY_DIAGNOSIS.md` and `memory_diagnosis_evidence.json`

## Confirmed source facts

### Linear dispatch is not the explicit MKLDNN-tensor Linear API

The pager binds ordinary contiguous BF16 arena views, bias is absent, and `nn.Linear.forward` calls `F.linear`. Native `linear` therefore uses `matmul(input, weight.t())`, not its MKLDNN-layout special case or bias-fused Python-facing addmm branch. Suitable 3-D inputs fold to `mm`; CPU `mm` shares `addmm_impl_cpu_` with beta zero. Thus seeing `aten::mm`/`aten::addmm` does **not** rule out oneDNN internally. Sources: [Linear.cpp, lines 63–111](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/Linear.cpp#L63-L111), [LinearAlgebra.cpp, mm and fold paths](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/LinearAlgebra.cpp#L1509-L1513).

For BF16 output, CPUBlas tries `mkldnn_bf16_gemm` when enabled/eligible, with a special GEMV bypass; otherwise it falls back. MKL's explicit BF16-to-FP32 GEMM is in a different overload, so claiming every BF16 Linear is an MKL GEMM would be wrong. The ordinary path is not evidence of an FP32 copy of all weights. Autocast's weight-cast cache is also inapplicable to the checked no-autocast path. [Pinned CPUBlas.cpp, lines 314–460](https://github.com/pytorch/pytorch/blob/5811a8d7da873dd699ff6687092c225caffcf1bb/aten/src/ATen/native/CPUBlas.cpp#L314-L460).

### Attention also exercises the native backend

Pinned Qwen3 source, lines 192–202, repeats K/V and performs two BF16 matmuls around FP32 softmax. Batched CPU matrix multiplication tries MKLDNN under its size/dtype/device heuristics. Its MKLDNN wrapper creates dense tensor views, may materialize unsupported strides, calls `ideep::matmul_forward::compute`, and can copy a reformatted output back. These allocations are outside the simple KV ledger. This is a dispatch possibility, not proof the failed process took it. [LinearAlgebra.cpp, lines 1636–1646](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/LinearAlgebra.cpp#L1636-L1646), [Matmul.cpp, lines 96–188 and 281–369](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/mkldnn/Matmul.cpp#L96-L188).

The 39 saved calls contain 17 distinct query lengths and 39 growing KV lengths. All 36 layers repeat those dimension families. This motivates testing shape-specific native retention, but does not justify multiplying a primitive's footprint by 36 or treating 9,828 pager binds as 9,828 retained weight copies.

### Caches and temporary storage are different mechanisms

oneDNN's global primitive cache retains shape/attribute-specific primitives/JIT work; the documented default capacity is 1,024 **entries**, not bytes. `ONEDNN_PRIMITIVE_CACHE_CAPACITY=0` disables that cache when supported, but does not promise release of every framework cache, BLAS pool or allocator arena. [oneDNN 3.7 primitive-cache documentation](https://uxlfoundation.github.io/oneDNN/v3.7/dev_guide_primitive_cache.html).

oneDNN calls inference temporaries **scratchpad**; its technical term **workspace** is training state shared with backward. Scratchpad footprint depends on implementation and threading, and user-managed versus library-managed scratchpads have different lifetimes. Generic documentation alone cannot tell us which bytes survived this run. [oneDNN 3.7 scratchpad documentation](https://uxlfoundation.github.io/oneDNN/v3.7/dev_guide_attributes_scratchpad.html).

The Torch commit pins iDeep `719d8e6cd7f7a0e01b155657526d693acf97c2b3`, which pins oneDNN `8d263e693366ef8db40acc569cc7d8edf644556d`: [Torch submodule listing](https://github.com/pytorch/pytorch/tree/5811a8d7da873dd699ff6687092c225caffcf1bb/third_party), [iDeep listing](https://github.com/intel/ideep/tree/719d8e6cd7f7a0e01b155657526d693acf97c2b3). Retrieval of that exact iDeep matmul header failed. A moving iDeep branch was readable, but its cache/scratchpad behavior is **not promoted to a pinned-runtime fact** here. The installed headers do independently identify oneDNN 3.7.1; the linked binary's build provenance should be recorded in any future probe.

MKL separately has default per-thread reusable memory pools; disabling its fast allocator can cost performance. Build support alone does not establish that those pools account for this gap. [Intel MKL allocator reference](https://www.intel.com/content/www/us/en/docs/onemkl/developer-reference-c/2025-2/mkl-disable-fast-mm.html).

## CPU SDPA: plausible benefit, material caveats

Torch 2.9.1 has a genuine CPU fused attention path supporting BF16, eligible masks, equal head dimension and last-dimension stride one. Its selector prefers CPU Flash over math; selection must be observed rather than assumed. The CPU Flash implementation tiles these <=128-token queries at 32 query rows by up to 512 KV rows, avoiding full Q×T score/softmax materialization. Its explicit main/reduced tile buffers at four threads total at most 459,776 B for head dimension 128. This excludes outputs, masks, optional packed K/V, kernel caches and backend temporaries. [CPU selector](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/transformers/sdp_utils_cpp.cpp), [CPU Flash kernel, allocation and dispatch](https://github.com/pytorch/pytorch/blob/v2.9.1/aten/src/ATen/native/cpu/FlashAttentionKernel.cpp#L363-L446).

There are three important limits:

1. The pinned HF adapter `transformers/integrations/sdpa_attention.py:30–37,108–114` only enables GQA without an attention mask on this CPU route. Cached multi-token chunks require an explicit absolute-position causal mask (`masking_utils.py:239–283`), so the adapter still repeats 8 KV heads to 32. Merely selecting `sdpa` does not remove those repeated buffers. Replacing this mask with `is_causal=True` would misalign non-square cached attention
2. Math fallback promotes BF16 Q/K/V and intermediate attention work to FP32 by default; memory can increase. Fused backend choice can also change numeric outputs. [Pinned attention.cpp, CPU dispatch and math path](https://github.com/pytorch/pytorch/blob/5811a8d7da873dd699ff6687092c225caffcf1bb/aten/src/ATen/native/transformers/attention.cpp#L704-L877), [numerical/backend documentation](https://docs.pytorch.org/docs/2.9/generated/torch.nn.functional.scaled_dot_product_attention.html)
3. The optional packed CPU path has its own shape-keyed, thread-local BRGEMM kernel cache and scratchpad vectors in CPUBlas.cpp:973–1100. It is distinct from oneDNN's primitive-cache capacity. Switching attention therefore does not prove absence of native retention. It would also amend the frozen eager baseline and require an explicit numerical/parity policy; it does not change source weight bytes

## Smallest proposed next diagnostic, only if separately authorized

**One bounded model-free native-operator attribution replay**, rather than another 4B forward or an immediate cache/SDPA toggle:

- Reuse the saved 39 `(query_length, KV_length)` pairs, exact BF16 shapes/strides, four threads and inference/no-autocast mode. Execute only one synthetic decoder layer's seven ordinary Linear calls plus the two real eager attention matmuls/softmax per pair. Use a single synthetic 49,807,360 B arena; no checkpoint reads, model/config construction, generation, gate or all-36-layer KV cache. Add the synthetic tied-head GEMM shape `[1,2560] × [2560,151936]` twice as a separately marked phase, with one 777,912,320 B synthetic matrix, so its unusual size is not silently omitted
- Keep baseline backend settings. Log current RSS, `smaps_rollup` anonymous/private/file proportions and `mallinfo2` at each operator-family boundary and after deleting its temporaries. Record Torch build configuration, oneDNN verbose primitive creation/execution and MKL verbose. Use a bounded profiler window with CPU memory profiling, `record_shapes=False`, `with_stack=False`; profiler accounting alone cannot see every native allocation. Stream logs to disk, not an in-memory history
- Retain the existing external 6 GiB process-tree, 1.5 GB host-available, 5 GB free-disk and 256 MB evidence guards. A prospective tighter 2 GiB diagnostic RSS stop and 16 MB log cap would leave headroom. Require fresh host availability >=6 GB, stop on the first limit, and do not auto-retry. If a 120 aggregate-CPU-second budget is granted, stop at an advance cumulative threshold such as 110 seconds, measured across the process tree; retain a hard backstop. Do not reuse the prior per-child-only accounting that overran its total budget

The decision output is **which operator family increases post-release anonymous RSS and which backend actually ran**. A positive finding supports a separately approved single-variable cache/allocator or SDPA comparison. A small or incomplete replay does not exonerate the full native execution path or demonstrate a fix. In particular, do not change `fp32_precision` to diagnose explicit BF16 inputs, and do not combine multiple cache/allocator toggles so their effects become unidentifiable.

The existing allocation replay and this review do not establish model competence, a complete answer, no-crop parity or eviction benefit.

### Additional local source hashes

- `transformers/integrations/sdpa_attention.py`: `0523b9e7b375941b91c226aa850ffc18af709d8f697701fd16f2babaec32f23f`
- `torch/version.py`: `1f11d022311106326d68591dacb5f86ba859bb6fa4d05e19b18490a072ce77f6`
- `torch/include/ATen/Config.h`: `ebecd3af7eccdb3a112a1d53b2248b178960a27cb17f6dd4d28ac6fd18bddae7`
- `torch/include/oneapi/dnnl/dnnl_version.h`: `7fdfca2a07164a9645a98dd287dfe3e2bf5bf264eca7a7291114677472f09c57`
