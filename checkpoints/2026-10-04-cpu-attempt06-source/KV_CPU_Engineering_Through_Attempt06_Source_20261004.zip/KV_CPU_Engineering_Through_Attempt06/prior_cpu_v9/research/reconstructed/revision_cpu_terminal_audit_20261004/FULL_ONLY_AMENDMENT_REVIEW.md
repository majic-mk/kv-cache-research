# Full-only amendment: narrow independent review

PASS for the specified prospective scope change, subject to additive durable backup and explicit parent launch GO. No launch or model call was performed by this review.

Final protocol: 2bf44eedde0e6a12e4bc778a4cec70aae848c68325296b0c8126a56091bfbf44
Final source manifest: 7cc53a6043833d71c266f04c9db605ed1c7aa699fcc23a1ee132f8b9af7f5ce8
Path: research/reconstructed/revision_cpu_full_only_20261004
Reviewer: /root/assess_next_cpu_model_gate

The parent-approved amendment reduces the remaining workload to one native Full arm, using exactly the same first frozen input, 82 original chunks, pinned plain-Qwen3 checkpoint, CPU BF16/native arithmetic, greedy maximum 64-token generation, and EOS 151645. The first paired attempt is preserved as a timing feasibility stop after 233 tokens with zero generated answer tokens. The new attempt cannot establish no-crop parity or eviction efficacy.

The actual runner changes only the total prospective call envelope from 290 to 145 and removes second-arm/semantic-wait continuation, writing NATIVE_FULL_GENERATION_COMPLETE_SEMANTIC_REVIEW_PENDING after normal completion. The common helper binds the separate protocol; the identical watchdog and pager operate from a separate directory/claim. The existing release byte remains enabled but operational launch still requires the parent’s GO. No native arithmetic, threshold, input, generation cap, or memory/disk guard changed. The dead no-crop implementation remains in the source but there is no invocation.

All source-manifest hashes and Python syntax were verified. Model/runtime/inputs/storage/acquisition-anchor protocol sections are value-equivalent to v2. All numeric resource and timing limits are identical: 6 GiB sampled process-tree RSS, 5 GB disk floor, 256 MB evidence, 1.5 GB live/6 GB start host available memory, at most 1800 seconds own phase, and the original 17:28:20.316980 UTC overall/17:25:20.316980 compute cutoffs. The source binds the same immutable acquisition receipt. The failed first attempt is explicitly included in cumulative accounting.

Prospective arithmetic: 2 × 4.847722630001954 observed maximum seconds × 145 possible fresh calls = 1,405.839562701 seconds. It can fit the remaining original window if launched promptly, but rising attention/evidence costs can still trigger the unchanged 2× projection at or after call 3. The watchdog and evidence checks remain active; this is not a completion guarantee.

Two copied metadata fields were corrected before final freeze: the amendment timestamp now records 16:56:31.062518 UTC and vector evidence names the single native Full arm. No further gate or model test is needed for this narrowly reviewed delta. A completed answer must still receive a source-based independent semantic review after guarded exit. Incorrect, unsupported, incomplete or cap-hit output cannot establish competence.
