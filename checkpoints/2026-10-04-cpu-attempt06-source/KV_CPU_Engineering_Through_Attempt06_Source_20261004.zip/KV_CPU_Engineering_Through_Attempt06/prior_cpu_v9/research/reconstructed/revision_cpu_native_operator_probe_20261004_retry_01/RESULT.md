# Native operator attribution: complete

All 39 frozen shape pairs completed: 273 synthetic Linear calls, 78 attention matmuls, 39 softmaxes, and two separately marked synthetic head GEMMs. No model/config/checkpoint/generation was used. Baseline backend settings were retained; no trim, allocator/cache toggle or SDPA was tested.

## Main finding

This model-free native execution creates substantial **freed-but-retained process heap**. At the end, with every tracked synthetic tensor released:

- RSS: 1,151,455,232 B, versus 216,481,792 B at baseline; increase **934,973,440 B**
- Anonymous memory increase: **922,988,544 B**
- glibc arena increase: **919,863,296 B**
- glibc free heap increase: **869,076,528 B**
- glibc allocated heap increase: **50,786,768 B**
- mmap allocation total returned to its baseline 4,153,344 B

Thus the observed ~935 MB residual is predominantly accompanied by glibc-free arena space, rather than the tracked live tensors. Whether and how much `malloc_trim(0)` would return is **not measured**. Free arena totals are allocator accounting, not a direct page-residency inventory.

At the last decoder chunk, known live tensor storage was only 65,036,288 B: one 49,807,360 B arena plus one layer's 15,228,928 B KV. RSS was 1,201,250,304 B. Removing those buffers reduced RSS by the arena's ~49.8 MB; most heap remained resident. Sequential checkpoint RSS growth was concentrated around QK and repeated-KV/mask phases, with later softmax/output-projection phases sometimes releasing or reusing memory. These phase deltas are correlations, not independent per-kernel allocated-byte totals.

The separate 777,912,320 B head weight allocation raised RSS to 1,929,359,360 B. The two head GEMMs added only 12,288 B at measured boundaries, and releasing the head returned its ~778 MB. This probe gives no evidence for a retained extra head-weight copy.

## Native path actually observed

All **353 matmul executions** were logged as `brg_matmul:avx512_core_bf16`, `attr-scratchpad:user`: 275 dense linears including the head and 78 attention BMMs. Verbose primitive creation recorded 164 cache misses and 189 hits. All 36 real-model layers sharing similar descriptor families would not automatically create 36 independent copies of these cache entries.

Runtime receipts identify:

- Torch 2.9.1+cpu, commit 5811a8d7da873dd699ff6687092c225caffcf1bb
- oneDNN 3.7.1, commit 8d263e693366ef8db40acc569cc7d8edf644556d
- Intel MKL 2024.2, product build 20240605
- OpenMP 4.5; actual ATen/OpenMP/MKL thread count 4, inter-op 1
- oneDNN ISA: AVX-512 with DL Boost and BF16 support; no GPU

No MKL GEMM execution lines appeared; the native matmul evidence is oneDNN. MKL build presence alone should not be used to blame its fast-memory pool.

## Safety and execution accounting

The authorized technical retry corrected the failed attempt's CPU-limit inheritance order. Its stdlib-only regression verified child CPU limits 105/105 and parent limits 7/8, using 0.048364 CPU seconds. Failed original sources/receipts remain separate and unchanged.

- Successful probe guarded wall: **7.516 seconds**
- Total recorded CPU, including failed startup and launch regression: **24.701726 seconds**
- Sampled combined guard/child peak RSS: **1,940,910,080 B**, below 2 GiB
- Lowest sampled host available: **5,219,266,560 B**, above 1.5 GB; fresh host >=6 GB verified
- Lowest sampled free disk: **9,055,993,856 B**, above 5 GB
- Combined sampled artifacts including failed attempt: **1,138,229 B**, below 16 MB
- Child exit 0, no guard stop/error; owned process group explicitly checked absent

No observed cap deviation in the successful probe. The 24.70-second figure includes the failed guarded startup, regression and successful guard/child; source preparation and post-run analysis commands are not counted as probe process CPU. Guard sampling cannot rule out between-sample transient memory peaks.

## What this does and does not establish

The new positive finding is allocator retention **with native operator execution included**. Earlier allocation-only replay omitted the native kernels. However, its 36-layer allocation pattern is not an apples-to-apples control for this one-layer probe. This result does not identify all ~3.9 GB excess in the failed Qwen3 run, establish a leak, prove a trim/cache/SDPA fix, or yield any answer/competence/no-crop/eviction result.

Full phase samples, exact shapes/strides/live-storage inventory and glibc/smaps readings are in `memory.jsonl`; backend events in `backend.log`; build details and numerical summaries in `ANALYSIS.json`. Frozen source hashes were reverified after completion.
