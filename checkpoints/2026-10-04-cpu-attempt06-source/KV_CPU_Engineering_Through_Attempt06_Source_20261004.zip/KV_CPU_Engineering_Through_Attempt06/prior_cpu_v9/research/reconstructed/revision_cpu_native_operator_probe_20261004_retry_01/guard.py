"""External cumulative-CPU/RSS/resource guard. Exactly one launch, no retries."""
from pathlib import Path
import ctypes,hashlib,json,os,resource,selectors,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
LIMITS=dict(combined_RSS_bytes=2*1024**3,host_available_bytes=1_500_000_000,fresh_host_available_bytes=6_000_000_000,free_disk_bytes=5_000_000_000,total_artifact_bytes=16_000_000,backend_log_bytes=8_000_000,memory_log_bytes=4_000_000,wall_seconds=60,aggregate_CPU_stop_seconds=100,child_hard_CPU_seconds=105,guard_hard_CPU_seconds=8,aggregate_CPU_hard_backstop_budget_seconds=120)
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def available():return next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
def proc_table():
    result={}
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            x=path.read_text().rsplit(')',1)[1].split()
            result[int(path.parent.name)]={'ppid':int(x[1]),'pgrp':int(x[2]),'start':int(x[19]),'cpu_ticks':int(x[11])+int(x[12]),'rss':int(x[21])*os.sysconf('SC_PAGE_SIZE')}
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return result
def descendants(table,pid):
    found={pid};old=set()
    while old!=found:
        old=found.copy();found|={i for i,v in table.items() if v['ppid'] in found or v['pgrp']==pid}
    return found
def select_reason(rss,host,disk,bytes_,wall,cpu):
    if rss>=LIMITS['combined_RSS_bytes']:return 'COMBINED_RSS_2GIB'
    if host<LIMITS['host_available_bytes']:return 'HOST_AVAILABLE_BELOW_1_5GB'
    if disk<LIMITS['free_disk_bytes']:return 'FREE_DISK_BELOW_5GB'
    if bytes_>=LIMITS['total_artifact_bytes']:return 'ARTIFACTS_16MB'
    if wall>=LIMITS['wall_seconds']:return 'WALL_60S'
    if cpu>=LIMITS['aggregate_CPU_stop_seconds']:return 'AGGREGATE_CPU_100S'
def selftest():
    t={10:{'ppid':1,'pgrp':10},11:{'ppid':10,'pgrp':10},12:{'ppid':11,'pgrp':10},99:{'ppid':1,'pgrp':99}}
    require(descendants(t,10)=={10,11,12},'Tree accounting test')
    normal=[0,6_000_000_000,6_000_000_000,0,0,0]
    tests=[(0,2*1024**3,'COMBINED_RSS_2GIB'),(1,1_499_999_999,'HOST_AVAILABLE_BELOW_1_5GB'),(2,4_999_999_999,'FREE_DISK_BELOW_5GB'),(3,16_000_000,'ARTIFACTS_16MB'),(4,60,'WALL_60S'),(5,100,'AGGREGATE_CPU_100S')]
    require(select_reason(*normal) is None,'Normal limits test')
    for i,v,expected in tests:
        x=normal.copy();x[i]=v;require(select_reason(*x)==expected,'Limit test '+expected)
    require(LIMITS['child_hard_CPU_seconds']+LIMITS['guard_hard_CPU_seconds']+2<120,'Hard limit headroom')
    return {'passed':True,'checks':9,'model_or_operator_execution':False}
def main():
    selftest();manifest=json.loads((P/'source_manifest.json').read_text());protocol=json.loads((P/'protocol.json').read_text())
    prior_cpu=protocol['prior_attempt_and_launch_test_CPU_seconds'];prior_artifacts=protocol['prior_attempt_artifact_bytes']
    require(0<=prior_cpu<2,'Prior CPU accounting')
    for name,sha in manifest['sha256'].items():require(hashlib.sha256((P/name).read_bytes()).hexdigest()==sha,'Frozen source mismatch '+name)
    require(not (P/'RUN_ONCE.json').exists(),'No retries permitted')
    host=available();disk=shutil.disk_usage(P).free
    require(host>=LIMITS['fresh_host_available_bytes'],'Fresh host below 6GB')
    require(disk>=LIMITS['free_disk_bytes']+LIMITS['total_artifact_bytes'],'Fresh disk reserve')
    launch={'unix_time':time.time(),'fresh_host_available':host,'fresh_free_disk':disk,'limits':LIMITS,'manifest_sha256':hashlib.sha256((P/'source_manifest.json').read_bytes()).hexdigest(),'guard_pid':os.getpid()}
    (P/'RUN_ONCE.json').open('x').write(json.dumps(launch,indent=2)+'\n')
    proc=None;reason=None;error=None;peak=0;cpu_peak=0;minimum_host=host;minimum_disk=disk;stream_bytes=0;max_log_bytes=0;cpu_seen={};begin=time.monotonic();last_sample=0
    def kill():
        if proc is not None:
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    def handler(sig,frame):
        nonlocal reason
        reason='GUARD_SIGNAL_'+str(sig);kill()
    for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGXCPU):signal.signal(sig,handler)
    signal.alarm(60)
    def child_limits():
        resource.setrlimit(resource.RLIMIT_CPU,(105,105));resource.setrlimit(resource.RLIMIT_FSIZE,(4_000_000,4_000_000))
        # If this independent guard dies unexpectedly, its owned child is killed.
        libc=ctypes.CDLL(None)
        if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:os._exit(127)
        if os.getppid()!=launch['guard_pid']:os._exit(127)
    env=os.environ.copy();env.update(PROBE_GUARD_PID=str(os.getpid()),ONEDNN_VERBOSE='profile',MKL_VERBOSE='1',PYTHONUNBUFFERED='1')
    command=['bash',str(ROOT/'research/reconstructed/runtime_recovery_20261004/cpu_python.sh'),str(P/'probe.py')]
    try:
        with (P/'backend.log').open('xb') as backend,(P/'guard_samples.jsonl').open('x',buffering=1) as samples:
            proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=child_limits,env=env)
            # Reduce only this guard after fork: child already installed 105s.
            resource.setrlimit(resource.RLIMIT_CPU,(7,8))
            os.set_blocking(proc.stdout.fileno(),False);sel=selectors.DefaultSelector();sel.register(proc.stdout,selectors.EVENT_READ)
            while True:
                for key,_ in sel.select(timeout=.02):
                    block=os.read(key.fd,65536)
                    if block:
                        room=LIMITS['backend_log_bytes']-stream_bytes
                        backend.write(block[:room]);backend.flush();stream_bytes+=min(len(block),room)
                        if len(block)>room:reason='BACKEND_LOG_8MB';kill()
                    else:sel.unregister(key.fileobj)
                table=proc_table();ids=descendants(table,proc.pid)
                for pid in ids:
                    if pid in table:
                        x=table[pid];k=(pid,x['start']);cpu_seen[k]=max(cpu_seen.get(k,0),x['cpu_ticks'])
                own=resource.getrusage(resource.RUSAGE_SELF);cpu=prior_cpu+sum(cpu_seen.values())/os.sysconf('SC_CLK_TCK')+own.ru_utime+own.ru_stime
                rss=sum(table[i]['rss'] for i in ids|{os.getpid()} if i in table);host=available();disk=shutil.disk_usage(P).free
                total_bytes=prior_artifacts+sum(p.stat().st_size for p in P.rglob('*') if p.is_file());wall=time.monotonic()-begin
                peak=max(peak,rss);cpu_peak=max(cpu_peak,cpu);minimum_host=min(minimum_host,host);minimum_disk=min(minimum_disk,disk);max_log_bytes=max(max_log_bytes,total_bytes)
                reason=reason or select_reason(rss,host,disk,total_bytes,wall,cpu)
                if wall-last_sample>=.1 or reason:
                    samples.write(json.dumps(dict(wall_seconds=wall,aggregate_CPU_seconds=cpu,combined_RSS_bytes=rss,host_available_bytes=host,free_disk_bytes=disk,total_artifact_bytes=total_bytes,stop=reason))+'\n');last_sample=wall
                if reason:kill()
                rc=proc.poll()
                if rc is not None and not sel.get_map():break
                if reason and wall>=62:raise RuntimeError('Stop cleanup exceeded grace')
            proc.wait();sel.close()
    except BaseException as e:error=repr(e);reason=reason or 'GUARD_EXCEPTION';kill()
    finally:
        kill()
        if proc is not None:proc.wait()
        signal.alarm(0)
        child=resource.getrusage(resource.RUSAGE_CHILDREN);own=resource.getrusage(resource.RUSAGE_SELF)
        this_cpu=child.ru_utime+child.ru_stime+own.ru_utime+own.ru_stime;total_cpu=prior_cpu+this_cpu
        group_absent=True
        if proc is not None:
            try:os.killpg(proc.pid,0);group_absent=False
            except ProcessLookupError:pass
        receipt=dict(status='COMPLETE' if proc is not None and proc.returncode==0 and reason is None and error is None else 'STOPPED_OR_FAILED',exit_code=None if proc is None else proc.returncode,termination=reason,guard_error=error,wall_seconds=time.monotonic()-begin,aggregate_CPU_seconds=total_cpu,child_CPU_seconds=child.ru_utime+child.ru_stime,guard_CPU_seconds=own.ru_utime+own.ru_stime,max_sampled_aggregate_CPU_seconds=cpu_peak,peak_combined_RSS_bytes=peak,minimum_host_available_bytes=minimum_host,minimum_free_disk_bytes=minimum_disk,maximum_sampled_artifact_bytes=max_log_bytes,backend_log_bytes=stream_bytes,owned_process_group_absent=group_absent,limits=LIMITS,command=command,model_calls=0,checkpoint_reads=0,GPU=False,automatic_retries=0)
        receipt.update(prior_attempt_and_launch_test_CPU_seconds=prior_cpu,this_attempt_CPU_seconds=this_cpu,prior_attempt_artifact_bytes=prior_artifacts,technical_retry_index=1,additional_retry_permitted=False)
        receipt['caps_passed']=bool(total_cpu<=120 and receipt['wall_seconds']<=60 and peak<=2*1024**3 and minimum_host>=1_500_000_000 and minimum_disk>=5_000_000_000 and max_log_bytes<=16_000_000)
        (P/'guard_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
    return 0 if receipt['status']=='COMPLETE' and receipt['caps_passed'] else 1
if __name__=='__main__':
    import sys
    if '--self-test' in sys.argv:print(json.dumps(selftest()))
    else:raise SystemExit(main())
