"""Tiny stdlib-only regression: child limits before guard reduction."""
from pathlib import Path
import ctypes,json,os,resource,signal,subprocess,sys,time
P=Path(__file__).resolve().parent
started=time.monotonic();parent_pid=os.getpid()
def child_limits():
    resource.setrlimit(resource.RLIMIT_CPU,(105,105))
    resource.setrlimit(resource.RLIMIT_FSIZE,(4_000_000,4_000_000))
    libc=ctypes.CDLL(None)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:os._exit(127)
    if os.getppid()!=parent_pid:os._exit(127)
code='import json,resource; print(json.dumps({"CPU":resource.getrlimit(resource.RLIMIT_CPU),"FSIZE":resource.getrlimit(resource.RLIMIT_FSIZE)}))'
proc=subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,preexec_fn=child_limits)
resource.setrlimit(resource.RLIMIT_CPU,(7,8))
try:out,err=proc.communicate(timeout=2)
finally:
    if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
observed=json.loads(out)
own=resource.getrusage(resource.RUSAGE_SELF);child=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=own.ru_utime+own.ru_stime+child.ru_utime+child.ru_stime
result={'passed':proc.returncode==0 and observed['CPU']==[105,105] and observed['FSIZE']==[4_000_000,4_000_000] and resource.getrlimit(resource.RLIMIT_CPU)==(7,8) and cpu<1,'child_limits':observed,'parent_CPU_limits':resource.getrlimit(resource.RLIMIT_CPU),'CPU_seconds_parent_plus_child':cpu,'wall_seconds':time.monotonic()-started,'Torch_import':False,'operator_calls':0,'stderr':err,'exit_code':proc.returncode}
(P/'launch_inheritance_test.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if not result['passed']:raise SystemExit(1)
