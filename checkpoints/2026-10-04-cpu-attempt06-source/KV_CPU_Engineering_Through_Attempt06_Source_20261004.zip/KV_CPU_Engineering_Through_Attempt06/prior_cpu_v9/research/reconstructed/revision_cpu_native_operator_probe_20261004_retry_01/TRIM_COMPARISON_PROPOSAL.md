# Proposed single-variable comparison, not implemented or run

## Question

Does process-local `malloc_trim(0)` at each completed chunk boundary reclaim the large free-heap residual now observed during **native operator execution**, while preserving exact synthetic operator outputs?

This is different from the earlier allocation-only trim replay, which omitted the native matmul execution now associated with heap growth. It remains a model-free test and cannot establish a full-model remedy.

## Frozen comparison

Two fresh processes, control then trim, each with exactly the current 39-shape schedule, one synthetic layer's seven Linears, two eager attention matmuls/softmax per shape, and the same two synthetic head calls. Same Torch/runtime/thread/backend settings and deterministic constant tensors. Same memory checkpoints and backend logs. Both arms release chunk temporaries identically and take pre/post-boundary readings; only the trim arm calls process-local `malloc_trim(0)` at that point. Record trim's return value and pre/post RSS/smaps/mallinfo2. No global allocator, cache, OS or attention setting changes.

Hash corresponding outputs in **both** arms before releasing them: seven Linear outputs, QK after scale/mask, BF16 softmax probabilities, AV output, and two head outputs. Stream SHA256 records with call/phase/shape/dtype. Use transient zero-copy contiguous uint8 memoryviews and bounded <=4 MiB hash slices; no retained tensor history or output files. These outputs are contiguous at the selected boundaries; fail rather than silently make a large non-contiguous copy.

Static hash work per arm:

- Seven Linear outputs: 228,433,920 B
- QK outputs: 455,943,872 B
- Softmax probabilities: 455,943,872 B
- AV outputs: 30,457,856 B
- Two head outputs: 607,744 B
- **Total 1,171,387,264 B per arm**, 392 output digests; largest individual output 29,286,400 B

The 39*10+2=392 digest count includes 7 Linear + QK + softmax + AV per chunk. Zero-copy chunked hashing avoids a new full output allocation. CPU overhead is unmeasured: allow roughly 2–5 additional CPU seconds per arm for planning, without claiming a benchmark. Both arms include identical hashing overhead; absolute footprint need not match the prior unhashed probe.

## Proposed limits and stop rules

- Fresh host available >=6,000,000,000 B before each arm
- Same external combined RSS ceiling 2 GiB, host-available floor 1.5 GB, free-disk floor 5 GB
- Aggregate artifacts for both new arms plus retained prior probe attempts <=16 MB; cap each backend log at 2 MB and each phase/digest log at 3 MB; stop on overflow
- Each arm wall <=45 seconds; child hard CPU <=36 seconds; its external guard hard CPU <=5 seconds
- Carry **24.701726 CPU seconds** already spent on the failed startup, launch regression and successful probe into cumulative accounting. Independent polling stops at **100 cumulative CPU seconds**, including both new guards/children; hard budget remains 120. Kernel per-process hard limits, with 2 seconds accounting headroom per new guard/child pair, bound the planned cumulative allowance to 110.701726 seconds. Record actual totals; do not present the proactive threshold as a successfully consumed budget
- Launch each arm from a fresh independent guard process, applying that guard's own lower CPU limit only after its child is spawned. This preserves the verified inheritance fix for both launches
- No retries. Stop the pair if a safety cap or unexpected error occurs. Compare only common complete output/shape prefixes when both arms have data; do not call an incomplete pair a full pass

Given the observed 23.93 child CPU seconds and 7.52 wall seconds for the unhashed sequence, two complete arms appear feasible within these prospective limits, but hashing/trim overhead could cause a partial result.

## Decision output

Report exact hash parity on the common completed prefix; boundary pre/post-trim deltas; end-of-sequence retained heap/RSS; peak RSS and CPU/wall costs. A large reproducible decrease with exact output hashes would demonstrate reclaimable retention for this synthetic workload. It would justify considering measured trim in separately approved model work, not authorize that work or guarantee the real 4B case fits.
