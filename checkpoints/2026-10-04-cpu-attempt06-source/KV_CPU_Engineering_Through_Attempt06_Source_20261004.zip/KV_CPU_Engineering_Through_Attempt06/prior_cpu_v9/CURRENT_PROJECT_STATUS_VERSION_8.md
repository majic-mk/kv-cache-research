# Final reviewed attempt-4 status and separate calibration preparation

The exact Full/trim CPU run passed its resource limits and executed the full 7,669-token prompt plus 64 sampled answer tokens. It failed the unchanged answer qualification because it hit the 64-token cap without EOS, ended mid-sentence and opened with an abstention contradicted by the source. The correct “5–2” fragment is preserved. This is not simply a wrong-score selection, a failure of the authors’ benchmark, or proof of broad model/method impossibility.

The independent terminal narrative is now included alongside the previously archived machine-readable audit. It verifies all 145 raw BF16 vectors, all 64 greedy selections, 5,220 K/V append records and all 39 prior prefix matches; the prompt assembly/tokenization check reproduces the frozen 7,669 IDs. No demonstrated assembly or causal-indexing defect was found. No independent unchunked/full-sequence comparison or no-crop/eviction arm was run.

Recorded wall time is 819.202078819 seconds, child CPU 2,769.159191 seconds, peak process-tree RSS 3,856,797,696 bytes and minimum host available memory 2,890,448,896 bytes. These measured execution costs establish resource completion for this run, not a throughput or KV-method benefit.

A separate post-exit streaming disk check at 18:26:48–18:26:59 UTC verified all 10 pinned local assets totaling 8,060,896,487 bytes. It is distinct from the runner's skipped in-process final rehash and resident/gate/RoPE checks. The latter did not run because the EOS gate failed; the separate receipt does not retroactively claim otherwise. No weights are included in this archive.

The final narrative also records a material interpretation limit: the project's 64-token smoke cap is much shorter than the pinned TRIM author runner's default 800 sampled decode steps (at most 799 appended tokens in that code). The literal pinned LongMemEval default also resolves to 800 in the reviewed branch. The frozen short-gate failure remains valid; longer-budget behavior was not observed in this checkpoint. Neither a correct later completion nor continued failure is inferred. Any new calibration needs a separately declared protocol and budget with this outcome preserved.

All 1,027 version-7 payload entries remain byte-identical. The new narrative and post-exit receipt add evidence without changing raw outputs or earlier protocols. PACKAGE_MANIFEST_VERSION_8.json covers every payload except itself, and CPU_VERSION_8_ADDITION.json records the additive boundary. The original 592 raw attempt files, additional semantic review, complete earlier CPU history and preparation remain included. Model weights, environments, download symlinks and declared bytecode exclusions remain external.

Main scientific outcomes remain unchanged, with no validated novel main method. AutoDL charges and cancellation remain unverified; no new paid route is represented here. Engineering hours and platform included allowance usage remain unquantified. All prior expense records and the separate allocation-only CPU-budget deviation are retained.

Full CPU archive: https://chatgpt.com/api/library/files/libfile_df6d73c95c28819181e8c3418427c3ec/download
Pinned prior-source audit archive: https://chatgpt.com/api/library/files/libfile_ccad5038b0b881919fbe66478025b6b4/download

## Separately declared author-budget preparation

This revision also preserves a new, independently reviewed pre-run protocol. It does not change or repair the old 64-token verdict. It calibrates author-budget baseline generation on the same frozen CPU input, with unchanged checkpoint, native math, paging and trim. It is not a reproduction of the author's different prompt/runtime/benchmark.

The declared loop allows up to 800 greedy selections and at most 799 emitted/fed tokens. EOS or final selection index 799 stops before append/feed. The terminal EOS or discarded last selection is saved as evidence only; EOS on the last selection remains EOS. The effective EOS set is {151645}. All 145 previous raw vectors/KV records and the first 64 selected IDs must match before extension beyond the old output is accepted.

This is one separately authorized attempt with a fresh 3,600-second model phase, 180-second cleanup reserve and 384 MB evidence cap. Memory/host-reserve/disk limits remain unchanged. The 881-call worst-case trajectory may exceed the hard time cap; timeout is a possible censoring outcome, not permission to extend the budget. No actual calibration call has occurred at this freeze, and launch still requires explicit GO and fresh runtime admission.

AUTHOR_BUDGET_PRERUN_STATUS.json pins the source, independent review, original author runner/license and all prior-reference checks. The short-gate result remains negative regardless of future calibration. This archive adds preparation, not a longer-generation result.
