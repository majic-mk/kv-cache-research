# Current project status: CPU validation and memory diagnosis

As of 2026-10-04 17:25 UTC. Read this additive update alongside CURRENT_PROJECT_STATUS_20261004_CPU_TERMINAL.md. Every version-3 entry remains byte-identical.

Pretrained 4B CPU validation remains inconclusive after the final actual host-memory stop. Across the three preserved attempts there were 50 completed native Full calls and 4,527 processed input tokens including repeated prefixes, zero generated tokens, zero answers and no no-crop execution. The largest completed unique prefix was 3,718 of 7,669 fixed tokens. No competence result, method-effect ranking, routing parity or eviction benefit is established. The earlier first24 negative gate and Full6 competence failure remain unchanged.

The final run stopped when host available memory fell to 1,329,688,576 bytes below the 1.5 GB reserve. Its sampled peak process-tree RSS was 5,384,413,184 bytes, below the separate 6 GiB limit. The read-only diagnosis estimates about 1.47 GB of explicit persistent tensor payload at that prefix, leaving roughly 3.9 GB of excess RSS without a proven root cause. Allocation churn, allocator retention and backend workspaces are plausible contributors; saved aggregate traces do not identify one cause or prove a leak. MEMORY_DIAGNOSIS.md and memory_diagnosis_evidence.json preserve the source/trace evidence and limits.

The subsequent allocation-only replay is a partial engineering diagnostic. It used synthetic tensor allocations with no model, checkpoint, matmul or LLM forward. The control completed 39 chunks; the trim arm was killed during its 39th chunk and has only 38 complete chunks. Comparisons are restricted to their common 38 chunks / 3,618 tokens. At that boundary trim reclaimed 89,112,576 bytes, and the largest observed boundary reclaim was 239,714,304 bytes. Combined peak RSS was about 1.10 GB, excluding the model/gate/arena fixed floor of 922,816,064 bytes. This does not recreate or explain the actual multi-GB RSS gap, establish an allocator-only cause, or prove a fix.

The replay consumed 123.096495 child CPU seconds against its proposed 120-second total cap, a 3.096495-second overrun. This is an explicit protocol deviation and guard limitation, not a successful CPU-budget check. Total wall time was 35.901282666 seconds, within 60 seconds. The trim process ended with SIGKILL without a parent resource trigger; the saved analysis calls the child CPU limit consistent with that outcome, while leaving the signal issuer unverified. Original scripts, partial evidence, guards and analysis are preserved without repair or retry.

No more pretrained-model attempt, paid path or retry is authorized in this window. AutoDL actual charges and cancellation remain unverified after its unresolved HTTP 502 submission and final 17:03:38 console check; do not record fees as zero. EXPENSES_20261004_CPU_TERMINAL.json and the exact operator receipt remain unchanged. There were no other purchases or paid API calls, platform included allowance usage is unquantified, and engineering hours were not logged. The allocation-only CPU total is separate from the actual-model CPU total of 1,010.189648 seconds.

## Reproducibility and scope

PACKAGE_MANIFEST_VERSION_4.json hashes all retained payload entries except itself. CPU_VERSION_4_ADDITION.json binds this revision to version 3 and the frozen allocation replay manifest. The replay's 14 original source/protocol/raw/guard/analysis files plus its manifest are included. The complete saved partial evidence from all three actual CPU attempts remains present. No models, tests or tokenizers were run while archiving.

Weights, download symlinks, environments and earlier declared synthetic tensor exclusions remain external. The current packet is complete for recorded evidence and retained source, not self-contained for execution. A separate ongoing primary-source investigation is outside this frozen checkpoint; its unfinished work is not included.

CPU checkpoint: https://chatgpt.com/api/library/files/libfile_df6d73c95c28819181e8c3418427c3ec/download
Main scientific checkpoint v7: https://chatgpt.com/api/library/files/libfile_720dc25a6108819181ce77e9d2fadf63/download
Full6 terminal: https://chatgpt.com/api/library/files/libfile_bc699f2b72ec81918c58febc973672af/download
