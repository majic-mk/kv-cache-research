# Author-budget calibration: completed answer fails source-based qualification

Attempt5 completed naturally at EOS after 162 greedy selections, emitting and feeding 161 tokens over 243 native calls. It passed resource, recorded-numerical and final integrity checks. Independent whole-answer semantic review failed. The answer contains the correct number 5–2 but attributes it to June16, misses the June30 update and concludes that the current record is unavailable. The source reports 3–2 on June16 and the latest 5–2 on June30. A supported latest-known/date-qualified answer was acceptable under the predeclared rubric.

This is distinct from attempt4's incomplete 64-token cap failure: the new response was naturally complete and was not capped or resource-censored. The old outcome remains unchanged. All 145 old raw-vector/KV records and the first 64 selected IDs match exactly. The new result closes this fixed pilot at its unchanged Full-baseline competence gate; no no-crop, compressed/eviction or GPU comparison was executed. It is one constructed-input result for this pinned native chunked CPU path, not a full author benchmark reproduction, aggregate score, general model incapability or impossibility claim about revision-sensitive KV research.

## Execution and verification

- 7,669 fixed prompt tokens; 161 fed generated tokens; 7,830 final ingested tokens
- 162 selections; terminal selection index161 is EOS151645 and was neither emitted nor fed
- 243 original BF16 vocabulary vectors, 73,840,896 decompressed bytes; 8,748 layer K/V append metadata records
- 162 selection records, 243 trim receipts and 241 advisory forecasts
- 1,323.211332560 seconds guarded wall; 4,160.038728 child CPU seconds
- Peak sampled process-tree RSS 3,758,768,128 bytes; minimum host available memory 2,947,284,992 bytes
- Exit0, no resource termination/watchdog exception, owned-process absence verified
- Final in-process resident/gate/RoPE checks and official shard rehash passed; no-crop and GPU remained unrun

Independent audit verifies all243 vectors,162 greedy choices, source positions, prior-prefix equality and author select/check-before-append termination. Full K/V tensor bytes were not retained; their hashes/shapes were. Source, exact full answer, producer outcome, independent narrative and machine receipts are preserved. Earlier pending-review strings describe their own creation time and are superseded by the separate bound final review.

## Exact restoration boundary

This cumulative checkpoint retains every one of version8's1,053 payload entries unchanged and adds terminal metadata plus the retrieval index. The complete attempt5 raw output is in a separate private Library artifact, identified by ATTEMPT_05_ARCHIVE_INDEX.json with exact ID, version, filename, size and SHA-256. It includes all1,146 original raw files /70,312,310 bytes, the additional bound semantic review, exact calibration source/protocol, frozen input, original author source/license and final audits. Nothing was dropped from the raw run to make the cumulative checkpoint smaller.

For complete restoration, retain both artifacts. Extract into fresh directories, verify both manifests, and merge only identical duplicate source/review files. The cumulative checkpoint contains prior attempt4 reference raw data needed to recheck the145 shared-prefix comparisons. Model weights, environments and download symlinks remain external. The small results package is supplementary and is not the full code/raw archive.

AutoDL charges and cancellation remain unverified under the last saved operational receipt. No new paid route was used for this calibration; no zero-fee inference is made. Platform included allowance usage and engineering hours are unquantified. Execution totals are distinct from engineering labor and from acquisition/preparation/review costs. All earlier scientific negatives and the separate allocation-only CPU-budget overrun remain intact.

No model, test, tokenizer or benchmark was executed during archival. Any future separately declared diagnostic is outside this frozen result.
