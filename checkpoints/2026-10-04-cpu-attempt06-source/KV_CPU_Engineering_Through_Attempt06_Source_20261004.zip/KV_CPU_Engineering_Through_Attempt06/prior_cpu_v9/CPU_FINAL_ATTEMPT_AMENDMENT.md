# Final bounded CPU engineering amendment

Full-only attempt 2 stopped at the existing conservative forecast after 8 actual input calls / 576 tokens, before an answer. All 26 files are preserved, including 8 complete original-BF16 vocabulary vectors (2,430,976 raw bytes) and 288 per-layer K/V append records. Vector hashes were verified after lossless decompression. K/V entries are hashes/shapes, not complete raw K/V tensors.

The guard records 51.0478584766 seconds wall, 137.546596 child CPU seconds and 2,410,582,016 bytes sampled peak process-tree RSS; owned process-group absence was verified. This was a runtime-projection stop. It establishes neither competence nor a compression effect. No answer, no-crop or GPU run occurred.

The separately frozen final amendment was made prospectively after these runtime observations. The unchanged 2x forecast becomes an advisory log instead of an early-abort condition. This explicitly changes the engineering forecast policy; it does not change scientific semantic/numerical acceptance thresholds. One final Native Full attempt uses the same first fixed input, checkpoint and numerical engine, at most 145 calls, the same 6 GiB RSS ceiling and at most 1,800 model-phase seconds. The actual compute cutoff remains 17:25:20.316980 UTC and the overall cutoff remains 17:28:20.316980 UTC. No deadline extension or further retry is included.

Final source, protocol and review hashes are in CPU_VERSION_2_ADDITION.json and research/reconstructed/revision_cpu_deadline_attempt_20261004. This snapshot precedes that final attempt; actual launch still requires parent GO. The hard guard may stop an incomplete run. Forecast logging is not a guarantee of completion.

All 147 prior archive entries remain byte-identical. The original pair protocol/results and prior Full-only amendment/results remain available with their historical manifests and status files. PACKAGE_MANIFEST_VERSION_2.json covers the full current archive; earlier manifests retain their earlier scopes. No weights, environments or download symlinks were added, and no models/tests were run for packaging.
