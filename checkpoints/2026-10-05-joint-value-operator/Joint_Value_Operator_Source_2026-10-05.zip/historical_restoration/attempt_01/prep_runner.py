"""Admitted model-free fixtures and one-layer CPU forecast. No real-data paths."""
from pathlib import Path
import hashlib,json,os,resource,subprocess,time,traceback,gc
import numpy as np
import reference as ref
import engine as en
from artifact_contract import Reader,LAYERS,ARMS,sha,attention,ratio
ROOT=Path(__file__).resolve().parent; OUT=Path(os.environ['JV_PREP_ATTEMPT']); CFG=json.loads((ROOT/'prep_config.json').read_text())
def clean(x):
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [clean(v) for v in x]
    return x
def write(name,x): (OUT/name).write_text(json.dumps(clean(x),indent=2,allow_nan=False)+'\n')
def close(a,b,label,tol=2e-10):
    err=float(np.max(np.abs(np.asarray(a)-np.asarray(b)))) if np.size(a) else 0.
    bound=tol*max(1.,float(np.max(np.abs(b))) if np.size(b) else 0.)
    if err>bound: raise AssertionError((label,err,bound))
    return err

def unit_tests(kernel):
    findings=[]; decisions=0
    fixtures=ref.generate_fixtures()
    for f in fixtures:
        P,V,W=f['P'],f['V'],f['W']; grid=ref.grid(V); Q=grid['nearest_codes']; groups,G,m,N=P.shape; d=V.shape[-1]
        np.savez(OUT/(f['name']+'.npz'),**{k:v for k,v in f.items() if isinstance(v,np.ndarray)})
        if f['seed']==2026100543:
            decomposition=ref.loss_decomposition(P,ref.decode(Q,grid['scales'],grid['zeros'])-V,W)
            findings.append({'test':'orthogonal_objectives','decomposition':decomposition})
            L=[float(np.sum(ref.objective_output(P,ref.decode(Q,grid['scales'],grid['zeros'])-V,W,z)**2)) for z in ('full','group','headwise')]
            close(L,np.full(3,L[0]),'orthogonal losses')
        for objective,refname in (('head','headwise'),('group','group'),('full','full')):
            got=en.cd_solve(P,V,W,grid,kernel,objective,budget=10**15,max_sweeps=1,force_one_sweep=True)
            want=ref.naive_full_residual_cd(P,V,W,grid['scales'],grid['zeros'],Q,grid['row_caps'],grid['nearest_sse'],objective=refname)
            if not np.array_equal(got['codes'],want['codes']): raise AssertionError(('CD code mismatch',f['name'],objective))
            path=np.concatenate([r[2] for r in got['paths']]); truth=np.array([r['new'] for r in want['trace']],np.uint8)
            if not np.array_equal(path,truth): raise AssertionError('CD update path differs')
            decisions+=len(path)
            np.savez(OUT/(f['name']+'_'+objective+'_cd.npz'),codes=got['codes'],path=path)
            findings.append({'test':'compact_vs_naive_cd','fixture':f['name'],'objective':objective,'decisions':len(path),'audit':got['audit']})
        for pname,Ptest in [('main',P)]+([('onehot',f['P_one_hot'])] if 'P_one_hot' in f else []):
            rows=np.arange(4); ch=np.arange(4); g0=0
            J=ref.explicit_design(Ptest,W,g0,rows,ch,grid['scales'])
            E=ref.decode(Q,grid['scales'],grid['zeros'])-V; R=ref.full_output(Ptest,E,W); H,grad=ref.exact_hg(J,R)
            background=ref.full_output(Ptest[1:],E[1:],W[1:])
            if np.max(np.abs(background))==0: raise AssertionError('Missing nonzero cross-group background')
            B=en.f64(W[g0,:,:4,:].reshape(G*4,W.shape[-1])); C=B@B.T; S=R@B.T; X=Ptest[g0,:,:,:4].transpose(1,0,2).reshape(m,G*4); T=X.T@X
            Hx=np.einsum('aibj,acbd->icjd',T.reshape(G,4,G,4),C.reshape(G,4,G,4),optimize=False).reshape(16,16)
            sc=np.repeat(grid['scales'][g0,rows].astype(float),4); Hcompact=Hx*sc[:,None]*sc[None,:]
            gcompact=np.einsum('hti,thc->ic',Ptest[g0,:,:,:4],S.reshape(m,G,4)).reshape(16)*sc
            herr=close(Hcompact,H,'explicit H'); gerr=close(gcompact,grad,'explicit g')
            q0=np.ascontiguousarray(Q[g0,:4,:4].reshape(16)); vr=np.repeat(np.arange(4,dtype=np.int32),4); vc=np.tile(np.arange(4,dtype=np.int32),4)
            got=kernel.block(en.f64(Hcompact),en.f64(gcompact),q0,en.f64(grid['scales'][g0,:4]),en.f64(grid['zeros'][g0,:4]),en.f64(V[g0,:4]),np.ascontiguousarray(Q[g0,:4]),en.f64(grid['nearest_sse'][g0,:4]),en.f64(grid['nearest_sse'][g0,:4]),vr,vc)
            want=ref.conditional_block_gptq(H,grad,q0,grid['scales'][g0],grid['zeros'][g0],V[g0],Q[g0],grid['row_caps'][g0],rows,ch,grid['nearest_sse'][g0])
            for a,b in (('raw','raw'),('guard','cap_filtered')):
                if not np.array_equal(got[a],want[b]['q']): raise AssertionError(('block proposal mismatch',f['name'],pname,a))
                close(got['steps'][0 if a=='raw' else 1,0],want['target'],'initial target')
                for j,st in enumerate(want[b]['steps']): close(got['steps'][0 if a=='raw' else 1,j+1],st['target_after'],'feedback step')
            if not np.array_equal(got['accepted'],want['accepted_q']): raise AssertionError('accepted proposal mismatch')
            terr=close(got['target'],want['target'],'conditional target'); uerr=close(got['factor'],want['U'],'inverse Cholesky')
            delta=got['accepted'].astype(float)-q0.astype(float); trueR=R.reshape(-1)+J@delta
            exactloss=float(np.sum(trueR*trueR)-np.sum(R*R)); predicted=float(2*grad@delta+delta@H@delta)
            close([predicted],[exactloss],'undamped conditional loss')
            # Compact accepted update and full residual reconciliation, retaining background.
            physical=sc.reshape(4,4)*delta.reshape(4,4)
            Ustate=np.einsum('hti,ic->thc',Ptest[g0,:,:,:4],physical).reshape(m,G*4)
            close(R+Ustate@B,trueR.reshape(R.shape),'compact accepted full update')
            close(S+Ustate@C,(R+Ustate@B)@B.T,'compact accepted sufficient state')
            np.savez(OUT/(f['name']+'_'+pname+'_block.npz'),H=H,g=grad,J=J,R=R,q0=q0,target=got['target'],factor=got['factor'],steps=got['steps'],raw=got['raw'],guard=got['guard'],accepted=got['accepted'],diag=got['diag'])
            findings.append({'test':'explicit_conditional_block','fixture':f['name'],'attention':pname,'H_error':herr,'g_error':gerr,'target_error':terr,'factor_error':uerr,'accepted_path':int(got['diag'][16]),'kernel_ledger':got['ledger']})
            decisions+=int(got['ledger'][8])
    # Fixed correlated-token fixture forces the guarded token GPTQ fallback.
    tv=np.tile(np.array([0.,.2,.8,1.]),(2,4,1)); tp=np.full((2,2,3,4),.25); tw=np.arange(2*2*4*8,dtype=float).reshape(2,2,4,8)/128-.5
    tg=ref.grid(tv); tr=en.token_gptq(tp,tv,tw,tg,budget=10**15)
    if tr['fallback_count']<1: raise AssertionError('Token fallback fixture failed to exercise guard')
    for st in tr['tiny_trace']:
        i=st['token']; expected=st['before'].copy()
        expected[:,i:]-=((expected[:,i]-st['accepted_decoded'])/st['Urow'][0])[:,None]*st['Urow'][None,:]
        close(st['after'],expected,'token accepted-vector compensation')
    findings.append({'test':'token_fallback_compensation','fallback_count':tr['fallback_count']})
    # Explicit exact rounding-distance ties, independent of a perturbed Newton solve.
    for target in (.5,1.5,2.5):
        raw=np.zeros(1,np.uint8); guard=raw.copy()
        ret=kernel.lib.jv_round_probe(en.ct.c_double(target),en.ct.c_uint8(15),en.ptr(raw,en.U8),en.ptr(guard,en.U8))
        if ret or raw[0]!=int(target+.5) or guard[0]!=raw[0]: raise AssertionError('half-up C ties')
        if ref._nearest_allowed(target,0,np.arange(4))!=raw[0]: raise AssertionError('half-up reference ties')
    # Exactly zero curvature and zero-nearest rows.
    q0=np.zeros(16,np.uint8); V=np.zeros((4,4)); scales=np.ones(4); zeros=np.zeros(4); near=np.zeros(4)
    z=kernel.block(np.zeros((16,16)),np.zeros(16),q0,scales,zeros,V,np.zeros((4,4),np.uint8),near,near,np.repeat(np.arange(4,dtype=np.int32),4),np.tile(np.arange(4,dtype=np.int32),4))
    if np.any(z['accepted']) or z['diag'][16]!=3: raise AssertionError('zero curvature guard')
    try: kernel.block(np.zeros((16,16)),np.ones(16),q0,scales,zeros,V,np.zeros((4,4),np.uint8),near,near,np.repeat(np.arange(4,dtype=np.int32),4),np.tile(np.arange(4,dtype=np.int32),4))
    except RuntimeError: pass
    else: raise AssertionError('inconsistent zero Hessian not rejected')
    # Future suffix contributes to denominator, but unavailable future keys cannot.
    q=np.ones((2,4,4)); keys=np.zeros((10,2,4)); keys[8]=2.; keys[9]=7.
    p=attention(q,keys,[8,9]); changed=keys.copy(); changed[9]=100.; p2=attention(q,changed,[8,9])
    close(p[:,:,0],p2[:,:,0],'causal future-key exclusion',0.)
    if np.any(p[:,:,:,9][:,:,0]) or np.any(np.sum(p[:,:,:,:4],axis=-1)>=1): raise AssertionError('causal denominator')
    prefix_only=attention(q[:1],keys[:8],[7])
    if np.allclose(p[:,:,0,:4],prefix_only[:,:,0,:4]): raise AssertionError('suffix not in denominator')
    if ratio(0,0)!=1 or ratio(1,0)!=float('inf'): raise AssertionError('zero metric')
    # Physical holdout access barrier, using only newly created synthetic files.
    packet=OUT/'synthetic_contract'; packet.mkdir(); rd=Reader(packet,synthetic=True)
    for split in ('calibration','holdout'):
        path=packet/split/'layer_00'; path.mkdir(parents=True); np.save(path/'query.npy',np.zeros((1,1,1),dtype='<u2'))
    rd.load('calibration',0,'query')
    try: rd.load('holdout',0,'query')
    except PermissionError: pass
    else: raise AssertionError('prelock holdout access')
    if len(rd.access)!=1: raise AssertionError('denied holdout was opened')
    records=[]; code=packet/'dummy_codes.npy'; np.save(code,np.zeros(1,np.uint8))
    for layer in LAYERS:
        for arm in ARMS: records.append({'layer':layer,'arm':arm,'full_sweep_complete':True,'row_caps_verified':True,'codes_path':str(code),'codes_sha256':sha(code)})
    rd.lock_encodings(records,packet/'encoding_lock.json'); rd.load('holdout',0,'query')
    findings.append({'test':'ties_zero_causality_and_physical_holdout_barrier','pass':True})
    return {'status':'PASS','decision_checks':decisions,'findings':findings}

def bf16(x): return ((np.asarray(x,np.float32).view(np.uint32)>>16).astype(np.uint16).astype(np.uint32)<<16).view(np.float32).astype(np.float64)
def forecast(kernel):
    started=time.process_time_ns(); rng=np.random.default_rng(CFG['native_forecast_seed']); k,G,N,d,m,p=8,4,192,128,16,2560
    # New synthetic arrays only. Every native-size head/channel/token is retained.
    q=bf16(rng.normal(size=(m,32,d))); keys=bf16(rng.normal(size=(528,k,d))); V=bf16(rng.normal(size=(k,N,d)))
    raw=rng.standard_normal((k,G,d,p),dtype=np.float32)/np.sqrt(p)
    bits=(raw.view(np.uint32)>>16).astype(np.uint16); del raw
    np.save(OUT/'native_synthetic_W_bf16.npy',bits)
    W=(bits.astype(np.uint32)<<16).view(np.float32).astype(np.float64); del bits
    acquisition=en.Work(); allP=attention(q,keys[:512],np.arange(496,512),acquisition); P=en.f64(allP[:,:,:,64:256]); grid=ref.grid(V)
    np.savez(OUT/'native_synthetic_inputs.npz',q=q,keys=keys,V=V,P=P,scales=grid['scales'],zeros=grid['zeros'],nearest=grid['nearest_codes'])
    arms={}; codes={'nearest':grid['nearest_codes']}; acquisition_mac=32*16*512*128
    for name,obj in [('headwise_cd','head'),('group_joint_cd','group'),('full_joint_cd','full')]:
        r=en.cd_solve(P,V,W,grid,kernel,obj,budget=10**15,max_sweeps=1,acquisition_mac=acquisition_mac,force_one_sweep=True)
        codes[name]=r.pop('codes'); first=r.pop('first_sweep'); paths=r.pop('paths')
        np.savez(OUT/(name+'_native_paths.npz'),codes=codes[name],path=np.concatenate([x[2] for x in paths]),kernel_ledgers=np.stack([x[3] for x in paths]))
        r['proposed_work_cap_pass']=r['work']['mac_equivalent_units']<=CFG['work_budget_per_layer_arm']; arms[name]=r; del paths
    r=en.token_gptq(P,V,W,grid,budget=10**15,acquisition_mac=acquisition_mac); r.pop('tiny_trace'); codes['guarded_token_gptq']=r.pop('codes'); rawcodes=r.pop('raw_codes'); r.pop('first_sweep')
    np.savez(OUT/'token_native_codes.npz',guard=codes['guarded_token_gptq'],raw=rawcodes,fallback_flags=r['fallback_flags'])
    r['proposed_work_cap_pass']=r['work']['mac_equivalent_units']<=CFG['work_budget_per_layer_arm']; arms['token_gptq_raw_and_guarded']=r
    r=en.blocked_solve(P,V,W,grid,kernel,budget=10**15,max_sweeps=1,acquisition_mac=acquisition_mac,force_one_sweep=True)
    codes['projected_block_gptq']=r.pop('codes'); r.pop('first_sweep'); paths=r.pop('paths')
    np.savez(OUT/'projected_native_paths.npz',codes=codes['projected_block_gptq'],raw=np.stack([x[3] for x in paths]),guard=np.stack([x[4] for x in paths]),accepted=np.stack([x[5] for x in paths]),diag=np.stack([x[6] for x in paths]),kernel_ledgers=np.stack([x[7] for x in paths]),guard_flags=np.stack([x[8] for x in paths]))
    r['proposed_work_cap_pass']=r['work']['mac_equivalent_units']<=CFG['work_budget_per_layer_arm']; arms['projected_block_gptq']=r; del paths
    # Performance-only evaluation on independently generated synthetic future Q.
    eval_beg=time.process_time_ns(); del W; gc.collect(); io_beg=time.process_time_ns()
    bits=np.load(OUT/'native_synthetic_W_bf16.npy',allow_pickle=False); W=(bits.astype(np.uint32)<<16).view(np.float32).astype(np.float64); del bits
    read_cpu=(time.process_time_ns()-io_beg)/1e9
    qtest=bf16(rng.normal(size=(m,32,d))); ew=en.Work(); PH=attention(qtest,keys,np.arange(512,528),ew)[:,:,:,64:256]
    for name,Q in codes.items():
        R=en.residual_heads(PH,ref.decode(Q,grid['scales'],grid['zeros'])-V,W,ew,'holdout_'+name)
        if not np.all(np.isfinite(R)): raise AssertionError('Synthetic evaluator nonfinite')
        del R
    eval_cpu=(time.process_time_ns()-eval_beg)/1e9
    enc=sum(a['cpu_seconds'] for a in arms.values()); perlayer=(time.process_time_ns()-started)/1e9
    return {'status':'MEASURED_SYNTHETIC_ONE_LAYER','shape':CFG['native_shape'],'arms':arms,'all_required_sweeps_complete':all(a['complete'] for a in arms.values()),'all_proposed_work_caps_pass':all(a['proposed_work_cap_pass'] for a in arms.values()),'physical_shared_attention_work':acquisition.summary(),'encoder_cpu_seconds':enc,'evaluation_and_second_synthetic_W_read_cpu_seconds':eval_cpu,'second_synthetic_W_read_conversion_cpu_seconds':read_cpu,'evaluation_work':ew.summary(),'entire_synthetic_layer_cpu_seconds':perlayer,'six_layer_linear_encoder_plus_evaluation_cpu_forecast':6*(enc+eval_cpu),'six_layer_linear_entire_synthetic_layer_cpu_forecast':6*perlayer,'forecast_limitations':'One unwarmed fixed-order synthetic layer; output shape and loop coverage are native-sized, but cache/I/O/value-dependent branches and real source reads differ. Linear forecast is not measured six-layer time or a runtime guarantee. Source loading, process overhead and uncertainty need separate reserve.'}

def main():
    start=time.process_time(); child0=resource.getrusage(resource.RUSAGE_CHILDREN)
    result={'status':'STARTED'}
    try:
        flags=CFG['compiler']['flags']; target=OUT/'kernels.so'; command=['gcc',*flags,str(ROOT/'kernels.c'),'-o',str(target),*CFG['compiler']['link_flags']]
        cp=subprocess.run(command,text=True,capture_output=True,check=False)
        write('compile.json',{'command':command,'returncode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr,'compiler':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],'source_sha256':sha(ROOT/'kernels.c')})
        if cp.returncode: raise RuntimeError('Own source compile failed')
        kernel=en.Kernels(target); tests=unit_tests(kernel); write('unit_results.json',tests)
        perf=forecast(kernel); write('forecast.json',perf)
        result={'status':'PREP_PASS' if perf['all_required_sweeps_complete'] and perf['all_proposed_work_caps_pass'] else 'PREP_WORK_CAP_INFEASIBLE','tests':'PASS','forecast_status':perf['status']}
    except BaseException as ex:
        result={'status':'PREP_FAILURE','error_type':type(ex).__name__,'error':str(ex),'traceback':traceback.format_exc()}
        raise
    finally:
        ru=resource.getrusage(resource.RUSAGE_SELF); kids=resource.getrusage(resource.RUSAGE_CHILDREN)
        result.update(process_plus_children_cpu_seconds=ru.ru_utime+ru.ru_stime+kids.ru_utime+kids.ru_stime,self_max_rss_bytes=ru.ru_maxrss*1024)
        write('terminal.json',result)
        files=[]
        for path in sorted(OUT.rglob('*')):
            if path.is_file() and path.name not in ('manifest.json','stdout.txt','stderr.txt'):
                files.append({'path':str(path.relative_to(OUT)),'bytes':path.stat().st_size,'sha256':sha(path)})
        write('manifest.json',{'files':files})
if __name__=='__main__': main()
