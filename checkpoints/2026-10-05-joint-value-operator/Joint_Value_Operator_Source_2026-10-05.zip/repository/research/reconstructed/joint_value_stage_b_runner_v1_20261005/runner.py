"""Real Stage B implementation; imported by the admitted supervised child only.

No inference. Frozen reference trajectory only. This module has no executable
entry point that can bypass launch.py. The ordinary unit tests use fresh arrays.
"""
from pathlib import Path
import gc, hashlib, json, time
from contracts import *

def strict_ratio(a,b):
    need(a>=0 and b>=0,'Nonnegative SSE')
    return 1. if a==0 and b==0 else None if b==0 else a/b

def ratio_number(value):return float('inf') if value is None else value

def finite_metrics(P,E,W,work):
    import numpy as np
    import engine
    heads=engine.residual_heads(P,E,W,work,'evaluation_error')
    groups=heads.sum(axis=1);full=groups.sum(axis=0)
    head=np.sum(heads*heads,axis=(0,1,3));group=np.sum(groups*groups,axis=(0,2));total=np.sum(full*full,axis=1)
    need(np.isfinite(head).all() and np.isfinite(group).all() and np.isfinite(total).all(),'Nonfinite metrics')
    work.add('metric_reductions',scalar=heads.size*3+groups.size*3+full.size*3,bytes_=heads.nbytes+groups.nbytes+full.nbytes)
    return {'head_sse':head.tolist(),'group_sse':group.tolist(),'full_sse':total.tolist(),'within_group_signed_cross':(group-head).tolist(),'between_group_signed_cross':(total-group).tolist()},full

def gates(metrics):
    """No missing arm/layer/query, no epsilon, no filtering, no holdout selection."""
    need(set(metrics)==set(LAYERS),'Gate missing layer')
    evaluated=ARMS+('raw_token_gptq','reference')
    for l in LAYERS:
        need(set(metrics[l])==set(evaluated),'Gate missing arm')
        for a in evaluated:
            v=metrics[l][a]['full_sse'];need(len(v)==16 and all(__import__('math').isfinite(x) and x>=0 for x in v),'Gate invalid query population')
    ratios={a:[] for a in ARMS}
    for l in LAYERS:
        nearest=sum(metrics[l]['nearest']['full_sse'])
        for a in ARMS:ratios[a].append(strict_ratio(sum(metrics[l][a]['full_sse']),nearest))
    means={a:sum(ratio_number(x) for x in xs)/6 for a,xs in ratios.items()}
    full=means['full_joint_cd'];comparators=[a for a in ARMS if a!='full_joint_cd']
    # Infinity is an explicit extended nonnegative number. inf<=.9*inf is not a win.
    beats={a:(__import__('math').isfinite(full) and means[a]>0 and (not __import__('math').isfinite(means[a]) or full<=.9*means[a])) for a in comparators}
    layers_better=sum(sum(metrics[l]['full_joint_cd']['full_sse'])<sum(metrics[l]['headwise_cd']['full_sse']) for l in LAYERS)
    peak=[{'layer':l,'position':512+i,'passed':x<=1.25*y} for l in LAYERS for i,(x,y) in enumerate(zip(metrics[l]['full_joint_cd']['full_sse'],metrics[l]['nearest']['full_sse']))]
    return {'scope':'one passage, six correlated layers and16 adjacent queries; local operator only','layerwise_nearest_normalized_ratios':ratios,'ratio_null_means_positive_over_zero_infinity':True,'mean_layerwise_ratios':{a:(v if __import__('math').isfinite(v) else None) for a,v in means.items()},'at_least_10_percent_better_than_each':beats,'layers_better_than_headwise':layers_better,'pointwise_96_cells':peak,'exploratory_gate_pass':all(beats.values()) and layers_better>=4 and all(z['passed'] for z in peak)}

def save_npz(out,relative,arrays,io):
    import numpy as np
    p=safe(out,relative);p.parent.mkdir(parents=True,exist_ok=True)
    # Uncompressed output has deterministic payload bound; no pickle/object arrays.
    for a in arrays.values():need(isinstance(a,np.ndarray) and not a.dtype.hasobject,'Unsafe output array')
    with p.open('xb') as f:np.savez(f,**arrays);f.flush();__import__('os').fsync(f.fileno())
    raw=io.read(p,'output_hash:'+relative);io.written(relative,len(raw))
    return {'path':relative,'bytes':len(raw),'sha256':digest(raw)}

def save_work_events(out,relative,work,io):
    p=safe(out,relative);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:
        for event in work.get('events',[]):f.write((json.dumps(event,separators=(',',':'),allow_nan=False)+'\n').encode())
        f.flush();__import__('os').fsync(f.fileno())
    raw=io.read(p,'work_event_hash:'+relative);io.written(relative,len(raw))
    return {'path':relative,'bytes':len(raw),'sha256':digest(raw)}

def read_npz(out,z,io):
    import numpy as np,io as stream
    raw=io.read(safe(out,z['path']),'locked_output:'+z['path'],z['sha256'],z['bytes'])
    with np.load(stream.BytesIO(raw),allow_pickle=False) as data:
        result={k:data[k] for k in data.files}
    io.materialize('locked_output_arrays',sum(a.nbytes for a in result.values()));return result

def paths_for(arm,result):
    import numpy as np
    if arm=='projected_block_gptq':
        rows=result['paths']
        return {'location':np.array([z[:3] for z in rows],np.int32),'raw':np.stack([z[3] for z in rows]),'guard':np.stack([z[4] for z in rows]),'accepted':np.stack([z[5] for z in rows]),'diagnostics':np.stack([z[6] for z in rows]),'ledger':np.stack([z[7] for z in rows]),'guard_flags':np.stack([z[8] for z in rows])}
    if arm.endswith('_cd'):
        rows=result['paths'];return {'location':np.array([z[:2] for z in rows],np.int32),'accepted':np.stack([z[2] for z in rows]),'ledger':np.stack([z[3] for z in rows])}
    if arm=='guarded_token_gptq':return {'raw_codes':result['raw_codes'],'guarded_codes':result['codes'],'fallback_flags':result['fallback_flags']}
    return {'nearest_codes':result['codes']}

def array_payload(obj):
    """Result-tree actual ndarray bytes (deduplicated identities), not a RSS claim."""
    import numpy as np
    seen=set()
    def visit(x):
        if id(x) in seen:return 0
        seen.add(id(x))
        if isinstance(x,np.ndarray):return x.nbytes
        if isinstance(x,dict):return sum(visit(z) for z in x.values())
        if isinstance(x,(tuple,list)):return sum(visit(z) for z in x)
        return 0
    return visit(obj)

def validate_native_kernel(kernel):
    import ctypes as ct,engine as en
    cd=[ct.c_int]*5+[en.D,en.D,en.D,en.U8,en.D,en.D,en.D,en.D,en.D,en.D,en.U8,en.U8,en.D,en.U64]
    for name in ('jv_cd_channel','jv_cd_diagonal_channel'):
        fn=getattr(kernel.lib,name);fn.argtypes=cd;fn.restype=ct.c_int
    for name in ('jv_cd_cost_bound','jv_cd_diagonal_cost_bound'):
        fn=getattr(kernel.lib,name);fn.argtypes=[ct.c_int]*4+[en.U64];fn.restype=ct.c_int
    kernel.lib.jv_block_cost_bound.argtypes=[ct.c_int]*3+[en.U64];kernel.lib.jv_block_cost_bound.restype=ct.c_int
    kernel.lib.jv_projected_block.argtypes=[ct.c_int]*3+[en.D,en.D,en.U8,en.I,en.I,en.D,en.D,en.D,en.U8,en.D,en.D,en.U8,en.U8,en.U8,en.U8,en.D,en.D,en.D,en.D,en.U64]
    kernel.lib.jv_projected_block.restype=ct.c_int

def run(grant,capture,weights,bindings,kernel_path,io):
    import numpy as np, engine as en,reference as ref,artifact_contract as ac
    start=time.perf_counter();cpu=time.process_time();out=grant.out
    kernel=en.Kernels(kernel_path);validate_native_kernel(kernel);records=[];physical=en.Work()
    arrays=[]
    for layer in LAYERS:
        setup_cpu=time.process_time();setup_wall=time.perf_counter()
        q=capture.load('calibration',layer,'query');k=capture.load('calibration',layer,'keys');v=capture.load('calibration',layer,'values')
        p=ac.attention(q,k,np.arange(496,512),physical);P=np.ascontiguousarray(p[:,:,:,64:256]);V=np.ascontiguousarray(v[64:256].transpose(1,0,2));del q,k,v,p
        io.materialize('active_P_and_V',P.nbytes+V.nbytes)
        W=weights.load(layer,'encode');grid=ref.grid(V)
        need(grid['clip_index']==117,'Native grid order statistic')
        gsave=save_npz(out,f'encoding/layer_{layer:02d}/grid.npz',{k:z for k,z in grid.items() if isinstance(z,np.ndarray)},io)
        setup={'cpu_seconds':time.process_time()-setup_cpu,'wall_seconds':time.perf_counter()-setup_wall,'scope':'shared calibration payload reads/P/grid/W decode and grid serialization'}
        for arm in ARMS:
            outer_cpu=time.process_time();outer_wall=time.perf_counter()
            if arm=='nearest':
                r={'codes':grid['nearest_codes'].copy(),'first_sweep':grid['nearest_codes'].copy(),'full_sweeps':1,'complete':True,'work':{'mac_equivalent_units':0,'macs':0,'scalar_ops':8*192*128*32,'logical_bytes':V.nbytes*3,'events':[]},'audit':{'initialization_only':True},'cpu_seconds':0.,'wall_seconds':0.}
            elif arm.endswith('_cd'):
                r=en.cd_solve(P,V,W,grid,kernel,{'headwise_cd':'head','group_joint_cd':'group','full_joint_cd':'full'}[arm],budget=BUDGET,acquisition_mac=33554432,force_one_sweep=False)
            elif arm=='guarded_token_gptq':r=en.token_gptq(P,V,W,grid,budget=BUDGET,acquisition_mac=33554432)
            else:r=en.blocked_solve(P,V,W,grid,kernel,budget=BUDGET,acquisition_mac=33554432,force_one_sweep=False)
            need(r['complete'] and r['full_sweeps']>=1 and r['first_sweep'] is not None,'Incomplete required arm '+arm)
            need(r['work']['mac_equivalent_units']<=BUDGET,'Over-budget arm')
            row=ref.row_sse(V,r['codes'],grid['scales'],grid['zeros']);need(ref.cap_feasible(row,grid['row_caps'],grid['nearest_sse']).all(),'Row cap')
            firstrow=ref.row_sse(V,r['first_sweep'],grid['scales'],grid['zeros']);need(ref.cap_feasible(firstrow,grid['row_caps'],grid['nearest_sse']).all(),'Checkpoint row cap')
            prefix=f'encoding/layer_{layer:02d}/{arm}'
            artifacts={'codes':save_npz(out,prefix+'/codes.npz',{'codes':r['codes']},io),'first_sweep':save_npz(out,prefix+'/first_sweep.npz',{'codes':r['first_sweep']},io),'grid':gsave,'paths':save_npz(out,prefix+'/paths.npz',paths_for(arm,r),io),'row_sse':save_npz(out,prefix+'/row_sse.npz',{'final':row,'first_sweep':firstrow,'nearest':grid['nearest_sse'],'caps':grid['row_caps']},io)}
            artifacts['work_events']=save_work_events(out,prefix+'/work_events.jsonl',r['work'],io)
            raw_caps=None
            if arm=='guarded_token_gptq':
                raw_sse=ref.row_sse(V,r['raw_codes'],grid['scales'],grid['zeros'])
                raw_caps={'row_sse':raw_sse.tolist(),'cap_violation_count':int((~ref.cap_feasible(raw_sse,grid['row_caps'],grid['nearest_sse'])).sum()),'ineligible_for_same_cap_superiority':True}
            record={'layer':layer,'arm':arm,'complete':True,'full_sweeps':r['full_sweeps'],'units':r.get('units'),'row_caps_verified':True,'artifacts':artifacts,'work':{k:v for k,v in r['work'].items() if k!='events'},'audit':r.get('audit',{}),'solver_cpu_seconds':r['cpu_seconds'],'solver_wall_seconds':r['wall_seconds'],'outer_arm_cpu_seconds':time.process_time()-outer_cpu,'outer_arm_wall_seconds':time.perf_counter()-outer_wall,'shared_layer_setup':setup,'wrapper_final_and_checkpoint_row_recompute_scalar_upper':8*192*128*12,'raw_token_caps':raw_caps,'standalone_attention':None if arm=='nearest' else {'QK_MAC':33554432,'logits':262144,'exp_calls':262144,'softmax_scalar_upper':1572864,'physical_shared_once':True},'actual_result_array_payload_bytes':array_payload(r),'input_array_payload_bytes':P.nbytes+V.nbytes+W.nbytes+array_payload(grid),'allocation_limit_reference':'ALLOCATION_PLAN.json; sampler enforces process-tree cap'}
            records.append(record);del r,row,firstrow;gc.collect()
        del P,V,W,grid;gc.collect()
    # Persistent hashes include codes, grid, first checkpoints, all paths, work,
    # admission inputs, source/config identities, W segment pins and byte ledger.
    lock_encodings(grant,records,bindings,io)
    evaluated={};all_metrics={'calibration':{},'holdout':{}};evaluation=en.Work()
    for layer in LAYERS:
        W=weights.load(layer,'evaluate');q=capture.load('calibration',layer,'query');k=capture.load('calibration',layer,'keys');v=capture.load('calibration',layer,'values')
        grid=read_npz(out,next(r for r in records if r['layer']==layer)['artifacts']['grid'],io)
        active=np.ascontiguousarray(v[64:256].transpose(1,0,2))
        for split in ('calibration','holdout'):
            if split=='holdout':
                del q
                q=capture.load('holdout',layer,'query');ks=capture.load('holdout',layer,'keys');vs=capture.load('holdout',layer,'values')
                kk=np.concatenate([k,ks],axis=0);vv=np.concatenate([v,vs],axis=0);del ks,vs
                io.materialize('exact_suffix_concatenation',kk.nbytes+vv.nbytes);positions=np.arange(512,528)
            else:kk=k;vv=v;positions=np.arange(496,512)
            Pall=ac.attention(q,kk,positions,evaluation);P=np.ascontiguousarray(Pall[:,:,:,64:256])
            original=en.residual_heads(Pall,np.ascontiguousarray(vv.transpose(1,0,2)),W,evaluation,'original_reference').sum(axis=(0,1))
            need(np.isfinite(original).all(),'Original operator reference nonfinite')
            save_npz(out,f'evaluation/{split}/layer_{layer:02d}/original_output.npz',{'output':original},io)
            metrics={}
            for arm in ARMS+('raw_token_gptq','reference'):
                if arm=='reference':E=np.zeros_like(active)
                else:
                    use='guarded_token_gptq' if arm=='raw_token_gptq' else arm;r=next(r for r in records if r['layer']==layer and r['arm']==use)
                    if arm=='raw_token_gptq':codes=read_npz(out,r['artifacts']['paths'],io)['raw_codes']
                    else:codes=read_npz(out,r['artifacts']['codes'],io)['codes']
                    need(codes.shape==(8,192,128) and codes.dtype==np.uint8 and np.all(codes<=3),'Locked codes invalid')
                    E=ref.decode(codes,grid['scales'],grid['zeros'])-active
                m,full=finite_metrics(P,E,W,evaluation);m['positions']=positions.tolist();m['cap_eligible']=arm!='raw_token_gptq';metrics[arm]=m
                save_npz(out,f'evaluation/{split}/layer_{layer:02d}/{arm}_signed_error.npz',{'signed_all_head_output_error':full},io)
                del E,full
            nearest=metrics['nearest']['full_sse']
            for m in metrics.values():m['nearest_normalized_query_sse']=[strict_ratio(a,b) for a,b in zip(m['full_sse'],nearest)]
            all_metrics[split][layer]=metrics
            del Pall,P,original,kk,vv
        del W,q,k,v,active,grid;gc.collect()
    answer={'status':'COMPLETE_PENDING_CLEAN_GUARD','evidence':'real_reference_trajectory_local_operator_only','encoding_lock_sha256':grant.lock,'metrics':all_metrics,'gate':gates(all_metrics['holdout']),'physical_shared_calibration':physical.summary(),'evaluation_extra_work':evaluation.summary(),'io':io.summary(),'cpu_seconds_child':time.process_time()-cpu,'wall_seconds_child':time.perf_counter()-start,'ratio_null_means_positive_over_zero_infinity':True,'format_ledger':{'hypothetical_packed_V_prefix_bytes':716800,'original_V_prefix_bytes':1048576,'hypothetical_KV_prefix_bytes':1765376,'original_KV_prefix_bytes':2097152,'reduction_KV_fraction':.158203125,'exact_suffix_V_bytes':32768,'exact_suffix_K_bytes':32768,'evidence_codes_are_uint8_not_packed_native_cache':True,'no_GPU_memory_or_latency_claim':True},'first_sweep_diagnostics':'immutable code checkpoints and update paths only; no matched-sweep quality comparison or checkpoint selection','projected_raw_semantics':'raw proposals at current accepted-state blocks; not an independent raw trajectory','trajectory':'fixed teacher-forced captured Q/K/V; no autoregressive rollout or model inference'}
    jwrite(out/'result.json',answer)
    jwrite(out/'completion.json',{'status':'COMPLETE_PENDING_CLEAN_GUARD','encoding_lock_sha256':grant.lock,'required_records':36,'evaluated_layer_query_cells_per_arm_split':96})
