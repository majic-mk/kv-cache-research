"""Synthetic temporary-file tests only. Never opens real tensors or W payloads."""
from pathlib import Path
import hashlib,io,json,os,struct,sys,tempfile,unittest
import numpy as np
from contracts import *
from runner import finite_metrics,gates,save_npz,paths_for,validate_native_kernel
PREP=Path(__file__).resolve().parent.parent/'joint_value_solver_prep_20261005'
sys.path.insert(0,str(PREP))
import engine as en, reference as ref,artifact_contract as ac

def rewrite(p,x):p.write_text(json.dumps(x,allow_nan=False))

def fixture(root):
    files=[];old={'files':[{'sha256':str(i)*64} for i in range(6)]};parity=[]
    for i,l in enumerate(LAYERS):parity.append({'layer':l,'query_bitwise':True,'keys_bitwise':True,'old_sha256':str(i)*64,'query_data_sha256':'0'*64,'keys_data_sha256':'0'*64})
    for path,spec in schema().items():
        bits=np.zeros(spec['shape'],dtype='<u2');buf=io.BytesIO();np.save(buf,bits,allow_pickle=False);raw=buf.getvalue()
        p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
        files.append(dict(path=path,**spec,raw_bytes=bits.nbytes,bytes=len(raw),sha256=digest(raw),data_sha256=digest(bits.tobytes())))
    chunks=[[0,128],[128,256],[256,384],[384,512],[512,528]]
    m={'schema':'joint_value_capture.v1','capture_packet_manifest_sha256':STAGE_A_HASH,'proposal_sha256':PROPOSAL_HASH,'config_sha256':CONFIG_HASH,'token_ids_sha256':TOKEN_HASH,'model_repository':'Qwen/Qwen3-4B-Instruct-2507','model_revision':'cdbee75f17c01a7cc42f958dc650907174af0554','layers':list(LAYERS),'query_heads':32,'kv_heads':8,'head_dim':128,'query_head_to_kv':'j//4','native_scaling':128**-.5,'native_dtype':'bfloat16','causal_query_t_attends_keys':'0:t inclusive','calibration_positions':[496,512],'holdout_positions':[512,528],'calibration_keys_and_values_positions':[0,512],'holdout_keys_and_values_positions':[512,528],'position_ranges_half_open':True,'raw_tensor_bytes':14548992,'all_old_query_and_key_bits_equal':True,'source_pins':{},'chunks':chunks,'causal_masks':[{'start':lo,'end':hi,'shape':[1,1,hi-lo,hi],'causal_positions_verified':True,'sha256':'a'*64} for lo,hi in chunks],'old_tensor_parity':parity,'files':files}
    rewrite(root/'tensor_manifest.json',m)
    completion={'status':'COMPLETE','stage':'A','model_calls':5,'teacher_forced':True,'model_and_full_cache_released':True,'all_old_query_and_key_bits_equal':True,'offline_optimization_performed':False,'tensor_manifest_sha256':digest((root/'tensor_manifest.json').read_bytes())}
    rewrite(root/'completion.json',completion);rewrite(root/'guard_result.json',{'exit_code':0,'termination':None,'cleanup':{'all_absent':True}})
    return m,old,completion

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='joint_stage_b_synthetic_');cls.root=Path(cls.temp.name);cls.a=cls.root/'A';cls.a.mkdir();cls.m,cls.old,cls.completion=fixture(cls.a)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def setUp(self):
        rewrite(self.a/'tensor_manifest.json',self.m);rewrite(self.a/'completion.json',self.completion);rewrite(self.a/'guard_result.json',{'exit_code':0,'termination':None,'cleanup':{'all_absent':True}})
        self.out=self.root/self._testMethodName;self.out.mkdir();self.io=IO();self.g=Grant(self.a,self.out,'f'*64,synthetic=True)
    def capture(self):return Capture(self.g,self.io,{},self.old)
    def test_calibration_read_holdout_denial(self):
        c=self.capture();before=self.io.read_bytes
        with self.assertRaises(PermissionError):c.load('holdout',0,'query')
        self.assertEqual(before,self.io.read_bytes)
        self.assertEqual(c.load('calibration',0,'query').shape,(16,32,128))
    def test_missing_stage_A_completion_guard_parity(self):
        for field in ('status','model_and_full_cache_released','all_old_query_and_key_bits_equal'):
            z=dict(self.completion);z[field]=False;rewrite(self.a/'completion.json',z)
            with self.assertRaises(ValueError):self.capture()
        rewrite(self.a/'completion.json',self.completion)
        rewrite(self.a/'guard_result.json',{'exit_code':0,'termination':'limit','cleanup':{'all_absent':True}})
        with self.assertRaises(ValueError):self.capture()
    def test_malformed_manifest_hash_shape_source(self):
        for kind in ('hash','shape','source','missing','parity'):
            z=json.loads(json.dumps(self.m))
            if kind=='hash':z['files'][0]['sha256']='short'
            if kind=='shape':z['files'][0]['shape']=[1,32,128]
            if kind=='source':z['config_sha256']='0'*64
            if kind=='missing':z['files'].pop()
            if kind=='parity':z['old_tensor_parity'][0]['query_bitwise']=False
            rewrite(self.a/'tensor_manifest.json',z);co=dict(self.completion);co['tensor_manifest_sha256']=digest((self.a/'tensor_manifest.json').read_bytes());rewrite(self.a/'completion.json',co)
            with self.assertRaises(ValueError,msg=kind):self.capture()
    def records(self):
        z=save_npz(self.out,'dummy.npz',{'codes':np.zeros((1,),np.uint8)},self.io)
        artifacts={k:z for k in ('codes','first_sweep','grid','paths','row_sse','work_events')}
        return [{'layer':l,'arm':a,'complete':True,'full_sweeps':1,'row_caps_verified':True,'work':{'mac_equivalent_units':1},'artifacts':artifacts} for l in LAYERS for a in ARMS]
    def test_lock_all_arms_and_mutation(self):
        records=self.records();self.g.segments={l:'a'*64 for l in LAYERS}
        for bad in (records[:-1],records+[records[0]]):
            with self.assertRaises(ValueError):lock_encodings(self.g,bad,{},self.io)
        for key,value in [('complete',False),('row_caps_verified',False),('full_sweeps',0)]:
            old=records[0][key];records[0][key]=value
            with self.assertRaises(ValueError):lock_encodings(self.g,records,{},self.io)
            records[0][key]=old
        lock_encodings(self.g,records,{},self.io)
        c=self.capture();self.assertEqual(c.load('holdout',0,'query').shape,(16,32,128))
        (self.out/'ENCODING_LOCK.json').write_bytes(b'{}')
        with self.assertRaises(ValueError):c.load('holdout',0,'keys')
    def test_wrong_payload_hash_dtype_nonfinite(self):
        c=self.capture();path=self.a/'calibration/layer_00/query.npy';old=path.read_bytes()
        try:
            path.write_bytes(old+b'bad')
            with self.assertRaises(ValueError):c.load('calibration',0,'query')
            bits=np.full((16,32,128),0x7f80,dtype='<u2');buf=io.BytesIO();np.save(buf,bits,allow_pickle=False);raw=buf.getvalue();path.write_bytes(raw)
            c.rows['calibration/layer_00/query.npy'].update(bytes=len(raw),sha256=digest(raw),data_sha256=digest(bits.tobytes()))
            with self.assertRaises(ValueError):c.load('calibration',0,'query')
        finally:path.write_bytes(old)
    def test_signed_native_W_orientation(self):
        root=self.out/'weights';root.mkdir();name='synthetic.safetensors'
        bits=np.zeros((2560,4096),'<u2');bits[17,3]=0xbf80;bits[100,4095]=0x4000;raw=bits.tobytes();del bits
        entries={f'model.layers.{l}.self_attn.o_proj.weight':{'dtype':'BF16','shape':[2560,4096],'data_offsets':[0,len(raw)]} for l in LAYERS}
        h=json.dumps(entries,separators=(',',':')).encode();blob=struct.pack('<Q',len(h))+h+raw;(root/name).write_bytes(blob)
        sha=digest(blob);metadata={'entries':{k:dict(v,shard=name,tensor_payload_bytes=len(raw)) for k,v in entries.items()},'header_reads':[{'shard':name,'bytes_read':len(h)+8,'header_sha256':digest(h)}]}
        pins={'schema':'joint_value_W_segments.v1','model_revision':'cdbee75f17c01a7cc42f958dc650907174af0554','segments':[{'layer':l,'key':f'model.layers.{l}.self_attn.o_proj.weight','shard':name,'shard_sha256':sha,'data_offsets':[0,len(raw)],'bytes':len(raw),'sha256':digest(raw)} for l in LAYERS]}
        pins['full_shard_hashes']=[{'shard':name,'stat_checks':{'unchanged':True,'resolved_before':str((root/name).resolve()),'resolved_after':str((root/name).resolve()),'descriptor_after':stat_identity((root/name).stat())}}]
        del blob,raw
        w=Weights(root,metadata,{'shards':[{'path':name,'bytes':(root/name).stat().st_size,'sha256':sha}]},pins,self.g,self.io).load(0,'encode')
        self.assertEqual(w[0,0,3,17],-1);self.assertEqual(w[7,3,127,100],2);self.assertEqual(np.count_nonzero(w),2)
    def test_full_suffix_softmax_and_signed_cancellation(self):
        q=np.zeros((2,4,4));k=np.zeros((6,2,4));p=ac.attention(q,k,[4,5]);self.assertAlmostEqual(p[0,0,0,0],1/5);self.assertEqual(p[0,0,0,5],0);self.assertAlmostEqual(p[0,0,1,0],1/6)
        E=np.ones((2,2,4));W=np.ones((2,2,4,3));W[:,1]*=-1
        m,error=finite_metrics(p[:,:,:,:2],E,W,en.Work());self.assertTrue(np.all(error==0));self.assertTrue(all(x>0 for x in m['head_sse']));self.assertTrue(all(x<0 for x in m['within_group_signed_cross']))
        design=sum((p[g,h,:,:2]@E[g]@W[g,h] for g in range(2) for h in range(2)));np.testing.assert_allclose(error,design,atol=0)
    def test_zero_denominator_gate_and_incomplete(self):
        metrics={l:{a:{'full_sse':[0.]*16} for a in ARMS+('raw_token_gptq','reference')} for l in LAYERS}
        z=gates(metrics);self.assertFalse(z['exploratory_gate_pass']);self.assertEqual(z['layerwise_nearest_normalized_ratios']['nearest'],[1.]*6)
        for l in LAYERS:metrics[l]['full_joint_cd']['full_sse'][0]=1.
        z=gates(metrics);self.assertIsNone(z['mean_layerwise_ratios']['full_joint_cd']);self.assertFalse(z['pointwise_96_cells'][0]['passed'])
        del metrics[0]['headwise_cd']
        with self.assertRaises(ValueError):gates(metrics)
    def test_perfect_control_cannot_be_beaten_by_ten_percent(self):
        metrics={l:{a:{'full_sse':[1.]*16} for a in ARMS+('raw_token_gptq','reference')} for l in LAYERS}
        for l in LAYERS:
            metrics[l]['full_joint_cd']['full_sse']=[0.]*16
            metrics[l]['group_joint_cd']['full_sse']=[0.]*16
        z=gates(metrics);self.assertEqual(z['layers_better_than_headwise'],6);self.assertFalse(z['at_least_10_percent_better_than_each']['group_joint_cd']);self.assertFalse(z['exploratory_gate_pass'])

    def test_tiny_all_solver_apis_and_writer(self):
        rng=np.random.default_rng(2026100561);P=rng.random((2,2,2,4));P/=P.sum(axis=-1,keepdims=True);V=rng.normal(size=(2,4,4));W=rng.normal(size=(2,2,4,6));grid=ref.grid(V);ker=en.Kernels(PREP/'attempt_03/kernels.so');validate_native_kernel(ker)
        outputs=[]
        for arm,obj in [('headwise_cd','head'),('group_joint_cd','group'),('full_joint_cd','full')]:outputs.append((arm,en.cd_solve(P,V,W,grid,ker,obj,force_one_sweep=True)))
        outputs.append(('projected_block_gptq',en.blocked_solve(P,V,W,grid,ker,force_one_sweep=True)))
        outputs.append(('guarded_token_gptq',en.token_gptq(P,V,W,grid)))
        for arm,r in outputs:
            self.assertTrue(r['complete']);self.assertTrue(ref.cap_feasible(ref.row_sse(V,r['codes'],grid['scales'],grid['zeros']),grid['row_caps'],grid['nearest_sse']).all());save_npz(self.out,arm+'.npz',paths_for(arm,r),self.io)
    def test_frozen_source_integrity_metadata_only(self):
        import launch
        digest_,manifest=launch.source_integrity(IO())
        self.assertEqual(len(digest_),64);self.assertEqual(manifest['status'],'FROZEN_SOURCE_ONLY_NOT_ADMISSION')
        self.assertFalse((launch.HERE/'ADMISSION.json').exists())
        with self.assertRaises(FileNotFoundError):launch.admission(IO(),digest_)
        self.assertFalse(launch.OUT.exists());self.assertFalse((launch.HERE/'RUN_CLAIM.json').exists())

    def test_admission_fail_closed_and_no_cap_expansion(self):
        import launch
        self.assertEqual(launch.REPO.name,'kv-cache-research')
        a={'decision':'ADMIT_ONE_JOINT_VALUE_STAGE_B_REAL','parent_authorized':True,'independent_review_accepted':True,'packet_manifest_sha256':'f'*64,'max_runs':1,'limits':dict(CAPS),'work_budget_per_layer_arm':BUDGET,'stage_A_tensor_manifest_sha256':'a'*64,'W_segment_pins_sha256':'b'*64,'W_provenance_guard_sha256':'c'*64,'W_provenance_finalization_sha256':'d'*64,'W_provenance_launcher_exit_code':0,'stage_A_guard_parent_exit_code':0}
        self.assertEqual(launch.admission(self.io,'f'*64,json.dumps(a)),a)
        for key,value in [('decision','NO'),('parent_authorized',False),('max_runs',2),('packet_manifest_sha256','0'*64),('work_budget_per_layer_arm',BUDGET+1),('limits',dict(CAPS,wall_seconds=301)),('W_segment_pins_sha256','')]:
            bad=dict(a);bad[key]=value
            with self.assertRaises(ValueError,msg=key):launch.admission(self.io,'f'*64,json.dumps(bad))

    def test_only_verified_existing_weight_symlink_is_allowed(self):
        target=self.out/'physical';target.write_bytes(b'synthetic')
        link=self.out/'shard';link.symlink_to(target)
        pins={'full_shard_hashes':[{'shard':'shard','stat_checks':{'unchanged':True,'resolved_before':str(target.resolve()),'resolved_after':str(target.resolve()),'descriptor_after':stat_identity(target.stat())}}]}
        self.assertEqual(verified_weight_path(self.out,'shard',pins)[0],target)
        other=self.out/'changed';other.write_bytes(b'synthetic');link.unlink();link.symlink_to(other)
        with self.assertRaises(ValueError):verified_weight_path(self.out,'shard',pins)

    def test_path_escape_and_split_symlink(self):
        with self.assertRaises(ValueError):safe(self.out,'../future')
        outside=self.out/'other';outside.mkdir();(self.out/'linked').symlink_to(outside,target_is_directory=True)
        with self.assertRaises(ValueError):safe(self.out,'linked/query.npy')

    def test_native_output_bound_without_new_native_solver_run(self):
        # These are previously admitted SYNTHETIC fixture metadata only.
        forecast=json.loads((PREP/'attempt_03/forecast.json').read_text())
        compact_work=sum(sum(len((json.dumps(e,separators=(',',':'))+'\n').encode()) for e in r['work']['events']) for r in forecast['arms'].values())*6
        path_files=['headwise_cd_native_paths.npz','group_joint_cd_native_paths.npz','full_joint_cd_native_paths.npz','projected_native_paths.npz','token_native_codes.npz']
        # Stored fixture path archives include at least the production fields;
        # allow1MiB/layer for zip/header/schema and nearest path overhead.
        paths=(sum((PREP/'attempt_03'/name).stat().st_size for name in path_files)+1048576)*6
        checkpoints_and_codes=6*6*196608*2+6*196608
        grids_and_rows=6*(8*192*(4+4+8+8+8)+6*8*192*8*4)
        signed_errors_and_reference=6*2*9*16*2560*8
        terminal_metrics_locks_guard_logs_reserve=16*1048576
        total=compact_work+paths+checkpoints_and_codes+grids_and_rows+signed_errors_and_reference+terminal_metrics_locks_guard_logs_reserve
        report={'basis':'previously admitted synthetic native-shape fixture counts; no new native-size solver execution','compact_work_events_bytes_six_layers':compact_work,'all_path_archives_bound':paths,'codes_checkpoints_bytes':checkpoints_and_codes,'grids_rows_bytes':grids_and_rows,'signed_errors_reference_bytes':signed_errors_and_reference,'metadata_and_logs_reserve':terminal_metrics_locks_guard_logs_reserve,'total_bound_bytes':total,'limit_bytes':CAPS['output_bytes'],'passed':total<CAPS['output_bytes']}
        destination=os.environ.get('JV_TEST_RECEIPTS')
        if destination:rewrite(Path(destination)/'native_output_bound.json',report)
        self.assertLess(total,CAPS['output_bytes'])

    def test_reviewed_guard_terminal_and_timeout(self):
        import supervisor_core as core
        records=[]
        for name,command,wall in [('clean',[sys.executable,'-c','pass'],2),('timeout',[sys.executable,'-c','import time;time.sleep(4)'],.15)]:
            out=self.out/name;out.mkdir();caps={'cpu_process_tree_seconds':10,'wall_seconds':wall,'rss_process_tree_bytes':536870912,'minimum_host_available_bytes':0,'output_bytes':1048576}
            z=core.supervise(command,out,os.environ.copy(),caps,{'accept_unobservable_cgroup_ceiling':True});self.assertTrue(z['cleanup']['all_absent']);self.assertEqual(z['final_output_bytes'],core.evidence_bytes(out));records.append(z)
        self.assertEqual(records[0]['exit_code'],0);self.assertIsNone(records[0]['termination']);self.assertEqual(records[1]['termination'],'wall_limit')
        # Preserve both intentional guarded outcomes outside disappearing temp dir.
        destination=os.environ.get('JV_TEST_RECEIPTS')
        if destination:rewrite(Path(destination)/'guard_fixture_receipts.json',records)
if __name__=='__main__':unittest.main(verbosity=2)
