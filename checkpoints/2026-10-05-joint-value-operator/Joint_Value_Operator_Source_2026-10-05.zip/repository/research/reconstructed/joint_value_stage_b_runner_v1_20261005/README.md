# Stage B real loader / encoder / evaluator v1

Source preparation only, 2026-10-05 UTC. No real Stage A/B execution, real tensor
or weight payload read, GPU action, model inference, installation, admission,
or run claim was performed by this implementation worker. The separately
assigned cryptographic W provenance pass is not a Stage B execution.

## Locked scientific contract

The immutable original proposal/config and Stage A packet remain unchanged.
The approved v2 amendment supplies a common 1,300,000,000 source-defined logical
MAC-equivalent cap per layer/encoder. These counts are not total-compute,
CPU-time, accelerator-time, or serving-speed equivalence. The frozen solver,
reference grid, exact candidate/tie/cap rules, traversal and acceptance math
are imported without edits. The adapter sets exact ctypes ABI signatures.

All six layers (0,7,14,21,28,35), all32 Q heads,8 shared-V groups,128 channels,
prefix512,16 calibration queries496:512 and active rows64:256 are fixed. The
full-projected, guarded ordinary token, full-joint, group-joint, headwise and
nearest arms must all complete. Ordinary raw token GPTQ is a separate saved
trajectory and is ineligible for same-cap superiority. Projected raw records
are proposals along the accepted-state path, not an independent raw arm.

Capture metadata validates COMPLETE,5 teacher-forced native calls, released
model/cache, clean guard/cleanup, exact Q/K parity, source/config/token IDs,
all36 payload schemas and causal mask metadata. Only calibration files are
opened/hashed while encoding. The encoding lock covers every code array,
grid, first-sweep checkpoint, all raw/guard/path/branch diagnostics, row SSE,
streamed work events, compact work/timing summaries, source/config/admission
bindings and W segment hashes. Holdout reads require this complete hash-locked
population. A failure invalidates the whole population without layer/arm drops
or retries. First-sweep diagnostics are immutable code/path checkpoints only;
there is no matched-sweep quality claim or checkpoint selection.

## Provenance and physical I/O

A separate verified receipt must prove all three pinned full-shard SHA256s and
six selected W segments were hashed from the same stream. Stage B verifies
receipt, clean guard and post-publication finalization hashes supplied in fresh admission. Existing weight
symlinks are accepted only when their resolved target and descriptor device,
inode, mode, size, mtime and ctime match that receipt; identity is checked
before and after each read. Captures and outputs reject symlink components.

Only exact signed W_o[2560,4096] intervals are loaded, mapped by transpose to
[8,4,128,2560], one layer at a time. Each segment is read and hash-verified once
for encoding and once for evaluation: 251,658,240 selected payload bytes in
all, plus explicitly counted header reads. No full shard is reread by Stage B.
All source checks, capture reads, duplicate hash reads, saved-code reads and
post-cleanup output hashes are also charged. Unbuffered API-byte consumption
is not a claim about storage-device traffic, downloads, or page-cache misses.

Acquisition materializations and result array payloads are explicit. Frozen
solver logical-byte/operation counters are separate source-defined categories;
hidden runtime allocations are covered by the live envelope and guarded RSS,
not mislabeled exact array counts. ALLOCATION_PLAN.json specifies the live
reserve. No full model, all-layer W, full residual history or dense196608-square
Hessian is retained. Detailed solver work events stream per arm; the all-layer
lock retains totals and file hashes rather than700k Python dictionaries.

## Evaluation and decision

After the lock, each layer reloads its W and prefix. Original output uses all
exact values. Future softmax includes all causal prefix and suffix keys through
the current query; only old active V errors enter the signed residual. Per-query
head/group/full SSE, signed within/between-group terms, full signed all-head
output-error vectors, original output vectors, calibration/holdout metrics and
raw-token cap violations are retained. Extra evaluation contractions and
recomputed calibration attention are charged separately from encoding.

Zero normalization is exact:0/0=1; positive/0 is JSON null with an explicit
infinity label. A zero-error control cannot be beaten by10 percent. The gate
uses the unfiltered six layerwise ratios, strict wins in at least4/6 layers and
every one of96 query caps. This is one passage's correlated local-operator
reference trajectory, not a model rollout, task-quality or distribution claim.

The716800B V-prefix /1765376B KV-prefix figures are hypothetical packed-format
ledgers beside the1048576B /2097152B BF16 sizes. Stored evidence codes remain
uint8; no packed serving implementation, native GPU memory saving, or latency
result is claimed. Exact suffix K/V are equal-cost additions.

## Admission and execution boundary

`launch.py` requires a fresh source-manifest-bound root/reviewer admission,
Stage A tensor-manifest digest, W provenance/guard/finalization digests, verified
zero parent-launcher exit codes, exact caps and one
run. It creates a persistent exclusive claim only after metadata preflight.
No ADMISSION.json, RUN_CLAIM.json or run directory is supplied in this packet.
It imports the frozen array solver only in the admitted guarded child. The
reviewed supervisor enforces240 aggregate tree CPU seconds,300 wall seconds,
512MiB sampled tree RSS,2GB host-available floor,256MiB output, one BLAS thread,
child cleanup and final high-water checks. Inherited CPU/AS/DATA/FSIZE ceilings
are recorded and incompatible ceilings rejected. Unobservable cgroup ceiling
acceptance must come from this packet's admission and is not capacity proof.

Final results remain pending until the guard reaps the child. The final manifest
hashes resource logs after cleanup and checks finalization CPU/wall, parent
high-water RSS, host/cgroup availability and terminal output bytes. It reports
COMPLETE_VALID_POPULATION only if all required checks pass.

## Synthetic implementation verification

All tests generate payloads in temporary directories or use previously admitted
synthetic solver fixtures. Tests cover native tensor schema/hash/finite checks,
prelock future-read denial, missing/duplicate layer/arm and cap/coverage failure,
lock mutation, source integrity, source-bound admission, symlink identity,
signed native-shaped W orientation, all tiny solver APIs, writer paths, full
causal suffix denominator, signed cancellation, zero/infinity/perfect-control
gates, and clean/intentional-timeout guard terminal accounting. Test attempts
and actual CPU/RSS receipts are preserved; an intentional dummy-child timeout
is a passing negative test, not an unreported resource failure.

The native output bound is212,657,722 bytes against268,435,456, based on the
previously admitted native synthetic fixture's deterministic event/path counts,
with16MiB reserved for metadata/logs. It is not a timing forecast or evidence
that a real run will complete. Tests are limited to the additional60 aggregate
CPU-second /512MiB authority and are supervised by test_supervisor.py. Receipts
and final cumulative usage are indexed in DELIVERY_MANIFEST.json.
