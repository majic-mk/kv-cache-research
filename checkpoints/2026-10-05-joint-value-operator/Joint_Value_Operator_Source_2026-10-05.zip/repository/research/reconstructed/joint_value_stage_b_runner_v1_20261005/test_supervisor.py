"""Bound ALL implementation-test CPU to root's additional60-second allowance."""
from pathlib import Path
import json,os,resource,signal,sys,time
HERE=Path(__file__).resolve().parent;PREP=HERE.parent/'joint_value_solver_prep_20261005'
sys.path.insert(0,str(PREP));import supervisor_core as core
ledger=HERE/'implementation_resource_ledger.jsonl'
rows=[json.loads(x) for x in ledger.read_text().splitlines()] if ledger.exists() else []
used=sum(x['charged_cpu_seconds'] for x in rows);remaining=60-used
if remaining<=0:raise RuntimeError('Additional implementation test CPU exhausted')
out=HERE/f'test_attempt_{len(rows)+1:02d}';out.mkdir()
env=os.environ.copy();env.update({x:'1' for x in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')});env['CUDA_VISIBLE_DEVICES']='';env['PYTHONDONTWRITEBYTECODE']='1';env['JV_TEST_RECEIPTS']=str(out)
caps={'cpu_process_tree_seconds':remaining,'wall_seconds':90,'rss_process_tree_bytes':536870912,'minimum_host_available_bytes':2000000000,'output_bytes':33554432}
signal.signal(signal.SIGTERM,core.interrupted);signal.signal(signal.SIGINT,core.interrupted)
z=core.supervise([sys.executable,str(HERE/'test_runner.py')],out,env,caps,{'accept_unobservable_cgroup_ceiling':True})
row={'attempt':out.name,'charged_cpu_seconds':z['aggregate_cpu_seconds_final'],'cumulative_cpu_seconds':used+z['aggregate_cpu_seconds_final'],'guard':z,'scope':'fresh synthetic payload files and own frozen C kernels only; no real tensors, weights, inference or Stage A/B launch'}
with ledger.open('a') as f:f.write(json.dumps(row)+'\n')
print(json.dumps(row,indent=2));sys.exit(0 if z['exit_code']==0 and z['termination'] is None and z['cleanup']['all_absent'] else 1)
