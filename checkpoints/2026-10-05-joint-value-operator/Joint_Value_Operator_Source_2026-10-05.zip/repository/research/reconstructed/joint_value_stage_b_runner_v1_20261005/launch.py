"""One-use Stage B launch; no payload access before source-bound admission.

Do not create ADMISSION.json or run this module during source preparation.
No fallback, automatic retry, compilation, download, or inference exists here.
"""
from pathlib import Path
import hashlib,json,os,resource,signal,sys,time
from contracts import *
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
PREP=HERE.parent/'joint_value_solver_prep_20261005'
A=HERE.parent/'joint_headwise_quality_plan_20261005'/'stage_a_packet'
ASSETS=REPO/'outputs/revision_cpu_model_assets_20261004'
OUT=HERE/'run'

def source_integrity(io):
    raw=io.read(HERE/'FROZEN_RUNNER_FILES.json','runner_source_manifest')
    manifest=json.loads(raw)
    need(manifest['status']=='FROZEN_SOURCE_ONLY_NOT_ADMISSION','Runner manifest status')
    for row in manifest['files']:
        io.read(safe(HERE,row['path']),'runner_source:'+row['path'],row['sha256'],row['bytes'])
    for row in manifest['external_files']:
        io.read(safe(REPO,row['path']),'external_source:'+row['path'],row['sha256'],row['bytes'])
    need(digest(io.read(A/'FROZEN_FILES.json','A_source_manifest'))==STAGE_A_HASH,'Stage A source pin')
    need(digest(io.read(PREP/'FROZEN_PREP_FILES.json','solver_source_manifest'))==PREP_HASH,'Solver source pin')
    for root,name in ((A,'FROZEN_FILES.json'),(PREP,'FROZEN_PREP_FILES.json')):
        packet=io.json(root/name,'nested_source_manifest')
        for row in packet['files']:io.read(safe(root,row['path']),'nested_source:'+row['path'],row['sha256'],row['bytes'])
    need(digest(io.read(PREP/'V2_WORK_BUDGET_AMENDMENT.json','v2_amendment'))==AMENDMENT_HASH,'v2 work amendment')
    return digest(raw),manifest

def admission(io,digest_,raw=None):
    a=json.loads(raw) if raw is not None else io.json(HERE/'ADMISSION.json','Stage_B_admission')
    need(a.get('decision')=='ADMIT_ONE_JOINT_VALUE_STAGE_B_REAL','No explicit Stage B admission')
    need(a.get('parent_authorized') is True and a.get('independent_review_accepted') is True,'Missing root/reviewer release')
    need(a.get('packet_manifest_sha256')==digest_ and a.get('max_runs')==1 and type(a.get('max_runs')) is int,'Wrong source or run count')
    need(a.get('limits')==CAPS and a.get('work_budget_per_layer_arm')==BUDGET,'Admission may not expand limits')
    need(len(a.get('stage_A_tensor_manifest_sha256',''))==64,'Stage A output must be pinned by admission')
    need(a.get('W_provenance_launcher_exit_code')==0 and a.get('stage_A_guard_parent_exit_code')==0,'Parent must verify successful provenance/Stage A launcher exit')
    need(len(a.get('W_provenance_finalization_sha256',''))==64,'Verified post-publication provenance receipt required')
    need(len(a.get('W_segment_pins_sha256',''))==64 and len(a.get('W_provenance_guard_sha256',''))==64,'Verified segment provenance required')
    return a

def provenance(io,a):
    # Metadata/receipt access only. Payload provenance belongs to a separately
    # approved bounded streaming pass, never a self-hash of an unverified segment.
    pins_path=safe(REPO,a['W_segment_pins_path']);guard_path=safe(REPO,a['W_provenance_guard_path'])
    pins=io.json(pins_path,'verified_W_segment_pins',a['W_segment_pins_sha256'])
    guard=io.json(guard_path,'W_provenance_guard',a['W_provenance_guard_sha256'])
    need(guard.get('exit_code')==0 and guard.get('termination') is None and guard.get('cleanup',{}).get('all_absent') is True,'Unclean W provenance guard')
    final=io.json(safe(REPO,a['W_provenance_finalization_path']),'W_provenance_finalization',a['W_provenance_finalization_sha256'])
    need(final.get('status')=='VERIFIED_PUBLISHED_WITHIN_FINAL_CAPS' and final.get('cleanup_all_absent') is True,'Unclean provenance publication')
    need(final.get('pins_sha256')==a['W_segment_pins_sha256'] and final.get('guard_sha256')==a['W_provenance_guard_sha256'],'Provenance receipt hash links')
    need(final.get('aggregate_cpu_seconds_after_publication',float('inf'))<=30 and final.get('elapsed_seconds_after_publication',float('inf'))<=90 and final.get('supervisor_high_water_rss_bytes_after_publication',float('inf'))<=268435456 and final.get('host_available_bytes_after_publication',0)>=2000000000,'Provenance publication caps')
    need(pins.get('all_shard_hashes_verified') is True,'W full-shard provenance unverified')
    need(pins.get('segments_hashed_from_same_full_shard_pass') is True,'W segment provenance not same stream')
    need(guard.get('aggregate_cpu_seconds_final',float('inf'))<=30 and guard.get('elapsed_seconds',float('inf'))<=90,'W provenance cap failure')
    return pins

def child():
    need(not sys.flags.optimize,'Optimized Python prohibited')
    io=IO();digest_,manifest=source_integrity(io)
    launch=io.json(OUT/'launch.json','launch_metadata')
    need(launch['guard_pid']==os.getppid(),'Wrong guard parent')
    a=admission(io,digest_,json.dumps(launch['admission']))
    need(launch['packet_manifest_sha256']==digest_,'Changed source after admission')
    for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):need(os.environ.get(name)=='1','One thread required')
    need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','GPU forbidden')
    # Only now may the pinned NumPy-only solver and native own C binary load.
    sys.path.insert(0,str(PREP))
    from runner import run
    pins=provenance(io,a);grant=Grant(A/'run',OUT,digest_)
    capture=Capture(grant,io,io.json(A/'EXTERNAL_PINS.json','external_pins'),io.json(A/'OLD_TENSOR_PINS.json','old_pins'))
    need(capture.manifest_hash==a['stage_A_tensor_manifest_sha256'],'Unadmitted Stage A output')
    weights=Weights(ASSETS,io.json(A.parent/'ASSET_METADATA.json','W_metadata'),io.json(A/'asset_expected.json','shard_expected'),pins,grant,io)
    bindings={'admission':a,'stage_A_tensor_manifest_sha256':capture.manifest_hash,'stage_A_packet_sha256':STAGE_A_HASH,'solver_manifest_sha256':PREP_HASH,'v2_amendment_sha256':AMENDMENT_HASH,'proposal_sha256':PROPOSAL_HASH,'config_sha256':CONFIG_HASH,'kernel_binary_sha256':manifest['kernel_binary_sha256'],'W_segment_pins_sha256':a['W_segment_pins_sha256'],'W_provenance_guard_sha256':a['W_provenance_guard_sha256'],'W_provenance_finalization_sha256':a['W_provenance_finalization_sha256'],'launch_metadata_and_source_IO':launch['source_io']}
    run(grant,capture,weights,bindings,PREP/'attempt_03/kernels.so',io)

def inherited_limits():
    limits={name:list(resource.getrlimit(getattr(resource,name))) for name in ('RLIMIT_CPU','RLIMIT_AS','RLIMIT_DATA','RLIMIT_FSIZE')}
    floors={'RLIMIT_CPU':CAPS['cpu_process_tree_seconds'],'RLIMIT_AS':CAPS['rss_process_tree_bytes'],'RLIMIT_DATA':CAPS['rss_process_tree_bytes'],'RLIMIT_FSIZE':CAPS['output_bytes']}
    for name,minimum in floors.items():
        finite=[x for x in limits[name] if x>=0]
        need(not finite or min(finite)>=minimum,'Inherited '+name+' below required envelope')
    return limits

def main():
    deadline=time.monotonic()+CAPS['wall_seconds']
    need(not sys.flags.optimize,'Optimized Python prohibited')
    io=IO();digest_,manifest=source_integrity(io);a=admission(io,digest_);provenance(io,a)
    # Validate Stage A receipts without opening calibration or holdout payload.
    grant=Grant(A/'run',OUT,digest_)
    capture=Capture(grant,io,io.json(A/'EXTERNAL_PINS.json','external_pins'),io.json(A/'OLD_TENSOR_PINS.json','old_pins'))
    need(capture.manifest_hash==a['stage_A_tensor_manifest_sha256'],'Wrong Stage A capture')
    sys.path.insert(0,str(PREP));import supervisor_core as core
    need(core.host_available()>=CAPS['minimum_host_available_bytes'],'Host available below2GB')
    cgroups=core.cgroup_limits();core.check_cgroups(cgroups,a);inherited=inherited_limits()
    need(__import__('shutil').disk_usage(HERE).free>=CAPS['output_bytes'],'Insufficient output free space')
    # Claim and unique output are never silently removed, reused, or retried.
    jwrite(HERE/'RUN_CLAIM.json',{'packet_manifest_sha256':digest_,'admission_sha256':digest(json.dumps(a,sort_keys=True).encode()),'max_runs':1})
    OUT.mkdir()
    jwrite(OUT/'launch.json',{'guard_pid':os.getpid(),'packet_manifest_sha256':digest_,'admission':a,'deadline_monotonic':deadline,'source_io':io.summary(),'inherited_limits':inherited,'cgroups':cgroups,'wall_deadline_scope':'entire launcher including metadata/source verification and finalization'})
    env=os.environ.copy();env.update({x:'1' for x in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')});env['CUDA_VISIBLE_DEVICES']='';env['PYTHONDONTWRITEBYTECODE']='1'
    signal.signal(signal.SIGTERM,core.interrupted);signal.signal(signal.SIGINT,core.interrupted)
    result=core.supervise([sys.executable,str(HERE/'launch.py'),'--supervised-child'],OUT,env,CAPS,a,deadline=deadline)
    complete=OUT/'completion.json';child_complete=json.loads(complete.read_text()).get('status')=='COMPLETE_PENDING_CLEAN_GUARD' if complete.exists() else False
    # Only after all children are reaped are source/result/resource hashes final.
    files=[]
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            raw=io.read(p,'post_cleanup_final_hash:'+str(p.relative_to(OUT)));files.append({'path':str(p.relative_to(OUT)),'bytes':len(raw),'sha256':digest(raw)})
    clean=result['exit_code']==0 and result['termination'] is None and result['cleanup']['all_absent'] and child_complete
    cpu=sum(resource.getrusage(x).ru_utime+resource.getrusage(x).ru_stime for x in (resource.RUSAGE_SELF,resource.RUSAGE_CHILDREN))
    final_hwm=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    final_host=core.host_available();final_cgroups=core.cgroup_limits()
    try:core.check_cgroups(final_cgroups,a);final_cgroup_ok=True
    except (RuntimeError,ValueError):final_cgroup_ok=False
    clean=clean and cpu<=CAPS['cpu_process_tree_seconds'] and time.monotonic()<=deadline and final_hwm<=CAPS['rss_process_tree_bytes'] and final_host>=CAPS['minimum_host_available_bytes'] and final_cgroup_ok
    final={'status':'COMPLETE_VALID_POPULATION' if clean else 'INVALID_WHOLE_POPULATION','no_retry':True,'source_manifest_sha256':digest_,'files':files,'post_cleanup_hash_read_bytes':io.read_bytes,'aggregate_cpu_seconds_including_finalization':cpu,'guard_parent_final_high_water_RSS_bytes':final_hwm,'host_available_after_final_hashes':final_host,'cgroups_after_final_hashes':final_cgroups,'final_cgroups_accepted':final_cgroup_ok,'cgroup_ceiling_unobservable_acceptance_is_not_capacity_proof':a.get('accept_unobservable_cgroup_ceiling',False)}
    # Precompute exact terminal size and include it in output-cap validation.
    raw=(json.dumps(final,indent=2,allow_nan=False)+'\n').encode()
    need(core.evidence_bytes(OUT)+len(raw)<=CAPS['output_bytes'],'Terminal output cap')
    jwrite(OUT/'FINAL_MANIFEST.json',final)
    need(core.evidence_bytes(OUT)<=CAPS['output_bytes'],'Post-terminal output cap')
    need(core.aggregate_cpu([])<=CAPS['cpu_process_tree_seconds'] and time.monotonic()<=deadline,'Post-terminal CPU/wall cap')
    need(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=CAPS['rss_process_tree_bytes'] and core.host_available()>=CAPS['minimum_host_available_bytes'],'Post-terminal RSS/host cap')
    core.check_cgroups(core.cgroup_limits(),a)
    return 0 if clean else 1

if __name__=='__main__':
    if sys.argv[1:]==['--supervised-child']:
        try:child()
        except BaseException as exc:
            if OUT.exists() and not (OUT/'failure.json').exists():jwrite(OUT/'failure.json',{'status':'INVALID_WHOLE_POPULATION','exception':type(exc).__name__,'message':str(exc),'no_retry':True})
            raise
    else:
        need(len(sys.argv)==1,'Unknown argument')
        try:sys.exit(main())
        except Exception as exc:
            if OUT.exists() and not (OUT/'launch_failure.json').exists():jwrite(OUT/'launch_failure.json',{'status':'INVALID_WHOLE_POPULATION','exception':type(exc).__name__,'message':str(exc),'no_retry':True})
            raise
