"""Stage B boundary contracts. No model imports; payload reads require a grant.

Synthetic tests construct every payload in their own TemporaryDirectory. A real
Grant is issued only by launch.py after fresh source-bound one-use admission.
"""
from pathlib import Path
import hashlib, io, json, os, struct
LAYERS=(0,7,14,21,28,35)
ARMS=('nearest','headwise_cd','group_joint_cd','full_joint_cd','guarded_token_gptq','projected_block_gptq')
BUDGET=1_300_000_000
CAPS={'cpu_process_tree_seconds':240,'wall_seconds':300,'rss_process_tree_bytes':536870912,'minimum_host_available_bytes':2_000_000_000,'output_bytes':268435456}
STAGE_A_HASH='c6b2221b0797889cf22fb032911f7902207f33ef1926cb9f27d65582fc77bce9'
PREP_HASH='f6f384d09b4090a3ff5f63376778f314415a81ef4102100c1b03090b16a2c32b'
AMENDMENT_HASH='5fdc5ea57a86f33f191938737751fee5869f3f9c0a10a9d0bced67be054440f2'
PROPOSAL_HASH='13e9accfc36a054a4935f00e77f24efc05d65dad22260ae02b955fc5f8350ef3'
CONFIG_HASH='a24b20825813b7b3f195585f19ab878ca0afde2db6445d3037ab17eed83b28f9'
TOKEN_HASH='27d8af446010f34bc39a8f16d63ae97e1857e5e61aba2398b10b197f5479966b'
def need(ok,msg):
    if not ok: raise ValueError(msg)
def digest(raw): return hashlib.sha256(raw).hexdigest()
def safe(root,relative):
    p=Path(relative); need(not p.is_absolute() and '..' not in p.parts,'Unsafe relative path')
    q=Path(root)/p
    for part in [q]+list(q.parents):
        if part==Path(root).parent:break
        need(not part.is_symlink(),'Symlink prohibited')
    need(q.resolve().is_relative_to(Path(root).resolve()),'Path escaped root'); return q

def jwrite(path,data):
    raw=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return {'path':str(p),'bytes':len(raw),'sha256':digest(raw)}

class IO:
    """Every physical input byte read is charged, including duplicate reads.

    materialized_bytes is cumulative explicit array/copy payload, NOT live RSS.
    Array envelopes and guard RSS are separate measurements.
    """
    def __init__(self):self.events=[];self.read_bytes=0;self.materialized_bytes=0;self.written_bytes=0
    def read(self,path,label,expected=None,size=None):
        with Path(path).open('rb',buffering=0) as f: raw=f.read()
        self.add_read(label,len(raw))
        if size is not None:need(len(raw)==size,'Size mismatch '+label)
        if expected is not None:need(digest(raw)==expected,'Hash mismatch '+label)
        return raw
    def add_read(self,label,n):self.read_bytes+=n;self.events.append({'kind':'physical_read','label':label,'bytes':n})
    def materialize(self,label,n):self.materialized_bytes+=n;self.events.append({'kind':'array_materialization','label':label,'bytes':n})
    def written(self,label,n):self.written_bytes+=n;self.events.append({'kind':'physical_write','label':label,'bytes':n})
    def json(self,path,label,expected=None):return json.loads(self.read(path,label,expected))
    def summary(self):return {'physical_read_bytes':self.read_bytes,'explicit_cumulative_materialized_bytes':self.materialized_bytes,'physical_written_bytes':self.written_bytes,'events':self.events,'materialization_is_not_live_RSS':True,'read_counter_scope':'unbuffered file API bytes consumed, including duplicate hash reads; not storage-device traffic or downloads'}

class Grant:
    def __init__(self,stage_a,out,source_hash,*,synthetic=False):
        self.stage_a=Path(stage_a).resolve();self.out=Path(out).resolve();self.source_hash=source_hash;self.synthetic=synthetic
        self.lock=None;self.segments={}
    def authorize_holdout(self,io):
        if self.lock is None:raise PermissionError('No future Q/K/V open or hash before all-layer/all-arm lock')
        raw=io.read(self.out/'ENCODING_LOCK.json','holdout_barrier_lock_recheck')
        need(digest(raw)==self.lock,'Encoding lock changed')

def schema():
    rows={}
    for l in LAYERS:
        for split,kind,shape,positions,role in (
            ('calibration','query',[16,32,128],[496,512],'calibration_query'),
            ('calibration','keys',[512,8,128],[0,512],'prefix_keys'),
            ('calibration','values',[512,8,128],[0,512],'prefix_values'),
            ('holdout','query',[16,32,128],[512,528],'holdout_query'),
            ('holdout','keys',[16,8,128],[512,528],'suffix_keys'),
            ('holdout','values',[16,8,128],[512,528],'suffix_values')):
            path=f'{split}/layer_{l:02d}/{kind}.npy'
            rows[path]={'layer':l,'split':split,'shape':shape,'positions':positions,'role':role,'storage_dtype':'<u2','logical_dtype':'bfloat16','layout':'token,head,channel','order':'C'}
    return rows

class Capture:
    def __init__(self,grant,io,external_pins,old_pins):
        self.grant=grant;self.io=io;root=grant.stage_a
        completion=io.json(root/'completion.json','stage_a_completion')
        guard=io.json(root/'guard_result.json','stage_a_guard')
        need(completion.get('status')=='COMPLETE' and completion.get('stage')=='A','Stage A not complete')
        need(completion.get('model_calls')==5 and completion.get('teacher_forced') is True,'Stage A native reference trajectory')
        need(completion.get('model_and_full_cache_released') is True and completion.get('all_old_query_and_key_bits_equal') is True and completion.get('offline_optimization_performed') is False,'Stage A trajectory/release')
        need(guard.get('exit_code')==0 and guard.get('termination') is None and guard.get('cleanup',{}).get('all_absent') is True,'Stage A guard/cleanup not clean')
        need(not (root/'failure.json').exists(),'Failed Stage A')
        self.manifest_hash=completion['tensor_manifest_sha256']
        m=io.json(root/'tensor_manifest.json','stage_a_manifest',self.manifest_hash)
        expected={'schema':'joint_value_capture.v1','capture_packet_manifest_sha256':STAGE_A_HASH,'proposal_sha256':PROPOSAL_HASH,'config_sha256':CONFIG_HASH,'token_ids_sha256':TOKEN_HASH,'model_repository':'Qwen/Qwen3-4B-Instruct-2507','model_revision':'cdbee75f17c01a7cc42f958dc650907174af0554','layers':list(LAYERS),'query_heads':32,'kv_heads':8,'head_dim':128,'query_head_to_kv':'j//4','native_scaling':128**-.5,'native_dtype':'bfloat16','causal_query_t_attends_keys':'0:t inclusive','calibration_positions':[496,512],'holdout_positions':[512,528],'calibration_keys_and_values_positions':[0,512],'holdout_keys_and_values_positions':[512,528],'position_ranges_half_open':True,'raw_tensor_bytes':14548992,'all_old_query_and_key_bits_equal':True,'source_pins':external_pins}
        for k,v in expected.items():need(m.get(k)==v,'Stage A metadata '+k)
        chunks=[[0,128],[128,256],[256,384],[384,512],[512,528]]
        need(m.get('chunks')==chunks,'Stage A chunk schedule')
        masks=m.get('causal_masks',[]);need(len(masks)==5,'Mask coverage')
        for z,(lo,hi) in zip(masks,chunks):need(z.get('start')==lo and z.get('end')==hi and z.get('shape')==[1,1,hi-lo,hi] and z.get('causal_positions_verified') is True and len(z.get('sha256',''))==64,'Mask metadata')
        parity=m.get('old_tensor_parity',[]);need(len(parity)==6,'Parity coverage')
        for l,z,old in zip(LAYERS,parity,old_pins['files']):
            need(z.get('layer')==l and z.get('query_bitwise') is True and z.get('keys_bitwise') is True and z.get('old_sha256')==old['sha256'],'Exact Q/K parity')
            need(len(z.get('query_data_sha256',''))==64 and len(z.get('keys_data_sha256',''))==64,'Parity hashes')
        files=m.get('files',[]);spec=schema()
        need(len(files)==36 and {z['path'] for z in files}==set(spec),'Tensor population')
        self.rows={}
        for z in files:
            for k,v in spec[z['path']].items():need(z.get(k)==v,'Tensor metadata '+k)
            need(z['raw_bytes']==__import__('math').prod(z['shape'])*2 and z['bytes']>=z['raw_bytes'],'Tensor size metadata')
            need(all(len(z.get(k,''))==64 for k in ('sha256','data_sha256')),'Tensor hash metadata')
            self.rows[z['path']]=z
        self.manifest=m
    def load(self,split,layer,kind):
        import numpy as np
        path=f'{split}/layer_{layer:02d}/{kind}.npy';need(path in self.rows,'Unexpected tensor')
        if split=='holdout':self.grant.authorize_holdout(self.io)
        z=self.rows[path];raw=self.io.read(safe(self.grant.stage_a,path),path,z['sha256'],z['bytes'])
        a=np.load(io.BytesIO(raw),allow_pickle=False)
        need(a.dtype==np.dtype('<u2') and a.flags.c_contiguous and list(a.shape)==z['shape'],'Tensor payload shape/dtype/order')
        need(digest(a.tobytes())==z['data_sha256'],'Tensor raw-data hash')
        self.io.materialize(path+':npy_and_hash_copy',a.nbytes*2)
        b=(a.astype(np.uint32)<<16).view(np.float32).astype(np.float64)
        self.io.materialize(path+':decode_u32_shift_fp64',a.size*(4+4+8))
        need(np.isfinite(b).all(),'Nonfinite BF16 tensor');return b

def stat_identity(st):
    return {k:getattr(st,k) for k in ('st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns')}

def verified_weight_path(root,shard,pins):
    need(Path(shard).name==shard and shard not in ('.','..'),'Unsafe shard name')
    rows=[x for x in pins.get('full_shard_hashes',[]) if x.get('shard')==shard]
    need(len(rows)==1,'Missing verified full shard identity')
    check=rows[0]['stat_checks'];need(check.get('unchanged') is True,'Provenance file identity changed')
    target=Path(root)/shard;resolved=target.resolve(strict=True)
    need(str(resolved)==check['resolved_after']==check['resolved_before'],'Unpinned weight symlink target')
    need(stat_identity(resolved.stat())==check['descriptor_after'],'Weight file changed since provenance')
    return resolved,check['descriptor_after']

class Weights:
    def __init__(self,root,metadata,shards,pins,grant,io):
        self.root=Path(root);self.metadata=metadata;self.shards={x['path']:x for x in shards['shards']};self.pins=pins;self.grant=grant;self.io=io
        need(pins.get('schema')=='joint_value_W_segments.v1' and pins.get('model_revision')=='cdbee75f17c01a7cc42f958dc650907174af0554','W segment pin identity')
        need(len(pins.get('segments',[]))==6 and [x['layer'] for x in pins['segments']]==list(LAYERS),'W segment coverage')
    def load(self,layer,phase):
        import numpy as np
        need(phase in ('encode','evaluate'),'W phase')
        if phase=='evaluate':self.grant.authorize_holdout(self.io)
        key=f'model.layers.{layer}.self_attn.o_proj.weight';z=self.metadata['entries'][key]
        pin=next(x for x in self.pins['segments'] if x['layer']==layer)
        need(z['dtype']=='BF16' and z['shape']==[2560,4096] and z['tensor_payload_bytes']==20971520,'W shape')
        shard=self.shards[z['shard']];p,identity=verified_weight_path(self.root,z['shard'],self.pins);need(p.stat().st_size==shard['bytes'],'W shard size')
        for k,v in {'key':key,'shard':z['shard'],'shard_sha256':shard['sha256'],'data_offsets':z['data_offsets'],'bytes':z['tensor_payload_bytes']}.items():need(pin.get(k)==v,'W segment pin '+k)
        need(len(pin.get('sha256',''))==64,'Missing W payload segment hash')
        header=next(x for x in self.metadata['header_reads'] if x['shard']==z['shard'])
        with p.open('rb',buffering=0) as f:
            need(stat_identity(os.fstat(f.fileno()))==identity,'Opened W identity changed')
            prefix=f.read(8);self.io.add_read(phase+':W_header_length',len(prefix));need(len(prefix)==8,'Truncated W header')
            n=struct.unpack('<Q',prefix)[0];need(n+8==header['bytes_read'],'W header length pin')
            h=f.read(n);self.io.add_read(phase+':W_header',len(h))
            need(digest(h)==header['header_sha256'],'W header hash')
            entry=json.loads(h)[key];need(entry=={'dtype':z['dtype'],'shape':z['shape'],'data_offsets':z['data_offsets']},'W header entry')
            start,end=z['data_offsets'];need(end-start==pin['bytes'] and 8+n+end<=shard['bytes'],'W offsets')
            f.seek(8+n+start);raw=f.read(end-start);self.io.add_read(phase+':W_payload:'+str(layer),len(raw))
            need(stat_identity(os.fstat(f.fileno()))==identity,'W identity changed during read')
        need(len(raw)==pin['bytes'] and digest(raw)==pin['sha256'],'W segment payload hash')
        if phase=='encode':need(layer not in self.grant.segments,'Repeated encoding W layer');self.grant.segments[layer]=pin['sha256']
        else:need(self.grant.segments.get(layer)==pin['sha256'],'Evaluation W differs from locked encoding')
        bits=np.frombuffer(raw,dtype='<u2').reshape(2560,4096)
        # Allocate only final80MiB plus <=4MiB conversion chunks. Signed values preserved.
        w=np.empty((4096,2560),np.float64)
        for lo in range(0,2560,64):
            chunk=(bits[lo:lo+64].astype(np.uint32)<<16).view(np.float32).astype(np.float64)
            w[:,lo:lo+64]=chunk.T
            self.io.materialize(phase+':W_chunk_u32_shift_fp64',chunk.size*16)
        self.io.materialize(phase+':W_final_FP64',w.nbytes)
        need(np.isfinite(w).all(),'Nonfinite W');return w.reshape(8,4,128,2560)

def check_record(r):
    need(r.get('arm') in ARMS and r.get('layer') in LAYERS,'Unexpected encoding record')
    need(r.get('complete') is True and r.get('full_sweeps',0)>=1 and r.get('row_caps_verified') is True,'Incomplete sweep/row caps')
    need(r['work']['mac_equivalent_units']<=BUDGET,'Work budget exceeded')
    need(set(r['artifacts'])=={'codes','first_sweep','grid','paths','row_sse','work_events'},'Missing code/grid/checkpoint/path/SSE artifact')

def lock_encodings(grant,records,bindings,io):
    expected={(l,a) for l in LAYERS for a in ARMS}
    need(len(records)==36 and {(r['layer'],r['arm']) for r in records}==expected,'Incomplete six-layer/all-arm population')
    for r in records:
        check_record(r)
        for z in r['artifacts'].values():io.read(safe(grant.out,z['path']),'encoding_lock:'+z['path'],z['sha256'],z['bytes'])
    need(set(grant.segments)==set(LAYERS),'Missing encoding W hash')
    payload={'schema':'joint_value_encoding_lock.v1','status':'ALL_ENCODINGS_LOCKED','source_manifest_sha256':grant.source_hash,'bindings':bindings,'records':records,'W_segment_sha256':{str(k):v for k,v in grant.segments.items()},'io_before_lock':io.summary()}
    z=jwrite(grant.out/'ENCODING_LOCK.json',payload);io.written('ENCODING_LOCK',z['bytes']);grant.lock=z['sha256'];return grant.lock
