#!/usr/bin/env python3
"""Fresh exact GQA compact-residual coordinate-descent equivalence/cost test."""
import os
for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[k]="1"
import hashlib,itertools,json,math,resource,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import numpy as np
HERE=Path(__file__).resolve().parent
CFG=json.loads((HERE/"config.json").read_text())
OUT=HERE/"results"
LEVELS=np.array([-2,-1,0,1],dtype=np.int8)
ALGORITHMS=CFG["algorithms"]

def projected(P,E,W):
    out=np.zeros((P.shape[1],W.shape[2]),dtype=np.float64)
    for h in range(P.shape[0]):
        out+=(P[h]@E)@W[h]
    return out

def fixture(seed,si,pi,shape):
    N,d,G,m,p=[shape[k] for k in ("N","d","G","m","p")]
    rk,rq,rv,rw,rkb,rqb,rvb,rwb=[np.random.default_rng(s) for s in np.random.SeedSequence([seed,si,pi]).spawn(8)]
    K=rk.normal(size=(N,d))
    Q=rq.normal(size=(1,m,d))+.35*rq.normal(size=(G,m,d))
    alpha=1+.25*np.sin(np.arange(d))
    step=alpha/2
    V=.4*rv.normal(size=(N,d))*alpha
    V[0,::7]=0
    W=rw.normal(size=(G,d,p))/math.sqrt(d)
    if pi==1:
        for h in range(1,G,2):
            W[h]=-W[h-1]+.05*rw.normal(size=(d,p))/math.sqrt(d)
    start=time.process_time()
    logits=np.stack([Q[h]@K.T for h in range(G)])/math.sqrt(d)
    logits-=logits.max(axis=-1,keepdims=True)
    P=np.exp(logits);P/=P.sum(axis=-1,keepdims=True)
    p_cpu=time.process_time()-start
    Kb=rkb.normal(size=(N,d)); Qb=rqb.normal(size=(G,m,d))
    Vb=.4*rvb.normal(size=(N,d))*alpha
    Wb=rwb.normal(size=(G,d,p))/math.sqrt(d)
    tb=time.process_time()
    lb=np.stack([Qb[h]@Kb.T for h in range(G)])/math.sqrt(d)
    lb-=lb.max(axis=-1,keepdims=True)
    Pb=np.exp(lb); Pb/=Pb.sum(axis=-1,keepdims=True)
    p_cpu+=time.process_time()-tb
    cb=np.clip(np.rint(Vb/step),-2,1).astype(np.int8)
    tb=time.process_time(); Rb=projected(Pb,cb*step-Vb,Wb)
    background_cpu=time.process_time()-tb
    near=np.clip(np.rint(V/step),-2,1).astype(np.int8)
    return {"K":K,"Q":Q,"V":V,"W":W,"P":P,"alpha":alpha,"step":step,"initial_codes":near,"background_K":Kb,"background_Q":Qb,"background_V":Vb,"background_W":Wb,"background_P":Pb,"background_codes":cb,"background_residual":Rb,"background_residual_CPU_seconds":np.array(background_cpu)},p_cpu

def run_algorithm(name,inp,shape):
    N,d,G,m,p=[shape[k] for k in ("N","d","G","m","p")]
    P,V,W,step=[inp[k] for k in ("P","V","W","step")]
    codes=inp["initial_codes"].copy()
    values=codes*step
    E=values-V
    base=np.sum(E*E,axis=1)
    row_sse=base.copy()
    t=time.process_time()
    R=inp["background_residual"].copy()+projected(P,E,W)
    init_cpu=time.process_time()-t
    initial_sse=float(np.sum(R*R))
    trace=np.zeros((2*d*N,8))
    residuals=np.zeros((2*d,m,p))
    direct_residuals=np.zeros_like(residuals)
    objectives=np.zeros((2*d,2))
    traces_i=0;checkpoint_i=0
    prep_cpu=loop_cpu=verify_cpu=0.
    max_direct_residual=0.
    max_row_tracking_residual=0.
    mechanics=True
    max_live_payload=0
    for pass_i in range(2):
      for c in range(d):
        t=time.process_time()
        B=W[:,c,:]
        if name=="head_gram_compact_cd":
            C=B@B.T
            S=R@B.T
            U=np.zeros((m,G))
        elif name=="qr_compact_cd":
            Uq,T=np.linalg.qr(B.T,mode="reduced")
            S=R@Uq
            S0=S.copy()
        prep_cpu+=time.process_time()-t
        t=time.process_time()
        for i in range(N):
            A=P[:,:,i].T
            if name=="full_projected_residual_cd":
                Di=A@B
                g=float(np.sum(R*Di))
                h=float(np.sum(Di*Di))
                active_bytes=R.nbytes+Di.nbytes
            elif name=="head_gram_compact_cd":
                AC=A@C
                g=float(np.sum(A*S))
                h=float(np.sum(A*AC))
                active_bytes=R.nbytes+C.nbytes+S.nbytes+U.nbytes+AC.nbytes
            else:
                Z=A@T.T
                g=float(np.sum(S*Z))
                h=float(np.sum(Z*Z))
                active_bytes=R.nbytes+Uq.nbytes+T.nbytes+S.nbytes+S0.nbytes+Z.nbytes
            max_live_payload=max(max_live_payload,active_bytes)
            old=int(codes[i,c]);new=old;delta=0.;predicted_change=0.
            if h>1e-24:
                deltas=LEVELS.astype(float)*step[c]-values[i,c]
                proposed_rows=row_sse[i]-E[i,c]**2+(E[i,c]+deltas)**2
                feasible=proposed_rows<=1.25*base[i]+1e-12
                changes=2*deltas*g+deltas*deltas*h
                choices=np.where(feasible,changes,np.inf)
                j=int(np.argmin(choices))
                if choices[j]<-1e-14:
                    new=int(LEVELS[j]);delta=float(deltas[j]);predicted_change=float(changes[j])
            trace[traces_i]=[pass_i,c,i,old,new,g,h,predicted_change]
            traces_i+=1
            if new!=old:
                codes[i,c]=new
                row_sse[i]+=(E[i,c]+delta)**2-E[i,c]**2
                E[i,c]+=delta
                values[i,c]+=delta
                if name=="full_projected_residual_cd":
                    R+=delta*Di
                elif name=="head_gram_compact_cd":
                    S+=delta*AC
                    U+=delta*A
                else:
                    S+=delta*Z
        if name=="head_gram_compact_cd":
            R+=U@B
        elif name=="qr_compact_cd":
            R+=(S-S0)@Uq.T
        residuals[checkpoint_i]=R
        loop_cpu+=time.process_time()-t
        t=time.process_time()
        # Independent direct reconstruction from current integer codes at every channel.
        true_E=codes*step-V
        Rd=inp["background_residual"]+projected(P,true_E,W)
        direct_residuals[checkpoint_i]=Rd
        sse=float(np.sum(R*R));direct_sse=float(np.sum(Rd*Rd))
        objectives[checkpoint_i]=[sse,direct_sse]
        max_direct_residual=max(max_direct_residual,float(np.max(np.abs(R-Rd))))
        max_row_tracking_residual=max(max_row_tracking_residual,float(np.max(np.abs(row_sse-np.sum(true_E*true_E,axis=1)))))
        tol=1e-9+1e-9*max(1.,direct_sse)
        mechanics &= bool(np.allclose(R,Rd,atol=tol,rtol=0))
        mechanics &= abs(sse-direct_sse)<=tol
        prev=initial_sse if checkpoint_i==0 else objectives[checkpoint_i-1,1]
        mechanics &= direct_sse<=prev+tol
        mechanics &= bool(np.all(np.sum(true_E*true_E,axis=1)<=1.25*base+1e-12))
        mechanics &= bool(np.isfinite(R).all() and np.isfinite(trace[:traces_i]).all())
        checkpoint_i+=1
        verify_cpu+=time.process_time()-t
    # Byte packing with padding at the end, never counted as additional real scalar entries.
    flat=(codes.reshape(-1)+2).astype(np.uint8)
    pad=(-len(flat))%4
    flat=np.pad(flat,(0,pad))
    packed=sum(flat[i::4]<<(2*i) for i in range(4))
    restored=np.stack([(packed>>(2*i))&3 for i in range(4)],axis=-1).reshape(-1)[:N*d].astype(np.int8)-2
    mechanics &= bool(np.array_equal(restored.reshape(N,d),codes))
    arr={"codes":codes,"values":values,"trace":trace,"residual_checkpoints":residuals,
         "direct_residual_checkpoints":direct_residuals,"objective_checkpoints":objectives,
         "packed":packed,"initial_row_sse":base,"tracked_row_sse":row_sse}
    meta={"mechanics":bool(mechanics),"initial_objective":initial_sse,"final_objective":float(objectives[-1,1]),
          "changed_coordinate_steps":int(np.count_nonzero(trace[:,3]!=trace[:,4])),
          "sequential_coordinate_steps":len(trace),"initial_residual_cpu_seconds":init_cpu,
          "method_preparation_cpu_seconds":prep_cpu,"cd_loop_cpu_seconds":loop_cpu,
          "direct_verification_cpu_seconds":verify_cpu,
          "encoder_cpu_seconds_excluding_verification":init_cpu+prep_cpu+loop_cpu,
          "max_direct_residual_absolute":max_direct_residual,
          "max_row_sse_tracking_absolute":max_row_tracking_residual,
          "working_residual_and_feature_payload_bytes":max_live_payload,
          "excluded_diagnostic_payload_bytes":trace.nbytes+residuals.nbytes+direct_residuals.nbytes+objectives.nbytes}
    return arr,meta

def costs(s):
    N,d,G,m,p=[s[k] for k in ("N","d","G","m","p")]
    return {"P_acquisition_QK_MAC_both_groups":2*G*m*N*d,
            "fixed_background_residual_MAC":G*m*N*d+G*m*d*p,
            "initial_residual_MAC":G*m*N*d+G*m*d*p,
            "full_CD_derivative_MAC_per_two_sweeps":2*N*d*m*G*p,
            "full_CD_gradient_dot_terms":2*N*d*m*p,
            "full_CD_curvature_square_terms":2*N*d*m*p,
            "compact_feature_MAC_upper_per_two_sweeps":2*N*d*m*G*G,
            "compact_gradient_dot_terms":2*N*d*m*G,
            "Gram_preparation_MAC_per_two_sweeps":2*d*(G*G*p+m*p*G),
            "QR_basis_factorization":"2*d factorizations of p-by-G matrix, ordinary reduced QR; reusable across queries in principle",
            "compact_reconciliation_MAC_upper_per_two_sweeps":2*d*m*G*p,
            "sequential_steps_per_two_sweeps":2*N*d,
            "P_payload_bytes_FP64":8*G*m*N,"E_payload_bytes_FP64":8*N*d,
            "R_payload_bytes_FP64":8*m*p,
            "full_H_payload_bytes_FP64":8*(N*d)**2,
            "rank_H_upper":min(N*d,m*p,m*G*d),
            "counts_scope":"Analytical logical work of the literal algorithm, not hardware instruction counts or timings. Dot/vector ops shown separately; diagnostic verification excluded."}

def main():
    t0=time.process_time();w0=time.perf_counter()
    if OUT.exists():raise RuntimeError("Refuse overwrite or rerun")
    OUT.mkdir()
    hashes={fn:hashlib.sha256((HERE/fn).read_bytes()).hexdigest() for fn in ("config.json","run_compact_cd.py")}
    (OUT/"start_receipt.json").write_text(json.dumps({"sha256":hashes,"numpy":np.__version__,"started_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())},indent=2))
    results=[];case_id=0
    for si,shape in enumerate(CFG["shapes"]):
      for seed in CFG["seeds"]:
       for pi,pmode in enumerate(CFG["projection_modes"]):
        inp,pcpu=fixture(seed,si,pi,shape)
        records={};arrays=dict(inp);outputs={}
        order=ALGORITHMS[case_id%3:]+ALGORITHMS[:case_id%3]
        for name in order:
            arr,meta=run_algorithm(name,inp,shape)
            records[name]=meta
            outputs[name]=arr
            arrays.update({name+"__"+k:v for k,v in arr.items()})
        ref=outputs["full_projected_residual_cd"]
        equal_final=all(np.array_equal(arr["codes"],ref["codes"]) for arr in outputs.values())
        equal_trace=all(np.array_equal(arr["trace"][:,4],ref["trace"][:,4]) for arr in outputs.values())
        max_diff=max(float(np.max(np.abs(arr["residual_checkpoints"]-ref["residual_checkpoints"]))) for arr in outputs.values())
        objscale=max(1.,float(np.max(ref["objective_checkpoints"])))
        close_outputs=all(np.allclose(arr["residual_checkpoints"],ref["residual_checkpoints"],atol=1e-9+1e-9*objscale,rtol=0) and np.allclose(arr["objective_checkpoints"],ref["objective_checkpoints"],atol=1e-9+1e-9*objscale,rtol=0) for arr in outputs.values())
        record={"case":case_id,"shape":shape,"seed":seed,"projection_mode":pmode,"run_order":order,
                "P_acquisition_cpu_seconds":pcpu,"background_residual_cpu_seconds":float(inp["background_residual_CPU_seconds"]),"algorithms":records,"costs":costs(shape),
                "gates":{"exact_final_codes":bool(equal_final),"exact_chosen_code_trace":bool(equal_trace),
                         "checkpoint_outputs":bool(close_outputs),"mechanics":all(x["mechanics"] for x in records.values())},
                "max_cross_algorithm_residual_absolute":max_diff,
                "peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
        record["pass"]=all(record["gates"].values())
        np.savez_compressed(OUT/f"case_{case_id:02d}.npz",**arrays)
        with (OUT/"cases.jsonl").open("a") as f:f.write(json.dumps(record)+"\n")
        results.append(record)
        print(json.dumps({"case":case_id,"shape":shape,"pass":record["pass"],"max_diff":max_diff,
             "encoder_CPU":{k:v["encoder_cpu_seconds_excluding_verification"] for k,v in records.items()}}),flush=True)
        case_id+=1
    result={"decision":"PASS_EXACT_PROJECTED_CD_ENGINEERING_ONLY" if all(r["pass"] for r in results) else "FAIL_FROZEN_EQUIVALENCE_CONTRACT",
            "cases":len(results),"all_gates_pass":all(r["pass"] for r in results),
            "max_cross_algorithm_residual_absolute":max(r["max_cross_algorithm_residual_absolute"] for r in results),
            "P_acquisition_CPU_seconds":sum(r["P_acquisition_cpu_seconds"] for r in results),
            "fixed_background_residual_CPU_seconds":sum(r["background_residual_cpu_seconds"] for r in results),
            "encoder_CPU_seconds_excluding_verification":{a:sum(r["algorithms"][a]["encoder_cpu_seconds_excluding_verification"] for r in results) for a in ALGORITHMS},
            "direct_verification_CPU_seconds":sum(x["direct_verification_cpu_seconds"] for r in results for x in r["algorithms"].values()),
            "cpu_seconds_through_result":time.process_time()-t0,"wall_seconds_through_result":time.perf_counter()-w0,
            "peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,"frozen_sha256":hashes,
            "scope":"Same exact scalar CD update order/grid/cap/objective. Compact representations are optimized strong baselines. No quality or general speed claim, no old packet rerun, no model inference/GPU."}
    if result["peak_rss_bytes"]>CFG["resources"]["rss_bytes_limit"]:result["decision"]="FAIL_RSS_LIMIT"
    (OUT/"result.json").write_text(json.dumps(result,indent=2))
    manifest=[{"file":p.name,"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.iterdir()) if p.is_file()]
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2))
    print(json.dumps(result),flush=True)

if __name__=="__main__":main()

