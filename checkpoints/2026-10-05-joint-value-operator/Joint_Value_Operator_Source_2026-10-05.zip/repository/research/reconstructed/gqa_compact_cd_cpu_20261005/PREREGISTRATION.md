# Fresh compact-CD mechanics registration

Registered and sent to the parent before numerical execution on 2026-10-05 at approximately 09:12 UTC.

- config.json SHA256: a251ddfeddf9ee9ea4148ed4b70bb9936afc6bf19689ac797a8d48607728cd7e
- run_compact_cd.py SHA256: de1881d78bc8d2bb98671da3276508eaa03ee73d4d6c20976b10f3a2e7956511

The exact configuration is in config.json. This is a fresh equivalence/cost test, with three new seeds and no old arrays, thresholds or outcomes reused. Source-derived arithmetic counts are not timings. Cross-KV-group error is represented by an independently generated second group held fixed in the total residual.

Both compact implementations are optimized strong baselines. The test has no model-quality admission gate and cannot rescue or reinterpret the earlier failed quality experiment. No source code, models, packages or GPU runtimes are executed.
