# Full projected GQA V-rounding: exact structure and source decision

2026-10-05 UTC. Source inspection and analytical cost derivation. This is distinct from the earlier failed N4/D2 quality packet, which remains unchanged.

## Decision

**Admit only a fresh tensor-equivalence/cost falsifier for an exact compact coordinate-descent implementation. Do not admit a new quality method or publication claim.**

The GQA Hessian contains useful structure beyond one Kronecker product. An exact channel-major residual representation reduces the arithmetic of scalar projected-CD updates without dropping cross-head terms or assuming the whole output projection is low rank. But an equally natural head-Gram sufficient-statistic implementation has the same scaling. QR is therefore not an asymptotically new quantization algorithm; both are strong optimized projected-CD controls.

There is a separate, concrete comparison worth preserving: OptR's released loss averages individually squared projected query-head errors. It is a legitimate proxy, but differs from squaring their sum. Whether retaining those cross-head terms improves genuinely held-out behavior at matched encoding cost is untested. The mechanics test cannot answer it.

## 1. Exact objective, Hessian and ranks

For one active KV group let E=Vhat-V have shape N-by-d, calibration attention P_h have shape m-by-N, and W_h have shape d-by-p. Let R_bg denote the fixed output error of other KV groups. The actual joint projected loss is

    L(E) = ||R_bg + T(E)||_F²,
    T(E) = sum_(h=1..G) P_h E W_h.

The Hessian of one-half this loss, under row-major vectorization, is

    H = sum_(h,h') (P_h^T P_h') tensor (W_h W_h'^T).

It is a **sum of Kronecker products**, not generally a single separable product and not the special mathematical Kronecker sum A tensor I + I tensor B. Individual off-diagonal terms need not be symmetric/PSD; the complete H is PSD.

The exact matrix-free forward and adjoint are

    T(E) = sum_h P_h E W_h,
    T*(R) = sum_h P_h^T R W_h^T.

Each application costs O(G m N d + G m d p) MACs. This already avoids the (Nd)-square Hessian and is a mandatory strong baseline for soft-rounding/projected-gradient methods.

Stack all P_h vertically into P_stack, and all W_h vertically into W_stack. Then

    rank(H) = rank(T)
      <= min(Nd, d rank(P_stack), m rank(W_stack))
      <= min(Nd, m p, m G d).

The rank is not “m queries”: each query has many independent output directions. For d=128, G=8, m=16, it can be as large as 16,384. A full-rank output factor for the group can have rank Gd=1,024. No assumption of tiny learned output rank is justified by these dimensions.

A Woodbury core at the 16,384 rank bound is 1 GiB in FP32 before factors, decomposition work, workspaces, damping and repeated updates. A small rank relative to Nd does not by itself make a sequential inverse-Hessian quantizer economical.

## 2. Exact channel-major compact residual

For a fixed value channel c, assemble B_c in R^(G-by-p), whose h-th row is W_h[c,:]. For token i let A_i in R^(m-by-G) have h-th column P_h[:,i]. Changing E[i,c] by delta changes the full residual by

    delta R = delta A_i B_c.

### Full-residual scalar CD reference

Keep the complete current R, form D_i=A_i B_c, and evaluate

    g=<R,D_i>,  h=||D_i||_F².
    loss_change(delta)=2 delta g + delta² h.

Test allowed fixed-grid codes and constraints using this exact scalar quadratic. This is the baseline update rule, not a new objective or optimizer.

### Head-Gram compact control

At the start of channel c compute

    C_c=B_c B_c^T; S=R B_c^T; U=0.

For each token, use g=<A_i,S> and h=<A_i,A_i C_c>. After an accepted delta:

    S += delta A_i C_c;
    U += delta A_i.

After the complete channel, reconcile R += U B_c. Every scalar uses the correct current derivative. Contributions from other channels/groups are already present in the initial S.

### Untruncated-QR compact control

Use reduced QR B_c^T=U_c T_c with orthonormal columns in U_c. Taking all G columns when G<=p requires no numerical-rank cutoff or approximation. At channel entry save S0=R U_c and set S=S0. For each token define Z_i=A_i T_c^T and use

    g=<S,Z_i>, h=||Z_i||², S += delta Z_i.

After the channel, reconcile R += (S-S0) U_c^T.

All modifications within that channel lie in span(U_c), so the orthogonal residual component is constant. This explains exact equivalence to full projected CD for the same order/grid/constraints. The low dimension is an **exact active-channel update span of at most G**, not a low-rank approximation to all of W_O.

### What the representation does not supply

- It does not find a globally optimal discrete quantization
- It does not reproduce GPTQ/OBS's one-pass continuous compensation trajectory; it reproduces cyclic discrete coordinate descent
- It does not reduce the N*d sequential coordinate decisions in an exact scalar sweep
- It does not establish that different query-head terms should be fitted using a short prefill window
- It does not permit independently optimizing KV groups while omitting their cross terms

For multiple KV groups, maintain one full residual containing every group's current error and update groups sequentially (or use an explicitly consistent block schedule). The Hessian for an active group has the form above; the full residual supplies the linear terms caused by other groups. The fresh test includes a second fixed group for this reason.

## 3. Actual logical costs at native head dimension

Take N=131072, d=128, G=8, m=16, p=4096; all counts below are for one active KV group/layer, not a whole model.

| Item | Analytical payload/work |
|---|---:|
| Dense FP32 H | 1 PiB |
| P_stack FP32 | 64 MiB |
| One dense E array FP32 | 64 MiB |
| Full residual R FP32 | 256 KiB |
| All W_h FP32 for this group | 16 MiB |
| Active compact residual m-by-G FP32 | 512 bytes |
| Active G-by-G Gram FP32 | 256 bytes |
| One QR basis p-by-G FP32 | 128 KiB |
| Scalar decisions per sweep | 16,777,216 |
| Full-reference derivative construction, N d m G p | 8.796 trillion MACs |
| Compact feature construction upper count, N d m G² | 17.180 billion MACs |
| Two channel projection/reconciliation terms, 2 d m G p | 134.218 million MACs |
| Attention QK acquisition, G m N d | 2.147 billion MACs |

QR's triangular factor can reduce constants; Gram needs no factorization and may have better setup constants. Both are O(N d m G²) for the scalar sweep plus O(d m G p + d p G²) setup/reconciliation terms. Counts exclude small scalar code-option/row-cap logic and list vector dots separately in the test.

The 512-fold ratio of the leading derivative-construction counts is **not a latency prediction**. The small sequential updates and reductions can be poor GPU workloads. At 16.8 million serial decisions per group/layer, an asymptotic arithmetic reduction may still be impractical online. Efficient matrix-free batch-gradient/AdaRound-style methods cost only O(GmNd+Gmdp) per forward/adjoint application and must be compared at matched encoder work and stopping criteria.

Storing P avoids recomputing attention for every channel but costs 64 MiB per group/layer. Streaming P by channel reduces storage at the cost of repeated acquisition. A blocked token/channel scheme changes the schedule and needs its own equivalence and cost contract. The full prefill attention matrix is neither needed nor free. Quantization parameters, original values, mutable codes, row-error bookkeeping and protected windows must also be counted in any deployment.

## 4. Closest sources and direct collisions

### QuantEase and generic matrix-free CD

[QuantEase, primary paper](https://arxiv.org/html/2309.01885v2#S3) already performs discrete coordinate minimization, maintains sufficient products and implements lazy updates. Its [pinned public code](https://github.com/linkedin/QuantEase/blob/e8c7d715c915e907ef9d57e477927bccee6be9ea/method/quantease.py#L47-L102) uses a token/feature Gram and matrix products. It relies on independent output rows in the original one-sided objective; it does not directly implement the exact joint GQA map.

[Wright's coordinate-descent treatment](https://arxiv.org/pdf/1502.04759) documents residual/sufficient-variable representations and block-coordinate variants. Thus avoiding an explicit Hessian or maintaining the active projected residual is established optimization machinery. The GQA specialization is concrete engineering, not evidence of a new general solver.

### AdaRound

[AdaRound, ICML2020](https://proceedings.mlr.press/v119/nagel20a.html) already learns non-nearest rounding decisions through a local loss and a soft relaxation. Its direct matrix-free adaptation to T(E) retains all terms. It is an essential encoding-cost/quality control. This screen did not execute or reproduce the author code.

### K-FAC, KronQ, YAQA, BaKron and GPTQ-2D

[K-FAC's original work](https://proceedings.mlr.press/v37/martens15.html) establishes separable curvature approximations. [KronQ, July2026](https://arxiv.org/html/2607.07964v1#S4) adds output-side covariance and shows that factor cancels in its column-block compensation; [pinned code](https://github.com/Intelligent-Computing-Lab-Panda/KronQ/blob/c1f84d2f556a2906bd8ac8e0faebe42a9faaf10b/calib/kronq_utils.py#L110-L137) explicitly discards it after preprocessing. That cancellation cannot be assumed for our nonseparable GQA sum.

[YAQA's pinned implementation](https://github.com/Cornell-RelaxML/yaqa-quantization/blob/f9508723251ad839f0162326569f17fe70486fcc/lib/algo/ldlq.py#L17-L67) uses two Hessian factors and block anti-diagonal processing.

[BaKron, August2026](https://arxiv.org/html/2608.06291v1#S3), and [GPTQ-2D, July2026](https://arxiv.org/html/2607.27042v1#S4), already reduce the work of two-sided adaptive rounding with a **single Kronecker metric** using structured lazy feedback and anti-diagonal parallelism. BaKron explicitly acknowledges that a sum/expectation of Kronecker products is not generally a single product, then approximates it. Their exact inverse-factor shortcuts do not automatically apply to the GQA sum. No attributable BaKron/GPTQ-2D code artifact was verified in this bounded pass; their papers and algorithms were read.

Replacing the exact H by one K-FAC/Shampoo factor is an occupied approximation, and would need an error ledger. Applying an inverse factor from that approximation is not “exact cross-head compensation.”

### OptR: the decisive objective distinction, source verified

[OptR, August2026](https://arxiv.org/html/2608.02691v1#A1), uses post-output-projection KV errors to learn rotations. The [released V-loss function at 66d4656](https://github.com/daniel-eai/Output-Aware-INT2-KV-Cache-Quantization/blob/66d46561b9bdf5d715f591e0f5845a4cbd927dee/optr/calibrate_optr.py#L83-L113) loops over query heads, squares each d_out, and then averages. It does not sum projected head errors before squaring, so h≠h' terms are absent. This is a legitimate headwise proxy, not a bug.

Its object being optimized is an offline reusable rotation, rather than per-prefix scalar codes. Those acquisition/amortization differences must survive any future comparison. Its held chunks are used for selection in the code; a new evaluation would need separately untouched final holdouts.

[September2026 Kronecker-Fisher work](https://arxiv.org/html/2609.02451v1#S3) already studies matrix-free truncated sums of Kronecker factors for curvature analysis. It concerns weight/Fisher estimation rather than this exact activation-cache CD solver. “Keep several Kronecker terms” is not by itself the residual contribution.

## 5. Approximation accounting

The proposed Gram/QR mechanics do not truncate output directions. If later replacing W_h by W_h+Delta W_h, then

    ||Delta T(E)||_F
      <= eta ||E||_F,
    eta = sum_h ||P_h||_2 ||Delta W_h||_2.

Consequently

    | ||T(E)+Delta T(E)||² - ||T(E)||² |
      <= 2 ||T(E)||_F eta ||E||_F + eta² ||E||_F².

A background residual replaces ||T(E)|| by ||R_bg+T(E)|| in the cross term. The bound may be loose but the omitted projection error cannot be called zero. Similarly, H approximation error obeys |e^T(H-Hhat)e| <= ||H-Hhat||_2 ||e||². An observed low Frobenius error alone is not a guarantee of small error in the rounding directions.

## 6. What the admitted mechanics test establishes

The frozen configuration uses entirely fresh synthetic tensors and seeds, full signed GQA coupling, and a fixed second-group residual. It compares full-residual CD, head-Gram CD and untruncated-QR CD under identical scalar ordering, code grid, initialization and row constraints. Its sole admission target is numerical equivalence and measured CPU costs at its declared shapes, through d=128.

A pass does not reopen the failed quality packet, demonstrate generalization, establish a GPU speedup, or make QR a new algorithm. The next scientifically distinct question, if separately admitted, would concern exact joint versus headwise objectives at matched encoding budgets on untouched natural tensors. No such test, model invocation or weight read is authorized or performed in this screen.

