# Exact compact projected-CD mechanics: terminal engineering pass

2026-10-05 UTC. **PASS_EXACT_PROJECTED_CD_ENGINEERING_ONLY.** One frozen run, no rerun or tuning. The previous failed N4/D2 quality gate remains unchanged.

## What passed

Across all 24 fresh cases, full projected-residual coordinate descent, head-Gram compact CD, and untruncated-QR compact CD produced:

- exactly identical final integer codes
- exactly identical chosen-code trajectories at every one of 132,768 coordinate updates per method
- matching channel-boundary residuals and objective values under the registered tolerances
- valid per-row error caps, finite arrays, non-increasing direct objective and exact 2-bit packing round trips

The maximum cross-algorithm residual difference was **1.2212453271e-15** in FP64. This verifies the compact representations for the declared update order and constraints; it does not demonstrate a superior optimizer or model quality.

## Full GQA and fixed second KV group

Shapes ranged from N17/d8/G1/m4/output16 to **N65/d128/G8/m8/output512**. Three new seeds and two signed projection families were used; the opposed family includes near-opposing head projection blocks.

An independently generated second KV group was quantized by nearest rounding and held fixed. Its projected error remained inside every method's full residual and derivative, so active-group updates included cross-group error interactions. All 24 background residuals are nonzero. Read-only saved-array verification reconstructed each background residual exactly from its stored P, V, codes and W.

This is not simultaneous optimization of every KV group. A complete future method must retain the full residual while updating groups in an explicit schedule.

## Workload and constraints

Every method used the same four-code 2-bit grid, same per-channel scales, nearest initialization, two channel-major cyclic sweeps, same token order and same per-row squared reconstruction-error cap of 1.25 times nearest. Each coordinate examined all four codes. No method was allowed a different grid, code ordering, observation set or guard.

Both compact methods are **optimized strong baselines**:
- Gram stores the active head-projected residual and uses a G-by-G Gram
- QR stores the active orthonormal residual and keeps all G QR columns

Neither discards cross-head terms or truncates learned projection directions. The per-channel exact rank bound is at most G even when the overall output map has much larger rank. The mathematical derivation and source comparisons are in SOURCE_AND_STRUCTURE.md.

## Measured CPU observations and limits

The complete script reported **23.1950 CPU seconds**, **23.2050 wall seconds**, and peak RSS **118,927,360 bytes (113.42 MiB)** through result construction. Final result-manifest hashing follows its internal result timer. The 120-CPU-second and 512-MiB OS limits were not approached.

Diagnostic encoder CPU totals, excluding direct verification:
- Full residual CD: 2.84614 seconds
- Head-Gram compact CD: 2.39017 seconds
- QR compact CD: 2.40638 seconds

For the six d128 cases, recorded encoder samples range:
- Full: 0.35183–0.40380 seconds
- Gram: 0.28817–0.32333 seconds
- QR: 0.28381–0.33160 seconds

These are **one-sample-per-case CPU observations**, not robust speedup estimates. Execution order rotated, but there were no repetition or warmup controls. Diagnostic traces and Python overhead are included in encoder timing.

### Important short-timer limitation

Short process CPU subtimers often read zero, with visible increments near four milliseconds elsewhere. P-acquisition and fixed-background-construction subtimers were all recorded as zero. Some preparation subtimers also read zero. Those values mean **unresolved timing at this granularity**, never zero work. No measurements were rerun to repair that limitation.

The analytical acquisition/encoding counts are separately preserved per case, including:
- both groups' QK acquisition
- fixed background construction
- active initial full residual
- each method's feature construction and scalar dot/update work
- projection/Gram/QR setup and reconciliation
- N*d sequential coordinate decisions per sweep

No CPU timing is extrapolated to GPU, long-context generation, or a whole model.

## Independent read-only verification

After the one run:
- All **27** result-manifest entries matched their SHA-256 checksums
- All 24 saved arrays contained active and background projection weights and background quantized values/codes
- All coordinate traces and final codes matched exactly
- Every background residual independently reconstructed with maximum difference zero

The audit only read saved arrays; it did not execute another optimization or retune anything. Details are in VERIFICATION.json.

## Artifacts

The approximately 357 MiB results directory contains every input, active/background group, calibration attention matrix, fixed projection block, initial code array, complete per-coordinate update trace, per-channel maintained and direct residual/objective, final code and packed payload.

Unchanged registered hashes:
- config.json: a251ddfeddf9ee9ea4148ed4b70bb9936afc6bf19689ac797a8d48607728cd7e
- run_compact_cd.py: de1881d78bc8d2bb98671da3276508eaa03ee73d4d6c20976b10f3a2e7956511

Terminal result hashes:
- results/result.json: 19c0c6a6c1f476f7997fb87f7c859029b2d65a51e3155225d3317927d9859e3c
- results/manifest.json: 33e483d79c1a4c47409914153918cf6b0e9347173c47b1dea79c0907ee598343

No inference, model download, installation, GPU, paid action or public modification occurred.

**Stopping point:** numerical equivalence is established for this fresh packet. Actual runs are stopped. Any exact-joint versus headwise quality comparison requires a separately justified protocol and independent natural tensor data.

