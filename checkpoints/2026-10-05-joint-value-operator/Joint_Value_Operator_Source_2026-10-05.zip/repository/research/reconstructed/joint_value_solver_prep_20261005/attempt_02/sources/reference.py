"""MODEL-FREE REFERENCE ONLY: fixed-grid V rounding and tiny signed designs.

No imports of model/runtime packages, no file/network access, and no main entry
point. The full-residual solver and explicit design are intentionally tiny-only.
This source is a preparation artifact, not authorization to execute Stage B.
"""
from __future__ import annotations

import numpy as np

EPS64 = np.finfo(np.float64).eps
TOL_MULTIPLIER = 64.0
CAP_MULTIPLIER = 1.25
DAMPING = 0.01
FIXTURE_SEEDS = (2026100541, 2026100542, 2026100543)


def _finite64(x, name):
    out = np.asarray(x, dtype=np.float64)
    if not np.all(np.isfinite(out)):
        raise ValueError(name + " must be finite")
    return out


def _codes(x, name="codes"):
    a = _finite64(x, name)
    if np.any((a < 0) | (a > 3) | (a != np.floor(a))):
        raise ValueError(name + " must contain integers 0..3")
    return a.astype(np.uint8)


def loss_tolerance(linear, quadratic):
    """Frozen absolute tolerance for an UNDAMPED loss difference."""
    terms = _finite64((linear, quadratic), "loss terms")
    magnitude = abs(float(terms[0])) + abs(float(terms[1]))
    if not np.isfinite(magnitude):
        raise ValueError("nonfinite loss magnitude")
    return TOL_MULTIPLIER * EPS64 * max(1.0, magnitude)


def cap_slack(nearest_sse, cap):
    """No absolute-one floor: a zero-nearest row has exactly zero slack."""
    nearest = _finite64(nearest_sse, "nearest_sse")
    limit = _finite64(cap, "cap")
    if np.any(nearest < 0) or np.any(limit < 0):
        raise ValueError("SSE and cap must be nonnegative")
    return TOL_MULTIPLIER * EPS64 * np.maximum(nearest, limit)


def cap_feasible(sse, cap, nearest_sse):
    sse = _finite64(sse, "sse")
    nearest = _finite64(nearest_sse, "nearest_sse")
    limit = _finite64(cap, "cap")
    if np.any(sse < 0):
        raise ValueError("SSE must be nonnegative")
    return np.where(nearest == 0.0, sse == 0.0,
                    sse <= limit + cap_slack(nearest, limit))


def decode(codes, scales, zeros):
    """Decode fixed FP32 metadata in FP64; no metadata recomputation."""
    q = _codes(codes)
    s = np.asarray(scales, dtype=np.float32).astype(np.float64)
    z = np.asarray(zeros, dtype=np.float32).astype(np.float64)
    if s.shape != q.shape[:-1] or z.shape != s.shape:
        raise ValueError("scales/zeros must have codes.shape[:-1]")
    if not np.all(np.isfinite(s)) or not np.all(np.isfinite(z)) or np.any(s <= 0):
        raise ValueError("invalid fixed-grid metadata")
    return s[..., None] * (q.astype(np.float64) - z[..., None])


def row_sse(V, codes, scales, zeros):
    original = _finite64(V, "V")
    reconstructed = decode(codes, scales, zeros)
    if original.shape != reconstructed.shape:
        raise ValueError("V/codes shape mismatch")
    error = reconstructed - original
    return _finite64(np.sum(error * error, axis=-1, dtype=np.float64), "row SSE")


def grid(V):
    """Freeze affine four-level metadata once from original [K,N,d] values."""
    v = _finite64(V, "V")
    if v.ndim != 3 or any(n == 0 for n in v.shape):
        raise ValueError("V must be nonempty [KV groups,tokens,channels]")
    d = v.shape[-1]
    clip_index = min(int(np.floor(0.92 * d)), d - 1)
    clip_abs = np.partition(np.abs(v), clip_index, axis=-1)[..., clip_index]
    clipped = np.clip(v, -clip_abs[..., None], clip_abs[..., None])
    low = np.min(clipped, axis=-1)
    high = np.max(clipped, axis=-1)
    scales = (np.maximum(high - low, 1e-8) / 3.0).astype(np.float32)
    zeros = (-low / scales.astype(np.float64)).astype(np.float32)
    nearest = np.clip(np.floor(v / scales.astype(np.float64)[..., None]
                               + zeros.astype(np.float64)[..., None] + 0.5),
                      0, 3).astype(np.uint8)
    nearest_sse = row_sse(v, nearest, scales, zeros)
    return {"scales": scales, "zeros": zeros, "nearest_codes": nearest,
            "nearest_sse": nearest_sse, "row_caps": CAP_MULTIPLIER * nearest_sse,
            "clip_index": clip_index, "clip_abs": clip_abs}


def _operator_inputs(P, E, W, tiny=False):
    p = _finite64(P, "P")
    e = _finite64(E, "E")
    w = _finite64(W, "W")
    if p.ndim != 4 or e.ndim != 3 or w.ndim != 4:
        raise ValueError("expected P[K,G,m,N], E[K,N,d], W[K,G,d,p]")
    K, G, m, N = p.shape
    if e.shape[:2] != (K, N) or w.shape[:3] != (K, G, e.shape[2]):
        raise ValueError("operator shape mismatch")
    if min(K, G, m, N, e.shape[2], w.shape[3]) <= 0:
        raise ValueError("empty operator")
    if tiny and (K > 2 or G > 4 or N > 8 or e.shape[2] > 8
                 or m > 4 or w.shape[3] > 12):
        raise ValueError("REFERENCE solver/design limited to declared tiny fixtures")
    return p, e, w


def head_outputs(P, E, W):
    p, e, w = _operator_inputs(P, E, W)
    # Deliberately explicit contraction order; all W entries retain their signs.
    K, G, m, _ = p.shape
    out = np.empty((K, G, m, w.shape[-1]), dtype=np.float64)
    for group in range(K):
        for head in range(G):
            out[group, head] = (p[group, head] @ e[group]) @ w[group, head]
    return out


def full_output(P, E, W):
    """Signed full-layer residual sum_{group,head} P E W, shape [m,p]."""
    return np.sum(head_outputs(P, E, W), axis=(0, 1), dtype=np.float64)


def objective_output(P, E, W, objective="full"):
    heads = head_outputs(P, E, W)
    if objective == "full":
        return np.sum(heads, axis=(0, 1), dtype=np.float64)
    if objective == "group":
        return np.sum(heads, axis=1, dtype=np.float64)
    if objective == "headwise":
        return heads
    raise ValueError("objective must be full, group, or headwise")


def loss_decomposition(P, E, W):
    heads = head_outputs(P, E, W)
    groups = np.sum(heads, axis=1, dtype=np.float64)
    full = np.sum(groups, axis=0, dtype=np.float64)
    L_head = float(np.sum(heads * heads))
    L_group = float(np.sum(groups * groups))
    L_full = float(np.sum(full * full))
    return {"headwise": L_head, "group": L_group, "full": L_full,
            "within_group_cross": L_group - L_head,
            "between_group_cross": L_full - L_group}


def _indices(indices, upper, name):
    a = np.asarray(indices)
    if a.ndim != 1 or a.size == 0 or a.dtype.kind not in "iu":
        raise ValueError(name + " must be a nonempty integer vector")
    if np.any(a < 0) or np.any(a >= upper) or len(set(a.tolist())) != a.size:
        raise ValueError(name + " contains invalid or repeated indices")
    return a.astype(np.int64)


def explicit_design(P, W, group, block_rows, block_channels, scales=None):
    """Materialize J[(query,output),(token,channel)] for ONE tiny group.

    Flattening is C order, so both sides are query/token-major. If scales is
    supplied ([K,N] or [N]), columns are code-space derivatives; else value-space.
    This intentionally forbidden-on-native-shapes oracle is independent of Grams.
    """
    p = _finite64(P, "P")
    w = _finite64(W, "W")
    if p.ndim != 4 or w.ndim != 4:
        raise ValueError("P/W rank mismatch")
    dummy = np.zeros((p.shape[0], p.shape[-1], w.shape[2]), dtype=np.float64)
    p, _, w = _operator_inputs(p, dummy, w, tiny=True)
    if not isinstance(group, (int, np.integer)) or not 0 <= group < p.shape[0]:
        raise ValueError("invalid group")
    rows = _indices(block_rows, p.shape[-1], "block_rows")
    channels = _indices(block_channels, w.shape[2], "block_channels")
    if rows.size * channels.size > 16:
        raise ValueError("explicit design is limited to 16 block variables")
    scale = np.ones(p.shape[-1], dtype=np.float64)
    if scales is not None:
        all_scales = np.asarray(scales, dtype=np.float32).astype(np.float64)
        scale = all_scales[group] if all_scales.ndim == 2 else all_scales
        if scale.shape != (p.shape[-1],) or not np.all(np.isfinite(scale)) or np.any(scale <= 0):
            raise ValueError("invalid code-space scales")
    columns = []
    for token in rows:
        for channel in channels:
            direction = np.zeros((p.shape[2], w.shape[-1]), dtype=np.float64)
            for head in range(p.shape[1]):
                direction += np.outer(p[group, head, :, token], w[group, head, channel])
            columns.append((direction * scale[token]).reshape(-1))
    return np.stack(columns, axis=1)


def exact_hg(J, residual):
    """H=J.T J and g=J.T R: gradient of SSE is 2g, Hessian is 2H."""
    design = _finite64(J, "J")
    r = _finite64(residual, "residual").reshape(-1)
    if design.ndim != 2 or design.shape[0] != r.size:
        raise ValueError("design/residual shape mismatch")
    return design.T @ design, design.T @ r


def explicit_conditional(P, V, W, current_codes, scales, zeros,
                         group, block_rows, block_channels):
    """Expose full R, other-group background, affine offset, J, H, g, q0."""
    q = _codes(current_codes)
    e = decode(q, scales, zeros) - _finite64(V, "V")
    p, e, w = _operator_inputs(P, e, W, tiny=True)
    rows = _indices(block_rows, q.shape[1], "block_rows")
    channels = _indices(block_channels, q.shape[2], "block_channels")
    J_value = explicit_design(p, w, group, rows, channels)
    J_code = explicit_design(p, w, group, rows, channels, scales)
    q0 = q[group][np.ix_(rows, channels)].reshape(-1).copy()
    R = full_output(p, e, w)
    other_error = e.copy()
    other_error[group] = 0.0
    other_group_residual = full_output(p, other_error, w)
    H, g = exact_hg(J_code, R)
    return {"J_value": J_value, "J_code": J_code, "H": H, "g": g,
            "q0": q0, "R": R, "other_group_residual": other_group_residual,
            "affine_offset": R.reshape(-1) - J_code @ q0.astype(np.float64)}


def _nearest_allowed(target, current, allowed):
    """Half-up on exact distance ties, matching clipped floor(target + .5).

    ``current`` is retained in the helper signature for the feedback call site;
    current-code tie preference applies to undamped LOSS decisions, not rounding.
    """
    allowed = np.asarray(allowed, dtype=np.int64)
    if allowed.size == 0 or not np.isfinite(target):
        raise ValueError("empty feasible set or nonfinite rounding target")
    distances = np.abs(allowed.astype(np.float64) - float(target))
    tied = allowed[distances == np.min(distances)]
    return int(np.max(tied))


def _candidate_row_sse(original_row, discrete_row, scale, zero, channel, candidate):
    """Recompute other channels rather than subtracting an old error square."""
    other = 0.0
    for c in range(original_row.size):
        if c != channel:
            error = float(scale) * (float(discrete_row[c]) - float(zero)) - float(original_row[c])
            other += error * error
    error = float(scale) * (float(candidate) - float(zero)) - float(original_row[channel])
    return other + error * error


def _proposal_loss(H, g, q0, proposal):
    delta = proposal.astype(np.float64) - q0.astype(np.float64)
    linear = float(2.0 * np.dot(delta, g))
    quadratic = float(delta @ H @ delta)
    if not np.isfinite(linear + quadratic):
        raise ValueError("nonfinite proposal loss change")
    return {"delta": delta, "linear": linear, "quadratic": quadratic,
            "loss_change": linear + quadratic,
            "tolerance": loss_tolerance(linear, quadratic)}


def conditional_block_gptq(H, g, q0, scales, zeros, origV, current_codes,
                          rowcaps, block_rows, block_channels, nearest_sse=None):
    """Two proposals for one <=16-variable block of one tiny KV group.

    scales/zeros/rowcaps/nearest_sse are [N]; origV/current_codes are [N,d].
    q0 must equal the token-major/channel-minor block of current_codes. Inputs
    are never mutated. Returned codes is the whole selected group, not all K.
    """
    h = _finite64(H, "H")
    grad = _finite64(g, "g")
    q_initial = _codes(q0, "q0").reshape(-1)
    current = _codes(current_codes).copy()
    original = _finite64(origV, "origV")
    if original.ndim != 2 or original.shape != current.shape or max(original.shape) > 8:
        raise ValueError("block reference accepts only one tiny [N,d] group")
    rows = _indices(block_rows, current.shape[0], "block_rows")
    channels = _indices(block_channels, current.shape[1], "block_channels")
    n = rows.size * channels.size
    if n > 16 or h.shape != (n, n) or grad.shape != (n,) or q_initial.shape != (n,):
        raise ValueError("conditional block shape mismatch or >16 variables")
    if not np.array_equal(q_initial, current[np.ix_(rows, channels)].reshape(-1)):
        raise ValueError("q0 must match current discrete codes")
    scales = np.asarray(scales, dtype=np.float32)
    zeros = np.asarray(zeros, dtype=np.float32)
    caps = _finite64(rowcaps, "rowcaps")
    if scales.shape != (current.shape[0],) or zeros.shape != scales.shape or caps.shape != scales.shape:
        raise ValueError("one metadata/cap entry per row required")
    if nearest_sse is None:
        near = np.clip(np.floor(original / scales.astype(np.float64)[:, None]
                                + zeros.astype(np.float64)[:, None] + 0.5), 0, 3).astype(np.uint8)
        nearest = row_sse(original, near, scales, zeros)
    else:
        nearest = _finite64(nearest_sse, "nearest_sse")
    if nearest.shape != caps.shape:
        raise ValueError("nearest_sse shape mismatch")
    if not np.all(cap_feasible(row_sse(original, current, scales, zeros), caps, nearest)):
        raise ValueError("current codes violate row caps")
    matrix_tol = TOL_MULTIPLIER * EPS64 * max(1.0, float(np.max(np.abs(h))))
    if np.max(np.abs(h - h.T)) > matrix_tol:
        raise ValueError("H is not symmetric within frozen tolerance")
    if float(np.min(np.linalg.eigvalsh(h))) < -matrix_tol:
        raise ValueError("H is not positive semidefinite within frozen tolerance")
    mu = float(np.mean(np.diag(h)))
    base = {"q0": q_initial.copy(), "mu": mu, "accepted_source": "current",
            "accepted_q": q_initial.copy(), "codes": current.copy(),
            "accepted_loss_change": 0.0, "raw": None, "cap_filtered": None,
            "M": None, "target": None, "U": None}
    if mu == 0.0:
        # Separate frozen zero-curvature consistency check; no retuning.
        zero_tol = TOL_MULTIPLIER * EPS64 * max(1.0, float(np.max(np.abs(h))))
        if np.max(np.abs(h)) > zero_tol or np.max(np.abs(grad)) > zero_tol:
            raise ValueError("zero curvature with inconsistent H or gradient")
        return {**base, "status": "zero_curvature", "zero_consistency_tolerance": zero_tol}
    if mu < 0.0:
        raise ValueError("negative mean curvature")
    if np.all(grad == 0.0):
        return {**base, "status": "zero_gradient"}
    M = h / mu + DAMPING * np.eye(n, dtype=np.float64)
    target = q_initial.astype(np.float64) - np.linalg.solve(M, grad / mu)
    # Exact pinned convention: U upper and U.T @ U = inv(M).
    U = np.linalg.cholesky(np.linalg.inv(M)).T
    if not np.all(np.isfinite(target)) or not np.all(np.isfinite(U)) or np.any(np.diag(U) <= 0):
        raise ValueError("nonfinite/invalid normalized target or inverse factor")
    coordinates = [(int(i), int(c)) for i in rows for c in channels]

    def make_proposal(filtered):
        z = target.copy()
        discrete_state = current.copy()
        proposed = np.empty(n, dtype=np.uint8)
        steps = []
        for a, (token, channel) in enumerate(coordinates):
            feasible = []
            for candidate in range(4):
                if filtered:
                    sse = _candidate_row_sse(original[token], discrete_state[token],
                                             scales[token], zeros[token], channel, candidate)
                    if not bool(cap_feasible(sse, caps[token], nearest[token])):
                        continue
                feasible.append(candidate)
            if filtered and int(q_initial[a]) not in feasible:
                raise AssertionError("remaining-current construction lost current feasibility")
            chosen = _nearest_allowed(z[a], q_initial[a], feasible)
            before = z.copy()
            error = (z[a] - chosen) / U[a, a]
            z[a:] -= error * U[a, a:]
            if not np.isfinite(error) or not np.all(np.isfinite(z)):
                raise ValueError("nonfinite feedback step")
            proposed[a] = chosen
            discrete_state[token, channel] = chosen
            steps.append({"coordinate": a, "token": token, "channel": channel,
                          "target_before": before, "target_after": z.copy(),
                          "feedback_error": float(error), "chosen": chosen,
                          "allowed_codes": tuple(feasible)})
        sse = row_sse(original, discrete_state, scales, zeros)
        feasible = bool(np.all(cap_feasible(sse, caps, nearest)))
        if filtered and not feasible:
            raise AssertionError("cap-filtered proposal failed final cap")
        return {"q": proposed, "codes": discrete_state, "row_sse": sse,
                "cap_feasible": feasible, "steps": steps,
                **_proposal_loss(h, grad, q_initial, proposed)}

    raw = make_proposal(False)
    filtered = make_proposal(True)
    best = None
    best_source = "current"
    for name, candidate in (("raw", raw), ("cap_filtered", filtered)):
        if not candidate["cap_feasible"] or candidate["loss_change"] >= -candidate["tolerance"]:
            continue
        if best is None:
            best, best_source = candidate, name
            continue
        tie_tol = max(candidate["tolerance"], best["tolerance"])
        difference = candidate["loss_change"] - best["loss_change"]
        # Current wins no-improvement ties; raw wins a raw/filtered loss tie.
        if difference < -tie_tol:
            best, best_source = candidate, name
    result = {**base, "status": "proposed", "M": M, "target": target, "U": U,
              "raw": raw, "cap_filtered": filtered, "accepted_source": best_source}
    if best is not None:
        result.update(accepted_q=best["q"].copy(), codes=best["codes"].copy(),
                      accepted_loss_change=best["loss_change"])
    return result


def naive_full_residual_cd(P, V, W, scales, zeros, current_codes, rowcaps,
                           nearest_sse=None, objective="full", coordinate_order=None):
    """One tiny reference sweep; recompute signed full residual per coordinate.

    Optional order consists of (KV group, token, channel), allowing a single
    channel/group to be compared with compact C-based updates. No real-data
    solver, convergence loop, budget-extension path, or timing claim is exposed.
    """
    original = _finite64(V, "V")
    q = _codes(current_codes).copy()
    p, _, w = _operator_inputs(P, original, W, tiny=True)
    if q.shape != original.shape:
        raise ValueError("current codes shape mismatch")
    scales = np.asarray(scales, dtype=np.float32)
    zeros = np.asarray(zeros, dtype=np.float32)
    caps = _finite64(rowcaps, "rowcaps")
    if caps.shape != original.shape[:2]:
        raise ValueError("rowcaps shape mismatch")
    if nearest_sse is None:
        near = np.clip(np.floor(original / scales.astype(np.float64)[..., None]
                                + zeros.astype(np.float64)[..., None] + 0.5), 0, 3).astype(np.uint8)
        nearest = row_sse(original, near, scales, zeros)
    else:
        nearest = _finite64(nearest_sse, "nearest_sse")
    if nearest.shape != caps.shape or not np.all(cap_feasible(row_sse(original, q, scales, zeros), caps, nearest)):
        raise ValueError("invalid nearest SSE or current row caps")
    K, N, d = q.shape
    if coordinate_order is None:
        order = [(group, token, channel) for start in range(0, d, 4)
                 for group in range(K) for channel in range(start, min(start + 4, d))
                 for token in range(N)]
    else:
        order = list(coordinate_order)
    if len(order) > K * N * d:
        raise ValueError("reference call limited to one sweep's coordinate count")
    trace = []
    for group, token, channel in order:
        if not (isinstance(group, (int, np.integer)) and isinstance(token, (int, np.integer))
                and isinstance(channel, (int, np.integer)) and 0 <= group < K
                and 0 <= token < N and 0 <= channel < d):
            raise ValueError("invalid coordinate")
        residual = objective_output(p, decode(q, scales, zeros) - original, w, objective)
        direction_error = np.zeros_like(original)
        direction_error[group, token, channel] = float(scales[group, token])
        direction = objective_output(p, direction_error, w, objective)
        H = float(np.sum(direction * direction))
        g = float(np.sum(direction * residual))
        old = int(q[group, token, channel])
        losses = np.full(4, np.inf, dtype=np.float64)
        tolerances = np.zeros(4, dtype=np.float64)
        feasible = np.zeros(4, dtype=bool)
        for code in range(4):
            sse = _candidate_row_sse(original[group, token], q[group, token],
                                     scales[group, token], zeros[group, token], channel, code)
            feasible[code] = bool(cap_feasible(sse, caps[group, token], nearest[group, token]))
            delta = float(code - old)
            linear, quadratic = 2.0 * delta * g, delta * delta * H
            tolerances[code] = loss_tolerance(linear, quadratic)
            if feasible[code]:
                losses[code] = linear + quadratic
        if not feasible[old]:
            raise AssertionError("current coordinate became infeasible")
        exact_best = int(np.argmin(losses))
        tied = [code for code in range(4) if feasible[code]
                and abs(losses[code] - losses[exact_best]) <= max(tolerances[code], tolerances[exact_best])]
        chosen = old if old in tied else min(tied)
        if chosen != old and losses[chosen] >= -tolerances[chosen]:
            chosen = old
        q[group, token, channel] = chosen
        trace.append({"group": int(group), "token": int(token), "channel": int(channel),
                      "old": old, "new": chosen, "H": H, "g": g,
                      "candidate_loss_changes": losses.copy(), "feasible": feasible.copy(),
                      "candidate_tolerances": tolerances.copy()})
    E = decode(q, scales, zeros) - original
    residual = objective_output(p, E, w, objective)
    return {"codes": q, "trace": trace, "objective": objective,
            "objective_residual": residual, "full_residual": full_output(p, E, w),
            "loss": float(np.sum(residual * residual)),
            "row_sse": row_sse(original, q, scales, zeros),
            "decomposition": loss_decomposition(p, E, w)}


def generate_fixtures():
    """Generate only the three NEW frozen-seed model-free algebra fixtures.

    The admitting runner must persist every array before tests and record its
    own source hashes and environment; this function itself performs no I/O.
    """
    specs = ((2026100541, "independent_general", 2, 8, 8, 4, 12),
             (2026100542, "sharp_signed_cancellation", 4, 8, 4, 4, 12),
             (2026100543, "uniform_orthogonal_heads", 2, 4, 4, 3, 8))
    fixtures = []
    for seed, name, G, N, d, m, outdim in specs:
        rng = np.random.default_rng(seed)
        V = rng.normal(0.0, 0.75, size=(2, N, d)).astype(np.float64)
        # Explicit non-grid interior values ensure other-group rounding error.
        for group in range(2):
            V[group, 0, :4] = (-1.25, -0.125, 0.375, 1.75)
            if d == 8:
                V[group, 0, 4:] = (-0.5, -0.25, 0.25, 0.5)
        W = rng.normal(0.0, 0.5, size=(2, G, d, outdim)).astype(np.float64)
        extras = {}
        if seed == 2026100541:
            # Two inactive exact-value keys retain mass in the denominator.
            full_probs = rng.uniform(0.05, 1.0, size=(2, G, m, N + 2))
            full_probs /= np.sum(full_probs, axis=-1, keepdims=True)
            P = full_probs[..., :N].copy()
            extras["P_full_with_two_exact_keys"] = full_probs
        elif seed == 2026100542:
            onehot = np.zeros((2, G, m, N), dtype=np.float64)
            for group in range(2):
                for head in range(G):
                    for query in range(m):
                        onehot[group, head, query, (2 * query + 3 * head + group) % N] = 1.0
            P = (1.0 - 2.0 ** -10) * onehot + (2.0 ** -10) / N
            extras["P_one_hot"] = onehot
            # Signed anti-alignment; different attentions prevent trivial cancellation.
            W[:, 1] = -0.875 * W[:, 0] + 0.0625 * W[:, 1]
            W[:, 3] = -0.75 * W[:, 2] + 0.0625 * W[:, 3]
        else:
            P = np.full((2, G, m, N), 1.0 / N, dtype=np.float64)
            # Four mutually orthogonal signed head subspaces, two dimensions each.
            W.fill(0.0)
            for group in range(2):
                for head in range(G):
                    start = 2 * (group * G + head)
                    W[group, head, :, start:start + 2] = rng.normal(0.0, 0.5, size=(d, 2))
            V[:, -1] = 0.0  # Exact zero-nearest rows exercise zero-only feasibility.
        metadata = grid(V)
        fixtures.append({"seed": seed, "name": name, "P": P, "V": V, "W": W,
                         **metadata, "current_codes": metadata["nearest_codes"].copy(),
                         "block_group": 0, "block_rows": np.arange(4, dtype=np.int64),
                         "block_channels": np.arange(4, dtype=np.int64), **extras})
    return fixtures
