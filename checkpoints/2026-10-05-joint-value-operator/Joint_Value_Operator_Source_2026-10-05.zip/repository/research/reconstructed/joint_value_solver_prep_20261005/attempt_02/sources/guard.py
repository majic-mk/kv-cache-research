"""Entry for reviewed Stage A supervision reused with strict prep caps."""
from pathlib import Path
import hashlib,json,os,signal,sys
import supervisor_core as core
ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/'prep_config.json').read_text())
def main():
    ledger=ROOT/'prep_resource_ledger.jsonl'; previous=[json.loads(x) for x in ledger.read_text().splitlines()] if ledger.exists() else []
    used=sum(x['charged_cpu_seconds'] for x in previous); remaining=120-used
    if remaining<1: raise RuntimeError('Cumulative preparation CPU authority exhausted')
    manifest=json.loads((ROOT/'FROZEN_PREP_FILES.json').read_text())
    for r in manifest['files']:
        p=ROOT/r['path']
        if hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']: raise RuntimeError('Unfrozen source '+r['path'])
    attempt=ROOT/f'attempt_{len(previous)+1:02d}'
    if attempt.exists(): raise RuntimeError('No attempt overwrite')
    attempt.mkdir(); env=os.environ.copy(); env.update(CFG['threads']); env['JV_PREP_ATTEMPT']=str(attempt)
    env['CUDA_VISIBLE_DEVICES']=''
    signal.signal(signal.SIGTERM,core.interrupted); signal.signal(signal.SIGINT,core.interrupted)
    caps={'cpu_process_tree_seconds':remaining,'wall_seconds':180,'rss_process_tree_bytes':536870912,'minimum_host_available_bytes':2000000000,'output_bytes':268435456}
    if core.host_available()<caps['minimum_host_available_bytes']: raise RuntimeError('Insufficient available memory')
    result=core.supervise([sys.executable,str(ROOT/'prep_runner.py')],attempt,env,caps,{'accept_unobservable_cgroup_ceiling':True})
    charged=result['aggregate_cpu_seconds_final']; terminal=attempt/'terminal.json'; term=json.loads(terminal.read_text()) if terminal.exists() else {}
    row={'attempt':attempt.name,'source_manifest_sha256':hashlib.sha256((ROOT/'FROZEN_PREP_FILES.json').read_bytes()).hexdigest(),'charged_cpu_seconds':charged,'cumulative_cpu_seconds':used+charged,'terminal_status':term.get('status','NO_RECEIPT'),'guard':result}
    with ledger.open('a') as f: f.write(json.dumps(row)+'\n')
    print(json.dumps(row,indent=2))
    if used+charged>120 or result['exit_code']!=0 or result['termination'] or not result['cleanup']['all_absent']: return 1
    return 0
if __name__=='__main__': sys.exit(main())
