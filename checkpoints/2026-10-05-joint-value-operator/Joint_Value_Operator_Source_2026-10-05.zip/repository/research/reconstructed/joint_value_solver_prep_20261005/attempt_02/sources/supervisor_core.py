"""Fresh one-use guard; imports no model. Sampling is not an OS RSS guarantee."""
from pathlib import Path
import ctypes, json, math, os, resource, signal, subprocess, sys, time
from supervisor_common import *
TICKS=os.sysconf('SC_CLK_TCK')

def group_processes(pgid):
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            f=(p/'stat').read_text().split(') ',1)[1].split()
            if int(f[2])!=pgid: continue
            status=(p/'status').read_text().splitlines()
            values={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in status if ':' in x}
            rows.append({'pid':int(p.name),'state':f[0],'start_ticks':int(f[19]),
                         'cpu_seconds':sum(int(f[i]) for i in (11,12,13,14))/TICKS,
                         'own_cpu_seconds':sum(int(f[i]) for i in (11,12))/TICKS,
                         'rss_bytes':int(values.get('VmRSS','0 kB').split()[0])*1024,
                         'hwm_bytes':int(values.get('VmHWM','0 kB').split()[0])*1024})
        except (OSError,ValueError,IndexError): continue
    return rows

def self_rss():
    return int(next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024

def usage_cpu(who):
    r=resource.getrusage(who); return r.ru_utime+r.ru_stime

def aggregate_cpu(members, children_baseline=0.):
    # Each live/zombie member includes its already-waited descendants. Once the
    # guard reaps that member the same usage moves to RUSAGE_CHILDREN, never both.
    return usage_cpu(resource.RUSAGE_SELF)+max(0.,usage_cpu(resource.RUSAGE_CHILDREN)-children_baseline)+sum(x['cpu_seconds'] for x in members)

def child_cpu_limit(prior, cap=240):
    return min([int(math.ceil(cap))]+[x for x in prior if x>=0])

def set_subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'Cannot become child subreaper')

def setup_child(guard_pid, cpu_cap=240):
    os.setsid()
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0: raise OSError(ctypes.get_errno(),'Cannot bind parent-death kill')
    if os.getppid()!=guard_pid: os._exit(125)
    limit=child_cpu_limit(resource.getrlimit(resource.RLIMIT_CPU),cpu_cap)
    resource.setrlimit(resource.RLIMIT_CPU,(limit,limit))

def interrupted(signum,frame): raise InterruptedError('Guard interrupted by signal '+str(signum))

def child_exited(child):
    return os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is not None

def cleanup_owned(child):
    """Kill only this session/group, then reap root and adopted descendants."""
    reaped=[]
    for sig in (signal.SIGTERM,signal.SIGKILL):
        if not any(x['state']!='Z' for x in group_processes(child.pid)): break
        try: os.killpg(child.pid,sig)
        except ProcessLookupError: pass
        time.sleep(.1)
    deadline=time.monotonic()+5
    while time.monotonic()<deadline:
        try: pid,status,usage=os.wait4(-child.pid,os.WNOHANG)
        except ChildProcessError: break
        if pid:
            reaped.append({'pid':pid,'exit_code':os.waitstatus_to_exitcode(status),'cpu_seconds':usage.ru_utime+usage.ru_stime,'max_rss_bytes':usage.ru_maxrss*1024})
            if pid==child.pid: child.returncode=os.waitstatus_to_exitcode(status)
        else: time.sleep(.01)
    return {'reaped':reaped,'live_absent':not any(x['state']!='Z' for x in group_processes(child.pid)),
            'all_absent':not group_processes(child.pid)}

def supervise(command,out,env,caps,admission_record,*,deadline=None):
    """Also exercised with dummy children in isolated temporary directories."""
    set_subreaper(); start=time.monotonic()
    deadline=deadline if deadline is not None else start+caps['wall_seconds']
    children_baseline=usage_cpu(resource.RUSAGE_CHILDREN)
    child=None; why=None; peak=0; peak_hwm=0; cpu_peak=0.; minimum=host_available(); cleanup={}
    log=(out/'runner.log').open('xb'); samples=(out/'resource_samples.jsonl').open('x',buffering=1)
    try:
        guard_pid=os.getpid()
        child=subprocess.Popen(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,
                               preexec_fn=lambda:setup_child(guard_pid,caps['cpu_process_tree_seconds']))
        while True:
            members=group_processes(child.pid)
            rss=self_rss()+sum(x['rss_bytes'] for x in members)
            peak=max(peak,rss); peak_hwm=max([peak_hwm]+[x['hwm_bytes'] for x in members])
            cpu=aggregate_cpu(members,children_baseline);cpu_peak=max(cpu_peak,cpu)
            available=host_available(); minimum=min(minimum,available); cg=cgroup_limits()
            sample={'elapsed_seconds':time.monotonic()-start,'process_tree_rss_bytes':rss,'aggregate_cpu_seconds':cpu,
                    'host_available_bytes':available,'output_bytes':evidence_bytes(out),'members':members}
            samples.write(json.dumps(sample,separators=(',',':'))+'\n')
            if time.monotonic()>=deadline: why='wall_limit'
            elif cpu>=caps['cpu_process_tree_seconds']: why='aggregate_cpu_limit'
            elif rss>caps['rss_process_tree_bytes']: why='sampled_tree_rss_limit'
            elif peak_hwm>caps['rss_process_tree_bytes']: why='child_hwm_limit'
            elif available<caps['minimum_host_available_bytes']: why='host_available_limit'
            elif evidence_bytes(out)>caps['output_bytes']-65536: why='output_limit_including_terminal_reserve'
            else:
                check_cgroups(cg,admission_record)
            if why or child_exited(child): break
            time.sleep(.05)
    except BaseException as exc: why='guard_exception:'+type(exc).__name__+':'+str(exc)
    finally:
        if child is not None: cleanup=cleanup_owned(child)
        samples.close();log.close()
    final_cpu=aggregate_cpu([],children_baseline)
    reaped_hwm=max([0]+[x['max_rss_bytes'] for x in cleanup.get('reaped',[])])
    peak_hwm=max(peak_hwm,reaped_hwm)
    if final_cpu>caps['cpu_process_tree_seconds']: why=why or 'final_aggregate_cpu_limit'
    if peak_hwm>caps['rss_process_tree_bytes']: why=why or 'final_child_hwm_limit'
    if time.monotonic()>deadline: why=why or 'final_wall_limit'
    if not cleanup.get('all_absent'): why=why or 'owned_group_cleanup_incomplete'
    if evidence_bytes(out)>caps['output_bytes']-65536: why=why or 'final_output_reserve_limit'
    result={'exit_code':None if child is None else child.returncode,'termination':why,'elapsed_seconds':time.monotonic()-start,
            'aggregate_cpu_seconds_final':final_cpu,'aggregate_cpu_seconds_sampled_peak':cpu_peak,
            'sampled_peak_process_tree_rss_bytes':peak,'child_high_water_rss_bytes':peak_hwm,
            'high_water_is_not_simultaneous_tree_peak':True,'rss_limit_is_sampled_not_os_enforced':True,
            'minimum_host_available_bytes':minimum,'cleanup':cleanup,'no_retry':True}
    before_receipt=evidence_bytes(out)
    result['final_output_bytes']=before_receipt
    while True:
        total=before_receipt+len((json.dumps(result,indent=2)+'\n').encode())
        if total==result['final_output_bytes']: break
        result['final_output_bytes']=total
    write_json(out/'guard_result.json',result)
    # Terminal check includes the receipt itself; reserved allowance bounds it.
    require(evidence_bytes(out)<=caps['output_bytes'],'Terminal evidence exceeds output cap')
    return result
