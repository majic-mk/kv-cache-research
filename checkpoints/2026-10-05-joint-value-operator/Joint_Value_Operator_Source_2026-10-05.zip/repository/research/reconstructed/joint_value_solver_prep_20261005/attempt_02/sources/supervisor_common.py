"""Resource-only support copied from reviewed Stage A, parameterized for prep."""
from pathlib import Path
import os,json
LIMITS={"cpu_process_tree_seconds":120,"wall_seconds":180,"rss_process_tree_bytes":536870912,"minimum_host_available_bytes":2000000000,"output_bytes":268435456}
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def write_json(path,value):
    with Path(path).open("x") as f: json.dump(value,f,indent=2); f.write("\n")
def host_available():
    return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def evidence_bytes(out):
    return sum(x.stat().st_size for x in out.rglob('*') if x.is_file()) if out.exists() else 0
def cgroup_limits():
    mounts=[]
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        if ' - cgroup2 ' in line:
            parts=line.split(' - ',1)[0].split(); mounts.append((Path(parts[4]),parts[3]))
    relative=next((x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')),None)
    rows=[]
    for mount, root in mounts:
        if relative is None: continue
        rel=os.path.relpath(relative, root)
        if rel.startswith('..'): continue
        leaf=mount/rel
        while True:
            row={'path':str(leaf)}
            for name in ('memory.max','memory.current','memory.high','cpu.max'):
                f=leaf/name
                if f.is_file(): row[name]=f.read_text().strip()
            rows.append(row)
            if leaf==mount or mount not in leaf.parents: break
            leaf=leaf.parent
    return {'visibility':'exposed' if any('memory.max' in x for x in rows) else 'unavailable','ancestors':rows}
def check_cgroups(cgroups, admission_record):
    if cgroups['visibility']=='unavailable':
        require(admission_record.get('accept_unobservable_cgroup_ceiling') is True,
                'Fresh root acceptance of unavailable cgroup ceiling required')
    for row in cgroups['ancestors']:
        maximum=row.get('memory.max','max')
        if maximum!='max':
            require(int(maximum)>=LIMITS['rss_process_tree_bytes'],'Exposed cgroup ceiling below preparation envelope')
            require(int(maximum)-int(row.get('memory.current','0'))>=LIMITS['minimum_host_available_bytes'], 'Exposed cgroup available capacity below floor')
