/*
 * Version 2: own C11 CPU kernels for model-free preparation.
 * Prospective change from v1: diagonal-specialized headwise CD only.
 * No BLAS, allocation, I/O, threads, model interface, or global mutable state.
 * Intended compiler flags (NOT evidence of an executed build):
 * gcc -std=c11 -O2 -fno-fast-math -ffp-contract=off -shared -fPIC kernels.c -lm
 *
 * Read KERNEL_API.md before using this ABI. Bounds are deliberately small.
 * Upper ledgers describe this source, not elapsed time or machine instructions.
 */
#include <stdint.h>
#include <stddef.h>
#include <float.h>
#include <math.h>
#include <string.h>

#define JV_MAX_N 192
#define JV_MAX_D 128
#define JV_MAX_M 16
#define JV_MAX_G 16
#define JV_MAX_K 16
#define JV_MAX_ROWS 4
#define JV_EPS (64.0 * DBL_EPSILON)
#define JV_ABI 1

enum { JV_OK=0, JV_BAD_ARGUMENT=1, JV_NONFINITE=2, JV_BAD_STATE=3,
       JV_NEGATIVE_CURVATURE=4, JV_FACTOR_FAILURE=5,
       JV_ZERO_H_NONZERO_G=6, JV_NUMERICAL_FAILURE=7 };
enum { J_MAC=0, J_MUL=1, J_ADD=2, J_DIV=3, J_SQRT=4, J_CMP=5,
       J_FLOOR=6, J_SCRATCH=7, J_DECISIONS=8, J_ACCEPTED=9,
       J_CANDIDATES=10, J_CAP_REJECTS=11, J_COMPLETED=12,
       J_STATUS=13, J_FACTOR_EXTRA=14, J_VERSION=15 };

static double jv_max(double a, double b) { return a > b ? a : b; }
static double jv_min(double a, double b) { return a < b ? a : b; }
static int jv_finite(double x) { return isfinite(x) != 0; }
static double jv_cap(double nearest) { return 1.25 * nearest; }
static double jv_cap_slack(double nearest) {
    return JV_EPS * jv_max(nearest, jv_cap(nearest));
}
static int jv_cap_ok(double sse, double nearest) {
    if (!jv_finite(sse) || sse < 0.0) return 0;
    if (nearest == 0.0) return sse == 0.0;
    return sse <= jv_cap(nearest) + jv_cap_slack(nearest);
}
static double jv_level(double scale, double zero, unsigned q) {
    return scale * ((double)q - zero);
}
static uint8_t jv_round(double z) {
    /* Clipping first avoids integer overflow for large finite targets. */
    if (z <= 0.0) return 0;
    if (z >= 3.0) return 3;
    return (uint8_t)floor(z + 0.5);
}
static uint8_t jv_feasible_round(double z,uint8_t mask) {
    int best=-1;double bestdist=INFINITY;
    for (int q=0;q<4;q++) if (mask & (uint8_t)(1u<<q)) {
        double dist=fabs(z-(double)q);
        /* Ascending order and <= give half-up ties. Outside the grid,
         * monotonic order avoids distance cancellation for huge targets. */
        if (best<0 || z>=3.0 || (z>0.0 && dist<=bestdist)) {
            best=q;bestdist=dist;
        }
    }
    return (uint8_t)best;
}

int jv_round_probe(double target,uint8_t allowed_mask,
                    uint8_t *out_raw,uint8_t *out_guard) {
    if (!out_raw || !out_guard || allowed_mask==0 || allowed_mask>15)
        return JV_BAD_ARGUMENT;
    if (!jv_finite(target)) return JV_NONFINITE;
    *out_raw=jv_round(target);*out_guard=jv_feasible_round(target,allowed_mask);
    return JV_OK;
}
static int jv_finish(uint64_t *ledger, int status) {
    if (ledger) ledger[J_STATUS]=(uint64_t)status;
    return status;
}
static int jv_block_finish(double *diag, uint64_t *ledger, int status) {
    if (diag) diag[23]=(double)status;
    return jv_finish(ledger,status);
}
static void jv_clear_ledger(uint64_t *ledger) {
    if (ledger) { memset(ledger,0,16*sizeof(*ledger)); ledger[J_VERSION]=JV_ABI; }
}

static int jv_cd_cost_bound_impl(int n,int d,int m,int G,uint64_t *ledger,
                                  int diagonal) {
    jv_clear_ledger(ledger);
    if (!ledger || n<1 || n>JV_MAX_N || d<1 || d>JV_MAX_D ||
        m<1 || m>JV_MAX_M || G<1 || G>JV_MAX_G)
        return jv_finish(ledger,JV_BAD_ARGUMENT);
    uint64_t N=(uint64_t)n,D=(uint64_t)d,T=(uint64_t)m*(uint64_t)G;
    uint64_t width=(diagonal ? 1u : (uint64_t)G);
    uint64_t dots=N*(T*width+2*T);
    ledger[J_MAC]=dots+4*N*T;
    ledger[J_MUL]=dots+N*(2*D+4*T+96)+4*(uint64_t)G*(uint64_t)G;
    ledger[J_ADD]=dots+N*(3*D+5*T+96)+4*(uint64_t)G*(uint64_t)G;
    ledger[J_CMP]=N*(3*D+T*width+4*T+128)+4*(uint64_t)G*(uint64_t)G+4*T;
    ledger[J_SCRATCH]=(uint64_t)(JV_MAX_M*JV_MAX_G*sizeof(double))+4096;
    return JV_OK;
}

int jv_cd_cost_bound(int n,int d,int m,int G,uint64_t *ledger) {
    return jv_cd_cost_bound_impl(n,d,m,G,ledger,0);
}

int jv_cd_diagonal_cost_bound(int n,int d,int m,int G,uint64_t *ledger) {
    return jv_cd_cost_bound_impl(n,d,m,G,ledger,1);
}

/* Original, unclipped values are used everywhere in the cap. */
static int jv_row_other(int row, int d, int omit, const uint8_t *codes,
                        const double *scale, const double *zero,
                        const double *v, double *sse) {
    double total=0.0;
    for (int c=0;c<d;c++) {
        size_t at=(size_t)row*(size_t)d+(size_t)c;
        if (codes[at]>3 || !jv_finite(v[at])) return JV_BAD_STATE;
        if (c==omit) continue;
        double e=jv_level(scale[row],zero[row],codes[at])-v[at];
        total += e*e;
        if (!jv_finite(total)) return JV_NONFINITE;
    }
    *sse=total;
    return JV_OK;
}

/* One channel, tokens in ascending order. Input and output must not alias. */
static int jv_cd_channel_impl(int n, int d, int m, int G, int ch,
    const double *A, const double *C, double *S, uint8_t *codes,
    const double *scale, const double *zero, const double *v,
    double *row_sse, const double *nearest_sse, double *pending,
    uint8_t *path, uint8_t *flags, double *diag, uint64_t *ledger,
    int diagonal) {
    double ac[JV_MAX_M*JV_MAX_G];
    jv_clear_ledger(ledger);
    if (!ledger || !A || !C || !S || !codes || !scale || !zero || !v ||
        !row_sse || !nearest_sse || !pending || !path || !flags || !diag ||
        n<1 || n>JV_MAX_N || d<1 || d>JV_MAX_D || m<1 || m>JV_MAX_M ||
        G<1 || G>JV_MAX_G || ch<0 || ch>=d)
        return jv_finish(ledger,JV_BAD_ARGUMENT);
    (void)jv_cd_cost_bound_impl(n,d,m,G,ledger,diagonal);
    for (int a=0;a<G;a++) for (int b=0;b<G;b++) {
        double x=C[a*G+b], y=C[b*G+a];
        if (!jv_finite(x)) return jv_finish(ledger,JV_NONFINITE);
        if (fabs(x-y)>JV_EPS*jv_max(fabs(x),fabs(y)))
            return jv_finish(ledger,JV_BAD_STATE);
        if (diagonal && a!=b && x!=0.0)
            return jv_finish(ledger,JV_BAD_STATE);
    }
    for (int t=0;t<m*G;t++)
        if (!jv_finite(S[t]) || !jv_finite(pending[t]))
            return jv_finish(ledger,JV_NONFINITE);
    for (int i=0;i<n;i++) {
        flags[i]=0; path[i]=codes[(size_t)i*d+ch];
        for (int f=0;f<6;f++) diag[(size_t)i*6+f]=0.0;
    }
    for (int i=0;i<n;i++) {
        if (!jv_finite(scale[i]) || !(scale[i]>0.0) ||
            !jv_finite(zero[i]) || !jv_finite(nearest_sse[i]) ||
            nearest_sse[i]<0.0 || !jv_finite(jv_cap(nearest_sse[i])) ||
            !jv_cap_ok(row_sse[i],nearest_sse[i]))
            return jv_finish(ledger,JV_BAD_STATE);
        size_t rowat=(size_t)i*(size_t)d+(size_t)ch;
        uint8_t old=codes[rowat];
        double other=0.0;
        int status=jv_row_other(i,d,ch,codes,scale,zero,v,&other);
        if (status) return jv_finish(ledger,status);
        double olderr=jv_level(scale[i],zero[i],old)-v[rowat];
        double old_sse=other+olderr*olderr;
        if (!jv_cap_ok(old_sse,nearest_sse[i]))
            return jv_finish(ledger,JV_BAD_STATE);
        const double *ai=A+(size_t)i*(size_t)m*(size_t)G;
        double g=0.0,h=0.0,h_abs=0.0;
        for (int t=0;t<m;t++) for (int b=0;b<G;b++) {
            double x=0.0;
            if (diagonal) {
                if (!jv_finite(ai[t*G+b])) return jv_finish(ledger,JV_NONFINITE);
                x=ai[t*G+b]*C[b*G+b];
            } else {
                for (int a=0;a<G;a++) {
                    if (!jv_finite(ai[t*G+a])) return jv_finish(ledger,JV_NONFINITE);
                    x += ai[t*G+a]*C[a*G+b];
                }
            }
            ac[t*G+b]=x;
            double h_term=ai[t*G+b]*x;
            h += h_term; h_abs += fabs(h_term);
            g += ai[t*G+b]*S[t*G+b];
        }
        if (!jv_finite(g) || !jv_finite(h) || !jv_finite(h_abs))
            return jv_finish(ledger,JV_NONFINITE);
        /* Do not clamp/rewrite curvature. A materially negative Gram stops. */
        if (h < -JV_EPS*jv_max(1.0,h_abs))
            return jv_finish(ledger,JV_NEGATIVE_CURVATURE);
        double losses[4],tols[4],sses[4],deltas[4];
        uint8_t feasible[4];
        int minq=old;
        for (int q=0;q<4;q++) {
            double e=jv_level(scale[i],zero[i],(unsigned)q)-v[rowat];
            sses[q]=other+e*e;
            feasible[q]=(uint8_t)jv_cap_ok(sses[q],nearest_sse[i]);
            deltas[q]=scale[i]*((double)q-(double)old);
            double linear=2.0*deltas[q]*g;
            double quad=(deltas[q]*deltas[q])*h;
            losses[q]=linear+quad;
            tols[q]=JV_EPS*jv_max(1.0,fabs(linear)+fabs(quad));
            if (!jv_finite(losses[q]) || !jv_finite(tols[q]) ||
                !jv_finite(sses[q])) return jv_finish(ledger,JV_NONFINITE);
            ledger[J_CANDIDATES]++;
            if (!feasible[q]) { flags[i]|=2; ledger[J_CAP_REJECTS]++; }
        }
        if (!feasible[old]) return jv_finish(ledger,JV_BAD_STATE);
        for (int q=0;q<4;q++)
            if (feasible[q] && losses[q]<losses[minq]) minq=q;
        int best=minq;
        if (fabs(losses[old]-losses[minq])<=jv_max(tols[old],tols[minq])) {
            best=old;
        } else {
            for (int q=0;q<4;q++) if (feasible[q] &&
                fabs(losses[q]-losses[minq])<=jv_max(tols[q],tols[minq])) {
                best=q; break;
            }
        }
        if (!(losses[best] < -tols[best])) best=old;
        /* Outputs for all fully completed preceding tokens survive a failure. */
        if (best!=old) {
            double delta=deltas[best];
            /* Precheck the entire update before committing this token. */
            for (int t=0;t<m*G;t++) {
                if (!jv_finite(S[t]+delta*ac[t]) ||
                    !jv_finite(pending[t]+delta*ai[t]))
                    return jv_finish(ledger,JV_NONFINITE);
            }
            for (int t=0;t<m*G;t++) {
                S[t] += delta*ac[t];
                pending[t] += delta*ai[t];
            }
            codes[rowat]=(uint8_t)best;
            flags[i]|=1; ledger[J_ACCEPTED]++;
        }
        row_sse[i]=sses[best]; path[i]=(uint8_t)best;
        double *out=diag+(size_t)i*6;
        out[0]=g;out[1]=h;out[2]=deltas[best];out[3]=losses[best];
        out[4]=sses[best];out[5]=tols[best];
        ledger[J_DECISIONS]++;ledger[J_COMPLETED]++;
    }
    return jv_finish(ledger,JV_OK);
}

int jv_cd_channel(int n,int d,int m,int G,int ch,
    const double *A,const double *C,double *S,uint8_t *codes,
    const double *scale,const double *zero,const double *v,
    double *row_sse,const double *nearest_sse,double *pending,
    uint8_t *path,uint8_t *flags,double *diag,uint64_t *ledger) {
    return jv_cd_channel_impl(n,d,m,G,ch,A,C,S,codes,scale,zero,v,row_sse,
                             nearest_sse,pending,path,flags,diag,ledger,0);
}

int jv_cd_diagonal_channel(int n,int d,int m,int G,int ch,
    const double *A,const double *C,double *S,uint8_t *codes,
    const double *scale,const double *zero,const double *v,
    double *row_sse,const double *nearest_sse,double *pending,
    uint8_t *path,uint8_t *flags,double *diag,uint64_t *ledger) {
    return jv_cd_channel_impl(n,d,m,G,ch,A,C,S,codes,scale,zero,v,row_sse,
                             nearest_sse,pending,path,flags,diag,ledger,1);
}

struct jv_block_scratch {
    double M[256],L[256],inverse[256],U[256];
    double rhs[16],solution[16],y[16],column[16],target[16],z[16];
    uint8_t work[JV_MAX_ROWS*JV_MAX_D];
    double rowtmp[JV_MAX_ROWS];
};

int jv_block_cost_bound(int k,int d,int nrows,uint64_t *ledger) {
    jv_clear_ledger(ledger);
    if (!ledger || k<1 || k>JV_MAX_K || d<1 || d>JV_MAX_D ||
        nrows<1 || nrows>JV_MAX_ROWS)
        return jv_finish(ledger,JV_BAD_ARGUMENT);
    uint64_t K=(uint64_t)k,D=(uint64_t)d,R=(uint64_t)nrows;
    uint64_t core=K*(K-1)*(K+1)/3+4*K*K*K+4*K*K;
    uint64_t row_elements=3*R*D+K*(D-1);
    ledger[J_MAC]=core;
    ledger[J_MUL]=core+2*row_elements+3*K*K+24*K+12*R+32;
    ledger[J_ADD]=core+3*row_elements+7*K*K+40*K+12*R+64;
    ledger[J_DIV]=4*K*K+8*K+4;
    ledger[J_SQRT]=2*K;
    ledger[J_CMP]=3*row_elements+20*K*K+96*K+40*R+128;
    ledger[J_FLOOR]=2*K;
    ledger[J_SCRATCH]=sizeof(struct jv_block_scratch)+4096;
    /* These non-MAC arithmetic operations are DISJOINT from core.
     * Includes normalization, inverse symmetrization, factor/solve divisions,
     * roots, residual subtraction and scale-aware residual-bound arithmetic. */
    ledger[J_FACTOR_EXTRA]=10*K*K+10*K+68;
    return JV_OK;
}

/* Lower Cholesky, reading the lower triangle. Input symmetry is checked first. */
static int jv_cholesky(int k,const double *a,double *l) {
    memset(l,0,(size_t)k*(size_t)k*sizeof(*l));
    for (int i=0;i<k;i++) for (int j=0;j<=i;j++) {
        double value=a[i*k+j];
        for (int p=0;p<j;p++) value-=l[i*k+p]*l[j*k+p];
        if (!jv_finite(value)) return JV_NONFINITE;
        if (i==j) {
            if (!(value>0.0)) return JV_FACTOR_FAILURE;
            l[i*k+j]=sqrt(value);
        } else l[i*k+j]=value/l[j*k+j];
        if (!jv_finite(l[i*k+j])) return JV_NONFINITE;
    }
    return JV_OK;
}

static int jv_chol_solve(int k,const double *l,const double *b,
                         double *y,double *x) {
    for (int i=0;i<k;i++) {
        double value=b[i];
        for (int j=0;j<i;j++) value-=l[i*k+j]*y[j];
        y[i]=value/l[i*k+i];
        if (!jv_finite(y[i])) return JV_NONFINITE;
    }
    for (int i=k-1;i>=0;i--) {
        double value=y[i];
        for (int j=i+1;j<k;j++) value-=l[j*k+i]*x[j];
        x[i]=value/l[i*k+i];
        if (!jv_finite(x[i])) return JV_NONFINITE;
    }
    return JV_OK;
}

static int jv_proposal_caps(int k,int d,int nrows,const uint8_t *proposal,
    const int32_t *vr,const int32_t *vc,const double *scale,const double *zero,
    const double *v,const uint8_t *current,const double *nearest,
    uint8_t *work,double *rowtmp,int *ok,double *excess) {
    memcpy(work,current,(size_t)nrows*(size_t)d);
    for (int a=0;a<k;a++) work[(size_t)vr[a]*d+vc[a]]=proposal[a];
    *ok=1; *excess=-INFINITY;
    for (int r=0;r<nrows;r++) {
        int st=jv_row_other(r,d,-1,work,scale,zero,v,&rowtmp[r]);
        if (st) return st;
        if (!jv_cap_ok(rowtmp[r],nearest[r])) *ok=0;
        *excess=jv_max(*excess,rowtmp[r]-jv_cap(nearest[r]));
    }
    return JV_OK;
}

static int jv_loss(int k,const double *h,const double *g,const uint8_t *q0,
                    const uint8_t *q,double *loss,double *tol) {
    double linear=0.0,quad=0.0;
    for (int a=0;a<k;a++) {
        double da=(double)q[a]-(double)q0[a];
        double lt=2.0*da*g[a];
        linear+=lt;
        for (int b=0;b<k;b++) {
            double db=(double)q[b]-(double)q0[b];
            double term=(da*h[a*k+b])*db;
            quad+=term;
        }
    }
    *loss=linear+quad;
    *tol=JV_EPS*jv_max(1.0,fabs(linear)+fabs(quad));
    return jv_finite(*loss)&&jv_finite(*tol) ? JV_OK : JV_NONFINITE;
}

/* Raw and guarded proposals share a target/factor and have separate feedback. */
int jv_projected_block(int k,int d,int nrows,const double *H,const double *g,
    const uint8_t *q0,const int32_t *var_row,const int32_t *var_ch,
    const double *scale,const double *zero,const double *v,
    const uint8_t *currentcodes,const double *row_sse,const double *nearest_sse,
    uint8_t *raw,uint8_t *guard,uint8_t *accepted,uint8_t *guard_flags,
    double *diag,double *target_out,double *factor_out,double *steps_out,
    uint64_t *ledger) {
    struct jv_block_scratch w;
    jv_clear_ledger(ledger);
    if (diag) { memset(diag,0,32*sizeof(*diag)); diag[31]=JV_ABI; }
    if (!ledger || !H || !g || !q0 || !var_row || !var_ch || !scale || !zero ||
        !v || !currentcodes || !row_sse || !nearest_sse || !raw || !guard ||
        !accepted || !guard_flags || !diag || k<1 || k>JV_MAX_K ||
        d<1 || d>JV_MAX_D || nrows<1 || nrows>JV_MAX_ROWS)
        return jv_block_finish(diag,ledger,JV_BAD_ARGUMENT);
    (void)jv_block_cost_bound(k,d,nrows,ledger);
    memcpy(raw,q0,(size_t)k);memcpy(guard,q0,(size_t)k);
    memcpy(accepted,q0,(size_t)k);memset(guard_flags,0,(size_t)k);
    memset(&w,0,sizeof(w));
    if (factor_out) memset(factor_out,0,(size_t)k*(size_t)k*sizeof(double));
    for (int a=0;a<k;a++) {
        if (var_row[a]<0 || var_row[a]>=nrows || var_ch[a]<0 || var_ch[a]>=d ||
            q0[a]>3 || currentcodes[(size_t)var_row[a]*d+var_ch[a]]!=q0[a])
            return jv_block_finish(diag,ledger,JV_BAD_STATE);
        for (int b=0;b<a;b++) if (var_row[a]==var_row[b] && var_ch[a]==var_ch[b])
            return jv_block_finish(diag,ledger,JV_BAD_STATE);
        if (!jv_finite(g[a])) return jv_block_finish(diag,ledger,JV_NONFINITE);
        diag[25]=jv_max(diag[25],fabs(g[a]));
        w.target[a]=(double)q0[a];
        if (target_out) target_out[a]=w.target[a];
    }
    if (steps_out) for (int p=0;p<2;p++) for (int a=0;a<=k;a++)
        for (int b=0;b<k;b++) steps_out[((size_t)p*(k+1)+a)*k+b]=(double)q0[b];
    for (int r=0;r<nrows;r++) {
        if (!jv_finite(scale[r]) || !(scale[r]>0.0) || !jv_finite(zero[r]) ||
            !jv_finite(nearest_sse[r]) || nearest_sse[r]<0.0 ||
            !jv_finite(jv_cap(nearest_sse[r])) ||
            !jv_cap_ok(row_sse[r],nearest_sse[r]))
            return jv_block_finish(diag,ledger,JV_BAD_STATE);
        int st=jv_row_other(r,d,-1,currentcodes,scale,zero,v,&w.rowtmp[r]);
        if (st) return jv_block_finish(diag,ledger,st);
        if (!jv_cap_ok(w.rowtmp[r],nearest_sse[r]))
            return jv_block_finish(diag,ledger,JV_BAD_STATE);
    }
    double trace=0.0;
    int all_h_zero=1;
    for (int a=0;a<k;a++) for (int b=0;b<k;b++) {
        double x=H[a*k+b];
        if (!jv_finite(x)) return jv_block_finish(diag,ledger,JV_NONFINITE);
        if (x!=0.0) all_h_zero=0;
        diag[24]=jv_max(diag[24],fabs(x));
        diag[1]=jv_max(diag[1],fabs(x-H[b*k+a]));
        if (a==b) {
            if (x<0.0) return jv_block_finish(diag,ledger,JV_NEGATIVE_CURVATURE);
            trace+=x;
        }
    }
    if (!jv_finite(trace) || !jv_finite(diag[1]))
        return jv_block_finish(diag,ledger,JV_NONFINITE);
    if (diag[1]>JV_EPS*diag[24]) return jv_block_finish(diag,ledger,JV_BAD_STATE);
    diag[0]=trace/(double)k;diag[26]=JV_EPS;
    diag[14]=1.0;diag[15]=1.0;
    if (trace==0.0) {
        if (!all_h_zero) return jv_block_finish(diag,ledger,JV_NEGATIVE_CURVATURE);
        diag[17]=1.0;
        if (diag[25]>JV_EPS) return jv_block_finish(diag,ledger,JV_ZERO_H_NONZERO_G);
        diag[16]=3.0;ledger[J_COMPLETED]=1;
        return jv_block_finish(diag,ledger,JV_OK);
    }
    if (!(diag[0]>0.0)) return jv_block_finish(diag,ledger,JV_NUMERICAL_FAILURE);
    if (diag[25]==0.0) {
        diag[16]=4.0;ledger[J_COMPLETED]=1;
        return jv_block_finish(diag,ledger,JV_OK);
    }
    double maxM=0.0,maxrhs=0.0;
    for (int a=0;a<k;a++) {
        w.rhs[a]=g[a]/diag[0];
        if (!jv_finite(w.rhs[a])) return jv_block_finish(diag,ledger,JV_NONFINITE);
        maxrhs=jv_max(maxrhs,fabs(w.rhs[a]));
        for (int b=0;b<k;b++) {
            double x=H[a*k+b]/diag[0];
            if (a==b) x+=0.01;
            w.M[a*k+b]=x;maxM=jv_max(maxM,fabs(x));
            if (!jv_finite(x)) return jv_block_finish(diag,ledger,JV_NONFINITE);
        }
    }
    int status=jv_cholesky(k,w.M,w.L);
    if (status) return jv_block_finish(diag,ledger,status);
    diag[2]=INFINITY;
    for (int a=0;a<k;a++) {
        diag[2]=jv_min(diag[2],w.L[a*k+a]);diag[3]=jv_max(diag[3],w.L[a*k+a]);
    }
    status=jv_chol_solve(k,w.L,w.rhs,w.y,w.solution);
    if (status) return jv_block_finish(diag,ledger,status);
    for (int a=0;a<k;a++) {
        w.target[a]=(double)q0[a]-w.solution[a];
        if (!jv_finite(w.target[a])) return jv_block_finish(diag,ledger,JV_NONFINITE);
        if (target_out) target_out[a]=w.target[a];
    }
    /* Invert using k unit-vector solves, then remove inversion roundoff skew. */
    for (int b=0;b<k;b++) {
        for (int a=0;a<k;a++) w.column[a]=(a==b ? 1.0 : 0.0);
        status=jv_chol_solve(k,w.L,w.column,w.y,w.z);
        if (status) return jv_block_finish(diag,ledger,status);
        for (int a=0;a<k;a++) w.inverse[a*k+b]=w.z[a];
    }
    for (int a=0;a<k;a++) for (int b=0;b<a;b++) {
        double avg=0.5*w.inverse[a*k+b]+0.5*w.inverse[b*k+a];
        if (!jv_finite(avg)) return jv_block_finish(diag,ledger,JV_NONFINITE);
        w.inverse[a*k+b]=avg;w.inverse[b*k+a]=avg;
    }
    /* U initially receives the lower Cholesky, then is transposed in place. */
    status=jv_cholesky(k,w.inverse,w.U);
    if (status) return jv_block_finish(diag,ledger,status);
    for (int a=0;a<k;a++) for (int b=0;b<a;b++) {
        w.U[b*k+a]=w.U[a*k+b];w.U[a*k+b]=0.0;
    }
    diag[4]=INFINITY;
    for (int a=0;a<k;a++) {
        diag[4]=jv_min(diag[4],w.U[a*k+a]);diag[5]=jv_max(diag[5],w.U[a*k+a]);
    }
    if (factor_out) memcpy(factor_out,w.U,(size_t)k*(size_t)k*sizeof(double));
    double maxinverse=0.0,maxsol=0.0;
    for (int a=0;a<k;a++) {
        maxsol=jv_max(maxsol,fabs(w.solution[a]));
        for (int b=0;b<k;b++) {
            maxinverse=jv_max(maxinverse,fabs(w.inverse[a*k+b]));
            double ll=0.0,mi=0.0,uu=0.0;
            for (int p=0;p<k;p++) {
                ll+=w.L[a*k+p]*w.L[b*k+p];
                mi+=w.M[a*k+p]*w.inverse[p*k+b];
                uu+=w.U[p*k+a]*w.U[p*k+b];
            }
            if (!jv_finite(ll) || !jv_finite(mi) || !jv_finite(uu))
                return jv_block_finish(diag,ledger,JV_NONFINITE);
            diag[6]=jv_max(diag[6],fabs(ll-w.M[a*k+b]));
            diag[7]=jv_max(diag[7],fabs(mi-(a==b ? 1.0 : 0.0)));
            diag[8]=jv_max(diag[8],fabs(uu-w.inverse[a*k+b]));
        }
        double mx=0.0;
        for (int p=0;p<k;p++) mx+=w.M[a*k+p]*w.solution[p];
        if (!jv_finite(mx)) return jv_block_finish(diag,ledger,JV_NONFINITE);
        diag[9]=jv_max(diag[9],fabs(mx-w.rhs[a]));
    }
    /* Fixed scale-aware backward-residual checks; no damping retry. */
    double rt=4096.0*DBL_EPSILON*(double)k;
    diag[27]=rt*jv_max(1.0,maxM);
    diag[28]=rt*jv_max(1.0,(double)k*maxM*maxinverse);
    diag[29]=rt*jv_max(1.0,maxrhs+(double)k*maxM*maxsol);
    double ut=rt*jv_max(1.0,maxinverse);
    if (!jv_finite(diag[27]) || !jv_finite(diag[28]) ||
        !jv_finite(diag[29]) || !jv_finite(ut) ||
        !jv_finite(diag[6]) || !jv_finite(diag[7]) ||
        !jv_finite(diag[8]) || !jv_finite(diag[9]) ||
        diag[6]>diag[27] || diag[7]>diag[28] || diag[8]>ut || diag[9]>diag[29])
        return jv_block_finish(diag,ledger,JV_NUMERICAL_FAILURE);
    for (int pass=0;pass<2;pass++) {
        uint8_t *proposal=(pass==0 ? raw : guard);
        memcpy(w.z,w.target,(size_t)k*sizeof(double));
        memcpy(w.work,currentcodes,(size_t)nrows*(size_t)d);
        if (steps_out) memcpy(steps_out+(size_t)pass*(k+1)*k,w.z,(size_t)k*sizeof(double));
        for (int a=0;a<k;a++) {
            uint8_t rounded=jv_round(w.z[a]),choice=rounded;
            if (pass==1) {
                int r=var_row[a],c=var_ch[a];
                double other=0.0;
                status=jv_row_other(r,d,c,w.work,scale,zero,v,&other);
                if (status) return jv_block_finish(diag,ledger,status);
                uint8_t allowed=0;
                int current_feasible=0;
                for (int q=0;q<4;q++) {
                    double e=jv_level(scale[r],zero[r],(unsigned)q)-v[(size_t)r*d+c];
                    double sse=other+e*e;
                    if (!jv_finite(sse)) return jv_block_finish(diag,ledger,JV_NONFINITE);
                    int feasible=jv_cap_ok(sse,nearest_sse[r]);
                    ledger[J_CANDIDATES]++;
                    if (q==q0[a]) current_feasible=feasible;
                    if (!feasible) {
                        ledger[J_CAP_REJECTS]++;guard_flags[a]|=8;
                        if (q==rounded) guard_flags[a]|=1;
                        continue;
                    }
                    allowed|=(uint8_t)(1u<<q);
                }
                if (!current_feasible || allowed==0)
                    return jv_block_finish(diag,ledger,JV_BAD_STATE);
                choice=jv_feasible_round(w.z[a],allowed);
                if (choice!=rounded) guard_flags[a]|=2;
                if (choice==q0[a]) guard_flags[a]|=4;
            }
            proposal[a]=choice;
            w.work[(size_t)var_row[a]*d+var_ch[a]]=choice;
            double err=(w.z[a]-(double)choice)/w.U[a*k+a];
            if (!jv_finite(err)) return jv_block_finish(diag,ledger,JV_NONFINITE);
            for (int b=a;b<k;b++) {
                w.z[b]-=err*w.U[a*k+b];
                if (!jv_finite(w.z[b])) return jv_block_finish(diag,ledger,JV_NONFINITE);
            }
            if (steps_out) memcpy(steps_out+((size_t)pass*(k+1)+a+1)*k,
                                   w.z,(size_t)k*sizeof(double));
            ledger[J_DECISIONS]++;
        }
    }
    status=jv_loss(k,H,g,q0,raw,&diag[10],&diag[12]);
    if (status) return jv_block_finish(diag,ledger,status);
    status=jv_loss(k,H,g,q0,guard,&diag[11],&diag[13]);
    if (status) return jv_block_finish(diag,ledger,status);
    int rawok=0,guardok=0;
    status=jv_proposal_caps(k,d,nrows,raw,var_row,var_ch,scale,zero,v,
                           currentcodes,nearest_sse,w.work,w.rowtmp,&rawok,&diag[21]);
    if (status) return jv_block_finish(diag,ledger,status);
    status=jv_proposal_caps(k,d,nrows,guard,var_row,var_ch,scale,zero,v,
                           currentcodes,nearest_sse,w.work,w.rowtmp,&guardok,&diag[22]);
    if (status) return jv_block_finish(diag,ledger,status);
    diag[14]=(double)rawok;diag[15]=(double)guardok;
    if (!guardok) return jv_block_finish(diag,ledger,JV_BAD_STATE);
    /* Current wins ties; raw wins a raw/guard tie. No damped loss is used. */
    int chosen=0;double bestloss=0.0,besttol=JV_EPS;
    if (rawok && diag[10]<-diag[12]) {
        chosen=1;bestloss=diag[10];besttol=diag[12];
    }
    if (guardok && diag[11]<-diag[13] &&
        diag[11]<bestloss-jv_max(besttol,diag[13])) chosen=2;
    if (chosen==1) memcpy(accepted,raw,(size_t)k);
    if (chosen==2) memcpy(accepted,guard,(size_t)k);
    diag[16]=(double)chosen;
    for (int a=0;a<k;a++) {
        if (raw[a]!=q0[a]) diag[18]+=1.0;
        if (guard[a]!=q0[a]) diag[19]+=1.0;
        if (accepted[a]!=q0[a]) { diag[20]+=1.0;ledger[J_ACCEPTED]++; }
    }
    ledger[J_COMPLETED]=1;
    return jv_block_finish(diag,ledger,JV_OK);
}
