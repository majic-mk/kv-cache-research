"""Transparent CPU operators. Pure arrays only; no model, weights, or dataset loader."""
import ctypes as ct
import math
import time
from pathlib import Path
import numpy as np
import reference as ref

U8=ct.POINTER(ct.c_uint8); D=ct.POINTER(ct.c_double); I=ct.POINTER(ct.c_int); U64=ct.POINTER(ct.c_uint64)
def ptr(a,typ=D): return a.ctypes.data_as(typ)
def f64(a): return np.ascontiguousarray(a,dtype=np.float64)

class Work:
    def __init__(self): self.rows=[]; self.macs=0; self.scalar=0; self.bytes=0; self.factor=0
    def add(self,label,macs=0,scalar=0,bytes_=0,factor=0):
        z={'label':label,'macs':int(macs),'scalar_ops':int(scalar),'logical_bytes':int(bytes_),'factor_nonmac_arithmetic':int(factor)}
        self.rows.append(z); self.macs+=z['macs']; self.scalar+=z['scalar_ops']; self.bytes+=z['logical_bytes']; self.factor+=z['factor_nonmac_arithmetic']
    @property
    def units(self): return self.macs+(self.factor+1)//2
    def mm(self,a,b,label):
        self.add(label,a.shape[0]*a.shape[1]*b.shape[1],bytes_=a.nbytes+b.nbytes+a.shape[0]*b.shape[1]*8)
        return a@b
    def summary(self): return {'macs':self.macs,'scalar_ops':self.scalar,'factor_nonmac_arithmetic':self.factor,'mac_equivalent_units':self.units,'logical_bytes':self.bytes,'events':self.rows}

class Kernels:
    def __init__(self,path):
        self.lib=ct.CDLL(str(Path(path).resolve()))
        self.lib.jv_cd_channel.restype=ct.c_int
        self.lib.jv_projected_block.restype=ct.c_int
    def cost_cd(self,n,d,m,G,diagonal=False):
        x=np.zeros(16,np.uint64)
        fn=self.lib.jv_cd_diagonal_cost_bound if diagonal else self.lib.jv_cd_cost_bound
        rc=fn(ct.c_int(n),ct.c_int(d),ct.c_int(m),ct.c_int(G),ptr(x,U64))
        if rc: raise RuntimeError('C CD cost status '+str(rc))
        return int(x[0])+(int(x[14])+1)//2
    def cost_block(self,k,d,nrows):
        x=np.zeros(16,np.uint64)
        rc=self.lib.jv_block_cost_bound(ct.c_int(k),ct.c_int(d),ct.c_int(nrows),ptr(x,U64))
        if rc: raise RuntimeError('C block cost status '+str(rc))
        return int(x[0])+(int(x[14])+1)//2
    def cd(self,A,C,S,codes,scales,zeros,V,rowerr,nearest,c,diagonal=False):
        n,m,G=A.shape; d=V.shape[1]
        U=np.zeros((m,G),dtype=np.float64); path=np.zeros(n,dtype=np.uint8)
        flags=np.zeros(n,dtype=np.uint8); diag=np.zeros((n,6),dtype=np.float64); ledger=np.zeros(16,dtype=np.uint64)
        fn=self.lib.jv_cd_diagonal_channel if diagonal else self.lib.jv_cd_channel
        ret=fn(ct.c_int(n),ct.c_int(d),ct.c_int(m),ct.c_int(G),ct.c_int(c),ptr(A),ptr(C),ptr(S),ptr(codes,U8),ptr(scales),ptr(zeros),ptr(V),ptr(rowerr),ptr(nearest),ptr(U),ptr(path,U8),ptr(flags,U8),ptr(diag),ptr(ledger,U64))
        if ret: raise RuntimeError('C CD status '+str(ret))
        return U,path,diag,ledger
    def block(self,H,g,q0,scale,zero,V,rowcodes,rowerr,nearest,varrow,varch):
        k=len(q0); nr,d=V.shape
        raw=np.zeros(k,np.uint8); guarded=raw.copy(); accepted=raw.copy(); flags=raw.copy()
        diag=np.zeros(32,np.float64); ledger=np.zeros(16,np.uint64); target=np.zeros(k); factor=np.zeros((k,k)); steps=np.zeros((2,k+1,k))
        ret=self.lib.jv_projected_block(ct.c_int(k),ct.c_int(d),ct.c_int(nr),ptr(H),ptr(g),ptr(q0,U8),ptr(varrow,I),ptr(varch,I),ptr(scale),ptr(zero),ptr(V),ptr(rowcodes,U8),ptr(rowerr),ptr(nearest),ptr(raw,U8),ptr(guarded,U8),ptr(accepted,U8),ptr(flags,U8),ptr(diag),ptr(target),ptr(factor),ptr(steps),ptr(ledger,U64))
        if ret: raise RuntimeError('C block status '+str(ret))
        return {'raw':raw,'guard':guarded,'accepted':accepted,'flags':flags,'diag':diag,'ledger':ledger,'target':target,'factor':factor,'steps':steps}

def initial_state(V,grid):
    Q=grid['nearest_codes'].copy(); E=ref.decode(Q,grid['scales'],grid['zeros'])-V
    return Q,E,np.sum(E*E,axis=2)

def residual_heads(P,E,W,work,label):
    groups,G,m,N=P.shape; p=W.shape[-1]
    R=np.empty((groups,G,m,p),np.float64)
    for g in range(groups):
        for h in range(G): R[g,h]=work.mm(work.mm(P[g,h],E[g],label+'_PE'),W[g,h],label+'_PEW')
    return R

def direct_verify(P,V,W,Q,grid,work,tracked,objective):
    E=ref.decode(Q,grid['scales'],grid['zeros'])-V
    heads=residual_heads(P,E,W,work,'final_independent_reconstruction')
    target=heads if objective=='head' else heads.sum(axis=1) if objective=='group' else heads.sum(axis=(0,1))
    err=float(np.max(np.abs(target-tracked)))
    tol=2e-10*max(1.,float(np.max(np.abs(target))))
    if err>tol: raise AssertionError(('tracked residual',objective,err,tol))
    sse=np.sum(E*E,axis=2); near=grid['nearest_sse']; cap=1.25*near
    if np.any(sse>cap+64*np.finfo(float).eps*np.maximum(near,cap)): raise AssertionError('row cap')
    if np.any(sse[near==0]!=0): raise AssertionError('zero row cap')
    return {'residual_max_error':err,'full_loss':float(np.sum(heads.sum(axis=(0,1))**2)),'head_loss':float(np.sum(heads**2)),'group_loss':float(np.sum(heads.sum(axis=1)**2))}

def cd_solve(P,V,W,grid,kernel,objective,budget=1_300_000_000,max_sweeps=100,acquisition_mac=0,force_one_sweep=False,efficient_headwise=True):
    begin=time.process_time_ns(); wall=time.perf_counter_ns(); work=Work()
    groups,G,m,N=P.shape; d=V.shape[2]; p=W.shape[-1]
    initialMAC=groups*G*(m*N*d+m*d*p)
    if acquisition_mac+2*initialMAC>budget: raise ValueError('Budget below fixed setup plus reserved verification')
    work.add('standalone_attention_acquisition',acquisition_mac)
    work.add('grid_and_nearest',scalar=groups*N*d*32,bytes_=V.nbytes*3)
    Q,E,rowerr=initial_state(V,grid)
    heads=residual_heads(P,E,W,work,'initial')
    tracked=heads.copy() if objective=='head' else heads.sum(axis=1) if objective=='group' else heads.sum(axis=(0,1))
    del heads,E
    A=[f64(P[g].transpose(2,1,0)) for g in range(groups)]
    scales=f64(grid['scales']); zeros=f64(grid['zeros']); near=f64(grid['nearest_sse'])
    paths=[]; units=0; sweeps=0; first=None; reserve=groups*G*(m*N*d+m*d*p)
    stop=False
    for sweep in range(max_sweeps):
        for c0 in range(0,d,4):
            width=min(4,d-c0)
            for g in range(groups):
                diaghead=(objective=='head' and efficient_headwise)
                upper=width*((G*p if diaghead else G*G*p)+2*m*G*p+kernel.cost_cd(N,d,m,G,diagonal=diaghead))
                if work.units+upper+reserve>budget: stop=True; break
                before_unit=work.units
                for c in range(c0,c0+width):
                    B=f64(W[g,:,c,:])
                    if diaghead:
                        C=np.diag(np.sum(B*B,axis=1)); work.add('cd_diagonal_head_gram',G*p,bytes_=B.nbytes+C.nbytes)
                    else: C=work.mm(B,B.T,'cd_head_gram')
                    if objective=='head':
                        C=np.diag(np.diag(C)); S=np.empty((m,G),np.float64)
                        for h in range(G): S[:,h]=work.mm(tracked[g,h],B[h,:,None],'cd_head_residual_projection')[:,0]
                    else:
                        R=tracked[g] if objective=='group' else tracked
                        S=work.mm(R,B.T,'cd_residual_projection')
                    S=f64(S)
                    U,path,diag,ledger=kernel.cd(A[g],C,S,Q[g],scales[g],zeros[g],V[g],rowerr[g],near[g],c,diagonal=diaghead)
                    # Named conservative charges; C kernel reports its own independent ledger as evidence.
                    work.add('cd_kernel_arithmetic_upper',macs=int(ledger[0]),factor=int(ledger[14]),scalar=int(sum(int(x) for x in ledger[1:7])),bytes_=A[g].nbytes+N*d*2+S.nbytes*2)
                    if objective=='head':
                        for h in range(G): tracked[g,h]+=work.mm(U[:,h,None],B[h,None,:],'cd_head_reconcile')
                    else:
                        delta=work.mm(U,B,'cd_reconcile')
                        if objective=='group': tracked[g]+=delta
                        else: tracked+=delta
                    paths.append((g,c,path.copy(),ledger.copy()))
                if work.units-before_unit>upper: raise AssertionError('CD unit cost bound violated')
                units+=1
            if stop: break
        if stop: break
        sweeps+=1
        if first is None: first=Q.copy()
        if force_one_sweep: break
    audit=direct_verify(P,V,W,Q,grid,work,tracked,objective)
    return {'codes':Q,'first_sweep':first,'paths':paths,'work':work.summary(),'full_sweeps':sweeps,'units':units,'audit':audit,'cpu_seconds':(time.process_time_ns()-begin)/1e9,'wall_seconds':(time.perf_counter_ns()-wall)/1e9,'complete':sweeps>=1}

def token_gptq(P,V,W,grid,budget=1_300_000_000,acquisition_mac=0):
    begin=time.process_time_ns(); wall=time.perf_counter_ns(); work=Work(); groups,G,m,N=P.shape; d=V.shape[2]
    work.add('standalone_attention_acquisition',acquisition_mac)
    work.add('grid_and_nearest',scalar=groups*N*d*32,bytes_=V.nbytes*3)
    scales=f64(grid['scales']); zeros=f64(grid['zeros']); near=grid['nearest_sse']
    reserve=groups*G*(m*N*d+m*d*W.shape[-1])
    predicted=work.units+groups*(G*m*N*N+3*N**3)+groups*d*N*(N+1)+reserve
    if predicted>budget:
        Q=grid['nearest_codes'].copy()
        return {'codes':Q,'raw_codes':Q.copy(),'first_sweep':None,'full_sweeps':0,'complete':False,'budget_blocked':True,'predicted_upper':predicted,'work':work.summary(),'audit':{},'cpu_seconds':(time.process_time_ns()-begin)/1e9,'wall_seconds':(time.perf_counter_ns()-wall)/1e9}
    factors=[]
    for group in range(groups):
        X=P[group].reshape(G*m,N); H=work.mm(X.T,X,'token_attention_gram'); mu=float(np.trace(H)/N)
        if mu==0: factors.append(None); continue
        M=H/mu+.01*np.eye(N)
        work.add('token_factor_inverse_factor_upper',macs=3*N**3,scalar=8*N*N)
        factors.append(np.linalg.cholesky(np.linalg.inv(M)).T)
    outputs=[]; fallback_count=0; tiny_trace=[]; fallback_flags=np.zeros((groups,N),np.uint8)
    for guarded in (False,True):
        Q=grid['nearest_codes'].copy()
        for group in range(groups):
            U=factors[group]
            if U is None: continue
            target=V[group].T.copy()
            for i in range(N):
                before=target.copy() if N<=8 and d<=8 else None
                fellback=False
                proposed=np.clip(np.floor(target[:,i]/scales[group,i]+zeros[group,i]+.5),0,3).astype(np.uint8)
                decoded=scales[group,i]*(proposed.astype(float)-zeros[group,i])
                err=float(np.sum((decoded-V[group,i])**2)); cap=1.25*near[group,i]
                if guarded and (err>cap+64*np.finfo(float).eps*max(cap,near[group,i]) or (near[group,i]==0 and err!=0)):
                    fallback_count+=1; fellback=True; fallback_flags[group,i]=1
                    proposed=grid['nearest_codes'][group,i].copy(); decoded=scales[group,i]*(proposed.astype(float)-zeros[group,i])
                Q[group,i]=proposed
                feedback=(target[:,i]-decoded)/U[i,i]
                target[:,i:]-=feedback[:,None]*U[i,i:][None,:]
                work.add('token_feedback',d*(N-i),scalar=d*16,bytes_=d*(N-i)*16)
                if before is not None: tiny_trace.append({'guarded':guarded,'group':group,'token':i,'fallback':fellback,'before':before,'after':target.copy(),'accepted_decoded':decoded.copy(),'Urow':U[i,i:].copy()})
        outputs.append(Q)
    E=ref.decode(outputs[1],grid['scales'],grid['zeros'])-V
    heads=residual_heads(P,E,W,work,'final_independent_reconstruction')
    err=np.sum(E*E,axis=2); cap=1.25*near
    if np.any(err>cap+64*np.finfo(float).eps*np.maximum(cap,near)): raise AssertionError('token row guard')
    if work.units>predicted or work.units>budget: raise AssertionError('Token budget bound violated')
    return {'fallback_flags':fallback_flags,'fallback_count':fallback_count,'tiny_trace':tiny_trace,'codes':outputs[1],'raw_codes':outputs[0],'first_sweep':outputs[1].copy(),'full_sweeps':1,'complete':True,'work':work.summary(),'audit':{'full_loss':float(np.sum(heads.sum(axis=(0,1))**2))},'cpu_seconds':(time.process_time_ns()-begin)/1e9,'wall_seconds':(time.perf_counter_ns()-wall)/1e9}

def blocked_solve(P,V,W,grid,kernel,budget=1_300_000_000,max_sweeps=100,acquisition_mac=0,force_one_sweep=False):
    begin=time.process_time_ns(); wall=time.perf_counter_ns(); work=Work(); groups,G,m,N=P.shape; d=V.shape[-1]; p=W.shape[-1]
    if N%4 or d%4: raise ValueError('fixed4x4 blocks require multiples of4')
    initialMAC=groups*G*(m*N*d+m*d*p); tokenGramMAC=groups*(N//4)*m*(G*4)**2
    if acquisition_mac+2*initialMAC+tokenGramMAC>budget: raise ValueError('Budget below fixed setup plus reserved verification')
    work.add('standalone_attention_acquisition',acquisition_mac); work.add('grid_and_nearest',scalar=groups*N*d*32,bytes_=V.nbytes*3)
    Q,E,rowerr=initial_state(V,grid); R=residual_heads(P,E,W,work,'initial').sum(axis=(0,1)); del E
    scales=f64(grid['scales']); zeros=f64(grid['zeros']); near=f64(grid['nearest_sse'])
    T={}
    for g in range(groups):
        for i0 in range(0,N,4):
            X=f64(P[g,:,:,i0:i0+4].transpose(1,0,2).reshape(m,G*4))
            T[g,i0]=work.mm(X.T,X,'attention_block_gram').reshape(G,4,G,4)
    reserve=groups*G*(m*N*d+m*d*p); paths=[]; sweeps=0; units=0; first=None; stop=False
    for sweep in range(max_sweeps):
        for c0 in range(0,d,4):
            channels=np.arange(c0,c0+4,dtype=np.int32)
            for g in range(groups):
                b=G*4; nblocks=N//4
                upper=b*b*p+2*m*b*p+nblocks*(256*G*G+16*m*G+m*b*b+m*G*16+kernel.cost_block(16,d,4))
                if work.units+upper+reserve>budget: stop=True; break
                before_unit=work.units
                B=f64(W[g,:,c0:c0+4,:].reshape(b,p)); C=work.mm(B,B.T,'block_weight_gram'); S=work.mm(R,B.T,'block_residual_projection'); pending=np.zeros((m,b))
                for i0 in range(0,N,4):
                    rows=np.arange(i0,i0+4); PH=f64(P[g,:,:,i0:i0+4]); HT=np.einsum('aibj,acbd->icjd',T[g,i0],C.reshape(G,4,G,4),optimize=False).reshape(16,16)
                    work.add('block_hessian_contraction',256*G*G)
                    gx=np.einsum('hti,thc->ic',PH,S.reshape(m,G,4),optimize=False).reshape(16)
                    work.add('block_gradient',16*m*G)
                    sc=np.repeat(scales[g,rows],4); H=f64(HT*sc[:,None]*sc[None,:]); grad=f64(gx*sc)
                    rowcodes=np.ascontiguousarray(Q[g,rows]); q0=np.ascontiguousarray(rowcodes[:,channels].reshape(16))
                    vr=np.repeat(np.arange(4,dtype=np.int32),4); vc=np.tile(channels,4)
                    z=kernel.block(H,grad,q0,f64(scales[g,rows]),f64(zeros[g,rows]),f64(V[g,rows]),rowcodes,f64(rowerr[g,rows]),f64(near[g,rows]),vr,vc)
                    work.add('block_factor_and_two_proposals_upper',macs=int(z['ledger'][0]),factor=int(z['ledger'][14]),scalar=int(sum(int(x) for x in z['ledger'][1:7])),bytes_=H.nbytes*5+rowcodes.nbytes*2)
                    new=z['accepted'].reshape(4,4); physical=scales[g,rows,None]*(new.astype(float)-q0.reshape(4,4).astype(float))
                    Q[g][np.ix_(rows,channels)]=new
                    Udelta=np.einsum('hti,ic->thc',PH,physical,optimize=False).reshape(m,b); work.add('block_delta_projection',m*G*4*4)
                    S+=work.mm(Udelta,C,'block_compact_update'); pending+=Udelta
                    rowerr[g,rows]=np.sum((ref.decode(Q[g,rows],scales[g,rows],zeros[g,rows])-V[g,rows])**2,axis=1)
                    work.add('block_row_guard_reconstruction',scalar=4*d*5+m*b)
                    paths.append((g,c0,i0,z['raw'].copy(),z['guard'].copy(),z['accepted'].copy(),z['diag'].copy(),z['ledger'].copy(),z['flags'].copy()))
                R+=work.mm(pending,B,'block_full_reconcile')
                if work.units-before_unit>upper: raise AssertionError('Block unit cost bound violated')
                units+=1
            if stop: break
        if stop: break
        sweeps+=1
        if first is None: first=Q.copy()
        if force_one_sweep: break
    audit=direct_verify(P,V,W,Q,grid,work,R,'full')
    return {'codes':Q,'first_sweep':first,'paths':paths,'work':work.summary(),'full_sweeps':sweeps,'units':units,'complete':sweeps>=1,'audit':audit,'cpu_seconds':(time.process_time_ns()-begin)/1e9,'wall_seconds':(time.perf_counter_ns()-wall)/1e9}
