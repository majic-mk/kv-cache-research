"""Physical split and encode-before-evaluate barrier. No model or weight loader."""
import hashlib,json
from pathlib import Path
import numpy as np
LAYERS=(0,7,14,21,28,35)
ARMS=('nearest','headwise_cd','group_joint_cd','full_joint_cd','guarded_token_gptq','projected_block_gptq')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while b:=f.read(1024*1024): h.update(b)
    return h.hexdigest()
def bf16_decode(u):
    if u.dtype!=np.dtype('<u2') or not u.flags.c_contiguous: raise ValueError('BF16 bits require little-endian uint16 C order')
    return (u.astype(np.uint32)<<16).view(np.float32).astype(np.float64)
class Reader:
    def __init__(self,root,*,synthetic=False,admission=None):
        self.root=Path(root).resolve(); self.access=[]; self.lock=None
        if not synthetic and not (admission and admission.get('scope')=='joint_value_stage_b_real' and admission.get('approved') is True):
            raise PermissionError('Fresh real Stage B admission is required before any tensor read')
    def load(self,split,layer,kind,expected_hash=None):
        if split not in ('calibration','holdout') or layer not in LAYERS or kind not in ('query','keys','values'): raise ValueError('Unexpected capture field')
        if split=='holdout' and self.lock is None: raise PermissionError('Holdout cannot be opened or hashed before all encodings lock')
        path=self.root/split/f'layer_{layer:02d}'/(kind+'.npy')
        self.access.append({'action':'open_tensor','split':split,'layer':layer,'kind':kind})
        if expected_hash and sha(path)!=expected_hash: raise ValueError('Tensor hash mismatch')
        return bf16_decode(np.load(path,allow_pickle=False))
    def lock_encodings(self,records,path):
        expected={(l,a) for l in LAYERS for a in ARMS}
        if {(r['layer'],r['arm']) for r in records}!=expected or len(records)!=len(expected): raise ValueError('Incomplete six-layer/all-arm population')
        for r in records:
            if not r['full_sweep_complete'] or not r['row_caps_verified']: raise ValueError('Incomplete or infeasible encoder')
            if sha(r['codes_path'])!=r['codes_sha256']: raise ValueError('Code manifest differs')
        p=Path(path)
        if p.exists(): raise FileExistsError('No encoding lock overwrite')
        p.write_text(json.dumps({'status':'ALL_ENCODINGS_LOCKED','records':records},indent=2)+'\n')
        self.lock=sha(p); return self.lock

def attention(q,keys,query_positions,work=None):
    """All supplied causal keys affect softmax denominator; never active-only normalize."""
    q=np.asarray(q,np.float64); keys=np.asarray(keys,np.float64); pos=np.asarray(query_positions)
    m,H,d=q.shape; N,K,dk=keys.shape
    if dk!=d or H%K or len(pos)!=m or np.any(pos<0) or np.any(pos>=N): raise ValueError('Attention shapes/positions')
    G=H//K; out=np.empty((K,G,m,N),np.float64)
    for k in range(K):
        for h in range(G):
            x=q[:,k*G+h,:]@keys[:,k,:].T/np.sqrt(d)
            x[np.arange(N)[None,:]>pos[:,None]]=-np.inf
            x-=x.max(axis=1,keepdims=True); np.exp(x,out=x); x/=x.sum(axis=1,keepdims=True)
            out[k,h]=x
    if work is not None: work.add('attention_QK',K*G*m*N*d,scalar=K*G*m*N*6,bytes_=q.nbytes+keys.nbytes+out.nbytes)
    return out

def ratio(a,b): return 1.0 if a==0 and b==0 else float('inf') if b==0 else a/b
