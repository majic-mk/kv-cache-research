# Stage B solver preparation: v2 terminal PASS

2026-10-05 UTC. Model-free engineering preparation only. No real Q/K/V or model-weight payload was read; no model ran. Real capture and operator-study admission remain separate.

## Result

The exact compact scalar-CD and projected4-by4 conditional Newton/GPTQ controls passed the explicit signed-GQA reference tests. The efficient diagonal headwise arm matches the generic headwise objective and update codes, including every196,608 decision in the native-size first sweep.

The prospectively amended common1.3-billion MAC-equivalent budget allows every required arm to complete at least one full synthetic sweep over192 tokens,128 channels and8 KV groups. The actual budget-stopping schedule was used, including additional complete units after the first sweep. All row constraints and final independently reconstructed residual checks passed.

This is solver/counter/runtime evidence, not a quality result. Synthetic calibration/holdout error values are diagnostic only. No claim about autoregressive quality, generalization, serving speedup, or a new optimization primitive follows.

## History preserved

- Attempt01: all tiny tests passed; native forecast rejected nonfinite synthetic weights caused by FP32 normalization being promoted toFP64 before bit reinterpretation. The fixture generator was corrected using in-place FP32 normalization and explicit shape/dtype/finite checks. Solver and grid were unchanged
- Attempt02/v1: all mechanics and full-sweep coverage passed, but the projected control charged1,272,733,696 units, exceeding the proposed1.2-billion allowance by72,733,696 (6.06%). This was an engineering budget-forecast mismatch, not a scientific falsification
- Root then approved the explicit pre-real-data v2 amendment to1.3 billion, common to all arms. Physical resource caps, data population, format, numerical guards and quality gates stayed unchanged
- V2 additionally implements the efficient diagonal headwise Gram/update path. Generic v1 headwise was a weaker implementation and is not the final strong matched-work control

The original proposal/config, Stage A22-file packet and v1 receipts remain byte-identical. V2_WORK_BUDGET_AMENDMENT.json binds their hashes; original sources and manifests are preserved under each attempt. No outcome from real data informed these changes.

## Tests

Three fresh fixed-seed fixtures use full signed shared-V GQA, two KV groups and nonzero background residuals. The800 recorded decision checks cover all three CD objective paths and explicit16-variable projected proposals. Additional diagonal/generic comparisons cover all tiny fixtures and the native196,608-decision first sweep.

Checks include:
- Explicit design versus compact H/g, with code-space scales and all cross-group linear terms
- Normalized damped Newton target, upper inverse-Cholesky and every feedback step
- Raw and cap-filtered proposals, remaining-current-discrete-code feasibility, undamped selection and exact compact reconciliation
- Orthogonal head subspaces, signed cancellation, exact one-hot and uniform attention
- Zero curvature, inconsistent zero-H/nonzero-g rejection, zero-nearest error and half-up rounding ties
- Token-GPTQ fallback compensation using the accepted row, while preserving its separate raw path
- Full causal softmax denominator, including available suffix keys and excluding unavailable future keys
- Zero-denominator metric handling and physical denial of future-file opening before a complete encoding lock

All tests passed. Maximum native final tracked-versus-direct residual error was2.3593e−16. This is numerical agreement on these fixtures, not a universal exact-arithmetic claim.

## Actual v2 budget stopping

One unit is one4-channel/KV-group visit. A full sweep has256 units. Token GPTQ is a fixed raw/guarded one-pass control and reports unused work.

| Arm | Completed sweeps + extra units | Charged MAC-equivalent units | Measured one-layer encoder CPU |
|---|---:|---:|---:|
| Efficient headwise CD |2 +22|1,299,791,872|0.9434s|
| Within-group joint CD |1 +204|1,298,661,376|0.3839s|
| Full-layer joint CD |1 +204|1,298,661,376|0.3634s|
| Token GPTQ, raw+guarded |1 pass|440,598,528|0.1439s|
| Projected blocked Newton/GPTQ |1 +7|1,296,711,328|2.3375s|

The charge is logical MAC upper counts, including factor dots, plus half the disjoint non-MAC factor arithmetic. Other scalar/cap/comparison/floor work and selected logical array-access bytes are separately reported. These byte ledgers describe source-level accesses, not measured memory-bus traffic or a complete allocator/serving ledger. Matching this MAC budget is not total runtime, energy or compute parity. The same kernel cost helper is used to precheck and charge each unit, and observed unit charges never exceeded its bound. Final direct residual reconstruction is reserved. Full setup and both token paths are charged.

Synthetic shape:8 KV groups,4 query heads/group,192 active tokens,128 channels,16 calibration queries,2560 output dimensions,512 prefix keys plus16 suffix keys. Values and projections are newly generated BF16-like arrays; no real model tensors enter this packet.

## CPU/RSS forecast and limits

V2 measured one-layer encoder CPU:4.1720s. Evaluation plus the second synthetic projection-file read/conversion:0.1320s. Entire synthetic-layer work:4.5598s.

Sixfold linear extrapolation of the entire synthetic-layer work is27.36 CPU seconds. This is not a measured six-layer or real-data runtime. The execution is single-threaded, fixed-order and unwarmed. Real source/header reads, file-cache behavior, interpreter startup, runtime variability, value-dependent branches and final artifact/guard work require additional reserve. No latency ranking should be inferred from the table, especially because methods complete different update counts.

Attempt03 guard receipt:
-6.2171 aggregate process-tree CPU seconds;6.0338 wall seconds
-251,338,752B sampled process-tree peak RSS;244,523,008B child high-water RSS
-62,220,765B run evidence before later source snapshots/report
-Owned process group fully reaped and absent
-No termination trigger; all caps respected

All three guarded preparation attempts together consumed12.6294 CPU seconds, below the120-second authority. No additional numerical run is planned. The reviewed supervision pattern includes guard RSS, child high-water checks, final CPU/wall/output checks, parent-death handling and kill-before-reap cleanup. Cgroup capacity remains unobservable under the explicitly accepted amendment; this is not capacity proof or an OS-enforced total-tree RSS guarantee.

Compiler: existing GCC14.2.0. Own source only, C11 -O2 -fno-fast-math -ffp-contract=off -fPIC -shared -Wall -Wextra, linked with-libm. No installation or unsafe floating-point optimization.

## Evidence and remaining release work

Current source manifest:

    f6f384d09b4090a3ff5f63376778f314415a81ef4102100c1b03090b16a2c32b

V2 amendment:

    5fdc5ea57a86f33f191938737751fee5869f3f9c0a10a9d0bced67be054440f2

Attempt03 forecast:

    2d8b9fc2c39efa41db0697d968a732de10aadcf34fe381b4678b06a5921076ac

Attempt03 unit results:

    76ef4f8ff2446e1b8e74184d96c0932896536cc4dc52cfb501c12b32c0fac876

All immutable tensor/code/result/compiler entries matched their child-manifest hashes, and pinned external metadata stayed unchanged. Guard resource logs, plus the attempt01 traceback log, continued growing after the child created its manifest; their terminal hashes are recorded separately in SAVED_VERIFICATION.json and the final delivery manifest after cleanup. The original child manifests are preserved rather than falsely reported as final log manifests. The independent reviewer's verdict remains separate.

This is a prepared solver/control library and synthetic harness, not a released real-data runner. Before real Stage B, finish the strict capture-consumer loader: mandatory Stage A COMPLETE/tensor-manifest/clean-guard checks, schema/hash/finite/position validation, and a lock binding all final codes, fixed grids, one-sweep checkpoints, work ledgers and exact source/config hashes before any future payload access. The present physical split/barrier helper has only been exercised on synthetic files and is explicitly not sufficient real-run admission. Real W_o tensor reading is not implemented or authorized here.

Any real capture or operator evaluation still needs independent final protocol/guard review and explicit root admission. The study remains an isolated-layer, reference-trajectory local-operator surrogate, not simultaneous compressed-model execution.
