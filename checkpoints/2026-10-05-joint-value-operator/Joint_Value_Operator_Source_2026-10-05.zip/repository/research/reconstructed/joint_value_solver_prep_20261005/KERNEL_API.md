# Own C CPU kernels v2: ABI and numerical contract

2026-10-05 UTC. Source preparation only. Creating these files did not compile,
execute, time, or validate the kernels. Numerical admission and an independent
tiny signed-GQA reference check remain required. These routines contain no model
loading, inference, file access, network access, allocation, BLAS, or threads.

The intended build is C11 with `-O2 -fno-fast-math -ffp-contract=off -shared
-fPIC` and the system math library (`-lm`). No package installation is required.
Fast-math, reassociation, and floating-point contraction are not permitted.
Binary64 must be IEEE-754 double with `DBL_EPSILON = 2^-52`. Use the default
round-to-nearest floating-point environment. The mathematical floor operation
is explicitly used for code rounding and is not replaced by the C rounding mode.

## Shared ABI

All exported routines return C `int`: 0 means successful completion. The status
codes are 1 invalid argument/dimension, 2 nonfinite arithmetic, 3 invalid state
(including symmetry, mapping, or row-cap failure), 4 negative curvature,
5 positive-definite factor failure, 6 exactly zero H with inconsistent g,
7 numerical residual failure. No status triggers an internal retry, damping
change, clipping of curvature, or fallback to another method.

Arrays are C-contiguous and row-major. Floating buffers are `double`;
codes/flags are `uint8_t`; coordinate maps are `int32_t`; ledgers are
`uint64_t[16]`. Set ctypes `argtypes` and `restype` explicitly. Dimensions and
indices are C `int`. All buffers are caller-owned, sized as below, writable
where applicable, and non-overlapping. There are no strides, hidden globals,
dynamic allocations, or retained pointers. Only the three explicitly optional
block diagnostic pointers may be NULL. A bad pointer or a short buffer cannot
be diagnosed by this C ABI and must be rejected by the caller.

Per-row metadata is fixed: level = scale * (code - zero), evaluated in FP64
from the supplied fixed FP32 metadata converted to double. `scale > 0` and
all data must be finite. Original V is the original, unclipped value array.
The only codes are 0, 1, 2, 3. Inputs must be a valid initialized state.

The cap is `1.25 * nearest_sse`. Positive-nearest feasibility is
`sse <= cap + 64*DBL_EPSILON*max(nearest_sse, cap)`. If nearest SSE is exactly
zero, only exactly zero SSE is feasible; there is no epsilon floor. Negative
SSE is invalid. The routines recompute cap errors from original V, rather than
subtracting a large old squared error from a tracked SSE. This recomputation is
included in the scalar arithmetic bounds. Supplied `row_sse` must itself be
finite, nonnegative, and feasible; recomputed code SSE is authoritative.

## Scalar compact CD

```c
int jv_cd_channel(
    int n, int d, int m, int G, int ch,
    const double *A, const double *C, double *S,
    uint8_t *codes, const double *scale, const double *zero,
    const double *v, double *row_sse, const double *nearest_sse,
    double *pending, uint8_t *path, uint8_t *flags,
    double *diag, uint64_t *ledger);
```

Bounds: `1<=n<=192`, `1<=d<=128`, `1<=m<=16`, `1<=G<=16`, `0<=ch<d`.

Inputs and in/out buffers:

- A `[n,m,G]`: each token's compact physical-value design
- C `[G,G]`: the corresponding output-row Gram; the headwise caller supplies
  its diagonal Gram rather than a joint Gram
- S `[m,G]`, in/out: current residual projected onto these output rows
- codes `[n,d]`, in/out: full current discrete row codes; only column ch changes
- scale, zero, nearest_sse `[n]`: fixed row metadata and fixed nearest error
- v `[n,d]`: original, unclipped values
- row_sse `[n]`, in/out: initialized current error; replaced by recomputed
  selected-code SSE for every completed token
- pending `[m,G]`, in/out: accumulated compact physical residual delta
- path `[n]`, output: selected code at each completed token
- flags `[n]`, output: bit 0 changed; bit 1 at least one candidate failed its cap
- diag `[n,6]`, output: g, h, physical delta, chosen loss delta, new row SSE,
  chosen loss tolerance
- ledger `[16]`, output: meanings below

The token order is ascending. The routine computes `AC=A_i C`,
`g=<A_i,S>`, `h=<A_i,AC>`. For every candidate q, the physical delta is
`scale[i]*(q-old_code)` and the loss is `2*delta*g + delta*delta*h`.
Candidate tolerance is exactly
`64*DBL_EPSILON*max(1,abs(2*delta*g)+abs(delta*delta*h))`.

Selection is frozen as follows: find the numerical minimum among feasible
candidates; ties to that minimum use the maximum of the two candidates'
tolerances. Keep current if it is tied; otherwise choose the lowest tied code.
An accepted non-current candidate must additionally satisfy `loss < -tol`.
For the selected change, update `S += delta*AC`, `pending += delta*A_i`,
the code, and the original-value row SSE. Precheck both entire floating updates
for finiteness before committing that token. Both precheck and commit arithmetic
are charged. No global residual reconciliation occurs inside this function:
the caller must reconcile pending changes before leaving the relevant
channel/group unit, according to its objective.

C symmetry is checked pairwise with tolerance `64*eps*max(abs(Cab),abs(Cba))`.
No symmetrization occurs. Curvature below
`-64*eps*max(1,sum(abs(A_i*AC)))` returns status 4. Roundoff-sized negative
curvature is retained as computed, never silently clamped.

If a token fails, earlier completed tokens remain committed. The entire arm
must stop; no automatic retry is permitted. `ledger[12]` is the count of fully
completed tokens. A failed token's diagnostics are not a successful result.

## Projected conditional block

```c
int jv_projected_block(
    int k, int d, int nrows,
    const double *H, const double *g, const uint8_t *q0,
    const int32_t *var_row, const int32_t *var_ch,
    const double *scale, const double *zero, const double *v,
    const uint8_t *currentcodes, const double *row_sse,
    const double *nearest_sse,
    uint8_t *raw, uint8_t *guard, uint8_t *accepted,
    uint8_t *guard_flags, double *diag,
    double *target_out, double *factor_out, double *steps_out,
    uint64_t *ledger);
```

Bounds: `1<=k<=16`, `1<=d<=128`, `1<=nrows<=4`.

- H `[k,k]`, g `[k]`: exact current conditional Hessian/gradient in code space;
  H is a Gram/PSD matrix, and g includes the current full residual/background
- q0 `[k]`: current block codes, equal to `currentcodes[var_row[a],var_ch[a]]`
- var_row, var_ch `[k]`: distinct coordinates in the stated proposal order;
  the intended 4-by-4 control uses token-major/channel-minor order
- scale, zero, row_sse, nearest_sse `[nrows]`; v, currentcodes `[nrows,d]`:
  full current rows, including unchanged channels
- raw, guard, accepted `[k]`: complete raw, cap-filtered, and accepted proposals
- guard_flags `[k]`: bit 0 unfiltered nearest code rejected by cap;
  bit 1 filtered choice differs from unfiltered nearest for that guarded
  continuous target; bit 2 filtered choice equals original q0;
  bit 3 any candidate was infeasible
- diag `[32]`: detailed fields below
- target_out `[k]`, optional: normalized conditional continuous target
- factor_out `[k,k]`, optional: upper triangular inverse-Cholesky U
- steps_out `[2,k+1,k]`, optional: initial target and full continuous state after
  every feedback step, separately for raw and guarded passes
- ledger `[16]`: detailed fields below

The function does not mutate its input state. Applying accepted codes,
updating compact S/pending, row errors, and global residual reconciliation are
the caller's responsibility. The raw proposal is a proposal at this current
accepted-state block; it is not an independent raw optimizer trajectory.

Numerics are fixed: `mu=trace(H)/k`, `M=H/mu+0.01*I`,
`target=q0-solve(M,g/mu)`. An own lower Cholesky and two triangular solves
form the target. The inverse is formed with k unit-vector solves. Tiny inversion
skew is removed by the symmetric arithmetic average of each off-diagonal pair.
Cholesky of that inverse, transposed, yields upper U with `U^T U=M^-1`.
This is inverse-Cholesky feedback, not a Cholesky of M mistaken for its inverse.

H symmetry requires `max(abs(H-H^T)) <= 64*eps*max(abs(H))`. Cholesky consumes
the lower triangle without changing H or averaging H. For symmetric-within-
roundoff inputs, any resulting difference from the full supplied M is covered
by the mandatory full-matrix residual check. Negative H diagonal is invalid.
No PSD repair, eigenvalue clipping, jitter, damping retry, or alternate solver
is used. The caller is responsible for constructing H as the stated Gram.

If trace(H) is exactly zero, all entries must be exactly zero; require
`max(abs(g)) <= 64*eps`, then keep current (path 3). A nonzero H with exactly
zero g keeps current (path 4). These early paths perform no factorization.
Nonfinite data, inconsistent zero curvature, factor failure, or excessive
residual returns nonzero and stops the arm.

Raw rounding is `clip(floor(z+0.5),0,3)`. Guarded rounding picks the closest
feasible code, with exact half ties upward, matching raw whenever all codes
are feasible. Outside [0,3], code ordering is used to avoid loss of distance
differences for very large finite targets. Feasibility uses a full discrete
row with finalized earlier choices and remaining CURRENT q0 codes. Remaining
continuous targets never enter cap state. Current q0 must remain feasible at
each step or status 3 is returned. Both passes perform the identical feedback
formula `z[a:] -= ((z[a]-q[a])/U[a,a])*U[a,a:]`, including the diagonal.

For each complete proposal, recompute all final full-row errors and evaluate
the exact undamped quadratic. Its frozen tolerance is
`64*eps*max(1,abs(sum(2*delta*g))+abs(sum(delta[a]*H[a,b]*delta[b])))`.
This is the absolute value of the summed linear and quadratic terms, not the
sum of absolute summands. An infeasible raw proposal is retained in diagnostics
but cannot be accepted. Current wins any loss tie; raw wins a raw/guard tie;
guard replaces raw only for a decrease greater than the maximum of their loss
tolerances. Every accepted non-current result is strictly better than current
under its own tolerance. Only undamped loss is used for acceptance.

### Mandatory factor residual checks

Let `r = 4096*DBL_EPSILON*k`, and all maxima below be elementwise absolute
maxima. Stop on any nonfinite value or a violation of:

- max(abs(L L^T - M)) <= r * max(1,maxM)
- max(abs(M inverse - I)) <= r * max(1,k*maxM*maxInverse)
- max(abs(U^T U - inverse)) <= r * max(1,maxInverse)
- max(abs(M solution - g/mu)) <= r * max(1,maxRhs+k*maxM*maxSolution)

These are fixed scale-aware backward-error thresholds, not a condition-number
estimate or a numerical-test receipt. The damping and Gram contract imply the
mathematical PSD bound condition(M)<=1601 at k=16; the kernel does not claim
to measure that condition number.

### Block diagnostics

Fields 0..31 respectively:

0 mu; 1 maximum H antisymmetry; 2 minimum L diagonal; 3 maximum L diagonal;
4 minimum U diagonal; 5 maximum U diagonal; 6 M-factor residual;
7 inverse residual; 8 inverse-Cholesky residual; 9 target solve residual;
10 raw loss delta; 11 guarded loss delta; 12 raw loss tolerance;
13 guarded loss tolerance; 14 raw final caps OK (0/1);
15 guarded final caps OK (0/1); 16 accepted path (0 current, 1 raw, 2 guard,
3 zero H, 4 zero g); 17 exactly zero H flag; 18 raw changed coordinates;
19 guarded changed coordinates; 20 accepted changed coordinates;
21 raw maximum row SSE minus cap; 22 guarded maximum row SSE minus cap;
23 status; 24 max abs H; 25 max abs g; 26 zero-H gradient tolerance;
27 M-factor residual tolerance; 28 inverse residual tolerance;
29 solve residual tolerance; 30 reserved zero; 31 ABI version 1.

Cap excess excludes slack, so a small positive excess may still be permitted.
Zero-H/zero-g paths initialize codes/target/steps to current, factor to zero,
caps-OK to 1, and skip unused factor/loss diagnostics, which remain zero.
On nonzero status, none of the block proposals is authorized for application.

## Ledger, cost admission, and scratch

`uint64_t ledger[16]` is:

0 logical MAC upper bound, including every dot, factor/solve dot, diagnostic
dot, and worst-case compact update arithmetic; 1 multiplication upper bound;
2 addition/subtraction upper bound; 3 division upper bound; 4 square-root
upper bound; 5 numerical comparison/predicate upper bound; 6 floor upper
bound; 7 source-level scratch payload ceiling in bytes; 8 actual sequential
decisions completed; 9 actual accepted changed coordinates; 10 actual
candidate cap tests; 11 actual candidate cap rejections; 12 fully completed
tokens (CD) or blocks (0/1); 13 status; 14 additional non-MAC factor arithmetic
upper bound; 15 ABI version 1.

Fields 0..7 and 14 are named upper bounds, not falsely labeled exact dynamic
operation counts. They are charged for the full declared call even when a
zero branch or rejection does less work. Exact event counters are 8..12.
An early failure can have partial event counts; it does not release the arm
to retry using its unused theoretical allowance.

Fields 1 and 2 INCLUDE multiplication/addition within field-0 MACs. Field 14
is a DISJOINT subset of fields 1..4, specifically factor-related operations
not already in field 0. Therefore the proposal's logical-MAC budget charge is
`ledger[0] + ceil(ledger[14]/2)`. Do not add fields 1..6 to that charge, do not
add field 0 a second time to their sum, and do not equate the charge to time.
Cap, scalar rounding/loss bookkeeping, and comparisons remain separately
reported scalar costs, as required by the proposal. The extra multiplication
per direct quadratic summand is scalar bookkeeping represented in field 1.
Callers must also charge their own array work, projections, initialization,
Gram preparation, data acquisition, reconciliation, and final verification.

The arithmetic tally counts binary64 arithmetic and numeric predicates,
including explicit finite predicates, code/cap tests, and comparisons in
min/max. It excludes address/index arithmetic, integer loop control, copies,
loads/stores, calls, counter maintenance, and implementation details of libm.
Divisions, square roots, floors, and comparisons are separately visible, not
represented as a claim about equivalent processor instructions. Memory copy
traffic and caller output/input buffers need their own live-allocation/I/O
ledger. No diagnostic output history is retained by these kernels.

The exact bound expressions used by the kernels are exported without data:

```c
int jv_cd_cost_bound(int n,int d,int m,int G,uint64_t *ledger);
int jv_block_cost_bound(int k,int d,int nrows,uint64_t *ledger);
```

They reset the full ledger, validate dimensions, and fill the same bounds as
the production call. Event counters remain zero. Use these helpers before the
next complete admitted unit; sum its calls and add caller work. There is no
separate hand-maintained forecast formula that can drift from production.

For a CD call, let T=m*G and B=n*(T*G+2*T). The dot charge plus both worst-case
update precheck and commit is B+4*n*T. Its inclusive multiplication bound is
B+n*(2*d+4*T+96)+4*G^2; addition bound is
B+n*(3*d+5*T+96)+4*G^2. Extra additive terms bound grid decoding, original-value
row scans, four candidates, tolerances, and cap validation.

For a projected block, let E=3*nrows*d+k*(d-1), representing current/final
full-row scans and guarded per-coordinate other-channel scans. Let
B=k*(k-1)*(k+1)/3+4*k^3+4*k^2. This covers both Cholesky dot loops, target and
k inverse triangular solves, three mandatory matrix-factor/inverse residual
products, the solve residual, two exact quadratic tests, and two feedback
passes. Field 0 is B. Inclusive multiplication is
B+2*E+3*k^2+24*k+12*nrows+32; inclusive additions are
B+3*E+7*k^2+40*k+12*nrows+64. The extra factor arithmetic bound in field 14
is 10*k^2+10*k+68. It covers matrix/gradient normalization, trace scaling,
inverse symmetrization, triangular divisions, roots, target formation,
residual subtraction, and residual-threshold arithmetic. This is charged in
addition to the dot budget; it does not recategorize factor dots as free.

Field 7 is fixed explicit workspace arrays plus a declared 4096-byte reserve
for scalar locals, helper locals, and call bookkeeping. CD explicit scratch
is 16*16 doubles. Block explicit scratch is the C struct containing four
16-by-16 double matrices, six length-16 double vectors, four full uint8 rows
of 128 channels, and four row SSE doubles. The struct's `sizeof` is used, so
padding is included. This is a source-level working-payload ceiling, not a
measured compiler stack frame or process RSS certificate. All caller buffers,
shared library mapping, runtime, and process-tree RSS must be accounted for
by the external guard and allocation ledger.

## Prospective v2 amendment: diagonal-specialized headwise CD

The only algorithmic source change from v1 is a diagonal-only implementation
of the same headwise scalar CD contraction. V1 is preserved at
`attempt_02/sources/kernels.c` and `attempt_02/sources/kernels_v1.c`, SHA256
`839c14047a1327c21edb8c2ca54970dfc47eaa94feb13e5b0ec089f40d562bdc`.
The projected block, rounding rules, acceptance, caps, candidate visitation,
physical grid, and all other algorithms are unchanged. ABI version remains 1:
the change adds exports without changing existing signatures or ledger fields.

The additional entry points are:

```c
int jv_cd_diagonal_channel(
    int n,int d,int m,int G,int ch,
    const double *A,const double *C,double *S,uint8_t *codes,
    const double *scale,const double *zero,const double *v,
    double *row_sse,const double *nearest_sse,double *pending,
    uint8_t *path,uint8_t *flags,double *diag,uint64_t *ledger);
int jv_cd_diagonal_cost_bound(int n,int d,int m,int G,uint64_t *ledger);
```

The array contracts are exactly the generic CD contracts, including C[G,G].
All off-diagonal C entries must be exactly zero; a nonzero off-diagonal returns
status 3. The caller constructs only the needed diagonal output-row squared
norms, rather than constructing a dense Gram and discarding its off-diagonals.
Its diagonal Gram construction is separately charged by the caller.

Generic and diagonal entry points use one shared implementation, with only
the compact AC contraction selected by a flag. The diagonal contraction is
`AC[t,b] = A_i[t,b] * C[b,b]`, without a sum over G. Subsequent h/g contractions,
candidate quadratics, code selection, row scans, S/pending updates, and path
recording are literally the same source. Matrix validation may inspect all
G-by-G C entries, but does not perform a dense contraction. For finite diagonal
C, this computes the same scalar objective and selected code path as generic
CD. Adding exact zero products in the generic contraction may differ only in
the sign of a floating zero, which does not change its numerical value or
selection. Numerical/code-path equivalence still requires the independently
admitted fixture check; this document does not claim that check was run.

Both prospective-bound and production calls invoke the same shared cost
function. Let T=m*G. For the diagonal route, replace generic
`B=n*(T*G+2*T)` by `Bdiag=n*(T+2*T)` in the inclusive multiplication/addition
formulas above. Field 0 is `Bdiag+4*n*T=7*n*T`, including worst-case update
precheck and commit. The comparison bound likewise replaces the repeated
`n*T*G` finite checks by `n*T`. Validation, cap tests, row scans, and scratch
ceilings remain charged. For each equal-sized CD call the MAC upper reduction
is exactly `n*T*(G-1)`. Use `jv_cd_diagonal_cost_bound` to admit diagonal calls;
do not use its lower bound for a generic call.

This source amendment does not authorize real-data capture or Stage B. The
parent owns prospective packet versioning, the 1.3-billion per-arm/per-layer
budget, physical process caps, fixture execution, and source hash recording.

## Shared scalar-rounding probe

```c
int jv_round_probe(double target,uint8_t allowed_mask,
                   uint8_t *out_raw,uint8_t *out_guard);
```

This uses the identical raw and feasible-rounding helpers used in production.
The nonempty 4-bit mask permits code q when bit q is set; higher bits are
invalid. It allows independent exact .5, 1.5, and 2.5 tie checks without a
factor solve perturbing the supplied target. It performs no allocation or
array access and reports nonfinite target/invalid arguments with nonzero
status. Its existence is not evidence that any such check was executed.

## Integration limits

These two routines do not implement calibration acquisition, attention,
global residual formation, cross-group reconciliation, ordinary token-axis
GPTQ, checkpointing, holdout isolation, process guards, or the entire arm
schedule. The caller must supply those explicitly. Successful kernel calls
alone establish neither a completed sweep nor a released Stage B packet.
The source and this contract must be hashed before any admitted execution;
later source changes require a new freeze and review.
