# Fresh model-free reference fixture specification

Date: 2026-10-05 UTC. Status: source preparation only. No test, model, weight payload, inference, install, or GPU execution is performed by this document or by authoring `reference.py`. These fixtures do not reuse the failed N4/D2 quality packet and cannot support a quality, robustness, novelty, runtime, or serving claim.

## Reference API

- `grid(V[K,N,d])` returns FP32 `scales[K,N]`, FP32 `zeros[K,N]`, UINT8 `nearest_codes[K,N,d]`, FP64 `nearest_sse[K,N]`, FP64 `row_caps[K,N]`, integer `clip_index`, and FP64 `clip_abs[K,N]`
- `decode(codes,scales,zeros)` and `row_sse(V,codes,scales,zeros)` accept any leading row dimensions, with metadata shape equal to `codes.shape[:-1]`
- `head_outputs(P,E,W)` has shape `[K,G,m,p]`; `full_output(P,E,W)` has shape `[m,p]`; `objective_output(..., objective='full'|'group'|'headwise')` exposes each signed objective before squaring
- `loss_decomposition(P,E,W)` returns headwise, group, full SSE and signed within-group/between-group differences
- `explicit_design(P,W,group,block_rows,block_channels,scales=None)` returns `[m*p,b]`, where `b=len(rows)*len(channels)<=16`. No scales means value-space; scales `[K,N]` or `[N]` means code-space. Rows and columns are C-order/query-major and token-major/channel-minor
- `exact_hg(J,R)` returns `H=J.T@J`, `g=J.T@R.ravel()`; the SSE gradient and Hessian are `2g` and `2H`
- `explicit_conditional(P,V,W,current_codes,scales,zeros,group,rows,channels)` returns `J_value`, `J_code`, `H`, `g`, `q0`, full `R`, `other_group_residual`, and `affine_offset=R.ravel()-J_code@q0`. For any candidate block `q`, its full residual is `affine_offset+J_code@q`
- `conditional_block_gptq(H,g,q0,scales,zeros,origV,current_codes,rowcaps,block_rows,block_channels,nearest_sse=None)` uses ONE selected group: metadata/caps `[N]`, values/codes `[N,d]`. Returns accepted whole-group `codes`, accepted block `accepted_q`, `accepted_source`, undamped accepted loss change, normalized `M`, target, upper `U`, and both `raw` and `cap_filtered` proposals with every feedback step, final row SSE, cap status, and quadratic components
- `naive_full_residual_cd(P,V,W,scales,zeros,current_codes,rowcaps,nearest_sse=None,objective='full',coordinate_order=None)` returns codes, coordinate trace, objective/full residual, objective loss, row SSE, and decomposition. An explicit order of `(group,token,channel)` tuples supports a single channel/group check. Default is one 4-channel-block/group/channel/token sweep. The full residual is independently reconstructed for every scalar decision
- `loss_tolerance`, `cap_slack`, and `cap_feasible` expose the frozen guard rules
- `generate_fixtures()` returns the three dictionaries below without filesystem or network operations

The explicit design and naive solver reject shapes larger than K=2, G=4, N=8, d=8, m=4, p=12. The block solver rejects more than 16 variables or N,d>8. There is no full-real-data solver or solver convergence loop. General grid/decode helpers allow a separate d=128 metadata audit.

## Frozen grid and floating-point conventions

Compute in FP64 from supplied original values. Symmetric clipping uses the absolute order statistic at `min(floor(.92*d),d-1)`, hence native d=128 selects index 117. Min/max are obtained after clipping. Set scale to FP32(max(clipped_max-clipped_min,1e-8)/3), then zero to FP32(-clipped_min/FP64(scale)). Decode only as FP64(scale)*(FP64(code)-FP64(zero)). Nearest is floor(original/FP64(scale)+FP64(zero)+.5), clipped to 0..3, stored UINT8. Nearest SSE is against the original, unclipped values; caps are exactly 1.25 times nearest SSE.

For a loss difference with linear and quadratic terms, the fixed absolute tolerance is `64*eps64*max(1,abs(linear)+abs(quadratic))`. Strict improvement means loss_change < -tolerance. Scalar-CD ties use the larger of the tied candidates' tolerances, keep current if tied, otherwise take the lowest code. Proposal ties use the larger proposal tolerance; current always wins a no-improvement tie, then raw wins a raw/cap-filtered tie by frozen enumeration order.

Raw and cap-filtered feedback choose the minimum absolute distance to the continuous target. Exact distance ties select the higher code, matching clipped floor(target+.5) when all four codes are feasible. There is no tolerance on these rounding-distance ties. The nearest initialization formula also rounds exact half-integers upward. This is distinct from the current-preferred/lowest-code tie rule for scalar-CD undamped LOSS decisions. This feedback convention was coordinated before execution with the compiled-kernel API.

Cap slack is `64*eps64*max(nearest_sse,cap)` with NO absolute-one floor. A row whose nearest SSE is exactly zero accepts exactly zero error only, regardless of supplied cap. All entry points reject nonfinite inputs; inconsistent shapes/codes, invalid current caps, or unexpected factorization failures stop rather than tune parameters.

For the block, use mu=mean(diag(H)), M=H/mu+.01 I, target=q0-solve(M,g/mu), and U=cholesky(inv(M)).T, satisfying U.T@U=inv(M). The feedback is z[a:] -= ((z[a]-q[a])/U[a,a])*U[a,a:]. Cap feasibility uses finalized discrete choices and unvisited CURRENT discrete codes; continuous remaining targets never enter the row state. Both proposals are evaluated by the UNDAMPED full conditional loss and final row caps. Raw proposals encountered on the accepted guarded path are diagnostics, not a separately evolved raw trajectory.

H symmetry/PSD audit tolerance is `64*eps64*max(1,max(abs(H)))`. If mu is exactly zero, both max(abs(H)) and max(abs(g)) must be <= that separately frozen zero-consistency tolerance; return current without factorization. Negative mu stops. If g is exactly zero, return current. No damping retuning, pseudoinverse, factor fallback, or silent H symmetrization exists.

## Fixed fixtures and RNG consumption

All fixtures use `numpy.random.default_rng(seed)`. The generator is the authoritative exact draw sequence; its source hash and the NumPy version must be recorded before execution. Preserve every returned ndarray, including auxiliary probabilities and fixed metadata, BEFORE algebra checks. Preserve every seed/name and shape in a JSON manifest. Default_rng cross-version identity is not assumed in place of persisted arrays.

1. Seed 2026100541, `independent_general`: K=2, G=2, N=8, d=8, m=4, p=12. Independent positive attention is normalized across N+2 keys, then restricted to N active values without renormalization. `P_full_with_two_exact_keys` retains all denominator probabilities. General signed W. This tests retained inactive-key mass and nonzero residual contributions from the other KV group
2. Seed 2026100542, `sharp_signed_cancellation`: K=2, G=4, N=8, d=4, m=4, p=12. The deterministic hot key is `(2*query+3*head+group)%N`. P is `(1-2^-10)*onehot+2^-10/N`. `P_one_hot` preserves a second, exact one-hot attention case. Heads 1 and 3 are deliberately signed anti-aligned with heads 0 and 2 with small independent components. No absolute values of W may enter an objective
3. Seed 2026100543, `uniform_orthogonal_heads`: K=2, G=2, N=4, d=4, m=3, p=8. Attention is uniform 1/N. Every query head occupies its own two-dimensional output subspace, with signed coefficients. Thus head/group/full SSE agree mathematically even with nonzero error in both groups. The last row of each V group is exactly zero, enforcing the zero-nearest/zero-error guard case

All fixtures draw V~Normal(0,.75), then explicitly place `[-1.25,-.125,.375,1.75]` in the first four channels of row 0 in BOTH groups; d=8 adds `[-.5,-.25,.25,.5]`. This guarantees nongrid interior values and nonzero other-group input error independently of chance. The full signed output background must also be checked and saved; input error alone is not a claim of nonzero output. General W is initially Normal(0,.5); the seeded transformations above follow those initial draws. Fixture 3 zeroes the initial W and then draws the disjoint two-column blocks. Exact RNG consumption is fixed in source.

Each fixture's selected block is group 0, rows [0,1,2,3], channels [0,1,2,3], yielding exactly 16 variables. Current codes start at nearest. Other unselected channels/tokens and group 1 remain in the conditional residual. For fixture 3 the zero row is intentionally part of that block.

## Required admitted tests (not executed here)

- Confirm metadata dtypes, exact nearest code formula, FP32-metadata/FP64-decode contract, native d=128 index 117, frozen caps, and zero-nearest rejection of any nonzero error
- Persist fixture arrays; verify both groups' errors and selected group's other-group OUTPUT residual are nonzero
- Materialize the 16-column J for each default attention and the exact-one-hot alternative. Compare independent compact H/g against J.T@J and J.T@full_R with all current groups included. Verify code scales on BOTH Hessian axes and the gradient axis
- For several fixed code deltas, compare direct full residual SSE difference with `2*delta.T@g+delta.T@H@delta`, including an unchanged delta and a changed-other-group background
- Compare normalized target with `q0-solve(H+.01*mu*I,g)`; compare U.T@U with inv(M); verify every raw and cap-filtered feedback update against the recorded pre-update z and U row
- Reconstruct each cap-filtered prefix using finalized coordinates plus remaining CURRENT codes. Confirm current feasibility at every coordinate, final row caps, exact zero-error row behavior, and the accepted strict UNDAMPED loss change. Save both proposals and all guard choices
- Compare compact CD decisions/codes/residuals with naive full-residual CD for one channel/group and one full fixture sweep, under full, group, and headwise objectives
- Verify orthogonal-head head/group/full losses agree. Record signed within-/between-group differences for general and anti-aligned W without asserting their signs in advance
- Explicit zero-H/zero-g, zero-H/nonzero-g, exact zero-gradient, nonfinite, invalid-cap, and exact rounding-tie cases must exercise stop/keep behavior; failed algebra checks stop this preparation packet

These are algebra/reconstruction checks only. No heldout or natural-tensor quality gate is run. No runtime measured on these tiny references predicts the proposed native Stage B implementation.
