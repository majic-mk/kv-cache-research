"""Fresh claim/configuration wrapper around byte-identical reviewed Stage A guard."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'reviewed_supervisor'))
import common
import guard as core


def checked_json(path):
    return json.loads(Path(path).read_text())


def check_pin(path, record):
    p = Path(path)
    common.require(p.stat().st_size == record['bytes'], 'Pinned size changed: ' + str(p))
    common.require(hashlib.sha256(p.read_bytes()).hexdigest() == record['sha256'],
                   'Pinned hash changed: ' + str(p))


def main():
    common.require(__debug__, 'Optimized Python forbidden')
    preflight = time.monotonic()
    cfg = checked_json(HERE / 'CONFIG.json')
    caps = cfg['limits']
    common.require(caps == {'cpu_process_tree_seconds': 30, 'wall_seconds': 90,
                           'rss_process_tree_bytes': 268435456, 'minimum_host_available_bytes': 2000000000,
                           'output_bytes': 8388608}, 'Exact hash-pass caps required')
    # Same shared dictionary used by the unchanged imported Stage A checks.
    common.LIMITS.clear()
    common.LIMITS.update(caps)
    common.require(Path(sys.executable).resolve() == Path(cfg['python']), 'Pinned interpreter')
    manifest_path = HERE / 'FROZEN_FILES.json'
    manifest = checked_json(manifest_path)
    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    for row in manifest['files']:
        check_pin(HERE / row['path'], row)
    for row in checked_json(HERE / 'EXPECTED_PINS.json')['source_pins']:
        check_pin(row['path'], row)
    admission = checked_json(HERE / 'ADMISSION.json')
    common.require(admission.get('decision') == 'ADMIT_ONE_W_SEGMENT_PROVENANCE_PASS', 'Exact admission')
    common.require(admission.get('packet_manifest_sha256') == digest, 'Admission packet hash')
    common.require(admission.get('review_accepted') is True and admission.get('parent_authorized') is True,
                   'Independent review and root authority required')
    common.require(admission.get('limits') == caps and admission.get('max_runs') == 1, 'Bounded one-pass admission')
    common.require(admission.get('accept_unobservable_cgroup_ceiling') is True, 'Fresh cgroup acceptance')
    review = Path(admission['review_path'])
    common.require(hashlib.sha256(review.read_bytes()).hexdigest() == admission['review_sha256'], 'Review pin')
    out = Path(cfg['output_directory'])
    common.require(not out.exists(), 'Output directory already exists; no retry')
    common.require(not (HERE / 'RUN_CLAIM.json').exists(), 'One-use claim already consumed')
    common.require(core.host_available() >= caps['minimum_host_available_bytes'], 'Host available below 2GB')
    common.require(shutil.disk_usage(HERE).free >= caps['output_bytes'], 'Insufficient evidence disk reserve')
    inherited = {name: list(resource.getrlimit(getattr(resource, name))) for name in
                 ('RLIMIT_CPU', 'RLIMIT_AS', 'RLIMIT_DATA', 'RLIMIT_FSIZE')}
    for name in ('RLIMIT_AS', 'RLIMIT_DATA'):
        finite = [v for v in inherited[name] if v >= 0]
        common.require(not finite or min(finite) >= caps['rss_process_tree_bytes'], 'Inherited memory limit below envelope')
    cgroups = core.cgroup_limits()
    core.check_cgroups(cgroups, admission)
    signal.signal(signal.SIGTERM, core.interrupted)
    signal.signal(signal.SIGINT, core.interrupted)
    common.write_json(HERE / 'RUN_CLAIM.json', {
        'packet_manifest_sha256': digest, 'max_runs': 1, 'guard_pid': os.getpid(),
        'started_utc_epoch': time.time(), 'scope': cfg['scope'], 'no_retry': True})
    out.mkdir()
    deadline = time.monotonic() + caps['wall_seconds']
    common.write_json(out / 'launch.json', {
        'packet_manifest_sha256': digest, 'limits': caps, 'source_admission': admission,
        'inherited_limits': inherited, 'cgroups': cgroups,
        'cgroup_unknown_is_not_capacity_proof': True, 'guard_pid': os.getpid(),
        'deadline_monotonic': deadline, 'metadata_only_preflight_seconds': time.monotonic() - preflight,
        'wall_deadline_scope': 'After metadata-only preflight; CPU includes entire guard process',
        'supervisor_source': 'Byte-identical reviewed Stage A guard.py and common.py; only runtime LIMITS configured'})
    env = dict(os.environ, JV_W_HASH_GUARD_PID=str(os.getpid()), JV_W_HASH_ONCE='PROVENANCE_ONLY',
               CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               PYTHONDONTWRITEBYTECODE='1')
    result = core.supervise([cfg['python'], '-B', str(HERE / 'verifier.py')],
                            out, env, caps, admission, deadline=deadline)
    common.require(result['exit_code'] == 0 and result['termination'] is None and
                   result['cleanup']['all_absent'], 'Provenance pass failed; no retry')
    candidate = checked_json(out / 'W_SEGMENTS_CANDIDATE.json')
    common.require(candidate['status'] == 'ALL_HASHES_VERIFIED_PENDING_CLEAN_SUPERVISOR_RECEIPT', 'Missing hashes')
    candidate.update(status='VERIFIED', all_shard_hashes_verified=True,
                     segments_hashed_from_same_full_shard_pass=True)
    candidate['provenance'].update({
        'packet_manifest_sha256': digest,
        'guard_result_path': str(out / 'guard_result.json'),
        'guard_result_sha256': hashlib.sha256((out / 'guard_result.json').read_bytes()).hexdigest(),
        'clean_supervisor_receipt_verified_before_publication': True})
    common.require(time.monotonic() <= deadline, 'Final publication wall cap')
    common.require(core.aggregate_cpu([]) <= caps['cpu_process_tree_seconds'], 'Final publication CPU cap')
    common.require(core.host_available() >= caps['minimum_host_available_bytes'], 'Final host floor')
    core.check_cgroups(core.cgroup_limits(), admission)
    common.write_json(out / 'W_SEGMENTS_VERIFIED.json', candidate)
    pins_sha256 = hashlib.sha256((out / 'W_SEGMENTS_VERIFIED.json').read_bytes()).hexdigest()
    final_cpu = core.aggregate_cpu([])
    final_wall = time.monotonic() - (deadline - caps['wall_seconds'])
    final_self_hwm = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    final_host = core.host_available()
    final_cgroups = core.cgroup_limits()
    common.require(final_cpu <= caps['cpu_process_tree_seconds'], 'Post-publication CPU cap')
    common.require(final_wall <= caps['wall_seconds'], 'Post-publication wall cap')
    common.require(final_self_hwm <= caps['rss_process_tree_bytes'], 'Post-publication supervisor high-water RSS cap')
    common.require(final_host >= caps['minimum_host_available_bytes'], 'Post-publication host floor')
    core.check_cgroups(final_cgroups, admission)
    finalization = {
        'status': 'VERIFIED_PUBLISHED_WITHIN_FINAL_CAPS', 'no_retry': True,
        'packet_manifest_sha256': digest, 'pins_sha256': pins_sha256,
        'guard_sha256': candidate['provenance']['guard_result_sha256'],
        'aggregate_cpu_seconds_after_publication': final_cpu,
        'elapsed_seconds_after_publication': final_wall,
        'supervisor_high_water_rss_bytes_after_publication': final_self_hwm,
        'host_available_bytes_after_publication': final_host,
        'cgroups_after_publication': final_cgroups,
        'cleanup_all_absent': result['cleanup']['all_absent'],
        'final_output_bytes_including_this_receipt': 0,
        'measurement_scope': 'After verified pins publication; final output includes this terminal receipt',
    }
    existing_bytes = core.evidence_bytes(out)
    while True:
        total = existing_bytes + len((json.dumps(finalization, indent=2) + '\n').encode())
        if total == finalization['final_output_bytes_including_this_receipt']:
            break
        finalization['final_output_bytes_including_this_receipt'] = total
    common.require(total <= caps['output_bytes'], 'Final output cap including finalization reserve')
    common.write_json(out / 'FINALIZATION.json', finalization)
    # Terminal checks include the receipt write; no more files follow.
    common.require(core.evidence_bytes(out) == total <= caps['output_bytes'], 'Terminal output cap')
    common.require(core.aggregate_cpu([]) <= caps['cpu_process_tree_seconds'], 'Terminal CPU cap')
    common.require(time.monotonic() <= deadline, 'Terminal wall cap')
    common.require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 <= caps['rss_process_tree_bytes'],
                   'Terminal supervisor high-water RSS cap')
    common.require(core.host_available() >= caps['minimum_host_available_bytes'], 'Terminal host floor')
    core.check_cgroups(core.cgroup_limits(), admission)
    print(json.dumps({'status': 'VERIFIED', 'pins_path': str(out / 'W_SEGMENTS_VERIFIED.json'),
                      'pins_sha256': pins_sha256,
                      'guard_sha256': candidate['provenance']['guard_result_sha256'],
                      'finalization_sha256': hashlib.sha256((out / 'FINALIZATION.json').read_bytes()).hexdigest(),
                      'full_shard_logical_read_bytes': 8044982000}, indent=2))


if __name__ == '__main__':
    main()
