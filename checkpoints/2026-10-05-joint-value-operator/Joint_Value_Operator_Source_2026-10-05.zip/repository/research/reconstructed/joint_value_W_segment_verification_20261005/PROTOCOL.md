# One-pass public checkpoint provenance verification

This packet authorizes no model inference, tensor-value decoding, optimization,
holdout access, GPU, download, installation, public action, or user-data change.
After an independent source PASS, exactly one execution may sequentially hash
the three existing Qwen/Qwen3-4B-Instruct-2507 shards at revision
cdbee75f17c01a7cc42f958dc650907174af0554. The existing full-shard SHA256, size,
raw JSON header SHA256 (excluding the initial eight-byte length), selected key,
shape, dtype and relative data offsets are bound before execution.

Exact logical model-file read charge is 8,044,982,000 bytes. Six W_o ranges at
layers 0,7,14,21,28,35 are each 20,971,520 bytes. Their aggregate hash input is
125,829,120 bytes, a subset of the full stream, requiring zero additional reads.
Shards are opened once each using unbuffered sequential reads. Full and range
hashes consume the same byte buffer. No numerical tensor payload is decoded,
copied to files, or retained after the stream; transient read buffer is 1 MiB.
Stat/link/descriptor identity is checked before and after every shard; access
time is intentionally excluded because reading can change it. Whole-shard
SHA256 and header pins provide content identity in addition to the stat checks.

The independently reviewed Stage A guard.py and common.py are copied unchanged.
Only their shared runtime LIMITS dictionary is configured downward. No Stage A
main, metadata_integrity, packet_integrity, admission or model code is called.
The wrapper checks frozen small-file/source pins, fresh review/admission,
inherited limits, host floor and cgroups, then consumes an exclusive new claim.
The claim remains consumed on any later failure. There is no automatic rerun.

Limits are 30 aggregate tree CPU seconds, 90 wall seconds, 256 MiB sampled tree
RSS, host available memory at least 2,000,000,000 bytes, and 8 MiB evidence. The
unchanged supervisor owns a fresh process group, inherits/tightens CPU limits,
uses parent-death kill and child-subreaper cleanup, samples resources, and reaps
its children. RSS sampling is not an OS-enforced tree RSS guarantee. Unavailable
cgroup visibility has fresh root acceptance for this narrow pass only and is
not a capacity proof. Metadata-only preflight is excluded from wall deadline;
CPU includes the entire wrapper process. This is provenance work, not a model
quality or resource-capacity experiment.

The worker writes a candidate metadata receipt. Only after a clean guard result
(exit 0, termination null, all owned processes absent) does the wrapper publish
W_SEGMENTS_VERIFIED.json with the two success booleans and guard-result digest.
Consumers must separately bind the final pins digest and clean guard digest.
The guard output-size receipt predates this final small publication; the wrapper
checks CPU, wall, self high-water RSS, host, cgroup and output after publication.
FINALIZATION.json binds the verified pins and immutable guard digests, records
these final measurements and exact total output including its own bytes. All
caps are checked once more after this terminal receipt is written. Consumers
must also require this finalization receipt and a successful launcher exit.
Frozen Stage A/Stage B sources and all original model files remain unchanged.
