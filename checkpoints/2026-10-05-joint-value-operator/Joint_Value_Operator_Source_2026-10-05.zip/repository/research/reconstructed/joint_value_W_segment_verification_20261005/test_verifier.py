"""Synthetic byte fixtures only. Never access the model checkpoint."""
from pathlib import Path
import hashlib
import json
import tempfile
import unittest
from unittest import mock

import verifier


class StreamTests(unittest.TestCase):
    def fixture(self, root):
        payload = bytes(range(113))
        spans = [('first', 0, 13), ('middle', 17, 81), ('last', 99, 113)]
        header = {key: {'dtype': 'U8', 'shape': [end - start], 'data_offsets': [start, end]}
                  for key, start, end in spans}
        raw = json.dumps(header, separators=(',', ':')).encode()
        blob = len(raw).to_bytes(8, 'little') + raw + payload
        target = root / 'public_test_bytes'
        target.write_bytes(blob)
        path = root / 'shard.test'
        path.symlink_to(target)
        shard = {'path': str(path), 'resolved_path': str(target.resolve()), 'shard': path.name,
                 'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(),
                 'header_bytes': len(raw), 'header_sha256': hashlib.sha256(raw).hexdigest(),
                 'tensor_count': len(spans), 'payload_bytes': len(payload)}
        segments = [{'layer': i, 'key': key, 'shard': path.name, 'dtype': 'U8',
                     'shape': [end - start], 'data_offsets': [start, end], 'bytes': end - start}
                    for i, (key, start, end) in enumerate(spans)]
        return shard, segments, payload

    def test_boundaries_same_stream_and_exact_counts(self):
        for chunk in (1, 7, 16, 64, 256):
            with self.subTest(chunk=chunk), tempfile.TemporaryDirectory() as tmp:
                shard, segments, payload = self.fixture(Path(tmp))
                progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0}
                opened = []
                original = Path.open

                def track(path, *args, **kwargs):
                    if str(path) == shard['path']:
                        opened.append((args, kwargs))
                    return original(path, *args, **kwargs)

                with mock.patch.object(Path, 'open', track):
                    result, got = verifier.verify_shard(shard, segments, chunk, progress)
                self.assertEqual(len(opened), 1)
                self.assertEqual(progress['logical_read_bytes'], shard['bytes'])
                self.assertEqual(progress['segment_subset_hashed_bytes'], sum(s['bytes'] for s in segments))
                self.assertTrue(result['stat_checks']['unchanged'])
                for actual, segment in zip(got, segments):
                    start, end = segment['data_offsets']
                    self.assertEqual(actual['sha256'], hashlib.sha256(payload[start:end]).hexdigest())

    def test_shard_with_no_selected_segments_is_still_fully_hashed(self):
        with tempfile.TemporaryDirectory() as tmp:
            shard, _, _ = self.fixture(Path(tmp))
            progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0}
            result, segments = verifier.verify_shard(shard, [], 17, progress)
            self.assertEqual(segments, [])
            self.assertEqual(progress, {'logical_read_bytes': shard['bytes'], 'segment_subset_hashed_bytes': 0})
            self.assertEqual(result['sha256'], shard['sha256'])

    def test_bad_header_rejected_before_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            shard, segments, _ = self.fixture(Path(tmp))
            shard['header_sha256'] = '0' * 64
            progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0}
            with self.assertRaisesRegex(RuntimeError, 'header hash'):
                verifier.verify_shard(shard, segments, 17, progress)
            self.assertEqual(progress['logical_read_bytes'], 8 + shard['header_bytes'])
            self.assertEqual(progress['segment_subset_hashed_bytes'], 0)

    def test_bad_full_hash_rejected_after_single_full_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            shard, segments, _ = self.fixture(Path(tmp))
            shard['sha256'] = '0' * 64
            progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0}
            with self.assertRaisesRegex(RuntimeError, 'full shard SHA256'):
                verifier.verify_shard(shard, segments, 17, progress)
            self.assertEqual(progress['logical_read_bytes'], shard['bytes'])

    def test_wrong_selected_layout_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            shard, segments, _ = self.fixture(Path(tmp))
            segments[0]['shape'] = [999]
            progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0}
            with self.assertRaisesRegex(RuntimeError, 'Selected tensor header'):
                verifier.verify_shard(shard, segments, 17, progress)
            self.assertEqual(progress['logical_read_bytes'], 8 + shard['header_bytes'])


if __name__ == '__main__':
    unittest.main()
