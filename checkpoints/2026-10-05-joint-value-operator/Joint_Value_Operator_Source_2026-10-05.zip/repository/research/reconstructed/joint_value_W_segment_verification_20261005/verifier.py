"""One sequential cryptographic stream per shard; never decode tensor values."""
from pathlib import Path
import hashlib
import json
import os
import resource
import stat
import sys
import time

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def snapshot(s):
    return {k: getattr(s, k) for k in
            ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def verify_shard(shard, segments, chunk_bytes, progress):
    path = Path(shard['path'])
    resolved = str(path.resolve(strict=True))
    require(resolved == shard['resolved_path'], 'Shard symlink target changed')
    link_before = snapshot(path.lstat())
    path_before = snapshot(path.stat())
    require(stat.S_ISREG(path_before['st_mode']), 'Shard target is not regular')
    require(path_before['st_size'] == shard['bytes'], 'Shard size mismatch')
    full = hashlib.sha256()
    digests = {s['key']: hashlib.sha256() for s in segments}
    counts = {s['key']: 0 for s in segments}
    logical = 0

    # This is the sole open of this model payload. Unbuffered reads forbid any
    # hidden read-ahead and every byte is charged before any subsequent checks.
    with path.open('rb', buffering=0) as stream:
        fd_before = snapshot(os.fstat(stream.fileno()))
        require(fd_before == path_before, 'Opened shard identity changed')

        def read_metadata_exact(n):
            nonlocal logical
            data = bytearray(n)
            view = memoryview(data)
            done = 0
            while done < n:
                got = stream.readinto(view[done:])
                require(got > 0, 'Premature EOF in header')
                full.update(view[done:done + got])
                done += got
                logical += got
                progress['logical_read_bytes'] += got
            return data

        prefix = read_metadata_exact(8)
        header_len = int.from_bytes(prefix, 'little')
        require(header_len == shard['header_bytes'], 'Header length pin mismatch')
        raw_header = read_metadata_exact(header_len)
        require(hashlib.sha256(raw_header).hexdigest() == shard['header_sha256'],
                'Raw JSON header hash mismatch')
        header = json.loads(raw_header, object_pairs_hook=unique_object)
        require(len([key for key in header if key != '__metadata__']) == shard['tensor_count'],
                'Header tensor count mismatch')
        payload_start = 8 + header_len
        require(payload_start + shard['payload_bytes'] == shard['bytes'], 'Pinned layout mismatch')
        intervals = []
        for segment in segments:
            entry = header.get(segment['key'])
            require(entry == {'dtype': segment['dtype'], 'shape': segment['shape'],
                              'data_offsets': segment['data_offsets']},
                    'Selected tensor header differs from pinned metadata')
            begin, end = segment['data_offsets']
            require(type(begin) is int and type(end) is int and
                    0 <= begin < end <= shard['payload_bytes'] and
                    end - begin == segment['bytes'], 'Invalid segment bounds')
            intervals.append((payload_start + begin, payload_start + end, segment['key']))
        intervals.sort()
        require(all(a[1] <= b[0] for a, b in zip(intervals, intervals[1:])),
                'Selected tensor intervals overlap')
        del raw_header, header, prefix

        buffer = bytearray(chunk_bytes)
        view = memoryview(buffer)
        while logical < shard['bytes']:
            begin = logical
            got = stream.readinto(view[:min(chunk_bytes, shard['bytes'] - logical)])
            require(got > 0, 'Premature EOF in payload')
            logical += got
            progress['logical_read_bytes'] += got
            full.update(view[:got])
            for left, right, key in intervals:
                lo, hi = max(begin, left), min(logical, right)
                if lo < hi:
                    digests[key].update(view[lo - begin:hi - begin])
                    counts[key] += hi - lo
                    progress['segment_subset_hashed_bytes'] += hi - lo
        # No EOF probe: exact size plus descriptor/path identity is checked.
        fd_after = snapshot(os.fstat(stream.fileno()))
        del view, buffer
    path_after = snapshot(path.stat())
    link_after = snapshot(path.lstat())
    resolved_after = str(path.resolve(strict=True))
    require(fd_before == fd_after == path_before == path_after, 'Shard mutated during stream')
    require(link_before == link_after and resolved == resolved_after, 'Shard link changed during stream')
    require(logical == shard['bytes'], 'Read charge mismatch')
    digest = full.hexdigest()
    require(digest == shard['sha256'], 'Pinned full shard SHA256 mismatch')
    result_segments = []
    for segment in segments:
        require(counts[segment['key']] == segment['bytes'], 'Segment hash byte count mismatch')
        result_segments.append({**segment, 'shard_sha256': digest,
                                'sha256': digests[segment['key']].hexdigest()})
    return {
        'shard': shard['shard'], 'sha256': digest, 'bytes': logical,
        'header_bytes': header_len, 'header_sha256': shard['header_sha256'],
        'header_hash_scope': 'raw JSON header excluding 8-byte length prefix',
        'full_hash_verified': True, 'logical_read_bytes': logical,
        'payload_bytes_read': shard['payload_bytes'],
        'segment_subset_hashed_bytes': sum(counts.values()),
        'file_open_count': 1, 'sequential_pass_count': 1,
        'stat_checks': {'descriptor_before': fd_before, 'descriptor_after': fd_after,
                        'path_before': path_before, 'path_after': path_after,
                        'link_before': link_before, 'link_after': link_after,
                        'resolved_before': resolved, 'resolved_after': resolved_after,
                        'unchanged': True},
    }, result_segments


def main():
    require(__debug__, 'Optimized Python forbidden')
    config = json.loads((HERE / 'CONFIG.json').read_text())
    out = Path(config['output_directory'])
    require(os.environ.get('JV_W_HASH_GUARD_PID') == str(os.getppid()), 'Must run under admitted guard')
    require(os.environ.get('JV_W_HASH_ONCE') == 'PROVENANCE_ONLY', 'Missing one-pass environment')
    require((HERE / 'RUN_CLAIM.json').is_file(), 'Missing consumed run claim')
    pins = json.loads((HERE / 'EXPECTED_PINS.json').read_text())
    start = time.monotonic()
    progress = {'logical_read_bytes': 0, 'segment_subset_hashed_bytes': 0,
                'current_shard': None, 'completed_shards': []}
    try:
        require(pins['model_revision'] == 'cdbee75f17c01a7cc42f958dc650907174af0554', 'Revision')
        require([s['layer'] for s in pins['segments']] == [0, 7, 14, 21, 28, 35], 'Layer order')
        require(len(pins['shards']) == 3, 'Three full shards required')
        require(all(s['dtype'] == 'BF16' and s['shape'] == [2560, 4096] and
                    s['bytes'] == 20971520 for s in pins['segments']), 'W_o layout')
        hashes = []
        results = []
        for shard in pins['shards']:
            progress['current_shard'] = shard['shard']
            selected = [s for s in pins['segments'] if s['shard'] == shard['shard']]
            full, segments = verify_shard(shard, selected, config['chunk_bytes'], progress)
            hashes.append(full)
            results.extend(segments)
            progress['completed_shards'].append(shard['shard'])
        require(progress['logical_read_bytes'] == pins['expected_full_shard_logical_read_bytes'] == 8044982000,
                'Exact aggregate read charge')
        require(progress['segment_subset_hashed_bytes'] == pins['expected_segment_subset_hashed_bytes'] == 125829120,
                'Exact selected hash subset charge')
        by_layer = {s['layer']: s for s in results}
        require(set(by_layer) == {0, 7, 14, 21, 28, 35} and len(results) == 6, 'Six unique segments')
        record = {
            'schema': 'joint_value_W_segments.v1',
            'status': 'ALL_HASHES_VERIFIED_PENDING_CLEAN_SUPERVISOR_RECEIPT',
            'model': pins['model'], 'model_revision': pins['model_revision'],
            'segments': [by_layer[n] for n in [0, 7, 14, 21, 28, 35]],
            'full_shard_hashes': hashes,
            'provenance': {
                'expected_pins_sha256': hashlib.sha256((HERE / 'EXPECTED_PINS.json').read_bytes()).hexdigest(),
                'full_shard_logical_read_bytes': progress['logical_read_bytes'],
                'selected_segment_subset_hashed_bytes': progress['segment_subset_hashed_bytes'],
                'selected_segment_extra_read_bytes': 0, 'maximum_stream_buffer_bytes': config['chunk_bytes'],
                'full_shard_open_count': 3, 'full_sequential_passes': 3,
                'tensor_values_decoded': False, 'weight_payload_copied_to_files': False,
                'weight_payload_retained': False, 'inference_run': False,
                'holdout_read': False, 'torch_imported': 'torch' in sys.modules,
                'worker_elapsed_seconds': time.monotonic() - start,
                'worker_max_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            },
        }
        with (out / 'W_SEGMENTS_CANDIDATE.json').open('x') as f:
            json.dump(record, f, indent=2)
            f.write('\n')
        print('Cryptographic pass completed; publication awaits clean supervisor receipt.')
    except BaseException as exc:
        failure = {'status': 'FAILED_NO_RETRY', 'error': type(exc).__name__ + ': ' + str(exc),
                   'progress': progress, 'elapsed_seconds': time.monotonic() - start}
        with (out / 'failure.json').open('x') as f:
            json.dump(failure, f, indent=2)
            f.write('\n')
        raise


if __name__ == '__main__':
    main()
