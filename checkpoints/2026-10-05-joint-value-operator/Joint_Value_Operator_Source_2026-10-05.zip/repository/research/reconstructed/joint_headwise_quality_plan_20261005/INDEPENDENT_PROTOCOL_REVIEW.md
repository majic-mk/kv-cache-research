# Independent joint-value protocol review

Date: 2026-10-05 UTC. Scope: source/protocol review only. No model call, checkpoint tensor payload read, real-data encoding, or quality experiment was performed by this reviewer. The chronological findings below preserve earlier blockers; the final hash-bound decision is in FINAL_INDEPENDENT_RELEASE_REVIEW.json.

## Present decision

**Final: valid completed run; frozen usefulness gate FAILED.** Source/preparation passed, root separately admitted Stage A and Stage B, and all resource/parity/cap/coverage checks passed. FINAL_INDEPENDENT_RESULT_AUDIT.json records the terminal outcome. The source-review and amendment history below is preserved.

The fixed all-six-layer population, three signed-GQA objective definitions, protected-value layout, causal calibration split, and teacher-forced local-operator claim are coherent. The historical failed quality tests remain unchanged and are not promoted by this proposal.

## Required executable checks

1. Persist physically separate calibration Q496:512, prefix K/V0:512, future Q512:528, and suffix K/V512:528. Stage A can compare old future Q/K solely for exact trajectory parity. Stage B encoding must not open future tensor payloads, even for integrity hashing, until every arm at every layer and its manifest are locked. The capture worker has confirmed this split is being implemented.
2. Use all 32 signed query-head output blocks and mapping j//4 to all eight shared-value groups. A full-joint update retains errors from other groups and reconciles the global residual before switching groups. Headwise sums squared projected head errors; group-joint sums squared within-group sums. No independence assumption is justified.
3. Calibration query t must normalize over keys 0:t inclusive. Future query t must include suffix keys 512:t. Compressing only tokens 64:256 does not authorize softmax renormalization over those rows.
4. Freeze clipping order statistic, exact FP32 metadata cast order, FP64 decode, initial nearest rounding, ties, numerical loss-decrease rule, and cap tolerance. Compute caps against original unclipped values. Zero nearest row error allows no positive error beyond the predeclared floating-point verification tolerance.
5. Token GPTQ raw and guarded paths must remain distinct. Guarded compensation uses the accepted row, including fallback. Projected blocked raw proposals are diagnostics on the guarded trajectory, not an independent raw solver path. Block acceptance uses the undamped exact conditional quadratic and the same row cap.
6. Tiny fixtures must independently materialize signed multi-group design matrices and test Hessians, gradients, code-space scale/damping, inverse-Cholesky feedback, nonzero background cross-group terms, strict acceptance, zero curvature, orthogonal subspaces, and causal denominators. Freeze arrays/seeds/tolerances before test execution.
7. Charge actual initialization, repeated contractions, factors, raw and guarded proposals, compensation, residual reconciliation, and one final direct residual reconstruction. The common MAC-equivalent ceiling is not a CPU forecast. Record scalar operations and bytes separately; do not silently omit duplicated work or factor setup amortization.
8. Every required method must visit every active coordinate for at least one sweep in all six layers. Any missing arm/layer, resource failure, parity failure, invalid cap, or incomplete sweep means an incomplete fixed-population study, with no superiority verdict. Never filter failed layers or queries.
9. Primary normalization is each layer's full holdout SSE divided by that same layer's nearest SSE, averaged across the six fixed layers. Preserve absolute SSEs and per-query diagnostics. Use exact zero-denominator conventions, not an epsilon. The 96 layer/query cells are correlated observations of one previously used passage.
10. This is an isolated-layer, reference-trajectory, teacher-forced operator surrogate. It is not simultaneous quantized-model propagation, autoregressive quality, independent-task generalization, OptR reproduction, or serving-speed evidence.

## Guard and environment review requirements

On 2026-10-05, this reviewer observed `/proc/self/cgroup` containing `0::/`, no cgroup mount in `/proc/self/mountinfo`, and absent `/sys/fs/cgroup/memory.max`, `memory.current`, and `memory.high`. Host available memory was approximately 6.36 GB at that inspection; it is not evidence of effective cgroup capacity.

Root subsequently gave a fresh technical acceptance of this exact cgroup-visibility limitation for this joint-value packet only, under Stage A limits of 180 wall seconds, 240 aggregate CPU seconds, 3 GiB process-tree RSS, and host available memory at least 2 GB; Stage B limits of 300 wall seconds, 240 aggregate CPU seconds, 512 MiB process-tree RSS, and the same host reserve. This acceptance is not run admission or capacity proof. It must be recorded in a dated, source-bound amendment before final manifesting; an old run's waiver cannot substitute.

The reviewed executable must still reject any known lower inherited/ancestor limit, record current visibility, use monotonic elapsed time, count guard and live/exited child CPU without double counting, check terminal high-water RSS and output size, kill/reap its owned process group on normal and exceptional exits, and verify cleanup. Sampled tree RSS and per-child high-water RSS must be labeled separately. An RSS polling guard is not a hard kernel tree-memory ceiling.

The proposed Stage B CPU allowance is particularly uncertain: the three CD arms have about 3.54 million scalar decisions across six layers, in addition to about 2.36 million projected feedback decisions. Small Python/NumPy dispatch costs can dominate. A bounded source-frozen model-free timing preflight, if separately admitted, or a credible source-level feasibility account is required before generating data for a known-infeasible replay. Cap exhaustion cannot count as a losing baseline.

## Stage A final source review, 10:03 UTC

**PASS source/protocol review**, bound to `stage_a_packet/FROZEN_FILES.json` SHA256 `c6b2221b0797889cf22fb032911f7902207f33ef1926cb9f27d65582fc77bce9`. This reviewer independently verified all 22 named files against their size/hash records. The artifact contract SHA256 is `e8dc619d352124359dc186e876e114f142776b6e11ae2ba54e8c7fa645d2e356`.

The frozen source enforces transparent native-interface capture, ordered traversal of all 36 layers on each of five calls, exact causal masks and GQA/scaling, prefill-only calibration Q, finite BF16 tensors, model/cache release before old parity reads, exact signed-zero-preserving BF16-bit Q/K parity on all six layers, and publication of physically split tensor files only after all parity checks pass. Its completion record separately identifies source-hashing bytes and pager tensor-read bytes.

The guard uses an exclusive one-use claim, a source-bound absent-by-default admission, process-group termination and subreaper cleanup, waitid without reaping before terminal accounting, wait4 high-water receipts, aggregate CPU checks, monotonic wall deadline, cgroup/host checks, and output reserve with a self-inclusive final output byte count. Metadata-only preflight duration is separately reported; the wall deadline starts after that preflight, while the CPU cap includes the guard's entire process lifetime. The cgroup amendment is dated and frozen; it remains an observability limitation, not a hard-memory guarantee.

Reviewed worker-produced receipts show 9 tiny synthetic attention/capture tests and 14 standard-library guard tests passing. Coverage includes transparent output identity, RoPE Q/K/V layout, signed zero, bad masks/shape/nonfinite rejection, missing or changed admission, one-use claim, lower known cgroup rejection, orphan cleanup, wall/CPU/output cutoff, final high-water detection when sampling misses a peak, and parent-death kill. This reviewer did not rerun those tests or execute a model.

Receipt hashes:
- Capture tests: `c9f2c1b54e73f254402bb1a5b42d7d0ba1341d1dcb01aa3cc77c43238566aaf5`
- Guard tests: `8cc58b4c6d9947c88ac8b0b9bdb1314925c997dadb3e6ee8baadd8e26e68f320`
- Preparation metadata: `948707d9c42537060c0cf8f6a44f7994e05a5664926951fe6a1abc3a5c2369b0`

At review time there was no new `ADMISSION.json`, `RUN_CLAIM.json`, or `run` directory. Stage A execution remains held until Stage B feasibility is reviewed and root separately admits this exact manifest.

## Stage B intermediate accounting findings

At source review, the drafted implementation incorrectly charged half of every conservative scalar/comparison bound against the 1.2-billion work limit while its pre-unit estimate omitted most of that charge. The native projected kernel alone would have charged approximately 5.5 billion units per sweep; the declared pre-unit value was not an upper bound. The token-GPTQ function also accepted a budget without enforcing it. These are release blockers, not quality findings. The worker acknowledged them and is replacing the draft with a typed ledger that separates general scalar work from contraction MACs and the explicit factor/solve charge, with shared pre/post unit bounds and complete token-arm reservation.

A feedback tie-rule mismatch between the reference and C implementation was also identified. The worker reports a pre-execution correction and explicit half-integer fixtures. Final source and receipts still require verification.

## Remaining final-review status

Pending: final Stage B manifest, numerical fixtures and receipts, operation/scratch ledgers, native-shape synthetic timing forecast, read-isolation tests, evaluator source, and exact-hash admission decision. No real-data execution is authorized by this review.

## Stage B v1 model-free outcome, 10:16 UTC

The corrected supervision code is byte-for-byte the reviewed Stage A supervisor through `supervise`, with only the resource-only support import changed. The typed ledger now separates general scalar/comparison/rounding work from MAC contractions and disjoint factor/solve arithmetic. The same C cost-bound functions are used before each unit and to charge it, and the wrapper asserts the completed unit charge does not exceed its bound. Token GPTQ reserves and validates its complete cost. Projected diagnostics now retain all 32 scalar fields and guard flags.

Attempt 01 passed the tiny tests, then failed because the native synthetic W generator promoted a normalization expression to FP64 before a uint32 bit view. It was preserved. A dtype-only generator fix and explicit finite/shape assertions were frozen for attempt 02; the solver kernel did not change. The preparation CPU ledger records 1.084855 seconds for the failed first attempt and 5.327427 seconds for the second, totaling 6.412282 seconds.

**V1 WORK CAP FAILED; no real-stage admission.** Attempt 02 completed all required full synthetic native-shape sweeps. Its projected control charged 1,272,733,696 units/layer, exceeding the fixed 1,200,000,000 limit by 72,733,696 (6.061%). Headwise, group-joint, and full-joint CD each charged 897,581,056 under the generic dense kernel; raw plus guarded token GPTQ charged 440,598,528. No required arm was dropped or called a quality loser.

The second attempt's tiny checks passed 800 coordinate/feedback checks including explicit signed multi-group Hessian/gradient/target/factor comparisons, all-three-objective compact-vs-naive CD paths, orthogonal objectives, one-hot routing, zero curvature, half-up feedback ties, guarded-token fallback compensation, causal suffix-key denominators, ratio zero handling, and physical holdout read blocking. The native projected diagnostic records contain 12,288 blocks: 7,743 kept current, 249 accepted raw, and 4,296 accepted cap-filtered proposals. These are synthetic engineering checks, not natural-data quality evidence.

Attempt 02 used 238,321,664 bytes child high-water RSS, terminated cleanly, and verified its owned process group absent. One full synthetic layer took 3.890198286 process CPU seconds including synthetic generation/IO; linear six-layer extrapolation is 23.341189716 seconds. The encoder-plus-evaluation extrapolation is 21.903502950 seconds. Neither is a real six-layer runtime guarantee, and a partial second CD sweep at the actual work cap still needs accounting in a final forecast.

V1 attempt-02 preparation source manifest: `754ea6b64f4b0abf9e83f8064594447249d7fe28d47b6fd8ab49f8b5f42d55dd`.
Receipt hashes:
- Unit results: `dc34b341e5f6ce5e186c7023770109345b418777e163f8e584ddc8a49e3ad584`
- Forecast: `53093d8771b7d533df7c45d9e651d947539b2fe40a01778865cc4b4107694781`
- Guard: `568d052604d811e3693d199f08712957423c3b72b2ba54e6b6bc3c84bf3c65d5`
- Terminal: `a8d0280106b40e1f1ae25aa8fc34114ab15c0de83914f10ed1c4bb9c6425782b`

## Independent record of root's pre-real-data v2 amendment

At 10:16:58 UTC on 2026-10-05, root explicitly approved preparing a **common 1,300,000,000-unit per-layer/per-arm work limit**, based on the observed mandatory-control cost above. This is a disclosed pre-real-data protocol amendment, not a pass of v1. All physical resource caps, fixed population, inputs, required arms, and quality gates remain unchanged. No actual capture was authorized.

Root also requires a diagonal-specialized headwise implementation with identical codes and corrected lower bounds before fresh v2 review. The current generic headwise solver unnecessarily computes off-diagonal head Grams and dense products that its objective discards; v1 timings/work cannot be presented as the strongest efficient headwise baseline.

Preserve the original proposal, config, Stage A frozen packet, v1 manifests, and failed/infeasible receipts without editing. Recommended binding: a new dated amendment pins those prior hashes and the new work limit; the new Stage B manifest pins that amendment and the unchanged Stage A source/contract. An eventual Stage A release record can point to the reviewed v2 Stage B manifest and amendment without changing capture provenance or claiming that the original proposal used 1.3 billion units.

## V2 solver/preparation final review, 10:26 UTC

**PASS solver/preparation; HOLD real-stage release packaging.** This pass is bound to `joint_value_solver_prep_20261005/FROZEN_PREP_FILES.json` SHA256 `f6f384d09b4090a3ff5f63376778f314415a81ef4102100c1b03090b16a2c32b` (14 independently verified files), and `V2_WORK_BUDGET_AMENDMENT.json` SHA256 `5fdc5ea57a86f33f191938737751fee5869f3f9c0a10a9d0bced67be054440f2` (all seven evidence hashes independently verified). Compiled kernel source SHA256 is `4b3a62a4001d122a8b8979d9660aca857f1cebcddeb9e1f7093e59b7b74261c7`.

The efficient headwise branch computes only diagonal head Grams and diagonal compact products, with a lower source-derived cost bound. Three tiny equivalence checks pass against generic headwise and naive signed reconstruction. This reviewer independently compared the saved native first-sweep code array and all 196,608 update-path decisions to preserved v1: both match exactly.

Attempt 03 uses actual 1.3-billion budget stopping and saves first-sweep checkpoints. All required coverage and work checks pass:
- Headwise: 1,299,791,872 units, 534 group/channel-block units, two complete sweeps plus 22 units
- Group-joint: 1,298,661,376 units, 460 units, one complete sweep plus 204 units
- Full-joint: 1,298,661,376 units, 460 units, one complete sweep plus 204 units
- Raw plus guarded token GPTQ: 440,598,528 units, complete single pass
- Projected blocked control: 1,296,711,328 units, 263 units, one complete sweep plus seven units

The 800 existing tiny decision/feedback checks and three efficient-headwise checks pass. The forecast's whole synthetic layer time is 4.559754452 CPU seconds; its labeled linear six-layer extrapolation is 27.358526712 seconds (encoder plus evaluator 25.823991876 seconds). Real source IO, process overhead, serialization, and numerical branch differences remain unmeasured. This supplies a plausible physical-cap forecast, not a latency promise.

Guard receipt: 6.217141 aggregate CPU seconds for attempt 03; cumulative preparation CPU is 12.629423 seconds, below the 120-second authority. Sampled process-tree RSS peaked at 251,338,752 bytes; child high-water RSS was 244,523,008 bytes. No termination reason, exit code zero, all owned processes reaped/absent, final output 62,220,765 bytes. Cgroup capacity remains unknown as disclosed.

Attempt-03 receipt hashes:
- Unit results: `76ef4f8ff2446e1b8e74184d96c0932896536cc4dc52cfb501c12b32c0fac876`
- Forecast: `2d8b9fc2c39efa41db0697d968a732de10aadcf34fe381b4678b06a5921076ac`
- Guard: `52c070eea9f017157a114cbdd0d21dd987f0073ce8bbad28959f2198ee40f2cc`
- Terminal: `8b7a4c6f01fb1bd7fbd0b1c43106904946692cdbc39c4afbb3a3808e5dae7a06`

### Real-stage blockers still open

The preparation README explicitly says the current artifact reader is a synthetic-only barrier exercise, not a complete real-data release loader. The reviewed preparation does not yet provide a complete source-frozen real Stage B runner/evaluator. Before real execution, that release must:

1. Verify Stage A COMPLETE, clean terminal guard/cleanup, exact tensor-manifest hash, required tensor hashes, shapes, positions, dtype/layout, finite values, model/source/config pins, and exact Q/K parity evidence
2. Read only physically separate calibration inputs during encoding and load selected signed W_o segments with pinned header/offset/size and recorded segment hashes; stream one layer and count both encoder/evaluator weight-read passes
3. Persist and lock all six layers' final codes, grids, first-sweep checkpoints, raw/guard decisions, operation/byte/allocation ledgers, exact config/source/amendment identities before opening future payloads
4. Use the unchanged causal future softmax denominator, FP64 reference, full/head/group decomposition, all layer/query SSEs and raw/guard diagnostics; implement zero-baseline ratios without epsilon and serialize infinities honestly
5. Apply the fixed six-layer mean-ratio/4-of-6/96-cell peak-error gate without layer filtering, variant selection, or holdout-based stopping; label isolated-layer teacher-forced results accurately
6. Reuse the reviewed physical guard at Stage B limits with independent one-use source-bound admission, and preserve existing artifacts rather than treating this preparation pass as real-run authorization

The standalone Stage A source pass remains valid. Overall execution admission is still root's separate decision after these release artifacts are reviewed.

## Separate cryptographic source-pin amendment, 10:33:34 UTC

No precomputed verified W_o segment hashes were found in the existing metadata. Full-shard SHA256 pins, header hashes, tensor offsets, and sizes existed; a fresh segment self-hash alone would not establish its association with the pinned checkpoint.

Root explicitly authorized a **separate source-verification pass**, preserving the frozen Stage A packet: stream the three pinned full shards once, verify full SHA256/size/header identity, and hash all six selected W_o byte intervals from those same streamed bytes. No payload retention, numerical inspection, model execution, optimization, or holdout read is authorized by this amendment.

Separate caps are 30 aggregate process-tree CPU seconds, 90 wall seconds, 256 MiB process-tree RSS, and host available memory at least 2 GB. This adds approximately 8,044,982,000 logical source-read bytes; the exact measured count must be reported. Segment bytes are overlapping subsets of that pass, not an additional read pass. The verifier and expected source pins must be frozen before execution, use reviewed supervision, verify exact consumed byte counts, and produce a clean terminal receipt. The final Stage B manifest/admission must bind the resulting segment-pin receipt and its guard evidence.

This is a narrow change to the previous no-payload-read state for cryptographic provenance only. All actual Stage A/B launches remain held, and all previously frozen physical stage caps, population, solver choices, and quality gates remain unchanged.

## Final source/release decision, 10:59 UTC

PASS for separate root stage admissions. Final review JSON SHA256 is `a5b43f7f5aed2d6a03d25178104b0f16bcab478b808c3bfce6f31234f77ea005`. It binds Stage A, the explicit v2 solver amendment, the complete Stage B runner/evaluator, compiled kernel, all source/test receipts, and the successful separate cryptographic provenance pass.

The final Stage B source manifest is `d9ad52fb6ec8aa585939fe9f9fc8c6d921a3588f5b0429b290e992a9fb0d740b`; delivery manifest is `34ab7980322fce3af1580d7a61af467ceb61787d57a11ccf9460269f3b2491f3`. This reviewer independently verified seven source files, 19 external bindings, and 43 delivery files, and ran only metadata/source-integrity and provenance-schema/path checks. That final check imported neither Torch nor NumPy and opened no tensor or model payload. All 16 final synthetic tests pass. Per-arm work events are streamed; the native-size output estimate is 212,657,722 bytes, below 256 MiB. Existing model shard symlinks are resolved only against verified target/descriptor identities. The zero-perfect-control percentage gate edge case, inherited resource checks, post-final resource checks, and provenance finalization binding are fixed.

The provenance pass completed exactly once: 8,044,982,000 bytes streamed, six segment hashes covering a 125,829,120-byte subset of the same reads, no decoding/inference/holdout access. Receipts and their hash/count links were independently verified. Final 6.571197 CPU seconds, 6.697161 wall seconds, 24,592,384-byte sampled peak tree RSS, clean group absence, and 65,881 bytes final output are within its separate limits. Verified pins SHA256 is `71f2b0055d0650da94383d66fc82fb74231be848b7c682b956b72b1d9e6598ed`; guard is `a8f8728644fc338512833bd8e6afae192af79e4206e8b72702c20606e5e9dfe3`; finalization is `2add4ed1d3a33c79bede513387642613be79ff0f563b67ae7726c262b40d4e1a`.

No actual Stage A/B admission, claim, or run existed at the final check. Root may admit Stage A separately. Stage B may be admitted only after a clean, parity-preserving Stage A completion and exact tensor-manifest binding. Any failed resource/parity/cap/coverage/source condition invalidates the whole fixed-population run. No further source change or holdout-based tuning is covered by this pass. A successful engineering review is not a natural-data quality result.

## Completed-run audit, 11:11 UTC

Root subsequently admitted one Stage A capture, then one Stage B replay against its exact successful tensor manifest. Both completed cleanly. This reviewer inspected metadata/receipts and recomputed scalar gate calculations; no model, encoder, raw capture tensor, or weight payload was rerun/read by the reviewer.

**The run is valid; the frozen usefulness gate failed.** Mean of six layerwise nearest-normalized holdout SSEs:
- Nearest: 1.000000000
- Efficient headwise CD: 0.828324749
- Group-joint CD: 0.821914459
- Full-joint CD: 0.808808818
- Guarded token GPTQ: 0.966594180
- Projected blocked GPTQ: 0.804669366

Full-joint is 19.12% better than nearest, but only 2.36% better than headwise and 1.59% better than group-joint, and 0.51% worse than the projected control. It wins against headwise only in layers 0 and 35 (two of six, versus four required). Layer 7, position 520 has 1.5414384 times nearest SSE, exceeding the 1.25 pointwise guard. It therefore fails all three material quality conditions, despite improving calibration full-output SSE over headwise in every layer. This is an observed transfer limitation on this fixed passage, not a general theorem about coupled rounding.

All 36 encodings are complete, cap-feasible, and within the common work budget. The lock's IO trace contains no prelock future payload event, and every locked artifact hash/size agrees with the final manifest. There were exactly 12 selected W reads, totaling 251,658,240 bytes across encoder/evaluator passes. Stage B used 37.932891 aggregate CPU seconds including parent finalization, 35.347983 guarded wall seconds, 208,621,568-byte sampled peak process-tree RSS, and 185,308,476 bytes final output. Its owned process group was reaped and absent. All caps passed.

The final audit is `FINAL_INDEPENDENT_RESULT_AUDIT.json`, SHA256 `e253d399d41b074edd8202bd2520fe5e25a6a73ad7489b0a2146093c90a1cf0a`. It binds Stage A tensor manifest `cdc60a65bda8247e1cf0615a5afd71c37cd916cecaebb2e1d287a4a3a85c03e6`, Stage B result `214f69f7c41ee3f0cc9068f1800643bcb711f869b4031da5638263a4d0f9f09e`, encoding lock `3b07c0187b569c9832a1125d2efbdf425f7e8b6944cfbffa476f2b1f17367f39`, guard `756ec96f69edec54cd80b909b7fd9114b89512574e0c80c3595e7d194072ebfa`, and final manifest `b13decf01a380c192324d03cad8a75ae0e6c24ee8e0e231c35ee9c4eb6084b69`.

Close this exact proposal. Do not rescue it by selecting favorable layers, queries, checkpoints or controls, or by a holdout-driven retry, budget extension or threshold change. The earlier failed toy and temporal experiments remain unchanged. No autoregressive quality, method-superiority, generality, novelty or serving-speed claim follows.
