"""Reconstruct the exact admission-time review using only two known later edits.

No experiment, inference, payload access, or overwrite. The input is the current
chronological review with a fixed SHA256. The output is accepted only if its
bytes reproduce the SHA256 already recorded in Stage A admission and launch.
"""
from pathlib import Path
import hashlib
import json
import sys

INPUT_SHA256 = "9a3342b1e3a96a540825f3aa159c78d58c7784cf99eb53cf54a6ebc461b0f57c"
OUTPUT_SHA256 = "5cf438b70d5193a280cc19fd7be2eacbf3d94a3ee59f8d22805e2aae2e80c3e8"
MARKER = "\n## Completed-run audit, 11:11 UTC\n"
LATER_DECISION = (
    "**Final: valid completed run; frozen usefulness gate FAILED.** "
    "Source/preparation passed, root separately admitted Stage A and Stage B, "
    "and all resource/parity/cap/coverage checks passed. "
    "FINAL_INDEPENDENT_RESULT_AUDIT.json records the terminal outcome. "
    "The source-review and amendment history below is preserved."
)
ADMISSION_TIME_DECISION = (
    "**Final: PASS source/preparation for separate root Stage A then Stage B admissions.** "
    "All source/preparation blockers described below were resolved before real capture/encoding. "
    "Actual execution still requires the exact stage admissions and successful prerequisite "
    "receipts specified in FINAL_INDEPENDENT_RELEASE_REVIEW.json."
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def reconstruct(raw):
    if sha(raw) != INPUT_SHA256:
        raise ValueError("Current review does not match the documented recovery input")
    text = raw.decode("utf-8")
    if text.count(MARKER) != 1:
        raise ValueError("Expected exactly one known completed-run appendix")
    # Undo the appended section including its leading blank line. The retained
    # text already ends in one LF; do not strip, normalize or add a newline.
    text = text.split(MARKER, 1)[0]
    if text.count(LATER_DECISION) != 1:
        raise ValueError("Expected exactly one known changed decision paragraph")
    text = text.replace(LATER_DECISION, ADMISSION_TIME_DECISION, 1)
    candidate = text.encode("utf-8")
    if sha(candidate) != OUTPUT_SHA256 or len(candidate) != 22558:
        raise ValueError("Reconstruction does not exactly match the pre-existing admission pin")
    return candidate


def main():
    here = Path(__file__).resolve().parent
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else here.parent / "INDEPENDENT_PROTOCOL_REVIEW.md"
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else here / "INDEPENDENT_PROTOCOL_REVIEW.stage_a_admission.reconstructed.md"
    if len(sys.argv) > 3:
        raise ValueError("Usage: reconstruct_admission_review.py [current_review [new_output]]")
    candidate = reconstruct(source.read_bytes())
    if output.exists():
        if output.read_bytes() != candidate:
            raise FileExistsError("Refusing to overwrite a different output")
        mode = "verified_existing_identical_reconstruction"
    else:
        with output.open("xb") as stream:
            stream.write(candidate)
        mode = "created_separate_exact_hash_reconstruction"
    if sha(output.read_bytes()) != OUTPUT_SHA256:
        raise ValueError("Written output hash differs")
    print(json.dumps({"status": mode, "path": str(output), "bytes": len(candidate),
                      "sha256": OUTPUT_SHA256, "input_sha256": INPUT_SHA256}, indent=2))


if __name__ == "__main__":
    main()
