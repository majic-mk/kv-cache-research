# Source/algebra audit: conditional projected block control

2026-10-05. No numerical experiment or model/weight-payload read. A separate algebra review found the4-token by4-channel projected conditional Newton/GPTQ construction sound. The complete implementation still requires an explicit tiny-Hessian numerical preflight and independent release review.

## Correctness findings

- The conditional target is q0−(H_code+lambda I)^−1 g_code, not the original floating quantizer codes. The gradient includes every current token/channel/group residual
- Normalize by mu=trace(H_code)/16 and use M=H_code/mu+.01 I; for PSD H_code, condition(M)<=1601. This prevents unnecessary scale-conditioning trouble without changing the target
- Upper inverse-Cholesky U with U^T U=M^−1 follows the pinned GPTQ feedback orientation
- Feasible feedback can always choose the current discrete code when its guard uses finalized choices plus the remaining CURRENT discrete codes. Remaining continuous targets do not enter the row-cap state
- Save raw proposal diagnostics, but do not call proposals encountered on a guarded accepted path a separate raw trajectory
- Accept by the true undamped loss and row cap, never by the damping-augmented proxy
- A16-row active W matrix contains only one group's four heads/four channels. Reconcile the global residual after each group/channel block; deferring across all eight groups without extra pending cross-Gram terms would be wrong
- Any contradictory zero-curvature/nonzero-gradient case or factor/nonfinite failure must stop the proposed packet, not silently retune or drop the control

## Conservative all-six-layer arithmetic for one projected blocked sweep

There are1,536 group/channel units,73,728 conditional blocks and2,359,296 sequential feedback decisions from the raw and feasible proposal passes.

| Component | Approximate dense conservative count |
|---|---:|
| Active W-row Grams |1.007 billion MACs|
| Compact residual projections plus global reconciliations |2.013 billion MACs|
| Reusable attention token-block Grams |0.009 billion MACs|
| Block Hessian contractions |0.302 billion MACs|
| Block gradients |0.075 billion MACs|
| Worst-case accepted compact updates |0.377 billion MACs|
| Two candidate quadratic tests |0.040 billion MACs|
| Two feedback passes |0.020 billion MACs|
| Scaling and conservative factor/inverse/solve charge |0.472 billion MAC-equivalents|
| Core sweep total |approximately4.32 billion MAC-equivalents|
| Initial projected residuals |1.082 billion MACs|
| Calibration QK over512 keys |0.201 billion MACs, plus softmax|
| One final independent residual reconstruction |1.082 billion MACs|

This is approximately0.94 billion MAC-equivalents per layer before final reconstruction,1.12 billion after it. A proposed1.2-billion cap is plausible arithmetically, but small scalar/guard costs and an implementation-level charge convention must be fixed. Divisions, roots, comparisons, Python dispatch, source I/O and BLAS calls are not equivalent to GEMM throughput. No240-CPU-second completion estimate is established.

The analogous scalar-CD single-sweep counts across six layers are approximately2.45 billion elementary MAC/vector-operation units for headwise and2.87 billion for full-joint, before shared acquisition/initialization and final auditing. These fuller bounds exceed a leading-term-only formula because dots and compact state updates are included. This difference is exactly why the actual implementation ledger, not equal iteration count, must decide the work budget.

## Memory and audit traps

All attention block Grams occupy0.75MiB per layer. All16-square conditional Hessians occupy24MiB, and optional inverse-factor caches another24MiB. Cached factors can be reused across sweeps since P, W and scales are fixed. Their original construction is still charged.

Streaming one W_o layer (80MiB FP64), keeping at most20MiB source BF16, and using compact state is compatible with a numerical-payload plan below about192MiB. This is not a process-RSS certificate. Avoid simultaneous extra FP32 conversion and retained large diagnostic copies where unnecessary.

Full residual histories at all group/channel boundaries require480MiB across six layers for one history,960MiB for tracked plus direct. Full independent residual reconstruction after every boundary adds approximately277 billion MACs. Save uint8 decisions and stream summaries; reserve one independent final reconstruction per arm instead.

## Why not substitute full-token projected GPTQ automatically

A192-token by one-channel projected conditional block compensates across more tokens but omits cross-channel block compensation, so it does not dominate4-by4. Straightforward dense factor/inverse/factor processing requires1,024 different192-square systems per layer, roughly116 billion FLOPs over six layers before other work. Rank<=64 structure may enable a better specialized implementation, but deriving and validating it is additional engineering. It is not a simpler mandatory replacement for this bounded16-variable control.

## Limits of this review

Formula/source audit only. No explicit Hessian fixture, floating-point tolerance, executable counter, resource guard or real data was tested. The prototype must pass those reviews before any model call or payload read. The control remains a blocked conditional method, not exact global GPTQ and not a novelty claim.
