# Exact-joint versus headwise V-rounding: source-verified quality plan

Superseded population/resource details: see TWO_STAGE_PROPOSAL.md and PROPOSED_CONFIG.json for the all-six-layer two-stage proposal. The one-layer sketch below is historical planning, not a release.

2026-10-05 UTC. **Preparation only. No new inference, tensor-weight read, quality replay or optimization was performed.** The compact-CD mechanics pass is engineering evidence; the previous N4/D2 quality result remains failed.

## Hypothesis and current admission state

A specific untested hypothesis is that fitting the **joint layer output error**, including signed cross-head and cross-KV-group terms, gives better temporally held-out readout at fixed cache format and encoder budget than fitting individually squared query-head errors.

The efficient exact head-Gram CD implementation makes that comparison feasible in principle. It is the strong implementation baseline, not a new QR invention. “Use the full loss” remains a substantial novelty risk: standard reconstruction optimization already supports it. A meaningful paper needs a repeatable natural-data benefit that survives stronger controls, online acquisition costs, independent holdouts and workload changes.

**No real-tensor quality run is admitted yet.** Required V and pre-compression calibration Q are absent. A new capture and fixed encoding protocol require separate authorization.

## 1. What OptR actually defines

[OptR, Sections 3.2 and 4.4](https://arxiv.org/html/2608.02691v1#S4.SS4) defines y_(t,j) as one query head's contribution after its W_O block, and averages ||e_V(t,j)||² over positions and heads. The [author code at 66d4656](https://github.com/daniel-eai/Output-Aware-INT2-KV-Cache-Quantization/blob/66d46561b9bdf5d715f591e0f5845a4cbd927dee/optr/calibrate_optr.py#L83-L113) computes each head's d_out, squares it, then averages.

No claim that different heads are independent, or that cross-head terms vanish, was found in the inspected paper. Its per-head decomposition is exact for each contribution. Calling the headwise loss a proxy for the full layer sum is our comparison, **not a bug claim or an author-stated equivalence that we disproved**.

OptR optimizes offline reusable rotations. Our proposed first ablation changes scalar codes on one prefix. They are different actions with different amortization. A headwise-CD control reproduces OptR's objective form, not the entire OptR method. No superiority over OptR may be claimed without its full rotation path as a separate method baseline.

## 2. Three objective levels, with all groups present

For layer output error r_j(t)=P_j(t,:) E_(g(j)) W_j, compare:

1. Headwise: L_head = sum_(t,j) ||r_j(t)||²
2. Within-group joint: L_group = sum_(t,g) ||sum_(j in g) r_j(t)||²
3. Full layer joint: L_full = sum_t ||sum_j r_j(t)||²

This isolates within-GQA-group and between-KV-group cross terms. The complete squared error equals the headwise term plus both signed cross terms.

When optimizing a single group for L_full, retain the current error from every other group in R_bg; after a block update, update the same global residual. Independently optimizing groups and adding their squared errors would instead implement L_group. The fixed-background mechanics check proves only that the implementation can retain those terms, not that doing so improves future behavior.

## 3. Verified assets and the missing causal information

Metadata-only verification used exactly the three safetensors header records, config and index supplied for:

- Qwen/Qwen3-4B-Instruct-2507
- revision cdbee75f17c01a7cc42f958dc650907174af0554
- 36 layers, 32 query heads, 8 KV heads, d=128, hidden size 2560
- GQA group size **4**, not 8
- Each W_O tensor is BF16 [2560,4096], 20 MiB
- All six selected W_O tensors together are 120 MiB BF16, or 240 MiB if converted to FP32

Only **45,808 safetensors-header bytes** were read; tensor payload read was **zero**. Actual cross-head Gram strengths cannot be inferred from shapes. ASSET_METADATA.json records all selected shapes, offsets and matching header hashes.

The existing six-layer packet at layers 0,7,14,21,28,35 stores:
- Q for positions 512–527: [16,32,128] BF16 per layer
- K for positions 0–527: [528,8,128] BF16 per layer
- no V and no prefill calibration queries before position 512

The trace is chunked, teacher-forced, full-cache reference execution. It is not generated-token deployment evidence.

**Causal trap:** taking the first eight saved queries as calibration would use future positions to optimize a cache purportedly compressed at position 512. A valid 512-prefix design instead needs new calibration Q from the completed prefill, for example positions 496–511. The existing 16 future queries can remain temporally held out. Changing the compression point to 520 would be another protocol, not a silent workaround.

## 4. Minimum additional data

For a single preselected layer, e.g. layer 14 chosen before inspecting V/error results:

- V0:512 for every KV head: 1 MiB BF16, sufficient for absolute output-error differences when only prefix V is compressed and later V stays exact
- Prefer V0:528: 1.03125 MiB BF16, allowing complete full-readout references including exact suffix values
- Calibration Q496:512 for all 32 heads: 128 KiB BF16
- All W_O blocks in that layer: 20 MiB BF16; read only that tensor if separately authorized
- Original token IDs, positions, causal masks, grouping, checkpoint/config identity, dtype, chunking and native attention scaling
- Re-captured Q/K identity checks against the existing reference packet, to ensure that newly captured V belongs to exactly the same native trajectory

Capturing the same fields for all six layers costs about **6.1875 MiB of V plus 0.75 MiB calibration Q**, excluding tiny metadata. Those activations cannot be reconstructed correctly from saved K alone. V-projection weights alone do not supply the missing hidden states.

The saved source execution reports five model calls, roughly 29.0 seconds in those calls plus 8.1 seconds pager setup, with approximately 2.09 GB peak RSS. Those are previous measurements, not a promise that a new capture fits a 512-MiB tensor-replay limit or will take the same time. A model-capture release needs its own prior resource contract. It is not authorized by this preparation.

A later W_O geometry-only read would require no inference, but is also deferred under the current “metadata only” instruction.

## 5. First real-tensor gate, if separately authorized

### Narrow purpose

Use one predeclared layer and one public prefix as an exploratory **problem-existence falsifier**. A positive result is insufficient for a paper or generality. Do not spend on all six layers or more passages merely because one layer fails. Any next scope must be separately justified.

Fix calibration to prefill queries 496–511, optimization boundary 512, and test to queries 512–527. Native causal attention must include each held-out query's available suffix keys in its softmax denominator. Only old-prefix V errors enter the difference when suffix V remains exact.

The current passage was previously used for selector work. It can be an objective-specific diagnostic, but cannot become evidence from a wholly unseen dataset. A later positive claim requires new public passages fixed before capture and a final holdout never used for selection.

### Format and initialization

A defensible source-aligned carrier is OptR's scalar affine INT2 grouping (128 dimensions) and protected windows, with all scale/zero-point/clipping choices fixed before solver comparison. For a 512-token prefix, its 64-token sink plus 256-token recent window leaves only **192 compressed tokens**. Report this actual footprint; do not quote its 64K effective bits per element.

Compute grids once from original V and keep them fixed across every arm. Hold K identical, initially full precision, to isolate the value objective. This is V-only objective isolation, not full OptR reproduction. A later quantized-K path must use identical quantized keys in every arm and include its separate error.

Keep the established 1.25-times-nearest per-row SSE constraint if used; apply it identically and retain raw/fallback outputs where an algorithm cannot enforce it internally. Do not loosen it after seeing real outcomes.

### Mandatory arms

- Full-precision readout reference
- Fixed-grid nearest rounding
- Headwise objective with efficient compact CD
- Within-KV-group joint objective with compact CD
- Full-layer joint objective with compact CD and all cross-group residuals
- Standard token-axis GPTQ on the same calibration attention
- A stronger projected block-GPTQ/OBS control with fully specified fixed token/channel blocks, damping, order, grid and guard
- Matrix-free soft-rounding/AdaRound-style optimization if claiming that full joint CD is algorithmically better, rather than only isolating the objective

The small-block projected GPTQ design must be validated and its construction/factorization charged before execution. It cannot be silently dropped because dense (N*d)-square GPTQ is impractical. Exact local block Hessians can be assembled from P_h^T P_h' and W_h W_h'^T without forming the global matrix. Blocks of 8 tokens by 8 channels give 64-dimensional local systems; that is an example to freeze and cost, not a tuned recommendation.

Full author OptR rotation calibration is an additional required comparison for any eventual method-superiority claim. The initial same-code-grid objective ablation must not borrow that label.

### Equal encoder budget, not merely equal sweeps

Headwise CD is cheaper than joint CD. At equal sweeps, giving the joint method more arithmetic would confound the claim. Freeze:
- one or two logical-MAC budgets per layer, including P acquisition, initialization, Gram/QR construction, block factorization and reconciliation
- a deterministic work counter and stop boundary common to all methods
- fixed solver order, damping, quantizer and guard; no held-out stopping
- both matched-coordinate-count and matched-total-work results, clearly distinguished
- actual CPU wall/time and peak allocation measurements using an appropriate aggregated timer

The completed mechanics packet exposed coarse short CPU subtimers; do not reuse those zeros as free acquisition costs. A new timing protocol must aggregate complete encoding operations. The exact budgets still require a source-level block-GPTQ cost audit; this plan is not a runnable frozen protocol.

### Measurements and stopping logic

Primary metric: **full layer** post-projection SSE on the 16 temporal holdout queries, with all 32 heads and all 8 groups. Report each query and layer separately, plus headwise, within-group and between-group contributions. Normalize comparisons by the same nearest baseline with explicit zero-denominator handling, never by an almost-zero full output without disclosure.

Require a prespecified material improvement versus the strongest eligible matched-budget control, not only versus nearest. Stop if improvement is calibration-only, disappears against headwise at equal work, comes only from cross-group terms being dropped in a control, or worsens a prespecified temporal/peak-error guard. No seed, passage, layer, cap or budget replacement based on results.

A single short temporal trace cannot establish robustness to new tasks or long generation. It is a cheap falsifier of the proposed effect, not a complete evaluation.

## 6. Negative controls and later independent evaluation

Before natural-data claims, require model-free tests where cross terms must vanish (mutually orthogonal head output subspaces), and signed-cancellation fixtures where headwise and full objectives differ. These are numerical controls only.

For the real packet, record fixed uniform/peaked routing stress patterns as diagnostics if included. Do not call a finite set of routes the exact all-head envelope: full enumeration would require N^32 route tuples. A bound on the maximum absolute error also does not imply pointwise relative non-regression versus nearest.

A later independent evaluation would need multiple prespecified public-prefix families, causal prefill-only calibration, untouched future continuations, and a separate validation set for any solver or rotation selection. Teacher-forced tensor readout remains distinct from autoregressive generation, task accuracy and deployment latency.

## 7. Remaining novelty and admission risk

- OptR genuinely omits h≠h' terms in its stated headwise loss, but it does not claim these terms are zero
- Full-output reconstruction is already a standard quantization objective; changing “average of squares” to “square of sum” alone is weak novelty
- Exact Gram CD is an efficient enabling baseline, not evidence for a new solver
- Cross-head errors may already cancel beneficially, and fitting short calibration traces may destroy cancellation under query shift
- True W_O geometry and actual attention/value errors are unmeasured; a large off-diagonal Gram norm alone would not prove useful quality headroom
- Rotation methods amortize offline costs across requests; per-prefix code optimization pays again for each prefix
- No claim about one-5090 performance follows from FP64 identities or this metadata inventory

**Next permitted action remains preparation and review.** No tensor weights or new model activations should be read/generated until the specific data/resource release is granted and the stronger baseline/budget contract is complete.

