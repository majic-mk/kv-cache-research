"""Stage A only: five identical native calls and separate BF16-bit artifacts."""
from pathlib import Path
import gc,hashlib,json,os,resource,time,traceback
from common import *
from cpu_release import require_cpu_release
from file_pager import FilePager
from capture import InterfaceCapture
from collector import Collector
from tensor_io import write_array, exact_parity
def main():
    require_cpu_release()
    launch=read_json(OUT/'launch.json')
    require(launch['guard_pid']==os.getppid(),'Wrong launcher parent')
    require(launch['packet_manifest_sha256']==packet_integrity(),'Packet changed after launch')
    deadline=float(launch['deadline_monotonic'])
    def check():check_live(deadline);require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=LIMITS['rss_process_tree_bytes'],'Child high-water RSS exceeded3GiB')
    check()
    import torch,transformers
    from transformers import Qwen3Config,Qwen3ForCausalLM
    from transformers.cache_utils import DynamicCache
    from transformers.models.qwen3 import modeling_qwen3 as qwen
    require(torch.__version__=='2.9.1+cpu' and torch.version.cuda is None,'Pinned CPU Torch only')
    require(transformers.__version__=='5.19.0.dev0','Pinned Transformers')
    require(sha_file(qwen.__file__)=='2b768b0eb0aacf1478bba1dc84318126c6c68fecb0ac9465f70154f24da4a80d','Pinned native Qwen3 source')
    import transformers.cache_utils as cache_source
    import transformers.modeling_utils as modeling_source
    import transformers.masking_utils as masking_source
    for source,expected_hash in ((cache_source,'2d2ab17aa02c9d2a993587ec58d1745b03595b6028c401cc6c976bb720ad6638'),(modeling_source,'3a32f432917a1265fc3f26b2a36032b047b9c4d367ea75a5c8d389b1d268cda0'),(masking_source,'af3d84dfe82a0b57c40625c89fb32b2cd6bf7351432ee5e76a9e8eac4289575b')):
        require(sha_file(source.__file__)==expected_hash,'Pinned native dependency: '+source.__name__)
    torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.set_grad_enabled(False);torch.use_deterministic_algorithms(True)
    raw=read_json(ASSETS/'config.json')
    require(sha_file(ASSETS/'config.json')==read_json(PACKET/'input_lock.json')['config_sha256'],'Config identity')
    actual=tuple(raw[x] for x in ('num_hidden_layers','num_attention_heads','num_key_value_heads','head_dim'))
    require(actual==(36,32,8,128),'Frozen dimensions must match actual config')
    require(raw['rope_theta']==5000000 and raw['rope_scaling'] is None and not raw['use_sliding_window'],'Frozen RoPE/attention')
    config=Qwen3Config.from_dict(raw);config._attn_implementation='eager'
    require(config.rope_parameters=={'rope_theta':5000000,'rope_type':'default'},'Native standardized RoPE')
    prior=torch.get_default_dtype();torch.set_default_dtype(torch.bfloat16)
    try:
        with torch.device('meta'):model=Qwen3ForCausalLM(config).eval()
    finally:torch.set_default_dtype(prior)
    model.model.rotary_emb=qwen.Qwen3RotaryEmbedding(config=config)
    require(len(model.model.layers)==36,'36 decoder layers')
    require(all(p.device.type=='meta' for p in model.parameters()),'Meta construction')
    require(model.lm_head.weight is model.model.embed_tokens.weight,'Native tied embedding/head')
    ids=read_json(PACKET/'token_ids.json');require(len(ids)==528 and all(type(x)is int and 0<=x<raw['vocab_size'] for x in ids),'Exact token ID range')
    expected=read_json(PACKET/'asset_expected.json')['shards']
    call_rows=[]
    collector=Collector(check)
    cache=DynamicCache(config=config)
    import ctypes
    libc=ctypes.CDLL(None);libc.malloc_trim.argtypes=[ctypes.c_size_t];libc.malloc_trim.restype=ctypes.c_int
    with torch.inference_mode():
        setup=time.monotonic()
        with FilePager(model,[ASSETS/x['path'] for x in expected],synthetic=False,expected_sources=expected) as pager:
            setup=time.monotonic()-setup;check()
            with InterfaceCapture(qwen,collector) as capture:
                require(qwen.ALL_ATTENTION_FUNCTIONS.get_interface(config._attn_implementation,qwen.eager_attention_forward) is capture.wrapper,'Eager dispatch must use the capture wrapper')
                for lo,hi in CHUNKS:
                    collector.begin(lo,hi);check();beg=time.monotonic()
                    output=model(torch.tensor([ids[lo:hi]],dtype=torch.long),past_key_values=cache,use_cache=True,logits_to_keep=1)
                    collector.finish()
                    require(bool(torch.isfinite(output.logits).all()),'Finite final-position logits')
                    del output
                    pager.assert_idle();gc.collect();trim=int(libc.malloc_trim(0));check()
                    call_rows.append({'start':lo,'end':hi,'seconds':time.monotonic()-beg,'trim_return':trim,'self_max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'host_available':host_available()})
            collector.complete()
            pager_stats=dict(pager.stats)
    write_json(OUT/'extraction.json',{'config_dimensions':actual,'layers':LAYERS,'all_query_heads':32,'all_kv_heads':8,'calls':call_rows,'capture_calls':collector.calls,'causal_masks':collector.mask_rows,'pager_setup_seconds':setup,'pager_stats':pager_stats,'teacher_forced':True,'actual_generated_trace':False,'model_calls':5,'GPU':False})
    # Release the model and full cache before any offline scoring/allocation.
    del model,cache,pager;gc.collect();libc.malloc_trim(0);check()
    # Model/cache/pager are gone before reading even one old tensor for parity.
    trace=collector.trace
    old_files=read_json(PACKET/'OLD_TENSOR_PINS.json')['files']
    parity=[]
    for layer,spec in zip(LAYERS,old_files):
        expected='layer_%02d.pt'%layer
        require(spec['path']==expected,'Old tensor manifest layer order')
        source=OLD/'run'/expected
        require(source.stat().st_size==spec['bytes'] and sha_file(source)==spec['sha256'],'Old tensor payload pin')
        prior=torch.load(source,map_location='cpu',weights_only=True)
        checked=exact_parity(trace[layer],prior)
        parity.append(dict(layer=layer,old_path=str(source.relative_to(ROOT)),old_sha256=spec['sha256'],**checked))
        del prior;check()
    # Only after ALL parity checks pass are any consumable tensors published.
    artifacts=[]
    for layer in LAYERS:
        item=trace[layer];prefix='layer_%02d'%layer
        for split,name,t,positions,role in (
            ('calibration','query',item['query_calibration'],(496,512),'calibration_query'),
            ('calibration','keys',item['keys'][:512],(0,512),'prefix_keys'),
            ('calibration','values',item['values'][:512],(0,512),'prefix_values'),
            ('holdout','query',item['query'],(512,528),'holdout_query'),
            ('holdout','keys',item['keys'][512:],(512,528),'suffix_keys'),
            ('holdout','values',item['values'][512:],(512,528),'suffix_values')):
            row=write_array(OUT,f'{split}/{prefix}/{name}.npy',t,positions,role)
            artifacts.append(dict(layer=layer,split=split,**row));check()
    raw_bytes=sum(x['raw_bytes'] for x in artifacts)
    require(raw_bytes==14548992,'Frozen full six-layer payload size')
    manifest={'schema':'joint_value_capture.v1','capture_packet_manifest_sha256':launch['packet_manifest_sha256'],
              'proposal_sha256':PROPOSAL_SHA,'config_sha256':CONFIG_SHA,'token_ids_sha256':TOKEN_SHA,
              'model_repository':'Qwen/Qwen3-4B-Instruct-2507','model_revision':'cdbee75f17c01a7cc42f958dc650907174af0554',
              'layers':list(LAYERS),'query_heads':32,'kv_heads':8,'head_dim':128,'query_head_to_kv':'j//4',
              'native_scaling':128**-.5,'native_dtype':'bfloat16','causal_query_t_attends_keys':'0:t inclusive',
              'chunks':[list(x) for x in CHUNKS],'calibration_positions':[496,512],'holdout_positions':[512,528],
              'calibration_keys_and_values_positions':[0,512],'holdout_keys_and_values_positions':[512,528],
              'position_ranges_half_open':True,'raw_tensor_bytes':raw_bytes,'files':artifacts,
              'source_pins':read_json(PACKET/'EXTERNAL_PINS.json'),'causal_masks':collector.mask_rows,
              'old_tensor_parity':parity,'all_old_query_and_key_bits_equal':True,
              'holdout_policy':'Stage B must lock all six-layer/all-arm encodings before opening or hashing holdout tensor files'}
    write_json(OUT/'tensor_manifest.json',manifest)
    del trace,collector;gc.collect();libc.malloc_trim(0);check()
    write_json(OUT/'completion.json',{'status':'COMPLETE','stage':'A','model_calls':5,'teacher_forced':True,
               'model_and_full_cache_released':True,'offline_optimization_performed':False,
               'all_old_query_and_key_bits_equal':True,'tensor_manifest_sha256':sha_file(OUT/'tensor_manifest.json'),
               'source_hash_bytes':pager_stats['source_file_bytes'],'pager_tensor_read_bytes':pager_stats['read_bytes'],
               'source_hash_plus_pager_read_bytes':pager_stats['source_file_bytes']+pager_stats['read_bytes'],
               'read_traffic_is_not_download':True,
               'self_max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024})
    check()
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        if OUT.exists() and not (OUT/'failure.json').exists():
            write_json(OUT/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(limit=8),'model_retry_authorized':False})
        raise
