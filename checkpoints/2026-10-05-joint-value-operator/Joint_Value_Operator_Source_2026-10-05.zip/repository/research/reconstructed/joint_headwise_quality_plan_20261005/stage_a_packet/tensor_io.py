"""Portable BF16-bit serialization. Imports NumPy/Torch only inside called helpers."""
import hashlib
from pathlib import Path
from common import require, sha_file

def bf16_bits(tensor):
    import numpy as np
    import torch
    require(tensor.dtype==torch.bfloat16 and tensor.device.type=='cpu','Exact CPU BF16 only')
    return tensor.contiguous().view(torch.uint16).numpy().astype(np.dtype('<u2'),copy=True)

def tensor_bit_hash(tensor):
    return hashlib.sha256(bf16_bits(tensor).tobytes(order='C')).hexdigest()

def write_array(out, relative, tensor, positions, role):
    import numpy as np
    p=Path(out)/relative; p.parent.mkdir(parents=True,exist_ok=True)
    bits=bf16_bits(tensor)
    with p.open('xb') as f: np.save(f,bits,allow_pickle=False)
    return {'path':relative,'bytes':p.stat().st_size,'sha256':sha_file(p),'data_sha256':hashlib.sha256(bits.tobytes()).hexdigest(),
            'shape':list(bits.shape),'storage_dtype':'<u2','logical_dtype':'bfloat16','layout':'token,head,channel',
            'order':'C','positions':list(positions),'role':role,'raw_bytes':bits.nbytes}

def exact_parity(current, prior):
    import numpy as np
    require(set(prior)=={'query','keys'},'Unexpected old tensor fields')
    require(np.array_equal(bf16_bits(current['query']),bf16_bits(prior['query'])),'Old future Q BF16-bit parity mismatch')
    require(np.array_equal(bf16_bits(current['keys']),bf16_bits(prior['keys'])),'Old full K BF16-bit parity mismatch')
    return {'query_bitwise':True,'keys_bitwise':True,
            'query_data_sha256':tensor_bit_hash(current['query']), 'keys_data_sha256':tensor_bit_hash(current['keys'])}
