# Stage A: same-trajectory joint-V research capture

Preparation only. No model execution, real weight-payload read, download, GPU, package installation, Stage B optimization, admission or one-use claim was performed to prepare this packet. Synthetic tests instantiate only a tiny random attention module. The historical packet is unchanged.

## Review and conditional entrypoint

Only after independent source/guard/protocol review and a separate root launch decision:

    research/reconstructed/runtime_recovery_20261004/.venv/bin/python research/reconstructed/joint_headwise_quality_plan_20261005/stage_a_packet/guard.py

The new packet deliberately has no ADMISSION.json or RUN_CLAIM.json. guard.py requires a root-created ADMISSION.json with decision `ADMIT_ONE_JOINT_VALUE_STAGE_A_CAPTURE`, final reviewed `packet_manifest_sha256`, `review_accepted: true`, `parent_authorized: true`, `max_runs: 1`, `stage_B_preparation_reviewed: true` and `limits` exactly equal to the proposal Stage A caps. If cgroup visibility is unavailable, `accept_unobservable_cgroup_ceiling: true` is additionally required for this exact packet. The frozen fresh environment amendment is acceptance of an observability limitation, not run permission or proof of capacity. These records document scope, not a cryptographic permission system.

A persistent exclusive RUN_CLAIM.json is consumed before starting the child; any claim or run directory blocks future launch. Never remove them to retry. Preparation failures do not authorize a run. The capture runner and unchanged file pager both call the new release function before importing model runtime or reading weight payloads. Historical authorization flags are not imported.

## Native workload and artifact contract

Exactly five teacher-forced native BF16 calls on the same existing pinned Qwen3-4B-Instruct-2507 revision and exact 528 token IDs: 0:128,128:256,256:384,384:512,512:528. Same four intra-op and one inter-op threads, deterministic mode, native eager attention/norm/RoPE/cache/FFN and unchanged preadv file pager. All 36 layers execute every time; layers 0,7,14,21,28,35 are copied only. No all-weights-resident path, model modification or generated continuation.

The transparent native attention-interface callback copies Q496:512 at the fourth call, then Q512:528 and K/V0:528 at the fifth call. Every layer traversal, native tensor shape/dtype, GQA mapping, scaling, and complete causal mask are verified. Native interface arguments and result objects are forwarded unchanged. No output tensors are exposed until bit patterns of all old Q512:528 and K0:528 are exactly equal against the historical pinned tensors. Any mismatch closes the packet.

After the model and cache are released, parity and serialization run. ARTIFACT_CONTRACT.json defines six independent NPY files per layer, physically separating calibration/prefix from holdout/suffix. All contain exact BF16 bits as little-endian uint16, token/head/channel order. Stage B must verify only calibration hashes before its complete all-layer/all-arm encoding lock. Merely seeing future file hashes in JSON metadata is not permission to open those files. Successful tensors total 14,548,992 raw bytes, plus NPY headers and receipts.

## Guard and accounting

Frozen maxima: 180 guarded wall seconds, 240 aggregate CPU seconds, 3GiB sampled process-tree RSS, 2,000,000,000B minimum host MemAvailable, 64MiB total evidence including logs and terminal receipt. Metadata/resource preflight time is separately recorded; aggregate CPU includes guard process CPU from startup. Any stricter inherited per-process CPU limit is retained. Known cgroup ancestors and stricter inherited address/data limits are checked. No resource extension or automatic retry.

The guard owns one process group, applies a parent-death kill and acts as child subreaper, monitors current/zombie CPU plus waited usage, and terminates/reaps the group on success, failure or interruption. Live/zombie child usage moves to RUSAGE_CHILDREN when reaped, avoiding intentional double counting. Linux per-process CPU limits backstop the single non-worker-spawning capture. This does not provide cgroup-enforced instantaneous tree CPU or RSS limits; samples can miss transient peaks. Final wait4 high-water RSS is separately recorded and checked, never mislabeled a simultaneous tree peak. Cleanup verifies no group entries remain. 64KiB is reserved inside the output cap for terminal reporting; final receipt records its own inclusive byte total.

The unchanged pager hashes all three shards before inference; actual source-hash bytes and pager tensor-read bytes are reported separately. The prior 45,156,444,912B logical read total is historical traffic, not a new download or free reused acquisition. No shard hash or tensor payload was read in preparation. Prior 44.97s wall / 2.10GB RSS are analogs, not forecasts.

## Model-free verification

Run test_guard.py with the standard interpreter and test_capture.py with the pinned interpreter. Dummy guard tests cover missing/malformed admission, exclusive claims, inherited limits, unknown/known cgroup boundaries, child success/failure, wall/aggregate-CPU/output limits, orphan adoption/reaping, parent death, and final high-water RSS when sampling misses it. Tiny native tests cover exact wrapper result identity, restoration on exceptions, post-norm/post-RoPE Q/K and native V, cache append, calibration/future query split, causal mask rejection, missing layer/nonfinite/layout failure, little-endian bits and signed-zero parity. checks/ contains passed receipts and fresh metadata-only environment inspection. No pytest/full repository test suite or real capture has been run.
