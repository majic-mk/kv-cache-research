"""Standard-library tests with isolated dummy children, never real admission."""
import json,os,resource,signal,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
import common,guard
class GuardTests(unittest.TestCase):
    def caps(self,**kw):
        value=dict(common.LIMITS,wall_seconds=5,cpu_process_tree_seconds=60,output_bytes=1048576);value.update(kw);return value
    def run_dummy(self,script,**caps):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)
            return guard.supervise([sys.executable,'-c',script],out,dict(os.environ),self.caps(**caps),{'accept_unobservable_cgroup_ceiling':True})
    def test_missing_admission(self):
        with tempfile.TemporaryDirectory() as d,patch.object(common,'PACKET',Path(d)),patch.object(common,'packet_integrity',return_value='fixture'):
            with self.assertRaises(FileNotFoundError):common.admission()
    def test_admission_rejects_changed_claims(self):
        a={'decision':'ADMIT_ONE_JOINT_VALUE_STAGE_A_CAPTURE','packet_manifest_sha256':'fixture','review_accepted':True,'parent_authorized':True,'max_runs':1,'stage_B_preparation_reviewed':True,'limits':dict(common.LIMITS)}
        self.assertEqual(common.validate_admission(a,'fixture'),a)
        for k,v in [('decision','old_run'),('packet_manifest_sha256','other'),('review_accepted',False),('parent_authorized',False),('max_runs',2),('stage_B_preparation_reviewed',False),('limits',{})]:
            with self.subTest(k=k),self.assertRaises(RuntimeError):common.validate_admission(dict(a,**{k:v}),'fixture')
    def test_claim_exclusive_no_retry(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture_claim.json';common.write_json(p,{'max_runs':1})
            with self.assertRaises(FileExistsError):common.write_json(p,{'max_runs':1})
    def test_lower_inherited_cpu_preserved(self):
        self.assertEqual(guard.child_cpu_limit((120,180)),120);self.assertEqual(guard.child_cpu_limit((-1,-1)),240)
    def test_cgroup_unobservable_fail_closed(self):
        with self.assertRaises(RuntimeError):common.check_cgroups({'visibility':'unavailable','ancestors':[]},{})
    def test_cgroup_lower_known_ceiling_not_waived(self):
        with self.assertRaises(RuntimeError):common.check_cgroups({'visibility':'exposed','ancestors':[{'memory.max':'10000','memory.current':'0'}]},{'accept_unobservable_cgroup_ceiling':True})
    def test_clean_dummy_exit(self):
        r=self.run_dummy('print("dummy only")')
        self.assertEqual(r['exit_code'],0);self.assertIsNone(r['termination']);self.assertTrue(r['cleanup']['all_absent']);self.assertGreater(r['child_high_water_rss_bytes'],0)
    def test_failed_dummy_exit_and_cleanup(self):
        r=self.run_dummy('raise RuntimeError("dummy failure")')
        self.assertNotEqual(r['exit_code'],0);self.assertTrue(r['cleanup']['all_absent'])
    def test_wall_limit_terminates_group(self):
        r=self.run_dummy('import time;time.sleep(20)',wall_seconds=.12)
        self.assertIn('wall_limit',r['termination']);self.assertTrue(r['cleanup']['all_absent'])
    def test_orphan_descendant_reaped(self):
        r=self.run_dummy('import subprocess,sys;subprocess.Popen([sys.executable,"-c","import time;time.sleep(20)"])')
        self.assertTrue(r['cleanup']['all_absent']);self.assertGreaterEqual(len(r['cleanup']['reaped']),2)
    def test_aggregate_cpu_limit(self):
        cap=guard.usage_cpu(resource.RUSAGE_SELF)+.12
        r=self.run_dummy('while True: pass',cpu_process_tree_seconds=cap)
        self.assertIn('cpu_limit',r['termination']);self.assertTrue(r['cleanup']['all_absent'])
    def test_output_limit_including_terminal_receipt(self):
        r=self.run_dummy('import sys;sys.stdout.write("x"*200000);sys.stdout.flush()',output_bytes=300000)
        self.assertIsNone(r['termination'])
        # Nonzero evidence reserve breaches are caught before the terminal receipt.
        r=self.run_dummy('import sys;sys.stdout.write("x"*210000);sys.stdout.flush()',output_bytes=262144)
        self.assertIn('output',r['termination'])
    def test_final_wait4_hwm_even_if_samples_miss_peak(self):
        real=guard.group_processes
        def hide_memory(pgid):return [dict(x,rss_bytes=0,hwm_bytes=0) for x in real(pgid)]
        with patch.object(guard,'group_processes',side_effect=hide_memory):
            r=self.run_dummy('x=bytearray(64*1024*1024)',rss_process_tree_bytes=48*1024*1024)
        self.assertEqual(r['termination'],'final_child_hwm_limit');self.assertTrue(r['cleanup']['all_absent'])
    def test_parent_death_kills_owned_child(self):
        packet=str(Path(__file__).resolve().parent)
        script='import os,subprocess,sys,time;sys.path.insert(0,'+repr(packet)+');from guard import setup_child;p=os.getpid();c=subprocess.Popen([sys.executable,"-c","import time;time.sleep(20)"],preexec_fn=lambda:setup_child(p));print(c.pid,flush=True);time.sleep(20)'
        parent=subprocess.Popen([sys.executable,'-c',script],stdout=subprocess.PIPE,text=True,start_new_session=True);pid=None
        try:
            import select
            self.assertTrue(select.select([parent.stdout],[],[],3)[0]);pid=int(parent.stdout.readline())
            parent.kill();parent.wait(timeout=2);deadline=time.monotonic()+2
            while any(x['state']!='Z' for x in guard.group_processes(pid)) and time.monotonic()<deadline:time.sleep(.01)
            self.assertFalse(any(x['state']!='Z' for x in guard.group_processes(pid)))
            # Supervisor tests enabled subreaper, so reap the adopted fixture too.
            try:os.waitpid(pid,0)
            except ChildProcessError:pass
        finally:
            if parent.poll() is None:parent.kill();parent.wait()
            parent.stdout.close()
            if pid is not None:
                try:os.killpg(pid,signal.SIGKILL)
                except ProcessLookupError:pass
if __name__=='__main__':unittest.main()
