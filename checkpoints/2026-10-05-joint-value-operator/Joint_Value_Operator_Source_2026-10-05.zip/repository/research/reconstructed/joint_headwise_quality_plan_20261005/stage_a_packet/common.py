"""Stage A constants, metadata-only integrity and resource checks. No Torch import."""
from pathlib import Path
import hashlib, json, os, shutil, time
PACKET = Path(__file__).resolve().parent
ROOT = PACKET.parents[3]
OLD = ROOT/'research/reconstructed/certified_selector_screen_20261005/temporal_packet'
ASSETS = ROOT/'outputs/revision_cpu_model_assets_20261004'
PYTHON = ROOT/'research/reconstructed/runtime_recovery_20261004/.venv/bin/python'
OUT = PACKET/'run'
LAYERS = (0, 7, 14, 21, 28, 35)
CHUNKS = ((0,128),(128,256),(256,384),(384,512),(512,528))
LIMITS = {'cpu_process_tree_seconds':240, 'wall_seconds':180, 'rss_process_tree_bytes':3221225472,
          'minimum_host_available_bytes':2000000000, 'output_bytes':67108864}
PROPOSAL_SHA = '13e9accfc36a054a4935f00e77f24efc05d65dad22260ae02b955fc5f8350ef3'
CONFIG_SHA = 'a24b20825813b7b3f195585f19ab878ca0afde2db6445d3037ab17eed83b28f9'
TOKEN_SHA = '27d8af446010f34bc39a8f16d63ae97e1857e5e61aba2398b10b197f5479966b'
def require(ok, msg):
    if not ok: raise RuntimeError(msg)
def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(1024*1024): h.update(b)
    return h.hexdigest()
def read_json(path): return json.loads(Path(path).read_text())
def write_json(path, value):
    with Path(path).open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def host_available():
    return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def evidence_bytes(out=OUT):
    return sum(x.stat().st_size for x in out.rglob('*') if x.is_file()) if out.exists() else 0
def cgroup_limits():
    mounts=[]
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        if ' - cgroup2 ' in line:
            parts=line.split(' - ',1)[0].split(); mounts.append((Path(parts[4]),parts[3]))
    relative=next((x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')),None)
    rows=[]
    for mount, root in mounts:
        if relative is None: continue
        rel=os.path.relpath(relative, root)
        if rel.startswith('..'): continue
        leaf=mount/rel
        while True:
            row={'path':str(leaf)}
            for name in ('memory.max','memory.current','memory.high','cpu.max'):
                f=leaf/name
                if f.is_file(): row[name]=f.read_text().strip()
            rows.append(row)
            if leaf==mount or mount not in leaf.parents: break
            leaf=leaf.parent
    return {'visibility':'exposed' if any('memory.max' in x for x in rows) else 'unavailable','ancestors':rows}
def check_cgroups(cgroups, admission_record):
    if cgroups['visibility']=='unavailable':
        require(admission_record.get('accept_unobservable_cgroup_ceiling') is True,
                'Fresh root acceptance of unavailable cgroup ceiling required')
    for row in cgroups['ancestors']:
        maximum=row.get('memory.max','max')
        if maximum!='max':
            require(int(maximum)>=LIMITS['rss_process_tree_bytes'],'Exposed cgroup ceiling below Stage A envelope')
            require(int(maximum)-int(row.get('memory.current','0'))>=LIMITS['minimum_host_available_bytes'], 'Exposed cgroup available capacity below floor')
def metadata_integrity():
    for x in read_json(PACKET/'EXTERNAL_PINS.json')['files']:
        p=ROOT/x['path']
        require(p.is_file() and p.stat().st_size==x['bytes'] and sha_file(p)==x['sha256'], 'External metadata/source changed: '+x['path'])
    require(sha_file(PACKET.parent/'TWO_STAGE_PROPOSAL.md')==PROPOSAL_SHA,'Proposal pin')
    require(sha_file(PACKET.parent/'PROPOSED_CONFIG.json')==CONFIG_SHA,'Config pin')
    require(read_json(PACKET.parent/'PROPOSED_CONFIG.json')['proposed_guards']['stage_A']==LIMITS,'Authoritative Stage A caps')
    require(sha_file(PACKET/'token_ids.json')==TOKEN_SHA,'Exact token bytes')
    ids=read_json(PACKET/'token_ids.json')
    raw=read_json(ASSETS/'config.json')
    require(len(ids)==528 and all(type(x) is int and 0<=x<raw['vocab_size'] for x in ids),'Exact 528 IDs')
    for x in read_json(PACKET/'asset_expected.json')['shards']:
        p=ASSETS/x['path']; require(p.is_file() and p.stat().st_size==x['bytes'],'Shard metadata unavailable: '+x['path'])
    # Historical tensors are metadata-only at preparation/preflight; no payload hashing here.
    for x in read_json(PACKET/'OLD_TENSOR_PINS.json')['files']:
        p=OLD/'run'/x['path']; require(p.is_file() and p.stat().st_size==x['bytes'],'Old parity tensor missing')
    return {'tokens':len(ids),'metadata_source_checks':'PASS','shard_payload_read':False,'old_tensor_payload_read':False}
def packet_integrity():
    for x in read_json(PACKET/'FROZEN_FILES.json')['files']:
        p=PACKET/x['path']
        require(p.is_file() and p.stat().st_size==x['bytes'] and sha_file(p)==x['sha256'],'Packet changed: '+x['path'])
    metadata_integrity()
    return sha_file(PACKET/'FROZEN_FILES.json')
def validate_admission(a, digest):
    require(a.get('decision')=='ADMIT_ONE_JOINT_VALUE_STAGE_A_CAPTURE','No explicit Stage A admission')
    require(a.get('packet_manifest_sha256')==digest,'Admission binds another packet')
    require(a.get('review_accepted') is True and a.get('parent_authorized') is True,'Independent review and root admission required')
    require(type(a.get('max_runs')) is int and a['max_runs']==1,'Exactly one capture permitted')
    require(a.get('stage_B_preparation_reviewed') is True,'Stage B feasibility preparation must be reviewed before capture')
    require(a.get('limits')==LIMITS,'Admission may not expand frozen caps')
    return a
def admission():
    require(__debug__,'Optimized Python forbidden')
    digest=packet_integrity()
    return digest, validate_admission(read_json(PACKET/'ADMISSION.json'),digest)
def check_live(deadline):
    require(time.monotonic()<deadline,'Stage A wall deadline')
    require(host_available()>=LIMITS['minimum_host_available_bytes'],'Host available below 2GB')
    require(evidence_bytes()<=LIMITS['output_bytes'],'Stage A evidence exceeds 64MiB')
    require(shutil.disk_usage(PACKET).free>=LIMITS['output_bytes'],'Insufficient free space for bounded evidence')
