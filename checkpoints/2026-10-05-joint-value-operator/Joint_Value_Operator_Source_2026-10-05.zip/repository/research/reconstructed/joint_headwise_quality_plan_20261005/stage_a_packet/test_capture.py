"""Small synthetic native attention only; no checkpoint weights or model calls."""
import tempfile,types,unittest
from pathlib import Path
import numpy as np
import torch
from transformers import Qwen3Config
from transformers.models.qwen3 import modeling_qwen3 as qwen
from transformers.cache_utils import DynamicCache
from capture import InterfaceCapture
from collector import Collector
from tensor_io import bf16_bits,write_array,exact_parity
class CaptureTests(unittest.TestCase):
    def test_argument_result_identity(self):
        values=[object() for _ in range(7)];seen=[];answer=object()
        def original(*args,**kwargs):
            self.assertTrue(all(a is b for a,b in zip(args,values[:6])))
            self.assertIs(kwargs['scaling'],values[6]);return answer
        module=types.SimpleNamespace(eager_attention_forward=original)
        with InterfaceCapture(module,lambda *a:seen.append(a)):
            self.assertIs(module.eager_attention_forward(*values[:6],scaling=values[6]),answer)
        self.assertIs(module.eager_attention_forward,original)
        self.assertIs(seen[0][1],values[1])
    def test_exception_restores(self):
        def original(*args,**kwargs):raise ValueError('synthetic')
        module=types.SimpleNamespace(eager_attention_forward=original)
        with self.assertRaises(ValueError):
            with InterfaceCapture(module,lambda *a:None):module.eager_attention_forward(*([None]*5))
        self.assertIs(module.eager_attention_forward,original)
    def test_callback_exception_restores(self):
        def original(*args,**kwargs):self.fail('must not execute')
        def callback(*args):raise ValueError('synthetic')
        module=types.SimpleNamespace(eager_attention_forward=original)
        with self.assertRaises(ValueError):
            with InterfaceCapture(module,callback):module.eager_attention_forward(*([None]*5))
        self.assertIs(module.eager_attention_forward,original)
    def test_native_three_chunk_qkv_parity(self):
        torch.manual_seed(907)
        config=Qwen3Config(hidden_size=32,intermediate_size=48,num_hidden_layers=1,num_attention_heads=4,num_key_value_heads=2,head_dim=8,max_position_embeddings=64,rope_theta=10000)
        config._attn_implementation='eager'
        attention=qwen.Qwen3Attention(config,layer_idx=0).to(torch.bfloat16).eval()
        rotary=qwen.Qwen3RotaryEmbedding(config)
        hidden=torch.randn(1,6,32,dtype=torch.bfloat16)
        chunks=((0,2),(2,4),(4,6))
        collector=Collector(lambda:None,layers=(0,),chunks=chunks,nlayers=1,qheads=4,kvheads=2,dim=8,calibration=(2,4),holdout=(4,6))
        baseline_cache=DynamicCache(config=config);capture_cache=DynamicCache(config=config)
        values=[];direct_queries=[];direct_keys=[]
        with torch.inference_mode():
            for lo,hi in chunks:
                h=hidden[:,lo:hi];rope=rotary(h,torch.arange(lo,hi).unsqueeze(0))
                allowed=torch.arange(hi)[None,:]<=torch.arange(lo,hi)[:,None]
                mask=torch.zeros(1,1,hi-lo,hi,dtype=torch.bfloat16).masked_fill(~allowed,torch.finfo(torch.bfloat16).min)
                q=attention.q_norm(attention.q_proj(h).view(1,hi-lo,4,8)).transpose(1,2)
                k=attention.k_norm(attention.k_proj(h).view(1,hi-lo,2,8)).transpose(1,2)
                q,k=qwen.apply_rotary_pos_emb(q,k,*rope)
                direct_queries.append(q[0].transpose(0,1));direct_keys.append(k[0].transpose(0,1))
                values.append(attention.v_proj(h).view(1,hi-lo,2,8)[0])
                baseline=attention(h,rope,mask,past_key_values=baseline_cache)[0]
                collector.begin(lo,hi)
                with InterfaceCapture(qwen,collector) as cap:
                    self.assertIs(qwen.ALL_ATTENTION_FUNCTIONS.get_interface('eager',qwen.eager_attention_forward),cap.wrapper)
                    observed=attention(h,rope,mask,past_key_values=capture_cache)[0]
                collector.finish();self.assertTrue(torch.equal(baseline,observed))
        collector.complete();t=collector.trace[0]
        self.assertTrue(np.array_equal(bf16_bits(t['query_calibration']),bf16_bits(direct_queries[1])))
        self.assertTrue(np.array_equal(bf16_bits(t['query']),bf16_bits(direct_queries[2])))
        self.assertTrue(np.array_equal(bf16_bits(t['keys']),bf16_bits(torch.cat(direct_keys))))
        self.assertTrue(np.array_equal(bf16_bits(t['values']),bf16_bits(torch.cat(values))))
        self.assertEqual(len(collector.mask_rows),3)
    def fixture(self):
        c=Collector(lambda:None,layers=(0,),chunks=((0,2),),nlayers=1,qheads=4,kvheads=2,dim=8,calibration=(0,2),holdout=(2,4));c.begin(0,2)
        args=[types.SimpleNamespace(layer_idx=0,num_key_value_groups=2),torch.zeros(1,4,2,8,dtype=torch.bfloat16),torch.zeros(1,2,2,8,dtype=torch.bfloat16),torch.zeros(1,2,2,8,dtype=torch.bfloat16),torch.tensor([[[[0.,-float('inf')],[0.,0.]]]],dtype=torch.bfloat16),(),{'scaling':8**-.5,'dropout':0.,'sliding_window':None}]
        return c,args
    def test_causal_future_rejected(self):
        c,a=self.fixture();a[4].zero_()
        with self.assertRaisesRegex(RuntimeError,'Future positions'):c(*a)
    def test_missing_layer_rejected(self):
        c,_=self.fixture()
        with self.assertRaisesRegex(RuntimeError,'Incomplete native'):c.finish()
    def test_nonfinite_calibration_rejected(self):
        c,a=self.fixture();a[1].fill_(float('nan'))
        with self.assertRaisesRegex(RuntimeError,'Finite calibration'):c(*a)
    def test_value_layout_rejected(self):
        c,a=self.fixture();a[3]=torch.zeros(1,4,2,8,dtype=torch.bfloat16)
        with self.assertRaisesRegex(RuntimeError,'K/V cache layout'):c(*a)
    def test_portable_bits_and_parity_including_signed_zero(self):
        t=torch.tensor([[[0.,-0.,1.,-2.]]],dtype=torch.bfloat16)
        current={'query':t,'keys':t}
        self.assertTrue(exact_parity(current,dict(current))['query_bitwise'])
        wrong={'query':t.clone(),'keys':t};wrong['query'][0,0,1]=0.
        with self.assertRaisesRegex(RuntimeError,'Q BF16-bit'):exact_parity(current,wrong)
        with tempfile.TemporaryDirectory() as d:
            row=write_array(d,'calibration/layer_00/query.npy',t,(0,1),'calibration_query')
            got=np.load(Path(d)/row['path'],allow_pickle=False)
            self.assertEqual(got.dtype.str,'<u2');self.assertEqual(got[0,0,1],0x8000)
            self.assertTrue(np.array_equal(got,bf16_bits(t)))
            with self.assertRaises(FileExistsError):write_array(d,row['path'],t,(0,1),'calibration_query')
if __name__=='__main__':
    torch.set_num_threads(1);torch.set_num_interop_threads(1);unittest.main()
