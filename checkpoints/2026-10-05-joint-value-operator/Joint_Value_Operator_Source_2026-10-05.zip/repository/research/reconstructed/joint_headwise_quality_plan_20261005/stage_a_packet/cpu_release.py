"""Fresh Stage A release. Historical release flags are deliberately not imported."""
import os
from common import admission, require
def require_cpu_release():
    admission()
    require(os.environ.get('JOINT_VALUE_GUARD_PID')==str(os.getppid()),'Owned Stage A guard required')
    require(os.environ.get('JOINT_VALUE_STAGE_A_RUN')=='ONE_EXPLICITLY_ADMITTED_CAPTURE','Stage A capture is not released')
