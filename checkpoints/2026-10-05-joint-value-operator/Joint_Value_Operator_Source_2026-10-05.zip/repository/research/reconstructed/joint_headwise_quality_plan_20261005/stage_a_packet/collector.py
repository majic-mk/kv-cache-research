"""Transparent callback validator and snapshots; no module-level model imports."""
import hashlib
from common import require, LAYERS, CHUNKS

class Collector:
    def __init__(self,check,*,layers=LAYERS,chunks=CHUNKS,nlayers=36,qheads=32,kvheads=8,dim=128,calibration=(496,512),holdout=(512,528)):
        self.check=check;self.layers=tuple(layers);self.chunks=tuple(chunks);self.nlayers=nlayers
        self.qheads=qheads;self.kvheads=kvheads;self.dim=dim;self.calibration=calibration;self.holdout=holdout
        self.trace={};self.calls={x:0 for x in range(nlayers)};self.seen=[];self.mask_rows=[];self.call_index=-1;self.mask_digest=None
    def begin(self,lo,hi):
        self.call_index+=1
        require(self.call_index<len(self.chunks) and (lo,hi)==self.chunks[self.call_index],'Frozen chunk order')
        self.start,self.end=lo,hi;self.seen=[];self.mask_digest=None
    def finish(self): require(self.seen==list(range(self.nlayers)),'Incomplete native layer traversal')
    def complete(self):
        require(self.call_index+1==len(self.chunks),'Incomplete chunk sequence')
        require(all(v==len(self.chunks) for v in self.calls.values()),'Every native layer must execute once per call')
        require(set(self.trace)==set(self.layers),'Missing selected layer')
        require(all(set(v)=={'query_calibration','query','keys','values'} for v in self.trace.values()),'Missing capture field')
    def __call__(self,module,q,k,v,mask,args,kwargs):
        import torch
        self.check();layer=int(module.layer_idx)
        require(layer==len(self.seen) and layer<self.nlayers,'Every native layer must execute once in order')
        self.seen.append(layer);self.calls[layer]+=1
        require(q.dtype==k.dtype==v.dtype==torch.bfloat16,'Native BF16 capture')
        require(q.device.type==k.device.type==v.device.type=='cpu','Native CPU only')
        require(tuple(q.shape)==(1,self.qheads,self.end-self.start,self.dim),'Native Q layout')
        require(tuple(k.shape)==tuple(v.shape)==(1,self.kvheads,self.end,self.dim),'Native K/V cache layout before GQA repeat')
        require(module.num_key_value_groups==self.qheads//self.kvheads,'Native GQA mapping')
        require(kwargs.get('scaling')==self.dim**-.5 and kwargs.get('dropout')==0. and kwargs.get('sliding_window') is None,'Native attention arguments')
        require(mask is not None and tuple(mask.shape)==(1,1,self.end-self.start,self.end),'Native causal-mask shape')
        require(mask.device.type=='cpu' and mask.dtype in (torch.bfloat16,torch.float32),'Native mask dtype/device')
        # Validate all causal positions, not only captured rows. No input mutation.
        allowed=torch.arange(self.end)[None,:]<=torch.arange(self.start,self.end)[:,None]
        flat=mask[0,0]
        require(bool((flat[allowed]==0).all()),'Allowed causal positions must have zero mask')
        blocked=flat[~allowed]
        require(bool(((blocked==torch.finfo(mask.dtype).min)|torch.isneginf(blocked)).all()),'Future positions must be masked')
        digest=hashlib.sha256(mask.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
        if self.mask_digest is None:
            self.mask_digest=digest
            self.mask_rows.append({'start':self.start,'end':self.end,'shape':list(mask.shape),'dtype':str(mask.dtype),'sha256':digest,'causal_positions_verified':True})
        require(digest==self.mask_digest,'Causal mask identity changed across layers')
        if layer not in self.layers: return
        if self.end==self.calibration[1]:
            require(self.start<=self.calibration[0],'Calibration not contained in frozen prefix call')
            require(layer not in self.trace,'Duplicate calibration capture')
            qq=q[0,:,self.calibration[0]-self.start:].transpose(0,1).detach().clone().contiguous()
            require(tuple(qq.shape)==(self.calibration[1]-self.calibration[0],self.qheads,self.dim),'Calibration shape')
            require(bool(torch.isfinite(qq).all()),'Finite calibration Q')
            self.trace[layer]={'query_calibration':qq}
        if (self.start,self.end)==self.holdout:
            require(layer in self.trace and set(self.trace[layer])=={'query_calibration'},'Missing calibration or duplicate holdout')
            for name,t in [('query',q),('keys',k),('values',v)]:
                copied=t[0].transpose(0,1).detach().clone().contiguous()
                require(bool(torch.isfinite(copied).all()),'Finite '+name)
                self.trace[layer][name]=copied
