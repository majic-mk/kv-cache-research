# Two-stage real-tensor proposal: joint versus headwise V rounding

2026-10-05 UTC. **Proposal only. No new model call, tensor-weight payload read, optimization run or timing experiment has been performed.** This supersedes the one-layer sketch in PLAN.md. PROPOSED_CONFIG.json fixes the proposed population and choices; it is not an executable release. Implementation hashes and independent protocol/guard review are still required.

## Recommendation

Prepare one bounded capture and one bounded operator-error comparison, conditional on the stronger projected control passing an independent tiny-Hessian check. Use all six previously selected layers and every head/channel. A successful result would identify local natural-tensor headroom worth further study. It would not establish autoregressive quality, independent-task generalization, a new optimizer, or a serving speedup.

The current engineering result is only exact compact-CD equivalence. The earlier N4/D2 frozen quality gate remains failed and is not reused here.

## Source distinction and novelty risk

[OptR Eq.15–16](https://arxiv.org/html/2608.02691v1#S4.SS4) averages squared projected errors of individual query heads. The [author implementation at commit66d4656](https://github.com/daniel-eai/Output-Aware-INT2-KV-Cache-Quantization/blob/66d46561b9bdf5d715f591e0f5845a4cbd927dee/optr/calibrate_optr.py#L83-L113) squares each head contribution before averaging. No independence theorem or assertion that cross-head terms vanish was found. This is a legitimate proxy.

The proposed headwise-CD arm is **OptR-inspired objective control**, not an OptR reproduction: it does not learn rotations, quantize K, reproduce training or amortize offline calibration. Full author OptR and matrix-free AdaRound-style optimization remain necessary before claiming a better practical method. [QuantEase](https://arxiv.org/html/2309.01885v2) already provides discrete coordinate optimization with cached sufficient statistics. Exact Gram CD is a strong enabling implementation; changing the loss alone remains weak novelty.

## A. One same-trajectory public capture

### Fixed input and native execution

Reuse the existing public Alice Chapter I token file, exactly IDs0:528, with no re-tokenization, chat template or special tokens. Token-file SHA256:

    27d8af446010f34bc39a8f16d63ae97e1857e5e61aba2398b10b197f5479966b

Model: Qwen/Qwen3-4B-Instruct-2507, revision cdbee75f17c01a7cc42f958dc650907174af0554. Native config has36 layers,32 query heads,8 KV heads, head dimension128, output dimension2560 and GQA group size4. Retain the exact existing native CPU BF16 code/config/runtime pins, deterministic mode, four intra-op threads, one inter-op thread and five teacher-forced chunks:0:128,128:256,256:384,384:512,512:528. Every layer executes; only layers0,7,14,21,28,35 are persisted. No generated continuation or model modification.

Capture at the same native attention interface:
- Post-normalization/post-RoPE Q496:512, all32 heads
- Q512:528 and K0:528 again, all heads, solely to verify bitwise parity with every tensor of the old six-layer packet
- Native V0:528, all8 KV heads, before GQA repetition
- Positions, causal-mask identity, native scaling, dtype/layout and exact source hashes

At the384:512 callback, copy the last16 queries. At512:528, copy the full value cache and the old Q/K parity fields. Require finite values and exact expected shapes, and verify every native layer is visited once per call. Any parity mismatch, missing layer or changed source pin stops the packet. Do not substitute approximate equality or use the new trajectory after a mismatch.

### Portable artifacts and read isolation

Save BF16 bit patterns as little-endian uint16 NumPy arrays plus explicit dtype/shape metadata. Split calibration and future query files. This permits later NumPy-only replay without loading Torch. New capture payload including duplicate parity Q/K is14,548,992 bytes across six layers; V plus new calibration Q alone is7,274,496 bytes. Preserve the old packet unchanged.

No extra8-GB checkpoint copy or model download is needed. Existing local shards are reused. W_o is an external pinned dependency: one selected20-MiB BF16 tensor at a time, with header, offset, size and tensor-segment hash recorded. Stage B reads all six selected tensors once for encoding and once for evaluation:240MiB total payload reads, no all-layer W_o allocation.

The existing pager hashes all three shards before inference. Its previous receipt records8,044,982,000 source-file bytes and37,111,462,912 paged tensor-read bytes; these are separate passes, so the prior logical source reads were at least45,156,444,912 bytes, excluding header/activation reads. Source hashing and actual pager I/O must be counted again. No claim that “reuse existing weights” makes acquisition free.

### Proposed capture guard, not a timing promise

Proposed maximum:240 aggregate process-tree CPU seconds,180 wall seconds,3GiB process-tree RSS, at least2,000,000,000 host-available bytes,64MiB output. Inspect current host/cgroup limits before release; do not inherit the old run's cgroup waiver. A guard must terminate and reap its owned process group, record sampled and child high-water RSS, and verify cleanup. No automatic retry or resource extension.

The prior capture had44.9729s guarded wall time,28.9924s inside its five calls,8.0954s pager setup and2,103,783,424B sampled process-tree peak RSS. These are historical receipts, not forecasts for the modified capture. Stage A releases the model/cache and exits before Stage B starts.

## B. Same-grid, all-layer local operator comparison

### Fixed population, causal split and format

- Layers0,7,14,21,28,35; every query head0:32, KV head0:8 and channel0:128
- Compression boundary512; calibration queries496:512 only; holdout queries512:528 only
- Prefix sink0:64 and recent256:512 stay BF16; only192 tokens64:256 are INT2
- All later values512:528 remain exact; K stays BF16 in every arm
- Identity rotation; one affine scalar four-level grid per token/KV row, shared by its128 channels
- Grid fixed once from original V: absolute clipping order statistic117 (zero-based) of128 values; clip symmetrically; scale=FP32(max(max_clipped−min_clipped,1e−8)/3), zero=FP32(−min_clipped/scale); code0..3; FP64 evaluator decodes scale*(code−zero)
- Nearest uses floor(V/scale+zero+0.5), clipped to0..3. All arms start with these codes
- Same per-row squared-error constraint: <=1.25 times that row's nearest SSE, against the original un-clipped BF16 values. A zero nearest SSE permits zero error only. The fixed grid and guard are never tuned from results

This is a source-inspired grid carrier, not bit-exact reproduction of an OptR fused decoder. FP64 uses exact captured BF16 inputs and fixed FP32 metadata; no native BF16 attention-output equivalence is claimed.

Per-layer V prefix storage:49,152B packed codes +12,288B FP32 scale/zero +655,360B protected BF16 values =716,800B (700KiB), versus1,048,576B uncompressed. With unchanged BF16 K, combined prefix KV falls from2,097,152B to1,765,376B, only15.82%. Exact suffix V adds32KiB equally to both; suffix K is also equal. Report this short-prefix footprint rather than a long-context2-bit claim. Decoder scratch and encoder tensors are separate.

### Three objectives

Let E_g=Vhat_g−V_g on active rows, P_j be the calibration attention restricted to these rows, and W_j the signed128-by2560 output block. Define r_j=P_j E_g W_j.

    Headwise:    L_head  = sum_j ||r_j||_F²
    Group-joint: L_group = sum_g ||sum_(j in g) r_j||_F²
    Full-joint:  L_full  = ||sum_j r_j||_F²

Always evaluate all arms with L_full. Save L_head, the within-group signed cross term L_group−L_head, and the between-group term L_full−L_group, on calibration and holdout. These differences can be negative.

For full-joint optimization, every group update sees the current error from every other quantized group. There is one global residual. Compact sufficient statistics are reconciled into it before advancing to another KV group. Independent per-group optimization would instead implement L_group and is not labeled full-joint.

Attention probabilities must be recomputed from all causally available keys: calibration query t attends0:t inclusive, and future query t includes the exact suffix keys512:t in the softmax denominator. Only active old-value errors enter residual differences. Never renormalize probabilities over only the192 compressed rows.

### Required arms and schedule

1. Original-value FP64 operator reference
2. Fixed-grid nearest
3. OptR-inspired headwise compact CD
4. Within-KV-group joint compact CD
5. Full-layer joint compact CD
6. Ordinary token-axis GPTQ with raw and cap-guarded trajectories
7. Full-projected conditional blocked Newton/GPTQ described below

CD uses channel blocks0:4,4:8,...124:128, KV groups0..7, channels ascending within each block, then tokens64..255. Candidate codes are0,1,2,3; choose the feasible minimum of the arm's exact scalar quadratic. Keep current code on a tie; otherwise choose the lowest tied code. Full/group/headwise CD have identical visitation and feasibility rules. Reconcile after each channel/KV group.

The ordinary token-axis control uses the shared-group attention Gram sum_j P_j^T P_j (192-by192), fixed token order, and source-style damping0.01 times mean diagonal. Quantize128 channels together at each token. The guarded trajectory falls back to that token's nearest128-channel vector if its proposed row exceeds the cap, and feeds the actual accepted vector into subsequent compensation. Save a separate ordinary raw trajectory; it is reported but ineligible for a same-cap superiority claim. Charge both paths. It is a weaker objective control, not a substitute for the projected arm.

### Projected blocked conditional Newton/GPTQ

Use fixed4-token by4-channel blocks within one KV group:16 code variables. Process channel block, KV group, then token blocks64:68,...252:256. This is **not exact global GPTQ** and not globally optimal rounding.

For the current group/channel block, stack the16 W rows (four heads times four channels) as B, form C=B B^T and S=R B^T from the current full-layer residual. A coordinate's compact update has entries P_j[:,i] in the matching channel positions. Exact block Hessian entries are

    H_value[(i,c),(k,d)]
      = sum_(j,j' in group) dot(P_j[:,i],P_j'[:,k]) * dot(W_j[c,:],W_j'[d,:]).

Cache attention token-block Grams across channel blocks, and W-row Grams across token blocks. Do not construct an [m*2560,16] dense design or reproject the full residual at every token block.

In code space, let D=diag(the16 fixed scales), H=D H_value D, g=D J_value^T R, and q0=current16 codes. With lambda=.01*mean(diag(H)), set

    A=H+lambda I,       z*=q0−A^(-1)g.

This minimizes the local damped quadratic around q0. If trace(H)=0 exactly, require g=0 under a separately frozen numerical consistency check and keep the block; if g=0, also keep current codes. Factor A with a fixed positive-definite procedure; nonfinite values or unexpected factor failure stop the arm without retuning damping.

For numerical scaling use mu=mean(diag(H)), M=H/mu+.01 I and z*=q0−solve(M,g/mu), algebraically the same target. For PSD H, condition(M)<=1601 at16 variables. Let U be upper triangular with U^T U=M^(-1), following the [pinned GPTQ inverse-Cholesky feedback convention](https://github.com/IST-DASLab/gptq/blob/2d65066eeb06a5c9ff5184d8cebdf33662c67faf/gptq.py#L91-L132). Starting from z*, round coordinate a and update all remaining continuous targets by

    z[a:] -= ((z[a]−q[a])/U[a,a]) * U[a,a:].

Produce two proposals using the same target/factor: ordinary raw rounding; and rounding to the nearest feasible code under the row cap, where feasibility is computed using already-finalized codes plus **remaining current discrete codes**, not the remaining continuous target. The current code is always feasible in this construction. Save both proposals and guard decisions; these raw proposals are not a fictional independent raw trajectory.

Evaluate each complete proposal with the exact **undamped** quadratic 2*delta^T g+delta^T H delta and final row caps. Among current and feasible proposals accept only a strict loss decrease, with fixed tie/numerical tolerance reviewed in the implementation. Update S through C, accumulate compact U_delta, then reconcile R += U_delta B after **every channel-block/KV-group**, before visiting the next group. No cross-group residual is discarded.

Independent preflight must compare H, g, conditional loss changes and feedback steps against an explicitly materialized tiny signed-GQA design, including nonzero background from another group. The solver is not released until that check and code-space scale/damping orientation are reviewed. This preflight itself needs admission; no such new test has been run.

### Encoder work and resource accounting

Use a proposed common1,200,000,000 logical-MAC upper budget per layer and encoder arm, including calibration QK acquisition, initialization, projected residuals, Gram preparation, factors, every proposal, updates and reconciliation. Reserve180,355,072 MACs per layer/arm for one final independent calibration-residual reconstruction before spending the iterative budget. Stop before the next complete channel-block/KV-group unit when its predeclared upper cost cannot fit. Count scalar rounding/cap operations, exponentials/sorts, solves and bytes separately. A MAC ledger does not equal CPU time or erase serial control-flow cost.

All required arms must finish at least one entire sweep across every active coordinate in every layer. Failure to do so is an incomplete budget test, not evidence that an omitted baseline lost. Report completed sweeps/units, unused budget, setup versus iterative work, actual aggregate CPU/wall time and peak scratch for every arm. Also retain one-sweep CODE checkpoints as matched-coordinate diagnostics; do not call equal sweeps equal work.

Calibration P may be computed once and reused within the study; report that physical shared cost once, while charging each standalone encoder arm the acquisition it would require in use. Nearest needs no calibration acquisition for encoding. Calibration acquisition is16 queries only, not the full512-square prefill matrix. It costs33,554,432 dense QK MACs per layer plus262,144 logits/softmax elements. Holdout acquisition separately costs34,603,008 MACs per layer plus270,336 logits. Historical Stage A inference, source hashing and attention reconstruction must appear separately from per-prefix encoding.

One full CD sweep has196,608 scalar decisions per layer,1,179,648 over six layers. The leading joint compact-CD sweep terms per layer are:
-50,331,648 MACs for active feature/Gram contractions
-167,772,160 MACs to project current residual into active channel rows
-167,772,160 MACs to reconcile all channel updates
-41,943,040 MACs for channel head-Gram preparation
-12,582,912 MACs for gradient dots, plus code/row-cap scalar work

These total440,401,920 MACs before extra bookkeeping and any reusable-feature choices. Initial projected residual construction adds180,355,072 MACs per layer. The implementation's complete ledger must include all duplicate contractions and update arithmetic rather than reusing this leading-term count as an exact runtime total. The separate conservative source audit totals about478 million MAC/vector-operation units per layer for full-joint CD and408 million for headwise CD; those larger bounds are the planning defaults until the executable ledger is audited. The five bounded encoder arms have an overall ceiling36 billion charged MAC-equivalents across six layers; evaluation is extra and must fit the same Stage B CPU cap. This is a work forecast, not a promised completion time.

A4-by4 projected-control sweep has12,288 blocks/layer,73,728 across six layers. Raw plus feasible feedback takes2,359,296 sequential16-coordinate decisions over six layers, before cap/acceptance logic. A separate source/algebra audit estimates0.94 billion MAC-equivalents per layer for one complete blocked sweep including calibration acquisition and initialization, or about1.12 billion with the reserved independent final reconstruction. Detailed conservative component counts are in BLOCK_CONTROL_AUDIT.md. Thus the1.2-billion work allowance has room for one sweep on paper; this does not establish CPU completion. Small factors are tractable; Python dispatch, scalar decisions and many16-square factorizations remain real risks. Do not launch an hours-long literal Python loop. A later source-frozen own compiled loop could be admitted if needed; compilation/install is not currently authorized. If the reviewed implementation cannot plausibly finish within the cap, report that blocker before Stage A rather than generate data for a known over-budget study.

Proposed Stage B maxima:240 aggregate process-tree CPU seconds,300 wall seconds,512MiB process-tree RSS,256MiB outputs, one BLAS thread. No inferred CPU latency or GPU speedup claim follows from operation counts. Incomplete/cap failure stops once with no layer dropping or automatic budget extension.

### Memory and weight-read plan

One layer at a time: W_o80MiB FP64, plus at most20MiB raw BF16 and40MiB transient FP32 conversion. Calibration P2MiB FP64; active values1.5MiB per copy; all per-head residuals10MiB; full residual320KiB; all attention token-block Grams0.75MiB; active W-row Gram/factor2KiB each. Optional all-block Hessian and inverse-factor caches are24MiB each and must be explicitly charged; the W-row Gram cache is0.5MiB. Do not retain dense full-token/head/channel Hessians, all-layer projections or the model. Keep code paths as uint8 plus compact flags and stream scalar diagnostics. A full residual history at every group/channel-block boundary would occupy480MiB across six layers, and tracked plus direct histories960MiB; neither is permitted. Recomputing the full residual at every such boundary adds about277 billion MACs, so verification is reserved once per final arm instead. Current codes, scales, row errors, traces and temporary arrays must appear in a live-allocation ledger before release.512MiB is a process limit, not just an array sum.

The joint variable count is196,608 per layer: a dense FP64 Hessian would be288GiB. The compact arm never constructs it. None of the projection directions are truncated; there is no uncounted low-rank approximation error.

### Holdout lock, measurements and proposed decision

Encode every arm for all six layers using calibration-only inputs. Persist final codes, one-sweep checkpoints, exact update paths/work counters and a locked manifest **before opening any future Q/K/V files for evaluation**. Evaluation then rereads W_o one layer at a time. It may not select a checkpoint, layer, budget, method variant or damping.

Save full-layer SSE for every layer/query/arm, calibration SSE, row SSE/cap status, headwise/group/full decomposition, nearest-normalized ratios and all raw/guard diagnostics. For comparisons to a zero-error baseline use0/0=1 and positive/0=+infinity, without epsilon. Report absolute errors alongside ratios. No misleading sample count: six layers and16 adjacent positions are correlated observations from one passage.

Proposed exploratory usefulness gate for full-joint CD:
1. At least10% lower mean of six layerwise nearest-normalized holdout SSEs than **each** of nearest, headwise CD, group-joint CD, guarded token GPTQ and guarded projected blocked GPTQ
2. Better holdout SSE than headwise CD in at least four of six layers
3. Every same-layer/same-query full-joint SSE <=1.25 times that query's nearest SSE; this is pointwise over the96 actual observations, not an all-attention guarantee
4. No invalid cap, missing arm, incomplete coverage, trajectory mismatch or resource failure

An evaluator-only strongest-control envelope may be shown but is not an executable policy. A calibration win with a heldout regression fails. Any failed gate closes this exact proposal, not all coupled rounding or every possible calibration distribution.

### Numerical and negative controls required before interpretation

Use a fresh tiny fixture, not the failed N4/D2 quality arrays: multiple shared-V groups, signed W_o, nonzero background, explicit full design/Hessian. Check block gradients/Hessians, damped target, both feedback paths and undamped acceptance. In mutually orthogonal output subspaces head/group/full objectives must agree. Include signed cancellation and one-hot/uniform attention to expose accidental omission of cross terms. These are algebra checks, not evidence of real-data quality or distributional robustness. All tolerances, fixture arrays and seeds must be frozen before their own admitted execution.

## What is still required before any execution

1. Complete the independent tiny-Hessian numerical check and implementation-level operation/scratch ledger. A source/algebra audit has accepted the formula and flagged timing/diagnostic hazards; no numerical preflight has run
2. Frozen implementation, portable tensor schema, numerical tolerances and all file hashes
3. Independently reviewed live process-tree resource guard and current capacity checks; no inherited authorization or cgroup waiver
4. Explicit root admission naming the exact Stage A/B packet and bounds

No new model inference or tensor-weight payload read is authorized by this document. A positive local operator result would still need independent public passages, untouched task families, actual OptR rotation calibration, stronger batched reconstruction optimizers and measured total serving cost before paper admission.
