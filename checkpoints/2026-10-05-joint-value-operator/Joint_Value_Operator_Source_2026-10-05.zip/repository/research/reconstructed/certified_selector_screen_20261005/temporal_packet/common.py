"""Model-free packet integrity and resource utilities."""
from pathlib import Path
import hashlib, json, os, shutil, time
PACKET=Path(__file__).resolve().parent
ROOT=PACKET.parents[3]
ASSETS=ROOT/'outputs/revision_cpu_model_assets_20261004'
PYTHON=ROOT/'research/reconstructed/runtime_recovery_20261004/.venv/bin/python'
OUT=PACKET/'run'
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def sha_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
def read_json(path):return json.loads(Path(path).read_text())
def write_json(path,value):
    path=Path(path)
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def host_available():
    return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def evidence_bytes():
    return sum(x.stat().st_size for x in OUT.rglob('*') if x.is_file()) if OUT.exists() else 0
def cgroup_limits():
    """Read exposed cgroup-v2 ancestors, or explicitly report unavailable."""
    mounts=[]
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        if ' - cgroup2 ' in line:
            before=line.split(' - ',1)[0].split()
            mounts.append((Path(before[4]),before[3]))
    relative=next((x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')),None)
    rows=[]
    for mount,root in mounts:
        if relative is None:continue
        rel=os.path.relpath(relative,root)
        if rel.startswith('..'):continue
        leaf=mount/rel
        while True:
            row={'path':str(leaf)}
            for name in ('memory.max','memory.current','memory.high','cpu.max'):
                f=leaf/name
                if f.is_file():row[name]=f.read_text().strip()
            rows.append(row)
            if leaf==mount:break
            if mount not in leaf.parents:break
            leaf=leaf.parent
    return {'visibility':'exposed' if any('memory.max' in x for x in rows) else 'unavailable','ancestors':rows}
def packet_integrity():
    manifest=read_json(PACKET/'FROZEN_FILES.json')
    for x in manifest['files']:
        path=PACKET/x['path']
        require(path.is_file() and path.stat().st_size==x['bytes'] and sha_file(path)==x['sha256'],'Packet changed: '+x['path'])
    return sha_file(PACKET/'FROZEN_FILES.json')
def admission():
    require(__debug__,'Optimized Python is forbidden')
    digest=packet_integrity()
    a=read_json(PACKET/'ADMISSION.json')
    require(a.get('decision')=='ADMIT_ONE_NEW_CPU_TEMPORAL_FEASIBILITY_RUN','No explicit new run admission')
    require(a.get('packet_manifest_sha256')==digest,'Admission binds another packet')
    require(a.get('review_accepted') is True and a.get('parent_authorized') is True,'Review and parent admission required')
    require(a.get('max_runs')==1,'Exactly one run permitted')
    return digest,a
def check_live(deadline):
    require(time.monotonic()<deadline,'600-second wall deadline')
    require(host_available()>=1500000000,'Host available below 1.5GB')
    require(evidence_bytes()<=100000000,'Evidence exceeds 100MB')
    require(shutil.disk_usage(PACKET).free>=1000000000,'Free disk below 1GB')
