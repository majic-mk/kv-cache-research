"""Independent one-shot resource guard. Requires absent-by-default ADMISSION.json."""
from pathlib import Path
import json,os,resource,signal,subprocess,sys,time
from common import *
def group_processes(pgid):
    found=[]
    for x in Path('/proc').iterdir():
        if not x.name.isdigit():continue
        try:
            fields=(x/'stat').read_text().split(') ',1)[1].split()
            if int(fields[2])==pgid and fields[0]!='Z':
                rss=int(next(a.split()[1] for a in (x/'status').read_text().splitlines() if a.startswith('VmRSS:')))*1024
                found.append((int(x.name),rss))
        except (OSError,ValueError,StopIteration):continue
    return found
def self_rss():
    return int(next(a.split()[1] for a in Path('/proc/self/status').read_text().splitlines() if a.startswith('VmRSS:')))*1024
def kill_owned(pgid):
    for sig in (signal.SIGTERM,signal.SIGKILL):
        if not group_processes(pgid):break
        try:os.killpg(pgid,sig)
        except ProcessLookupError:pass
        time.sleep(.25)
    return not group_processes(pgid)
def child_cpu_limit(prior):
    return min([2350]+[x for x in prior if x>=0])
def setup_child(guard_pid):
    os.setsid()
    import ctypes
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Could not bind parent-death kill')
    if os.getppid()!=guard_pid:os._exit(125)
    limit=child_cpu_limit(resource.getrlimit(resource.RLIMIT_CPU))
    resource.setrlimit(resource.RLIMIT_CPU,(limit,limit))
def interrupted(signum,frame):
    raise InterruptedError('Guard interrupted by signal '+str(signum))
def main():
    digest,a=admission()
    signal.signal(signal.SIGTERM,interrupted)
    signal.signal(signal.SIGINT,interrupted)
    require(Path(sys.executable).resolve()==PYTHON.resolve(),'Use pinned interpreter')
    require(not OUT.exists(),'Run directory already exists')
    require(not (PACKET/'RUN_CLAIM.json').exists(),'One-use claim already consumed')
    require(host_available()>=6000000000,'Preload reserve requires6GB available')
    require(shutil.disk_usage(PACKET).free>=1000000000,'Free disk below1GB')
    expected=read_json(PACKET/'asset_expected.json')
    for x in expected['shards']:
        f=ASSETS/x['path'];require(f.is_file() and f.stat().st_size==x['bytes'],'Pinned shard availability')
    # Never stop unrelated processes; competing model jobs block this launch.
    own={os.getpid(),os.getppid()}
    for x in Path('/proc').iterdir():
        if not x.name.isdigit() or int(x.name) in own:continue
        try:cmd=(x/'cmdline').read_bytes()
        except OSError:continue
        if b'python' in cmd and (b'actual_runner.py' in cmd or b'capture_runner.py' in cmd):
            raise RuntimeError('Competing model runner detected')
    inherited={name:list(resource.getrlimit(getattr(resource,name))) for name in ('RLIMIT_CPU','RLIMIT_AS','RLIMIT_DATA','RLIMIT_FSIZE')}
    for name in ('RLIMIT_AS','RLIMIT_DATA'):
        finite=[x for x in inherited[name] if x>=0]
        require(not finite or min(finite)>=5368709120,'Inherited '+name+' is below the declared RSS envelope')
    cgroups=cgroup_limits()
    if cgroups['visibility']=='unavailable':
        require(a.get('accept_unobservable_cgroup_ceiling') is True,'Cgroup ceiling unavailable; explicit parent acceptance of this observability limit required')
    for row in cgroups['ancestors']:
        maximum=row.get('memory.max','max')
        if maximum!='max':
            require(int(maximum)>=5368709120,'Exposed cgroup ceiling below5GiB')
            require(int(maximum)-int(row.get('memory.current','0'))>=1500000000,'Exposed cgroup remaining capacity below1.5GB')
    start=time.monotonic();deadline=start+600
    write_json(PACKET/'RUN_CLAIM.json',{'packet_manifest_sha256':digest,'started_utc_epoch':time.time(),'guard_pid':os.getpid(),'max_runs':1})
    OUT.mkdir()
    write_json(OUT/'launch.json',{'guard_pid':os.getpid(),'packet_manifest_sha256':digest,'deadline_monotonic':deadline,'wall_seconds':600,'tree_rss_bytes':5368709120,'host_min_bytes':1500000000,'source_admission':a,'inherited_limits':inherited,'cgroup_visibility':cgroups})
    env=dict(os.environ,TEMPORAL_GUARD_PID=str(os.getpid()),TEMPORAL_PACKET_RUN='ONE_EXPLICITLY_ADMITTED_RUN',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',CUDA_VISIBLE_DEVICES='')
    def child_setup():
        setup_child(int(env['TEMPORAL_GUARD_PID']))
    child=None;why=None;peak=0;minimum=host_available();absent=False
    log=(OUT/'runner.log').open('xb');samples=(OUT/'resource_samples.jsonl').open('x',buffering=1)
    try:
        child=subprocess.Popen([str(PYTHON),str(PACKET/'capture_runner.py')],cwd=PACKET,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=child_setup)
        while True:
            members=group_processes(child.pid);rss=self_rss()+sum(x[1] for x in members);peak=max(peak,rss);available=host_available();minimum=min(minimum,available)
            cg=cgroup_limits()
            cg_bad=False
            for row in cg['ancestors']:
                maximum=row.get('memory.max','max')
                if maximum!='max' and (int(maximum)<5368709120 or int(maximum)-int(row.get('memory.current','0'))<1500000000):cg_bad=True
            sample={'elapsed':time.monotonic()-start,'tree_rss_bytes':rss,'host_available':available,'evidence_bytes':evidence_bytes(),'cgroup_visibility':cg}
            samples.write(json.dumps(sample,separators=(',',':'))+'\n')
            if time.monotonic()>=deadline:why='wall_limit'
            elif rss>5368709120:why='tree_rss_limit'
            elif available<1500000000:why='host_available_limit'
            elif cg_bad:why='cgroup_capacity_limit'
            elif cg['visibility']=='unavailable' and not a.get('accept_unobservable_cgroup_ceiling'):why='cgroup_visibility_lost'
            elif evidence_bytes()>100000000:why='evidence_limit'
            elif shutil.disk_usage(PACKET).free<1000000000:why='disk_limit'
            if why or child.poll() is not None:break
            time.sleep(.1)
    except BaseException as exc:why='guard_exception:'+type(exc).__name__+':'+str(exc)
    finally:
        if child:
            absent=kill_owned(child.pid)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:why=why or 'cleanup_wait_timeout'
        samples.close();log.close()
        write_json(OUT/'guard_result.json',{'exit_code':None if child is None else child.returncode,'termination':why,'elapsed_seconds':time.monotonic()-start,'sampled_peak_process_tree_rss_bytes':peak,'minimum_host_available_bytes':minimum,'owned_process_group_absence_verified':absent,'evidence_bytes':evidence_bytes(),'no_retry':True})
    require(child is not None and child.returncode==0 and why is None and absent,'Run did not complete cleanly')
if __name__=='__main__':main()
