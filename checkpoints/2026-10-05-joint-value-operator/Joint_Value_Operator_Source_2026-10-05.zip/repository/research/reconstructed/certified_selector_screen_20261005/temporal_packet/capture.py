"""Transparent native attention-interface capture; no model imports at module load."""
from contextlib import AbstractContextManager

class InterfaceCapture(AbstractContextManager):
    def __init__(self, module, callback):
        self.module = module
        self.callback = callback
        self.original = None
        self.wrapper = None

    def __enter__(self):
        if self.original is not None:
            raise RuntimeError("Capture is already installed")
        self.original = self.module.eager_attention_forward
        original = self.original
        callback = self.callback
        def wrapper(attention_module, query, key, value, attention_mask, *args, **kwargs):
            callback(attention_module, query, key, value, attention_mask, args, kwargs)
            return original(attention_module, query, key, value, attention_mask, *args, **kwargs)
        self.wrapper = wrapper
        self.module.eager_attention_forward = wrapper
        return self

    def __exit__(self, *unused):
        if self.original is not None:
            if self.module.eager_attention_forward is not self.wrapper:
                raise RuntimeError("Native interface changed while capture was installed")
            self.module.eager_attention_forward = self.original
            self.original = None
            self.wrapper = None
        return False
