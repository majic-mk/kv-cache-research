"""Bounded, model-free FP64 replay of the frozen temporal selector proposal.

Only process_trace() is a real-trace entry point. It requires the frozen CPU BF16
shapes/layers. SelectorArm and ReplayConfig support small mathematical unit tests;
they do not produce evidence of real-model feasibility. No tensor files are read
or written, and no model/runtime/cache code is imported.

The motion inequalities are real-arithmetic statements. Decisions below use
ordinary FP64 with a conservative comparison ambiguity guard, NOT outward-rounded
interval arithmetic. Every arm is checked against separately computed full FP64
scores, so claims are limited to observed selector-set parity with that reference.
Logical operation/byte ledgers are NOT measured physical memory traffic or speed.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
import math
from pathlib import Path
from time import perf_counter_ns
from typing import Any

import torch

EXPECTED_LAYERS = (0, 7, 14, 21, 28, 35)
ARMS = ("full_current", "warmstart_exact_control", "global_motion",
        "pagewise_motion_secondary")
FP64_BYTES = 8
# Frozen conservative policy: a positive separation <= 64 eps times score scale
# is treated as unresolved. This is not a floating-point error proof.
COMPARISON_EPS_MULTIPLIER = 64


@dataclass(frozen=True)
class ReplayConfig:
    page_size: int = 64
    old_pages: int = 8
    r: int = 2
    head_dim: int = 128
    prefix_tokens: int = 512
    input_element_bytes: int = 2

    def __post_init__(self) -> None:
        if min(self.page_size, self.old_pages, self.r, self.head_dim) <= 0:
            raise ValueError("All dimensions and r must be positive")
        if self.r >= self.old_pages:
            raise ValueError("The certificate requires 0 < r < old_pages")
        if self.prefix_tokens != self.page_size * self.old_pages:
            raise ValueError("prefix_tokens must equal page_size * old_pages")

    @property
    def scale(self) -> float:
        return math.sqrt(self.head_dim)


def strict_separation(lhs: float, rhs: float) -> bool:
    """Conservative FP64 comparison; it does not certify real arithmetic."""
    if not (math.isfinite(lhs) and math.isfinite(rhs)):
        return False
    guard = (COMPARISON_EPS_MULTIPLIER * torch.finfo(torch.float64).eps
             * max(1.0, abs(lhs), abs(rhs)))
    return lhs - rhs > guard


def ranked_top(scores: dict[int, float], r: int) -> list[int]:
    if len(scores) < r or not all(math.isfinite(v) for v in scores.values()):
        raise ValueError("Top-r needs enough finite scores")
    return sorted(scores, key=lambda page: (-scores[page], page))[:r]


def block_logsumexp(query: torch.Tensor, keys: torch.Tensor) -> float:
    """One deterministic CPU FP64 page calculation with its actual token count."""
    if query.dtype != torch.float64 or keys.dtype != torch.float64:
        raise TypeError("The scoring primitive accepts FP64 tensors only")
    if query.device.type != "cpu" or keys.device.type != "cpu":
        raise ValueError("CPU replay only")
    if keys.ndim != 2 or query.ndim != 1 or keys.shape[1] != query.numel():
        raise ValueError("Expected query[d], keys[tokens,d]")
    if keys.shape[0] < 1:
        raise ValueError("A page must contain at least one causal key")
    # The same fixed primitive is used in separate reference and arm calls.
    logits = torch.mv(keys, query) / math.sqrt(query.numel())
    value = float(torch.logsumexp(logits, dim=0).item())
    if not math.isfinite(value):
        raise ValueError("Nonfinite FP64 page score; stop replay")
    return value


def page_radii(old_keys: torch.Tensor) -> torch.Tensor:
    if old_keys.dtype != torch.float64 or old_keys.ndim != 3:
        raise ValueError("Expected FP64 old_keys[pages,tokens,d]")
    radii = torch.linalg.vector_norm(old_keys, dim=-1).amax(dim=-1)
    if not bool(torch.isfinite(radii).all()):
        raise ValueError("Nonfinite page radius; stop replay")
    return radii


def gqa_kv_head(query_head: int, query_heads: int = 32, kv_heads: int = 8) -> int:
    if query_heads % kv_heads or not 0 <= query_head < query_heads:
        raise ValueError("Invalid GQA head mapping")
    return query_head // (query_heads // kv_heads)


def causal_current_page(keys: torch.Tensor, position: int,
                        config: ReplayConfig) -> torch.Tensor:
    """The new key is already appended; never expose the future."""
    if keys.ndim != 2 or keys.shape[1] != config.head_dim:
        raise ValueError("Expected keys[tokens,head_dim]")
    if not config.prefix_tokens <= position < keys.shape[0]:
        raise ValueError("Unavailable current key")
    if position - config.prefix_tokens + 1 >= config.page_size:
        raise ValueError("Completed growing page requires a new full anchor")
    return keys[config.prefix_tokens:position + 1]


def full_reference(query: torch.Tensor, old_keys: torch.Tensor,
                   current_keys: torch.Tensor, r: int) -> dict[str, Any]:
    """Compute fresh scores without consulting any arm or temporal state."""
    old_scores = {b: block_logsumexp(query, old_keys[b])
                  for b in range(old_keys.shape[0])}
    all_scores = dict(old_scores)
    all_scores[old_keys.shape[0]] = block_logsumexp(query, current_keys)
    old_top = ranked_top(old_scores, r)
    overall = ranked_top(all_scores, r)
    descending = ranked_top(old_scores, len(old_scores))
    return {"old_scores": old_scores, "all_scores": all_scores,
            "old_top_ranked": old_top, "old_top_set": sorted(old_top),
            "all_top_ranked": overall, "all_top_set": sorted(overall),
            "old_gap": old_scores[descending[r - 1]] - old_scores[descending[r]]}


class SelectorArm:
    """One query head, one arm; partial refinements never mutate its anchor."""
    def __init__(self, name: str, old_keys: torch.Tensor,
                 config: ReplayConfig, radii: torch.Tensor | None = None):
        if name not in ARMS:
            raise ValueError(f"Unknown arm: {name}")
        if tuple(old_keys.shape) != (config.old_pages, config.page_size, config.head_dim):
            raise ValueError("Old keys do not match config")
        if old_keys.dtype != torch.float64 or old_keys.device.type != "cpu":
            raise ValueError("Old keys must be CPU FP64")
        self.name, self.old_keys, self.cfg = name, old_keys, config
        self.radii = page_radii(old_keys) if radii is None else radii
        if tuple(self.radii.shape) != (config.old_pages,):
            raise ValueError("Radius shape mismatch")
        self.r_max = float(self.radii.max().item())
        self.anchor_query: torch.Tensor | None = None
        self.anchor_position: int | None = None
        self.anchor_scores: dict[int, float] | None = None
        self.anchor_top: list[int] | None = None
        self.anchor_gap: float | None = None
        self.previous_top: list[int] | None = None
        self.previous_position: int | None = None
        self.ledger: Counter = Counter()

    def _score(self, query: torch.Tensor, pages: list[int],
               scores: dict[int, float]) -> None:
        for page in pages:
            if page in scores:
                raise AssertionError("A current-query page must not be scored twice")
            scores[page] = block_logsumexp(query, self.old_keys[page])
            self.ledger["old_pages_scored"] += 1
            self.ledger["old_tokens_scored"] += self.cfg.page_size
            self.ledger["score_dot_coordinates"] += self.cfg.page_size * self.cfg.head_dim
            self.ledger["logsumexp_calls"] += 1

    def _refresh(self, query: torch.Tensor, position: int,
                 scores: dict[int, float]) -> None:
        if set(scores) != set(range(self.cfg.old_pages)):
            raise AssertionError("Cannot reset an anchor from partial current scores")
        order = ranked_top(scores, self.cfg.old_pages)
        self.anchor_query = query.clone()
        self.anchor_position = position
        self.anchor_scores = dict(scores)
        self.anchor_top = order[:self.cfg.r]
        self.anchor_gap = scores[order[self.cfg.r - 1]] - scores[order[self.cfg.r]]
        self.ledger["full_anchor_refreshes"] += 1
        self.ledger["anchor_write_bytes_logical"] += (
            self.cfg.head_dim + self.cfg.old_pages + self.cfg.r + 2) * FP64_BYTES
        self.ledger["exact_selection_entries"] += self.cfg.old_pages

    def _metadata_scan(self, entries: int, bytes_per_entry: int) -> None:
        self.ledger["metadata_scan_passes"] += 1
        self.ledger["metadata_page_entries_read"] += entries
        self.ledger["metadata_read_bytes_logical"] += entries * bytes_per_entry

    def advance(self, query: torch.Tensor, position: int,
                current_keys: torch.Tensor) -> dict[str, Any]:
        cfg = self.cfg
        if query.dtype != torch.float64 or tuple(query.shape) != (cfg.head_dim,):
            raise ValueError("Expected one FP64 query[head_dim]")
        if current_keys.dtype != torch.float64 or current_keys.device.type != "cpu":
            raise ValueError("Current keys must be CPU FP64")
        causal_count = position - cfg.prefix_tokens + 1
        if not 1 <= causal_count < cfg.page_size:
            raise ValueError("Only the frozen uncompleted growing-page case is supported")
        if tuple(current_keys.shape) != (causal_count, cfg.head_dim):
            raise ValueError("Current page must include exactly all available causal keys")
        expected_position = (cfg.prefix_tokens if self.previous_position is None
                             else self.previous_position + 1)
        if position != expected_position:
            raise ValueError("Replay must start at the prefix and advance one position")
        if not bool(torch.isfinite(query).all()) or not bool(torch.isfinite(current_keys).all()):
            raise ValueError("Nonfinite query/current keys; stop replay")
        before = dict(self.ledger)
        anchor_before = self.anchor_position
        anchor_top_before = None if self.anchor_top is None else sorted(self.anchor_top)
        anchor_gap_before = self.anchor_gap
        scores: dict[int, float] = {}
        refined: list[int] = []
        motion = bound = slack = pagewise_slack = None
        initial_certificate_pass = False
        eligible = self.anchor_query is not None and self.name in ARMS[2:]
        all_ids = list(range(cfg.old_pages))
        if self.name in ("full_current", "warmstart_exact_control"):
            order = all_ids
            if self.name == "warmstart_exact_control" and self.previous_top is not None:
                order = self.previous_top + [b for b in all_ids if b not in self.previous_top]
            self._score(query, order, scores)
            refined = list(order)
            decision = "full_current" if self.name == "full_current" else "warmstart_full_current"
        elif self.anchor_query is None:
            self._score(query, all_ids, scores)
            refined = list(all_ids)
            self._refresh(query, position, scores)
            decision = "initial_full_refresh"
        else:
            self.ledger["eligible_checks"] += 1
            self.ledger["query_motion_checks"] += 1
            self.ledger["query_motion_coordinates"] += cfg.head_dim
            self.ledger["query_motion_read_bytes_logical"] += 2 * cfg.head_dim * FP64_BYTES
            motion = float(torch.linalg.vector_norm(query - self.anchor_query).item())
            bound = 2.0 * motion * self.r_max / cfg.scale
            slack = self.anchor_gap - bound
            if self.name == "global_motion":
                self.ledger["metadata_read_bytes_logical"] += 2 * FP64_BYTES
                initial_certificate_pass = strict_separation(self.anchor_gap, bound)
                if initial_certificate_pass:
                    self._score(query, self.anchor_top, scores)
                    refined = list(self.anchor_top)
                    decision = "global_certified_reuse"
                else:
                    self._score(query, all_ids, scores)
                    refined = list(all_ids)
                    self._refresh(query, position, scores)
                    decision = "global_failed_full_refresh"
            else:
                # Both radius and mass metadata for all pages are scanned.
                self._metadata_scan(cfg.old_pages, 2 * FP64_BYTES)
                errors = {b: motion * float(self.radii[b].item()) / cfg.scale for b in all_ids}
                lower = {b: self.anchor_scores[b] - errors[b] for b in all_ids}
                upper = {b: self.anchor_scores[b] + errors[b] for b in all_ids}
                self._metadata_scan(cfg.old_pages, FP64_BYTES)
                selected_lower = min(lower[b] for b in self.anchor_top)
                omitted_upper = max(upper[b] for b in all_ids if b not in self.anchor_top)
                pagewise_slack = selected_lower - omitted_upper
                initial_certificate_pass = strict_separation(selected_lower, omitted_upper)
                self._score(query, self.anchor_top, scores)
                refined = list(self.anchor_top)
                if initial_certificate_pass:
                    decision = "pagewise_certified_reuse"
                else:
                    # Scores already obtained at this query are ephemeral. Only a
                    # complete scan of all pages below will reset the common anchor.
                    while len(scores) < cfg.old_pages:
                        candidates = ranked_top(scores, cfg.r)
                        self.ledger["exact_selection_entries"] += len(scores)
                        threshold = scores[candidates[-1]]
                        unseen = [b for b in all_ids if b not in scores]
                        self._metadata_scan(len(unseen), FP64_BYTES)
                        highest = min(unseen, key=lambda b: (-upper[b], b))
                        if strict_separation(threshold, upper[highest]):
                            break
                        self._score(query, [highest], scores)
                        refined.append(highest)
                    if len(scores) == cfg.old_pages:
                        self._refresh(query, position, scores)
                        decision = "pagewise_refined_full_refresh"
                    else:
                        decision = "pagewise_refined_partial"
            if initial_certificate_pass:
                self.ledger["initial_certificate_passes"] += 1
            if len(scores) < cfg.old_pages:
                self.ledger["eligible_avoided_full_old_scoring"] += 1
            else:
                self.ledger["eligible_full_refreshes"] += 1
        current_score = block_logsumexp(query, current_keys)
        self.ledger["current_pages_scored"] += 1
        self.ledger["current_tokens_scored"] += causal_count
        self.ledger["score_dot_coordinates"] += causal_count * cfg.head_dim
        self.ledger["logsumexp_calls"] += 1
        old_top = ranked_top(scores, cfg.r)
        self.ledger["exact_selection_entries"] += len(scores)
        merge = {b: scores[b] for b in old_top}
        merge[cfg.old_pages] = current_score
        overall = ranked_top(merge, cfg.r)
        self.ledger["exact_selection_entries"] += len(merge)
        self.ledger["decisions"] += 1
        tokens_scored = self.ledger["old_tokens_scored"] + self.ledger["current_tokens_scored"]
        self.ledger["exact_key_bytes_at_input_dtype_logical"] = tokens_scored * cfg.head_dim * cfg.input_element_bytes
        self.ledger["exact_key_bytes_fp64_replay_logical"] = tokens_scored * cfg.head_dim * FP64_BYTES
        self.previous_top, self.previous_position = list(old_top), position
        delta = {k: int(v - before.get(k, 0)) for k, v in self.ledger.items()
                 if v - before.get(k, 0)}
        return {"decision": decision, "eligible": eligible,
                "initial_certificate_pass": initial_certificate_pass,
                "avoided_full_old_scoring": eligible and len(scores) < cfg.old_pages,
                "anchor_position_before": anchor_before,
                "anchor_position_after": self.anchor_position,
                "anchor_old_top_set_before": anchor_top_before,
                "anchor_gap_before": anchor_gap_before,
                "anchor_gap_after": self.anchor_gap,
                "query_motion_from_full_refresh": motion, "r_max": self.r_max,
                "twice_global_motion_bound": bound, "global_certificate_slack": slack,
                "pagewise_initial_slack": pagewise_slack,
                "refined_old_page_ids": refined,
                "current_page_id": cfg.old_pages, "current_page_tokens": causal_count,
                "old_top_ranked": old_top, "old_top_set": sorted(old_top),
                "all_top_ranked": overall, "all_top_set": sorted(overall),
                "cost_delta": delta}


class ReferenceParityError(RuntimeError):
    """An independently recomputed full FP64 reference disagreed; stop immediately."""


def _validate_real_traces(traces: dict) -> list[int]:
    if not isinstance(traces, dict) or set(traces) != set(EXPECTED_LAYERS):
        raise ValueError(f"Expected exactly the frozen integer layer IDs {EXPECTED_LAYERS}")
    for layer in EXPECTED_LAYERS:
        trace = traces[layer]
        if not isinstance(trace, dict) or "query" not in trace or "keys" not in trace:
            raise ValueError(f"Layer {layer}: expected query and keys")
        for name, shape in (("query", (16, 32, 128)), ("keys", (528, 8, 128))):
            tensor = trace[name]
            if not isinstance(tensor, torch.Tensor) or tuple(tensor.shape) != shape:
                raise ValueError(f"Layer {layer} {name}: expected shape {shape}")
            if tensor.dtype != torch.bfloat16 or tensor.device.type != "cpu":
                raise ValueError(f"Layer {layer} {name}: expected CPU BF16")
            if tensor.requires_grad or not bool(torch.isfinite(tensor).all()):
                raise ValueError(f"Layer {layer} {name}: must be finite detached tensors")
    return list(EXPECTED_LAYERS)


def _json_dump(value: Any, path: Path) -> None:
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2, sort_keys=True, allow_nan=False)
        output.write("\n")


def process_trace(traces: dict, output_dir: str | Path) -> dict[str, Any]:
    """Replay frozen real tensors; write JSON/JSONL only; return the summary.

    Fresh output filenames are exclusive-create. The parent owns wall/RSS/artifact
    guards and launch authorization. This function never loads a model or tensors.
    All six frozen traces must be supplied together; no post-outcome workload choice.
    """
    layers = _validate_real_traces(traces)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    evidence_path = output_dir / "replay_evidence.jsonl"
    summary_path = output_dir / "replay_summary.json"
    if evidence_path.exists() or summary_path.exists():
        raise FileExistsError("Refusing to overwrite or resume prior replay evidence")
    cfg = ReplayConfig()
    totals = {name: Counter() for name in ARMS}
    decisions = {name: Counter() for name in ARMS}
    runs = {name: Counter() for name in ARMS[2:]}
    unions: dict[tuple, set] = defaultdict(set)
    stability = Counter()
    cold = Counter()
    agreement_count = 0
    audit_elapsed_ns = 0
    conversion_elapsed_ns = 0
    input_bytes = sum(t.numel() * t.element_size() for trace in traces.values()
                      for k, t in trace.items() if k in ("query", "keys"))
    layer_working_tensor_bytes_peak = 0
    with evidence_path.open("x", encoding="utf-8") as evidence, torch.inference_mode():
        for layer in layers:
            conversion_start = perf_counter_ns()
            query = traces[layer]["query"].to(dtype=torch.float64)
            keys = traces[layer]["keys"].to(dtype=torch.float64)
            conversion_elapsed_ns += perf_counter_ns() - conversion_start
            layer_working_tensor_bytes_peak = max(layer_working_tensor_bytes_peak,
                                                  (query.numel() + keys.numel()) * FP64_BYTES)
            # Radius metadata is computed once per physical KV head/page, shared
            # among its four query heads and the temporal policy controls.
            cold_start = perf_counter_ns()
            all_radii = {kv: page_radii(keys[:512, kv].reshape(8, 64, 128))
                         for kv in range(8)}
            cold["radius_build_elapsed_ns_diagnostic"] += perf_counter_ns() - cold_start
            cold["radius_key_vectors"] += 512 * 8
            cold["radius_norm_coordinates"] += 512 * 8 * 128
            cold["radius_key_bytes_input_dtype_logical"] += 512 * 8 * 128 * 2
            cold["radius_key_bytes_fp64_replay_logical"] += 512 * 8 * 128 * FP64_BYTES
            for head in range(32):
                kv_head = gqa_kv_head(head)
                old_keys = keys[:512, kv_head].reshape(8, 64, 128)
                policies = {}
                for name in ARMS:
                    build_start = perf_counter_ns()
                    policies[name] = SelectorArm(name, old_keys, cfg, all_radii[kv_head])
                    totals[name]["arm_build_elapsed_ns_diagnostic"] += perf_counter_ns() - build_start
                previous_reference = None
                run_lengths = {name: 0 for name in ARMS[2:]}
                for step in range(16):
                    position = 512 + step
                    q = query[step, head]
                    # Includes key at position, excludes every future key.
                    current = causal_current_page(keys[:, kv_head], position, cfg)
                    # All advances are timed before the full reference audit.
                    # Fixed ordering/cache effects still preclude speed claims.
                    step_results = {}
                    for name, policy in policies.items():
                        arm_start = perf_counter_ns()
                        step_results[name] = policy.advance(q, position, current)
                        elapsed = perf_counter_ns() - arm_start
                        step_results[name]["elapsed_ns_diagnostic_before_audit"] = elapsed
                        totals[name]["advance_elapsed_ns_diagnostic"] += elapsed
                    audit_start = perf_counter_ns()
                    reference = full_reference(q, old_keys, current, cfg.r)
                    audit_elapsed_ns += perf_counter_ns() - audit_start
                    if previous_reference is not None:
                        stability["eligible_head_steps"] += 1
                        stability["old_set_unchanged_from_previous_query"] += int(
                            reference["old_top_set"] == previous_reference["old_top_set"])
                        stability["all_set_unchanged_from_previous_query"] += int(
                            reference["all_top_set"] == previous_reference["all_top_set"])
                    record = {"layer": layer, "query_head": head, "kv_head": kv_head,
                              "step": step, "position": position,
                              "reference_old_top_set": reference["old_top_set"],
                              "reference_all_top_set": reference["all_top_set"],
                              "reference_old_gap": reference["old_gap"],
                              "exact_old_set_stable_from_previous_query": None if previous_reference is None else
                                  reference["old_top_set"] == previous_reference["old_top_set"],
                              "exact_all_set_stable_from_previous_query": None if previous_reference is None else
                                  reference["all_top_set"] == previous_reference["all_top_set"],
                              "arms": {}}
                    for name, policy in policies.items():
                        result = step_results[name]
                        old_match = result["old_top_set"] == reference["old_top_set"]
                        overall_match = result["all_top_set"] == reference["all_top_set"]
                        result["reference_old_set_agreement"] = old_match
                        result["reference_all_set_agreement"] = overall_match
                        anchor_set = result["anchor_old_top_set_before"]
                        result["exact_old_set_stable_from_full_refresh_anchor"] = (
                            None if anchor_set is None else anchor_set == reference["old_top_set"])
                        record["arms"][name] = result
                        if not (old_match and overall_match):
                            record["correctness_stop"] = {"arm": name, "reason": "FP64_REFERENCE_SET_MISMATCH"}
                            evidence.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
                            evidence.flush()
                            raise ReferenceParityError(f"{name}: layer={layer}, head={head}, position={position}")
                        agreement_count += 1
                        totals[name].update(result["cost_delta"])
                        decisions[name][result["decision"]] += 1
                        unions[(name, layer, step, kv_head)].update(result["refined_old_page_ids"])
                        if name in run_lengths and result["eligible"]:
                            if result["avoided_full_old_scoring"]:
                                run_lengths[name] += 1
                            elif run_lengths[name]:
                                runs[name][run_lengths[name]] += 1
                                run_lengths[name] = 0
                            if result["exact_old_set_stable_from_full_refresh_anchor"] and not result["initial_certificate_pass"]:
                                totals[name]["anchor_set_stable_but_initial_bound_failed"] += 1
                    evidence.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
                    previous_reference = reference
                for name, length in run_lengths.items():
                    if length:
                        runs[name][length] += 1
            # Do not keep converted trace tensors for earlier layers.
            del policy, policies, old_keys, q, current, query, keys, all_radii
    summaries = {}
    for name in ARMS:
        ledger = {key: int(totals[name].get(key, 0)) for key in (
            "old_pages_scored", "old_tokens_scored", "current_pages_scored",
            "current_tokens_scored", "score_dot_coordinates", "logsumexp_calls",
            "eligible_checks", "query_motion_checks", "query_motion_coordinates",
            "query_motion_read_bytes_logical", "metadata_scan_passes",
            "metadata_page_entries_read", "metadata_read_bytes_logical",
            "anchor_write_bytes_logical", "full_anchor_refreshes",
            "initial_certificate_passes", "eligible_avoided_full_old_scoring",
            "eligible_full_refreshes", "anchor_set_stable_but_initial_bound_failed",
            "exact_selection_entries", "decisions",
            "exact_key_bytes_at_input_dtype_logical", "exact_key_bytes_fp64_replay_logical",
            "arm_build_elapsed_ns_diagnostic", "advance_elapsed_ns_diagnostic")}
        union_old_pages = sum(len(pages) for key, pages in unions.items() if key[0] == name)
        # Exactly one current-page fetch per layer/step/KV head in this ideal
        # deduplication ledger, irrespective of four logical query-head uses.
        union_current_tokens = len(layers) * 8 * sum(range(1, 17))
        eligible = ledger.get("eligible_checks", 0)
        summaries[name] = {
            "ledger": ledger, "decisions": dict(decisions[name]),
            "initial_certificate_fraction_of_eligible": None if not eligible else
                ledger.get("initial_certificate_passes", 0) / eligible,
            "avoided_full_old_scoring_fraction_of_eligible": None if not eligible else
                ledger.get("eligible_avoided_full_old_scoring", 0) / eligible,
            "avoided_full_scoring_run_lengths": dict(sorted(runs.get(name, {}).items())),
            "deduplicated_gqa_old_page_union_count": union_old_pages,
            "deduplicated_gqa_exact_key_bytes_input_dtype_logical":
                (union_old_pages * 64 + union_current_tokens) * 128 * 2,
            "deduplicated_gqa_exact_key_bytes_fp64_replay_logical":
                (union_old_pages * 64 + union_current_tokens) * 128 * FP64_BYTES,
            "avoided_old_page_scores_vs_full_current":
                totals["full_current"]["old_pages_scored"] - totals[name]["old_pages_scored"],
        }
    head_steps = len(layers) * 32 * 16
    summary = {
        "status": "FP64_REFERENCE_SET_PARITY_PASSED",
        "scope": "Frozen six-layer CPU BF16 trace converted to FP64; selector scores only",
        "machine_certified_intervals": False,
        "production_bf16_bit_exact_claim": False,
        "real_model_outputs_or_quality_evaluated": False,
        "timing_speedup_or_novelty_claim": False,
        "numerical_policy": {
            "dtype": "torch.float64", "scale": "sqrt(128)",
            "tie_break": "descending computed score, ascending page ID",
            "strict_comparison_guard": "lhs-rhs > 64*FP64_epsilon*max(1,abs(lhs),abs(rhs))",
            "guard_is_formal_rounding_error_bound": False,
            "independent_reference_for_every_arm_decision": True,
        },
        "head_steps": head_steps, "arm_decisions_checked": agreement_count,
        "eligible_head_steps_per_temporal_arm": len(layers) * 32 * 15,
        "exact_set_stability": dict(stability), "arms": summaries,
        "cold_build_shared_once": dict(cold),
        "reference_validation_work_excluded_from_arm_ledgers": {
            "old_page_scores": head_steps * 8, "current_page_scores": head_steps,
            "elapsed_ns_diagnostic": audit_elapsed_ns,
            "dot_coordinates": len(layers) * 32 * (16 * 512 + sum(range(1, 17))) * 128,
        },
        "fp64_conversion_elapsed_ns_diagnostic": conversion_elapsed_ns,
        "timing_caveat": "Unwarmed fixed-order CPU micro-replay; includes Python overhead; no production speed inference",
        "memory_accounting": {
            "input_bf16_tensor_bytes_all_layers": input_bytes,
            "converted_fp64_working_tensor_bytes_peak_one_layer": layer_working_tensor_bytes_peak,
            "shared_radius_metadata_bytes_one_layer": 8 * (8 + 1) * FP64_BYTES,
            "temporal_anchor_payload_bytes_per_head_per_arm": (128 + 8 + 2 + 2) * FP64_BYTES,
            "pagewise_interval_payload_bytes_per_head": 3 * 8 * FP64_BYTES,
            "page_logit_scratch_bytes_upper_bound": 64 * FP64_BYTES,
            "page_norm_intermediate_bytes_one_kv_head": 512 * FP64_BYTES,
            "actual_implementation_processes_one_head_at_a_time": True,
            "excludes_python_allocator_torch_internal_and_process_rss": True,
            "byte_ledger_is_logical_not_measured_hardware_traffic": True,
            "gqa_union_is_ideal_deduplication_accounting_not_executed_transfer": True,
        },
        "limitations": [
            "Strict guarded FP64 comparisons are not outward-rounded interval certificates.",
            "Observed exact set parity applies only to the recorded FP64 score reference.",
            "Warmstart is a full-current-score ordering control, not a GVR kernel reproduction.",
            "Exact scoring ledgers include retained candidate and growing-page scoring.",
            "Reference and baseline score calls are separate; validation work is extra.",
            "Cold norm construction is shared in this replay but must be charged to a deployed temporal policy.",
            "Byte and operation counts alone cannot establish net speed benefit or novelty.",
            "No generated trace, attention outputs, mass coverage, PPL, or quality claim.",
        ],
        "evidence_filename": evidence_path.name,
        "evidence_bytes": evidence_path.stat().st_size,
    }
    _json_dump(summary, summary_path)
    return summary
