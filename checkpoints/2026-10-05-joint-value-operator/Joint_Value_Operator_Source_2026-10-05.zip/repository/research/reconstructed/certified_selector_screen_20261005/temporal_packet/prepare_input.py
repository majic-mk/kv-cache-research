"""Reproduce and verify frozen prose/token lock only; never imports/loads a model."""
from pathlib import Path
import hashlib,json
from common import PACKET,ASSETS,read_json,require,sha_file
def main():
    from transformers import AutoTokenizer
    source=read_json(PACKET/'source_lines.json')
    require([x['line'] for x in source['lines']]==list(range(60,131)),'Source line sequence')
    text='\n'.join(x['text'] for x in source['lines'])+'\n'
    actual=(PACKET/'input_excerpt.txt').read_text()
    require(actual==text,'Exact source excerpt reconstruction')
    lock=read_json(PACKET/'input_lock.json')
    require(sha_file(PACKET/'input_excerpt.txt')==lock['source_text_sha256'],'Source hash')
    require(sha_file(ASSETS/'tokenizer.json')==lock['tokenizer_asset_sha256'],'Tokenizer hash')
    require(sha_file(ASSETS/'config.json')==lock['config_sha256'],'Config hash')
    tok=AutoTokenizer.from_pretrained(ASSETS,local_files_only=True,trust_remote_code=False)
    ids=tok.encode(text,add_special_tokens=False)[:528]
    require(ids==read_json(PACKET/'token_ids.json') and len(ids)==528,'Exact canonical token IDs')
    require(sha_file(PACKET/'token_ids.json')==lock['ids_sha256'],'Token file hash')
    print(json.dumps({'status':'PASS','source_reconstruction':True,'token_ids':528,'model_loads':0,'pretrained_forwards':0}))
if __name__=='__main__':main()
