"""Single guarded native CPU extraction and offline replay. Never run directly."""
from pathlib import Path
import gc,hashlib,json,os,resource,time,traceback
from common import *
from cpu_release import require_cpu_release
from file_pager import FilePager
from capture import InterfaceCapture
LAYERS=(0,7,14,21,28,35)
def main():
    require_cpu_release()
    launch=read_json(OUT/'launch.json')
    require(launch['guard_pid']==os.getppid(),'Wrong launcher parent')
    require(launch['packet_manifest_sha256']==packet_integrity(),'Packet changed after launch')
    deadline=float(launch['deadline_monotonic'])
    def check():check_live(deadline);require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=5368709120,'Child high-water RSS exceeded5GiB')
    check()
    import torch,transformers
    from transformers import Qwen3Config,Qwen3ForCausalLM
    from transformers.cache_utils import DynamicCache
    from transformers.models.qwen3 import modeling_qwen3 as qwen
    require(torch.__version__=='2.9.1+cpu' and torch.version.cuda is None,'Pinned CPU Torch only')
    require(transformers.__version__=='5.19.0.dev0','Pinned Transformers')
    require(sha_file(qwen.__file__)=='2b768b0eb0aacf1478bba1dc84318126c6c68fecb0ac9465f70154f24da4a80d','Pinned native Qwen3 source')
    import transformers.cache_utils as cache_source
    import transformers.modeling_utils as modeling_source
    import transformers.masking_utils as masking_source
    for source,expected_hash in ((cache_source,'2d2ab17aa02c9d2a993587ec58d1745b03595b6028c401cc6c976bb720ad6638'),(modeling_source,'3a32f432917a1265fc3f26b2a36032b047b9c4d367ea75a5c8d389b1d268cda0'),(masking_source,'af3d84dfe82a0b57c40625c89fb32b2cd6bf7351432ee5e76a9e8eac4289575b')):
        require(sha_file(source.__file__)==expected_hash,'Pinned native dependency: '+source.__name__)
    torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.set_grad_enabled(False);torch.use_deterministic_algorithms(True)
    raw=read_json(ASSETS/'config.json')
    require(sha_file(ASSETS/'config.json')==read_json(PACKET/'input_lock.json')['config_sha256'],'Config identity')
    actual=tuple(raw[x] for x in ('num_hidden_layers','num_attention_heads','num_key_value_heads','head_dim'))
    require(actual==(36,32,8,128),'Frozen dimensions must match actual config')
    require(raw['rope_theta']==5000000 and raw['rope_scaling'] is None and not raw['use_sliding_window'],'Frozen RoPE/attention')
    config=Qwen3Config.from_dict(raw);config._attn_implementation='eager'
    require(config.rope_parameters=={'rope_theta':5000000,'rope_type':'default'},'Native standardized RoPE')
    prior=torch.get_default_dtype();torch.set_default_dtype(torch.bfloat16)
    try:
        with torch.device('meta'):model=Qwen3ForCausalLM(config).eval()
    finally:torch.set_default_dtype(prior)
    model.model.rotary_emb=qwen.Qwen3RotaryEmbedding(config=config)
    require(len(model.model.layers)==36,'36 decoder layers')
    require(all(p.device.type=='meta' for p in model.parameters()),'Meta construction')
    require(model.lm_head.weight is model.model.embed_tokens.weight,'Native tied embedding/head')
    ids=read_json(PACKET/'token_ids.json');require(len(ids)==528 and all(type(x)is int and 0<=x<raw['vocab_size'] for x in ids),'Exact token ID range')
    expected=read_json(PACKET/'asset_expected.json')['shards']
    trace={};call_rows=[];capture_calls={i:0 for i in range(36)};current={'start':0,'end':0,'layers_seen':[]}
    def callback(module,q,k,v,mask,args,kwargs):
        check()
        layer=int(module.layer_idx)
        require(layer in capture_calls,'Unknown native layer')
        require(layer==len(current['layers_seen']),'Every native layer must execute once in order')
        current['layers_seen'].append(layer)
        capture_calls[layer]+=1
        require(q.dtype==k.dtype==v.dtype==torch.bfloat16,'Native BF16 capture')
        require(q.device.type==k.device.type=='cpu','CPU only capture')
        require(tuple(q.shape)==(1,32,current['end']-current['start'],128),'Native Q layout')
        require(tuple(k.shape)==(1,8,current['end'],128),'Native K layout before GQA repeat')
        require(module.num_key_value_groups==4,'Native GQA mapping')
        require(kwargs.get('scaling')==128**-0.5 and kwargs.get('dropout')==0.0 and kwargs.get('sliding_window') is None,'Native attention arguments')
        if current['start']==512 and layer in LAYERS:
            require(layer not in trace,'Duplicate target layer capture')
            qq=q[0].transpose(0,1).detach().clone().contiguous()
            kk=k[0].transpose(0,1).detach().clone().contiguous()
            require(bool(torch.isfinite(qq).all()) and bool(torch.isfinite(kk).all()),'Finite captured tensors')
            trace[layer]={'query':qq,'keys':kk}
    cache=DynamicCache(config=config)
    import ctypes
    libc=ctypes.CDLL(None);libc.malloc_trim.argtypes=[ctypes.c_size_t];libc.malloc_trim.restype=ctypes.c_int
    with torch.inference_mode():
        setup=time.monotonic()
        with FilePager(model,[ASSETS/x['path'] for x in expected],synthetic=False,expected_sources=expected) as pager:
            setup=time.monotonic()-setup;check()
            with InterfaceCapture(qwen,callback) as capture:
                require(qwen.ALL_ATTENTION_FUNCTIONS.get_interface(config._attn_implementation,qwen.eager_attention_forward) is capture.wrapper,'Eager dispatch must use the capture wrapper')
                for lo,hi in ((0,128),(128,256),(256,384),(384,512),(512,528)):
                    current.update(start=lo,end=hi,layers_seen=[]);check();beg=time.monotonic()
                    output=model(torch.tensor([ids[lo:hi]],dtype=torch.long),past_key_values=cache,use_cache=True,logits_to_keep=1)
                    require(current['layers_seen']==list(range(36)),'Incomplete native layer traversal')
                    require(bool(torch.isfinite(output.logits).all()),'Finite final-position logits')
                    del output
                    pager.assert_idle();gc.collect();trim=int(libc.malloc_trim(0));check()
                    call_rows.append({'start':lo,'end':hi,'seconds':time.monotonic()-beg,'trim_return':trim,'self_max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'host_available':host_available()})
            require(all(capture_calls[x]==5 for x in range(36)) and set(trace)==set(LAYERS),'All36 native layers observed five times')
            pager_stats=dict(pager.stats)
    write_json(OUT/'extraction.json',{'config_dimensions':actual,'layers':LAYERS,'all_query_heads':32,'all_kv_heads':8,'calls':call_rows,'capture_calls':capture_calls,'pager_setup_seconds':setup,'pager_stats':pager_stats,'teacher_forced':True,'actual_generated_trace':False,'model_calls':5,'GPU':False})
    # Release the model and full cache before any offline scoring/allocation.
    del model,cache,pager;gc.collect();libc.malloc_trim(0);check()
    artifacts=[]
    for layer in LAYERS:
        target=OUT/('layer_%02d.pt'%layer)
        require(not target.exists(),'No overwrite')
        torch.save(trace[layer],target)
        artifacts.append({'path':target.name,'bytes':target.stat().st_size,'sha256':sha_file(target),'query_shape':list(trace[layer]['query'].shape),'keys_shape':list(trace[layer]['keys'].shape),'dtype':'torch.bfloat16'})
        check()
    write_json(OUT/'tensor_manifest.json',{'raw_tensor_bytes':sum(t.numel()*t.element_size() for x in trace.values() for t in x.values()),'files':artifacts})
    from selector_replay import process_trace
    began=time.monotonic();summary=process_trace(trace,OUT);check()
    write_json(OUT/'completion.json',{'status':'COMPLETE','model_calls':5,'teacher_forced':True,'selector_reference':'FP64 replay only','machine_exact_attention_claim':False,'offline_total_seconds':time.monotonic()-began,'summary':summary,'self_max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024})
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        if OUT.exists() and not (OUT/'failure.json').exists():
            write_json(OUT/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(limit=8),'model_retry_authorized':False})
        raise
