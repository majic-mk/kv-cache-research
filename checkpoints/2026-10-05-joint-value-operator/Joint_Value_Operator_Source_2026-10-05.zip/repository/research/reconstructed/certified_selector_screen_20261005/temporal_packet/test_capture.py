"""Model-free capture unit tests: random tiny attention component only."""
import unittest,types,torch
from capture import InterfaceCapture
from transformers import Qwen3Config
from transformers.models.qwen3 import modeling_qwen3 as qwen
from transformers.cache_utils import DynamicCache
class CaptureTests(unittest.TestCase):
    def test_argument_result_identity(self):
        values=[object() for _ in range(7)];seen=[];answer=object()
        def orig(*args,**kwargs):
            self.assertTrue(all(a is b for a,b in zip(args,values[:6])))
            self.assertIs(kwargs['scaling'],values[6]);return answer
        module=types.SimpleNamespace(eager_attention_forward=orig)
        with InterfaceCapture(module,lambda *a:seen.append(a)) as cap:
            self.assertIs(module.eager_attention_forward(*values[:6],scaling=values[6]),answer)
        self.assertIs(module.eager_attention_forward,orig)
        self.assertIs(seen[0][1],values[1]);self.assertIs(seen[0][6]['scaling'],values[6])
    def test_exception_restores(self):
        def orig(*args,**kwargs):raise ValueError('fixture failure')
        module=types.SimpleNamespace(eager_attention_forward=orig)
        with self.assertRaises(ValueError):
            with InterfaceCapture(module,lambda *a:None):
                module.eager_attention_forward(*([None]*5))
        self.assertIs(module.eager_attention_forward,orig)
    def test_callback_exception_restores(self):
        def orig(*args,**kwargs):self.fail('should not execute')
        def callback(*args):raise ValueError('callback fixture')
        module=types.SimpleNamespace(eager_attention_forward=orig)
        with self.assertRaises(ValueError):
            with InterfaceCapture(module,callback):module.eager_attention_forward(*([None]*5))
        self.assertIs(module.eager_attention_forward,orig)
    def test_native_post_norm_rope_gqa_capture(self):
        torch.manual_seed(907)
        config=Qwen3Config(hidden_size=32,intermediate_size=48,num_hidden_layers=1,num_attention_heads=4,num_key_value_heads=2,head_dim=8,max_position_embeddings=64,rope_theta=10000)
        config._attn_implementation='eager'
        attention=qwen.Qwen3Attention(config,layer_idx=0).to(torch.bfloat16).eval()
        rotary=qwen.Qwen3RotaryEmbedding(config)
        hidden=torch.randn(1,3,32,dtype=torch.bfloat16)
        pos=torch.arange(3).unsqueeze(0);rope=rotary(hidden,pos)
        mask=torch.zeros(1,1,3,3,dtype=torch.bfloat16).masked_fill(torch.triu(torch.ones(3,3,dtype=torch.bool),1),torch.finfo(torch.bfloat16).min)
        received=[]
        def callback(module,q,k,v,m,args,kwargs):received.append((q.detach().clone(),k.detach().clone(),kwargs))
        with torch.inference_mode():
            direct_q=attention.q_norm(attention.q_proj(hidden).view(1,3,4,8)).transpose(1,2)
            direct_k=attention.k_norm(attention.k_proj(hidden).view(1,3,2,8)).transpose(1,2)
            direct_q,direct_k=qwen.apply_rotary_pos_emb(direct_q,direct_k,*rope)
            reference=attention(hidden,rope,mask,past_key_values=DynamicCache(config=config))[0]
            original=qwen.eager_attention_forward
            with InterfaceCapture(qwen,callback) as cap:
                self.assertIs(qwen.ALL_ATTENTION_FUNCTIONS.get_interface('eager',qwen.eager_attention_forward),cap.wrapper)
                observed=attention(hidden,rope,mask,past_key_values=DynamicCache(config=config))[0]
            self.assertIs(qwen.eager_attention_forward,original)
        self.assertEqual(len(received),1)
        q,k,kwargs=received[0]
        self.assertEqual(tuple(q.shape),(1,4,3,8));self.assertEqual(tuple(k.shape),(1,2,3,8))
        self.assertTrue(torch.equal(q,direct_q));self.assertTrue(torch.equal(k,direct_k))
        self.assertTrue(torch.equal(reference,observed));self.assertEqual(kwargs['scaling'],8**-0.5)
if __name__=='__main__':
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    unittest.main()

