"""Tiny deterministic math fixtures only, never real-tensor feasibility evidence."""
import math
import unittest
import torch
from selector_replay import (ARMS, ReplayConfig, SelectorArm, block_logsumexp,
    causal_current_page, full_reference, gqa_kv_head, page_radii, process_trace,
    ranked_top, strict_separation)


def fixture(values):
    values = torch.tensor(values, dtype=torch.float64)
    if values.ndim == 1:
        values = values[:, None]
    n, d = values.shape
    return (ReplayConfig(page_size=8, old_pages=n, r=2, head_dim=d,
                         prefix_tokens=8*n, input_element_bytes=8),
            values[:, None, :].repeat(1, 8, 1))


class SelectorMathTests(unittest.TestCase):
    def check_reference(self, result, q, keys, current):
        ref = full_reference(q, keys, current, 2)
        self.assertEqual(result['old_top_set'], ref['old_top_set'])
        self.assertEqual(result['all_top_set'], ref['all_top_set'])

    def test_logsumexp_and_tie_break(self):
        q = torch.tensor([1.], dtype=torch.float64)
        k = torch.tensor([[1000.], [1000.]], dtype=torch.float64)
        self.assertAlmostEqual(block_logsumexp(q, k), 1000+math.log(2), places=12)
        self.assertEqual(ranked_top({3: 1., 1: 1., 2: 0.}, 2), [1, 3])
        with self.assertRaises(TypeError):
            block_logsumexp(q.float(), k)

    def test_motion_bound_math(self):
        keys = torch.sin(torch.arange(72, dtype=torch.float64)).reshape(3, 8, 3)
        qa = torch.tensor([.4, -1., .2], dtype=torch.float64)
        qt = torch.tensor([-.2, .8, .3], dtype=torch.float64)
        motion = float(torch.linalg.vector_norm(qt-qa))
        radii = page_radii(keys)
        for p in range(3):
            delta = abs(block_logsumexp(qt, keys[p])-block_logsumexp(qa, keys[p]))
            self.assertLessEqual(delta, motion*float(radii[p])/math.sqrt(3)+1e-12)

    def test_anchor_drift_across_consecutive_reuses(self):
        cfg, keys = fixture([4, 3, 0])
        arm = SelectorArm('global_motion', keys, cfg)
        results = []
        for step, value in enumerate([1., 1.1, 1.2, 1.4]):
            q = torch.tensor([value], dtype=torch.float64)
            current = torch.zeros((step+1, 1), dtype=torch.float64)
            result = arm.advance(q, cfg.prefix_tokens+step, current)
            self.check_reference(result, q, keys, current)
            results.append(result)
        self.assertEqual([r['decision'] for r in results], ['initial_full_refresh',
            'global_certified_reuse', 'global_certified_reuse', 'global_failed_full_refresh'])
        self.assertEqual(results[2]['anchor_position_after'], cfg.prefix_tokens)
        self.assertAlmostEqual(results[3]['query_motion_from_full_refresh'], .4)
        self.assertEqual(results[3]['anchor_position_after'], cfg.prefix_tokens+3)
        self.assertEqual(results[1]['refined_old_page_ids'], [0, 1])
        self.assertEqual(results[1]['cost_delta'].get('metadata_scan_passes', 0), 0)

    def test_growing_page_entrant_and_no_future_leak_every_arm(self):
        cfg, keys = fixture([4, 3, 0])
        q = torch.ones(1, dtype=torch.float64)
        all_keys = torch.cat((keys.reshape(-1, 1), torch.tensor([[0.], [20.], [-20.]], dtype=torch.float64)))
        for name in ARMS:
            arm = SelectorArm(name, keys, cfg)
            first = causal_current_page(all_keys, cfg.prefix_tokens, cfg)
            self.assertEqual(arm.advance(q, cfg.prefix_tokens, first)['all_top_set'], [0, 1])
            second = causal_current_page(all_keys, cfg.prefix_tokens+1, cfg)
            result = arm.advance(q, cfg.prefix_tokens+1, second)
            self.check_reference(result, q, keys, second)
            self.assertEqual(result['all_top_set'], [0, 3])
            self.assertEqual(result['cost_delta']['current_tokens_scored'], 2)
        self.assertEqual(tuple(first.shape), (1, 1))
        self.assertEqual(float(first[0, 0]), 0.)
        with self.assertRaises(ValueError):
            SelectorArm('global_motion', keys, cfg).advance(q, cfg.prefix_tokens, all_keys[-3:])

    def test_non_first_gqa_mapping(self):
        self.assertEqual([gqa_kv_head(h) for h in [0, 3, 4, 7, 8, 27, 31]], [0, 0, 1, 1, 2, 6, 7])
        q = torch.tensor([2.], dtype=torch.float64)
        keys = torch.arange(8, dtype=torch.float64).reshape(1, 8, 1)
        self.assertEqual(block_logsumexp(q, keys[:, gqa_kv_head(27)]), 12.)
        self.assertNotEqual(block_logsumexp(q, keys[:, gqa_kv_head(27)]), block_logsumexp(q, keys[:, 0]))
        with self.assertRaises(ValueError):
            gqa_kv_head(32)

    def test_tie_and_near_zero_positive_slack_fallback(self):
        q = torch.ones(1, dtype=torch.float64)
        for values, next_q in [([1, 1, 1], q), ([4, 3, 0], torch.tensor(
                [1.375-2*torch.finfo(torch.float64).eps], dtype=torch.float64))]:
            cfg, keys = fixture(values)
            arm = SelectorArm('global_motion', keys, cfg)
            arm.advance(q, cfg.prefix_tokens, torch.zeros((1, 1), dtype=torch.float64))
            result = arm.advance(next_q, cfg.prefix_tokens+1, torch.zeros((2, 1), dtype=torch.float64))
            self.assertEqual(result['decision'], 'global_failed_full_refresh')
            self.assertEqual(result['old_top_set'], [0, 1])
            if values[0] == 4:
                self.assertGreater(result['global_certificate_slack'], 0.)
        self.assertFalse(strict_separation(1., math.nextafter(1., 0.)))
        self.assertFalse(strict_separation(float('nan'), 0.))

    def test_pagewise_all_omitted_bounds_partial_anchor_unchanged(self):
        cfg, keys = fixture([[4, 0], [3, 0], [0, 10], [-1, 100]])
        arm = SelectorArm('pagewise_motion_secondary', keys, cfg)
        qa = torch.tensor([1., 0.], dtype=torch.float64)
        arm.advance(qa, cfg.prefix_tokens, torch.zeros((1, 2), dtype=torch.float64))
        saved_scores = dict(arm.anchor_scores)
        q = torch.tensor([1., .1], dtype=torch.float64)
        current = torch.zeros((2, 2), dtype=torch.float64)
        result = arm.advance(q, cfg.prefix_tokens+1, current)
        self.check_reference(result, q, keys, current)
        # Lower anchor-score page 3 outranks page 2's upper bound due its radius.
        self.assertEqual(result['refined_old_page_ids'], [0, 1, 3])
        self.assertEqual(result['decision'], 'pagewise_refined_partial')
        self.assertEqual(result['old_top_set'], [0, 3])
        self.assertEqual(arm.anchor_position, cfg.prefix_tokens)
        self.assertEqual(arm.anchor_scores, saved_scores)
        self.assertTrue(torch.equal(arm.anchor_query, qa))
        self.assertGreater(result['cost_delta']['metadata_scan_passes'], 1)
        self.assertGreaterEqual(result['cost_delta']['metadata_page_entries_read'], 8)
        q2 = torch.tensor([1., .2], dtype=torch.float64)
        third = arm.advance(q2, cfg.prefix_tokens+2, torch.zeros((3, 2), dtype=torch.float64))
        self.assertAlmostEqual(third['query_motion_from_full_refresh'], .2)

    def test_pagewise_full_refresh_resets_all_anchor_state(self):
        cfg, keys = fixture([4, 3, 0])
        arm = SelectorArm('pagewise_motion_secondary', keys, cfg)
        qa = torch.ones(1, dtype=torch.float64)
        arm.advance(qa, cfg.prefix_tokens, torch.zeros((1, 1), dtype=torch.float64))
        current = torch.zeros((2, 1), dtype=torch.float64)
        result = arm.advance(-qa, cfg.prefix_tokens+1, current)
        self.check_reference(result, -qa, keys, current)
        self.assertEqual(set(result['refined_old_page_ids']), {0, 1, 2})
        self.assertEqual(result['decision'], 'pagewise_refined_full_refresh')
        self.assertEqual(arm.anchor_position, cfg.prefix_tokens+1)
        self.assertTrue(torch.equal(arm.anchor_query, -qa))
        self.assertEqual(arm.anchor_scores, full_reference(-qa, keys, current, 2)['old_scores'])

    def test_invalid_input_and_partial_refresh_rejected(self):
        with self.assertRaises(ValueError):
            process_trace({}, '/not-created-by-this-test')
        invalid = {layer: {'query': torch.zeros((1, 1, 1)), 'keys': torch.zeros((1, 1, 1))}
                   for layer in (0, 7, 14, 21, 28, 35)}
        with self.assertRaises(ValueError):
            process_trace(invalid, '/not-created-by-this-test')
        cfg, keys = fixture([4, 3, 0])
        arm = SelectorArm('global_motion', keys, cfg)
        with self.assertRaises(ValueError):
            arm.advance(torch.ones(1, dtype=torch.float64), cfg.prefix_tokens+1,
                        torch.zeros((2, 1), dtype=torch.float64))
        with self.assertRaises(AssertionError):
            arm._refresh(torch.ones(1, dtype=torch.float64), cfg.prefix_tokens, {0: 1.})


if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main()
