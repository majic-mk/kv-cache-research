"""New task-specific admission composes the unchanged legacy helper gate."""
from legacy_cpu_release import require_cpu_release as require_legacy_release
from common import admission, require
import os
def require_cpu_release():
    require_legacy_release()
    admission()
    require(os.environ.get('TEMPORAL_GUARD_PID')==str(os.getppid()),'Owned new-task guard required')
    require(os.environ.get('TEMPORAL_PACKET_RUN')=='ONE_EXPLICITLY_ADMITTED_RUN','New task is not released')

