"""Small standard-library guard tests; never starts a model or real launcher."""
import os,signal,subprocess,sys,tempfile,time,unittest
from unittest.mock import patch
from pathlib import Path
import common
from common import write_json,cgroup_limits
from guard import group_processes,kill_owned,child_cpu_limit,interrupted
class GuardTests(unittest.TestCase):
    def test_missing_admission_fails(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(common,'PACKET',Path(d)),patch.object(common,'packet_integrity',return_value='fixture'):
                with self.assertRaises(FileNotFoundError):common.admission()
    def test_lower_inherited_cpu_preserved(self):
        self.assertEqual(child_cpu_limit((120,180)),120)
        self.assertEqual(child_cpu_limit((-1,200)),200)
        self.assertEqual(child_cpu_limit((-1,-1)),2350)
    def test_interrupt_handler_raises(self):
        with self.assertRaises(InterruptedError):interrupted(signal.SIGTERM,None)
    def test_claim_is_exclusive(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'claim.json'
            write_json(p,{'max_runs':1})
            with self.assertRaises(FileExistsError):write_json(p,{'max_runs':1})
    def test_owned_group_cleanup(self):
        child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],start_new_session=True)
        try:
            deadline=time.monotonic()+2
            while not group_processes(child.pid) and time.monotonic()<deadline:time.sleep(.01)
            self.assertTrue(group_processes(child.pid))
            self.assertTrue(kill_owned(child.pid))
            child.wait(timeout=2)
            self.assertFalse(group_processes(child.pid))
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGKILL);child.wait()
    def test_cgroup_visibility_explicit(self):
        result=cgroup_limits()
        self.assertIn(result['visibility'],('exposed','unavailable'))
        self.assertIsInstance(result['ancestors'],list)
    def test_parent_death_kills_owned_child(self):
        packet=str(Path(__file__).resolve().parent)
        script="import os,subprocess,sys,time;sys.path.insert(0,"+repr(packet)+");from guard import setup_child;p=os.getpid();c=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],preexec_fn=lambda:setup_child(p));print(c.pid,flush=True);time.sleep(20)"
        parent=subprocess.Popen([sys.executable,'-c',script],stdout=subprocess.PIPE,text=True,start_new_session=True)
        child_pid=None
        try:
            import select
            ready,_,_=select.select([parent.stdout],[],[],3)
            self.assertTrue(ready,'Child setup deadline')
            child_pid=int(parent.stdout.readline().strip())
            self.assertTrue(group_processes(child_pid))
            parent.kill();parent.wait(timeout=2)
            deadline=time.monotonic()+2
            while group_processes(child_pid) and time.monotonic()<deadline:time.sleep(.01)
            self.assertFalse(group_processes(child_pid))
        finally:
            if parent.poll() is None:parent.kill();parent.wait()
            parent.stdout.close()
            if child_pid is not None:kill_owned(child_pid)
if __name__=='__main__':unittest.main()
