# Dustin selected-head scoring plane: source and admission check

2026-10-05 UTC. **Do not admit this as a research topic yet.** A transparent exact-SRH index can be specified using released CompressKV artifacts, but that surrogate is not Dustin. Its group-aware memory and missing-key traffic are substantial, and the closest systems already implement the underlying split between a compact resident selector and offloaded full KV.

The potentially substantive comparison is **exact head/layer sparsity versus approximate all-head key indexes under equal total memory and transferred bytes**. Cross-domain transfer is allowed; the present limitation is lack of evidence for a beneficial operating point, not that the ingredients were used elsewhere.

## 1. Primary-artifact search and version boundary

Dustin arXiv2606.24957v1 (2026-06-23) supplies the inspected methods and AppendixL capacity limitation. Its abstract page, full HTML, official [PMLR record](https://proceedings.mlr.press/v306/lee26d.html), and a verified [coauthor institutional page](https://www.ee.ncku.edu.tw/teacher/index2.php?teacher_id=190) did not expose implementation/configuration artifacts.

The PMLR metadata lists additional coauthors relative to arXivv1. The PMLR PDF link did not yield readable PDF content in the web tool; its GitHub contents lookup returned404. Its OpenReview link reached browser verification. We did not claim to inspect a different published full-text version, solve a new challenge, or download the approximately26MB arXiv source/PDF. The arXiv methods remain explicitly versioned.

Exact-title and Dustin repository searches, including relevant author organizations, did not verify a repository. A secondary “View Code” badge is not evidence of an author release; its page returned403. This is a bounded “not verified” result, not a claim that no code can exist.

Missing for an exact Dustin reproduction:

- the selected target layer and its SRH identities/count
- selected draft layers/heads and tuned split m for a particular pair
- exact draft-cache policy and associated full-history scoring-key retention
- accepted-state/query capture, cache layout and actual gather/offload code

[Dustin §§4.1–4.2, AppendixC/I/L](https://arxiv.org/html/2606.24957v1) describes a global token support across target layers, selected using historical target and lookahead draft attention. Target selection starts from one profiled layer. Sink4 and recent16 are protected; Qwen2.5-7B/0.5B uses depth3. It acknowledges full-history capacity remains. Offline profiling is required, not learned probe training. Its “same draft configuration as the corresponding baseline” wording does not resolve every full-versus-streaming cache implementation detail.

No opaque baseline was reconstructed.

## 2. Available adjacent artifact: CompressKV

The [author repository](https://github.com/TUDa-HWAI/CompressKV/tree/4838455a7b0d32e130b96953a7487703d3af4ca4) is pinned to commit4838455a7b0d32e130b96953a7487703d3af4ca4. Its small released files include ranked query heads for Qwen2.5-7B, Llama3.1-8B and Mistral.

Inspected code:

- methods/compresskv/snapkv_utils.py: selects first_k=4 query heads, maps each to KV group by integer division, computes selected-head attention, applies softmax, sums over observation queries, pools, averages heads and gathers all KV groups at selected positions
- methods/compresskv/qwen2_hijack.py: prompt compression path and subsequent cache append
- longbench/pred_compresskv.py: defaults/configuration wiring
- scripts/run_longbench.sh and head-extraction utility

[CompressKV §3.3 and implementation details](https://arxiv.org/html/2606.24467v1) make this prompt-time, per-layer eviction with an observation window8 and pooling kernel5. It does not implement repeated global-history sparse verification. Turning it into an online exact-SRH selector is a new, openly specified surrogate, and cannot inherit Dustin's speed or quality results.

The head rankings are usable without re-running their identification, but are model-specific. They do not establish an artifact for the user's existing4B model. No weights were downloaded.

## 3. Exact GQA memory audit from real source geometry

The [Qwen2.5-7B config](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/raw/main/config.json) has28 layers,28 query heads,4 KV heads, dimension128 and BF16 storage. Each KV group serves7 query heads. The released top4 heads in each layer touch **67 distinct layer/KV-group pairs out of112**.

This is not4/28 of key memory. Source-only arithmetic at one sequence of32768 tokens:

| Object | Raw bytes | MiB |
|---|---:|---:|
| Full target KV | 1,879,048,192 | 1792 |
| Full target keys | 939,524,096 | 896 |
| Exact top4 SRH key plane across all layers | 562,036,736 | 536 |
| One exact group in every layer, minimum | 234,881,024 | 224 |
| All-head2-bit index payload, before metadata | 117,440,512 | 112 |
| Hypothetical one target layer,1–4 unique groups | 8,388,608–33,554,432 | 8–32 |
| Full target KV for512 gathered token positions | 29,360,128 | 28 |

Thus the released all-layer top4 exact plane retains59.8% of full key bytes, or29.9% of full KV. It uses4.786 times the raw2-bit all-head index payload. Even one exact group per layer costs twice that payload on this architecture.

The inspected CompressKV implementation uses advanced indexing to build a per-query-head key temporary. Deduplicating the persistent GQA plane therefore does not automatically eliminate that temporary; a revised gather/kernel layout would be needed to avoid it.

These are payload counts, not measured allocations. Scale/codebook metadata, scoring scratch, gather buffers, graph reservations, weights, draft state and recent/generated state must all be added. A raw index ratio does not prove either system's total memory or throughput.

The attractive8–32MiB one-layer figure is only a conditional bound, using1–4 groups. It is not a verified Dustin configuration, nor evidence that one layer preserves other layers' selections.

The [Qwen2.5-0.5B draft config](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/raw/main/config.json) separately gives24 layers,14 query heads,2 KV heads and dimension64. Its full BF16 KV at32768 tokens would be384MiB. This is a conditional full-cache storage count, not an assertion about the unavailable Dustin implementation.

The released files contain head rankings, not a ready real Q/K/V trace for this falsifier. The audit script and complete layer/group output are saved. It imports only the Python standard library and processes released IDs; it performs no model inference.

## 4. General scoring, capacity and traffic formulas

For selected query-head set H_l at layer l, G_l is the set of unique GQA groups they reference. With element size b, head dimension d_l, history N and observation-query count w_l:

M_index = N * sum_l(b*d_l*|G_l|)
F_QK = 2*N * sum_l(w_l*d_l*|H_l|)

F_QK counts multiply/add operations, not softmax, pooling, top-k, reductions or time. Even when two selected queries share a key, they have different dot products and normalizers. GQA deduplicates stored keys, not the query-head computation.

For the released all-layer Qwen top4 set, F_QK is939,524,096 operations at window1 and7,516,192,768 at window8. CompressKV pays its published window8 selection at prefill; charging this every decode step would be a new cost.

A group-deduplicated resident plane can theoretically reuse its exact K in verification. If every selected position must supply all groups, the ideal missing payload per token/layer is:

b*d_l*(2*Hkv_l - |G_l|)

This includes all V and missing K. A physical packed-page implementation may still transfer resident K again; the ideal formula is not automatically attained. With the audited all-layer Qwen set, it is40,192 bytes per token versus28,672 for a V-only path, a1.402× payload ratio before metadata and copies. With a very small scoring-layer subset, the whole-model ratio approaches2×.

Let P_l(I_l) be the physical pages covering logical selected indices, R_l ready resident pages, and page byte sizes s_p. The actual miss traffic is the sum over p in P_l(I_l) minus R_l of s_p, separated into K/V components if their layouts permit reuse. Already queued pages are reusable only after their completion event.

For illustration of the bound,512 logical tokens with16-token pages can require up to8192 physical token slots. For this target, cold full-KV traffic ranges from28MiB for perfectly packed512 slots to448MiB at that maximum page expansion. This is a combinatorial bound, not a trace measurement or a proposed page size for Dustin.

Accepted KV that is to remain recallable also needs backing-store writes or retained device storage. Rejected speculative entries must not pollute the historical scoring plane. Double buffering, prefetch time windows and shared-link contention belong in the cost inequality.

## 5. Query readiness and exactness

An exact key plane gives exact selected-head scores only for the supplied queries. It does not make a draft, stale or sparse-derived query equal to the dense target's query.

For a same-token late-layer global selector, queries may not be available before earlier layers need their selected KV. The implementation must specify a historical query, a proxy, an extra scoring forward or some other causal route and charge it. Dustin explicitly uses historical target state plus draft lookahead; replacing that with current exact target queries is not free.

The transparent comparison must preserve the same query tensor, position transform, normalization and tie rule when isolating index representation. A separate closed-loop test is then needed to evaluate how selected supports alter future queries and committed state.

## 6. Closest mechanisms already present

Detailed primary-source and code anchors are in prior_designs/comparison_report.md.

- **ShadowKV:** low-rank full-head keys and chunk summaries on GPU, CPU value backing, miss-aware fetch and overlapped key reconstruction/value movement
- **RetrievalAttention:** attention-aware CPU indexing and CPU partial attention combined with GPU partial attention; not merely GPU-key ranking followed by V fetch
- **DuoAttention:** actual KV-group partition, full KV for retrieval groups and sink/recent KV for streaming groups
- **HeadInfer:** exact group-level KV offload and prefetch; already combined with DuoAttention
- **InfiniGen:** resident partial-key channels with partial next-layer query weights predict which full KV to fetch one layer ahead; this is the closest causal selector/data-plane control
- **Double Sparsity:** selected exact key channels across full history plus full-KV offload and next-layer prediction; a close channel-versus-head representation control. Its GQA execution readiness was not established
- **Context-intensive offloading/YAKV:** per-token low-bit key landmarks are a strong equal-index-budget selector control

These mechanisms do not prove exact SRH scoring useless or forbid a meaningful transfer. They prevent treating head partition, resident key metadata, CPU values or prefetch as the contribution by themselves.

Crucial YAKV implementation distinction: the evaluation path can quantize/dequantize landmarks into BF16 tensors and retain full device keys; it is not a memory/speed baseline. The separate real offload inference path has packed2-bit landmarks and CPU KV, but also substantial gather/dequantization buffers. Its total allocation must be inspected, not inferred from index bits.

## 7. Transparent hypothesis and cheapest valid next gate

If pursued later, the explicit surrogate would be:

**Freeze CompressKV's released top4 heads for Qwen2.5-7B; store their unique GQA keys exactly, keep offloaded historical KV recallable, and reuse the specified selected-head score aggregation to choose per-layer token support. Test whether avoiding key approximation compensates for omitted-head information and additional missing-K traffic.**

This is not Dustin reproduction and not yet an admitted research mechanism. A precise online observation-window/query policy must be frozen before any run; using the prefill code unchanged does not create an online decoder.

Strongest controls:

1. Exact all-head, token-level key scoring as a selector oracle
2. InfiniGen's partial-channel causal predictor and Double Sparsity's channel index
3. ShadowKV's published low-rank/chunk selector
4. Actual low-bit per-token landmark selection at matched **total** device footprint
5. The same head selector with ordinary full-key storage, isolating storage/layout from ranking
6. DuoAttention plus HeadInfer for exact group partition/offload
7. Original CompressKV for the prompt-only setting, without borrowing online claims

A necessary CPU falsifier can operate on already-recorded real Q/K/V and page/residency traces, if they become available. Freeze model/checkpoint, prompts, context/output horizon, head set, query provenance, memory cap and quality tolerances first. Compute selector score equality, omitted-head attention mass, selected-attention output error and page-closed miss bytes. Include the scorer's transient memory and required backing writes.

Reject the proposed operating point if it exceeds the total device cap, has no selector-quality advantage over the equal-total-memory low-bit/channel baseline, or if its optimistic compulsory-transfer/scoring lower bound cannot beat the measured baseline. Replaying full-model quality under changed supports still requires later authorized model execution; tensor snapshots only reject selector feasibility.

At the raw112MiB index cap, preserving the released top4 exact plane already fails the storage gate536>112. This limited arithmetic rejection does not establish failure at a different total-system memory budget. Reducing layers or heads changes the frozen surrogate and would require a new hypothesis, not a post-hoc rescue.

## 8. Admission decision

**NOT_ADMITTED_AFTER_SOURCE_AND_STORAGE_SCREEN.**

The available adjacent code makes a clear future hypothesis possible. It does not currently provide an authentic online trace, Dustin configuration, matched-memory quality result, or distinct algorithmic improvement beyond replacing one known selector representation with another. Existing author-selected heads are not transferable to the user's4B model without verification/profiling.

No model/GPU experiment, install, large download, provider request or publication occurred. The only execution was standard-library arithmetic on a small released head-ID file. The earlier rotation and P&F reports remain unchanged.

A useful reopening condition is concrete: a released compatible query/key trace or an authorized small-model trace plan must show an equal-total-memory selector advantage and plausible transfer headroom over InfiniGen/ShadowKV/low-bit landmarks. Otherwise this branch should stay closed rather than expand into arbitrary new names.
