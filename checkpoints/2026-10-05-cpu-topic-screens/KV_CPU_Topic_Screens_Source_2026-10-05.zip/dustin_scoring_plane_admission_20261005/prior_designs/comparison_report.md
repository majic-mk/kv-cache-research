# Selected exact-key scoring plane: closest-design and implementation admission
Date: 2026-10-05. Scope: bounded primary-paper and author-code inspection only. No inference, installation, compilation, GPU execution, benchmarks, or model/data downloads.

## Decision
**Conditionally distinctive, not yet admitted as a demonstrated improvement.** Keeping a small exact-key scoring plane and using it to request a broader sparse KV execution set is a meaningful combination to test. However, neither GPU-side global-history scoring, head-aware offload, nor selected-KV fetching is new. The specific hypothesis is that a *small, causally available set of exact retrieval-head keys predicts a shared execution-token set better per total byte/cost* than existing compressed-key/partial-channel/all-head selectors. This requires a query-generation schedule and evaluation; exact stored keys do not establish exact dense-model relevance.

“DoubleCache” could not be identified as an LLM primary paper or author repository in bounded exact-name searches. Do not attribute a mechanism or novelty result to that name. Double Sparsity is separately verified below and must not silently be renamed DoubleCache.

## Closest mechanisms, with author-code evidence

### 1. DuoAttention: true head partition, but complete attention state rather than a scoring index
[Paper §3.1](https://arxiv.org/html/2410.10819v1#S3.SS1) assigns a gate to each **KV head**, so all query heads sharing it in GQA receive the same full/streaming policy. Gates are optimized against output deviation rather than merely high attention scores.

[Author static cache](https://github.com/mit-han-lab/duo-attention/blob/fe93c314ae87306ef6629dc16713250b4718ffe7/duo_attn/patch/static_kv_cache.py#L31-L99) allocates full-length **K and V** for retrieval groups and sink+recent **K and V** for streaming groups. [Llama implementation](https://github.com/mit-han-lab/duo-attention/blob/fe93c314ae87306ef6629dc16713250b4718ffe7/duo_attn/patch/llama.py#L186-L267) splits/reorders heads and computes the two attention outputs before concatenation.

Difference: the proposed plane retains K only for selected groups, uses them to choose tokens for other heads/layers, and preserves offloaded state for those others. DuoAttention itself does not provide that cross-head token-ranking guarantee. Its released head patterns are a reproducible *alternative head-selector control*, not evidence that their scores predict all heads.

### 2. HeadInfer: head-granular full-cache scheduling, including a DuoAttention combination
[Author forward](https://github.com/wdlctc/headinfer/blob/b57e449f3c0709739d812134649fdae7d1ca6a9f/headinfer/mp.py#L30-L106) loops over every KV head, projects its query group, updates one cache slot, and computes attention before concatenating outputs. [Slot mapping](https://github.com/wdlctc/headinfer/blob/b57e449f3c0709739d812134649fdae7d1ca6a9f/headinfer/mp.py#L214-L237) increments layer offsets by number of KV heads. Although [cache.py](https://github.com/wdlctc/headinfer/blob/b57e449f3c0709739d812134649fdae7d1ca6a9f/headinfer/cache.py#L30-L68) names entries “layers,” these remapped slots are head groups. It brings full K+V slots in and evicts the previous slot.

[Paper Appendix D](https://arxiv.org/html/2502.12574v1#A4) already combines head-wise offload with DuoAttention retrieval/streaming sparsity. Thus “selected retrieval heads + offload” alone is not an adequate contribution. The proposed difference is a persistent K-only selector with token-sparse execution, whereas baseline HeadInfer computes full attention head by head. HeadInfer remains a useful exact full-attention offload control, with transfer cost rather than lost-state bias.

### 3. InfiniGen: closest causal resident-index + selective-KV-prefetch control
[Paper §4.3 and memory discussion](https://arxiv.org/html/2406.19707v1) uses a GPU-resident partial key cache and partial query weights, selecting channels after a skewing transformation. It predicts layer i's important tokens using layer i−1's attention input, enabling prefetch before the true layer-i query is available.

[Author selection controller](https://github.com/snu-comparch/InfiniGen/blob/3754f52d131c30ab7a310e3c4cf356e8e3326ac3/speedup/infinigen/infinigen/kv_selection_controller.py) explicitly computes the proxy query, multiplies partial historical keys, counts scores above max−alpha, averages a count over heads, and selects that many entries per head. [Runtime](https://github.com/snu-comparch/InfiniGen/blob/3754f52d131c30ab7a310e3c4cf356e8e3326ac3/speedup/flexgen/infinigen/flex_opt.py#L430-L465) gathers both K and V into a pinned staging allocation and copies them on a prefetch stream; partial cache updates are at lines 510–542.

Difference: exact selected-head vectors replace channel-reduced all-head proxies; a shared global token set could replace per-head selection. The new design must not claim its exact keys make its early/proxy query exact. InfiniGen already owns the basic resident-small-key-index → predict → fetch-full-KV pattern and explicitly handles the scheduling issue.

### 4. Double Sparsity: exact selected key channels for all historical tokens, plus offload
[Author offloading/model.py](https://github.com/andy-yang-1/DoubleSparse/blob/b0575e638a279d9b2bdd2359dc3fcb5616a1c67a/offloading/model.py#L83-L147) keeps full K+V in pinned CPU storage, small GPU execution caches, and a full-history GPU k_label channel subset. [Decode](https://github.com/andy-yang-1/DoubleSparse/blob/b0575e638a279d9b2bdd2359dc3fcb5616a1c67a/offloading/model.py#L342-L393) scores selected channels, obtains top-k, and fetches K+V using DGL pinned-row gather; most layers use a next-layer proxy query to prefetch on a separate stream.

This is a particularly close representation ablation: exact *channels* across heads versus exact *heads* across channels. Current code hard-codes first/last unstable layers and its offload shapes mix query-head and KV-head counts; do not assume the offloading branch is drop-in GQA support without testing. No claim of execution readiness was established.

### 5. ShadowKV: low-rank key reconstruction + landmark scoring + CPU values
[Author efficient cache](https://github.com/ByteDance-Seed/ShadowKV/blob/e51904cdeab7d4d34013370f09f2cf5fcd655e15/models/kv_cache.py#L371-L719) is concrete and directly reusable for comparison:
- Pinned CPU V is chunk-major; K's low-rank factors and landmark vectors are moved to GPU before decode (lines 400–408, 480–530, 668–683)
- Post-RoPE chunk means are scoring landmarks; outlier and recent K+V stay resident (lines 532–588)
- Query-head scores are max-reduced within each GQA group; top chunks are selected **per KV head** (lines 616–645)
- Cache-hit offsets avoid re-fetching present V; missed K is reconstructed and RoPE applied (lines 647–666)
- [Model scheduling](https://github.com/ByteDance-Seed/ShadowKV/blob/e51904cdeab7d4d34013370f09f2cf5fcd655e15/models/base.py#L140-L164) overlaps V transfer with key reconstruction

Difference: the proposal eliminates approximation for the retained scoring heads, but must fetch missing full K for all unretained groups. It cannot inherit ShadowKV's V-only transfer accounting. Beware the separate ShadowKVCache accuracy class: its misleadingly named v_cache_cpu is GPU-resident; use ShadowKVCache_CPU for transfer claims.

### 6. Context-intensive offloading / YAKV: mandatory equal-index-byte accuracy control, with two very different code paths
[Primary paper §§4.1–4.3](https://arxiv.org/html/2604.08426v1#S4) finds that low-rank reconstruction and chunk-mean selection fail on more information-intensive tasks. It evaluates an exact BF16 per-token key “oracle” and low-bit per-token/small-chunk keys, plus residual landmarks. This is direct prior evidence for replacing approximate chunk scoring, not evidence that retrieval-head-only scoring suffices.

**Accuracy implementation is simulation:** [ShadowKVCache](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/shadowkv-models/shadowkv_models/kv_cache.py#L112-L413) labels itself accuracy-only. It stores v_cache_cpu on device, defaults keys_on_device=True, and quantize_dequantizes landmarks into BF16 arrays. rank=-1 retains full keys; keys_on_device=False still invokes result.to(device) before gathering in the inspected get_key_cache path (lines 518–526). This path is not valid physical-memory/transfer evidence for low-bit offload.

**Separate actual inference implementation exists:** [minisgl attention/shadowkv.py](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L98-L151) allocates packed 2-bit landmark codes and scales on GPU. With enable_offloading=True, lines 180–258 allocate full K+V on CPU and map it for GPU addressing. [map_to_gpu](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/shadowkv/csrc/shadowkv.cpp#L117-L190) host-registers CPU storage and wraps the same pointer; it does not copy the full cache into HBM. [Gather](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/shadowkv/csrc/gather_kv_cache.cu) transfers both K and V selected by per-head landmark indices.

**Important total-state caveats:** inference code preallocates gathered KV scratch with maximum sequence capacity, not just sparse budget (lines 285–289). When KV quantization is on, it also allocates a BF16 dequantized maximum-sequence buffer plus full-history scales (lines 192–224). These are one-layer execution buffers rather than all-layer full KV residency, but can be material. Nonquantized landmark scoring averages queries within GQA groups (lines 535–552), unlike ShadowKV's max-of-normalized per-query scores. README requires page_size=1, no CUDA graphs, and naive cache. It is released code, not a benchmarked drop-in production baseline in this investigation.

### 7. RetrievalAttention versus its current successor
[Original paper §§3.2–3.3 / Appendix C](https://arxiv.org/html/2409.10516v1#S3.SS2) places indexed full KV in CPU, uses an attention-aware graph built from prefill query/key relations, and computes CPU partial attention alongside GPU sink/recent attention. Partial outputs are merged, avoiding bulk selected KV H2D. For GQA it describes one graph per query head while sharing underlying KV vectors. This is not a resident GPU exact-key plane.

The public repository now implements **RetroInfer**, not that original algorithm. Current main and the first code-upload commit (4fc50f6, 2025-05-15) contain retroinfer_cache.py; a prior inspected commit contains only README among code-like files. Do not relabel current results as reproduced original RetrievalAttention. [Current author code](https://github.com/microsoft/RetrievalAttention/blob/03f912c6e917c380d9d90c5ec85bb0f161ba53ef/cache_hub/retroinfer_cache.py#L754-L828) scores GPU cluster centroids, sums normalized query-group scores, fetches missed full-KV pages via a CPU wave buffer, and merges approximation from an estimation zone. It supplies a useful released sparse offload engine/control.

## Derived systems costs: not measured results
Let B=batch, N=history tokens, d=head dimension, e=bytes per element, H_l=KV heads in layer l, G_l=distinct KV heads whose exact keys are resident, and P_l=fetched missing token count **after page closure and cache-hit subtraction**.

- Exact scoring-key storage: B N d e ΣG_l. Full KV reference: 2 B N d e ΣH_l. Count unique KV groups, not selected query heads; multiple retrieval query heads may share keys, and scattered heads may cover nearly every group.
- Ideal selective H2D when resident scoring keys are reused: B d e Σ[P_l(2H_l−G_l)]. If the fetch path copies full all-head KV pages without excluding resident K, use 2 B d e Σ[P_l H_l]. Metadata, padding, staging, new-token writes, and redundant layout copies are additional.
- ShadowKV's V-only ideal is B d e Σ[P_l H_l]. Therefore little resident-head coverage approaches twice its transferred element count for the same sparse set. A full-head exact K/V-offload variant has a half-full-KV GPU storage floor before buffers.
- Raw BF16 exact-key fraction f matches 2-bit all-head key-index bytes only when f=1/8. This comparison excludes quantization scales/codebooks and *every* execution buffer; it is not a whole-system memory or speed result. The parent-derived Qwen2.5-7B 67/112-group example has f≈0.598, so its exact plane is far larger than a 2-bit all-head index.
- Exact token selection plus fixed-size page transfer can amplify traffic sharply. For k scattered selected tokens, page size c, and N tokens, fetched token capacity is at most min(N,kc). Under an illustrative independent uniform selection approximation, expected capacity is N[1−(1−c/N)^k]. This is not an empirical claim; contiguous/local selections can be much better.
- Speculative branch/step/head/layer unions must be measured after deduplication. Token-budget equality before page closure is not transfer-budget equality.
- Resident keys still require full-history HBM scan for each scoring query. Use actual per-step queries and group reuse when counting scoring traffic and arithmetic.

## Causality, exactness, and admission conditions
These are analytical requirements, not claims made by the compared papers:
1. State the source and time of every scoring Q. Exact K with sparse/draft Q is exact only for that Q, not for the dense target query.
2. A global set aggregated from later-layer current queries cannot be available before those layers have run. Specify a separate scoring pass, a proxy/previous-step Q, a single accessible layer, or a sequential update rule, and charge its cost.
3. A sparse verification pass generally changes target logits. Full CPU KV availability does not make the sparse acceptance test distribution-preserving. An exact fallback or valid certificate is needed for a lossless speculative-decoding claim.
4. Compare at least: full/exact offload; same scoring/fetch engine with all-head exact keys; selected-head exact keys; random or budget-matched KV-group selection; a DuoAttention-derived head set; compressed all-head index (YAKV/ShadowKV); and channel-sparse resident index (InfiniGen/DoubleSparse).
5. Hold token/page geometry, causal scoring schedule, precision, fallback policy, and total GPU resident/staging bytes comparable. Report acceptance/output agreement, CPU↔GPU bytes, page miss rate, head/group coverage, index scan latency, gather latency, full fallback incidence, and accepted-token throughput.
6. Treat released surrogate head patterns as surrogate evidence. Do not label them Dustin's unreleased target-layer artifact or assume a 7B/8B pattern transfers to a 4B model.

## Receipts and limits
The sources/ directory contains only fetched UTF-8 source/config/README files; receipts/ records repository trees and file identities. source_manifest.json pins blob hashes and commit URLs. Source content integrity is checked with Git blob SHA-1 and SHA-256; report validation is static only. No performance or hardware availability claim has been established.

