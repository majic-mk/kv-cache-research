"""Read-only arithmetic on released head IDs; no model, tensor library or timing claim."""
import json
from pathlib import Path
BASE = Path(__file__).resolve().parent
heads = json.loads((BASE/'sources/CompressKV_scores__Qwen2.5-7B-Instruct_head_idx.json').read_text())
cfg = json.loads((BASE/'sources/Qwen2.5-7B_geometry.json').read_text())
L, Hq, Hkv, d, b = (cfg[k] for k in ('num_hidden_layers','num_attention_heads','num_key_value_heads','head_dim','bytes_per_element'))
assert L == len(heads) and Hq % Hkv == 0
r, N, m = Hq//Hkv, 32768, 4 # m is the author's fixed first_k, not selected after this audit
rows=[]
for layer in range(L):
    order=heads[str(layer)]
    assert len(order)==Hq and set(order)==set(range(Hq))
    q=order[:m]
    groups=sorted({x//r for x in q})
    rows.append(dict(layer=layer,query_heads=q,kv_groups=groups))
G=sum(len(row['kv_groups']) for row in rows)
out=dict(model=cfg['model_id'],N=N,first_k=m,gqa_ratio=r,rows=rows,
    sum_groups=G,full_groups=L*Hkv,
    exact_top4_key_bytes=N*d*b*G,
    full_KV_bytes=2*N*d*b*L*Hkv,
    full_key_bytes=N*d*b*L*Hkv,
    raw_2bit_allhead_index_bytes=N*d*L*Hkv//4,
    minimum_one_exact_group_per_layer_bytes=N*d*b*L,
    exact_selector_QK_flops_window1=2*N*d*L*m,
    exact_selector_QK_flops_window8=2*N*d*L*m*8,
    ideal_missing_KV_bytes_per_selected_token=d*b*(2*L*Hkv-G),
    V_only_bytes_per_selected_token=d*b*L*Hkv,
    note='Raw storage/operation counts only. Not actual allocation, speed, quality, or Dustin reproduction.')
(BASE/'group_memory_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
