# Exact comparison checklist, pending primary P&F access

This is an evidence-acquisition checklist, not a proposed research contribution or a novelty verdict.

Resolve from the paper/code:
1. Which model produces each layer's key-importance signal? Does the draft use the target's KV, own KV, shared weights or a learned mapping?
2. Does P&F accept drafted tokens into output, and what verifier distribution is used: dense target, sparse target or corrected target?
3. Are supports chosen per draft token, by union over a speculative block, or reused across iterations? Is causal verification independent of later candidate tokens?
4. At what point does the fetch become eligible, and which computation overlaps it? Distinguish HBM gathering, CPU-to-GPU transfer and network transfer.
5. Which completion/fence must precede verification, and what happens on partial acceptance, rejection or failed fetch?
6. Does full KV remain on GPU or CPU? Count draft KV, metadata, working-set union, residual/tentative state and double buffers.
7. What author-stated limitations remain after the joint path? Separate no artifact, unimplemented integration and genuinely unspecified mechanism.
8. Compare directly against OasisKV §§4.2–4.3 and §5.3.1, whose prototype uses one forced-rejected lookahead token and a layer-local capped prefetch pipeline.

Do not introduce an alternative framework or CPU simulator before resolving these source questions. A missing full text is not a promising residual. Keep the earlier frozen rotation screen unchanged.

