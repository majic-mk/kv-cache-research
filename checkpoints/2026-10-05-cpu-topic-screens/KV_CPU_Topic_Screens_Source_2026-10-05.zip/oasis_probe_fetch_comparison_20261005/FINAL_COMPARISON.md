# OasisKV / Probe-and-Fetch: completed full-text comparison

2026-10-05 UTC. **Close the broad “accepted speculation plus sparse prefetching” proposal: the joint execution path already exists in Probe-and-Fetch.** Its quality contract is approximate sparse verification, not equivalence to serial OasisKV or the dense target. Requiring that stronger equivalence does not automatically create a new research contribution.

This resolves the previously missing paper-level comparison. It does not reproduce either system or claim access to unpublished implementation details.

## Source identity and access

The user supplied the actual institutional PDF, Library file ID libfile_a517babe75388191ad5141ace93af9d8. The file is 1,946,978 bytes, SHA-256 bb34e500161c447f3d716298a0c193a15e8cccc38594d1cf1d648db6b3afb4d0. It contains 12 physical pages: one CityUHK cover plus article pages **8127–8137**. The cover identifies the final published version; title, authors, venue and DOI **10.1145/3774904.3792794** match the [institutional record](https://scholars.cityu.edu.hk/en/publications/probe-and-fetch-dynamic-kv-cache-pruning-for-accelerated-long-con/).

The text was extracted successfully after a recoverable cross-reference warning. Printed page8131, containing the support-union and rejection equations, was rendered and visually checked. The original PDF was not modified. Sections2.1–2.6,3.1–3.4,4.1–4.2, conclusion and AppendixA were read.

No public author implementation/checkpoint was verified. Both [first-author](https://aslyc.github.io/) and [corresponding-author](https://rui-kong.github.io/) pages list the exact paper but do not link a separate artifact for it. The failed browser challenge is no longer a reading blocker because the upload supplied the paper.

## 1. What P&F actually does

The following refers to the uploaded final paper, not its abstract:

- **Training, pp8129–8130, §2.3:** a single-layer EAGLE-3-inspired probe shares frozen embeddings/LM head with the target, consumes selected target hidden representations, and is trained for next-token prediction, output-distribution distillation, and attention-pattern matching
- **Memory, pp8130–8131, §2.4:** prompt KV is placed in CPU backing memory, with a GPU active cache containing prefetched historical KV and newly generated entries
- **Selection, p8131, Eq1:** the probe produces gamma drafts. Their individual top-k historical index sets are combined by union
- **Overlap, p8131, §2.5:** fetching the entries identified at draft step j overlaps computation of draft step j+1 on separate CUDA streams
- **Verification and commit, p8131, §2.5:** the target verifies the block using the fetched compact cache, then commits the accepted prefix and a correction token. The described path has a single target verification pass; it does not prescribe re-running each accepted token against serial OasisKV supports
- **Quality contract, pp8128 and8131:** sparse verification explicitly relinquishes standard full-context distributional equivalence. Eq2 uses the sparse target probability p_L(x | prefix, C_sparse) in the residual correction
- **Experimental boundary, p8132, §3.1:** reported offline decoding uses temperature0, no CoT and maximum128 output tokens. Probe training uses a 2B-token subset. The single-GPU model is Llama3.1-8B on A100; other reported large models use TP8

The paper's claims of good measured quality are not a proof of exact dense sampling or of long-reasoning fidelity. Its correction formula cannot, by itself, restore a dense distribution that was never evaluated.

## 2. Exact comparison with OasisKV

[OasisKV §§4.2–4.3 and5.3.1](https://arxiv.org/html/2608.08097v1) uses a public draft/MTP artifact to obtain one lookahead token. It propagates that token alongside the normal token through the target's current sparse working set, scans key summaries, and prepares the next layer-specific resident sets with capped transfers. The published prototype forces draft rejection. Its lookahead queries therefore need not become committed target state.

| Question | P&F, published paper | OasisKV, published paper |
|---|---|---|
| Accepted draft tokens | Yes, multi-token block | No; forced rejection |
| Predictor | Target-aligned trained probe | Reused public draft/MTP plus target-side lookahead queries |
| Historical selection | Union of per-draft top-k indices | Per-layer/head summary ranking and capped updates |
| Transfer overlap | CPU fetch during subsequent drafting | Layer-local next-step pipeline |
| Target forward used for output | Sparse verification on fetched block context | Normal sparse next-token execution |
| Claimed exact dense equivalence | Explicitly relinquished | Sparse approximation evaluated against dense baseline |
| Detailed source artifact independently inspected | None verified | None verified |

P&F therefore directly covers the proposed broad joint path, including CPU offload. “Train-free deployment” alone is not the remaining invention: OasisKV already supplies that predictor route, so combining the two still needs a specific additional contribution.

## 3. Reconcile the accepted-state obligation

The earlier analysis was valid for a particular stronger target: preserve **serial OasisKV's exact sparse-state transition** while allowing its already-computed lookahead state to be committed.

That is not P&F's stated contract. P&F first builds a union support for the speculative block and then computes the target verification/state under that support. It deliberately accepts a sparse approximation; it does not promise to reproduce the succession of per-step resident sets a different serial sparse policy would use.

Accordingly:

- The earlier tensor witness can disprove a naïve serial-OasisKV-preserving acceptance patch
- It does **not** expose a demonstrated P&F bug
- The paper does not establish all implementation-level accepted-KV write/copy details, because no code was verified
- This remaining artifact uncertainty must not be converted into a novelty claim

The strongest controls remain block-frozen sparse verification, accepted-state replay, ready token-specific supports, and dense exact verification. These ordinary alternatives must be tested under their own declared targets.

## 4. A concrete accounting caveat, not a new topic

P&F Eq1 forms a union. With gamma per-token top-k sets, its actual historical cardinality u satisfies

k <= u <= min(gamma*k, history_length)

when each set has k distinct entries. The default gamma8,k256 can therefore describe between256 and2048 historical entries before separately retained recent/generated state. This is a mathematical bound, not a measured occupancy.

Section2.6 writes verification complexity using k as the sparse-context size, while §3.4 describes k per draft step. The explicit union rule requires charging **u**, or documenting an additional truncation/high-overlap assumption. The paper does not give a clear union re-truncation rule in the inspected methods.

This warrants a reproduction question, not an allegation of an implementation error or inflated measured performance. Implementations may provision sufficient buffers or observe heavy overlap. No trace or code was available to decide that.

Likewise, the last newly selected entries of a draft block have less remaining drafting time to hide their fetch. Whether the final tail is hidden depends on actual readiness, transfer volume, and other overlappable work. A generic asynchronous-stream claim is insufficient to derive zero exposed delay for every workload.

## 5. Cost inequality retained, with correct scope

The accompanying COST_INEQUALITY.md defines

D + V + R + X + C < T_seq(N),

where R reproduces accepted state for the explicitly chosen target and X is only unhidden transfer delay. In the one-draft-token special case, full serial-cost accepted-state replay cancels the acceptance benefit under the stated assumptions.

P&F can avoid that R because it chooses an approximate block verification target. Its comparison must instead charge actual union cardinality, probe training/serving state, and quality differences. The inequality is useful experimental accounting, not a new algorithm.

No synthetic timings, model tests, GPU run or paper-specific performance reproduction were performed.

## 6. Directly related author-stated limitations

P&F's own introductory Challenge3 and §2.5 acknowledge that sparse verification sacrifices strict equivalence. Its experiments do not settle general sampling fidelity or long-output reasoning. This is a real limit, but **“make sparse verification exact” is not yet a concrete economical mechanism** and should not be offered as a new topic on its own.

OasisKV additionally says its prototype lacks prefix caching (§5.5.2); its associated TTFT advantage is analytic. That is an implementation boundary and does not reopen the closed generic prefix-sharing lane.

The separate accessible **Dustin** paper, AppendixL, explicitly distinguishes sparse verification's bandwidth savings from physical GPU-capacity savings: full history remains indexed/resident. This is a more concrete adjacent source for a bounded residency/dataflow question. Generic offloading is already covered by P&F and OasisKV, so any next proposal must identify an actual representation or information-flow difference. No Dustin-based candidate is promoted by this report.

## Terminal disposition

**CLOSED_BROAD_JOINT_PATH_ALREADY_PRESENT.**

Resolved: P&F has accepted speculation, CPU→GPU fetching during drafting, sparse block verification and an explicitly approximate quality contract.

Not resolved or claimed: implementation-level cache/state correctness, actual union-size distributions, hidden-transfer tails, 5090 compatibility, or superiority of a new mechanism. Absence of an author artifact is a reproducibility limitation, not evidence of an unoccupied problem.

Existing phase-falsifier artifacts remain unchanged. This comparison used the user-provided primary PDF and source reading only.


## Bounded follow-on screen

The subsequent union-budget/horizon screen is complete in ../prefetch_union_horizon_screen_20261005/REPORT.md. It identifies the horizon-dependent sparse-target complication, resource-aware speculative controls, and Dustin’s key-only scoring-plane source question. No further candidate is admitted from that screen; cross-domain transfer remains permitted if it supplies a distinct useful mechanism.
