# Necessary economics of accepted-state replay

This is a symbolic derivation, not a timing experiment. No parameter below has been measured for P&F or an accepted-speculation OasisKV implementation.

## General cycle

Fix the target transition semantics, including its sparse selector, capped-admission state, auxiliary draft state/randomness, and accepted cache state. Let:

- N be the number of tokens emitted by one speculative cycle, under a consistent counting convention
- T_seq(N) be the elapsed time for that exact target to emit the corresponding N tokens by serial execution
- D be drafting/probing time not already counted in V
- V be the initial verification/lookahead work
- R be work required to make committed accepted-token state equal to the target; include selector/draft replay if target-state reproduction needs it
- X be the portion of fetch/readiness delay not hidden behind D, V or R
- C be additional controller/synchronization overhead not included elsewhere

No overlapping stage may be counted twice. For a fixed trace, a throughput benefit requires

D + V + R + X + C < T_seq(N).

Under a stationary comparison with the same reward convention, a necessary expected-cycle condition is

E[R + X + C] < E[T_seq(N) - D - V].

The right side is the available repair/transfer headroom. This does not predict a speedup without actual compatible timings and acceptance/support traces. A ratio of expected work is not automatically the mean per-request latency; queueing/SLO claims need their own model.

## One-draft-token special case

Let the draft be accepted with probability a. Standard one-token speculation emits one correction/bonus token plus the accepted draft when accepted, giving expected N=1+a. Suppose one serial target step costs T, and conditional accepted-state replay also costs T. Then

T_spec = D + V + aT + X + C
T_serial = (1+a)T

so a benefit requires D + V + X + C < T.

If V >= T and the other terms are nonnegative, there is no benefit. Increasing acceptance alone does not help: the saved serial work is spent reproducing the accepted state.

This conclusion is conditional. It does not apply when replay is cheaper, fetch stalls were removed, verifier batching changes the real cost, some intermediate state is reusable, or the target was changed to a block-frozen sparse policy. Those changes must be stated and paid for.

## Multi-token replay is not necessarily serial replay

For a block with A accepted drafts, R(A) need not equal A*T. Ordinary batched replay may read weights once and exploit compute utilization. The correct baseline therefore includes **batched accepted-state replay**, with required token-specific supports and selector state reproduced. Claiming a new repair advantage against only A separate forwards would be weak.

Likewise, a union of historical supports may be fetched once and read with distinct per-token masks. That is an existing straightforward control. Its extra residency, gather/index work and causal masking must be counted. Reading the union without those masks defines a different sparse target.

## Necessary transfer bound

For a particular layer, let M_l be the number of distinct nonresident block-head records required before a verifier/replay use, B_l their total bytes, and beta the effective link bandwidth. If the relevant transfer stream has W_l seconds of useful lead time, unhidden delay cannot be less than

max(0, B_l/beta - W_l),

ignoring additional request/launch latency. Shared links couple layers and requests, so independently summing these lower bounds can overcount; max/critical-path analysis or a correctly shared-resource schedule is needed. Memory traffic should use the deduplicated union of fetched records, while attention reads remain token-support-specific.

If a serial policy permits at most C block replacements per logical step and speculation advances N logical steps at once, performing only one C-sized update generally changes the policy. Performing all intended updates can require a larger cumulative transfer set or transient resident union. A meaningful design must identify reuse/structure that reduces this burden without borrowing future support or ignoring repaired-state work.

## What this does and does not establish

The one-token case rules out a naïve performance argument under explicit assumptions. The general condition identifies which quantities a real implementation must improve. Neither proves that P&F misses the problem, that OasisKV can be accelerated by a new method, or that support-equivalent acceptance is novel.

The full P&F method must determine whether it already uses consistent target supports, block-frozen verification, a separate dense verifier, replay, or an equivalent joint schedule. Until that source comparison is complete, this is an analysis obligation only.

