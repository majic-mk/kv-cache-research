# Fused/streaming kernel controls for YAKV scratch removal
Date: 2026-10-05. Static, bounded source inspection only. No package installation, compilation, GPU call, inference, or benchmark was run.

## Decision in brief

**Full-length K/V reconstruction and score matrices are not necessary for attention or exact top-k, and concrete implementations already remove them.** The strongest controls are FlashInfer's fused exact DSA indexer, FlashInfer's direct NVFP4 sparse MLA decode, QuaRot's int4 paged attention, and vLLM's TurboQuant codebook-key attention.

**No inspected implementation is a drop-in consumer of YAKV's exact EDEN2-256 HIGGS K/V cache with its selected per-head blocks and CPU-origin transport.** A specific implementation residual survives: directly consume these vector-codebook rows, score in Hadamard coordinates, accumulate V in those coordinates, merge online attention states, and inverse-transform only O. The algebra and overall streaming consumer are existing techniques. Novelty cannot be “rotate Q once,” “use online softmax,” “fuse dequantization,” or “delete an O(ND) temporary” in isolation.

The essential comparison is **same-format, BF16-preserving tiled HIGGS dequantization inside attention versus transformed-domain HIGGS attention**, with the exact same selected rows and CPU-transfer policy. That comparison isolates whether avoiding per-row inverse transforms adds anything beyond existing gather/dequant/attention fusion.

## Source pins and validation

- YAKV author implementation: `yandex-research/context-intensive-kv-offloading@7dae3165a1bb747d3707c30db996af6a1277cf23`
- FlashInfer current source: `flashinfer-ai/flashinfer@745b12352d4419799ff20fb4f6743382dc374b67`
- QuaRot author implementation: `spcl/QuaRot@5008669b08c1f11f9b64d52d16fddd47ca754c5a`
- QJL author implementation: `amirzandieh/QJL@648b3641f96b6e95e091217220b94e4739fd4d82`
- vLLM TurboQuant: `vllm-project/vllm@d61081dc3d3f1740a5d8bf82608b62974393c2de`

35 source files, approximately 0.8 MB, are recorded in `source_manifest.json` with URL, pin, SHA-256 and line count. vLLM files were reused from the existing pinned source tree; the two principal TurboQuant decoder files were additionally compared to commit-pinned GitHub text and matched. Python AST inspection, without importing FlashInfer, confirms the DSA generated-program registry is populated for SM100a/103a/107a.

**Documentation trap:** the DSA README's “placeholder registry” status paragraph is stale at this pin. `cake_jit.py:46–144` actually registers SM100a scan/finalize programs, followed by SM103a/107a registrations, and corresponding generated CUDA files exist. Also, the API and README disagree about the ordering of non-finite scores. Restrict exactness claims here to finite inputs.

## 1. YAKV already scores packed landmarks in transformed coordinates

[YAKV higgs_score.cu, lines 20–53](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/higgs/csrc/higgs_score.cu#L20-L53) explicitly moves the Hadamard transform from every landmark to the small query tensor. The transformed query remains FP32. The main kernel directly reads code bytes, performs BF16 lattice lookups, computes dot products and per-head scale multiplication, and takes a max over query heads in each GQA group; the final scores are rounded to BF16 and written to the full landmark-score array. See [lines 194–257](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/higgs/csrc/higgs_score.cu#L194-L257).

This is **2-bit vector quantization**: EDEN4-256, one byte per four dimensions. It is not four independent scalar 2-bit values. Full K/V uses **4-bit vector quantization**: EDEN2-256, one byte per two dimensions, plus FP32 per-head scales. [Format definitions, higgs.py:21–62](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/quantization/higgs.py#L21-L62).

What remains unfused is selection and attention consumption:
- The scorer writes `[max_B,Hkv,max_N/chunk_size]` BF16 scores
- `shadowkv_topk_kernel` then reads these scores; its radix branch makes three passes (high-byte histogram, threshold-bucket histogram, compaction)
- The API still requires a full-length int64 output allocation although only k indices are stored
- K/V gather, scale gather and two full-head dequant launches precede attention

[Top-k implementation: lines 89–170 and 173–194](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/shadowkv/shadowkv_topk.py#L89-L194). The radix branch favors smaller indices at equal-score cutoffs; the short-row sort packs the index into a descending key and favors larger indices. Any bit-for-bit selection contract must preserve the actual branch, not assume a single universal tie rule.

## 2. FlashInfer fused scoring + exact top-k: real, but a different score function

[Public dsa_indexer_topk](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/dsa_indexer.py#L29-L118) computes weighted ReLU sums across 32 query heads, with BF16 keys of dimension 128 and FP32 score arithmetic. It selects exact global top-k for those computed scores, without storing a query-by-key score matrix.

The implementation uses a persistent scan and ascending-index finalize kernel. The exact candidate gate can rescan when its sampled threshold is too aggressive; it is not an approximate fixed candidate-margin algorithm. [Scoring/reduction and gate contract](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/cake_dsa_indexer/README.md#L46-L116).

Workspace:
`SM_count × 4 queries/CTA × round128(max(4k,k+128)) × 8 bytes`.
At 148 SMs and k=2048 this is exactly 38,797,312 bytes, 37 MiB. Outputs add 8×T×k bytes (int32 ids and FP32 scores). The scratch is independent of sequence length for fixed k; if k grows proportionally with context, its bound grows with k. [Host formula](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/cake_dsa_indexer/cake_backend.py#L226-L269), [populated registry](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/cake_dsa_indexer/cake_jit.py#L46-L144).

Not a drop-in: SM100/103/107 only, fixed 32×128 geometry, BF16 dense keys rather than EDEN lookup codes, weighted-ReLU sum rather than YAKV max-over-GQA, FP32 rather than BF16-rounded ranking, fixed scalar k rather than per-slot k, and different tie/output ordering. It is a strong algorithmic/kernel baseline for exact bounded-candidate scoring, not evidence that YAKV can simply call it.

FlashInfer's separate [top_k_page_table_transform](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/topk.py#L1076-L1189) fuses selection with physical-index translation, but still requires an already materialized `[num_rows,max_len]` score tensor. It alone does not solve score scratch.

## 3. FlashInfer direct quantized sparse attention already eliminates selected-row staging

[Experimental nvfp4_sparse_mla_decode](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/nvfp4_sparse_mla_decode/README.md#L5-L90) reads selected 352-byte NVFP4 cache rows directly. It loads a small ring of 32-row stages, expands the FP4×FP8 representation into exact FP16 tile values in shared memory, computes QK and online softmax, accumulates PV, and merges cluster partials through distributed shared memory. The CUDA backend has no global workspace; its Python wrapper only allocates output when absent.

Actual [kernel load/dequant and QK loops](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/nvfp4_sparse_mla_decode/csrc/nvfp4_sparse_mla_decode.cuh#L200-L310), [PV and cluster merge](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/nvfp4_sparse_mla_decode/csrc/nvfp4_sparse_mla_decode.cuh#L363-L442).

Limits matter: GPU-resident cache, 16 query heads, 576 key dimensions/512 value dimensions, FP8 Q, BF16 O, particular top-k staging constraints, SM100/103. This does not support HIGGS codebooks or prove a CPU-mapped cache can be substituted without transport cost.

Author-reported cost, not measured here: 218,624 bytes shared memory per CUDA CTA, one CTA/SM; the kernel was shared-memory-bound in one GB200 profile. Its README measures approximately 5.3 µs/layer for an avoided selected-row FP8 gather, but direct decode wins over FP8 TRTLLM-gen only in a batch band and loses outside it. Exact decoding of an NVFP4 row is not exact attention arithmetic: author validation reports about 0.3% relative error versus FP32, and the CUDA cluster path casts partial O to FP16. [Cost/validation](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/nvfp4_sparse_mla_decode/README.md#L77-L138).

## 4. QuaRot is an older transformed-value and int4 streaming control

The actual [QuaRot int4 launcher](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/kernels/flashinfer.cu#L9-L45) instantiates its FlashInfer-derived paged decoder. The kernel loads quantized pages into a four-stage shared ring, converts values into registers, updates online attention states, normalizes, and writes O. It does not materialize full reconstructed K/V or scores. [Paged tile/state loop](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/kernels/include/flashinfer/decode.cuh#L503-L688), [online state equations](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/kernels/include/flashinfer/state.cuh#L35-L94).

Decode [rotates Q once](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/transformers/kv_cache.py#L111-L127). Keys are rotated before packing. Values are already in a transformed basis because [rotate_ov_proj](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/e2e/checkpoint_utils/rotation_utils.py#L96-L101) transforms v_proj weights and folds a compensating transform into o_proj. A remaining across-head transform is [applied to the attention output](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/e2e/quantized_llama/modeling_llama.py#L80-L103).

Thus transformed-basis V accumulation followed by output/projection compensation is existing code, although this is not precisely YAKV's “apply H/d to final O” epilogue. QuaRot uses affine int4 quantization, modified projection weights, and a D=128 same-head-count decoder; it neither consumes EDEN2 indices nor implements YAKV per-head selected CPU blocks. Do not dismiss those mapping differences.

## 5. vLLM TurboQuant is the closest current codebook-key/GQA consumer

The existing pinned vLLM tree contains [TurboQuant split decoder](https://github.com/vllm-project/vllm/blob/d61081dc3d3f1740a5d8bf82608b62974393c2de/vllm/v1/attention/ops/turboquant_soa/triton_turboquant_decode.py):
- Q rotation outside the KV loop, lines 529–538
- packed centroid-key lookup and per-token norm, lines 220–254
- online softmax, packed affine-V reconstruction and weighted accumulation, lines 257–306
- only `[B,Hq,S,D+1]` FP32 split-state scratch plus output/LSE; default S=32, lines 485–643

A [unified variant](https://github.com/vllm-project/vllm/blob/d61081dc3d3f1740a5d8bf82608b62974393c2de/vllm/v1/attention/ops/turboquant_soa/triton_turboquant_unified_attention.py#L74-L113) fuses Q rotation into each attention program's prologue, with tensor-core QK/PV and GQA packing. It casts rotated Q to the original Q dtype and explicitly acknowledges changed rounding order. These are GPU/accelerator resident paged consumers; neither one provides YAKV CPU offload or landmark top-k.

The crucial non-equivalence: TurboQuant's V is affine scalar-quantized in the original value basis. [Store signatures identify raw V](https://github.com/vllm-project/vllm/blob/d61081dc3d3f1740a5d8bf82608b62974393c2de/vllm/v1/attention/ops/turboquant_soa/triton_turboquant_store.py#L218-L269), and the decoder directly accumulates `index × scale + zero`. No EDEN2 vector-codebook V or output-only inverse Hadamard is present in these inspected paths.

The original [HIGGS paper](https://arxiv.org/html/2411.17525v1#S4) already discusses using transformed-space lookup-table matrix multiplication, including vectorized p=2 FLUTE support. That supports the algebra/lookup primitive, not a claim that its weight-matmul kernels implement a fused selective KV attention consumer. The Google TurboQuant blog links papers, not a verified author implementation of this exact path; no community repository is treated as author code here.

## 6. QJL does not remove the full score/softmax array

Author QJL already computes queries against packed sketches, but [qjl_gqa_score_kernel.cu:207](https://github.com/amirzandieh/QJL/blob/648b3641f96b6e95e091217220b94e4739fd4d82/qjl_kernel/csrc/qjl_gqa_score_kernel.cu#L186-L230) allocates a full FP32 score tensor. [llama3_qjl.py:186–222](https://github.com/amirzandieh/QJL/blob/648b3641f96b6e95e091217220b94e4739fd4d82/models/llama3_qjl.py#L186-L222) materializes softmax weights and separately calls quantized PV. It is a packed-scoring primitive control, not an end-to-end no-score-scratch control.

## 7. Precise surviving HIGGS numerical/dataflow experiment

Let H be the symmetric, unnormalized D-dimensional Hadamard matrix (H²=D I), cK/cV be concatenated BF16 lattice points selected by EDEN2 codes, and sK/sV the stored per-head row scales.

The author's [dequantization kernel](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/higgs/csrc/higgs_dequantize_heads.cu#L108-L134) actually computes:
- Kbar_j = round_BF16((sK_j/D) H cK_j)
- Vbar_j = round_BF16((sV_j/D) H cV_j)
- then ordinary attention consumes Kbar, Vbar

A transformed-domain consumer instead naturally computes the following **unrounded reconstructed-vector contract**:
- q' = Hq/D
- logits_j = sK_j · dot(q',cK_j) × attention_scale
- p = softmax(logits over exactly the same selected rows)
- u = sum_j p_j sV_j cV_j
- O = H u/D

In real arithmetic that is identical to attention on unrounded reconstructed quantized K/V. In finite arithmetic it has its own transform, dot, softmax and accumulation rounding. It is **not** bitwise identical to current YAKV: componentwise BF16 rounding before QK and PV cannot commute through the transform or weighted sum. Nor does existing landmark max/GQA ranking become the full-attention formula; preserve the selection path when isolating the consumer.

Two valid contracts must not be conflated:
1. **BF16-staged-reference preservation:** decode each tile with the author's exact BF16 conversion, then consume the tile; global dense scratch can still disappear, but per-row inverse H remains. Same mathematical BF16 inputs do not alone guarantee bitwise equality to FlashAttention's reduction order.
2. **Transformed reconstruction:** eliminate per-row inverse H and rowwise BF16 rounding; compare to a high-precision oracle for the formula above, report output/logit differences against current YAKV, and verify downstream impact separately.

Remaining engineering differences are substantive but specific: two-coordinate vector LUT access/bank behavior; GQA reuse without duplicating decode; per-row FP32 scales; selected head-specific row addresses and valid lengths; handling prefix/suffix blocks consistently; output-only H after merging split states; and overlap/transport from the CPU origin. None of the inspected controls combines all of these.

## 8. Cost target and stopping condition

For quantized full K/V, B slots, maximum length N, Hkv heads, D dimensions, YAKV allocates:
- gathered codes: B·N·Hkv·D bytes (K+V, 4-bit)
- gathered scales: 8·B·N·Hkv bytes
- reconstructed BF16 K/V: 4·B·N·Hkv·D bytes

[Allocations and producer/consumer calls](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L185-L225), [gather/dequant dispatch](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L574-L618).

Example B=1,N=131072,Hkv=8,D=128: 512 MiB BF16 reconstruction + 128 MiB codes + 8 MiB scales. These are maximum-capacity allocations; runtime work follows selected lengths. If Z rows/head are selected, removing one BF16 write and one BF16 attention read ideally removes 8·B·Z·Hkv·D bytes of global traffic. This is a lower-level traffic model, not a measured end-to-end saving; reads/reuse depend on the actual attention schedule. CPU-to-GPU bytes still have to move.

The transformed-value proposal additionally changes inverse-transform work from per selected K and V head (O(B·Z·Hkv·D log D)) to query/output transforms (O(B·Hq·D log D)), with codebook lookup, QK, softmax and PV still required. A same-contract tiled consumer gives the scratch-removal control; its cost difference is the correct place to test the extra transform claim.

**Stopping rule for this screen:** retain only a format-/transport-specific implementation experiment, not an admitted algorithmic novelty. No further generic rotation/top-k/attention survey is warranted. A later authorized measurement should compare (A) author path, (B) same-format BF16-preserving fused consumer, and (C) transformed-domain consumer with frozen selections, then report peak allocated/reserved bytes, HBM/host traffic, LUT/transform/attention time, numerical drift, and end-to-end latency. If C cannot beat B in the intended regime or violates the declared accuracy budget, the additional transformed-domain proposal has no demonstrated benefit.

