"""Recover diagnostic-control arrays deterministically from frozen primary arrays.
Does not alter either original protocol, script, results or arrays archive.
"""
import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
import json
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
records=[]
for suffix,g in (("",3),("_native_geometry",8)):
    d=p/("tensor_results"+suffix)
    a=np.load(d/"arrays.npz")
    res=json.loads((d/"result.json").read_text())
    def attn(q,k,v):
        l=np.einsum("bqd,bqnd->bqn",q,np.repeat(k,g,axis=1))/np.sqrt(128.)
        ex=np.exp(l-l.max(axis=-1,keepdims=True));pr=ex/ex.sum(axis=-1,keepdims=True)
        o=np.einsum("bqn,bqnd->bqd",pr,np.repeat(v,g,axis=1))
        return l,pr,o
    q=a["q"].astype(np.float64)
    ik=a["codebook_k"]*a["scales_k"][...,None]
    iv=a["codebook_v"]*a["scales_v"][...,None]
    li,pi,oi=attn(q,ik,iv)
    li2,pi2,oi2=attn(q@np.eye(128),ik,iv)
    lw,pw,ow=attn(q,a["keys_unrounded"][:,::-1],a["values_unrounded"][:,::-1])
    neg=float(np.abs(a["logits_reference"]-lw).max())
    assert neg==res["controls"]["wrong_group_negative_max_abs"]
    assert np.max(np.abs(oi-oi2))==res["controls"]["identity"]["max_abs"]
    np.savez(d/"diagnostic_control_arrays.npz",identity_logits=li,identity_prob=pi,identity_out=oi,identity_matrix_logits=li2,identity_matrix_prob=pi2,identity_matrix_out=oi2,wrong_group_logits=lw,wrong_group_prob=pw,wrong_group_out=ow)
    records.append(dict(case=suffix or "initial",controls_match_frozen_results=True))
(p/"diagnostic_recovery.json").write_text(json.dumps(records,indent=2)+"\n")
print(json.dumps(records))
