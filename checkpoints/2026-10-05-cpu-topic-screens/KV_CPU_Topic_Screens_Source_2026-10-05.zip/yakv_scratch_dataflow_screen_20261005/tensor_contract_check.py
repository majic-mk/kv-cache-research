import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
os.environ["OMP_NUM_THREADS"]="1"
import resource, time, json, hashlib, zipfile
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import numpy as np
base=Path(__file__).resolve().parent
start=time.process_time()
proto=json.loads((base/"tensor_protocol.json").read_text())
p=base/"sources/EDEN2-256.pt"
raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()==proto["actual_grid"]["sha256"]
assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==proto["actual_grid"]["git_blob"]
with zipfile.ZipFile(p) as z:
    assert z.read("EDEN2-256/byteorder")==b"little"
    data=z.read("EDEN2-256/data/0")
assert len(data)==512*4
grid=np.frombuffer(data,dtype="<f4").copy().reshape(256,2)
def bf16(x):
    x=np.array(x,dtype=np.float32,copy=True,order="C")
    u=x.view(np.uint32)
    u=(u + np.uint32(0x7fff) + ((u>>16)&1)) & np.uint32(0xffff0000)
    return u.view(np.float32)
def fwht(x):
    r=x.copy(); n=r.shape[-1]; h=1
    while h<n:
        v=r.reshape(*r.shape[:-1],-1,2*h)
        a=v[...,:h].copy(); b=v[...,h:].copy()
        v[...,:h]=a+b; v[...,h:]=a-b; h*=2
    return r
def attn(q,k,v):
    logits=np.einsum("bqd,bqnd->bqn",q,np.repeat(k,3,axis=1))/np.sqrt(128.)
    ex=np.exp(logits-logits.max(axis=-1,keepdims=True))
    prob=ex/ex.sum(axis=-1,keepdims=True)
    out=np.einsum("bqn,bqnd->bqd",prob,np.repeat(v,3,axis=1))
    return logits,prob,out
def metrics(a,b):
    e=np.abs(a-b)
    return {"max_abs":float(e.max()),"rmse":float(np.sqrt(np.mean(e*e))),
            "scaled_max":float(e.max()/max(1.,float(np.abs(a).max())))}
rng=np.random.default_rng(proto["seed"])
B,H,N,D,G=2,2,17,128,3
grid16=bf16(grid)
codes_k=rng.integers(0,256,size=(B,H,N,D//2),dtype=np.uint8)
codes_v=rng.integers(0,256,size=(B,H,N,D//2),dtype=np.uint8)
q=bf16(rng.standard_normal((B,H*G,D)))
sk=np.exp(rng.uniform(np.log(.25),np.log(64.),size=(B,H,N))).astype(np.float32)
sv=np.exp(rng.uniform(np.log(.25),np.log(64.),size=(B,H,N))).astype(np.float32)
ck=grid16[codes_k].reshape(B,H,N,D).astype(np.float64)
cv=grid16[codes_v].reshape(B,H,N,D).astype(np.float64)
ku=fwht(ck)*sk.astype(np.float64)[...,None]/D
vu=fwht(cv)*sv.astype(np.float64)[...,None]/D
la,pa,oa=attn(q.astype(np.float64),ku,vu)
qt=fwht(q.astype(np.float64))/D
lb,pb,ub=attn(qt,ck*sk[...,None],cv*sv[...,None])
ob=fwht(ub)/D
# Existing staged format: FP32 inverse Hadamard and scale, per-row BF16 cast.
kr=bf16(fwht(ck.astype(np.float32))*(sk/np.float32(D))[...,None])
vr=bf16(fwht(cv.astype(np.float32))*(sv/np.float32(D))[...,None])
lr,pr,orr=attn(q.astype(np.float64),kr.astype(np.float64),vr.astype(np.float64))
# Source-style FP32 reconstruction before BF16 also preserved separately.
k32=fwht(ck.astype(np.float32))*(sk/np.float32(D))[...,None]
v32=fwht(cv.astype(np.float32))*(sv/np.float32(D))[...,None]
mat=np.array([[1.]],dtype=np.float64)
while len(mat)<D: mat=np.block([[mat,mat],[mat,-mat]])
fwerr=metrics(q.astype(np.float64)@mat,fwht(q.astype(np.float64)))
li,pi,oi=attn(q.astype(np.float64),ck*sk[...,None],cv*sv[...,None])
li2,pi2,oi2=attn(q.astype(np.float64)@np.eye(D),ck*sk[...,None],cv*sv[...,None])
lw,_,_=attn(q.astype(np.float64),ku[:,::-1],vu[:,::-1])
primary={"logits":metrics(la,lb),"probabilities":metrics(pa,pb),"output":metrics(oa,ob)}
secondary={"logits":metrics(lr,lb),"probabilities":metrics(pr,pb),"output":metrics(orr,ob),
           "keys_bf16_vs_unrounded":metrics(ku,kr),"values_bf16_vs_unrounded":metrics(vu,vr)}
controls={"fwht_vs_matrix":fwerr,"identity":metrics(oi,oi2),
          "wrong_group_negative_max_abs":float(np.max(np.abs(la-lw)))}
passed=all(v["scaled_max"]<=1e-12 for v in primary.values()) and fwerr["scaled_max"]<=1e-12 and controls["identity"]["max_abs"]==0 and controls["wrong_group_negative_max_abs"]>1e-6
outdir=base/"tensor_results"; outdir.mkdir(exist_ok=True)
np.savez(outdir/"arrays.npz",grid_fp32=grid,grid_bf16=grid16,codes_k=codes_k,codes_v=codes_v,q=q,scales_k=sk,scales_v=sv,codebook_k=ck,codebook_v=cv,keys_unrounded=ku,values_unrounded=vu,keys_fp32=k32,values_fp32=v32,keys_bf16=kr,values_bf16=vr,q_transformed=qt,logits_reference=la,prob_reference=pa,out_reference=oa,logits_transformed=lb,prob_transformed=pb,transformed_accumulator=ub,out_transformed=ob,logits_bf16_staged=lr,prob_bf16_staged=pr,out_bf16_staged=orr,hadamard_matrix=mat)
res={"status":"ALGEBRA_PASS_BF16_STAGED_NON_EQUIVALENCE" if passed else "CONTROL_OR_ALGEBRA_FAIL","protocol_sha256":hashlib.sha256((base/"tensor_protocol.json").read_bytes()).hexdigest(),"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"primary":primary,"secondary":secondary,"controls":controls,"seconds_cpu":time.process_time()-start,"peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,"native_kernel_validation":False,"model_quality_claim":False,"actual_author_grid":True}
(outdir/"result.json").write_text(json.dumps(res,indent=2)+"\n")
print(json.dumps(res,indent=2))
if not passed: raise SystemExit(2)
