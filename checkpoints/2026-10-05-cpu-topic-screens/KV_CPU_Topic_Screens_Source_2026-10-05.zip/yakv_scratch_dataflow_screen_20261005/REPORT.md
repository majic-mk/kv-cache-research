# YAKV real-offload scratch and transformed-codebook attention

2026-10-05 UTC. **There is a concrete HIGGS-format integration hypothesis worth preserving, but no demonstrated speedup or new general attention principle.** Existing kernels already solve generic sparse gather/dequant/attention fusion and transformed-value accumulation. The remaining combination is YAKV's selected CPU-origin EDEN codebook K/V, row scales and GQA, consumed directly in transformed coordinates.

A frozen CPU-only test with the actual author codebook validates the real-arithmetic transformation. It also shows that this changes the current per-row BF16 rounding contract. This distinction must survive any later implementation or quality claim.

## 1. Real implementation and lifecycle

Pinned author source: [context-intensive-kv-offloading commit7dae316](https://github.com/yandex-research/context-intensive-kv-offloading/tree/7dae3165a1bb747d3707c30db996af6a1277cf23/inference).

This report uses the real minisgl inference path, not the accuracy-only simulation:

- [engine.py lines61–69](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/engine/engine.py#L61-L69) creates one ShadowKVPool with max_running_req+1 slots
- [shadowkv.py lines180–258](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L180-L258) places full code storage in mapped CPU memory under offloading, but keeps full-history FP32 code scales on GPU
- [lines204–225 and285–295](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L204-L295) reserve gathered codes/scales and BF16 dequantized KV at maximum sequence capacity
- [select_kv lines574–620](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L574-L620) gathers chosen rows, gathers scales, dequantizes K/V separately, then returns BF16 buffers
- [fa.py lines59–95](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/fa.py#L59-L95) feeds those buffers to FlashAttention; prefill uses the current full K/V inputs directly

The scratch is persistent and reused across layers. It is not a full-history BF16 allocation for every layer. CUDA gather and dequantization iterate over active selected lengths; they do not automatically read or decode all reserved slots. Reserving Nmax bytes and transferring Nmax bytes are different claims.

### Generated-token growth prevents a naïve fixed sparse cap

The [metadata kernel](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/shadowkv/csrc/metadata_kernels.cu) fixes the prompt's infix and pruned-infix lengths. Decode uses:

R_current = N_current - I_prompt + I_selected.

New generated tokens therefore remain in the working set. A short unpruned prompt followed by long generation can need almost Nmax entries. Allocating only sparse_fraction*Nmax without a prompt/output-length contract would be unsafe. Pooling by live required capacity is ordinary allocator work, not the proposed research contribution.

## 2. Concrete storage and movement

For B allocated slots, maximum length N, H local KV heads, D128, FP32 row scales and HIGGS4-bit codes:

- gathered codes: B*N*H*D bytes for K and V together
- BF16 reconstructed KV: 4*B*N*H*D bytes
- gathered scales: 8*B*N*H bytes
- full-history GPU scales across L layers: 8*L*B*N*H bytes

The [author example](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/README.md) requests16 running sequences and131072 maximum length. The engine adds a slot, so B=17. The [Qwen3-30B-A3B-Instruct-2507 config](https://huggingface.co/Qwen/Qwen3-30B-A3B-Instruct-2507/raw/main/config.json) gives H=4,D=128,L=48 at TP1.

Those source shapes imply, before allocator overhead:

| Allocation | GiB |
|---|---:|
| gathered4-bit K/V | 1.0625 |
| BF16 reconstructed K/V | 4.25 |
| gathered scales | 0.06640625 |
| three KV staging arrays together | 5.37890625 |
| full-history GPU scales | 3.1875 |
| chunk2 packed2-bit landmarks plus scales | 7.171875 |

These arrays coexist, but the values are analytical payload totals, not measured peaks or evidence that the README model/configuration fits a5090. Weights and other workspaces are additional. The source model is not the user's existing4B model.

For an active selected set with total rows R across requests, BF16 dequantization writes4*R*H*D bytes and attention must consume those values. A fused tile consumer can avoid that global intermediate and its write/read round trip, at least8*R*H*D logical HBM bytes. Actual cache transactions, re-reads, GQA reuse and kernel scheduling may differ.

The same set still requires its selected code traffic from CPU. Fusion does not make PCIe bytes disappear. Moving currently GPU-resident scales alongside CPU codes could reduce persistent scale storage but adds scale traffic and changes layout; this is a conventional packed-record control, not an additional invention.

## 3. What is already fused

Detailed code pins and comparisons are in kernel_controls/REPORT.md.

- YAKV's [higgs_score.cu lines20–53,213–230](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/higgs/csrc/higgs_score.cu#L20-L53) already transforms Q once and directly scores packed2-bit landmarks against codebook vectors. Avoiding one inverse transform per landmark is already implemented
- FlashInfer's fused DSA indexer avoids a full score matrix while performing exact top-k for its own scoring rule; its fixed geometry/hardware/scoring semantics differ
- FlashInfer's sparse NVFP4 MLA decoder directly indexes low-bit rows, decodes tiles in shared memory and performs online softmax/PV without a global BF16 selected-KV buffer. It is not a HIGGS/GQA drop-in
- QuaRot author code already uses transformed K/V attention, query rotation and output/projection-side inverse transforms with streaming int4 attention
- A current vLLM TurboQuant GQA decoder already rotates Q, loads packed centroid K, performs online softmax/PV and uses bounded split-output scratch. Its V format is ordinary scalar quantization in the original coordinates
- HIGGS/FLUTE already provides transformed-space vector-codebook linear multiplication

Thus “fuse scoring,” “avoid dense dequantized KV,” or “move a common linear transform past value aggregation” is not a new algorithm. Their existence also does not prove a HIGGS selective-offload specialization fast.

## 4. Precise residual implementation hypothesis

**Keep YAKV's existing selection and CPU-origin4-bit EDEN code storage. Replace its selected-row inverse-Hadamard/BF16 materialization plus attention with a consumer that operates on codebook coordinates and row scales, then inverse-transforms only the attention output.**

This requires concrete kernel/dataflow work:

1. Reuse or retain the already-computed transformed query from landmark scoring; the published scorer currently treats it as a temporary
2. Gather selected packed rows and scales into a compact transport buffer, or safely consume mapped CPU rows if that wins. Direct remote loads are not assumed faster
3. Reuse each KV-group codebook load across its GQA query heads, keeping a separate softmax and value accumulator for each query head
4. Decode EDEN2-256 pairs in registers/shared memory and apply each row's K/V scale; do not replace vector codes with a scalar4-bit format
5. Perform online softmax and scale-aware PV in codebook coordinates, including the selected prefix/infix/suffix rows and original causal/index semantics
6. Merge any split-K softmax states in that coordinate system, then apply one inverse Hadamard per final query-head output

For R selected rows, the existing dequantizer performs2*H*R length-D inverse transforms. The candidate performs Hq output transforms; Q-side work can be shared with the existing scorer. This removes per-row inverse work in addition to removing a global BF16 buffer. Codebook lookup, scalar multiplications, QK/PV and selected CPU traffic remain.

This is a meaningful implementation hypothesis rather than a Python-temporary cleanup. No checked direct implementation combines all these exact codec/selection/offload/GQA details. That bounded finding is not a novelty guarantee; QuaRot and TurboQuant are mandatory architectural controls.

### The strongest same-format control

A fused tiled HIGGS decoder should preserve the existing per-row inverse transform and BF16 rounding, but immediately feed the resulting tile to attention without a global BF16 cache. This isolates the proposed output-only inverse transform from the generic staging elimination already established by FlashInfer.

Comparing only against YAKV's current global staging would over-credit the candidate.

## 5. Exactness contract

YAKV's source decoder looks up BF16 lattice values, applies an FP32 unnormalized H_D transform, multiplies by row scale/D and rounds each reconstructed component to BF16 before attention.

For codebook vectors cK,cV and row scales sK,sV, define unrounded reconstructions:

Khat = sK*H_D(cK)/D
Vhat = sV*H_D(cV)/D.

Then q' = H_D(q)/D gives identical real-arithmetic logits, and

u = sum_i p_i*sV_i*cV_i
O = H_D(u)/D

gives identical real-arithmetic attention output for those unrounded reconstructions.

It is not generally identical to applying attention to BF16(Khat),BF16(Vhat). Rounding is nonlinear and cannot be moved through softmax or PV by linearity. Standard finite-precision attention reductions also need their own tolerance contract.

Two legitimate targets therefore exist:

- Same staged-BF16 target: decode and BF16-round within the attention tile. This can eliminate global scratch but retains per-row transforms
- Unrounded codebook target: output-only inverse is mathematically valid, with numerical/quality validation against the staged target and original model still required

Do not label the second bit-exact YAKV, or claim that removing BF16 rounding can never worsen output quality.

## 6. Frozen CPU tensor check: executed within authorization

Protocol saved before execution, SHA256:
8be62ca55940d13beeb180d269b4e2e5adbd1625b24d80de628b964c9c60ffe2.

The actual EDEN2-256 codebook was fetched through the official pinned raw endpoint. Its3238 bytes match Git blob6e7d381d90243d18704db389744da3b061b08cd9. The ZIP storage and pickle disassembly were inspected; no pickle or author code was executed. Raw FP32 storage was read with NumPy and rounded to BF16 as the author loader does.

Frozen case: seed20261005; batch2;2 KV heads; GQA3;17 rows;D128; actual256×2 grid; artificial valid byte-code patterns and FP32 row scales. These are not model activations or an encoding-quality evaluation.

Results:

- FP64 transformed versus reconstructed logits: max absolute3.55e-15
- probabilities:3.33e-16
- output:7.11e-15
- explicit Hadamard/identity controls: zero difference
- wrong-group negative control: clearly detected
- against FP32-transform/per-row-BF16 reconstructed reference: max output difference0.0439968; scale-normalized maximum0.00225357

The last comparison falsifies a bitwise-equivalence claim on the frozen arrays. It does not measure quality degradation or predict model behavior. The CPU butterfly is not validation of native CUDA instruction ordering, and the attention reference is FP64 rather than FlashAttention.

The first case exercises mathematical GQA but6 query heads is outside the current landmark dispatcher. It was preserved unchanged. A separately frozen diagnostic uses the author example’s32 query heads/4 KV heads, seed unchanged, and the same gates. It also passes FP64 identity (7.11e-15 maximum output error); its BF16-staged output difference is0.0546492, scaled maximum0.00333936. This is a shape-coverage extension, not tuning of the original result.

The two runs used about0.032 CPU seconds combined, with maximum peakRSS27760KiB. All inputs, codebook values, intermediate reconstructions, logits, probabilities and outputs are preserved in tensor_results/arrays.npz. Neither run was tuned after observing its results; both protocols, scripts and complete arrays remain separate.

## 7. Admission and next necessary test

**Retain as a bounded codec-specific engineering hypothesis; do not promote it as a new attention principle or demonstrated research result.**

The source supports real avoidable staging and transform work. The tensor check supports the revised unrounded-codebook contract. It does not establish that a native implementation beats the strongest fused tiled control once register pressure, GQA reuse, codebook lookup, PCIe transport and split/merge costs are included.

The next necessary performance test, only after separate authorization and hardware availability, is a kernel-only comparison on one GPU:

- current YAKV staged4-bit path
- same-format fused tiled dequantization preserving BF16 rows
- transformed-codebook output-only inverse path
- appropriate available direct quantized-attention control

Freeze selected indices and codes, distinguish transport-inclusive and device-only timing, account complete persistent/peak allocations and require the declared numerical tolerance. Test unequal request lengths, active-slot holes, prefix/local boundaries, GQA and split-K. No model weights are needed for this first performance falsifier. End-to-end quality needs a later compatible model/checkpoint test.

Stop this branch if the output-only inverse has no material advantage over the same-format fused control, or if its numerical contract cannot be accepted. It would then be a format-port exercise, even if it improves an unoptimized baseline.

No GPU run, model inference, installation, spending or publication occurred. No latency was synthesized.
