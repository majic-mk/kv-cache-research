# Sparse-prefetch union budget and speculative horizon: bounded screen

2026-10-05 UTC. **No new topic is admitted from this screen.** P&F already implements accepted speculation with sparse prefetching. A KV-specific transfer of resource-aware speculative scheduling remains logically possible, but the currently described policy is only adaptive depth plus resource accounting. The missing evidence is a distinct useful KV mechanism and an executable, quality-controlled baseline, not a requirement that every primitive be unprecedented.

No inference, model download, installation, GPU execution, synthetic timing, or new rotation experiment was performed.

## 1. What is actually unresolved in P&F

The uploaded final P&F paper is fully read; see ../oasis_probe_fetch_comparison_20261005/FINAL_COMPARISON.md for identity, page references and the completed comparison.

P&F Eq1 (printed p8131) unions per-draft top-k historical supports. Section2.6 accounts for verification with sparse context size k; the actual union cardinality can reach gamma*k. No explicit union re-truncation or residency-conditioned adaptive horizon policy was found in the inspected methods. This is an accounting/reproduction question. It is not an author-stated claim that such a controller remains unsolved, and it does not demonstrate a buffer overflow or a performance error in an unavailable implementation.

A meaningful proposed controller must distinguish all of the following:

- logical historical support for each verification row
- physical pages actually transferred
- pages already resident, pinned or in flight
- provisional versus accepted generated KV
- draft work already spent and transfers that cannot be cancelled
- verification work and the sparse target whose probabilities it computes

## 2. Exact resource formulation for any subsequent proposal

Let S_i be the logical historical support predicted for draft position i. Let P(S_i) map it to the physical pages required by the chosen layout, including layer and KV-head identity. For prefix length j:

U_j = union(i <= j) S_i
G_j = union(i <= j) P(S_i)
F_j = G_j minus already resident or reusable in-flight pages

The new transfer bytes are sum of the actual byte sizes of pages in F_j, not |U_j| times an assumed constant when layouts, head counts or page sizes differ. In-flight pages only count as ready when their completion precedes the consumer. Occupancy must also include protected recent/generated entries, selector metadata, speculative writes and any double buffering.

A prospective cycle objective is:

J(j) = E[committed tokens | j, chosen sparse target] /
       E[draft cost + exposed transfer tail + verification cost + scheduling/commit cost]

The numerator includes the correction/bonus token where the decoder actually produces it. It is not merely j times an unconditional acceptance rate. A ratio of expectations must not silently become an expectation of per-round ratios.

Verification cost is V(j, U_j, row supports, layout), not a fixed constant or necessarily linear in j*k. Shared PCIe contention and the last draft's shorter prefetch window must be charged once on the real execution critical path.

This formulation is ordinary accounting. Writing it down is not the proposed contribution.

## 3. Strong prior controls, with concrete source evidence

### Adaptive length is already implemented

[SpecDec++](https://github.com/Kaffaljidhmah2/SpecDec_pp/tree/9c52edcfe3542fde89be4623840843a8925dee06), COLM2025, has inspected author code. In hf_generation.py lines699–737, an acceptance head updates cumulative acceptance and stops when predicted rejection exceeds a threshold, subject to minimum/maximum bounds. The example uses threshold0.7 and bounds2–20. This is a real baseline artifact, not merely an abstract.

Saved source files are pinned to commit9c52edcfe3542fde89be4623840843a8925dee06 and were not executed. Training that head or loading its model pair is outside the present screen.

[ASPIRE §4.2 and AppendixA](https://arxiv.org/html/2609.17943v1) chooses per-request horizon from estimated acceptance and a runtime-fitted cost ratio. Its cost model includes sparse draft context, full verification context and batch token count. It therefore supplies a stronger control than a fixed horizon or a simple accept-all/increase heuristic. Its verifier is dense, so it does not establish P&F's approximate-target semantics.

### Resource-aware adaptation has a close transferable precedent

[MoE-SpeQ §§3.2–3.3](https://arxiv.org/html/2511.14102v1) optimizes expected accepted tokens per cycle using profiled draft/verification cost and new expert transfers inferred from predicted demand versus current cache state. It explicitly includes overlap and dynamic speculative depth. The resources are expert weights rather than KV pages. This does not prove the KV problem solved; it establishes the minimum strength of the transferred baseline.

[AcceptMoE Method](https://arxiv.org/html/2608.02989v1) weights resource demand by commitment probability and prunes nonresident experts under a rerouting constraint. It explicitly distinguishes eligibility from residency, uses capacity-limited execution waves, and admits that changing verifier routing changes the target. Its speculative tree is fixed in evaluation. It is a useful control for residency/quality coupling, not an existing KV horizon implementation.

No attributable public source implementation was verified for ASPIRE, MoE-SpeQ, AcceptMoE, Dustin, P&F or OasisKV in this bounded check. Exact-name repository searches and paper links are saved where queried. An unrelated repository returned by the MoE-SpeQ name search was not treated as author code.

## 4. The real KV-specific obstacle

In P&F's shared union-support target, adding a later draft can add historical entries attended to by earlier verification rows. Therefore:

p_target(x_i | prefix, U_j) need not equal p_target(x_i | prefix, U_(j+1)).

Changing horizon can change earlier logits, accepted-prefix length and subsequently committed higher-layer KV. Acceptance statistics from one horizon/support cannot automatically label the counterfactual under another horizon. This follows from attention normalization and changed hidden states; it is not a reported P&F defect.

This is a legitimate place where a transfer from expert scheduling needs adaptation. Merely using resident-overlap bytes in a known horizon optimizer does not address it. Conversely, this difference does not establish that a sophisticated controller must help.

Three ordinary ways to isolate the issue are already available as controls:

1. Freeze the sparse support before choosing horizon; adaptation then cannot improve it through later support union
2. Fetch the physical union but enforce predefined row-specific logical supports
3. Let the block union vary, and evaluate the resulting quality change explicitly

The second control incurs masking/layout work and must use the actual compatible kernel. Neither ordinary row masks nor accepted-state consistency should be renamed as the innovation. Branch pruning or budget changes can also alter which draft states are available; preserving a serial sparse policy requires a separately defined state transition.

## 5. What would be required before admitting a transferred policy

Required strongest controls, under the same model/drafter and declared quality contract:

- P&F's fixed gamma/k path with actual union and transfer accounting
- fixed physical-byte union budget, stopping before an additional draft breaches it
- acceptance-adaptive depth, with the same hard byte cap
- cost-aware adaptive depth using actual sparse verifier cost
- residency-aware resource-cost adaptation obtained by a direct MoE-SpeQ-style transfer
- fixed-support and row-specific-support controls from section4
- target-only sparse execution and dense verification reference where feasible

Comparisons must match peak resident memory and account for page amplification, speculative pages, predictor overhead, CPU-to-GPU traffic, any GPU-to-CPU accepted-KV writes and exposed transfer stalls. More accepted tokens against an easier approximate target is not automatically better quality.

### Cheapest necessary falsifier, not executed

First require authentic existing source or recorded tensor/trace artifacts from the chosen sparse-verification path. For a frozen prompt/round set, preserve predicted supports, page mapping, residency/in-flight state, draft probabilities, target logits for each compared support/horizon, accepted-prefix outcomes and measured stage readiness/costs.

A CPU trace analysis can then reject the idea if an optimistic offline controller has no headroom over the strongest admissible baseline after required bytes, verification work and unavoidable dependencies are charged. It can also reject a proposed policy that merely reproduces the fixed-byte or direct-transfer controller's decisions.

A trace containing logits only for one union cannot establish counterfactual acceptance under another union. Reusing those labels silently would invalidate the test. Synthetic supports can test bookkeeping, but cannot establish real headroom or quality. This screen does not invent such timings or traces.

No specific nontrivial policy that survives these controls was supplied by the present sources. The current proposal is therefore **not admitted**, rather than declared impossible or exhausted.

## 6. One directly related author-stated limitation: Dustin capacity

[Dustin AppendixL and §4.2.3](https://arxiv.org/html/2606.24957v1) explicitly says its full-history indexing does not increase the context length allowed by GPU capacity. Its sparse verifier cannot supply scores for omitted history, so it separately reconstructs global scores from selected semantic retrieval heads. Section4.2 uses offline head/layer selection and budget profiling; the paper's full-layer KV remains available.

### Concrete next source question

Can the exact selected-head scoring path retain only its required historical keys on GPU, while the remaining full-history KV lives in CPU memory and only selected physical pages are fetched for verification?

This is a principled possible transfer of a separate scoring/data plane. It is not yet a new method. The key-only estimator requirement creates a more precise question than “add offloading,” but existing retrieval/offload systems may already cover the relevant mechanism.

For GQA, count unique KV groups referenced by selected query heads, not query heads themselves. Also retain all draft-model state its unchanged forward path requires. With N historical tokens, head dimension d and element bytes b:

M_score = N*d*b*sum_l(unique selected KV groups at target layer l)
M_full_target = 2*N*d*b*sum_l(H_kv,l)

Then add selected-page full KV, draft KV, model weights, staging/double buffers, generated-state writes and metadata. A sparse scorer's small operation count alone does not imply its capacity or transfer overhead is acceptable.

The semantic obligation is equality to the same Dustin selector and its existing approximate verifier, including softmax normalization, stable tie-breaking, sink/local protection and the historical query associated with committed state. No claim of dense equivalence follows.

Admission blockers: no author code or published exact head/configuration artifact was verified; target-side selected keys alone do not make the draft forward executable; all-layer token/page fetches can erase the saved attention bandwidth. Profiling/training burden must be charged rather than replaced by invented heads.

Cheapest source-only gate: obtain and inspect the actual selected-head/group lists and cache layout, then evaluate the above memory bound and compulsory per-round transfer bytes from genuine supports. A later CPU tensor equality check could falsify a key-only reconstruction or GQA mapping. Without those artifacts, it cannot establish useful real-system headroom.

**Status: next precise source question only; no candidate admitted and no run authorized by this report.** Generic key-residency/offloading assembly remains insufficient. A positive candidate would need a concrete layout, exact selection preservation and a measured benefit over a direct offload baseline.

## 7. Scope and stopping condition

The broad P&F comparison is closed. The union-horizon screen stops because it has identified the specific KV semantic complication, required strong controls, and missing executable evidence; a new name or hyperparameter sweep would not resolve those gaps.

This is a bounded negative/admission result, not an exhaustive novelty review, rejection of cross-domain transfer, or publication forecast.
