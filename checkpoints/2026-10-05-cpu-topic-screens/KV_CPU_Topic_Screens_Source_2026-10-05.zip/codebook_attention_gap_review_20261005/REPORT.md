# Independent review: is EDEN attention more than a kernel port?

2026-10-05. Source-only review. No installation, compilation, inference, GPU access, provider action, or publication. The arithmetic/resource estimates below are analytical, not measured speedups.

## Verdict

**Not yet a substantive new method. Keep a bounded engineering experiment, not an admitted research direction.** YAKV has real avoidable staging and per-row inverse-transform work. A transformed EDEN2 consumer could be useful. But vector-pair lookup, GQA tile sharing, online softmax, row-scale handling, and moving a shared value transform after aggregation are already available ingredients. Their combination has not yet supplied a mechanism that beats an ordinary, competently implemented same-format port.

The important additional source finding is that **vLLM's existing TurboQuant kernel already has a 256-by-2 pair-table load path and GQA-stacked tensor-core attention**. The table is currently constructed from Cartesian pairs of 16 scalar centroids, but the runtime gather does not require Cartesian values. Loading EDEN2's arbitrary pairs instead is a small load-site adaptation, not a new lookup algorithm. This is an inference from inspected code, not a claim of a working drop-in: value decoding, FP32 scales, selected row addresses, rotations, numerical behavior, and transport still require work.

## Strong baselines and what they establish

1. **YAKV author path, pinned 7dae316.** [select_kv](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/attention/shadowkv.py#L574-L618) gathers selected packed rows and scales, runs two inverse-Hadamard/BF16 decoders, and returns global BF16 buffers. [The decoder](https://github.com/yandex-research/context-intensive-kv-offloading/blob/7dae3165a1bb747d3707c30db996af6a1277cf23/inference/python/minisgl/kernel/higgs/csrc/higgs_dequantize_heads.cu#L41-L134) already addresses random EDEN lookups with a 32-fold, bank-conflict-free shared table: 32 KiB for a logical 1 KiB BF16 codebook. This is the deployment baseline, not the strongest algorithmic control.
2. **Same-format fused BF16-preserving control.** Decode EDEN K/V into on-chip tiles, perform the author's per-row inverse transform and BF16 conversion, then run attention. Share each decoded tile across its GQA heads. This removes global BF16 staging while preserving the input-row target. It is a control to implement, not existing verified HIGGS attention code.
3. **Simple transformed EDEN port.** Adapt the [vLLM pair-table load](https://github.com/vllm-project/vllm/blob/d61081dc3d3f1740a5d8bf82608b62974393c2de/vllm/v1/attention/ops/turboquant_soa/triton_turboquant_unified_attention.py#L173-L193), retain its GQA QK/PV and online/split reduction, add EDEN V lookup and final inverse transform. The [pair-table constructor](https://github.com/vllm-project/vllm/blob/d61081dc3d3f1740a5d8bf82608b62974393c2de/vllm/v1/attention/ops/turboquant_soa/triton_turboquant_decode_v2.py#L3-L62) explicitly identifies pair lookup and shared KV-group programs as FLUTE-derived optimizations. This is the strongest port baseline for any further proposed schedule. Current vLLM V is affine scalar-quantized; changing it is necessary, but not by itself a new principle.
4. **HIGGS/FLUTE, pinned 9eb83a1.** [The HIGGS adapter](https://github.com/HanGuo97/flute/blob/9eb83a12d56949bbe7fe9c836ba97a67bd1e3761/flute/integrations/higgs.py#L50-L97) installs an arbitrary p=2 grid as the pair map. [The kernel](https://github.com/HanGuo97/flute/blob/9eb83a12d56949bbe7fe9c836ba97a67bd1e3761/flute/csrc/qgemm_kernel.hpp#L606-L710) already duplicates maps by lane, pipelines compressed tiles, dequantizes, and feeds MMA. [HIGGS §4.3 and Appendix G](https://arxiv.org/html/2411.17525v1#S4.SS3) explicitly describe direct transformed-space multiplication. Weight GEMM is not selective KV attention, but arbitrary pair lookup and avoiding per-vector inverse transforms are established.
5. **QuaRot and FlashInfer controls.** [QuaRot query rotation](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/transformers/kv_cache.py#L111-L127), [value/projection rotation](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/e2e/checkpoint_utils/rotation_utils.py#L96-L101), and [streaming int4 attention](https://github.com/spcl/QuaRot/blob/5008669b08c1f11f9b64d52d16fddd47ca754c5a/quarot/kernels/include/flashinfer/decode.cuh#L503-L688) rule out a generic transformed-V novelty claim. [FlashInfer's sparse NVFP4 MLA decoder](https://github.com/flashinfer-ai/flashinfer/blob/745b12352d4419799ff20fb4f6743382dc374b67/flashinfer/experimental/nvfp4_sparse_mla_decode/README.md) is a concrete selected-row decode/attention fusion control, with different codec, hardware and geometry. Neither is a HIGGS offload drop-in.

## Candidate mechanisms, examined concretely

### Query-specific inner-product tables

For D=128, let p=0..63 index coordinate pairs and c=0..255 index EDEN points. For each transformed query head g, precompute T[g,p,c] = q'[g,2p:2p+2] dot C[c]. Then the row logit is sK[row] times the sum of 64 table entries. The scale belongs outside the sum; varying row scales prevent treating this as unqualified nearest-Euclidean-distance lookup.

This is ordinary asymmetric product-quantization scoring. [PQCache §3.1](https://arxiv.org/html/2407.12820v1#S3.SS1) already computes query/centroid products and gathers them by codes before selective CPU retrieval. [LOOKAT §3.5](https://arxiv.org/html/2601.10155v1#S3.SS5) explicitly applies lookup-and-sum to attention. LOOKAT is only evidence for this formula: its hardware-specific kernels remain future work, and this review does not adopt its compression, rank-preservation, or speedup claims.

The resource issue is substantial:

- FP32 table: 64 × 256 × 4 = **65,536 bytes per query head**; GQA8 requires 512 KiB if all eight tables are resident
- Global EDEN coordinates themselves are only 1 KiB BF16 and can be shared; query-dependent tables cannot be shared across different Q heads
- Table construction performs 16,384 two-coordinate dots: 32,768 multiplications plus 16,384 pair additions per Q head
- Each row then performs 64 lookups, 63 summation additions and a scale multiply, versus 128 multiplications and 127 additions for a direct dot, before common scale handling
- The ideal scalar operation-count crossover is R>256 selected rows per head, ignoring table initialization, memory access, tensor-core throughput, occupancy and reuse. It is not a performance prediction

Tiling pairs saves table storage but requires partial-score storage/reloads or repeatedly scanning codes. Tiling heads repeats the KV traversal. A single-head 64 KiB table may fit on some GPUs; saying that does not solve GQA reuse or occupancy. The missing deliverable is a schedule that wins after these costs, rather than naming LUT reuse.

### Code-weighted value histograms

After computing attention weights, exact real-arithmetic PV can be rewritten as h[g,p,c] = sum_rows(prob[g,row] × sV[row] × 1[codeV[row,p]=c]), then u[g,2p:2p+2] = sum_c h[g,p,c] C[c]. This can reuse repeated codes, but a dense histogram is **64 KiB/head**, versus **512 bytes/head** for a normal FP32 D128 output accumulator: 128× larger state. GQA8 again needs 512 KiB before other storage.

Histogram scatters and collisions replace efficient FMA/MMA. Persisting it through online softmax also requires rescaling or an alternative normalization schedule; clearing and resolving a dense histogram per tile can swamp its savings. Sparse occupied-bin processing needs an explicit indexing/reduction algorithm and evidence of sufficient reuse. Independent pair histograms cannot recover exact softmax probabilities, which depend on each row's joint code sequence and scale. [LISA's codeword-histogram attention](https://arxiv.org/abs/2105.14068) is relevant prior art, but its trained/relaxed attention formulation is not evidence of a semantics-preserving shortcut for YAKV.

### Row scales, GQA, selected rows and transport

For the unrounded codebook target, K scale may be applied once per logit and V scale once per attention weight before PV. That reduces scale operations relative to per-coordinate scaling, but is a routine diagonal-factorization optimization. It also changes rounding versus scaling and casting decoded coordinates before dot products.

The useful deployment constraint is head-specific selected addresses, with the same rows shared by all queries in a KV group. The source gather already maps prefix, selected chunks and suffix rows. A port must preserve this, active-slot holes, valid lengths and generated-token growth. Directly reading mapped CPU rows is not automatically better than a gather: remote transaction granularity, repeated GQA loads and overlap may dominate. No candidate described so far reduces the required CPU code payload for unchanged selections.

## Exact logical traffic and transform accounting

Let M = sum over active requests and KV heads of selected row count. D=128. Ignore metadata, query/output traffic, cache effects and any additional reads from the actual schedule. Assume code gather is retained and each KV tile is shared by its GQA group.

| Per selected head-row | Author staging | Fused BF16 control | Simple transformed port |
|---|---:|---:|---:|
| CPU-origin K+V code payload | D = 128 B | 128 B | 128 B |
| HBM code staging write + read | 2D = 256 B | 256 B | 256 B |
| Global BF16 K+V write + first read | 8D = 1,024 B | 0 | 0 |
| Separate GPU scale gather read/write + consumer read | 24 B | 24 B | 24 B |

Thus the two fused designs each remove **1,024 M logical bytes**, and the transformed port saves **zero additional staging bytes relative to the fused BF16 control**. Bypassing gathered scales can remove 16 M bytes for either fused design. Eliminating code gathering could remove another 256 M HBM bytes, also for either design; that does not eliminate 128 M host-origin bytes. If scales are moved to the CPU, add 8 M host bytes. These are payload/logical-access counts, not exact physical bus or DRAM transaction measurements.

The incremental transformed-port opportunity is arithmetic: the BF16 control requires 2 M inverse D-point Hadamards; the transformed version requires one output inverse per active Q head, plus Q transforms unless reused from scoring. Each D128 butterfly costs 896 scalar add/sub operations, so the removed per-row transform term is 1,792 M operations before output/Q costs. Attention's QK+PV still costs approximately 4GD operations per selected KV row. GQA-sharing must be equally competent in both controls.

Maximum-capacity scratch is separate from active traffic. In the author's B=17, Nmax=131072, Hkv=4 example, both fused designs can eliminate the same 4.25 GiB global BF16 allocation. This allocation is reused across layers, not multiplied by layer count. A capacity gain may matter even without latency improvement, but it belongs to both fused controls.

## Cheapest falsifier and admission gate

**Source-stage falsifier, already reached:** the claimed differentiating ingredients are present in prior implementations, including arbitrary p=2 FLUTE lookup and GQA pair-LUT attention. The bare residual cannot currently support a substantive new-method claim. No further algebra identity test will change that.

**Smallest performance experiment, requiring later authorization:** one GPU, no model weights; freeze actual EDEN2 codes/scales and selected-index patterns. Compare (A) author staging, (B) same-format fused inverse/BF16 tiles, and (C) the simple transformed pair-LUT port. Only if proposing an additional LUT/histogram/transport schedule add (D), and require it to beat C, not merely A. Use a small preregistered grid spanning the intended selected lengths, GQA1/8, batch1 and a batching case; report device-only and identical transport-inclusive timing. Keep selections, codec and numerical target fixed within each valid comparison. Profile lookup stalls, shared memory, register spills, GQA reloads and split-state cost.

If C beats B meaningfully with acceptable numerical changes, that establishes a useful codec-specific transfer. It does **not**, by itself, establish a new algorithm beyond the straightforward port. A publishable systems case would still need a new bounded-memory schedule or an independently important measured deployment result with strong controls. If a proposed D does not beat C in the intended regime, reject its mechanism.

The existing CPU tests establish only real-arithmetic equivalence for unrounded reconstructed codebooks. The native-geometry 32Q/4KV frozen test reports output difference 7.11e-15 in FP64 but 0.0546492 against its simulated BF16-staged reference (scaled 0.00333936). It neither validates a GPU kernel nor establishes model quality. Per-row BF16 rounding cannot be commuted through attention, and removal of that rounding has no guaranteed beneficial effect.

## Evidence record

Reused the pinned source packet and CPU result files under `../yakv_scratch_dataflow_screen_20261005/`, independently inspected the decisive load sites, and verified vLLM lines 173–193 against the commit-pinned GitHub endpoint. Newly retrieved FLUTE source files are saved in `sources/`; their pin is `9eb83a12d56949bbe7fe9c836ba97a67bd1e3761`. Search was bounded to actual implementations and direct method precedents. Failure to find an exact combined implementation is not novelty evidence.
