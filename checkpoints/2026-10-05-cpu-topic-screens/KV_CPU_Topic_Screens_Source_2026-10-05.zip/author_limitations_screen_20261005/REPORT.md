# Author-stated limitations: bounded source screen and one CPU falsifier

Date: 2026-10-05 UTC. **Decision: no candidate promoted.** One concrete approximation mechanism was specified and tested, then stopped at its predeclared phase-error gate. No model was loaded or run. No package was installed, no GPU/provider was used, and spending was zero.

## Result first

The proposed mechanism was a **fixed offline Hadamard transform across the eight slowest RoPE frequency pairs**, with no runtime inverse. It aimed to remove an online Q/K rotation while gaining more mixing support than exact pairwise rotations.

For the recorded Qwen2.5-7B-Instruct geometry and all 32,768 possible nonnegative relative offsets in its native context, its maximum phase operator norm is **0.1053186445**, exceeding the predeclared **0.05** contract. The maximum occurs at relative offset 32,767. The unchanged transform under fixed YaRN ×4 and 128K context reaches **0.1053210524** before, or **0.1365463213** after, YaRN's attention scaling.

The code's numerical controls passed. The quantization comparison was **not run**, because primary phase failure was the stopping condition. Runtime was **7.75 CPU seconds**, with **34,296 KiB peak RSS**. This is a rejection of the fixed transform under this chosen uniform error contract. It is not an observed model-quality failure, an impossibility result for all approximate rotations, or grounds to shorten the context, alter the band, loosen the threshold, or start a model run.

## 1. Source-supported limitation and proposed mechanism

### What the authors actually leave open

[OScaR, Appendix A](https://arxiv.org/html/2605.19660v1#A1), identifies online rotation/scaling overhead and explains that RoPE prevents folding its Q/K Hadamard into projection weights. Its existing implementation already reduces the cost with fused preprocessing and Tensor Core support. This motivates looking for a cheaper transform; it does not establish the proposed method.

The pinned [author Qwen3 path](https://github.com/ZunhaiSu/OScaR-KV-Quant/blob/d2109f573da841151355976b66b06dade991388b/kv_cache_compression/qwen3_model.py#L108-L126) applies Q/K normalization, RoPE, then the quantizer's transform. The [quantizer](https://github.com/ZunhaiSu/OScaR-KV-Quant/blob/d2109f573da841151355976b66b06dade991388b/kv_cache_compression/quarot_utils.py#L669-L698) rotates Q and K together. The [CUDA preprocessing](https://github.com/ZunhaiSu/OScaR-KV-Quant/blob/d2109f573da841151355976b66b06dade991388b/csrc/oscar/src/k_preprocess.cu) already has a specialized 128-dimensional path. Comparing against an unfused Python Hadamard alone would be unfair.

### The hypothesis supplied by this screen

For a finite deployment horizon, nearby low RoPE frequencies might permit broader, approximately commuting mixing. A fixed transform could be absorbed into Q/K weights and biases, leaving a small phase error but no online transform. The useful trade would be lower quantization error than an exact pairwise transform, with the added phase error sufficiently small and the saved runtime work meaningful.

The source does not claim this idea or its benefit. The hypothesis specifically adds **approximate cross-frequency mixing before RoPE**, rather than renaming exact commutative quantization, a post-RoPE block rotation, or ordinary kernel fusion.

### Strong prior controls and what they rule out

- [FPTQuant, §3.1.1 and Appendix C](https://arxiv.org/html/2506.04985v2#S3.SS1.SSS1), already folds exact paired rotations and reciprocal Q/K scales into weights. Exact pairwise offline transformation is occupied
- [CommVQ, §4.2](https://arxiv.org/html/2506.18879v1#S4.SS2), already uses RoPE-commutative codebooks and rearranged attention computation. Its pinned [KeyCompressor](https://github.com/UMass-Embodied-AGI/CommVQ/blob/d1f0377429b30ff8933fd0debcbc9c0d4efd06a3/commvq/compress_triton.py#L131-L168) explicitly constructs paired 2×2 codebook matrices. Commutativity itself is not the residual
- [RotateKV, §4.2.2](https://arxiv.org/html/2501.16383v1#S4.SS2.SSS2), folds the forward pre-RoPE transform into weights but retains the inverse operation. Removing that inverse while bounding the resulting attention change is the particular proposed trade
- [Wang et al., August 2026, §§2–3, 6 and Appendix M](https://arxiv.org/html/2608.13365v1), proves that distinct frequencies restrict exact single-head orthogonal commutation to individual pairs. Its controlled support interpolation already studies 2 through 128 channels. Those transforms are applied **after** RoPE, preserving unquantized attention even for larger blocks. Their result therefore constrains the mixing-benefit story without measuring this candidate's pre-RoPE phase error. Their scoped negative pairwise result must not be interpreted as proof that all pairwise methods fail

The bounded search did not establish novelty of finite-horizon approximate fusion. FPTQuant's full author implementation and Wang et al.'s companion artifact were not located through the inspected primary pages/repository search. Their full relevant paper sections were read; they are not claimed reproduced.

## 2. Frozen mathematical contract

Column-vector convention is used here. Let R_delta be RoPE's relative-position rotation and U the candidate. Original unquantized attention has numerator

a = q^T R_delta k.

Absorbing U into both Q and K projections changes it to

a_U = q^T U^T R_delta U k.

Therefore E_delta = U^T R_delta U - R_delta, and

|a_U - a| / sqrt(d) <= ||q|| ||k|| ||E_delta||_2 / sqrt(d).

Applying U **after** RoPE to both streams instead is exactly inner-product preserving. This is the crucial placement control; less quantization error in a post-RoPE experiment cannot be imported as evidence for offline fusion.

### Model geometry and fixed transform

The [official raw Qwen2.5-7B-Instruct config](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/raw/main/config.json) was read on the test date. It records hidden size 3,584; 28 query heads; 4 KV heads; 28 layers; theta 1,000,000; native maximum length 32,768; and sliding windows disabled. Thus d_head = 128, with frequencies omega_j = theta^(-2j/128), j=0,...,63.

The file page identifies last change [a306ca65c69cb09b9ce8ae8396fd529d509d872e](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/commit/a306ca65c69cb09b9ce8ae8396fd529d509d872e). The immutable raw/blob URLs could not be retrieved by the web tool; the available bytes were the current raw config. This source-access distinction is preserved rather than claiming an immutable-byte fetch.

U is identity on frequency pairs 0–55 and normalized Sylvester H8 mixing on pairs 56–63, acting identically on their two real coordinates. In the native rotate_half layout, pair j is (j,j+64). There is no head mixing, fitted parameter, adaptive band, runtime inverse, or correction. The exact same U is used at all positions and in both scaling conditions.

### Primary gate

Evaluate the exact numerical spectral norm of E_delta at **every integer delta = 0,...,32767**. Negative offsets have the same singular values because U is real. The predeclared gate is max_delta ||E_delta||_2 <= 0.05.

This 0.05 is a prospective engineering error budget, not an empirically established model-quality boundary. The test asks whether the chosen transform meets that uniform contract. Its failure cannot establish that a deployment permitting greater error is useless.

The calculation uses complex128 8×8 SVD, equivalent to the real 16×16 active band; all other dimensions contribute zero phase error. It stores the full norm-versus-offset arrays and an attaining singular-vector witness. An analytic bound from the band's frequency diameter is also reported, but the gate uses SVD rather than that looser bound.

### Fixed positional-scaling check

The [model card](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct#processing-long-texts) specifies static YaRN factor 4 with original length 32,768 for longer contexts. The test uses the pinned [Transformers YaRN formula](https://github.com/huggingface/transformers/blob/1aac9583ceb31c8290897c8cb17292922c8b24b4/src/transformers/modeling_rope_utils.py#L345-L483), defaults beta_fast=32, beta_slow=1, truncation enabled, and attention factor 1+0.1 ln(4). It evaluates every offset through 131,071 without changing U.

This is a float64 NumPy translation of the archived formula, not execution of its Torch float32 implementation. Both normalized rotation error and the squared attention-factor scaling of the raw dot-product error are recorded.

## 3. Executed controls, results, and interpretation

| Check | Result |
|---|---:|
| H8 orthogonality residual | 1.11e-16 |
| Identity commutation residual | 0 |
| Exact per-pair rotation commutation residual, both horizons | <=2.49e-16 |
| Real-16D versus complex-8D spectral norm disagreement | <=2.09e-17 |
| Two-pair Hadamard analytic formula disagreement | <=2.45e-16 |
| Q/K-style weight-plus-bias folding error, synthetic FP64 projection | 1.78e-15 |
| Native phase maximum | 0.1053186445 |
| Native phase median / p99 | 0.0526815958 / 0.1042666280 |
| YaRN phase maximum, normalized | 0.1053210524 |
| YaRN phase maximum, attention-scaled | 0.1365463213 |

The saved real singular vectors have unit norm and attain the native phase error 0.1053186445. For hypothetical Q and K each of norm sqrt(128), this permits a logit shift of 1.19154 after the ordinary 1/sqrt(128) normalization, or 1.54485 in the YaRN condition. These are constructed norm-scaled witnesses, **not measurements of real Q/K norms, typical logits, softmax changes, answers, or perplexity**.

The failure is not numerical noise, an interleaved-versus-split-pair mistake, or omission of projection bias. It arises from using one broader fixed transform before unequal-frequency rotations. The scaling check also prevents treating a 4× longer YaRN context as automatically 4× safer merely because its slow frequencies are divided by four.

### Why the secondary quantization test stopped

The prospective packet included a tensor-only OScaR-style quantization comparison: original uncompressed; identity; exact pairwise rotation; full-head post-RoPE Hadamard; identical-support post-RoPE U; candidate U without quantization; and candidate U with quantization. Its aim was to separate quantization gain, phase-only loss, and their interaction, preserving every synthetic seed/tensor. Actual learned FPTQuant and CommVQ would remain necessary later full-method comparisons.

Primary phase failure stopped this stage. Consequently **there is no measured quantization benefit, total-distortion result, or claim that the phase error exceeds actual quantization savings**. A favorable constructed quantization case cannot rescue the failed uniform contract retrospectively.

## 4. Real execution economics and remaining model caveats

The [pinned Qwen2 attention source](https://github.com/huggingface/transformers/blob/1aac9583ceb31c8290897c8cb17292922c8b24b4/src/transformers/models/qwen2/modeling_qwen2.py#L156-L191) maps biased Q/K projections directly to RoPE, so folding requires rotating the corresponding projection rows **and biases**. GQA requires matching the same transform in every query head that reads a KV head. This screen checks the local projection identity on synthetic weights only.

Qwen3's learned Q/K normalization is a separate obstruction. An orthogonal transform preserves an unweighted RMS denominator, but arbitrary learned per-channel gamma does not generally commute with a wider rotation. A generic port must prove its normalization rewrite or count its added operations. The test does not silently replace Qwen3 normalization or claim the fold works there.

For BF16/FP16 projection weights, folding can preserve projection shape and remove runtime U application in principle, with one-time transform/write cost. Folding already-quantized W4 weights generally requires dequantization/refolding/requantization and fresh accuracy validation; it is not free. A deployable study must count this preprocessing and its storage, the existing normalization/packing work, and a fused online baseline. No 5090 speedup or compatibility measurement was made.

The candidate is therefore stopped before kernel development, saved-model tensor capture, or GPU admission. No retuned band/window follows under the same hypothesis.

## 5. Second author-stated limitation: screened, not admitted

[OasisKV, §5.3.1](https://arxiv.org/html/2608.08097v1#S5.SS3.SSS1), states that its draft token is currently forced to reject and leaves joint accepted-token speculation with prefetching to future work. Its §§4.2–4.3 explain the existing draft-query propagation, summary scan, layer-local dependency pipeline and capped transfers. A meaningful residual would have to show how accepting several tokens changes sparse support preparation and the available transfer deadline, rather than just turning on two existing features.

A strong nearby lead is [Probe-and-Fetch, WWW 2026, author institution record](https://scholars.cityu.edu.hk/en/publications/probe-and-fetch-dynamic-kv-cache-pruning-for-accelerated-long-con/), whose abstract already describes integrating speculative decoding and dynamic KV fetching to address synchronization. Its full publisher paper returned 403, and neither its implementation nor an attributable OasisKV repository was verified in this bounded pass. An empty repository search is not proof that no code exists.

**No second mechanism is promoted.** The author's future-work sentence establishes an implementation boundary, not an unoccupied topic. Before a further proposal, the exact P&F verification/fetch schedule and target-distribution contract must be read and compared. A generic token-prefix union, transactional buffer, or scheduling simulation would not establish the requested contribution. No distributed-GPU experiment or local port is justified from these sources.

## 6. Reproducibility and stopping receipt

Files in this directory:

- protocol.json: frozen before numerical execution; SHA-256 9acec1c1691bdf822556f3d10fecd8b1c9650c49c69953ff56249f8187a22d0e
- phase_falsifier.py: frozen executable; SHA-256 ba53426f697cf4a45fad584251d00985c2858c2f6aa9b07c141812edc26eac7d
- run.log: complete successful execution output
- results/result.json: decision, controls, resource use and precise numbers
- results/native_arrays.npz and results/yarn4_arrays.npz: all offset/operator-norm arrays, frequencies, matrices and real witnesses
- results/controls_arrays.npz: full synthetic folding-control inputs/outputs
- results/sha256.json: result-file checksums
- sources/: inspected pinned author/Transformers code, tree receipts, code-source receipt and paper evidence index

The source screen first inspected the existing architecture, calibration, query-drift, reconstructed novelty, resource, testing and alternative-direction decisions. It did not reopen the first24/Full6, predictive-codec, deferred-state, adapter, speculative-rollback, shared-mask/allocation, or generic testing lanes. The test is new and model-free; no old experiment data were reused.

**Final state: one fixed mechanism rejected under its registered contract; second mechanism not admitted because the strongest close comparison and author artifact remain unresolved.** This finite screen is complete. It warrants neither paid use nor a publication claim.

