"""Fixed finite-horizon RoPE fusion falsifier. No model, torch, or external runtime."""
import os
for name in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[name] = "1"
import resource, signal, json, math, hashlib, time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CPU, (120,120))
resource.setrlimit(resource.RLIMIT_AS, (512*1024*1024,512*1024*1024))
signal.alarm(140)
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"results"
OUT.mkdir(exist_ok=True)
PROTOCOL=json.loads((ROOT/"protocol.json").read_text())
START=time.process_time()
rng=np.random.default_rng(20261005)
def hmat(n):
    h=np.array([[1.]],dtype=np.float64)
    while len(h)<n:
        h=np.block([[h,h],[h,-h]])
    return h/math.sqrt(n)
H=hmat(8)
idx=np.arange(56,64)
omega=1000000.**(-2*np.arange(64,dtype=np.float64)/128)
def yarn(w):
    dim=128; base=1000000.; orig=32768; factor=4.
    def bound(n):
        return dim*math.log(orig/(n*2*math.pi))/(2*math.log(base))
    lo=max(math.floor(bound(32)),0)
    hi=min(math.ceil(bound(1)),dim-1)
    denom=(hi-lo) if hi!=lo else .001
    ramp=np.clip((np.arange(dim//2,dtype=np.float64)-lo)/denom,0,1)
    ext=1-ramp
    return (w/factor)*(1-ext)+w*ext,1+.1*math.log(factor),lo,hi
yw,ya,yl,yh=yarn(omega)
def real_rep(z):
    return np.block([[z.real,-z.imag],[z.imag,z.real]])
fixed_deltas=[0,1,127,1023,8191,32767]
controls={"H_orthogonality_max":float(np.max(np.abs(H.T@H-np.eye(8))))}
summaries={}
for name,w,L,amp in [("native",omega,32768,1.),("yarn4",yw,131072,ya)]:
    op=np.zeros(L,dtype=np.float64)
    identity_max=0.; commuting_max=0.; analytic_max=0.
    band=w[idx]
    for begin in range(0,L,1024):
        delta=np.arange(begin,min(begin+1024,L),dtype=np.float64)
        phase=np.exp(1j*delta[:,None]*band[None,:])
        D=np.zeros((len(delta),8,8),dtype=np.complex128)
        D[:,np.arange(8),np.arange(8)]=phase
        E=np.einsum("ij,bjk,kl->bil",H.T,D,H)-D
        op[begin:begin+len(delta)]=np.linalg.svd(E,compute_uv=False)[:,0]
        identity_max=max(identity_max,float(np.max(np.abs(D-D))))
        G=np.exp(1j*math.pi/4)*np.eye(8,dtype=np.complex128)
        commute=np.einsum("ij,bjk,kl->bil",G.conj().T,D,G)-D
        commuting_max=max(commuting_max,float(np.max(np.abs(commute))))
    equiv=[]
    for d in fixed_deltas+([131071] if name=="yarn4" else []):
        D=np.diag(np.exp(1j*d*band)); E=H.T@D@H-D
        Ur=real_rep(H.astype(np.complex128)); Dr=real_rep(D)
        equiv.append(abs(float(np.linalg.svd(Ur.T@Dr@Ur-Dr,compute_uv=False)[0])-op[d]))
        H2=hmat(2); D2=np.diag(np.exp(1j*d*band[:2]))
        exact=float(np.linalg.svd(H2.T@D2@H2-D2,compute_uv=False)[0])
        analytic=math.sqrt(2)*abs(math.sin(d*(band[0]-band[1])/2))
        analytic_max=max(analytic_max,abs(exact-analytic))
    imax=int(np.argmax(op))
    D=np.diag(np.exp(1j*imax*band)); E=H.T@D@H-D
    left,s,right=np.linalg.svd(E)
    q=left[:,0]; k=right.conj().T[:,0]
    attained=abs(np.vdot(q,E@k))
    # Full real native-layout witness. Complex realification preserves real dot products.
    qr=real_rep(np.column_stack([q,np.zeros(8)]))[:,0] # [Re(q),Im(q)]
    kr=real_rep(np.column_stack([k,np.zeros(8)]))[:,0]
    Er=real_rep(E)
    # Complex singular vectors can attain complex magnitude; use direct real SVD for exact real witness.
    rl,rs,rr=np.linalg.svd(Er)
    qr=rl[:,0]; kr=rr.T[:,0]
    signed=float(qr@Er@kr)
    np.savez_compressed(OUT/(name+"_arrays.npz"),
        relative_offsets=np.arange(L,dtype=np.int64),operator_norm=op,
        omega_all=w,omega_band=band,H=H,endpoint_error_complex=E,
        witness_q_real=qr,witness_k_real=kr,endpoint_error_real=Er)
    summaries[name]={
        "max_tokens":L,"max_relative_offset":L-1,"attention_factor":amp,
        "norm_max":float(op[imax]),"maximizing_offset":imax,
        "norm_mean":float(op.mean()),"norm_percentiles":dict(zip(["p50","p95","p99"],map(float,np.percentile(op,[50,95,99])))),
        "threshold":.05,"normalized_gate_pass":bool(op[imax]<=.05),
        "raw_attention_scaled_max":float(op[imax]*amp**2),
        "unit_qk_attention_logit_max":float(op[imax]*amp**2/math.sqrt(128)),
        "norm_sqrt_d_qk_attention_logit_max":float(op[imax]*amp**2*math.sqrt(128)),
        "analytic_uniform_bound":float(min(2,(L-1)*(band.max()-band.min()))),
        "witness_signed_error":signed,"witness_q_norm":float(np.linalg.norm(qr)),
        "witness_k_norm":float(np.linalg.norm(kr)),
        "complex_witness_error":float(attained),
        "controls":{"identity_max":identity_max,"commuting_pair_rotation_max":commuting_max,
          "complex_real_svd_error_max":float(max(equiv)),"two_pair_analytic_error_max":analytic_max}
    }
# Projection/bias folding algebra, small synthetic matrices only; no model weights.
U=np.eye(128); U[np.ix_(idx,idx)]=H; U[np.ix_(idx+64,idx+64)]=H
W=rng.normal(size=(128,16)); b=rng.normal(size=128); x=rng.normal(size=16)
fold_before=U@(W@x+b); fold_after=(U@W)@x+U@b
fold_error=float(np.max(np.abs(fold_before-fold_after)))
controls["weight_bias_fold_abs_max"]=fold_error
np.savez_compressed(OUT/"controls_arrays.npz",U=U,W=W,b=b,x=x,fold_before=fold_before,fold_after=fold_after)
control_ok=all(v<=1e-12 for v in controls.values()) and all(
    v<=1e-12 for name in summaries for v in summaries[name]["controls"].values())
result={
    "protocol_sha256":hashlib.sha256((ROOT/"protocol.json").read_bytes()).hexdigest(),
    "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "numpy_version":np.__version__,"dtype":"float64/complex128",
    "source_formula_note":"YaRN formula is a float64 NumPy translation of the archived source, not an execution of Torch's float32 implementation.",
    "yarn_correction_low":yl,"yarn_correction_high":yh,
    "qwen_norm_caveat":"No QK norm in pinned Qwen2Attention; Qwen3 QK norm/gamma folding is not covered.",
    "controls":controls,"controls_pass":control_ok,"phase":summaries,
    "secondary_quantization":"NOT_RUN_PHASE_GATE_FAILED" if not summaries["native"]["normalized_gate_pass"] else "NOT_RUN_REQUIRES_FULLY_SPECIFIED_SECONDARY_ARRAY_GENERATOR",
    "verdict":"REJECT_FIXED_U8_UNIFORM_PHASE_CONTRACT" if control_ok and not summaries["native"]["normalized_gate_pass"] else "REVIEW",
    "cpu_seconds":time.process_time()-START,
    "max_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
}
(OUT/"result.json").write_text(json.dumps(result,indent=2)+"\n")
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file()}
(OUT/"sha256.json").write_text(json.dumps(files,indent=2)+"\n")
print(json.dumps(result,indent=2))

