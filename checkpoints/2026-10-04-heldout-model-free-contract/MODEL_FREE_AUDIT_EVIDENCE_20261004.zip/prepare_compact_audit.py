import ast,hashlib,json,resource,shutil,stat,sys,zipfile
from pathlib import Path,PurePosixPath
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
b=Path(__file__).resolve().parent;work=b/'compact_contract';assert not work.exists();assert shutil.disk_usage(b).free>=5_000_000_000
archive=b.parent/'revision_compact_contract_backup_20261004_sq0h6uoq/KV_Revision_Heldout_Preparation_20261004.zip'
assert archive.stat().st_size==1273736 and hashlib.sha256(archive.read_bytes()).hexdigest()=='75dc11b605c2f324fe44abdcad254b1a8d111bcc778a3558aeff5db8f72421f5'
prefix='KV_Revision_Heldout_Preparation_20261004/'
with zipfile.ZipFile(archive) as z:
 names=z.namelist();assert len(names)==len(set(names))==124
 manifestbytes=z.read(prefix+'PACKAGE_MANIFEST_VERSION_1.json');assert hashlib.sha256(manifestbytes).hexdigest()=='5e5dec602f4e8b92aadb690e6f67ad14d5786d2ea9df3fb28c83a05804d77e95'
 manifest=json.loads(manifestbytes);expected={prefix+x['path']:x for x in manifest['files']}
 assert set(names)==set(expected)|{prefix+'PACKAGE_MANIFEST_VERSION_1.json'}
 for i in z.infolist():
  p=PurePosixPath(i.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(i.external_attr>>16)
  data=z.read(i)
  if i.filename in expected:
   row=expected[i.filename];assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
  out=work/i.filename;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
root=work/prefix;here=root/'research/reconstructed/revision_heldout_compact_contract_20261004';reconstructed=here.parent
protocol=json.loads((here/'protocol.json').read_text());missing=[x for x in protocol['source_dependencies'] if not (reconstructed/x['path']).is_file()]
assert len(missing)==4
archives=[(b.parent/'revision_pilot_final_backup_20261004_lohcd0zj/KV_Revision_V2_Preparation_20261004.zip','772b551c4e0cfa44c4e255ae9c91e2362d2331cbf9360793994ffa7adc94fe07','libfile_eb47ac747be081918af5c0edb54c6808',3),(b.parent/'revision_temporal_terminal_backup_20261004_4q4apt3j/KV_CPU_TemporalScope_Attempt6_20261004.zip','6f4d45cc977d757603a9ac6a676aa569700d86d55abb57a9500dd9cc711e5086','libfile_454225933afc8191b2c5ee4369b72c84',0)]
resolved=[]
for path,digest,lid,ver in archives:
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
 with zipfile.ZipFile(path) as z:
  for row in missing:
   target=reconstructed/row['path']
   if target.exists():continue
   candidates=[n for n in z.namelist() if n.endswith('/research/reconstructed/'+row['path'])]
   for name in candidates:
    data=z.read(name)
    if len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']:
     target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);resolved.append({**row,'source_library_id':lid,'source_version':ver,'source_archive_sha256':digest,'archive_member':name});break
for row in protocol['source_dependencies']:
 data=(reconstructed/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
allowed={'common','decode','freeze_source','maps','parity','plan','receipts','storage'}
pythonfiles=list(here.glob('*.py'))
for p in pythonfiles:
 tree=ast.parse(p.read_text());compile(p.read_bytes(),str(p),'exec')
 for n in ast.walk(tree):
  imports=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module or ''] if isinstance(n,ast.ImportFrom) else []
  for mod in imports:assert mod.partition('.')[0] in sys.stdlib_module_names|allowed,(p.name,mod)
result={'archive_sha256':'75dc11b605c2f324fe44abdcad254b1a8d111bcc778a3558aeff5db8f72421f5','archive_entries_verified':124,'payload_manifest_rows_verified':len(manifest['files']),'source_dependency_rows':len(protocol['source_dependencies']),'missing_from_standalone_v1':missing,'resolved_only_from_declared_archives':resolved,'all_dependency_hashes_verified':True,'current_contract_python_modules_static_compiled_stdlib_import_graph':len(pythonfiles),'live_worktree_bytes_used':False,'source_modified':False}
(b/'COMPACT_RESTORATION_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
