import ast,hashlib,json,resource,shutil
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
b=Path(__file__).resolve().parent;r=b/'extracted/KV_CPU_Engineering_Through_Attempt06'
assert shutil.disk_usage(b).free>=5_000_000_000
# Follow RESTORE.md: preserve snapshots and assemble only research/outputs into a separate tree.
d=b/'assembled';assert not d.exists();duplicates=[]
for root in ('prior_cpu_v9','attempt06'):
 for kind in ('research','outputs'):
  for p in (r/root/kind).rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(r/root);out=d/rel
   if out.exists():
    assert out.read_bytes()==p.read_bytes(),str(rel);duplicates.append(str(rel))
   else:out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
# Reconstitute the archived locked pre-release version separately, in its original relative location.
locked=b/'locked_contract_checkout';sub=Path('research/reconstructed/revision_cpu_file_pager_20261004')
l=r/'prior_cpu_v9'/sub/'reviewed_locked_source'
for p in l.iterdir():
 if p.is_file():out=locked/sub/p.name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
for rel in ('research/reconstructed/revision_cpu_feasibility_20261004/prospective_cpu_protocol_v2.json','research/reconstructed/revision_causal_v2_20261004/refinement_02_delimiter/constructed_variants.json','outputs/revision_cpu_model_assets_20261004/acquisition_start.json'):
 out=locked/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(d/rel,out)
assert 'CPU_EXECUTION_RELEASED = False' in (locked/sub/'cpu_release.py').read_text()
manifest=json.loads((locked/sub/'source_manifest.json').read_text())
for row in manifest['files']:assert hashlib.sha256((locked/sub/row['path']).read_bytes()).hexdigest()==row['sha256']
(b/'assembly.json').write_text(json.dumps({'assembled_research_outputs_files':len(list(d.rglob('*'))),'byte_identical_duplicate_paths':duplicates,'locked_snapshot_files_verified':len(manifest['files']),'locked_snapshot_source_manifest_sha256':hashlib.sha256((locked/sub/'source_manifest.json').read_bytes()).hexdigest()},indent=2)+'\n')
print((b/'assembly.json').read_text())
