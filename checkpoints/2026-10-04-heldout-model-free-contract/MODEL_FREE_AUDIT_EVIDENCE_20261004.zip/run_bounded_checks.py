import json,os,resource,shutil,signal,subprocess,sys,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(55,55))
b=Path(__file__).resolve().parent;t0=time.monotonic();limit=60;results=[]
checks=[('attempt06_stdlib_helpers',[sys.executable,'-I','-S',str(b/'check_stdlib_helpers.py')],b),('locked_original_contract_tests',[sys.executable,'-S','-B',str(b/'locked_contract_checkout/research/reconstructed/revision_cpu_file_pager_20261004/test_actual_contracts.py')],b/'locked_contract_checkout')]
for name,cmd,cwd in checks:
 start=time.monotonic();assert shutil.disk_usage(b).free>=5_000_000_000
 with (b/(name+'.stdout')).open('w') as stdout,(b/(name+'.stderr')).open('w') as stderr:
  proc=subprocess.Popen(cmd,cwd=cwd,stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','CUDA_VISIBLE_DEVICES':'','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'})
  peak=0;free=shutil.disk_usage(b).free;stop=None
  while proc.poll() is None:
   records={}
   for p in Path('/proc').glob('[0-9]*/stat'):
    try:f=p.read_text().rsplit(')',1)[1].split();records[int(p.parent.name)]=(int(f[1]),int(f[21])*os.sysconf('SC_PAGE_SIZE'))
    except (OSError,IndexError,ValueError):pass
   ids={proc.pid};prev=None
   while ids!=prev:prev=ids.copy();ids|={pid for pid,(parent,rss) in records.items() if parent in ids}
   rss=sum(records[pid][1] for pid in ids|{os.getpid()} if pid in records);peak=max(peak,rss)
   free=min(free,shutil.disk_usage(b).free)
   if rss>=1024**3:stop='RSS_1GIB'
   elif free<5_000_000_000:stop='DISK_FLOOR_5GB'
   elif time.monotonic()-t0>=55:stop='WALL_55S_STOP_WITHIN_60S'
   if stop:os.killpg(proc.pid,signal.SIGKILL);break
   time.sleep(.01)
  rc=proc.wait()
 results.append({'name':name,'returncode':rc,'elapsed_seconds':time.monotonic()-start,'sampled_process_tree_peak_rss_bytes_including_supervisor':peak,'disk_free_min_bytes':free,'stop_reason':stop,'stdout_file':name+'.stdout','stderr_file':name+'.stderr','automatic_retries':0})
 if stop:break
receipt={'checks':results,'elapsed_seconds_all':time.monotonic()-t0,'max_address_space_per_process_bytes':1024**3,'model_experiment':False,'downloads':0,'installs':0}
(b/'stdlib_test_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
for x in results:
 print('\n'+x['name']+' STDOUT\n'+(b/x['stdout_file']).read_text());print('STDERR\n'+(b/x['stderr_file']).read_text())
