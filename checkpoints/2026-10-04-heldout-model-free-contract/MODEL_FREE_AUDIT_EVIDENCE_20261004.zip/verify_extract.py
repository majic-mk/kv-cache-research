import hashlib,json,os,resource,shutil,stat,time,zipfile
from pathlib import Path,PurePosixPath
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(55,55))
t0=time.monotonic();base=Path(__file__).resolve().parent
src=base.parent/'github_cpu_attempt06_delivery_20261004';target=base/'extracted'
assert not target.exists();assert shutil.disk_usage(base).free>=5*1024**3
a=src/'KV_CPU_Engineering_Through_Attempt06_Source_20261004.zip';m=src/'SOURCE_SELECTION_MANIFEST.json'
assert a.stat().st_size==1947480
assert hashlib.sha256(a.read_bytes()).hexdigest()=='9646bd399b959e4dfe92f69979eb73cca15924e99de289900bba6fcaaa447de4'
assert hashlib.sha256(m.read_bytes()).hexdigest()=='6a8adb27d8ab8c0fea491a8be4a485cbd85738cb66f0652d06fcab9c290f283c'
manifest=json.loads(m.read_text());prefix='KV_CPU_Engineering_Through_Attempt06/'
expected={prefix+r['path']:r for r in manifest['selected_files']}
with zipfile.ZipFile(a) as z:
 names=z.namelist();assert len(names)==len(set(names));assert set(names)==set(expected)|{'SOURCE_SELECTION_MANIFEST.json'}
 assert sum(i.file_size for i in z.infolist())<16*1024**2
 for i in z.infolist():
  p=PurePosixPath(i.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
  assert not stat.S_ISLNK(i.external_attr>>16)
  data=z.read(i)
  if i.filename in expected:
   e=expected[i.filename];assert len(data)==e['bytes'];assert hashlib.sha256(data).hexdigest()==e['sha256']
  else:assert data==m.read_bytes()
  out=target/i.filename;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
pyfiles=list(target.rglob('*.py'));errors=[]
for p in pyfiles:
 try:compile(p.read_bytes(),str(p),'exec')
 except Exception as e:errors.append({'file':str(p.relative_to(target)),'error':str(e)})
res={'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'selected_file_count':len(expected),'selected_file_hashes_verified':True,'python_files_static_compiled':len(pyfiles),'compile_errors':errors,'elapsed_seconds':time.monotonic()-t0,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'disk_free_bytes_after':shutil.disk_usage(base).free,'runtime_imports_or_model_execution':False}
(base/'verification.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
