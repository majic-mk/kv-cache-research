import json,os,resource,shutil,signal,subprocess,sys,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(60,60))
b=Path(__file__).resolve().parent;here=b/'compact_contract/KV_Revision_Heldout_Preparation_20261004/research/reconstructed/revision_heldout_compact_contract_20261004';out=b/'compact_check_01';assert not out.exists()
assert shutil.disk_usage(b).free>=5_000_000_000
command=[sys.executable,'-B','check_model_free.py','--output',str(out)]
env={**os.environ,'PYTHONPATH':'','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','CUDA_VISIBLE_DEVICES':'','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','TMPDIR':str(b/'compact_tmp')};Path(env['TMPDIR']).mkdir()
start=time.monotonic();peak=0;free=shutil.disk_usage(b).free;stop=None
with (b/'compact_runner.stdout').open('w') as stdout,(b/'compact_runner.stderr').open('w') as stderr:
 proc=subprocess.Popen(command,cwd=here,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 while proc.poll() is None:
  records={}
  for p in Path('/proc').glob('[0-9]*/stat'):
   try:f=p.read_text().rsplit(')',1)[1].split();records[int(p.parent.name)]=(int(f[1]),int(f[21])*os.sysconf('SC_PAGE_SIZE'))
   except (OSError,IndexError,ValueError):pass
  ids={proc.pid};prev=None
  while ids!=prev:prev=ids.copy();ids|={pid for pid,(parent,rss) in records.items() if parent in ids}
  rss=sum(records[pid][1] for pid in ids|{os.getpid()} if pid in records);peak=max(peak,rss);free=min(free,shutil.disk_usage(b).free)
  if rss>=1024**3:stop='RSS_1GIB'
  elif free<5_000_000_000:stop='DISK_FLOOR_5GB'
  elif time.monotonic()-start>=53:stop='WALL_53S_STOP_WITHIN_OVERALL_60S'
  if stop:os.killpg(proc.pid,signal.SIGKILL);break
  time.sleep(.01)
 rc=proc.wait()
r={'returncode':rc,'elapsed_seconds':time.monotonic()-start,'sampled_tree_peak_rss_bytes_including_supervisor':peak,'disk_free_min_bytes':free,'stop_reason':stop,'automatic_retries':0,'command':['python','-B','check_model_free.py','--output','<fresh exclusive output directory>'],'source_edits':False,'model_calls':0,'installs':0,'downloads':0,'provider_actions':0}
if (out/'result.json').exists():r['preserved_runner_receipt']=json.loads((out/'result.json').read_text())
(b/'COMPACT_TEST_RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print((b/'compact_runner.stderr').read_text());print((out/'tests.log').read_text()[-5000:])
