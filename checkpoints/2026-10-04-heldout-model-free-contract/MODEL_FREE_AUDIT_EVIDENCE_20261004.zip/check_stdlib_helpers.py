import hashlib,json,resource,sys,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));sys.dont_write_bytecode=True
base=Path(__file__).resolve().parent;target=base/'assembled/research/reconstructed/revision_temporal_scope_diagnostic_20261004'
allowed={'actual_common','file_pager','cpu_release','decode_contract','actual_guard'}
class SafeImports:
 def find_spec(self,fullname,path=None,target=None):
  if fullname.partition('.')[0] not in sys.stdlib_module_names|allowed:raise ImportError('Non-stdlib import forbidden by audit: '+fullname)
sys.meta_path.insert(0,SafeImports());sys.path.insert(0,str(target))
from actual_common import load_protocol,load_row,source_integrity,acquisition_anchor,load_reference_prefix,ROOT
from decode_contract import MAX_SELECTIONS,selection_action
from actual_guard import process_tree_rss
p=load_protocol();row=load_row(p);source=source_integrity();anchor=acquisition_anchor(ROOT/'outputs/revision_cpu_model_assets_20261004/acquisition_start.json')
groups=['exact_protocol_hash','all_eight_attempt06_source_hashes','sixteen_parent_ID_hashes_and_diagnostic_input_boundary_proof','unchanged_historical_acquisition_anchor']
fixtures=[]
for eos_index in (None,0,100,799):
 emitted=fed=0
 for index in range(MAX_SELECTIONS):
  action=selection_action(index,151645 if index==eos_index else index%100)
  emitted+=action['emit_token'];fed+=action['feed_token']
  if action['stop']:break
 assert index+1==(800 if eos_index is None else eos_index+1)
 assert emitted==fed==(799 if eos_index is None else eos_index)
 assert action['eos_selected']==(eos_index is not None)
 fixtures.append({'eos_index':eos_index,'selected':index+1,'emitted':emitted,'fed':fed})
groups.append('four_author_EOS_exhaustion_fixtures')
assert process_tree_rss({17:(1,100),18:(17,200)},17)==300
try:process_tree_rss({},999999)
except ValueError:pass
else:raise AssertionError('Missing child admitted')
groups.append('process_tree_accounting_and_missing_child_refusal')
try:load_reference_prefix(p)
except FileNotFoundError as e:reference={'status':'BLOCKED_EXPECTED_DECLARED_EXTERNAL_RAW_DEPENDENCY','missing_path':str(Path(e.filename).relative_to(ROOT))}
else:raise AssertionError('Unexpected available raw references')
assert 'torch' not in sys.modules
print(json.dumps({'status':'PASS_LIMITED_STDLIB_HELPERS','groups':groups,'source_manifest_sha256':source,'diagnostic_tokens':len(row['canonical_token_ids']),'decode_fixtures':fixtures,'reference_check':reference,'torch_imported':False,'model_calls':0},indent=2))
