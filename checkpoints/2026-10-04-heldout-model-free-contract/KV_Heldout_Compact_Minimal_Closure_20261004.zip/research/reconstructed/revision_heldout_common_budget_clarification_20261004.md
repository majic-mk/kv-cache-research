# Prospective heldout pilot common history budget

Date: 2026-10-04 UTC. Design clarification only. No model execution, runtime changes or execution authorization.

## Frozen decision

Use **B=1,024 rows per layer and KV head, with zero post-history-call slack S=0 for all six compressed arms**. Static TRIM uses `buffer_size=1`, `sliding_window_size=0`, and the existing single-step scoring rule. Last-N and random use the same history-call eviction boundaries and B. This is a **declared common-budget adaptation of the released static TRIM policy**, not an untouched author reproduction.

This additive clarification supersedes only the 128-token trigger-buffer choice and resulting unequal-slack statement in `revision_heldout_success_branch_recommendation_20261004.md` (SHA-256 `2014cf9c99a93826b354507df00fa42a4cd4e5e2114db94833fcd9af3e869bf5`). That recommendation remains byte-identical. The two-family/eight-input cohort, task wording, outcome rubric, eight arms, maximum 64 answer generations and conservative go/no-go rule remain as frozen. No heldout model outputs informed this decision. The original sixteen-input packet remains closed.

## Reason for the choice

The pinned static release config specifies `buffer_size=128`. The source compresses when resident length is at least `memory_size + buffer_size`, then retains exactly B rows. Consequently the maximum post-call extra occupancy is **127**, not 128; the trigger gap is 128. It is not a protected window. Native-buffer online TRIM can reach the query with B through B+127 rows, while deferred selection has exactly B. Those extra rows vary with chunk boundaries and can change the interpretation of placement effects.

A forced final crop alone would equalize query-entry length while retaining unequal intermediate history capacity. The smallest causal pilot instead fixes the complete online history-boundary budget. Source-supported `buffer_size=1` triggers exactly when resident length exceeds B. It changes the released default's eviction frequency and can change its outputs and cost. The adaptation must be visible in every results label and methods description. No native-buffer sensitivity arm or sweep is added to this pilot; source-only accounting for that alternative is permissible.

Source evidence: `revision_baseline_contracts_20261004/sources/trimkv_cache_utils.py`, `TrimKVCache.compress`, especially the trigger, score and chronological top-k gather; SHA-256 `bb3013d5ff53a8264218b48bafa513c608ad3919d2c6d4172fb248a8b656cae5`. Release config SHA-256 `8c3482ca125ccc2c0b5319b3bf9c02d319afc2e8198b0fe0f44fbecfff88d7f0`. Source revision `49d2a2951ba12e6431a3986b418ee791b209d7c2`; gate revision `89112809f83d05c3058eadcab4104abde5721b81`.

## Exact history and query boundary

1. All arms ingest the identical frozen canonical history partitions, each at most 128 tokens. An online call attends to its resident past plus the complete current chunk. After the complete model forward, crop each layer/head to B if resident length exceeds B. Otherwise retain every row. The post-call length is therefore `min(seen_history_tokens, B)` at every history boundary. Preserve the score formula, released gate weights, original-position maps and chronological K/V gathers; no replay or recovery of evicted K/V is allowed.
2. Each deferred arm ingests the same history partitions without eviction, then applies its policy once at the exact history/query seam to retain B rows. It has a Full-history ingestion peak. It is a deferred-selection diagnostic with a larger ingestion-memory allowance, not an equal-peak-memory serving competitor.
3. The final online crop is the ordinary crop after the last history call, not an additional selection using the question. At query entry, all six compressed arms contain exactly 1,024 history rows per layer/head. Native Full and gate-loaded no-crop retain all history rows.
4. **Freeze selection after the history seam for every compressed arm.** Append all final-query and actually fed output tokens without further eviction; charge their storage. B is a retained-history budget, not a strict end-to-end 1,024-row resident bound. Earlier wording about post-call S=0 refers only to history ingestion.
5. The Negroni history has 8,420 tokens and 82 canonical history partitions; its complete query suffix has 80 tokens. The book history has 6,905 tokens and 73 history partitions; its suffix has 71 tokens. The rendered review's 84/75 `all_input_calls` are metadata partition counts including the final user message and assistant header, not executed model-call counts. They cannot be used to infer an additional query forward or eviction operation. The future execution contract must explicitly bind its common suffix-feed schedule; these serialization boundaries do not authorize extra selection.

The frozen input SHA-256 remains `b7c95c4d2cf6429e5306702e571a593d5ab6e6e82708bbd743208d368996a753`. The rendered review remains `98c4a94a2b2f10bd19e239513a1db6bf377eb6e0ddadd68674f6f1e7c113c23c`. No prompt or canonical ID is altered.

## Estimand and resource claims

The primary outcome and contrast remain the prespecified placement interaction in relevant-minus-peer obsolete-answer errors, online minus deferred under static TRIM. The claim is limited to this **history-only, zero-slack budget adaptation**. The regime contrast includes different survivor choices and different later hidden states/gates induced by irreversible history eviction. It does not isolate a unique representation mechanism or estimate released-default TRIM performance.

At a history append, online logical resident KV occupancy is at most B+C, at most 1,152 rows for C=128, before eviction. Old tensors, concatenated tensors, gathered tensors and allocator reservations can coexist; B+C is not a physical-byte peak bound. At equal numbers of fed suffix tokens the compressed arms have equal KV row counts, but gate/score/position metadata and temporary allocations still differ. Different answer lengths also give different terminal storage.

At query completion, compressed resident lengths are 1,104 and 1,095. Under the unchanged author rule of at most 800 selections and 799 emitted/fed tokens, their maximum lengths are 1,903 and 1,894. EOS and cap-discarded tokens are not fed. Batch-one native BF16 KV payload is 147,456 bytes per row across all 36 layers and 8 KV heads: 150,994,944 bytes at B, before gate state, scores, position maps, model weights, activations and allocator costs. Record actual payload, allocated/reserved GPU memory, host memory/backing, transient peaks, transfers, and all selector/gather/evidence costs. Unmeasured values remain unknown.

The earlier source audit's caveats remain: reservoir placement crosses value/completion-echo recency boundaries, not the earlier reporting-date headers. At far placement, the last 1,024 history rows are entirely reservoir rows; predictable Last-N source-row loss is not by itself a revision-specific empirical finding. Report date accuracy separately from the primary obsolete-value event.

## Admission boundary

A later implementation must assert the exact history/query seam, online post-history lengths, deferred pre/post-selection lengths, original positions and no post-seam crops. It must satisfy the prospectively exact no-crop parity contract without tolerance relaxation. These are future admission requirements, not tests executed by this clarification.

GPU execution still requires a separately accepted practical cost/runtime proposal and verified resource control. No additional CPU sweep, model ladder, native-slack rescue, code change, provider action or run is authorized here. A positive limited pilot would still not establish publication novelty.
