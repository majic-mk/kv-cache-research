"""Own pure-stdlib port of pinned author select/check/append ordering."""
MAX_SELECTIONS=800
EOS_TOKEN_IDS=frozenset({151645})
def selection_action(index,token_id):
    if not (type(index) is int and 0<=index<MAX_SELECTIONS and type(token_id) is int and 0<=token_id<151936):
        raise ValueError('Selection index/token outside frozen contract')
    eos=token_id in EOS_TOKEN_IDS
    last=index==MAX_SELECTIONS-1
    stop=eos or last
    return dict(selection_index=index,selected_token_id=token_id,eos_selected=eos,final_iteration=last,
                emit_token=not stop,feed_token=not stop,stop=stop,
                stop_reason='EOS' if eos else ('SELECTION_LIMIT' if last else None))

def selected_prefix_check(index,token_id,expected_ids):
    if index>=len(expected_ids):return None
    return dict(selection_index=index,expected_token_id=expected_ids[index],actual_token_id=token_id,
                passed=token_id==expected_ids[index])
