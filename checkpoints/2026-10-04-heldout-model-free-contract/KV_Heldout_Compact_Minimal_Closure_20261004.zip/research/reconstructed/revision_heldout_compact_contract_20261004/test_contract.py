import copy
import json
import struct
import unittest
from pathlib import Path

from common import ContractError, canonical, file_hash, sha, strict_json
import decode
import maps
import parity
import plan

P = Path(__file__).resolve().parent

def i64(values):
    return b''.join(struct.pack('<q', x) for x in values)

def bits(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]

def selection(index, token=42, **kwargs):
    return decode.encode_selection(index, token, bits(0.5), bits(-0.69314718), 0x3f80, 82 + index, **kwargs)

def map_fixture(values, seen=10, candidates=10):
    return maps.encode_map(i64(values), [1, 1, 1, len(values)], seen_position=seen, candidate_count=candidates)

def side(append=1):
    h = sha(b'fixture hash, no tensor')
    return {'vector': parity.tensor_reference('bfloat16', [1, 1, 151936], h), 'append': [{'layer': l, 'k': parity.tensor_reference('bfloat16', [1, 8, append, 128], h), 'v': parity.tensor_reference('bfloat16', [1, 8, append, 128], h)} for l in range(36)]}

class PlanTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = plan.load_inputs()
        cls.cases = plan.fixed_plan(cls.rows)

    def test_frozen_plan_matches(self):
        saved = strict_json((P / 'frozen_plan.json').read_bytes())
        self.assertEqual(saved['protocol_sha256'], file_hash(P / 'protocol.json'))
        self.assertEqual(saved['cases'], self.cases)
        self.assertEqual(saved['input_schedules'], {r['variant_id']: plan.schedule(r) for r in self.rows})
        self.assertEqual(saved['crop_schedules'], {a: {r['variant_id']: plan.crop_schedule(r, a) for r in self.rows} for a in plan.ARMS})

    def test_final_source_freeze(self):
        import freeze_source
        freeze_source.verify()

    def test_source_dependencies_unchanged(self):
        for reference in plan.load_protocol()['source_dependencies']:
            path = P.parent / reference['path']
            self.assertEqual(path.stat().st_size, reference['bytes'])
            self.assertEqual(file_hash(path), reference['sha256'])

    def test_exact_work_envelope(self):
        self.assertEqual(len(self.cases), 64)
        self.assertEqual([c['arm'] for c in self.cases[::8]], list(plan.ARMS))
        self.assertEqual(sum(len(plan.schedule(r)) + 799 for r in self.rows) * 8, 56160)
        crops = sum(len(plan.crop_schedule(r, a)) for a in plan.ARMS for r in self.rows)
        self.assertEqual(crops, 1644)
        self.assertEqual(crops * 36 * 8 * 1024 * 2, 969670656)
        self.assertLess(1644 * (36 * 8 * 1024 * 2 + maps.MAX_HEADER + 12), 1000000000)
        self.assertEqual(parity.PAIR_BYTES * 7020, 33190560)
        self.assertEqual(decode.RECORD.size * 51200, 1638400)

    def test_complete_suffix_once(self):
        for row in self.rows:
            queries = [c for c in plan.schedule(row) if c['phase'] == 'query']
            self.assertEqual(len(queries), 1)
            self.assertEqual(queries[0]['start'], row['history_tokens'])
            self.assertEqual(queries[0]['end'], row['total_input_tokens'])
            self.assertIn(queries[0]['end'] - queries[0]['start'], (80, 71))

    def test_all_full_wrong_is_noop(self):
        outcomes = [{'case_index': c['case_index'], 'arm': c['arm'], 'variant_id': c['variant_id'], 'numerical_checks_passed': True, 'semantic': 'Full-wrong/generic-error', 'status': 'SELECTION_LIMIT'} for c in self.cases]
        result = plan.outcome_admission(self.cases, outcomes)
        self.assertIs(result['retained_outcomes'], outcomes)
        self.assertEqual(result['case_indices'], list(range(64)))
        self.assertFalse(result['semantic_cohort_gate'])
        self.assertFalse(result['numerical_stop_required'])
        self.assertFalse(result['execution_authorized'])

    def test_numerical_failure_retains_denominator(self):
        c = self.cases[0]
        result = plan.outcome_admission(self.cases, [dict(c, numerical_checks_passed=False)])
        self.assertTrue(result['numerical_stop_required'])
        self.assertEqual(result['denominator_cases'], 64)
        self.assertEqual(len(result['retained_outcomes']), 1)

    def test_replacement_and_duplicates_rejected(self):
        with self.assertRaises(ContractError):
            plan.fixed_plan(self.rows[:-1])
        c = dict(self.cases[0], numerical_checks_passed=True)
        with self.assertRaises(ContractError):
            plan.outcome_admission(self.cases, [c, c])

    def test_altered_plan_and_input_rejected(self):
        rows = copy.deepcopy(self.rows)
        rows[0]['canonical_token_ids'][0] += 1
        with self.assertRaises(ContractError):
            plan.fixed_plan(rows)
        cases = copy.deepcopy(self.cases)
        cases[0]['variant_id'] = 'replacement'
        with self.assertRaises(ContractError):
            plan.outcome_admission(cases, [])

    def test_numeric_alias_plan_rejected(self):
        cases = copy.deepcopy(self.cases)
        cases[0]['case_index'] = False
        with self.assertRaises(ContractError):
            plan.outcome_admission(cases, [])

    def test_random_exact_pinned_key(self):
        import hashlib
        expected = int.from_bytes(hashlib.sha256(b'revision-pilot-priority-v1\0' + struct.pack('<QQQQ', 1701, 3, 2, 41)).digest()[:8], 'little', signed=True)
        self.assertEqual(plan.priority(3, 2, 41), expected)

    def test_paired_random_and_recency(self):
        for policy in ('recency', 'random'):
            online = []
            for start in range(0, 120, 10):
                online = plan.control_selection(online + list(range(start, start + 10)), policy, layer=2, head=1, budget=7)
            self.assertEqual(online, plan.control_selection(list(range(120)), policy, layer=2, head=1, budget=7))

    def test_execution_locked(self):
        for args in ((), ('approved',)):
            with self.assertRaisesRegex(RuntimeError, 'EXECUTION_LOCKED'):
                plan.execute(*args)

class DecodeTests(unittest.TestCase):
    def test_32byte_exact_bits(self):
        raw = selection(0)
        self.assertEqual(len(raw), 32)
        decoded = decode.decode_selection(raw)
        self.assertEqual(decoded['selected_probability_fp32_le_bits'], bits(0.5))
        self.assertEqual(decoded['selected_logit_bf16_le_bits'], 0x3f80)

    def test_selection_forward_binding_short_and_long(self):
        for case, call in ((0, 82), (4, 73), (63, 73)):
            raw = decode.encode_selection(0, decode.EOS, bits(.5), bits(-.69314718), 0x3f80, call)
            decode.encode_answer(case, '', raw, 'EOS')
            bad = decode.encode_selection(0, decode.EOS, bits(.5), bits(-.69314718), 0x3f80, 0)
            with self.assertRaises(ContractError):
                decode.encode_answer(case, '', bad, 'EOS')

    def test_early_eos(self):
        records = selection(0, decode.EOS)
        answer = decode.decode_answer(decode.encode_answer(0, '', records, 'EOS'), records)
        self.assertEqual(answer['emitted_ids'], [])
        self.assertEqual(answer['terminal_discarded_selection']['selected_token_id'], decode.EOS)

    def test_final_eos_precedes_cap(self):
        records = b''.join(selection(i) for i in range(799)) + selection(799, decode.EOS)
        answer = decode.decode_answer(decode.encode_answer(0, 'complete fixture text', records, 'EOS'), records)
        self.assertEqual(len(answer['emitted_ids']), 799)
        self.assertFalse(answer['terminal_discarded_selection']['cap'])

    def test_full_cap_discard(self):
        records = b''.join(selection(i) for i in range(800))
        answer = decode.decode_answer(decode.encode_answer(0, 'complete', records, 'SELECTION_LIMIT'), records)
        self.assertEqual(len(answer['selected_ids']), 800)
        self.assertEqual(len(answer['fed_ids']), 799)
        self.assertFalse(answer['terminal_discarded_selection']['emitted'])

    def test_censored_partial_flags_preserved(self):
        records = selection(0, emitted=True, fed=False)
        answer = decode.decode_answer(decode.encode_answer(1, 'partial', records, 'RESOURCE_CENSORED', 'resource guard'), records)
        self.assertEqual(answer['emitted_ids'], [42])
        self.assertEqual(answer['fed_ids'], [])

    def test_zero_selection_failure(self):
        raw = decode.encode_answer(0, '', b'', 'FAILED', 'failure before selection')
        self.assertEqual(decode.decode_answer(raw, b'')['selection_count'], 0)

    def test_nonfinite_probability_and_bf16(self):
        for prob, logprob, bf16 in [(0, bits(-1), 0x3f80), (bits(float('nan')), bits(-1), 0x3f80), (bits(.5), bits(1), 0x3f80), (bits(.5), bits(-1), 0x7f80)]:
            with self.assertRaises(ContractError):
                decode.encode_selection(0, 42, prob, logprob, bf16, 1)

    def test_bad_ranges(self):
        for index, token in [(-1, 1), (800, 1), (True, 1), (1, 151936), (1, -1)]:
            with self.assertRaises(ContractError):
                selection(index, token)

    def test_terminal_emit_and_flags_rejected(self):
        with self.assertRaises(ContractError):
            selection(799, emitted=True)
        corrupt = bytearray(selection(0)); corrupt[16] |= 4
        with self.assertRaises(ContractError):
            decode.decode_selection(bytes(corrupt))

    def test_truncation_and_terminal_state(self):
        with self.assertRaises(ContractError):
            decode.decode_selection(selection(0)[:-1])
        with self.assertRaises(ContractError):
            decode.encode_answer(0, '', selection(0, decode.EOS), 'SELECTION_LIMIT')
        with self.assertRaises(ContractError):
            decode.encode_answer(0, '', selection(0, decode.EOS) + selection(1), 'FAILED', 'after EOS')

    def test_complete_text_hash_and_ids(self):
        records = selection(0) + selection(1, decode.EOS)
        raw = decode.encode_answer(0, '完整答案\nnot truncated', records, 'EOS')
        answer = strict_json(raw); answer['raw_answer'] += '!'
        with self.assertRaises(ContractError):
            decode.decode_answer(canonical(answer), records)
        with self.assertRaises(ContractError):
            decode.decode_answer(raw, selection(0, 43) + selection(1, decode.EOS))

class MapTests(unittest.TestCase):
    def test_lossless_order_shape_dtype(self):
        values = [8, 1, 7]
        raw = map_fixture(values)
        header, source = maps.decode_map(raw)
        self.assertEqual(source, i64(values))
        self.assertEqual(header['source_dtype'], 'int64')
        self.assertEqual(header['source_shape'], [1, 1, 1, 3])
        self.assertEqual(header['compact_bytes'], 6)

    def test_upper_bound(self):
        raw = map_fixture([0, 8419], seen=8420, candidates=8420)
        self.assertEqual(maps.decode_map(raw)[1], i64([0, 8419]))

    def test_negative_overflow_unseen(self):
        for values in ([-1], [8420], [65536], [2**63 - 1]):
            with self.assertRaises(ContractError):
                map_fixture(values, seen=8420, candidates=8420)
        with self.assertRaises(ContractError):
            map_fixture([0], seen=65537, candidates=65537)

    def test_invalid_shape_and_length(self):
        for shape in ([0], [-1], [True], [36, 8, 1025], [1] * 5):
            with self.assertRaises(ContractError):
                maps.encode_map(b'', shape, seen_position=10, candidate_count=10)
        with self.assertRaises(ContractError):
            maps.encode_map(b'123', [1], seen_position=10, candidate_count=10)

    def test_truncation_hash_corruption_and_trailing(self):
        raw = map_fixture([1, 2, 3])
        for bad in (raw[:-1], raw + b'x', raw[:-2] + b'\x04\x00'):
            with self.assertRaises(ContractError):
                maps.decode_map(bad)

    def test_dtype_tamper(self):
        raw = map_fixture([1, 2, 3])
        with self.assertRaises(ContractError):
            maps.decode_map(raw.replace(b'"int64"', b'"int32"'))

    def test_paired_order_equality(self):
        a = map_fixture([1, 2, 3]); b = map_fixture([1, 2, 3], candidates=9)
        self.assertTrue(maps.paired_maps_equal(a, b)['equal'])
        self.assertFalse(maps.paired_maps_equal(a, map_fixture([3, 2, 1]))['equal'])

    def test_all_layer_head_map_transition_no_recovery(self):
        first = maps.encode_map(i64(list(range(6, 1030)) * (36 * 8)), [36, 1, 8, 1024], seen_position=1030, candidate_count=1030)
        crop = {'phase': 'history', 'seen': 1030, 'candidate_count': 1030, 'retained_count': 1024}
        self.assertTrue(maps.validate_production_map(first, crop)['passed'])
        second = maps.encode_map(i64(list(range(16, 1040)) * (36 * 8)), [36, 1, 8, 1024], seen_position=1040, candidate_count=1034)
        crop.update(seen=1040, candidate_count=1034)
        self.assertTrue(maps.validate_production_map(second, crop, first, 1030)['passed'])
        bad_values = [1] + list(range(17, 1040))
        bad = maps.encode_map(i64(bad_values * (36 * 8)), [36, 1, 8, 1024], seen_position=1040, candidate_count=1034)
        with self.assertRaises(ContractError):
            maps.validate_production_map(bad, crop, first, 1030)
        crop['phase'] = 'query'
        with self.assertRaises(ContractError):
            maps.validate_production_map(second, crop, first, 1030)

class ParityTests(unittest.TestCase):
    def encode(self, a=None, b=None, checks=None):
        return parity.encode_pair(0, 0, 'history', 0, 1, sha(b'input IDs'), a or side(), b or side(), checks or {k: True for k in parity.CHECKS})

    def test_exact_references_not_raw_proofs(self):
        raw = self.encode(); value = parity.decode_pair(raw)
        self.assertEqual(len(raw), 4728)
        self.assertTrue(value['passed'])
        self.assertFalse(value['raw_vectors_archived'])
        self.assertFalse(value['raw_KV_archived'])
        self.assertFalse(value['independent_argmax_recomputable'])
        self.assertEqual(len(value['native']['append']), 36)

    def test_mismatch_preserved_as_failure(self):
        other = side(); other['append'][35]['v']['raw_tensor_bytes_sha256'] = sha(b'different')
        value = parity.decode_pair(self.encode(b=other))
        self.assertFalse(value['passed'])
        self.assertNotEqual(value['native'], value['no_crop'])

    def test_answer_pair_case_identity(self):
        records = selection(0, decode.EOS)
        native = strict_json(decode.encode_answer(0, '', records, 'EOS'))
        no_crop = strict_json(decode.encode_answer(8, '', records, 'EOS'))
        self.assertTrue(parity.answer_pair_receipt(native, no_crop)['passed'])
        with self.assertRaises(ContractError):
            parity.answer_pair_receipt(native, native)

    def test_runtime_receipt_failure_preserved(self):
        checks = {k: True for k in parity.CHECKS}; checks['causal_mask_passed'] = False
        self.assertFalse(parity.decode_pair(self.encode(checks=checks))['passed'])

    def test_shape_and_layer_omission(self):
        for change in ('shape', 'missing', 'order'):
            other = side()
            if change == 'shape': other['vector']['shape'] = [1, 151936]
            if change == 'missing': other['append'].pop()
            if change == 'order': other['append'].reverse()
            with self.assertRaises(ContractError):
                self.encode(b=other)

    def test_truncation_and_schedule_mismatch(self):
        with self.assertRaises(ContractError):
            parity.decode_pair(self.encode()[:-1])
        with self.assertRaises(ContractError):
            parity.validate_call_pair(self.encode(), {'phase':'history','start':0,'end':2,'ids_sha256':sha(b'input IDs')}, 0, 0)

class StrictJSONTests(unittest.TestCase):
    def test_duplicate_and_nonfinite(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(ContractError):
                strict_json(raw)


class ReceiptTests(unittest.TestCase):
    def test_hash_bound_receipt(self):
        import receipts
        r = receipts.hash_bound_receipt('fixture', {'value': 3})
        self.assertEqual(receipts.verify_receipt(r), {'value': 3})
        r['payload']['value'] = 4
        with self.assertRaises(ContractError):
            receipts.verify_receipt(r)

    def test_exact_call_schedule_and_extra_query_rejected(self):
        import receipts
        row = plan.load_inputs()[0]
        calls = [{'call_index': i, **x} for i, x in enumerate(receipts.expected_calls(row, [42]))]
        records = selection(0) + selection(1, decode.EOS)
        answer = decode.encode_answer(0, 'fixture', records, 'EOS')
        receipts.validate_call_schedule(row, answer, records, calls, complete=True)
        altered = copy.deepcopy(calls); altered[-1]['ids_sha256'] = sha(canonical([43]))
        with self.assertRaises(ContractError):
            receipts.validate_call_schedule(row, answer, records, altered, complete=True)
        with self.assertRaises(ContractError):
            receipts.validate_call_schedule(row, answer, records, calls + [calls[-1]], complete=True)
        with self.assertRaises(ContractError):
            receipts.validate_call_schedule(row, answer, records, calls[:-1], complete=True)

    def test_map_inventory_missing_is_explicit(self):
        import receipts
        row = plan.load_inputs()[0]
        receipt = receipts.map_inventory(row, 'trim_online', [], complete=False)
        self.assertGreater(receipt['payload']['missing_map_count'], 0)
        with self.assertRaises(ContractError):
            receipts.map_inventory(row, 'trim_online', [], complete=True)
        receipts.map_inventory(row, 'full', [], complete=True)

    def test_cost_overhead_required(self):
        import receipts
        timings = {name: 0 for name in receipts.TIMING_FIELDS}
        counters = {name: 0 for name in receipts.COUNTER_FIELDS}
        resources = {name: 0 for name in receipts.RESOURCE_FIELDS}
        receipts.measured_cost_receipt(timings, counters, resources)
        del timings['normalization_seconds']
        with self.assertRaises(ContractError):
            receipts.measured_cost_receipt(timings, counters, resources)

    def test_immutability_mismatch_recorded(self):
        import receipts
        before = {name: sha(b'fixture') for name in ('base_parameters','gate_parameters','runtime_source','input_packet','contract_source')}
        after = dict(before, gate_parameters=sha(b'changed'))
        self.assertFalse(receipts.immutability_receipt(before, after)['payload']['unchanged'])

class FileCodecRoundtripTests(unittest.TestCase):
    def test_all_codecs_in_actual_tiny_archive(self):
        import tempfile
        from storage import EvidenceWriter, verify_archive
        records = selection(0) + selection(1, decode.EOS)
        answer = decode.encode_answer(0, 'complete fixture answer', records, 'EOS')
        positions = map_fixture([1, 3, 8])
        pair = parity.encode_pair(0, 0, 'history', 0, 1, sha(b'fixture IDs'), side(), side(), {name: True for name in parity.CHECKS})
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'new_archive'
            with EvidenceWriter(root) as writer:
                for category, name, payload in [('selections','selected.bin',records), ('answers','answer.json',answer), ('maps','positions.bin',positions), ('baseline','parity.bin',pair)]:
                    writer.put(category, name, payload)
                writer.finalize('complete')
            verify_archive(root)
            self.assertEqual(decode.decode_answer((root/'answers/answer.json').read_bytes(), (root/'selections/selected.bin').read_bytes())['raw_answer'], 'complete fixture answer')
            self.assertEqual(maps.decode_map((root/'maps/positions.bin').read_bytes())[1], i64([1,3,8]))
            self.assertTrue(parity.decode_pair((root/'baseline/parity.bin').read_bytes())['passed'])

if __name__ == '__main__':
    unittest.main()
