"""Lossless int64-to-uint16 position map codec with checked, explicit bounds.

This is a CPU byte codec, not a selection implementation or tensor evidence.
"""
import math
import struct
from common import canonical, integer, require, sha, strict_json

MAGIC = b'KVMAP01\0'
MAX_ELEMENTS = 36 * 8 * 1024
MAX_HEADER = 4096

def _shape(shape):
    require(type(shape) in (list, tuple) and 1 <= len(shape) <= 4, 'invalid map rank')
    for dimension in shape:
        integer(dimension, 1, MAX_ELEMENTS, 'shape dimension')
    elements = math.prod(shape)
    require(elements <= MAX_ELEMENTS, 'map element bound exceeded')
    return elements

def encode_map(int64_le_bytes, shape, *, seen_position, candidate_count):
    elements = _shape(shape)
    integer(seen_position, 1, 8420, 'history seen position')
    integer(candidate_count, shape[-1], seen_position, 'candidate count')
    require(type(int64_le_bytes) is bytes and len(int64_le_bytes) == elements * 8, 'int64 source byte length mismatch')
    compact = bytearray(elements * 2)
    for i, (position,) in enumerate(struct.iter_unpack('<q', int64_le_bytes)):
        integer(position, 0, seen_position - 1, 'original history position')
        struct.pack_into('<H', compact, i * 2, position)
    compact = bytes(compact)
    header = {'schema': 'selected_original_position_map_v1', 'source_dtype': 'int64', 'source_byte_order': 'little', 'source_shape': list(shape), 'source_int64_sha256': sha(int64_le_bytes), 'encoding': 'uint16_le', 'compact_sha256': sha(compact), 'seen_position': seen_position, 'candidate_count': candidate_count, 'retained_count': shape[-1], 'elements': elements, 'compact_bytes': len(compact), 'proven_upper_exclusive': seen_position, 'history_global_upper_exclusive': 8420, 'tensor_order': 'C_contiguous'}
    encoded_header = canonical(header)
    require(len(encoded_header) <= MAX_HEADER, 'header too large')
    return MAGIC + struct.pack('<I', len(encoded_header)) + encoded_header + compact

def decode_map(raw):
    require(type(raw) is bytes and raw[:8] == MAGIC and len(raw) >= 12, 'invalid/truncated map magic')
    header_size = struct.unpack_from('<I', raw, 8)[0]
    require(0 < header_size <= MAX_HEADER and len(raw) >= 12 + header_size, 'invalid/truncated map header')
    header = strict_json(raw[12:12 + header_size])
    require(header['source_dtype'] == 'int64' and header['source_byte_order'] == 'little' and header['encoding'] == 'uint16_le', 'dtype/encoding mismatch')
    elements = _shape(header['source_shape'])
    payload = raw[12 + header_size:]
    require(len(payload) == elements * 2, 'map payload truncated or has trailing bytes')
    source = bytearray(elements * 8)
    for i, (position,) in enumerate(struct.iter_unpack('<H', payload)):
        struct.pack_into('<q', source, i * 8, position)
    source = bytes(source)
    require(encode_map(source, header['source_shape'], seen_position=header['seen_position'], candidate_count=header['candidate_count']) == raw, 'map header/hash/source/range mismatch')
    return header, source

def rows_from_map(raw):
    header, source = decode_map(raw)
    values = tuple(x[0] for x in struct.iter_unpack('<q', source))
    size = header['retained_count']
    return header, [values[i:i + size] for i in range(0, len(values), size)]

def validate_production_map(raw, expected_crop, previous_raw=None, previous_seen=0):
    """Validate actual maps against prior survivors plus just-appended history.

    Checks cannot establish gathered K/V contents. Runtime gather/mask/reset
    receipts remain separate, explicitly producer-reported checks.
    """
    header, rows = rows_from_map(raw)
    require(header['source_shape'] == [36, 1, 8, 1024], 'production map must contain all 36 layers and 8 heads')
    require(expected_crop['phase'] in ('history', 'history_seam'), 'no query/decode selection is permitted')
    for key in ('candidate_count', 'retained_count'):
        require(header[key] == expected_crop[key], 'crop count mismatch')
    require(header['seen_position'] == expected_crop['seen'], 'crop boundary mismatch')
    integer(previous_seen, 0, header['seen_position'] - 1, 'previous crop boundary')
    if previous_raw is not None:
        prior_header, prior_rows = rows_from_map(previous_raw)
        require(prior_header['source_shape'] == header['source_shape'] and prior_header['seen_position'] == previous_seen, 'previous survivor map mismatch')
    else:
        require(previous_seen == 0, 'first crop requires complete original candidate prefix')
        prior_rows = [()] * len(rows)
    appended = set(range(previous_seen, header['seen_position']))
    for prior, selected in zip(prior_rows, rows):
        candidates = set(prior) | appended
        require(len(candidates) == header['candidate_count'], 'resident-only candidate count mismatch')
        require(tuple(sorted(set(selected))) == selected, 'map is not unique chronological original positions')
        require(set(selected) <= candidates, 'evicted position was recovered or unseen position selected')
    return {'passed': True, 'map_sha256': sha(raw), 'all_layers_heads_retained': True, 'gathered_KV_bytes_independently_verified': False}

def paired_maps_equal(online_raw, deferred_raw):
    left, a = decode_map(online_raw); right, b = decode_map(deferred_raw)
    require(left['source_shape'] == right['source_shape'] and left['seen_position'] == right['seen_position'], 'paired map geometry mismatch')
    return {'equal': a == b, 'online_map_sha256': sha(online_raw), 'deferred_map_sha256': sha(deferred_raw), 'comparison': 'exact ordered int64 original-position maps, not K/V tensors'}
