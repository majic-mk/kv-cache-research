"""Shared strict, model-free helpers; hashes are integrity bindings, not attestations."""
import hashlib
import json
import re
from pathlib import Path

class ContractError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise ContractError(message)

def integer(value, low, high, name):
    require(type(value) is int and low <= value <= high, f'invalid {name}')
    return value

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(value):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'invalid SHA-256')
    return value

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')

def strict_json(data):
    def pairs(items):
        obj = {}
        for key, value in items:
            require(key not in obj, 'duplicate JSON key')
            obj[key] = value
        return obj
    def constant(value):
        raise ContractError('nonfinite JSON number')
    return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)

def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()
