"""The only runnable check: bounded stdlib contract tests. Never model execution."""
import argparse
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent

def child_limits():
    resource.setrlimit(resource.RLIMIT_AS, (1073741824, 1073741824))
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    signal.alarm(60)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='new exclusive small check-results directory')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    if shutil.disk_usage(HERE).free < 5000000000:
        raise RuntimeError('5,000,000,000-byte disk floor not met')
    output.mkdir(parents=False, exist_ok=False)
    begin = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    with (output / 'tests.log').open('xb') as log:
        try:
            proc = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(HERE), '-p', 'test_*.py', '-v'], cwd=HERE, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=60, preexec_fn=child_limits)
            status, returncode = 'PASSED' if proc.returncode == 0 else 'FAILED', proc.returncode
        except subprocess.TimeoutExpired:
            status, returncode = 'WALL_TIMEOUT', None
    result = {'status': status, 'returncode': returncode, 'evidence_kind': 'model_free_source_contract_tests', 'wall_seconds': time.monotonic() - begin, 'wall_limit_seconds': 60, 'address_space_limit_bytes': 1073741824, 'disk_floor_bytes': 5000000000, 'child_max_rss_bytes': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss * 1024, 'disk_free_after': shutil.disk_usage(HERE).free, 'model_calls': 0, 'provider_actions': 0, 'execution_authorized': False}
    with (output / 'result.json').open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps(result))
    return 0 if status == 'PASSED' else 1

if __name__ == '__main__':
    raise SystemExit(main())
