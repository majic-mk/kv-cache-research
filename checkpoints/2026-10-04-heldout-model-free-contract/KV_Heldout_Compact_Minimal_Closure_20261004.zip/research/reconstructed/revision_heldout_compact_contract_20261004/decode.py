"""Lossless fixed 32-byte selected-token records and complete-answer contracts.

Floating values are supplied as observed bit patterns, never recomputed here.
"""
import math
import struct
from common import canonical, integer, require, sha, strict_json

RECORD = struct.Struct('<HIHIIHHIQ')  # 32 bytes; trailing fields reserved zero
EOS = 151645
VOCAB = 151936

def action(index, token_id):
    integer(index, 0, 799, 'selection index'); integer(token_id, 0, VOCAB - 1, 'token ID')
    eos = token_id == EOS
    stop = eos or index == 799
    return {'eos': eos, 'cap': index == 799 and not eos, 'emit': not stop, 'feed': not stop, 'stop_reason': 'EOS' if eos else ('SELECTION_LIMIT' if stop else None)}

def f32(bits):
    integer(bits, 0, 0xffffffff, 'FP32 bits')
    return struct.unpack('<f', struct.pack('<I', bits))[0]

def encode_selection(index, token_id, probability_bits, log_probability_bits, logit_bf16_bits, forward_call, emitted=None, fed=None):
    expected = action(index, token_id)
    probability = f32(probability_bits); log_probability = f32(log_probability_bits)
    require(math.isfinite(probability) and 0 < probability <= 1, 'invalid selected probability')
    require(math.isfinite(log_probability) and log_probability <= 0, 'invalid selected log probability')
    integer(logit_bf16_bits, 0, 65535, 'BF16 bits')
    require(logit_bf16_bits & 0x7f80 != 0x7f80, 'nonfinite selected BF16 logit')
    integer(forward_call, 0, 881, 'forward call')
    emitted = expected['emit'] if emitted is None else emitted
    fed = expected['feed'] if fed is None else fed
    require(type(emitted) is bool and type(fed) is bool and (not fed or emitted), 'invalid actual emit/feed flags')
    require(not expected['stop_reason'] or not (emitted or fed), 'terminal selection cannot be emitted or fed')
    flags = int(emitted) | int(fed) << 1 | int(expected['eos']) << 2 | int(expected['cap']) << 3
    return RECORD.pack(index, token_id, logit_bf16_bits, probability_bits, log_probability_bits, flags, 0, forward_call, 0)

def decode_selection(raw):
    require(len(raw) == RECORD.size, 'truncated or oversized selected-token record')
    index, token, bf16, prob, logprob, flags, zero, call, reserved = RECORD.unpack(raw)
    require(zero == reserved == 0 and flags & ~15 == 0, 'reserved selection bits changed')
    require(encode_selection(index, token, prob, logprob, bf16, call, bool(flags & 1), bool(flags & 2)) == raw, 'inconsistent stop flags')
    return {'selection_index': index, 'selected_token_id': token, 'selected_probability_fp32_le_bits': prob, 'selected_log_probability_fp32_le_bits': logprob, 'selected_logit_bf16_le_bits': bf16, 'emitted': bool(flags & 1), 'fed': bool(flags & 2), 'forward_call': call, **action(index, token)}

def encode_answer(case_index, raw_answer, records, status, reason=None):
    integer(case_index, 0, 63, 'case index')
    require(type(raw_answer) is str, 'complete raw answer must be text')
    require(type(records) is bytes and len(records) % RECORD.size == 0 and len(records) <= 800 * RECORD.size, 'invalid selection stream length')
    rows = [decode_selection(records[i:i + RECORD.size]) for i in range(0, len(records), RECORD.size)]
    require([r['selection_index'] for r in rows] == list(range(len(rows))), 'missing or repeated selections')
    from plan import load_protocol
    query_call = load_protocol()['inputs']['rows'][case_index % 8]['history_forward_calls']
    require(all(r['forward_call'] == query_call + i for i, r in enumerate(rows)), 'selection forward-call progression changed')
    require(status in ('EOS', 'SELECTION_LIMIT', 'RESOURCE_CENSORED', 'FAILED'), 'invalid answer state')
    require(all(not r['stop_reason'] and r['emitted'] and r['fed'] for r in rows[:-1]), 'selection after terminal or pending feed')
    terminal = rows[-1] if rows and rows[-1]['stop_reason'] else None
    if status in ('EOS', 'SELECTION_LIMIT'):
        require(terminal and terminal['stop_reason'] == status, 'completion state mismatch')
        require(reason is None, 'unexpected censoring reason')
    else:
        require(type(reason) is str and bool(reason), 'failure/censoring reason required')
        require(terminal is None, 'natural EOS/cap must keep its actual terminal state')
    result = {'schema': 'complete_answer_v1', 'case_index': case_index, 'status': status, 'censoring_or_failure_reason': reason, 'raw_answer': raw_answer, 'raw_answer_utf8_sha256': sha(raw_answer.encode()), 'selected_ids': [r['selected_token_id'] for r in rows], 'emitted_ids': [r['selected_token_id'] for r in rows if r['emitted']], 'fed_ids': [r['selected_token_id'] for r in rows if r['fed']], 'terminal_discarded_selection': terminal, 'selection_records_sha256': sha(records), 'selection_count': len(rows), 'text_decode_checked_by_backend': False, 'semantic_cohort_gate': False}
    return canonical(result)

def decode_answer(raw, records):
    value = strict_json(raw)
    expected = encode_answer(value['case_index'], value['raw_answer'], records, value['status'], value['censoring_or_failure_reason'])
    require(raw == expected, 'answer hash/IDs/terminal record mismatch or noncanonical answer')
    return value
