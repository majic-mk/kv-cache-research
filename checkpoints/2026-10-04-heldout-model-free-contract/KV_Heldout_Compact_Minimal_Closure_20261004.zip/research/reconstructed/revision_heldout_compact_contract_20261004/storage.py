"""Bounded, write-once source-contract evidence storage (stdlib only).

This module does not import a model, authorize execution, or certify a runtime.
Budget ceilings concern every retained file's logical byte length, including all
control/index/failure files. Filesystem allocation is checked independently before
mkdir, file creation and every write; a disk guard cannot reserve space against
other processes. No operation follows a symlink. A killed process may leave a
partial file and its durable intent without a failure receipt; no such directory
verifies as a completed archive. Recover by inspection, never by overwriting it.

API: Budget(caps=..., total=..., disk_floor=...) only accepts ceilings at or below
production defaults (the disk floor cannot be lowered). Budget.check(used, added)
supports model-free boundary arithmetic. EvidenceWriter(new_root, budget=None,
evidence_kind='model_free_fixture') accepts immutable bytes via put(category,
name, data), returning a digest/length receipt. finalize(state) accepts complete,
failed, interrupted or resource_censored and returns the final receipt path.
verify_archive(root) verifies only complete archives and returns their receipt.
Close writers with a context manager or close(); closing never implies success.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

PRODUCTION_CAPS = MappingProxyType({
    "maps": 1_000_000_000,
    "baseline": 50_000_000,
    "selections": 2_000_000,
    "answers": 20_000_000,
    "metadata": 256_000_000,
    "sources": 100_000_000,
    "logs": 128_000_000,
    "indexes": 64_000_000,
    "emergency": 20_000_000,
})
TOTAL_CAP = 2_000_000_000
DISK_FLOOR = 5_000_000_000
EVIDENCE_KINDS = frozenset({"model_free_fixture", "source_contract"})
CHUNK = 64 * 1024
_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,119}\Z")
_STATES = frozenset({"complete", "failed", "interrupted", "resource_censored"})


class EvidenceError(ValueError):
    """An evidence/archive contract was violated."""


class BudgetExceeded(EvidenceError):
    pass


class DiskFloorError(EvidenceError):
    pass


class IncompleteArchive(EvidenceError):
    pass


def _integer(value, name):
    if type(value) is not int or value < 0:
        raise EvidenceError(f"{name} must be a nonnegative integer")
    return value


def _json(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=True, allow_nan=False) + "\n").encode("ascii")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise EvidenceError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _parse(data):
    try:
        return json.loads(data, object_pairs_hook=_unique_object,
                          parse_constant=lambda value: (_ for _ in ()).throw(
                              EvidenceError(f"nonfinite JSON: {value}")))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise EvidenceError("invalid control JSON") from exc


@dataclass(frozen=True)
class Budget:
    caps: Mapping[str, int] = field(default_factory=lambda: dict(PRODUCTION_CAPS))
    total: int = TOTAL_CAP
    disk_floor: int = DISK_FLOOR

    def __post_init__(self):
        caps = dict(self.caps)
        if set(caps) != set(PRODUCTION_CAPS):
            raise EvidenceError("caps must specify exactly the production categories")
        for category, value in caps.items():
            if _integer(value, category) > PRODUCTION_CAPS[category]:
                raise EvidenceError(f"cannot enlarge {category} production cap")
        if _integer(self.total, "total") > TOTAL_CAP:
            raise EvidenceError("cannot enlarge production total cap")
        if _integer(self.disk_floor, "disk_floor") < DISK_FLOOR:
            raise EvidenceError("cannot lower production disk floor")
        if caps["emergency"] > self.total:
            raise EvidenceError("emergency reserve exceeds total")
        object.__setattr__(self, "caps", MappingProxyType(caps))

    def check(self, used: Mapping[str, int], added: Mapping[str, int]):
        """Pure ledger preflight. Never allocates the represented payload sizes."""
        if set(used) - set(self.caps) or set(added) - set(self.caps):
            raise EvidenceError("unknown ledger category")
        after = {}
        for category, cap in self.caps.items():
            value = (_integer(used.get(category, 0), "used bytes") +
                     _integer(added.get(category, 0), "added bytes"))
            if value > cap:
                raise BudgetExceeded(f"{category} cap exceeded: {value} > {cap}")
            after[category] = value
        if sum(after.values()) > self.total:
            raise BudgetExceeded("total retained-byte cap exceeded")
        normal = sum(value for category, value in after.items() if category != "emergency")
        if normal > self.total - self.caps["emergency"]:
            raise BudgetExceeded("normal write would consume the emergency reserve")
        return after

    def to_dict(self):
        return {"caps": dict(self.caps), "total": self.total,
                "disk_floor": self.disk_floor}


def _absolute(path):
    raw = os.fspath(path)
    if not isinstance(raw, str) or not raw or "\0" in raw or ".." in raw.split("/"):
        raise EvidenceError("unsafe output path")
    return Path(os.path.abspath(raw))


def _open_dir(path):
    """Walk every component with O_NOFOLLOW, including ancestors."""
    path = _absolute(path)
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                              dir_fd=fd)
            os.close(fd)
            fd = next_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


def _identity(fd):
    info = os.fstat(fd)
    return info.st_dev, info.st_ino


def _free_bytes(fd):
    info = os.fstatvfs(fd)
    return info.f_bavail * info.f_frsize


def _disk_check(fd, length, budget, reserve=0):
    info = os.fstatvfs(fd)
    block = max(info.f_frsize, 4096)
    # Round data allocation up and include an extra block for directory metadata.
    required = ((length + block - 1) // block + 1) * block
    if _free_bytes(fd) - required - reserve < budget.disk_floor:
        raise DiskFloorError("write would cross the free-disk floor/reserve")


def _safe_name(name):
    if not isinstance(name, str) or _NAME.fullmatch(name) is None:
        raise EvidenceError("name must be a simple 1..120 character filename")
    return name


def _hash_file(dirfd, name):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=dirfd)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise EvidenceError("only non-linked regular evidence files are permitted")
        digest = hashlib.sha256()
        length = 0
        while True:
            part = os.read(fd, CHUNK)
            if not part:
                break
            digest.update(part)
            length += len(part)
        after = os.fstat(fd)
        if (before.st_size != length or after.st_size != length or
                before.st_mtime_ns != after.st_mtime_ns or
                before.st_ctime_ns != after.st_ctime_ns):
            raise EvidenceError("file changed while being verified")
        return {"bytes": length, "sha256": digest.hexdigest()}
    finally:
        os.close(fd)


def _inventory(rootfd, dirs):
    if set(os.listdir(rootfd)) != set(PRODUCTION_CAPS):
        raise EvidenceError("unexpected or missing archive directory")
    entries = []
    for category, dirfd in dirs.items():
        named = os.stat(category, dir_fd=rootfd, follow_symlinks=False)
        if not stat.S_ISDIR(named.st_mode) or (named.st_dev, named.st_ino) != _identity(dirfd):
            raise EvidenceError("archive directory was replaced")
        for name in sorted(os.listdir(dirfd)):
            _safe_name(name)
            entry = _hash_file(dirfd, name)
            entry["path"] = f"{category}/{name}"
            entries.append(entry)
    return sorted(entries, key=lambda item: item["path"])


class EvidenceWriter:
    """Single-writer archive. All files and the root are created exclusively.

    put() accepts only bytes, so an expected length/digest is known before I/O.
    Intent and commit indexes are charged along with payloads. On any failed put
    the writer stops; it never retries, truncates, removes, or replaces evidence.
    Catchable failures attempt an emergency receipt. Receipt failure is exposed
    as failure_receipt_error and an exception note, never silently ignored.
    """

    def __init__(self, root, budget=None, evidence_kind="model_free_fixture"):
        if evidence_kind not in EVIDENCE_KINDS:
            raise EvidenceError("only model_free_fixture/source_contract are permitted")
        self.root = _absolute(root)
        self.budget = Budget() if budget is None else budget
        if not isinstance(self.budget, Budget):
            raise EvidenceError("budget must be Budget")
        self.evidence_kind = evidence_kind
        self._fds = {}
        self._rootfd = None
        self._used = dict.fromkeys(PRODUCTION_CAPS, 0)
        self._sequence = 0
        self._stopped = False
        self._finalized = False
        self.failure_receipt_error = None
        parentfd = _open_dir(self.root.parent)
        try:
            _disk_check(parentfd, 0, self.budget, self.budget.caps["emergency"])
            os.mkdir(self.root.name, mode=0o700, dir_fd=parentfd)
            self._rootfd = os.open(self.root.name, os.O_RDONLY | os.O_DIRECTORY |
                                   os.O_NOFOLLOW, dir_fd=parentfd)
            self._root_identity = _identity(self._rootfd)
            for category in PRODUCTION_CAPS:
                _disk_check(self._rootfd, 0, self.budget, self.budget.caps["emergency"])
                os.mkdir(category, mode=0o700, dir_fd=self._rootfd)
                self._fds[category] = os.open(category, os.O_RDONLY | os.O_DIRECTORY |
                                               os.O_NOFOLLOW, dir_fd=self._rootfd)
            contract = self._labels() | {"schema": 1, "budget": self.budget.to_dict(),
                                        "launch_authorized": False}
            self._write("indexes", "contract.json", _json(contract))
            os.fsync(self._rootfd)
        except BaseException as exc:
            # A newly created root is deliberately retained even on startup failure.
            if len(self._fds) == len(PRODUCTION_CAPS):
                self._record_failure(exc, {"operation": "initialize"})
            self.close()
            raise
        finally:
            os.close(parentfd)

    @property
    def used(self):
        return dict(self._used)

    def _labels(self):
        return {"evidence_kind": self.evidence_kind, "contract_kind": "source_contract"}

    def _namespace(self):
        if self._rootfd is None:
            raise EvidenceError("writer is closed")
        fd = _open_dir(self.root)
        try:
            if _identity(fd) != self._root_identity:
                raise EvidenceError("archive root was replaced")
        finally:
            os.close(fd)
        if set(os.listdir(self._rootfd)) != set(PRODUCTION_CAPS):
            raise EvidenceError("unexpected archive root contents")
        for category, dirfd in self._fds.items():
            info = os.stat(category, dir_fd=self._rootfd, follow_symlinks=False)
            if not stat.S_ISDIR(info.st_mode) or (info.st_dev, info.st_ino) != _identity(dirfd):
                raise EvidenceError("archive category was replaced")

    def _write(self, category, name, data):
        """Every retained content byte is charged, even on an interrupted write."""
        self._namespace()
        self.budget.check(self._used, {category: len(data)})
        reserve = (max(0, self.budget.caps["emergency"] - self._used["emergency"])
                   if category != "emergency" else 0)
        dirfd = self._fds[category]
        _disk_check(dirfd, len(data), self.budget, reserve)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=dirfd)
        starting_bytes = self._used[category]
        charged = 0
        try:
            view = memoryview(data)
            while charged < len(data):
                part = view[charged:charged + CHUNK]
                self.budget.check(self._used, {category: len(part)})
                _disk_check(fd, len(part), self.budget, reserve)
                written = os.write(fd, part)
                if written <= 0 or written > len(part):
                    raise OSError("invalid/zero-length OS write")
                charged += written
                self._used[category] += written
            os.fsync(fd)
            if os.fstat(fd).st_size != len(data):
                raise EvidenceError("written length differs from requested length")
        finally:
            # An interrupt may occur after the OS wrote bytes but before accounting.
            actual = os.fstat(fd).st_size
            self._used[category] = starting_bytes + actual
            os.close(fd)
            os.fsync(dirfd)
        result = _hash_file(dirfd, name)
        if result != {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}:
            raise EvidenceError("written hash/length failed read-back verification")

    def _record_failure(self, exc, operation):
        self._stopped = True
        record = self._labels() | {"schema": 1, "status": "failed",
                  "operation": operation, "error_type": type(exc).__name__,
                  "error": str(exc), "retained_bytes": self.used,
                  "partial_files_preserved": True, "launch_authorized": False}
        try:
            self._write("emergency", f"failure{self._sequence:08d}.json", _json(record))
        except BaseException as receipt_exc:
            self.failure_receipt_error = receipt_exc
            if hasattr(exc, "add_note"):
                exc.add_note(f"Failure receipt could not be completed: {receipt_exc!r}; "
                             "all partial files were retained")

    def put(self, category, name, data):
        if self._stopped or self._finalized or self._rootfd is None:
            raise EvidenceError("writer is stopped/finalized/closed")
        if category not in PRODUCTION_CAPS or category in {"indexes", "emergency"}:
            raise EvidenceError("put requires a non-control evidence category")
        _safe_name(name)
        if type(data) is not bytes:
            raise EvidenceError("put requires immutable bytes; implicit conversions are forbidden")
        receipt = self._labels() | {"schema": 1, "sequence": self._sequence,
                   "path": f"{category}/{name}", "bytes": len(data),
                   "sha256": hashlib.sha256(data).hexdigest()}
        intent = _json(receipt | {"status": "intent"})
        commit = _json(receipt | {"status": "complete"})
        sequence = self._sequence
        self._sequence += 1
        try:
            self._namespace()
            # Reject occupied destinations before writing any transaction record.
            try:
                os.stat(name, dir_fd=self._fds[category], follow_symlinks=False)
            except FileNotFoundError:
                pass
            else:
                raise FileExistsError(f"evidence path already exists: {category}/{name}")
            self.budget.check(self._used, {category: len(data),
                                          "indexes": len(intent) + len(commit)})
            _disk_check(self._rootfd, len(data) + len(intent) + len(commit), self.budget,
                        self.budget.caps["emergency"] - self._used["emergency"])
            self._write("indexes", f"tx{sequence:08d}.intent.json", intent)
            self._write(category, name, data)
            self._write("indexes", f"tx{sequence:08d}.commit.json", commit)
            return receipt
        except BaseException as exc:
            self._record_failure(exc, {"operation": "put", "sequence": sequence,
                                       "path": f"{category}/{name}"})
            raise

    def finalize(self, state="complete"):
        if state not in _STATES:
            raise EvidenceError("unknown finalization state")
        if self._finalized or self._rootfd is None:
            raise EvidenceError("writer is finalized/closed")
        if self._stopped and state == "complete":
            raise IncompleteArchive("a stopped writer cannot finalize as complete")
        category = "indexes" if state == "complete" else "emergency"
        try:
            self._namespace()
            entries = _inventory(self._rootfd, self._fds)
            used = dict.fromkeys(PRODUCTION_CAPS, 0)
            for entry in entries:
                used[entry["path"].split("/")[0]] += entry["bytes"]
            if used != self._used:
                raise EvidenceError("retained-byte ledger does not match files")
            payload = self._labels() | {"schema": 1, "state": state,
                      "launch_authorized": False, "budget": self.budget.to_dict(),
                      "accounting_before_final": self.used, "entries": entries}
            envelope = {"payload": payload, "sha256": hashlib.sha256(_json(payload)).hexdigest()}
            self._write(category, "final.json", _json(envelope))
            self._finalized = True
            if state == "complete":
                verify_archive(self.root)
            return self.root / category / "final.json"
        except BaseException as exc:
            self._record_failure(exc, {"operation": "finalize", "state": state})
            raise

    def close(self):
        for fd in self._fds.values():
            os.close(fd)
        self._fds.clear()
        if self._rootfd is not None:
            os.close(self._rootfd)
            self._rootfd = None

    def __enter__(self):
        return self

    def __exit__(self, kind, value, traceback):
        if value is not None and not self._stopped and not self._finalized:
            self._record_failure(value, {"operation": "context_exit"})
        self.close()
        return False


def _read_control(dirs, path, limit):
    category, name = path.split("/")
    _safe_name(name)
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=dirs[category])
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > limit:
            raise EvidenceError("invalid or oversized control file")
        chunks = []
        left = info.st_size
        while left:
            part = os.read(fd, min(left, CHUNK))
            if not part:
                raise EvidenceError("truncated control file")
            chunks.append(part)
            left -= len(part)
        if os.read(fd, 1):
            raise EvidenceError("control file changed while reading")
        return _parse(b"".join(chunks))
    finally:
        os.close(fd)


def verify_archive(root):
    """Verify a completed archive; incomplete/failure archives never pass.

    Hashes provide integrity relative to these receipts, not authentication or
    proof of a model run. Verification streams payloads in 64 KiB chunks.
    """
    rootfd = _open_dir(root)
    dirs = {}
    try:
        for category in PRODUCTION_CAPS:
            dirs[category] = os.open(category, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                     dir_fd=rootfd)
        actual = _inventory(rootfd, dirs)
        by_path = {entry["path"]: entry for entry in actual}
        finals = set(by_path) & {"indexes/final.json", "emergency/final.json"}
        if finals != {"indexes/final.json"}:
            raise IncompleteArchive("archive has no unique successful final receipt")
        envelope = _read_control(dirs, "indexes/final.json", PRODUCTION_CAPS["indexes"])
        if not isinstance(envelope, dict) or set(envelope) != {"payload", "sha256"}:
            raise EvidenceError("invalid final envelope")
        payload = envelope["payload"]
        if envelope["sha256"] != hashlib.sha256(_json(payload)).hexdigest():
            raise EvidenceError("final receipt hash mismatch")
        expected_keys = {"schema", "state", "evidence_kind", "contract_kind", "launch_authorized",
                         "budget", "accounting_before_final", "entries"}
        if not isinstance(payload, dict) or set(payload) != expected_keys:
            raise EvidenceError("invalid final payload")
        if (payload["schema"] != 1 or payload["state"] != "complete" or
                payload["evidence_kind"] not in EVIDENCE_KINDS or
                payload["contract_kind"] != "source_contract" or
                payload["launch_authorized"] is not False):
            raise IncompleteArchive("invalid complete source-contract labels/state")
        budget = Budget(**payload["budget"])
        entries = payload["entries"]
        if not isinstance(entries, list):
            raise EvidenceError("invalid file index")
        expected = {}
        for entry in entries:
            if not isinstance(entry, dict) or set(entry) != {"path", "bytes", "sha256"}:
                raise EvidenceError("invalid file index entry")
            path = entry["path"]
            if not isinstance(path, str) or path.count("/") != 1:
                raise EvidenceError("unsafe indexed path")
            category, name = path.split("/")
            if category not in PRODUCTION_CAPS:
                raise EvidenceError("unknown indexed category")
            _safe_name(name)
            _integer(entry["bytes"], "indexed length")
            if (path in expected or path == "indexes/final.json" or
                    not isinstance(entry["sha256"], str) or
                    re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]) is None):
                raise EvidenceError("duplicate/invalid index entry")
            expected[path] = entry
        if set(by_path) != set(expected) | {"indexes/final.json"}:
            raise EvidenceError("unindexed, missing, or partial archive file")
        used = dict.fromkeys(PRODUCTION_CAPS, 0)
        for path, entry in expected.items():
            if by_path[path] != entry:
                raise EvidenceError(f"hash/length mismatch (possibly truncated): {path}")
            used[path.split("/")[0]] += entry["bytes"]
        if used != payload["accounting_before_final"]:
            raise EvidenceError("archive accounting differs from indexed files")
        budget.check(used, {"indexes": by_path["indexes/final.json"]["bytes"]})
        contract = _read_control(dirs, "indexes/contract.json", PRODUCTION_CAPS["indexes"])
        required_contract = {"schema": 1, "budget": budget.to_dict(), "launch_authorized": False,
                             "evidence_kind": payload["evidence_kind"], "contract_kind": "source_contract"}
        if contract != required_contract:
            raise EvidenceError("archive contract mismatch")
        if any(path.startswith("emergency/") for path in expected):
            raise IncompleteArchive("failure evidence exists in a complete archive")
        intents = {}
        commits = {}
        for path in expected:
            if not path.startswith("indexes/") or path == "indexes/contract.json":
                continue
            match = re.fullmatch(r"indexes/tx(\d{8})\.(intent|commit)\.json", path)
            if match is None:
                raise EvidenceError("unknown index/control file")
            record = _read_control(dirs, path, PRODUCTION_CAPS["indexes"])
            seq, kind = int(match[1]), match[2]
            required = {"schema", "sequence", "path", "bytes", "sha256", "status",
                        "evidence_kind", "contract_kind"}
            if (not isinstance(record, dict) or set(record) != required or
                    type(record["sequence"]) is not int or record["sequence"] != seq or
                    record["schema"] != 1 or record["evidence_kind"] != payload["evidence_kind"] or
                    record["contract_kind"] != "source_contract" or
                    record["status"] != ("intent" if kind == "intent" else "complete")):
                raise EvidenceError("invalid transaction record")
            (intents if kind == "intent" else commits)[seq] = record
        if set(intents) != set(commits) or set(intents) != set(range(len(intents))):
            raise IncompleteArchive("missing transaction intent/commit")
        committed_paths = set()
        for seq, record in intents.items():
            expected_commit = record | {"status": "complete"}
            if commits[seq] != expected_commit:
                raise EvidenceError("intent/commit mismatch")
            path = record["path"]
            if (not isinstance(path, str) or path not in expected or
                    path.split("/")[0] in {"indexes", "emergency"} or path in committed_paths):
                raise EvidenceError("invalid or duplicated committed payload")
            if expected[path] != {"path": path, "bytes": record["bytes"], "sha256": record["sha256"]}:
                raise EvidenceError("transaction expected hash/length differs from archived payload")
            committed_paths.add(path)
        data_paths = {path for path in expected if not path.startswith("indexes/")}
        if data_paths != committed_paths:
            raise IncompleteArchive("payload lacks a complete transaction")
        return payload
    finally:
        for fd in dirs.values():
            os.close(fd)
        os.close(rootfd)
