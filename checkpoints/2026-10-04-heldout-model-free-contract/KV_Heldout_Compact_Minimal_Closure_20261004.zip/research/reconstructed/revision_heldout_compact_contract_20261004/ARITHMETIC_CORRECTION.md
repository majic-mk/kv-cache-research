# Additive evidence-cap arithmetic correction

2026-10-04 UTC. Source-only correction; no policy enlargement or execution authorization.

The frozen feasibility revision 2 report (SHA-256 `d37a1774b14a4c7e3190dfeed73e5725b3d7fa04a12e6bef1d683878aee7e6f5`) lists these decimal-MB category caps:

1000 maps + 50 baseline + 2 selected-token records + 20 answers/IDs + 256 metadata + 100 sources + 128 logs + 64 indexes + 20 emergency = **1640 MB**, not 1740 MB.

The total remains 2,000,000,000 bytes. Headroom is therefore **360,000,000 bytes**, not 260,000,000. Every individual ceiling, including the 20,000,000-byte emergency reserve, remains exactly unchanged. Headroom cannot enlarge a category or add cases.

The parent explicitly confirmed this correction before the final source freeze. The original feasibility report/JSON/freeze are untouched. The first model-free test attempt exposed the erroneous total in its test expectation; `checks_01` preserves the failed result, log, manifest and matching original source snapshot. A separate tiny index-overhead test fixture also required correction; writer limits/accounting were not relaxed.
