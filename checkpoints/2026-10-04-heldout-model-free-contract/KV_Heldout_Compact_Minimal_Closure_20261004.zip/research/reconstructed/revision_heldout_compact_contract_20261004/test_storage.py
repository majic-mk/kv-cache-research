"""Tiny model-free tests; boundary sizes are integer ledgers, never huge writes."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import storage
from storage import (Budget, BudgetExceeded, DISK_FLOOR, DiskFloorError,
                     EvidenceError, EvidenceWriter, IncompleteArchive,
                     PRODUCTION_CAPS, TOTAL_CAP, verify_archive)


def small_budget(**overrides):
    caps = {key: min(value, 100_000) for key, value in PRODUCTION_CAPS.items()}
    caps.update({"maps": 512, "answers": 512, "indexes": 32_768, "emergency": 8_192})
    caps.update(overrides.pop("caps", {}))
    return Budget(caps=caps, total=overrides.pop("total", 262_144), **overrides)


class BudgetTests(unittest.TestCase):
    def test_exact_production_decimal_caps(self):
        self.assertEqual(dict(PRODUCTION_CAPS), {
            "maps": 1_000_000_000, "baseline": 50_000_000,
            "selections": 2_000_000, "answers": 20_000_000,
            "metadata": 256_000_000, "sources": 100_000_000,
            "logs": 128_000_000, "indexes": 64_000_000,
            "emergency": 20_000_000})
        self.assertEqual(TOTAL_CAP, 2_000_000_000)
        self.assertEqual(DISK_FLOOR, 5_000_000_000)
        # The frozen category list sums to 1,640 MB; the report's 1,740 MB
        # prose total is an arithmetic error, not authority to change any cap.
        self.assertEqual(sum(PRODUCTION_CAPS.values()), 1_640_000_000)

    def test_all_category_boundaries_without_allocating_payloads(self):
        budget = Budget()
        for category, cap in PRODUCTION_CAPS.items():
            with self.subTest(category=category):
                self.assertEqual(budget.check({}, {category: cap})[category], cap)
                with self.assertRaises(BudgetExceeded):
                    budget.check({}, {category: cap + 1})
                with self.assertRaises(BudgetExceeded):
                    budget.check({category: cap}, {category: 1})

    def test_total_reserve_with_synthetic_ledger(self):
        budget = Budget(total=1_100_000_000)
        exact = {"maps": 1_000_000_000, "metadata": 80_000_000}
        budget.check(exact, {})
        with self.assertRaisesRegex(BudgetExceeded, "emergency reserve"):
            budget.check(exact, {"metadata": 1})
        # Emergency receipt writes can use their reserved room, normal writes cannot.
        budget.check(exact, {"emergency": 20_000_000})
        with self.assertRaises(BudgetExceeded):
            budget.check(exact | {"emergency": 20_000_000}, {"metadata": 1})

    def test_fixture_cannot_enlarge_caps_or_lower_disk_floor(self):
        for category in PRODUCTION_CAPS:
            with self.subTest(category=category), self.assertRaises(EvidenceError):
                Budget(caps=dict(PRODUCTION_CAPS) | {category: PRODUCTION_CAPS[category] + 1})
        with self.assertRaises(EvidenceError):
            Budget(total=TOTAL_CAP + 1)
        with self.assertRaises(EvidenceError):
            Budget(disk_floor=DISK_FLOOR - 1)
        with self.assertRaises(TypeError):
            Budget().caps["maps"] = 0

    def test_bad_and_boolean_ledgers_rejected(self):
        for value in (-1, 1.5, True, "2"):
            with self.subTest(value=value), self.assertRaises(EvidenceError):
                Budget().check({}, {"maps": value})
        with self.assertRaises(EvidenceError):
            Budget().check({"alien": 0}, {})
        with self.assertRaises(EvidenceError):
            Budget(caps={"maps": 1})


class WriterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="compact-evidence-fixture-")
        self.base = Path(self.temp.name)
        self.root = self.base / "archive"
        self.writer = None

    def tearDown(self):
        if self.writer is not None:
            self.writer.close()
        self.temp.cleanup()

    def make_writer(self, **kwargs):
        self.writer = EvidenceWriter(self.root, budget=kwargs.pop("budget", small_budget()), **kwargs)
        return self.writer

    def completed(self):
        writer = self.make_writer()
        writer.put("maps", "positions.u16", b"\x00\x00\xff\x1f")
        writer.put("answers", "answer.utf8", "complete raw answer \u03bb".encode())
        writer.finalize("complete")
        return writer

    def test_tiny_roundtrip_hash_length_and_all_accounting(self):
        writer = self.completed()
        result = verify_archive(self.root)
        self.assertEqual(result["state"], "complete")
        self.assertEqual(result["evidence_kind"], "model_free_fixture")
        self.assertEqual(result["contract_kind"], "source_contract")
        self.assertIs(result["launch_authorized"], False)
        files = [path for path in self.root.rglob("*") if path.is_file()]
        self.assertEqual(sum(writer.used.values()), sum(path.stat().st_size for path in files))
        self.assertGreater(writer.used["indexes"], 0)
        self.assertEqual(writer.used["emergency"], 0)
        self.assertEqual((self.root / "maps/positions.u16").read_bytes(), b"\x00\x00\xff\x1f")

    def test_labels_allow_only_fixture_or_source_contract(self):
        with self.assertRaises(EvidenceError):
            EvidenceWriter(self.root, evidence_kind="real_model")
        self.assertFalse(self.root.exists())
        writer = self.make_writer(evidence_kind="source_contract")
        writer.finalize()
        self.assertEqual(verify_archive(self.root)["evidence_kind"], "source_contract")

    def test_exclusive_root_never_overwritten(self):
        writer = self.completed()
        original = (self.root / "indexes/final.json").read_bytes()
        with self.assertRaises(FileExistsError):
            EvidenceWriter(self.root)
        self.assertEqual((self.root / "indexes/final.json").read_bytes(), original)
        self.assertEqual(writer.used["emergency"], 0)

    def test_exclusive_payload_and_stopped_writer(self):
        writer = self.make_writer()
        writer.put("maps", "same.bin", b"first")
        with self.assertRaises(FileExistsError):
            writer.put("maps", "same.bin", b"second")
        self.assertEqual((self.root / "maps/same.bin").read_bytes(), b"first")
        self.assertTrue(list((self.root / "emergency").glob("failure*.json")))
        with self.assertRaises(EvidenceError):
            writer.put("answers", "later.txt", b"never written")
        with self.assertRaises(IncompleteArchive):
            writer.finalize("complete")

    def test_path_traversal_and_control_categories_rejected(self):
        writer = self.make_writer()
        for name in ("../escape", "/escape", "a/b", "..", ".", "", "x" * 121):
            with self.subTest(name=name), self.assertRaises(EvidenceError):
                writer.put("maps", name, b"x")
        for category in ("indexes", "emergency", "../maps", "unknown"):
            with self.subTest(category=category), self.assertRaises(EvidenceError):
                writer.put(category, "x", b"x")
        for data in (bytearray(b"x"), memoryview(b"x"), "x", iter([b"x"])):
            with self.assertRaises(EvidenceError):
                writer.put("maps", "x", data)
        with self.assertRaises(EvidenceError):
            EvidenceWriter(str(self.base) + "/../escape")

    def test_symlink_ancestor_rejected(self):
        alias = self.base / "alias"
        alias.symlink_to(self.base, target_is_directory=True)
        with self.assertRaises(OSError):
            EvidenceWriter(alias / "archive")
        self.assertFalse(self.root.exists())

    def test_symlink_payload_not_followed_or_overwritten(self):
        writer = self.make_writer()
        target = self.base / "untouched"
        target.write_bytes(b"original")
        (self.root / "maps/evil").symlink_to(target)
        with self.assertRaises(FileExistsError):
            writer.put("maps", "evil", b"replacement")
        self.assertEqual(target.read_bytes(), b"original")

    def test_replaced_category_directory_rejected(self):
        writer = self.make_writer()
        moved = self.base / "old_maps"
        (self.root / "maps").rename(moved)
        (self.root / "maps").symlink_to(moved, target_is_directory=True)
        with self.assertRaises(EvidenceError):
            writer.put("maps", "blocked", b"x")
        self.assertFalse((moved / "blocked").exists())
        self.assertIsNotNone(writer.failure_receipt_error)

    def test_payload_cap_failure_records_failure_without_silent_drop(self):
        writer = self.make_writer()
        with self.assertRaises(BudgetExceeded):
            writer.put("maps", "too_big.bin", b"x" * 513)
        self.assertFalse((self.root / "maps/too_big.bin").exists())
        failure = json.loads(next((self.root / "emergency").glob("failure*.json")).read_bytes())
        self.assertEqual(failure["error_type"], "BudgetExceeded")
        self.assertEqual(failure["operation"]["path"], "maps/too_big.bin")
        self.assertTrue(failure["partial_files_preserved"])
        writer.finalize("failed")
        with self.assertRaises(IncompleteArchive):
            verify_archive(self.root)

    def test_index_overhead_preflight_precedes_payload(self):
        labels = {"evidence_kind": "model_free_fixture", "contract_kind": "source_contract"}
        receipt = labels | {"schema": 1, "sequence": 0, "path": "maps/tiny.bin",
                            "bytes": 1, "sha256": hashlib.sha256(b"x").hexdigest()}
        intent_size = len(storage._json(receipt | {"status": "intent"}))
        commit_size = len(storage._json(receipt | {"status": "complete"}))
        # The budget value is itself serialized in contract.json. Solve the tiny
        # fixed point rather than guessing a numeric index threshold.
        cap = 1_000
        for _ in range(8):
            budget = small_budget(caps={"indexes": cap})
            contract = labels | {"schema": 1, "budget": budget.to_dict(),
                                 "launch_authorized": False}
            contract_size = len(storage._json(contract))
            exact_one_byte_short = contract_size + intent_size + commit_size - 1
            if cap == exact_one_byte_short:
                break
            cap = exact_one_byte_short
        else:
            self.fail("fixture index-cap serialization did not stabilize")
        writer = self.make_writer(budget=budget)
        self.assertEqual(writer.used["indexes"], contract_size)
        remaining = budget.caps["indexes"] - writer.used["indexes"]
        self.assertLessEqual(intent_size, remaining)
        self.assertLessEqual(commit_size, remaining)
        self.assertEqual(intent_size + commit_size, remaining + 1)
        with self.assertRaises(BudgetExceeded):
            writer.put("maps", "tiny.bin", b"x")
        self.assertFalse((self.root / "maps/tiny.bin").exists())
        self.assertFalse(list((self.root / "indexes").glob("tx*.json")))

    def test_disk_floor_checked_before_creation_and_every_write(self):
        with mock.patch.object(storage, "_free_bytes", return_value=DISK_FLOOR):
            with self.assertRaises(DiskFloorError):
                self.make_writer()
        self.assertFalse(self.root.exists())
        writer = self.make_writer()
        original = storage._free_bytes
        calls = []
        def observed(fd):
            calls.append(fd)
            return original(fd)
        with mock.patch.object(storage, "_free_bytes", side_effect=observed):
            writer.put("maps", "tiny.bin", b"x")
        # Overall transaction + create and actual write of intent/payload/commit.
        self.assertGreaterEqual(len(calls), 7)

    def test_partial_write_interrupt_preserved_and_not_committed(self):
        writer = self.make_writer()
        original = os.write
        calls = 0
        def interrupted(fd, data):
            nonlocal calls
            calls += 1
            if calls == 2:  # The durable intent is first, payload is second.
                original(fd, data[:3])
                raise KeyboardInterrupt("fixture interrupted payload")
            return original(fd, data)
        with mock.patch.object(storage.os, "write", side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt):
                writer.put("maps", "partial.bin", b"payload")
        self.assertEqual((self.root / "maps/partial.bin").read_bytes(), b"pay")
        self.assertEqual(writer.used["maps"], 3)
        self.assertEqual(len(list((self.root / "indexes").glob("*.intent.json"))), 1)
        self.assertFalse(list((self.root / "indexes").glob("*.commit.json")))
        self.assertEqual(len(list((self.root / "emergency").glob("failure*.json"))), 1)
        writer.finalize("interrupted")
        self.assertEqual((self.root / "maps/partial.bin").read_bytes(), b"pay")
        with self.assertRaises(IncompleteArchive):
            verify_archive(self.root)

    def test_interrupt_between_local_and_ledger_increment_counts_actual_bytes(self):
        writer = self.make_writer()
        class InterruptingLedger(dict):
            armed = True
            def __setitem__(self, key, value):
                if key == "maps" and value > 0 and self.armed:
                    self.armed = False
                    raise KeyboardInterrupt("after local charged increment")
                return super().__setitem__(key, value)
        writer._used = InterruptingLedger(writer._used)
        with self.assertRaises(KeyboardInterrupt):
            writer.put("maps", "interrupted-ledger.bin", b"seven!!")
        self.assertEqual(writer.used["maps"], 7)
        self.assertEqual((self.root / "maps/interrupted-ledger.bin").stat().st_size, 7)
        writer.finalize("interrupted")

    def test_short_os_writes_are_completed_without_truncation(self):
        writer = self.make_writer()
        original = os.write
        with mock.patch.object(storage.os, "write", side_effect=lambda fd, data: original(fd, data[:7])):
            receipt = writer.put("maps", "short.bin", b"0123456789abcdefghijk")
        self.assertEqual(receipt["bytes"], 21)
        writer.finalize()
        verify_archive(self.root)

    def test_failed_receipt_is_explicit_and_partials_remain(self):
        writer = self.make_writer()
        original_contract = (self.root / "indexes/contract.json").read_bytes()
        with mock.patch.object(storage, "_free_bytes", return_value=0):
            with self.assertRaises(DiskFloorError) as caught:
                writer.put("maps", "not_written", b"x")
        self.assertIsInstance(writer.failure_receipt_error, DiskFloorError)
        self.assertTrue(any("Failure receipt" in text for text in caught.exception.__notes__))
        self.assertEqual((self.root / "indexes/contract.json").read_bytes(), original_contract)

    def test_finalize_is_exclusive_and_closing_is_not_success(self):
        writer = self.completed()
        with self.assertRaises(EvidenceError):
            writer.finalize()
        with self.assertRaises(EvidenceError):
            writer.put("maps", "later", b"x")
        other = self.base / "unfinished"
        with EvidenceWriter(other, budget=small_budget()) as unfinished:
            unfinished.put("maps", "x", b"x")
        with self.assertRaises(IncompleteArchive):
            verify_archive(other)

    def test_truncated_payload_is_rejected(self):
        self.completed()
        path = self.root / "maps/positions.u16"
        path.write_bytes(path.read_bytes()[:-1])
        with self.assertRaisesRegex(EvidenceError, "hash/length"):
            verify_archive(self.root)

    def test_equal_length_alteration_is_rejected(self):
        self.completed()
        (self.root / "maps/positions.u16").write_bytes(b"XXXX")
        with self.assertRaisesRegex(EvidenceError, "hash/length"):
            verify_archive(self.root)

    def test_truncated_final_receipt_is_rejected(self):
        self.completed()
        path = self.root / "indexes/final.json"
        path.write_bytes(path.read_bytes()[:-3])
        with self.assertRaises(EvidenceError):
            verify_archive(self.root)

    def test_unindexed_missing_and_symlink_files_rejected(self):
        self.completed()
        extra = self.root / "logs/extra"
        extra.write_bytes(b"extra")
        with self.assertRaises(EvidenceError):
            verify_archive(self.root)
        extra.unlink()
        victim = self.root / "maps/positions.u16"
        original = victim.read_bytes()
        victim.unlink()
        with self.assertRaises(EvidenceError):
            verify_archive(self.root)
        target = self.base / "target"
        target.write_bytes(original)
        victim.symlink_to(target)
        with self.assertRaises(OSError):
            verify_archive(self.root)

    def test_rehashed_truncation_still_fails_transaction_expected_length(self):
        self.completed()
        victim = self.root / "maps/positions.u16"
        victim.write_bytes(b"\x00")
        final = self.root / "indexes/final.json"
        envelope = json.loads(final.read_bytes())
        payload = envelope["payload"]
        for entry in payload["entries"]:
            if entry["path"] == "maps/positions.u16":
                entry["bytes"] = 1
                entry["sha256"] = hashlib.sha256(b"\x00").hexdigest()
        payload["accounting_before_final"]["maps"] = 1
        envelope["sha256"] = hashlib.sha256(storage._json(payload)).hexdigest()
        final.write_bytes(storage._json(envelope))
        with self.assertRaisesRegex(EvidenceError, "transaction expected hash/length"):
            verify_archive(self.root)

    def test_duplicate_json_keys_rejected(self):
        self.completed()
        final = self.root / "indexes/final.json"
        value = final.read_bytes()
        final.write_bytes(b'{"sha256":"invalid",' + value[1:])
        with self.assertRaisesRegex(EvidenceError, "duplicate JSON key"):
            verify_archive(self.root)


if __name__ == "__main__":
    unittest.main()
