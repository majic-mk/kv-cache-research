"""Freeze only this bounded source/protocol package, never release execution."""
import json
from pathlib import Path
from common import file_hash, strict_json, require

HERE = Path(__file__).resolve().parent
NAMES = ('README.md', 'FORMAT.md', 'ARITHMETIC_CORRECTION.md', 'common.py', 'plan.py', 'decode.py', 'maps.py', 'parity.py', 'receipts.py', 'storage.py', 'protocol.json', 'frozen_plan.json', 'check_model_free.py', 'freeze_source.py', 'test_contract.py', 'test_storage.py')

def make_manifest():
    return {'status': 'FROZEN_SOURCE_ONLY_NO_EXECUTION_AUTHORITY', 'schema': 1, 'files': [{'path': name, 'bytes': (HERE / name).stat().st_size, 'sha256': file_hash(HERE / name)} for name in NAMES], 'model_calls': 0, 'backend_implemented': False, 'execution_authorized': False}

def verify():
    saved = strict_json((HERE / 'source_manifest.json').read_bytes())
    require(saved == make_manifest(), 'source/protocol freeze mismatch')
    return saved

if __name__ == '__main__':
    with (HERE / 'source_manifest.json').open('x') as stream:
        json.dump(make_manifest(), stream, indent=2); stream.write('\n')
    verify()
    print('Frozen source/protocol only; all execution remains locked')
