# Held-out compact evidence contract, source-only

This is bounded standard-library source preparation for the already frozen two-family/eight-input prospective KV pilot. It is **not a research result, model execution, qualified backend, deployment, or GPU authorization**. The current practical route remains STOP-for-now. No CUDA/model backend exists here; `plan.execute()` and running `plan.py` always raise `EXECUTION_LOCKED`. The storage writer accepts only `model_free_fixture` or `source_contract` evidence labels.

All files are new in this directory. Closed CPU/GPU experiments, their contracts, failures and raw archives remain untouched. No dependencies, model imports, inference, provider operations or spend were used. Dependency hashes reference preserved files; they do not prove a live model/runtime is installed or qualified.

## Frozen scientific and planning bindings

`protocol.json` binds feasibility revision 2; the additive S=0 clarification; the complete eight input rows, prompts and canonical ID hashes; source/tokenizer/base/gate/candidate-runtime pins; and all 55 manifested frozen input/source packet files. SHA-256-null small base metadata entries retain their existing Git blob SHA-1 pins, rather than inventing SHA-256 values. `frozen_plan.json` contains the exact 64 cases and full canonical history/query call schedules.

Order is arm-major: native Full, gate-loaded no-crop Full, static TRIM online/deferred, original-position recency online/deferred, fixed-priority random online/deferred. Each arm uses the frozen eight-input order. This fixed order is not a statistically controlled latency benchmark. B=1024, zero post-history-call slack, TRIM buffer_size=1/W=0, seed1701. Random preserves the exact existing SHA-256 key encoding, signed-priority direction, position tie rule, chronological gather and resident-only candidates.

Each complete 80/71-token final query suffix is one forward. No selection occurs after the history seam. Deferred ingestion retains Full history and has a larger memory peak. Author decode selects/records first, then checks EOS, then selection index 799; the terminal selected ID is discarded from emit/feed but retained in evidence. Maximum 800 selections/799 emitted and fed tokens. EOS at 799 is EOS, not a cap hit. Numerical failure stops the packet; Full-wrong, generic-error, cap-ended and partial rows stay in the fixed denominator. `outcome_admission` cannot remove or replace cases or authorize execution.

Source-only totals: 64 generations, 51,200 selections, 51,136 emitted/fed tokens, 56,160 forwards, 7,020 Full/no-crop forward pairs, 1,644 all-layer/head crop maps. These are bounds, not operations run.

## Supported codecs and checks

- `decode.py`: exact 32-byte little-endian records. Fields in order are selection index uint16, token ID uint32, selected original BF16 logit uint16 bits, selected probability uint32 FP32 bits, selected log-probability uint32 FP32 bits, flags uint16, reserved uint16=0, producing forward-call uint32, reserved uint64=0. Records bind to the case-specific query/decode call indices. EOS/cap flags, actual emitted/fed flags and interrupted pending feeds are checked. Complete raw UTF-8 answers and every selected/emitted/fed ID are preserved with exact hashes, including the discarded terminal record
- Normalization is prospectively frozen as separate FP32 softmax and log_softmax over the same original BF16 vocabulary vector cast to FP32. Argmax is on the original logits, lowest token index for ties. The selected FP32 and BF16 bit patterns are supplied unchanged; this module never computes probabilities or claims to independently verify them. A future implementation must charge normalization, scalar transfers and serialization overhead
- `maps.py`: checked lossless int64 little-endian source bytes to uint16 little-endian, explicit original shape/dtype, original and compact SHA-256, and order preservation. Bound0<=position<seen <= 8420 proves the compact representation. Production crop shape is [36,1,8,1024]. Every layer/head of every crop is retained. Production validators check chronological unique rows, canonical crop boundaries, previous survivors plus newly appended candidates, no recovery and no query/decode maps. Paired map comparison checks exact ordered reconstructed int64 maps
- Maximum compact map payload 969,670,656 bytes. Even a 4096-byte map header plus 12-byte framing per crop stays below the 1,000,000,000-byte map category cap. No compression/deduplication ratio is assumed
- `parity.py`: each 4728-byte Full/no-crop pair has fixed geometry, same-call/input/range binding, two complete-vocabulary-vector SHA-256 references and 144 appended K/V SHA-256 references (36 layers×K/V×both sides). Hashes cover exact contiguous little-endian raw bytes; this new raw-byte scheme is explicitly distinct from historical shape-prefixed digests. Maximum 33,190,560 pair bytes. Mismatches and failed producer checks remain representable and return failed parity; they are not relaxed or silently skipped
- `receipts.py`: hash-bound actual call/answer/selection references, complete or explicitly partial map inventories, required timing/transfer fields including normalization overhead, and before/after identity-hash receipts. On-device checks and model/gate immutability remain producer-reported observations. Hash binding is not a digital signature or proof that inference happened
- `storage.py`: exclusive new output roots and filenames, symlink/linked-file rejection, bounded category/total accounting including index/control/failure/finalization files, preflight before writes, retained failed/partial files, read-back length/hash checks, and final archive verification. Archive completion is storage integrity only; it never means experimental completeness or execution readiness

## Retained-byte ceilings

Decimal bytes: maps 1,000,000,000; baseline 50,000,000; selections 2,000,000; answers 20,000,000; metadata 256,000,000; sources 100,000,000; logs 128,000,000; indexes 64,000,000; emergency 20,000,000. Total 2,000,000,000. Category ceilings sum 1,640,000,000; 360,000,000 bytes of total headroom does not enlarge categories or add cases. Normal writes cannot consume emergency capacity. Smaller test caps are allowed, never larger production caps. Disk free space must remain at least 5,000,000,000 bytes; other processes can still consume disk, so this check is not an OS reservation.

Any cap/I/O/integrity failure stops the writer, preserves already written data/intent/failure receipts and surfaces an error. It never truncates, replaces, samples, retries inference, deletes an old archive, or falls back to reduced evidence. SIGKILL can prevent a final failure receipt; a durable intent or partial file remains incomplete. A future backend must preflight/reserve its next required evidence before performing the operation; no such backend or runtime release exists here. Oversize caller data is rejected explicitly, not silently truncated.

## Model-free verification

From this directory, run:

    python -B check_model_free.py --output checks_01

Use a new output directory for each attempt. The child test process is bounded to 60 seconds wall, 60 seconds CPU and 1 GiB address space; the runner checks a 5 GB free-disk floor and records actual wall time/RSS. Tests use small real files and synthetic ledger boundary arithmetic, never 2 GB stress writes. The source freeze and check outputs are separate: a passing test receipt is not model, GPU, performance or research evidence.

The tests cover exact eight-input/64-case schedules, source hashes, no-op semantic admission with Full-wrong rows, numerical-stop retention, EOS/cap/censoring edges, malformed ranges/dtypes/shapes/overflow, truncation/hash mismatch, all-layer map/no-recovery and paired equality, baseline identity/schedule binding, lost/extra records, tiny actual file roundtrips, category/total/emergency/disk limits, exclusive paths and preserved interruptions.

## Unavailable post-hoc analyses and remaining gates

No raw vocabulary vectors or raw selected K/V tensors are archived by this contract. It cannot independently reconstruct argmax, selected probabilities, alternate-token probabilities/ranks, entropy, KL/distribution divergence, teacher-forced answer scores, residuals behind a hash mismatch, gate-score/top-k margins, or selected K/V contents. Exact supplied byte-hash equality is retained; raw-tensor reinspection is not.

A qualified backend, on-device finite/argmax/gather/reset/mask checks, real model/gate immutability observations, fully bound runtime metadata and timing/resource/provider samples, actual emitted-text/tokenizer verification, runtime bundle completeness, opening device fixtures, cost/stop control and methods-hidden complete-answer review remain unimplemented/unverified. No 2 GB-scale serializer throughput/stress test was performed. No GPU approval, single-start route, prior-charge reconciliation, physical memory fit, speedup, causal finding or publication readiness follows from this package.
