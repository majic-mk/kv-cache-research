"""Compact exact Full/no-crop hash references, not archived raw tensor proofs.

Each 4728-byte pair records raw-byte SHA-256 digests for two full vocab vectors
and two sides * 36 layers * K/V appended tensors. Geometry is fixed in metadata.
Hash equality verifies the supplied references only; it cannot independently
establish argmax, finite tensors, a real forward, or honest producer checks.
"""
import struct
from common import canonical, digest, integer, require, sha

MAGIC = b'KVPAR01\0'
HEADER = struct.Struct('<8sBBHII32sI')
PAIR_BYTES = HEADER.size + (2 + 2 * 36 * 2) * 32
PHASES = ('history', 'query', 'decode')
CHECKS = ('original_logits_argmax_equal', 'all_logits_finite', 'reset_passed', 'causal_mask_passed', 'append_positions_passed')

def tensor_reference(dtype, shape, raw_sha256):
    require(dtype == 'bfloat16', 'parity requires original BF16 tensors')
    require(type(shape) is list and all(type(v) is int and v > 0 for v in shape), 'invalid tensor shape')
    return {'dtype': dtype, 'shape': shape, 'byte_order': 'little', 'raw_tensor_bytes_sha256': digest(raw_sha256)}

def _side(side, appended):
    expected_vector_shape = [1, 1, 151936]
    require(side['vector'] == tensor_reference('bfloat16', expected_vector_shape, side['vector']['raw_tensor_bytes_sha256']), 'full-vector geometry mismatch')
    require(len(side['append']) == 36, 'every layer append required')
    hashes = [bytes.fromhex(digest(side['vector']['raw_tensor_bytes_sha256']))]
    for layer, pair in enumerate(side['append']):
        require(pair['layer'] == layer, 'layer missing/duplicate/out of order')
        for name in ('k', 'v'):
            ref = pair[name]
            require(ref == tensor_reference('bfloat16', [1, 8, appended, 128], ref['raw_tensor_bytes_sha256']), 'append geometry mismatch')
            hashes.append(bytes.fromhex(ref['raw_tensor_bytes_sha256']))
    return hashes

def encode_pair(prompt_index, call_index, phase, start, end, ids_sha256, native, no_crop, checks):
    integer(prompt_index, 0, 7, 'prompt index'); integer(call_index, 0, 881, 'call index')
    require(phase in PHASES, 'invalid call phase')
    integer(start, 0, 9298, 'call start'); integer(end, start + 1, 9299, 'call end')
    require(end - start <= 128 and (phase != 'decode' or end - start == 1), 'invalid append range')
    require(set(checks) == set(CHECKS) and all(type(v) is bool for v in checks.values()), 'exact runtime check fields required')
    flags = sum(int(checks[name]) << i for i, name in enumerate(CHECKS))
    a, b = _side(native, end - start), _side(no_crop, end - start)
    return HEADER.pack(MAGIC, prompt_index, PHASES.index(phase), call_index, start, end, bytes.fromhex(digest(ids_sha256)), flags) + b''.join([a[0], b[0]] + a[1:] + b[1:])

def decode_pair(raw):
    require(type(raw) is bytes and len(raw) == PAIR_BYTES, 'truncated/oversized parity pair')
    magic, prompt, phase, call, start, end, ids, flags = HEADER.unpack(raw[:HEADER.size])
    require(magic == MAGIC and phase < len(PHASES) and flags & ~31 == 0, 'parity magic/phase/reserved bits changed')
    hashes = [raw[i:i + 32].hex() for i in range(HEADER.size, len(raw), 32)]
    def side(vector, append):
        return {'vector': tensor_reference('bfloat16', [1, 1, 151936], vector), 'append': [{'layer': i, 'k': tensor_reference('bfloat16', [1, 8, end - start, 128], append[2 * i]), 'v': tensor_reference('bfloat16', [1, 8, end - start, 128], append[2 * i + 1])} for i in range(36)]}
    a, b = side(hashes[0], hashes[2:74]), side(hashes[1], hashes[74:146])
    checks = {name: bool(flags & (1 << i)) for i, name in enumerate(CHECKS)}
    require(encode_pair(prompt, call, PHASES[phase], start, end, ids.hex(), a, b, checks) == raw, 'noncanonical pair')
    return {'prompt_index': prompt, 'call_index': call, 'phase': PHASES[phase], 'start': start, 'end': end, 'ids_sha256': ids.hex(), 'native': a, 'no_crop': b, 'producer_reported_checks': checks, 'exact_hash_reference_parity': a == b, 'passed': a == b and all(checks.values()), 'raw_vectors_archived': False, 'raw_KV_archived': False, 'independent_argmax_recomputable': False, 'receipt_sha256': sha(raw)}

def validate_call_pair(raw, expected, prompt_index, call_index):
    result = decode_pair(raw)
    require(result['prompt_index'] == prompt_index and result['call_index'] == call_index, 'paired call identity changed')
    for name in ('phase', 'start', 'end', 'ids_sha256'):
        require(result[name] == expected[name], 'paired call schedule/input changed')
    return result

def answer_pair_receipt(native_answer, no_crop_answer):
    integer(native_answer['case_index'], 0, 7, 'native Full case')
    require(no_crop_answer['case_index'] == native_answer['case_index'] + 8, 'Full/no-crop case pairing changed')
    fields = ('selected_ids', 'emitted_ids', 'fed_ids', 'status', 'terminal_discarded_selection', 'selection_records_sha256', 'raw_answer')
    return {'passed': all(native_answer[name] == no_crop_answer[name] for name in fields), 'native_answer_sha256': sha(canonical(native_answer)), 'no_crop_answer_sha256': sha(canonical(no_crop_answer)), 'compared_fields': list(fields), 'evidence_level': 'hash-bound producer result records; not raw-logit proof'}
