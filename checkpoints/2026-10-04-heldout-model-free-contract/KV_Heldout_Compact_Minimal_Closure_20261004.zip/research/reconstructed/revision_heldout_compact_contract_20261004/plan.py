"""Frozen planning/admission only. There is deliberately no model or provider backend."""
import hashlib
import json
import struct
from pathlib import Path
from common import canonical, digest, file_hash, integer, require, sha, strict_json

HERE = Path(__file__).resolve().parent
ARMS = ('full', 'no_crop', 'trim_online', 'trim_deferred', 'recency_online', 'recency_deferred', 'random_online', 'random_deferred')
BUDGET = 1024
SEED = 1701
MAX_SELECTIONS = 800
VOCAB = 151936
LAYERS = 36
HEADS = 8

def load_protocol():
    return strict_json((HERE / 'protocol.json').read_bytes())

def load_inputs(reconstructed=None):
    base = Path(reconstructed) if reconstructed else HERE.parent
    contract = load_protocol()
    spec = contract['inputs']
    path = base / spec['path']
    require(path.stat().st_size == spec['bytes'] and file_hash(path) == spec['sha256'], 'frozen packet bytes changed')
    rows = strict_json(path.read_bytes())
    require(len(rows) == 8, 'exactly eight inputs required')
    for row, expected in zip(rows, spec['rows']):
        require(row['variant_id'] == expected['variant_id'], 'input order changed')
        ids = row['canonical_token_ids']
        require(type(ids) is list and all(type(x) is int and 0 <= x < VOCAB for x in ids), 'invalid token IDs')
        # The packet canonical ID hash uses compact JSON; integers are ASCII.
        require(sha(json.dumps(ids, separators=(',', ':')).encode()) == expected['canonical_ids_sha256'] == row['canonical_ids_sha256'], 'canonical IDs changed')
        require(sha(row['canonical_prompt'].encode()) == expected['canonical_prompt_sha256'] == row['canonical_prompt_sha256'], 'prompt text changed')
        require(len(ids) == expected['total_input_tokens'] == row['total_input_tokens'], 'input length changed')
        history = row['history_tokens']
        require(history == expected['history_tokens'] == row['query_absolute_start'], 'history seam changed')
        require(ids[history:] == row['query_suffix_token_ids'] and row['query_suffix_range'] == [history, len(ids)], 'query suffix changed')
        ends = row['history_online_chunk_end_indices']
        require(len(ends) == expected['history_forward_calls'] and ends[-1] == history, 'history calls changed')
        require(all(type(x) is int for x in ends) and all(0 < end - start <= 128 for start, end in zip([0] + ends[:-1], ends)), 'invalid history partition')
        require(sha(canonical(ends)) == expected['history_ends_sha256'], 'history partition hash changed')
    return rows

def validate_row(row):
    expected = {item['variant_id']: item for item in load_protocol()['inputs']['rows']}
    require(type(row) is dict and row.get('variant_id') in expected, 'unknown frozen row')
    require(sha(canonical(row)) == expected[row['variant_id']]['complete_row_sha256'], 'frozen row contents changed')
    return row

def schedule(row):
    validate_row(row)
    start = 0
    result = []
    for end in row['history_online_chunk_end_indices']:
        result.append({'phase': 'history', 'start': start, 'end': end, 'ids_sha256': sha(canonical(row['canonical_token_ids'][start:end]))})
        start = end
    # One complete suffix forward. Metadata user/header split is not a call.
    result.append({'phase': 'query', 'start': start, 'end': row['total_input_tokens'], 'ids_sha256': sha(canonical(row['query_suffix_token_ids']))})
    return result

def fixed_plan(rows):
    frozen = load_protocol()['inputs']['rows']
    require(canonical(rows) == canonical(load_inputs()), 'input row contents must equal the exact frozen packet')
    require([r['variant_id'] for r in rows] == [r['variant_id'] for r in frozen], 'cohort cannot be replaced or filtered')
    return [{'case_index': a * 8 + i, 'arm': arm, 'variant_id': row['variant_id'], 'canonical_ids_sha256': frozen[i]['canonical_ids_sha256'], 'schedule_key': row['variant_id'], 'max_selections': 800, 'max_emitted_and_fed': 799} for a, arm in enumerate(ARMS) for i, row in enumerate(rows)]

def outcome_admission(plan, outcome_rows):
    """A pure no-filter annotation. Semantic outcomes never admit a smaller cohort."""
    frozen_cases = strict_json((HERE / 'frozen_plan.json').read_bytes())['cases']
    require(canonical(plan) == canonical(frozen_cases), 'invalid or altered fixed plan')
    seen = set()
    numerical_stop = False
    for row in outcome_rows:
        index = integer(row['case_index'], 0, 63, 'case index')
        require(index not in seen, 'duplicate outcome')
        seen.add(index)
        require(row['arm'] == plan[index]['arm'] and row['variant_id'] == plan[index]['variant_id'], 'outcome identity changed')
        require(type(row['numerical_checks_passed']) is bool, 'numerical status must be explicit')
        numerical_stop |= not row['numerical_checks_passed']
    return {'case_indices': list(range(64)), 'denominator_cases': 64, 'denominator_inputs': 8, 'source_families': 2, 'retained_outcomes': outcome_rows, 'numerical_stop_required': numerical_stop, 'semantic_cohort_gate': False, 'execution_authorized': False}

def crop_schedule(row, arm):
    validate_row(row)
    require(arm in ARMS, 'unknown arm')
    if arm in ('full', 'no_crop'):
        return []
    if arm.endswith('_deferred'):
        return [{'phase': 'history_seam', 'seen': row['history_tokens'], 'candidate_count': row['history_tokens'], 'retained_count': BUDGET}]
    result, resident, previous = [], 0, 0
    for end in row['history_online_chunk_end_indices']:
        resident += end - previous
        if resident > BUDGET:
            result.append({'phase': 'history', 'seen': end, 'candidate_count': resident, 'retained_count': BUDGET})
            resident = BUDGET
        require(resident == min(end, BUDGET), 'nonzero history slack')
        previous = end
    return result

def priority(layer, head, position):
    integer(layer, 0, 35, 'layer'); integer(head, 0, 7, 'head'); integer(position, 0, 8419, 'history position')
    raw = hashlib.sha256(b'revision-pilot-priority-v1\0' + struct.pack('<QQQQ', SEED, layer, head, position)).digest()[:8]
    return int.from_bytes(raw, 'little', signed=True)

def control_selection(resident_positions, policy, layer=0, head=0, budget=BUDGET):
    integer(budget, 1, BUDGET, 'retained budget')
    require(len(resident_positions) == len(set(resident_positions)), 'duplicate resident positions')
    for p in resident_positions:
        integer(p, 0, 8419, 'resident position')
    if policy == 'recency':
        return sorted(resident_positions)[-budget:]
    require(policy == 'random', 'unknown control')
    return sorted(sorted(resident_positions, key=lambda p: (-priority(layer, head, p), p))[:budget])

def execute(*args, **kwargs):
    raise RuntimeError('EXECUTION_LOCKED: source-only contract; no backend, approval, provisioning or inference path exists')

if __name__ == '__main__':
    execute()
