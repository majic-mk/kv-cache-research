"""Hash-bound source/trace receipts. These validate claims, not execution reality."""
from common import canonical, digest, integer, require, sha
from maps import decode_map, validate_production_map
from plan import ARMS, crop_schedule, schedule

TIMING_FIELDS = ('history_seconds', 'query_seconds', 'decode_seconds', 'gate_seconds', 'selector_seconds', 'gather_seconds', 'normalization_seconds', 'selected_scalar_transfer_seconds', 'evidence_serialization_seconds', 'synchronization_seconds', 'end_to_end_seconds')
COUNTER_FIELDS = ('host_to_device_bytes', 'device_to_host_bytes', 'selected_scalar_transfer_bytes', 'evidence_bytes', 'append_tensor_written_bytes', 'gather_tensor_written_bytes')
RESOURCE_FIELDS = ('device_allocated_bytes', 'device_reserved_bytes', 'device_free_bytes', 'process_tree_RSS_bytes', 'disk_free_bytes')

def hash_bound_receipt(kind, payload):
    require(type(kind) is str and bool(kind) and type(payload) is dict, 'invalid receipt')
    return {'schema': 'source_contract_receipt_v1', 'kind': kind, 'payload': payload, 'payload_sha256': sha(canonical(payload)), 'evidence_level': 'hash-bound supplied data; no signature or independently observed execution'}

def verify_receipt(receipt):
    require(receipt == hash_bound_receipt(receipt['kind'], receipt['payload']), 'receipt hash/fields mismatch')
    return receipt['payload']

def map_inventory(row, arm, actual_maps, *, complete):
    """Each list member is the actual complete all-layer/head map bytes.

    The expected event order supplies phase/seen/candidate metadata. Empty maps
    cannot stand in for unretained evidence. A partial list stays explicit and
    cannot be called complete. No new map can appear after the history seam.
    """
    require(arm in ARMS and type(complete) is bool, 'invalid inventory scope')
    expected = crop_schedule(row, arm)
    require(len(actual_maps) <= len(expected), 'extra or post-seam selections')
    require(not complete or len(actual_maps) == len(expected), 'one or more actual crop maps missing')
    references = []
    previous = None
    previous_seen = 0
    for index, (raw, event) in enumerate(zip(actual_maps, expected)):
        checked = validate_production_map(raw, event, previous, previous_seen)
        references.append({'event_index': index, **event, 'bytes': len(raw), 'map_sha256': checked['map_sha256']})
        previous, previous_seen = raw, event['seen']
    return hash_bound_receipt('selected_map_inventory', {'variant_id': row['variant_id'], 'arm': arm, 'complete': complete, 'expected_map_count': len(expected), 'retained_map_count': len(references), 'missing_map_count': len(expected) - len(references), 'map_references': references, 'query_decode_map_count': 0, 'raw_KV_proof': False})

def expected_calls(row, fed_token_ids):
    require(type(fed_token_ids) is list and len(fed_token_ids) <= 799, 'invalid fed sequence')
    calls = schedule(row)
    for index, token in enumerate(fed_token_ids):
        integer(token, 0, 151935, 'fed token')
        start = row['total_input_tokens'] + index
        calls.append({'phase': 'decode', 'start': start, 'end': start + 1, 'ids_sha256': sha(canonical([token]))})
    return calls

def validate_call_schedule(row, answer_raw, selection_records, actual_calls, *, complete):
    from decode import decode_answer
    from plan import load_protocol
    answer = decode_answer(answer_raw, selection_records)
    require(load_protocol()['inputs']['rows'][answer['case_index'] % 8]['variant_id'] == row['variant_id'], 'answer/call prompt identity changed')
    expected = expected_calls(row, answer['fed_ids'])
    require(type(complete) is bool and len(actual_calls) <= len(expected), 'extra calls')
    require(not complete or len(actual_calls) == len(expected), 'complete case missing call receipts')
    for index, call in enumerate(actual_calls):
        require(call == {'call_index': index, **expected[index]}, 'call identity/input/range mismatch')
    return hash_bound_receipt('call_schedule', {'variant_id': row['variant_id'], 'complete': complete, 'actual_calls': actual_calls, 'expected_call_count': len(expected), 'all_input_ids_in_frozen_packet': True, 'all_generated_input_ids_in_answer': True, 'answer_sha256': sha(answer_raw), 'selection_records_sha256': sha(selection_records)})

def measured_cost_receipt(timings, counters, resources):
    import math
    require(set(timings) == set(TIMING_FIELDS), 'missing timing, including normalization/transfer overhead')
    for value in timings.values():
        require(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'invalid measured time')
    require(set(counters) == set(COUNTER_FIELDS) and set(resources) == set(RESOURCE_FIELDS), 'missing byte/resource counter')
    for value in list(counters.values()) + list(resources.values()):
        integer(value, 0, 2**63 - 1, 'observed byte count')
    return hash_bound_receipt('reported_costs', {'timings': timings, 'counters': counters, 'resources': resources, 'timing_overlap': 'unspecified: do not sum to claim disjoint wall time', 'measurement_verified_by_contract': False})

def immutability_receipt(before, after):
    require(set(before) == set(after) == {'base_parameters', 'gate_parameters', 'runtime_source', 'input_packet', 'contract_source'}, 'incomplete identity hashes')
    for value in list(before.values()) + list(after.values()):
        digest(value)
    return hash_bound_receipt('reported_immutability', {'before': before, 'after': after, 'unchanged': before == after, 'raw_parameters_archived': False, 'actual_memory_independently_verified': False})
