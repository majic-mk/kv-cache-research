# Held-out compact evidence/plan contract

**Source-only. No research result, model backend, execution readiness or GPU approval.** The practical route remains STOP-for-now. `plan.execute()` and running `plan.py` always fail closed. Only standard-library contract tests may run. Closed CPU/GPU experiments and their evidence remain unchanged.

## What is frozen

`protocol.json` and `frozen_plan.json` bind the exact eight input/prompt/ID hashes, 64 arm-major cases, eight listed arms, B=1024/S=0/seed1701, exact random-key/tie rules, one complete query-suffix forward, and author 800-selection/799-emitted/fed semantics. EOS at selection799 takes precedence over the cap; the discarded terminal selection remains recorded. Full-wrong and all other semantic outcomes remain in the fixed denominator. Numerical failure stops the packet. Fixed order is not a controlled latency benchmark.

## Supported checks

- Complete raw answers and all selected/emitted/fed IDs; exact FP32 probability/log-probability bits and original BF16 selected-logit bits, with case/call identity and terminal/censoring checks
- Lossless int64-source to uint16-LE map encoding under proven original-position bounds, preserving shape/order and every layer/head/crop; resident-only/no-recovery, history-only, completeness and paired equality checks
- Exact Full/no-crop same-call vocabulary-vector and per-layer appended K/V byte-hash references, shape/dtype and hash-bound receipts. These are supplied references, not archived raw-tensor or independently recomputable argmax proofs
- Exclusive output roots/paths, strict category/total/index accounting, emergency reserve, ≥5 GB free-disk floor, preserved failures/partial files, and read-back hash/length verification

The total retained-evidence ceiling stays 2,000,000,000 bytes. All listed category caps are unchanged. They sum to 1,640,000,000, leaving 360,000,000 headroom; the frozen feasibility report's addition error is corrected only in `ARITHMETIC_CORRECTION.md`. No allowance is enlarged.

## Bounded model-free tests

From this directory:

    python -B check_model_free.py --output new_check_directory

Every attempt uses an exclusive output directory, ≤60 seconds wall/CPU, ≤1 GiB address space and a 5 GB disk floor. Tests use tiny actual file roundtrips and synthetic ledger boundaries, never 2 GB stress writes. They cover invalid ranges/overflow, EOS/cap edges, malformed/truncated/hash-mismatched records, map equality, Full-wrong admission no-op and interrupted writes. Source/protocol hashes are in `source_manifest.json`; attempt receipts are separate. Failed attempt01 is preserved with its original source snapshot.

## Important limits

No model/CUDA/backend/provider action or dependency installation occurred. Runtime normalization, on-device checks, model/gate immutability, resource/cost control, actual text decoding and full runtime-bundle qualification remain unimplemented/unverified. Hash-bound claims do not prove execution.

Without raw vocabulary vectors or selected K/V, later analyses cannot independently recompute argmax/probabilities, alternate-token ranks, entropy/KL, teacher-forced scores, numerical mismatch residuals, gate-score/top-k margins or selected K/V contents. No throughput, physical-memory, causal, publication or readiness claim follows.

See `FORMAT.md` for exact encodings, category caps, source pins and remaining gates.
