# Success branch: one held-out interaction pilot, not prompt rescue

Date: 2026-10-04 UTC. Recommendation only. No families selected, prompts built, inference run, or GPU authorized by this report. The two development families, their sixteen variants, both original failures and the successful temporal-scope diagnostic remain development evidence. The original pilot stays closed.

## Decision and substantive gap

**One final small held-out interaction pilot is scientifically defensible to propose. Another paraphrase-only Full gate is not the useful next research test.** The question must be whether relevant obsolete repetitions create an additional *placement-dependent stale-answer penalty when eviction is physically irreversible during history formation*, compared with deferred selection by the same policy.

TRIM-KV Appendix B.3 already covers capacity-driven chunked-prefill eviction; Positions Are Not Facts already covers update interventions, online masking and prompt/abstention sensitivity. Therefore neither online eviction, changed-fact questions, nor query-sensitive answer recovery is the contribution. The candidate gap is their specific controlled interaction, potentially showing when deferred-selection evaluation gives a misleading account of a fixed-capacity serving policy. I did not identify that exact comparison in the inspected primary sections; this is a scoped distinction, not exhaustive proof of novelty. [TRIM-KV](https://arxiv.org/html/2512.03324v2), Appendix B.3; [Positions Are Not Facts](https://arxiv.org/html/2609.33759v1), §§2, 6, A.4, C.1.3, D.6

The result would still be a feasibility signal about one static learned policy, not a new algorithm, general ranking, population finding or paper-ready contribution. A single-5090 implementation is plausible at these context lengths, but measured memory/runtime and a separately approved cost bound remain necessary.

## Smallest defensible fixed cohort

**Exactly two new independent source families**, the minimum for replication beyond one anecdote. Four would be stronger, but doubling the first test is not justified before any interaction has been observed.

Before looking at any new output, freeze this selection rule: start from the existing jointly admitted source-only eligibility ledger; exclude the two development families and every question sharing either family's source sessions, plus any other family already used for model-guided prompt development; group by shared source history; rank eligible groups by SHA-256 with the new fixed salt `revision-serving-holdout-v1`; take the first two. Keep IDs sealed until this protocol is accepted. Do not replace a failed, awkward or Full-wrong family. If the fixed construction cannot be completed for either selected family, report the failure and stop this packet rather than move down the ranking.

Use four prompts per family: **three target-relevant obsolete copies versus three irrelevant same-string copies**, each at two controlled reservoir placements. Preserve the complete original history, original date/value labels and equal whole-prompt lengths within family. Reuse the already source-reviewed archive-owner distinction. Move one fixed, target-free 1,024-token reservoir from before to after the immutable source; use one frozen reservoir text/order, independently checked for relevance. Hold total length and final-question position fixed. Inventory all latest-answer semantic echoes and disclose exact ages. This does not independently separate absolute position from age or guarantee crossing a protected window.

This reduced design is deliberately a **relevance-of-fixed-repetition** test, not a repetition-dose experiment. The shared low-copy baseline cancels from the primary relevant-minus-irrelevant contrast. Omitting low-zero/high-neutral cells saves half the old workload, while giving up claims about repetition versus no repetition and broad neutrality of filler. Those claims must not reappear in the title or conclusions.

## One task wording policy, fixed before output

Use one generic template for all eight inputs:

“According to the provided conversation history, what is the most recently reported [queried attribute], and on which session date was it reported?”

Fill only the attribute description, reviewed from the original question without outputs. Do not provide values, report dates, examples, answer options, or source-location hints. Keep the existing system and archival-scope rules; no case-specific prompt edits, truncation, user-only conversion or hidden output format. Preserve the original query date. Freeze supported record/value and session-date references through source-only review before inference.

This is explicitly a latest-reported-state-and-report-date task. It is not unchanged LongMemEval evaluation or a test of actual current-world truth. The extra date request remains part of the task; do not attribute any outcome uniquely to the temporal-scope wording.

## Minimal strong baseline set and workload

Fix the same pinned Qwen3-4B checkpoint, BF16, canonical chunks, greedy author 800-selection rule, no training and no model/budget sweep. B=1,024. Eight arms on each of eight prompts:

1. Native Full
2. Gate-loaded no-crop Full
3. Static released TRIM, irreversible online
4. Static released TRIM, deferred selection
5. Last-N recency, online
6. Last-N recency, deferred
7. Seeded random, online
8. Seeded random, deferred

**Maximum 64 answer generations**, not 64 independent observations; there are only two source families. Static TRIM uses its declared W=0 and 128-token trigger slack. Random uses one frozen seed and samples only currently resident candidates. Recency preserves original-position rows. Freeze history selection before the final query and charge query/output growth. Deferred selection retains Full history during ingestion, so its larger memory peak must be disclosed. Recency/random immediate crops do not match TRIM's slack peak.

Static TRIM supplies the trained comparator; this is not a claim that it is the strongest current algorithm. DBTRIM remains a relevant later comparison before broad policy claims. Do not add a mislabeled H2O, unreconciled SnapKV or uncharged recoverable cache merely to lengthen the baseline list. All arms require the existing position/mask/reset/gather checks and a prospectively exact no-crop parity contract. Numerical failure stops the whole packet without loosening tolerances.

## Outcomes and go/no-go rule

Keep **every selected family and every outcome**. Do not require every Full answer to be correct as an eligibility gate, drop Full-wrong rows, replace families, or condition the primary result on successful Full answers.

For each family and placement, let Y mean that the complete answer incorrectly endorses the designated obsolete value as the latest report. Preserve separate latest-value accuracy, report-date accuracy, joint complete-answer accuracy, stale-only/mixed/other errors, abstention and EOS/cap status. A qualified historical old value is not Y. No substring scoring. Review complete answers against the complete source, with methods hidden where possible.

The primary contrast is the relevant-minus-irrelevant difference in Y under online TRIM, minus that same difference under deferred TRIM. The primary placement effect is its farther-minus-nearer difference. Record same-prompt Full contrasts and paired corrections/losses; Full subtraction cancels algebraically from the final regime comparison but remains essential for interpreting transitions. Show all eight input rows for all arms; do not select an attractive average.

**GO only to a fresh, larger proposal, not to a paper claim:** both held-out families show a positive prespecified placement interaction under static TRIM, and each contains a directed online relevant-copy stale transition with a supported corresponding Full/deferred answer. The matching irrelevant-copy and nearer-placement outcomes must show that the result is not merely indiscriminate failure or disappearance of stale answers into abstention. Both-family replication is a conservative screening rule, not statistical significance. Recency/random outcomes provide context; a signal confined to random or recency does not qualify as failure of the learned comparator.

**NO-GO for automatic expansion:** no TRIM interaction, only one-family signal, ordinary Full/source confusion explaining the apparent signal, generic errors across relevance controls, date/format failures masquerading as stale-current errors, numerical failure, or a result requiring favorable scoring. Preserve the limited null or inconclusive outcome; do not search seeds, budgets, placement lengths, models or replacement cases until an effect appears. Resource censoring stays inconclusive and confers no retry authorization.

## What “cheap” must mean here

A 64-case sweep on the present file-paged CPU is not honestly a cheap next check: one diagnostic took 13.5 minutes end-to-end, and completion lengths vary. Do not launch an unbounded CPU study or another backend-engineering loop. The zero-weight preparation is limited to the single fixed disjoint packet above; its successful construction is not empirical evidence.

Proceed to the 64-case pilot only if an already supported execution path and an actual tightly bounded cost/time proposal make it inexpensive enough for the user. Otherwise stop this research route for now. No purchase, model run, provider action, source mutation or GPU provisioning is authorized by this recommendation. If later expanded, these pilot families also become development material; confirmatory efficacy needs further held-out families and stronger generalization evidence.

## Parent-accepted preparation-only boundary, 2026-10-04

The parent accepted this recommendation for source-only preparation. No additional CPU model ladder, 64-generation CPU sweep, or inference is authorized. GPU execution remains conditional on a new practical cost/runtime proposal and confirmed resource control, including the selected device, usable memory, supported runtime, hard spending/time limits and verified stop/release behavior. Selecting and constructing the disjoint deterministic two-family packet must use source semantics only, never prior model outcomes.

An empirical interaction, even if observed, would not by itself establish publication novelty. If its practical interpretation cannot be materially distinguished from TRIM's existing chunked-eviction evaluation and Positions Are Not Facts' interventions, the pilot would remain a limited replication/diagnostic and would not justify a novelty claim. No new algorithm or publication outcome is assumed.
