"""Deterministic local tokenizer-only prompt builder. Never load a model or network client."""
from pathlib import Path
import json,hashlib,re,sys,copy,resource
from tokenizers import Tokenizer
from jinja2 import Environment
import tokenizers,jinja2
O=Path(__file__).resolve().parent;R=O.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def dump(n,x):
 p=O/n;assert not p.exists(),n;p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
protocol=json.loads((O/'protocol_preselection_frozen.json').read_text());frozen=json.loads((O/'pre_render_freeze.json').read_text())
for path,digest in frozen['files'].items():assert sha((O/path).read_bytes())==digest,(path,'hash mismatch')
review=json.loads((O/'independent_source_review.json').read_text());assert review['approved_for_rendering'] is True
plans=json.loads((O/'selected_semantics_frozen.json').read_text());content=json.loads((O/'construction_content_frozen.json').read_text());sources=json.loads((O/'selected_author_records.json').read_text());by={a['question_id']:a for a in sources}
raw=(R/'revision_causal_input_packet_20261004/sources/longmemeval_oracle.json').read_bytes();assert sha(raw)==protocol['source']['sha256'];fullby={a['question_id']:a for a in json.loads(raw)}
for q,a in by.items():assert canon(a)==canon(fullby[q])
tp=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/data_prep/local/tokenizer/tokenizer.json');assert sha(tp.read_bytes())==protocol['construction']['tokenizer_sha256']
tok=Tokenizer.from_file(str(tp));tcpath=R/'revision_causal_input_packet_20261004/sources/qwen3_4b__tokenizer_config.json';tc=json.loads(tcpath.read_text());assert sha(tcpath.read_bytes())=='a62ff0a2472a0fa1b8eaabcb57c59b58afa42a22831dc141400b6e0cf2b65ce3';template=Environment().from_string(tc['chat_template'])
def enc(s):return tok.encode(s,add_special_tokens=False)
def render(msgs,gen=False):return template.render(messages=msgs,tools=None,add_generation_prompt=gen)
words=content['padding_vocabulary']
def pad(text,target,measure):
 i=0;steps=[]
 while measure(text)<target:
  n=measure(text)
  for off in range(len(words)):
   word=words[(i+off)%len(words)];trial=text+' '+word;m=measure(trial)
   if n<m<=target:
    text=trial;i+=off+1;steps.append(word);break
  else:raise ValueError('Cannot hit exact frozen token target')
  if len(steps)>2000:raise ValueError('Padding bound exceeded')
 assert measure(text)==target
 return text,steps
reservoir=copy.deepcopy(content['reservoir_seed_messages']);reservoir[-1]['content']+='\nNeutral margin:'
def reservoir_size(last):
 msgs=copy.deepcopy(reservoir);msgs[-1]['content']=last;return len(enc(render(msgs)).ids)
reservoir[-1]['content'],reservoir_words=pad(reservoir[-1]['content'],1024,reservoir_size)
reservoir_text=render(reservoir);reservoir_ids=enc(reservoir_text).ids;assert len(reservoir_ids)==1024
# No target strings or updates may be introduced by neutral material.
assert not re.search(r'negroni|emma|nightingale|kristin|finished|unfinished|\d',reservoir_text,re.I)
dump('reservoir_frozen.json',{'messages':reservoir,'canonical_text':reservoir_text,'canonical_token_ids':reservoir_ids,'ids_sha256':sha(canon(reservoir_ids)),'canonical_tokens':1024,'padding_words':reservoir_words,'semantic_scope':'Target-free layout text only; behavioral neutrality is not established.'})
variants=[];audits=[]
for p in plans:
 q=p['question_id'];a=by[q];assert p['semantic_review_status']=='approved_for_input_construction'
 olddate=p['old_report_date'];quote=p['old_quote'];rawslots={}
 for condition,owner in [('target','current user'),('peer','other user')]:
  rawslots[condition]='Archived duplicate. Original assertion date: '+olddate+'. Archive owner: '+owner+'. This repeats that dated assertion; it is not a new event.\nQuotation: "'+quote+'"\nNeutral margin:'
 assert len(enc(rawslots['target']).ids)==len(enc(rawslots['peer']).ids)
 target=len(enc(rawslots['target']).ids)+16
 padded,steps=pad(rawslots['target'],target,lambda s:len(enc(s).ids));suffix=padded[len(rawslots['target']):]
 slots={'target':padded,'peer':rawslots['peer']+suffix};assert len(enc(slots['peer']).ids)==target
 assert slots['target'].replace('Archive owner: current user','Archive owner: other user')==slots['peer']
 fam=[]
 for placement in ['reservoir_before','reservoir_after']:
  for condition in ['target','peer']:
   msgs=[{'role':'system','content':content['system']}];lineage=[{'kind':'system'}]
   def append_reservoir():
    msgs.extend(copy.deepcopy(reservoir));lineage.extend({'kind':'neutral_reservoir','index':i} for i in range(len(reservoir)))
   if placement=='reservoir_before':append_reservoir()
   for si,ss in enumerate(a['haystack_sessions']):
    if si==p['new_value_location']['session']:
     for k in range(3):
      msgs.extend([{'role':'user','content':slots[condition]},{'role':'assistant','content':'The dated quotation has been recorded with its stated owner.'}]);lineage.extend([{'kind':'archival_copy','copy_index':k,'owner':condition},{'kind':'archival_ack','copy_index':k}])
    for ti,t in enumerate(ss):
     msgs.append({'role':t['role'],'content':('Session date: '+a['haystack_dates'][si]+'\n' if ti==0 else '')+t['content']});lineage.append({'kind':'original_source','session':si,'turn':ti})
   if placement=='reservoir_after':append_reservoir()
   history_text=render(msgs);history_ids=enc(history_text).ids;hn=len(history_ids)
   msgs.append({'role':'user','content':'Current date: '+a['question_date']+'\nQuestion: '+p['query']});lineage.append({'kind':'final_query'})
   text=render(msgs,True);e=enc(text);assert e.ids[:hn]==history_ids
   bounds=[];ranges=[];prev=0
   for k in range(1,len(msgs)+1):
    pre=render(msgs[:k]);ids=enc(pre).ids;assert e.ids[:len(ids)]==ids
    bounds.append(len(ids));ranges.append([prev,len(ids)]);prev=len(ids)
   assert bounds[-2]==hn
   source_ranges=[];reservoir_ranges=[];copy_ranges=[]
   for i,l in enumerate(lineage):
    if l['kind']=='original_source':
     si,ti=l['session'],l['turn'];t=a['haystack_sessions'][si][ti]
     assert msgs[i]['role']==t['role'] and msgs[i]['content']==('Session date: '+a['haystack_dates'][si]+'\n' if ti==0 else '')+t['content']
     source_ranges.append({'session':si,'turn':ti,'role':t['role'],'content_sha256':sha(t['content'].encode()),'has_answer':t['has_answer'],'canonical_token_range':ranges[i]})
    if l['kind']=='neutral_reservoir':reservoir_ranges.append(ranges[i])
    if l['kind'] in ['archival_copy','archival_ack']:copy_ranges.append({**l,'token_range':ranges[i]})
   assert sum(b-a0 for a0,b in reservoir_ranges)==1024
   def locate(note):
    i=next(i for i,l in enumerate(lineage) if l.get('kind')=='original_source' and l.get('session')==note['session'] and l.get('turn')==note['turn'])
    pre=render(msgs[:i]);chunk=render(msgs[:i+1])[len(pre):];start=len(pre)+chunk.index(note['text']);end=start+len(note['text'])
    indices=[j for j,(s,t) in enumerate(e.offsets) if s<end and t>start];assert indices
    ts,te=min(indices),max(indices)+1
    return {**note,'char_range':[start,end],'token_range':[ts,te],'age_at_history_end':hn-te,'age_after_query':len(e.ids)-te,'wholly_in_last_1024_at_query':ts>=len(e.ids)-1024,'wholly_in_last_128_at_query':ts>=len(e.ids)-128}
   echoes=[locate(note) for note in p['current_semantic_echoes']];cues=[locate(note) for note in p['associated_cues']];old_echoes=[locate(note) for note in p['old_semantic_echoes']]
   oldspan=locate({'session':p['old_quote_location']['session'],'turn':p['old_quote_location']['turn'],'text':p['old_quote'],'kind':'original_old_quote'})
   hist_ends=[];prev=0
   for end in bounds[:-1]:
    hist_ends.extend(range(prev+128,end,128));hist_ends.append(end);prev=end
   assert hist_ends[-1]==hn and all(0<b-a0<=128 for a0,b in zip([0]+hist_ends[:-1],hist_ends))
   allends=list(hist_ends);prev=hn
   for end in [bounds[-1],len(e.ids)]:
    allends.extend(range(prev+128,end,128));allends.append(end);prev=end
   assert allends[-1]==len(e.ids)
   v={'variant_id':q+'__'+placement+'__'+condition,'question_id':q,'condition':condition,'placement':placement,'placement_interpretation':'nearer' if placement=='reservoir_before' else 'farther','added_quote_count':3,'added_target_relevant_old_copies':3 if condition=='target' else 0,'added_peer_same_string_copies':3 if condition=='peer' else 0,'canonical_prompt':text,'canonical_token_ids':e.ids,'canonical_prompt_sha256':sha(text.encode()),'canonical_ids_sha256':sha(canon(e.ids)),'total_input_tokens':len(e.ids),'history_tokens':hn,'query_absolute_start':hn,'query_suffix_token_ids':e.ids[hn:],'messages':msgs,'message_lineage':lineage,'recorded_message_end_indices':bounds,'history_online_chunk_end_indices':hist_ends,'all_online_chunk_end_indices':allends,'query_suffix_range':[hn,len(e.ids)],'original_source_token_ranges':source_ranges,'source_record_sha256':sha(canon(a)),'archival_ranges':copy_ranges,'reservoir_ranges':reservoir_ranges,'reservoir_tokens':1024,'old_evidence_span':oldspan,'old_semantic_echoes':old_echoes,'current_semantic_echoes':echoes,'associated_cues':cues,'last_direct_echo':max([x for x in echoes if x['kind'].startswith('explicit')],key=lambda x:x['token_range'][1]),'last_semantic_echo':max(echoes,key=lambda x:x['token_range'][1]),'last_associated_cue':max(cues,key=lambda x:x['token_range'][1]) if cues else None,'original_author_answer':a['answer'],'expected_latest_value':p['expected_latest_value'],'expected_report_session_date':p['expected_session_date'],'designated_stale_value':p['old_value'],'status':'FROZEN_INPUT_ONLY_NOT_MODEL_RESULT','inference_authorized':False}
   fam.append(v)
  rr,pp=fam[-2:]
  # Exactly three inserted content labels differ; system text remains identical.
  diffs=[]
  for i,(m,n) in enumerate(zip(rr['messages'],pp['messages'])):
   if m!=n:
    assert rr['message_lineage'][i]['kind']=='archival_copy'
    assert m['role']==n['role'] and m['content'].replace('Archive owner: current user','Archive owner: other user')==n['content'];diffs.append(i)
  assert len(diffs)==3 and rr['original_source_token_ranges']==pp['original_source_token_ranges']
 assert len({v['total_input_tokens'] for v in fam})==len({v['history_tokens'] for v in fam})==1
 for cond in ['target','peer']:
  near=next(v for v in fam if v['condition']==cond and v['placement']=='reservoir_before');far=next(v for v in fam if v['condition']==cond and v['placement']=='reservoir_after')
  for n,f in zip(near['original_source_token_ranges'],far['original_source_token_ranges']):
   assert [t-1024 for t in n['canonical_token_range']]==f['canonical_token_range']
  for n,f in zip(near['current_semantic_echoes'],far['current_semantic_echoes']):assert f['age_after_query']-n['age_after_query']==1024
 audits.append({'question_id':q,'prompts':4,'total_tokens':fam[0]['total_input_tokens'],'history_tokens':fam[0]['history_tokens'],'copy_tokens':target,'copy_padding_words':steps,'source_roles_content_dates_labels_preserved':True,'exact_owner_only_relevance_difference':True,'placement_source_shift_tokens':1024,'last_direct_echo_age_after_query':{v['placement']:v['last_direct_echo']['age_after_query'] for v in fam},'last_semantic_echo_age_after_query':{v['placement']:v['last_semantic_echo']['age_after_query'] for v in fam},'last_semantic_echo_wholly_in_last_1024_after_query':{v['placement']:v['last_semantic_echo']['wholly_in_last_1024_at_query'] for v in fam},'last_associated_cue_age_after_query':{v['placement']:v['last_associated_cue']['age_after_query'] for v in fam},'last_direct_echo_wholly_in_last_1024_after_query':{v['placement']:v['last_direct_echo']['wholly_in_last_1024_at_query'] for v in fam}})
 variants.extend(fam)
assert len(variants)==8 and 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'prompts').mkdir(exist_ok=False)
for v in variants:
 (O/'prompts'/f"{v['variant_id']}.txt").write_text(v['canonical_prompt'])
 (O/'prompts'/f"{v['variant_id']}.ids.json").write_text(json.dumps(v['canonical_token_ids'],separators=(',',':'))+'\n')
dump('constructed_inputs.json',variants);dump('construction_audit.json',{'families':audits,'prompts':8,'model_calls':0,'gpu_calls':0,'network_calls':0,'new_download_bytes':0,'tokenizers_version':tokenizers.__version__,'jinja2_version':jinja2.__version__,'torch_imported':False,'transformers_imported':False,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'source_population':'500-record oracle subset; not full LongMemEval-S histories','scope':'Input construction and symbolic positions only; no observed retention, serving effect, repetition-dose effect or novelty proof.'})
print(json.dumps(audits,indent=2))
