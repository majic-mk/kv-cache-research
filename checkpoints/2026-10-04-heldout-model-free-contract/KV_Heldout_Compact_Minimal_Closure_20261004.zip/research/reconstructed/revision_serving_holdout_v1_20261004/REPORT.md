# Held-out serving-interaction inputs: source-only preparation

Date: 2026-10-04 UTC. **Eight fixed inputs constructed and model-free validation passed. No inference, model load, GPU use, download, provider action or paid action occurred.** This packet does not authorize a 64-generation pilot or establish novelty, model competence, compression harm, or a new method.

## Fixed selection and exclusions

The reused public LongMemEval-cleaned oracle file has 500 records and SHA-256 `821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c`. Its original acquisition receipt and MIT notice are retained. These are complete **oracle** histories, not complete LongMemEval-S noisy histories.

Before new ranking or prompt rendering, `protocol_preselection_frozen.json` froze the source population, exclusion/grouping/hash rule, query template, construction, rubric and stopping rule. Its SHA-256 is `98676149515108bfd8e9bf01a2caf7613024f8d40873b2a8ea199fa2bb9e5cd0`.

The earlier ledger's 27 joint admissions were inherited; its 28 rejected/disputed rows were not reopened. The audit excludes development IDs `c7dc5443` and `6a1eabeb`, earlier audit anchors, their shared-history components, and conservatively matched volleyball/charity-5K histories despite different IDs. Across all 500 records, 18 semantic matches plus prior-anchor/component propagation exclude 22 records. Only the two original development rows intersect the 27 admitted candidates, leaving 25 eligible groups.

The graph checks shared session IDs and canonical role/content session hashes. Full-source review separately resolved generic shared advice phrases; neither was shared target evidence. Those flags and the initial pre-ranking assertion stop are preserved. The final exclusion/selection was independently recomputed across all 25 groups.

Rank is ascending SHA-256 of `revision-serving-holdout-v1|group_fingerprint`. The fixed first two are:

- `603deb26`: Negroni-at-home attempts since Emma taught the user. Old report: **5**, August 11, 2023. Latest report: **10 times**, November 30, 2023. Original author label remains `10`; original query date remains December 29, 2023
- `b01defab`: reading completion of *The Nightingale* by Kristin Hannah. Old report: **temporarily put down, unfinished**, January 21, 2023. Latest report: **finished**, March 30, 2023. Original author label remains `Yes`; original query date remains April 23, 2023

Both full histories, all 46 source turns, ownership, report dates, old quotes and semantic cues were independently reviewed. There are no detected shared source/target families with development or between the two selected records. This is source disjointness under the recorded audit, not a population-independence theorem for a synthetic corpus. No replacements were used or allowed.

## Frozen task and eight inputs

The task prospectively asks the most recently **reported** fact and its reporting **session date**. The date is not the event date or query date. The complete author facts and labels remain unchanged; the task wording is a declared modification, not unchanged benchmark evaluation.

Exact questions:

1. “According to the provided conversation history, what is the most recently reported number of times I have tried making a Negroni at home since my friend Emma showed me how to make it, and on which session date was it reported?”
2. “According to the provided conversation history, what is the most recently reported reading completion status for "The Nightingale" by Kristin Hannah, and on which session date was it reported?”

Each family has four inputs: exactly three **added** target-owned older quotations versus exactly three unrelated-peer same-string quotations, each with one fixed 1,024-token reservoir placed before versus after the source-plus-inserts. Every quotation is dated to the older reporting session and inserted immediately before the newer session. Copies never assert reinstatement or a new event. Original older/newer source evidence remains in both arms.

Within every matched target/peer pair, only three archive-owner labels differ. The selected quote, date, padding and all other text are identical. The final-v2 system/owner semantics and official chat template are reused. The reservoir is the same AB descriptive material and frozen neutral word sequence across both families and all arms. It is semantically target-free; behavioral neutrality is not assumed.

No low-zero/high-neutral arms exist. This is relevance of fixed added repetition, **not a repetition-dose experiment**. In particular, the book history already has several old-state echoes (S0T2/3/4/10/11); it is not a one-old-exposure source.

## Exact token and placement result

Only the existing pinned tokenizer was used: SHA-256 `aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4`, tokenizers 0.21.4 and Jinja2 3.1.6. No Torch or Transformers import occurred.

- Negroni: all four inputs **8,500 tokens**, history/query boundary **8,420**, query suffix **80**
- Nightingale: all four inputs **6,976 tokens**, history/query boundary **6,905**, query suffix **71**
- Source/evidence positions match exactly across relevance conditions. Moving the reservoir changes every original source position by exactly **1,024 tokens**, with unchanged total length and final-query position
- Recorded-message boundaries and complete-history canonical chunks of at most **128 tokens** are saved. Chunk counts are 82 for Negroni and 73 for Nightingale; this is an input schedule, not executed cache processing

Ages below count canonical tokens after each reviewed span through the full query suffix. “Nearer” means reservoir before source; “farther” means reservoir after source.

- Negroni last explicit/semantic count (S1T10): **467 → 1,491**
- Nightingale last explicit completion report (S1T8): **753 → 1,777**
- Nightingale conservative implicit completion echo (whole original S1T10): **322 → 1,346**
- Nightingale late associated discussion (S1T11): **106 → 1,130**

Both latest value/completion-echo spans are wholly inside the symbolic last-1,024-token suffix in the nearer placement and outside it in the farther placement. This is a deterministic **value/completion-echo recency-control boundary** result. The reporting-session date is printed at the newer session’s first turn, substantially earlier than these late echoes. The full value-plus-date evidence does not cross this boundary together; date binding and joint-answer accuracy remain separate requirements. Newer-date-header ages are **3,712 → 4,736** tokens for Negroni and **3,004 → 4,028** for Nightingale; neither header is inside last-1,024 in either placement. It does not certify TRIM retention: static TRIM's W=0 and 128-token trigger slack must not be conflated with a protected 1,024-token window. Placement still changes absolute position and age together; it does not isolate them. The book's implicit and associated cues must remain visible in interpretations. In the farther placement, all last-1,024 history rows belong to the reservoir: a last-N selector therefore drops every direct original-source row by construction. That expected source-row loss is not a discovered revision-specific failure; later contextual representations may still carry source information.

## Review, amendments, and verification

All semantic disputes were resolved and frozen before the first full prompt render. The pre-render freeze SHA-256 is `96811e8e2498f706fe2be7c94008634f5ee6cfcdda57d6d4c4d05ae87db12bee`.

Preserved amendments:

1. Initial source-selection script stopped before ranking on a generic 12-word advice overlap; full-turn semantic adjudication retained the flag without creating a false shared-history edge
2. Removed grammatical leading “my” from the book query attribute; promoted the late ending reaction into the semantic-age inventory
3. Used the whole unchanged S1T10 as the conservative book completion-echo boundary, separately preserved its clearest opening cue, and inventoried original old-state echoes

The original preselection file and its earlier recommendation binding were not rewritten. The later accepted recommendation hash `2014cf9c99a93826b354507df00fa42a4cd4e5e2114db94833fcd9af3e869bf5` is recorded as subsequent provenance.

`verification.json` reports 1,230 passed model-free assertions, covering source bytes/roles/dates/labels, exact canonical tokenization and hashes, boundaries, original date/query preservation, owner-only differences, source-position matching, fixed reservoir, echo positions and rank rule. Assertion count is software validation, not research observations; the independent sample count remains **two source families**. Final independent read-only audit also passed, rechecking all 61,904 token IDs, 280 message boundaries, 184 source-turn instances and 72 span coordinates; each target/peer pair differs at exactly three token IDs. See `independent_rendered_review.json`.

## Files and use boundaries

- `selected_author_records.json`, `source_provenance.json`: intact selected public records, full-source/session hashes and original receipt
- `protocol_preselection_frozen.json`, `exclusion_audit.json`, `ranked_families_frozen.json`: prospective criteria and complete inclusion/exclusion trail
- `selected_semantics_frozen.json`, `independent_source_review.json`: exact questions, quotes, expected answers/dates, and semantic review
- `pre_render_freeze.json`: before-render hashes
- `constructed_inputs.json`: all eight exact prompts, canonical IDs, message/chunk/evidence boundaries, dates, expected answers and metadata
- `prompts/*.txt` and `prompts/*.ids.json`: standalone exact prompt text and token IDs
- `construction_audit.json`, `verification.json`, `independent_rendered_review.json`: structural results and independent final audit; no model output
- `input_schedule_note.json`: recorded boundaries versus future runtime-call semantics
- `amendment_*.json`, preserved proposal/attempt files: source-only changes before outcomes

Scripts refuse to overwrite frozen build outputs. Reproduction requires an isolated clean output copy with the same pinned local dependencies and accepted source/semantic files; do not mutate this packet or the old development packets.

The original compressed/GPU packet remains closed following complete Full failure. The successful query-only diagnostic on its 7,624-token history established sensitivity to the **whole revised query**, not an isolated temporal mechanism or a new method. Construction here neither rescues that gate nor releases execution. Any later pilot needs separately applicable approval and the accepted bounded execution proposal; all selected families and outcomes must remain in its denominator.
