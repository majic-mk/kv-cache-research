"""Resolve independently agreed source-only annotations, then freeze before rendering."""
from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
review=json.loads((O/'independent_source_review.json').read_text());assert review['approved_for_rendering'] is True
plans=json.loads((O/'selected_semantics_proposed.json').read_text());source={a['question_id']:a for a in json.loads((O/'selected_author_records.json').read_text())}
for p in plans:
 p['semantic_review_status']='approved_for_input_construction';a=source[p['question_id']]
 p['old_semantic_echoes']=[{'session':0,'turn':p['old_quote_location']['turn'],'text':p['old_quote'],'kind':'explicit_old_state','explanation':'Original old-state report retained, before three added archival duplicates.'}]
 if p['question_id']=='b01defab':
  p['queried_attribute']='reading completion status for "The Nightingale" by Kristin Hannah'
  p['query']='According to the provided conversation history, what is the most recently reported '+p['queried_attribute']+', and on which session date was it reported?'
  cue=next(x for x in p['associated_cues'] if x['turn']==10);p['associated_cues'].remove(cue)
  p['clearest_implicit_completion_cue']=cue
  p['current_semantic_echoes'].append({'session':1,'turn':10,'text':a['haystack_sessions'][1][10]['content'],'kind':'implicit_context_supported_completed_reading','explanation':'First-person reaction to the ending and subsequent reflection in context support completed reading. Entire unchanged turn is conservative semantic-echo boundary; opening two sentences are clearest local cue. S1T8 remains last explicit completion report.'})
  spans={3:'You got this! With consistent effort, you should be able to finish "The Nightingale" in time for your book club discussion. Good luck, and I hope you\'ll enjoy the rest of the book!',4:'I think I\'ll stick to my original plan to pick up "The Poppy War" next, but it\'s good to know I can fit in "The Nightingale" later.',10:'Maybe they can suggest some books that will help me get back into "The Nightingale" too.',11:'By asking for their help, you\'re not only getting book recommendations, but also tapping into their expertise and passion for reading. So, don\'t be afraid to share your concerns, and I\'m sure you\'ll get some wonderful advice to help you get back into "The Nightingale" or discover new books that you\'ll love!'}
  for turn,text in spans.items():
   assert text in a['haystack_sessions'][0][turn]['content'];p['old_semantic_echoes'].append({'session':0,'turn':turn,'text':text,'kind':'unfinished_state_context_echo','explanation':'Original source still treats completing/returning to the target book as future at old session. This is an additional original-source old-state exposure, not an added copy.'})
  p['echo_policy']='S1T8 last explicit completion report; entire S1T10 user turn conservative implicit completion echo; S1T11 separate associated book discussion. Preserve all three boundary types and no absence/latent-state claim.'
 p['source_old_state_turns']=[{'session':x['session'],'turn':x['turn']} for x in p['old_semantic_echoes']]
 p['fixed_repetition_scope']='Exactly three ADDED obsolete quotation copies in each relevance condition; source original exposures preserved, not normalized. No repetition-dose or source-single-exposure claim.'
 for note in p['current_semantic_echoes']+p['associated_cues']+p['old_semantic_echoes']:assert note['text'] in a['haystack_sessions'][note['session']][note['turn']]['content']
content=json.loads((O/'construction_content_proposed.json').read_text());content['status']='APPROVED_AND_FROZEN_BEFORE_RENDERING';content['semantic_review_file']='independent_source_review.json'
for name,data in [('selected_semantics_frozen.json',plans),('construction_content_frozen.json',content)]:
 assert not (O/name).exists();(O/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
files=['protocol_preselection_frozen.json','exclusion_audit.json','ranked_families_frozen.json','selected_families_frozen.json','selected_author_records.json','selected_semantics_frozen.json','construction_content_frozen.json','independent_source_review.json','amendment_01_overlap_adjudication.json','amendment_02_pre_render_semantics.json','amendment_03_conservative_echo_boundaries.json','build_inputs.py','verify_inputs.py','source_provenance.json']
f={'status':'FROZEN_BEFORE_PROMPT_RENDERING_AND_ANY_OUTCOME','date_utc':'2026-10-04','files':{n:sha((O/n).read_bytes()) for n in files},'new_model_outputs_seen':False,'rendering_authority':'Input preparation only; independent source reviewer approval, no execution release.','no_cohort_replacement':True,'expected_queries':[p['query'] for p in plans]}
assert not (O/'pre_render_freeze.json').exists();(O/'pre_render_freeze.json').write_text(json.dumps(f,indent=2,ensure_ascii=False)+'\n');(O/'pre_render_freeze.sha256').write_text(sha((O/'pre_render_freeze.json').read_bytes())+'\n');print(sha((O/'pre_render_freeze.json').read_bytes()))
