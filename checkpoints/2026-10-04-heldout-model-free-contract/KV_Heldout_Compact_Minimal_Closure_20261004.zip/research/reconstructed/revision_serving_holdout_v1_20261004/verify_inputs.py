"""Independent model-free validation of canonical input artifacts."""
from pathlib import Path
import json,hashlib,sys,collections,datetime
from tokenizers import Tokenizer
from jinja2 import Environment
O=Path(__file__).resolve().parent;R=O.parent
sha=lambda x:hashlib.sha256(x).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
checks=[]
def check(ok,name):
 assert ok,name;checks.append(name)
p=json.loads((O/'protocol_preselection_frozen.json').read_text());f=json.loads((O/'pre_render_freeze.json').read_text())
for path,d in f['files'].items():check(sha((O/path).read_bytes())==d,'pre_render_hash:'+path)
raw=(R/'revision_causal_input_packet_20261004/sources/longmemeval_oracle.json').read_bytes();check(sha(raw)==p['source']['sha256'],'public_source_hash');by={x['question_id']:x for x in json.loads(raw)}
selected=json.loads((O/'selected_families_frozen.json').read_text());ranks=json.loads((O/'ranked_families_frozen.json').read_text());check(selected==ranks[:2],'top_two_rank_no_replacement');check([x['representative'] for x in selected]==['603deb26','b01defab'],'fixed_two_ids')
for r in ranks:check(r['rank_sha256']==sha(('revision-serving-holdout-v1|'+r['group_fingerprint']).encode()),'rank:'+r['representative'])
check(ranks==sorted(ranks,key=lambda r:(r['rank_sha256'],r['representative'])),'rank_order')
tp=Path('/workspace/scratch/a95be92193c8/kv_research_20261003/data_prep/local/tokenizer/tokenizer.json');check(sha(tp.read_bytes())==p['construction']['tokenizer_sha256'],'pinned_tokenizer_hash');tok=Tokenizer.from_file(str(tp))
config=R/'revision_causal_input_packet_20261004/sources/qwen3_4b__tokenizer_config.json';check(sha(config.read_bytes())=='a62ff0a2472a0fa1b8eaabcb57c59b58afa42a22831dc141400b6e0cf2b65ce3','pinned_chat_template_config');temp=Environment().from_string(json.loads(config.read_text())['chat_template'])
render=lambda m,g=False:temp.render(messages=m,tools=None,add_generation_prompt=g)
enc=lambda x:tok.encode(x,add_special_tokens=False).ids
variants=json.loads((O/'constructed_inputs.json').read_text());plans={x['question_id']:x for x in json.loads((O/'selected_semantics_frozen.json').read_text())};content=json.loads((O/'construction_content_frozen.json').read_text());reservoir=json.loads((O/'reservoir_frozen.json').read_text())
check(len(variants)==8 and len({v['variant_id'] for v in variants})==8,'exact_eight_unique_prompts');check(len(enc(render(reservoir['messages'])))==1024,'exact_reservoir_length')
for v in variants:
 name=v['variant_id'];q=v['question_id'];a=by[q];s=plans[q];m=v['messages'];line=v['message_lineage'];ids=v['canonical_token_ids'];hn=v['history_tokens']
 check(render(m,True)==v['canonical_prompt'],name+':template_render');check(enc(v['canonical_prompt'])==ids,name+':canonical_tokenization');check(sha(v['canonical_prompt'].encode())==v['canonical_prompt_sha256'],name+':prompt_hash');check(sha(canon(ids))==v['canonical_ids_sha256'],name+':id_hash');check(enc(render(m[:-1]))==ids[:hn],name+':history_exact_prefix')
 check(v['query_suffix_token_ids']==ids[hn:],name+':query_suffix');check(m[0]=={'role':'system','content':content['system']},name+':same_system');check(m[-1]['content']=='Current date: '+a['question_date']+'\nQuestion: '+s['query'],name+':frozen_query_and_original_date')
 check((O/'prompts'/f'{name}.txt').read_text()==v['canonical_prompt'],name+':text_file');check(json.loads((O/'prompts'/f'{name}.ids.json').read_text())==ids,name+':ids_file')
 original=[(i,l) for i,l in enumerate(line) if l['kind']=='original_source'];check(len(original)==sum(map(len,a['haystack_sessions'])),name+':full_source_turn_count')
 for i,l in original:
  si,ti=l['session'],l['turn'];t=a['haystack_sessions'][si][ti]
  check(m[i]['role']==t['role'] and m[i]['content']==('Session date: '+a['haystack_dates'][si]+'\n' if ti==0 else '')+t['content'],name+f':exact_source_{si}_{ti}')
 for sr in v['original_source_token_ranges']:
  t=a['haystack_sessions'][sr['session']][sr['turn']];check(sr['has_answer']==t['has_answer'] and sr['content_sha256']==sha(t['content'].encode()),name+f':labels_{sr["session"]}_{sr["turn"]}')
 check(v['source_record_sha256']==sha(canon(a)),name+':author_record_hash');check(v['original_author_answer']==a['answer'],name+':author_answer_unmodified')
 copies=[(i,l) for i,l in enumerate(line) if l['kind']=='archival_copy'];check(len(copies)==3,name+':three_copies')
 for i,l in copies:
  check(s['old_quote'] in m[i]['content'] and s['old_report_date'] in m[i]['content'],name+':exact_old_quote_date');check(('Archive owner: current user' if v['condition']=='target' else 'Archive owner: other user') in m[i]['content'],name+':owner_scope')
 newer_index=next(i for i,l in original if l['session']==s['new_value_location']['session']);check(max(i for i,_ in copies)<newer_index,name+':all_copies_before_new_session')
 check([m[i] for i,l in enumerate(line) if l['kind']=='neutral_reservoir']==reservoir['messages'],name+':identical_reservoir')
 prev=0
 for i,end in enumerate(v['recorded_message_end_indices']):check(enc(render(m[:i+1]))==ids[:end],name+f':boundary_{i}')
 ends=v['history_online_chunk_end_indices'];check(ends[-1]==hn and all(0<b-a0<=128 for a0,b in zip([0]+ends[:-1],ends)),name+':history_chunk_partition')
 for note in v['current_semantic_echoes']+v['associated_cues']+v['old_semantic_echoes']+[v['old_evidence_span']]:
  b,e=note['char_range'];tb,te=note['token_range'];check(v['canonical_prompt'][b:e]==note['text'],name+':span_text');check(note['text'] in a['haystack_sessions'][note['session']][note['turn']]['content'],name+':span_source');check(note['age_at_history_end']==hn-te and note['age_after_query']==len(ids)-te,name+':span_age')
 check(v['expected_report_session_date']==s['expected_session_date'],name+':gold_report_date');check(v['status']=='FROZEN_INPUT_ONLY_NOT_MODEL_RESULT' and v['inference_authorized'] is False,name+':no_inference_label')
for q in plans:
 fam=[v for v in variants if v['question_id']==q];check(len({v['total_input_tokens'] for v in fam})==1 and len({v['history_tokens'] for v in fam})==1,q+':matched_total_query_position')
 for place in ['reservoir_before','reservoir_after']:
  rr=next(v for v in fam if v['placement']==place and v['condition']=='target');pp=next(v for v in fam if v['placement']==place and v['condition']=='peer');diffs=[i for i,(a,b) in enumerate(zip(rr['messages'],pp['messages'])) if a!=b];check(len(diffs)==3,q+place+':exactly_three_message_differences')
  for i in diffs:check(rr['messages'][i]['content'].replace('Archive owner: current user','Archive owner: other user')==pp['messages'][i]['content'],q+place+':owner_only_change')
  check(rr['original_source_token_ranges']==pp['original_source_token_ranges'],q+place+':source_positions_equal')
 for cond in ['target','peer']:
  near=next(v for v in fam if v['condition']==cond and v['placement']=='reservoir_before');far=next(v for v in fam if v['condition']==cond and v['placement']=='reservoir_after')
  for n,f0 in zip(near['original_source_token_ranges'],far['original_source_token_ranges']):check([x-1024 for x in n['canonical_token_range']]==f0['canonical_token_range'],q+cond+':fixed_source_shift')
  check(far['last_direct_echo']['age_after_query']-near['last_direct_echo']['age_after_query']==1024,q+cond+':fixed_echo_age_shift')
check('torch' not in sys.modules and 'transformers' not in sys.modules,'no_model_runtime_imports')
result={'status':'PASS','checks_passed':len(checks),'checks':checks,'prompts':8,'independent_source_families':2,'model_calls':0,'gpu_calls':0,'network_calls':0,'scope':'Model-free artifact verification, not scientific effect or execution authorization.'}
assert not (O/'verification.json').exists();(O/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
