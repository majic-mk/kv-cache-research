"""Write source-only semantic proposal; no tokenization, prompt rendering or inference."""
from pathlib import Path
import json,hashlib,ast,datetime
O=Path(__file__).resolve().parent;R=O.parent
src=json.loads((O/'selected_author_records.json').read_text());by={a['question_id']:a for a in src}
def snippet(q,s,t,text,kind,why):
 assert text in by[q]['haystack_sessions'][s][t]['content'];return {'session':s,'turn':t,'text':text,'kind':kind,'explanation':why}
plans=[]
q='603deb26';a=by[q];old=a['haystack_sessions'][0][4]['content'];old=old[old.index('By the way,'):old.index(' Do you have any recommendations')]
p={'question_id':q,'semantic_review_status':'pending_independent_source_review','queried_attribute':'number of times I have tried making a Negroni at home since my friend Emma showed me how to make it','old_value':'5 attempts','new_value':'10 attempts','original_author_answer':a['answer'],'old_quote':old,'old_quote_location':{'session':0,'turn':4},'new_value_location':{'session':1,'turn':0},'latest_explicit_report_location':{'session':1,'turn':10},'old_report_date':a['haystack_dates'][0],'latest_report_date':a['haystack_dates'][1],'expected_latest_value':'10 times','expected_session_date':'2023-11-30','old_aliases':['5 times','five times'],'new_aliases':['10 times','ten times'],'current_semantic_echoes':[],'associated_cues':[]}
for t in [0,6,10]:
 text=a['haystack_sessions'][1][t]['content'];start=text.index("I've tried making");end=text.index('.',start)+1
 p['current_semantic_echoes'].append(snippet(q,1,t,text[start:end],'explicit_latest_count','Same first-person completed Negroni-at-home attempt count since Emma taught it; no new contradictory later count.'))
p['associated_cues'].append(snippet(q,1,7,"it's great that you're perfecting your Negroni game.",'target_associated_not_count','Acknowledges Negroni activity but does not identify or definitely corefer to a numeric count.'))
p['ownership_and_timing']='All original first-person user reports are about the same attempt slot since Emma taught the user. Latest report date is November 30 session, not dinner party date or December 29 query date. Source typo teached and complete source roles/labels remain unchanged.'
p['future_or_unrelated_mentions']='Plans to try other cocktails and recommendations/recipe quantities do not assert extra completed Negroni attempts; numeric recipe values are not count evidence.'
plans.append(p)
q='b01defab';a=by[q];old=a['haystack_sessions'][0][2]['content'];old=old[old.index('By the way,'):]
p={'question_id':q,'semantic_review_status':'pending_independent_source_review','queried_attribute':'my reading completion status for "The Nightingale" by Kristin Hannah','old_value':'unfinished; temporarily put down','new_value':'finished','original_author_answer':a['answer'],'old_quote':old,'old_quote_location':{'session':0,'turn':2},'new_value_location':{'session':1,'turn':0},'latest_explicit_report_location':{'session':1,'turn':8},'old_report_date':a['haystack_dates'][0],'latest_report_date':a['haystack_dates'][1],'expected_latest_value':'Finished reading The Nightingale (Yes)','expected_session_date':'2023-03-30','old_aliases':['put down temporarily','get back to'],'new_aliases':['recently finished "The Nightingale"','"The Nightingale" by Kristin Hannah, which I finished reading recently'],'current_semantic_echoes':[],'associated_cues':[]}
p['current_semantic_echoes'].append(snippet(q,1,0,'I also recently finished "The Nightingale" by Kristin Hannah, which was amazing, by the way.','explicit_completed_reading','Direct completed-reading report; does not require knowledge of the book.'))
p['current_semantic_echoes'].append(snippet(q,1,8,'By the way, I was thinking about "The Nightingale" by Kristin Hannah, which I finished reading recently.','explicit_completed_reading','Last explicit completion report; same March 30 session.'))
p['associated_cues'].append(snippet(q,1,1,'Based on your taste in "The Seven Husbands of Evelyn Hugo" and "The Nightingale", here are some suggestions:','title_taste_association','Names taste but not an explicit completion status.'))
p['associated_cues'].append(snippet(q,1,9,"What did you think of the ending?",'ending_question','Asks about the ending; not itself a direct assertion that the user finished.'))
p['associated_cues'].append(snippet(q,1,10,'I loved "The Nightingale"! Yes, the ending was emotional, but it was also a perfect conclusion to the story.','ending_experience_cue','User reacts to the ending and supports completed-reading interpretation in context; conservatively inventory it without claiming a new explicit completion assertion.'))
p['associated_cues'].append(snippet(q,1,11,'And I think that\'s one of the things that makes "The Nightingale" such an unforgettable read – it\'s a testament to the human spirit, and the ways in which people can find strength and courage in the face of unimaginable adversity.','assistant_shared_book_discussion','Later title/discussion cue retained; expresses opinion about book, not a new report of user completion.'))
p['ownership_and_timing']='Old temporary pause plus future finish question makes unfinished state clear; later user explicitly completed same title/author. Latest report March 30 session, not unknown event completion date or April 23 query date. Actual book facts/opinions in assistant turns are irrelevant to target truth and need no external checking.'
p['future_or_unrelated_mentions']='Future reading suggestions concern other books. Completion of The Seven Husbands of Evelyn Hugo is a distinct entity; do not treat it as target evidence. Source plot discussion is retained without validating literary details.'
plans.append(p)
for p in plans:
 a=by[p['question_id']]
 p['query']='According to the provided conversation history, what is the most recently reported '+p['queried_attribute']+', and on which session date was it reported?'
 p['query_date']=a['question_date']
 p['dates_verified_increasing_before_query']=all(datetime.datetime.strptime(d,'%Y/%m/%d (%a) %H:%M')<=datetime.datetime.strptime(a['question_date'],'%Y/%m/%d (%a) %H:%M') for d in a['haystack_dates']) and a['haystack_dates']==sorted(a['haystack_dates'])
 assert p['dates_verified_increasing_before_query'] and p['old_quote'] in a['haystack_sessions'][p['old_quote_location']['session']][p['old_quote_location']['turn']]['content']
 p['padding_and_copies_truth_rule']='Neutral layout text has no report about this target. Current-user archive repeats older assertion with old date; other-user archive is unrelated owner even when title/name/string matches. No copy is a new update; both truth states remain as author source.'
 p['scoring_detail']='An answer that says the old status/count is the latest reported state is stale. Clearly qualified older state plus correct latest state/date is correct. Correct current value with wrong report date is value-correct/date-wrong, never joint-correct. Unresolved simultaneous old/new endorsement is mixed; any stale endorsement is also flagged separately.'
 p['echo_policy']='Record all explicit/definite answer-bearing source spans, plus separate late associated cues. Token ages of both categories must be reported; no semantic-echo absence or latent-state claim.'
(O/'selected_semantics_proposed.json').write_text(json.dumps(plans,indent=2,ensure_ascii=False)+'\n')
# Extract existing, reviewed fixed descriptive material without executing builder.
oldbuilder=R/'revision_causal_v2_20261004/refinement_02_delimiter/build_variants.py'
vals={}
for n in ast.parse(oldbuilder.read_text()).body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['SYSTEM','reservoir','padwords']:vals[n.targets[0].id]=ast.literal_eval(n.value)
contract={'system':vals['SYSTEM'],'reservoir_seed_messages':[{'role':r,'content':s} for block in vals['reservoir'] for r,s in block],'order':'AB for every family/arm','padding_vocabulary':vals['padwords'],'reservoir_exact_tokens':1024,'reservoir_padding_rule':'Append newline Neutral margin: then deterministic padding words to final neutral assistant acknowledgment until canonical four-message reservoir is exactly 1024 tokens; earliest fitting word in cyclic frozen vocabulary, increment index by chosen offset+1. Stop on impossibility.','copy_padding_rule':'Use exact three historical copies and acknowledgment; each raw relevant/peer copy must have equal canonical token size. Append Neutral margin: and same deterministic 16-token padding to both; no condition-specific pad text.','source_builder_sha256':hashlib.sha256(oldbuilder.read_bytes()).hexdigest(),'status':'pending_independent_semantic_review_before_full_prompt_rendering'}
(O/'construction_content_proposed.json').write_text(json.dumps(contract,indent=2,ensure_ascii=False)+'\n')
print(json.dumps([{'id':p['question_id'],'query':p['query'],'old_quote':p['old_quote'],'expected':p['expected_latest_value'],'date':p['expected_session_date'],'echo_turns':[e['turn'] for e in p['current_semantic_echoes']]} for p in plans],indent=2))
