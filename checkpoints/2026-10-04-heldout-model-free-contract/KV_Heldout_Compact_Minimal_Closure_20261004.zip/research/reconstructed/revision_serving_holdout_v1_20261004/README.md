# Eight source-only held-out inputs

Start with [REPORT.md](REPORT.md). Exactly two prospectively hash-selected, source-disjoint families; three added target/peer obsolete quotes at two fixed 1,024-token-reservoir placements each.

- Negroni attempts: 10 times, reporting session November 30, 2023
- The Nightingale: finished, reporting session March 30, 2023

All eight input prompts and token IDs are frozen in `constructed_inputs.json` and `prompts/`. Source, exclusion, semantic review, amendments, dates, expected answers and boundaries are included. Model-free validation passed; no inference was performed or authorized. The old packet stays closed.
