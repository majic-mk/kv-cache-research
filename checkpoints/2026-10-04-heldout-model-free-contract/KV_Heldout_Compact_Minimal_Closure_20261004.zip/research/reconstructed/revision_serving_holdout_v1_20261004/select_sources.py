"""Offline source exclusion/selection, no model imports or outcomes."""
from pathlib import Path
import json,hashlib,re,itertools,collections,datetime
O=Path(__file__).resolve().parent;R=O.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def dump(n,x):
 p=O/n;assert not p.exists(),n;p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
c=json.loads((O/'protocol_preselection_frozen.json').read_text());assert sha((O/'protocol_preselection_frozen.json').read_bytes())==(O/'protocol_preselection_frozen.sha256').read_text().strip()
raw=(R/c['source']['path'].removeprefix('../')).read_bytes();assert sha(raw)==c['source']['sha256'];src=json.loads(raw);assert len(src)==500
by={a['question_id']:a for a in src};ledger=json.loads((R/'revision_causal_v2_20261004/eligibility_55_final.json').read_text());admit={a['question_id']:a for a in ledger if a['final_disposition']=='admit'}
def clean(a):return [[{'role':t['role'],'content':t['content']} for t in ss] for ss in a['haystack_sessions']]
fp={q:sha(canon(clean(a))) for q,a in by.items()}
for q,a in admit.items():assert a['family_fingerprint']==fp[q]
parent={q:q for q in by}
def root(q):
 while parent[q]!=q:parent[q]=parent[parent[q]];q=parent[q]
 return q
def union(a,b):parent[root(a)]=root(b)
seen={};edges=[]
for q,a in by.items():
 keys=['id:'+s for s in a['haystack_session_ids']]+['hash:'+sha(canon(s)) for s in clean(a)]
 for key in keys:
  if key in seen:union(q,seen[key]);edges.append({'left':seen[key],'right':q,'key':key})
  else:seen[key]=q
# Broad deliberately conservative semantic exclusion: any source mentioning volleyball,
# charity 5K in either order, the development club, or either development 5K numeric alias.
# This excludes generic-topic false positives rather than risk admitting a shared target family.
patterns=[r'volleyball',r'charity\s+5k',r'5k\s+charity',r'net\s+ninjas',r'27\s*:\s*12',r'25\s*:\s*50',r'27 minutes and 12 seconds',r'25 minutes and 50 seconds']
semantic=[]
for q,a in by.items():
 text='\n'.join(t['content'] for ss in a['haystack_sessions'] for t in ss)
 hits=[p for p in patterns if re.search(p,text,re.I)]
 if hits:semantic.append({'question_id':q,'patterns':hits,'reason':'Conservative development target/history semantic exclusion; no claim every broad match is literally same event'})
seeds=set(c['development_exclusion']['ids']+c['development_exclusion']['extra_conservative_source_only_prior_anchors'])|{r['question_id'] for r in semantic}
blocked_roots={root(q) for q in seeds};blocked={q for q in by if root(q) in blocked_roots}
# Full 12-word user-turn overlap audit among admitted sources and development anchors.
def ngrams(a):
 d=set()
 for ss in a['haystack_sessions']:
  for t in ss:
   if t['role']=='user':
    w=re.findall(r'\w+',t['content'].lower());d|={tuple(w[i:i+12]) for i in range(max(0,len(w)-11))}
 return d
ng={q:ngrams(by[q]) for q in set(admit)|seeds};flags=[]
for a,b in itertools.combinations(sorted(admit),2):
 common=ng[a]&ng[b]
 if common:flags.append({'left':a,'right':b,'shared_12grams':[' '.join(x) for x in sorted(common)],'adjudication':'Generic motivation-help request shared; different Fitbit-use-duration vs coding-practice targets and full histories. Not a shared evidence event.'})
assert [(x['left'],x['right']) for x in flags]==[('08e075c7','cc5ded98')]
devflags=[]
for a in sorted(set(admit)-blocked):
 for b in sorted(seeds):
  common=ng[a]&ng[b]
  if common:devflags.append({'candidate':a,'excluded':b,'shared_12grams':[' '.join(x) for x in sorted(common)]})
assert len(devflags)==1 and devflags[0]['candidate']=='6a27ffc2' and devflags[0]['excluded']=='d3ab962e',devflags
for flag in devflags:flag['adjudication']='Generic start-with advice question, not same target/evidence/history; source-only amendment_01 records full turns.'
components=collections.defaultdict(list)
for q in by:components[root(q)].append(q)
ranks=[]
for members in components.values():
 admitted=sorted(set(members)&set(admit))
 if not admitted or root(members[0]) in blocked_roots:continue
 fps=sorted({fp[q] for q in members});groupfp=fps[0] if len(fps)==1 else sha(canon(fps))
 q=admitted[0];rh=sha(('revision-serving-holdout-v1|'+groupfp).encode())
 ranks.append({'representative':q,'all_component_ids':sorted(members),'admitted_ids':admitted,'group_fingerprint':groupfp,'rank_sha256':rh,'author_question':by[q]['question'],'author_answer':by[q]['answer'],'old_review_value':admit[q]['review_old_value'],'new_review_value':admit[q]['review_new_value']})
ranks.sort(key=lambda r:(r['rank_sha256'],r['representative']))
audit={'source_sha256':sha(raw),'total_records':len(src),'existing_joint_admissions':len(admit),'all_source_history_edges':edges,'semantic_patterns':patterns,'semantic_exclusions_all_corpus':semantic,'excluded_component_ids':sorted(blocked),'candidate_exclusions':[{'question_id':q,'reason':'development/source-family exclusion'} for q in sorted(set(admit)&blocked)],'prior_nonadmitted_records':[{'question_id':a['question_id'],'disposition':a['final_disposition']} for a in ledger if a['final_disposition']!='admit'],'overlap_flags':flags,'remaining_candidates_overlap_development':devflags,'independent_eligible_components':len(ranks),'selection_model_outputs_used':False,'scope':'Source-disjoint under recorded mechanical and conservative semantic audit; no population independence theorem.'}
dump('exclusion_audit.json',audit);dump('ranked_families_frozen.json',ranks);dump('selected_families_frozen.json',ranks[:2]);dump('selected_author_records.json',[by[r['representative']] for r in ranks[:2]])
print(json.dumps({'eligible_components':len(ranks),'selected':ranks[:2]},indent=2))
