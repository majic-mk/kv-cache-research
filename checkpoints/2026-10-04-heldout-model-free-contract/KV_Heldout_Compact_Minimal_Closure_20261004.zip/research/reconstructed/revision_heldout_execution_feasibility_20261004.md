# Held-out KV pilot: execution feasibility and bounded-cost decision

2026-10-04 UTC. **Report only. Recommendation: STOP for now.** No model import, model execution, CUDA call, installation, provider/browser/server operation, purchase, credential action, or runtime/code change was performed. The only new files are this report and its structured arithmetic companion, `revision_heldout_execution_feasibility_20261004.json`.

## Decision

The logical model/cache sizes are plausible for a single 32 GB GPU, but there is **no verified practical execution path for this new 64-generation packet today**. The existing CUDA harness is source-prepared and mock-tested, not actual-device qualified; it is hard-bound to a different closed experiment. Its deployment never established a working image, installed runtime, actual CUDA/no-crop parity, reliable immediate billing stop, or reconciled prior cost. Changing a few configuration values would not make it eligible.

Do not run 64 file-paged CPU generations as a fallback. The independently audited CPU diagnostic took 810.726 seconds for only 50 selections/49 emitted tokens. Multiplying that observation by 64 gives 14.413 hours **as an illustration, not a forecast or bound**; this cohort and longer completions differ. The full-cap file-paged implementation would read up to 408,094,035,148,800 bytes of decoder weights across 56,160 forwards. No CPU/backend ladder is proposed.

One conditional route is specified below so a future decision can be concrete. It is a **new proposal requiring separate authorization and qualification**, not a request to spend now and not reuse of the earlier CNY15/two-hour permission. If its gates cannot be satisfied without another engineering/provisioning loop, stop this route rather than spend to discover that fact.

## Bound design, and what changed prospectively

The frozen scientific recommendation is `revision_heldout_success_branch_recommendation_20261004.md`, SHA-256 `2014cf9c99a93826b354507df00fa42a4cd4e5e2114db94833fcd9af3e869bf5`. It initially proposed released-default TRIM trigger gap 128. The additive design clarification `revision_heldout_common_budget_clarification_20261004.md`, SHA-256 `59c545fcaedf1634426b3b29a73664a632f9d3f036bb69a1e5409da8cf84867d`, now prospectively chooses **common zero post-history-call slack**: B=1,024, static TRIM buffer_size=1/W=0, and immediate post-forward recency/random crops on the same history boundaries. Neither old document nor any frozen input was rewritten.

This is a declared common-budget adaptation of released static TRIM, not untouched released-default performance. Online compressed arms finish each history call at min(seen,B); deferred arms retain Full history, then select B once at the pre-query seam. No selection follows that seam. The deferred Full-history ingestion-memory disadvantage must be visible in reporting. Original positions, masks, actual selected rows and all growth after the seam count.

Eight arms remain: native Full, gate-loaded no-crop Full, static TRIM online/deferred, original-position recency online/deferred, and fixed-priority keyed random online/deferred. The random implementation must bind its existing seed 1701, exact hash-key encoding/tie rule and resident-only selection prospectively; persistent priorities permit paired online/deferred final-set equality. No seed/budget/model/arm sweep is added.

The input packet has eight prompts and only two source families. `revision_serving_holdout_v1_20261004/constructed_inputs.json` is 1,489,179 bytes, SHA-256 `b7c95c4d2cf6429e5306702e571a593d5ab6e6e82708bbd743208d368996a753`. Independent rendered review SHA-256 is `98c4a94a2b2f10bd19e239513a1db6bf377eb6e0ddadd68674f6f1e7c113c23c`. All rows, including Full-wrong, cap-ended and generic-error rows, remain in the denominator. Numerical failure stops the packet; semantic wrongness does not select or replace cases.

Main costing uses the complete 80/71-token suffix in **one** forward, preserving the accepted author-path query convention. This must be explicitly bound in a future runtime contract. The extra final-user/assistant-header serialization boundaries are metadata, not permission for another query forward or eviction.

## Exact work envelope

All arithmetic is standard-library integer arithmetic over the frozen IDs/chunks, not measured inference.

| Quantity | Bound |
|---|---:|
| Four Negroni prompts | 8,500 input tokens each; 8,420 history + 80 query; 82 history forwards |
| Four Nightingale prompts | 6,976 input tokens each; 6,905 history + 71 query; 73 history forwards |
| All canonical input tokens across eight arms | 495,232 |
| Answer generations | At most 64, with no retries/replacements |
| Greedy selections | At most 51,200 = 64 × 800 |
| Emitted and fed output tokens | At most 51,136 = 64 × 799 |
| Total model forwards | At most 56,160 = 4 × 8 × (82+1+799) + 4 × 8 × (73+1+799) |
| Full/no-crop forward pairs | At most 7,020 pairs; 14,040 individual forwards |

These production counts exclude the separately bounded finite opening-device fixtures; those fixture operations, allocations and evidence still consume the same cost/time envelope and must be enumerated before release.

The author rule is select/record, then stop before emit/feed on EOS or selection index 799. The terminal selected ID must be retained separately even when discarded from returned text. EOS at index 799 is EOS, not a cap hit. Shorter EOS completion reduces actual work; it is not a license to forecast every future answer as short.

## Model, KV and physical-resource accounting

The exact Qwen3-4B-Instruct-2507 checkpoint and separate static gate are already verified locally. That does not establish their presence on any remote machine. Base revision is `cdbee75f17c01a7cc42f958dc650907174af0554`; gate revision is `89112809f83d05c3058eadcab4104abde5721b81`. Base parameters: 4,022,468,096 BF16 parameters = 8,044,936,192 bytes. Gate tensors: 94,704,192 bytes. Combined resident parameter payload: **8,139,640,384 bytes**, excluding allocator/framework state.

For batch one, 36 layers × 8 KV heads × 128 head width × K/V × two-byte BF16 = **147,456 bytes per logical resident row**. B alone is 150,994,944 KV bytes. The prepared adapter also stores int64 positions (2,304 bytes/row), BF16 gate log-beta (576 bytes/row when applicable), or int64 random priority (2,304 bytes/row). These metadata costs differ by policy.

| Arm | Max history rows before crop | History rows at query entry | Max resident rows including output | Max logical cache+policy metadata bytes |
|---|---:|---:|---:|---:|
| Native Full | 8,420 | 8,420 | 9,299 | 1,371,193,344 |
| Gate-loaded no-crop | 8,420 | 8,420 | 9,299 | 1,397,974,464 |
| TRIM online S=0 | 1,152 | 1,024 | 1,903 | 286,089,408 |
| TRIM deferred | 8,420 | 1,024 | 8,420 | 1,265,829,120 |
| Recency online | 1,152 | 1,024 | 1,903 | 284,993,280 |
| Recency deferred | 8,420 | 1,024 | 8,420 | 1,260,979,200 |
| Random online | 1,152 | 1,024 | 1,903 | 289,377,792 |
| Random deferred | 8,420 | 1,024 | 8,420 | 1,280,378,880 |

These are exact **logical payload maxima under the stated implementation representation**, not total VRAM peaks. Native/no-crop parameters plus logical cache alone reach about 9.54 GB. Concatenation keeps old/new layer tensors alive together; selection keeps old/gathered state together; scores, sorting workspace, native activations, allocator reservation and eager attention are additional. A conservative all-old-plus-all-new cache allowance is under 2.80 GB, but it still does not bound total CUDA allocation.

Eager attention materializes expanded 32-head K/V and attention intermediates. Conservative shape-only ceilings include 152,354,816 bytes for expanded K/V at 9,299 rows; at Q=128/K=8,500, a 34,816,000-byte boolean mask, 69,632,000-byte BF16 mask or attention matrix, and 139,264,000-byte FP32 softmax matrix. Some bounds occur at different calls and some intermediates coexist; do not add or subtract them to invent an exact allocator peak. BLAS/runtime scratch and host cold-load peaks remain unmeasured. Actual allocated/reserved/high-water and free memory must be recorded before/after load and every case, with active limits.

Candidate hardware is one 32 GB RTX 5090-class card with the **same qualified SM120/CUDA12.8 runtime**; the old 16-CPU/92-GB-host offer is only a historical candidate. It has not been re-quoted here. Prospective guards: ≥30,000,000,000 total GPU bytes, ≥2,000,000,000 free GPU bytes throughout, process-tree RSS <24,000,000,000 bytes, and at least 30 GB host MemAvailable before load. A guard threshold is not proof that the load fits; no oversubscribed/shared-device assumption or swap fit is allowed.

### Source-default128 alternative, not an extra run

The original >=B+128 trigger can leave up to 127 post-call extra rows. For these chunks, final online TRIM history rows are 1,137/1,075 for Negroni near/far and 1,145/1,075 for Nightingale near/far. Peak suffix-growth rows become 2,016. There are 354 online TRIM crop events rather than 540 under S=0. This changes occupancy, costs and potentially outputs. The structured report preserves this source-only arithmetic; it is not an authorized sensitivity arm or rescue option.

## Costs hidden by a simple KV-size estimate

Under the main S=0 design, every online compressed arm performs 540 all-layer crop events across eight prompts; each deferred arm performs eight. Total: **1,644 all-layer crop events**. There are 384,403,968 TRIM-score/random-sort candidate elements across their relevant crop calls. Random additionally computes permanent priorities on appended candidates. Gate evaluation, score/top-k/stable sorting, K/V/metadata gathers, synchronization, evidence and transfers all need separate timing.

If the old concatenate-every-forward layout is retained, the full-cap 64-case packet writes **26,264,086,792,704 bytes of appended cache tensors** and **253,730,488,320 bytes of gathered tensors** on device. These are algorithmic write-volume counts, not PCIe transfers or latency predictions. Read traffic and attention/MLP work add more.

The old debug strategy is particularly expensive:

- KV append hashes across all arms transfer 80,565,239,808 bytes to host
- Per-layer key-position hashes before every adapter call transfer 279,043,338,240 bytes
- Crop-state hashes transfer 253,730,488,320 bytes, including selected K/V and metadata
- Hashing every output vocabulary vector transfers 17,065,451,520 bytes, before separately saving raw answer/chunk vectors
- Its answer plus baseline input-vector saves would transfer another 15,939,909,632 bytes

Those five counted categories total **646,344,427,520 bytes** of device-to-host traffic at the cap, excluding opening fixtures, final state/position hashes, gate identity and repeated whole-backbone hashes. The prepared two-process stage layout adds roughly 48 GB of backbone hashing. The current CPU hashing path also performs many synchronous device copies, Python calls and fsync operations. Neither nominal GPU throughput nor small KV payload predicts this path's wall time. Merely deleting vector files while keeping every hash call does not remove their transfers.

## Prospective smaller evidence contract

The endpoint is complete-answer stale-error interaction, not distribution-level attribution. **Do not retain all-vocabulary vectors by default for this new packet.** The old all-vocabulary contracts and existing raw archives stay unchanged. This smaller contract is a proposal, requires acceptance before any output, and is not implemented or execution-approved.

Retain, without sampling or truncating:

1. Every exact source/prompt/tokenizer/model/gate/runtime/source-code hash and full frozen input/source files; original dates, source semantics, arm IDs/order/seed and cost/stop receipts
2. Every complete raw decoded answer and emitted-token ID list; every selected ID including the terminal discarded selection; emitted/fed flags; selection indices; natural EOS/cap/resource-censoring state. Store the selected-token probability and log-probability from a frozen FP32 normalization of the original logits, selected BF16 logit bits, and their exact dtype/encoding. This measures probability of the actual greedy token, not a counterfactual target answer
3. Exact native/no-crop same-call full-vector dtype/shape/byte-hash equality, every layer's appended K/V byte hashes and original-position range, all selected/emitted IDs/EOS/cap equality, model/gate immutability proofs, and signed/hash-bound parity results. No tolerance relaxation. Retain the actual input IDs and per-call schedule so all compared calls are auditable
4. Every actual selected original-position map for every layer/head/crop, with seen position, candidate/retained counts, original tensor dtype/shape and lossless serialized encoding; selected-set equality for paired recency/random; no-query/decode-selection proofs; prefix-survival counts and reset/mask/gather checks. Check actual gathered K/V against the selected old rows on-device and record the check result. Preserve original-position causality and no-recovery checks
5. All case/call phase timings, selector/gather/evidence and transfer-byte counters, allocated/reserved/free GPU peaks, process-tree RSS, disk and provider-cost/timer samples, failures and completion receipts. Score full answers against the complete source after inference, methods-hidden where practical

Efficiency choices that require a separately reviewed implementation:

- Keep baseline append hashes on CPU if necessary: maximum 20,141,309,952 D2H bytes, plus 4,266,362,880 bytes for baseline full-vector hashes. The resulting SHA-256 append digest payload is only 32,348,160 bytes. Thus exact baseline parity remains expensive but finite and explicitly charged
- Do not repeatedly hash unchanged/reconstructible position arrays on device. Transfer actual maps once per crop and validate append-only positions against the CPU schedule. Use exact on-device gather checks instead of copying every selected K/V tensor solely for debug hashes. Preserve all reset/mask/gather assertions; this changes the retrospective evidence format, not permission to skip runtime correctness checks
- Selected history positions fit in uint16 (<8,420). Store them losslessly as little-endian uint16 with checked int64 round-trip and an explicit original-dtype field. All 1,644 maps occupy exactly **969,670,656 bytes**, versus 3,878,682,624 bytes as int64. No deduplication or compression ratio is needed for that bound
- A 32-byte fixed record for each selected token/probability is 1,638,400 bytes maximum. Compact fixed-schema baseline/call metadata avoids millions of repeated JSON field names. Full text and all token IDs still remain

Proposed retained-evidence hard cap: **2,000,000,000 bytes**, with a prospectively tested bounded serializer. An allocation of 1,000 MB maps, 50 MB baseline hash/shape payloads, 2 MB selected-probability records, 20 MB answers/IDs, 256 MB call/crop metadata, 100 MB source/manifest bundle, 128 MB resource/debug logs, 64 MB indexes and 20 MB emergency-finalization reserve totals 1,740 MB. The spare 260 MB is headroom, not permission for extra cases. These category ceilings are engineering requirements, not claims an unimplemented writer has passed. Any category/total breach stops while preserving partials; it never silently drops evidence. Bounded logging and source bundles must be validated model-free before rental. Compression may save space, but no expected compression ratio is part of admission.

What this contract precludes: independent post-hoc reconstruction of all-vocabulary logits, alternate-token probabilities/ranks, entropy, KL/distribution divergence, teacher-forced answer scores, numerical residuals behind a hash mismatch, later score/top-k-margin analysis from unretained gate/score vectors, and independent reconstruction of selected K/V contents from raw tensors. Baseline byte-hash parity is retained, but raw-vector reinspection and independent recomputation of every argmax from archived logits are not. On-device argmax/finite/gather checks and hash-bound receipts must be distinguished from archived raw tensor evidence. Do not later claim those unavailable analyses without a separately authorized experiment.

## Deployment, disk and transfer bound

Existing local model verification does not avoid remote staging. The prepared cold bootstrap still requires 51 runtime wheels totaling **4,101,535,868 bytes**, base files **8,060,896,487 bytes**, and gate file **94,725,981 bytes**: **12,257,158,336 bytes of official downloads**, before installation/hash overhead. Its repacked Transformers wheel is another 13,830,288 bytes in the small upload. No fully cached CUDA wheelhouse or remotely ready image was established. A stock image matching a Torch version string is not a qualified reuse path.

The old fifteen-minute 0.5-CPU/2-GB no-card setup was never certified. Transfer alone would require 13.62 MB/s continuously for all 900 seconds, or 20.43 MB/s with five minutes reserved for installation/hash checks. These are required arithmetic rates, not measured service performance. No fresh image ladder, local multi-GB staging project or automatic retry is proposed.

At least a 50 GB target data volume remains a reasonable candidate, but actual free bytes and installed sizes must be measured. Retaining the existing wheels, base/gate, repacked wheel, 2 GB evidence, a 2.1 GB temporary archive and a 6 GB free reserve requires **22,370,988,624 bytes plus the installed environment, other upload/source files and existing disk use**. Installed size is unknown, so this is a conditional inventory bound, not a certified 30 GB fit. Preserve the 6 GB free floor. Staging/base transfer and the final evidence export are included in wall time and any network/storage fees. Do not keep a GPU powered merely for setup, compression, semantic review or export.

## Cost status and the one conditional proposal

**Current new spending authority: none. Current verified project remaining balance: unknown.** The user-level total project cap is CNY100. The parent reports two owned instances failed image pull and disappeared, while a third submission returned HTTP502 with no instance ID. Actual charges and the third request's final resource state were not rechecked in this report-only task. They must not be assigned zero cost or treated as proof no resource exists.

Historical AutoDL quote: CNY2.78/hour for one RTX5090 32 GB offer, with then-visible free 30+50 GB disks and CNY0.10/hour no-card mode. That quote is stale. It does not establish today's availability, mandatory fees, billing quantum, image health, shutdown semantics or price. The earlier CNY15/two-hour permission belonged to the closed window and cannot authorize this packet.

If the user later chooses to revisit this route, the only proposed execution envelope is:

- One newly identified isolated 32 GB GPU instance, one GPU power start, at most 64 predeclared answer generations and no reruns
- **The observed AutoDL provider flow does not currently satisfy this strict single-start route.** The parent reports that creation boots the GPU; using no-card bootstrap can then require an immediate GPU stop followed by a second GPU start for productive inference. No direct create-off/no-card path was demonstrated. This proposal therefore remains blocked for that observed flow. It does not authorize a second start, a speculative alternative creation route or a retry; even brief creation/boot seconds and their billing rounding must count in any separately considered future proposal
- A new **CNY10 maximum incremental all-in cost**, subject to a verified project ledger establishing `past settled charges + upper bound of pending/unknown liabilities + this CNY10 <= CNY100`. Unknown liabilities need a provider-supported upper bound or reconciliation before anything new is created
- At most **7,200 seconds absolute** from the first billable preparation operation through termination, and at most 7,200 cumulative powered seconds across GPU/no-card modes; unused GPU stopped immediately; at most one bounded 900-second no-card setup if a working non-GPU setup path is already verified. No resets/extensions. Preserve at least 180 seconds for finalization, with a verified provider stop deadline independent of the worker
- The live price calculation must include per-start rounding, setup/no-card/storage/network/tax/fixed fees and any cancellation/minimum charges. At the old prices only, two rounded GPU hours plus one rounded no-card hour would be CNY5.66 before other charges. This is an illustration, not a current offer or a completion forecast. If the actual all-in ceiling exceeds CNY10, do not create/start
- Stopping GPU billing must not leave unbounded chargeable storage or another recurring commitment. If storage is not free after shutdown, its full approved retention period and a supported, authorized termination mechanism must fit the cap before creation; destructive deletion is not authorized by this proposal
- One continuous GPU computation session: finite opening checks; eight native Full plus eight no-crop cases; numerical/identity/resource admission only; then the 48 compressed cases. Full correctness is scored offline, never used as a cohort gate. No human semantic-review pause requires a second GPU load. Any real pause ends billing immediately and the packet is resource-censored rather than automatically restarted

This envelope bounds allowed loss; it does not promise 64-case completion. Before admitting remaining cases, the complete measured load/parity/prefill/decode/selection/gather/evidence path must support a conservative remaining-work estimate under the **800-selection cap and longest cache**, including reserve. Short observed answers alone are insufficient. Hard time/cost guards remain controlling even when forecasts are optimistic. An inability to establish a credible completion prospect is a stop, not authority for an open-ended benchmark or cap reduction.

## Required live preflight and minimal stop plan

These are future requirements only. No commands or provider actions were executed here.

1. **Before any paid creation:** reconcile the failed/ambiguous submissions and charges read-only, identify only resources owned by this project, confirm other instances are untouched, verify current itemized quote/terms and project headroom, and obtain a fresh explicit approval for the exact instance/service, CNY cap, mode, time bound, storage and any mandatory terms. Inspect current image availability and supported access; no credential/access grant is implicit
2. **Before any GPU start:** a separately reviewed new packet must bind the eight input hashes, additive S=0 clarification, one-shot suffix feed, author 800-selection termination, numerical-only admission, compact evidence schema and run identity. Tests must be model-free and cover the exact full work plan, caps, failure/partial preservation, independent paired-map recomputation, selection boundaries, and watchdog behavior. Do not unlock or mutate the closed old harness. The target must already have exact installed runtime/asset/source receipts, storage headroom and measured staging completion
3. **Resource/control proof:** verify actual instance ID, GPU count/type/SM120/available memory, host/disk limits, clock/time origin, fresh provider scheduled shutdown and a ready named controller capable of immediate non-destructive shutdown. Verify the previous stop actually ended GPU billing before trusting any future restart. A local kill or JSON request is not provider billing-stop evidence. If no verified provider stop path exists, no GPU start
4. **Finite actual-device opening gate:** exact Torch2.9.1+cu128, CUDA12.8 build/driver support, compiled sm_120, pinned Transformers/Qwen3 source, BF16 kernel, native FP32 RoPE internals/norm behavior, immutable base plus separate gate, deterministic settings, reset/original-position/multi-token future-leakage/gather checks, and actual same-call no-crop parity. Record real load/VRAM/RSS and evidence-write overhead. Numerical/shape/runtime mismatch stops; no tolerance widening, compilation route, fallback backend or repeated opening trials
5. **Bounded production gate:** consume only the saved IDs/chunks. Numerical parity is mandatory for every Full/no-crop pair, not just a tiny fixture. Failed semantic answers and natural cap terminations are retained as outcomes; hard-resource cutoff is separately recorded as censoring. Every compressed arm freezes selection before the query and charges all suffix growth. Fixed case order is set before output. Each unique attempted row is at most once
6. **Every completion, pause, failure or controller disconnect:** terminate only the verified project process group, immediately invoke the preverified non-destructive provider stop, and verify the actual stopped/billing-stopped state and timestamp. Preserve partials and retrieve/archive them with GPU off where supported. Do not delete instance/data, borrow or stop another instance, renew the lease, restart automatically, or spend past the cap to rescue evidence. If the provider/control state is uncertain, report the exact uncertainty promptly and resolve the owned resource state before any new creation

No prospective source preparation, successful tiny test, cached model, or generated proposal itself releases these gates. The current practical recommendation remains **stop for now**.

## Sources and verification limits

The structured JSON companion includes every input ID hash, per-case S=0/S128 arithmetic and exact source-file hashes. Key local source locations:

- `revision_heldout_common_budget_clarification_20261004.md` and `.freeze.json`: additive S=0 choice, not authority to execute
- `revision_serving_holdout_v1_20261004/{REPORT.md,input_schedule_note.json,constructed_inputs.json,independent_rendered_review.json}`: exact cohort, suffix/chunk definitions and source-only validation
- `revision_gpu_pilot_20261004/protocol.py:32-62,106-122`: old 16-row input binding, split schedule, 64-token plan and all-correct gate
- `revision_gpu_pilot_20261004/cuda_backend.py:120-130,149-174,252-264,289-371`: synchronous hashing, hardcoded decode, append capture, masks, gather and debug evidence
- `revision_gpu_pilot_20261004/pilot.py:57-102`: old 32+96 staging, EOS admission and unchanged 128-case completion claims
- `revision_gpu_pilot_20261004/{harness_status.json,run_guard.py}`: mock-only status and explicit lack of provider billing termination
- `revision_gpu_deployment_20261004/{deployment_sizes.json,README.md,IMAGE_PORTABILITY_REVIEW.md}`: exact cold transfer inventory and unverified target fit
- `revision_temporal_scope_diagnostic_20261004/{decode_contract.py,protocol.json}`: exact 800-selection/799-emission author semantics and file-paged weight-read bytes
- `revision_temporal_scope_diagnostic_review_20261004/terminal_audit.json`: 810.726-second diagnostic, 49 emitted tokens, 3,680,804,864-byte measured RSS; CPU only
- Pinned `transformers/models/qwen3/modeling_qwen3.py`, SHA-256 `2b768b0eb0aacf1478bba1dc84318126c6c68fecb0ac9465f70154f24da4a80d`: eager attention and native arithmetic; inspected as text only

No fresh web/provider quote was obtained because this assignment prohibited provider/server/browser operations. Current price, charges, shutdown behavior, image health, target installed size, actual CUDA parity and actual full-cap runtime remain unknown. No performance, compressed accuracy, scientific interaction or novelty is established by this report.

## Revision 2 correction receipt

2026-10-04 UTC. Corrected the deferred Full-history ingestion cost to a memory disadvantage. Explicitly marked the strict single-GPU-start conditional route as unsatisfied by the parent-reported create-and-boot plus no-card bootstrap flow. No second start or alternative provider route is authorized. The complete prior report and arithmetic companion are preserved byte-for-byte as `.revision01.md` and `.revision01.json`; no underlying calculation or frozen scientific/source artifact changed. No new research, execution or provider action was performed for this correction.
