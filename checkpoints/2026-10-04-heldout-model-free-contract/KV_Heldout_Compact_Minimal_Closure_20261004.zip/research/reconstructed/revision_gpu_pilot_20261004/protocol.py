"""Pure-stdlib frozen protocol, plan, bounded evidence and semantic gates."""
from pathlib import Path
import hashlib
import gzip
import json
import os
import struct
import time
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING

if not __debug__:
    raise RuntimeError('OPTIMIZATION_FORBIDDEN: all protocol/admission checks must remain active')

P=Path(__file__).resolve().parent
ROOT=P.parents[2]

def sha_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(8*1024*1024): h.update(block)
    return h.hexdigest()

def canonical_hash(value):
    # Normalize integer mapping keys and tuples through JSON before sorting, so
    # hashes survive evidence write/read round trips without key-order changes.
    normalized=json.loads(json.dumps(value,allow_nan=False))
    return hashlib.sha256(json.dumps(normalized,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def load_config():return json.loads((P/'pilot_config.json').read_text())

def load_inputs(root=ROOT, config=None):
    c=config or load_config();path=Path(root)/c['input_file']
    assert sha_file(path)==c['input_sha256'],'Frozen input file changed'
    rows=json.loads(path.read_text());assert len(rows)==16
    assert [r['variant_id'] for r in rows]==c['variant_order'],'Input order changed'
    for r in rows:
        ids=r['canonical_token_ids'];ends=r['online_chunk_end_indices']
        assert hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()==r['canonical_ids_sha256']==c['canonical_id_hashes'][r['variant_id']]
        assert len(ids)==r['total_input_tokens'] and r['history_tokens']==r['query_absolute_start']
        assert ends==sorted(set(ends)) and ends[-1]==len(ids) and r['history_tokens'] in ends
        assert all(0<b-a<=128 for a,b in zip([0]+ends[:-1],ends))
        assert len(r['message_lineage'])==len(r['recorded_message_end_indices'])
        assert r['source_verbatim_preserved'] is True
    assert sum(len(r['canonical_token_ids']) for r in rows)==128376
    return rows

def chunks(row):
    start=0
    for end in row['online_chunk_end_indices']:
        lineage=[i for i,(a,b) in enumerate(zip([0]+row['recorded_message_end_indices'][:-1],row['recorded_message_end_indices'])) if a<end and b>start]
        phase='history' if end<=row['history_tokens'] else 'query'
        assert not start<row['history_tokens']<end
        yield {'start':start,'end':end,'phase':phase,'message_indices':lineage,
               'session_labels':[row['message_lineage'][i] for i in lineage]}
        start=end

def fixed_plan(rows,c):
    return [{'case_index':i*16+j,'arm':a['id'],'variant_id':r['variant_id'],
             'input_sha256':r['canonical_ids_sha256'],'chunks':list(chunks(r)),
             'history_boundary':r['history_tokens'],'generation_cap':64}
            for i,a in enumerate(c['arms']) for j,r in enumerate(rows)]

def priority(seed,layer,head,position):
    raw=hashlib.sha256(b'revision-pilot-priority-v1\0'+struct.pack('<QQQQ',seed,layer,head,position)).digest()[:8]
    return int.from_bytes(raw,'little',signed=True)

def control_selection(positions,policy,budget,seed=1701,layer=0,head=0):
    if policy=='last_n':return sorted(positions)[-budget:]
    assert policy=='random'
    return sorted(sorted(positions,key=lambda p:(-priority(seed,layer,head,p),p))[:budget])

def verify_source_manifest():
    manifest=json.loads((P/'source_manifest.json').read_text())
    for r in manifest['files']:
        assert sha_file(P/r['path'])==r['sha256'],f"Source/parameter changed: {r['path']}"
    return canonical_hash(manifest)

class Evidence:
    """Append-only, exclusive files; hard retained-data ceiling, no silent dropping."""
    def __init__(self,path,limit=6_000_000_000,min_free=6_000_000_000,namespace=None,binding=None):
        self.binding=binding or {}
        self.root=Path(path);self.path=self.root/namespace if namespace else self.root
        self.path.mkdir(parents=True,exist_ok=True)
        self.limit,self.min_free=limit,min_free
        self.records=[];self.write_seconds=0.;self.writes=0;self.bytes=sum(f.stat().st_size for f in self.root.rglob('*') if f.is_file())
        self.check(0)
    def check(self,new):
        assert self.bytes+new<=self.limit,'Evidence limit reached: stop, preserve partials'
        fs=os.statvfs(self.path);assert fs.f_bavail*fs.f_frsize-new>=self.min_free,'Disk reserve reached'
    def put(self,name,data,metadata=None,compress=False):
        started=time.perf_counter()
        raw=data;digest=hashlib.sha256(raw).hexdigest()
        if compress:data=gzip.compress(raw,compresslevel=1,mtime=0)
        self.check(len(data));target=self.path/name;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        self.bytes+=len(data)
        record={'path':str(target.relative_to(self.root)),'bytes':len(data),'uncompressed_bytes':len(raw),'raw_sha256':digest,'codec':'gzip' if compress else 'none','metadata':metadata or {},'run_binding':self.binding}
        self.records.append(record)
        with (self.path/'manifest.jsonl').open('a') as f:
            line=json.dumps(record,sort_keys=True)+'\n';self.check(len(line));f.write(line);f.flush();os.fsync(f.fileno());self.bytes+=len(line)
        self.write_seconds+=time.perf_counter()-started;self.writes+=1
        return record
    def json(self,name,value):return self.put(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())

def semantic_gate_only(rows,results,review,config_hash):
    """Semantic decisions are external review, never substring inference."""
    expected={(a,r['variant_id']) for a in ('full','no_crop') for r in rows}
    assert {(x['arm'],x['variant_id']) for x in results}==expected and len(results)==32
    assert review['config_sha256']==config_hash and review['result_sha256']==canonical_hash(results)
    assert review['reviewer'] and review['review_method']=='independent_researcher_or_agent_semantic_source_review'
    assert review['rubric_accepts_qualified_historical_plus_current'] is True
    assert review['old_value_substring_is_error'] is False
    judgments=review['judgments'];assert set(judgments)=={r['variant_id'] for r in rows}
    for r in rows:
        j=judgments[r['variant_id']]
        assert j['full_semantically_correct'] is True and j['no_crop_semantically_consistent'] is True
        assert j['rationale'] and j['source_reference']
    for result in results:
        assert result['eos_reached'] and not result['cap_hit'] and result['generated_ids']
        assert result['parity_passed'] is True and result['backbone_immutable'] is True
    return {'passed':True,'result_sha256':canonical_hash(results),'review_sha256':canonical_hash(review),'config_sha256':config_hash}

def semantic_review_template(rows,results,config_hash):
    return {'status':'PENDING_DO_NOT_AUTOFILL','reviewer':'','review_method':'independent_researcher_or_agent_semantic_source_review',
            'config_sha256':config_hash,'result_sha256':canonical_hash(results),
            'rubric_accepts_qualified_historical_plus_current':True,'old_value_substring_is_error':False,
            'judgments':{r['variant_id']:{'full_semantically_correct':None,'no_crop_semantically_consistent':None,
                        'rationale':'','source_reference':'','current_value_reference':r['review_current_value'],
                        'competitor_reference_not_substring_rule':r['review_competitor_value'],
                        'complete_source':'frozen canonical_prompt in active input file'} for r in rows}}

def require(condition,message):
    if not condition:raise RuntimeError(message)


def validate_approval(receipt,c,evidence_root=None):
    """Exact quote, whole-duration upper cost, run/root/lease and billing-stop binding."""
    require(evidence_root is not None,'Approval must bind one evidence root')
    require(receipt.get('explicit_user_approval_reference'),'Explicit approval reference missing')
    require(receipt.get('approved_config_sha256')==sha_file(P/'pilot_config.json'),'Approved config changed')
    require(receipt.get('quote')==c['verified_quote'],'Exact inspected quote changed or missing')
    require(receipt.get('currency')=='CNY','Approval currency must be CNY')
    require(receipt.get('run_id') and receipt.get('lease_id') and receipt.get('provider_instance_id'),'Run and lease identity required')
    require(receipt['pilot_start_unix']<=time.time()<receipt['pilot_absolute_deadline_unix']<=receipt['pilot_start_unix']+7200,'Original absolute two-hour pilot envelope exceeded')
    require(Path(receipt.get('evidence_root','')).resolve()==Path(evidence_root).resolve(),'Approval bound to another output root')
    seconds=receipt.get('maximum_authorized_powered_on_seconds')
    require(type(seconds) is int and 0<seconds<=7200,'Duration exceeds approved two-hour bound')
    approved=Decimal(str(receipt.get('approved_total_cost_cny')))
    require(approved.is_finite() and 0<approved<=Decimal('15.00'),'Approval exceeds CNY15 or is invalid')
    q=receipt['quote']
    money={k:Decimal(str(q[k])) for k in ('hourly_rate_cny','hourly_addons_cny','daily_disk_fee_cny','other_daily_mandatory_fee_cny','one_time_fees_cny','tax_or_other_fixed_fees_cny')}
    require(all(v.is_finite() and v>=0 for v in money.values()),'Invalid fee amount')
    # Conservative rounding covers the allowed initial GPU boot plus Stage A/B
    # restarts and one optional no-card preparation period; actual costs are logged.
    cycles=c['approval_policy']['maximum_gpu_power_starts']
    hours=Decimal((seconds+3599)//3600+cycles-1);days=Decimal((seconds+86399)//86400)
    no_card_upper=Decimal((seconds+3599)//3600)*Decimal(q['no_card_hourly_rate_cny'])
    maximum=(hours*(money['hourly_rate_cny']+money['hourly_addons_cny'])+days*(money['daily_disk_fee_cny']+money['other_daily_mandatory_fee_cny'])+money['one_time_fees_cny']+money['tax_or_other_fixed_fees_cny']+no_card_upper).quantize(Decimal('.01'),rounding=ROUND_CEILING)
    require(maximum<=approved and maximum<=Decimal('15.00'),'Quote times authorized duration plus fees exceeds approved cap')
    require(Decimal(str(receipt.get('computed_maximum_charge_cny')))==maximum,'Recorded maximum charge differs from exact fee calculation')
    require(receipt.get('provider_scheduled_shutdown_stops_billing_verified') is True,'Verified billing-stopping scheduled shutdown required')
    require(receipt.get('scheduled_shutdown_evidence') and receipt.get('shutdown_authorized') is True,'Scheduled-shutdown evidence/permission missing')
    require(receipt.get('destructive_deletion_required') is False,'No instance/data deletion is required or authorized here')
    require(receipt.get('setup_and_base_acquisition_authorized') is True,'Setup/base acquisition not authorized')
    controller=receipt['immediate_shutdown_controller']
    require(controller['ready'] is True and controller['reference'] and controller.get('readiness_evidence') and controller.get('completion_event_delivery_verified') is True and controller['non_destructive'] is True,'Immediate billing-stop controller not ready')
    require(controller['on_every_exit'] is True,'Shutdown must occur on semantic pause, failure and completion')
    cycle=receipt['power_cycle'];previous=receipt['previous_power_cycles']
    require(cycle['execution_stage'] in ('stage-a','stage-b') and cycle['power_mode']=='gpu','Wrong execution power mode/stage')
    require(len(previous)<c['approval_policy']['maximum_power_cycles'],'Unexpected power-cycle/retry count')
    require(sum(p['power_mode']=='gpu' for p in previous)<c['approval_policy']['maximum_gpu_power_starts'],'GPU power-start ceiling')
    require(sum(p['power_mode']=='no_card' for p in previous)<=c['approval_policy']['maximum_no_card_power_starts'],'No-card power-start ceiling')
    spent_seconds=0.;spent_cost=Decimal('0')
    for old in previous:
        require(old['run_id']==receipt['run_id'] and old['provider_instance_id']==receipt['provider_instance_id'],'Prior powered period belongs to another run/instance')
        require(old['billing_stopped_verified'] is True and old['shutdown_evidence'],'Prior GPU billing stop not verified')
        require(old['power_mode'] in ('gpu','no_card'),'Unknown prior paid mode')
        duration=old['stop_unix']-old['start_unix'];require(duration>=0,'Invalid prior powered duration')
        charge=Decimal(str(old['actual_charge_cny']));require(charge.is_finite() and charge>=0,'Invalid prior actual charge')
        spent_seconds+=duration;spent_cost+=charge
    start=cycle['start_unix'];stop=receipt['absolute_stop_unix'];shutdown=receipt['scheduled_shutdown_unix']
    require(type(cycle['maximum_seconds']) is int and cycle['maximum_seconds']>0,'Invalid cycle duration')
    remaining=seconds-spent_seconds
    require(remaining>0 and cycle['maximum_seconds']<=remaining,'Cumulative two-hour powered-on allowance exhausted')
    require(start<=time.time()<shutdown<=stop<=min(start+cycle['maximum_seconds'],receipt['pilot_absolute_deadline_unix']),'Current-cycle absolute shutdown deadline invalid')
    require(not previous or previous[-1]['stop_unix']<=start,'Overlapping powered-on cycles')
    current_upper=Decimal((cycle['maximum_seconds']+3599)//3600)*(money['hourly_rate_cny']+money['hourly_addons_cny'])+days*(money['daily_disk_fee_cny']+money['other_daily_mandatory_fee_cny'])+money['one_time_fees_cny']+money['tax_or_other_fixed_fees_cny']
    require(spent_cost>=0 and spent_cost+current_upper<=approved and spent_cost+current_upper<=Decimal('15.00'),'Actual prior cost plus remaining quote exceeds cap')
    require(receipt['provisioned_disk_bytes']>=c['limits']['minimum_server_disk_capacity_bytes'],'Disk allocation below requirement')
    setup=receipt['setup_acquisition_receipt']
    require(isinstance(setup,dict),'Setup receipt missing')
    require(all(isinstance(setup[k],(int,float)) and setup[k]>=0 for k in ('setup_seconds','download_seconds','download_bytes')),'Unmeasured setup/download cost')
    require(setup['commands_log_sha256'] and setup['logs_path'] and isinstance(setup['base_downloaded_this_lease'],bool),'Incomplete setup receipt')
    require(setup['setup_seconds']+setup['download_seconds']<=900,'Setup/download exceeded the 15-minute stop limit')
    return min(stop,shutdown,receipt['pilot_absolute_deadline_unix'])


def establish_run_identity(root,receipt,c,source_hash,stage):
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True)
    binding={k:receipt[k] for k in ('run_id','lease_id','provider_instance_id','pilot_start_unix','pilot_absolute_deadline_unix')}
    binding['approval_reference']=receipt['explicit_user_approval_reference']
    binding.update(evidence_root=str(root),config_sha256=sha_file(P/'pilot_config.json'),
                   source_manifest_sha256=source_hash,input_sha256=c['input_sha256'],execution_kind='real_authorized_cuda_pilot')
    path=root/'run_identity.json'
    if path.exists():require(json.loads(path.read_text())==binding,'Run/root/lease identity changed')
    else:
        require(stage=='stage-a','Stage B cannot create a new run identity')
        with path.open('x') as f:json.dump(binding,f,indent=2);f.write('\n')
    return binding


@dataclass(frozen=True)
class VerifiedStageA:
    run_id: str
    results_sha256: str
    checkpoint_sha256: str
    evidence_index_sha256: str
    binding: dict


def stage_a_gate(rows,results,review,config_hash,bundle=None):
    require(isinstance(bundle,VerifiedStageA),'Actual same-root Stage A runtime/evidence binding is required; mock records are insufficient')
    require(bundle.results_sha256==canonical_hash(results),'Stage A results differ from verified evidence')
    decision=semantic_gate_only(rows,results,review,config_hash)
    decision.update(run_id=bundle.run_id,stage_a_checkpoint_sha256=bundle.checkpoint_sha256,
                    evidence_index_sha256=bundle.evidence_index_sha256,run_binding=bundle.binding)
    return decision


def verify_stage_a_bundle(root,c,rows,binding):
    """Verify actual files/receipts, not caller-provided success flags. No GPU imports."""
    root=Path(root).resolve();base=root/'stage-a'
    require(json.loads((root/'run_identity.json').read_text())==binding,'Same-root identity mismatch')
    checkpoint=json.loads((base/'stage_a_checkpoint.json').read_text())
    require(checkpoint['status']=='AWAITING_SEMANTIC_REVIEW_NO_POLICY_ADMISSION','Stage A not completed')
    require(checkpoint['run_binding']==binding and checkpoint['full_cases']==16 and checkpoint['no_crop_cases']==16,'Stage A run/config/source/lease binding mismatch')
    receipts=[json.loads(line) for line in (base/'manifest.jsonl').read_text().splitlines()]
    require(receipts[-1]['path']=='stage-a/stage_a_checkpoint.json','Completion checkpoint must be final Stage A receipt')
    require(len(receipts)-1==checkpoint['evidence_receipt_count'],'Evidence receipt count mismatch')
    index_hash=canonical_hash(receipts[:-1]);require(index_hash==checkpoint['evidence_index_sha256'],'Evidence index changed')
    index={r['path']:r for r in receipts};require(len(index)==len(receipts),'Duplicate evidence paths')
    tensor_digests={}
    for record in receipts:
        path=(root/record['path']).resolve()
        require(path.is_relative_to(base.resolve()) and path.is_file(),'Evidence escaped/missing from same Stage A root')
        require(record.get('run_binding')==binding,'Unbound or mock evidence record')
        require(path.stat().st_size==record['bytes'],'Evidence size changed')
        stream=gzip.open(path,'rb') if record['codec']=='gzip' else path.open('rb')
        h=hashlib.sha256();size=0
        meta=record['metadata'];tensor_h=hashlib.sha256(str((tuple(meta['shape']),meta['dtype'])).encode()) if 'shape' in meta and 'dtype' in meta else None
        with stream:
            while block:=stream.read(8*1024*1024):
                h.update(block);size+=len(block)
                if tensor_h is not None:tensor_h.update(block)
        if tensor_h is not None:tensor_digests[record['path']]=tensor_h.hexdigest()
        require(size==record['uncompressed_bytes'] and h.hexdigest()==record['raw_sha256'],'Raw evidence hash changed')
    def read(name):
        require('stage-a/'+name in index,'Required Stage A evidence missing: '+name)
        return json.loads((base/name).read_text())
    launch=read('stage-a_launch.json')
    require(launch['run_binding']==binding and launch['config_sha256']==binding['config_sha256'] and launch['source_manifest_hash']==binding['source_manifest_sha256'],'Launch binding changed')
    require(index['stage-a/frozen_inputs.json']['raw_sha256']==c['input_sha256'],'Actual Stage A inputs changed')
    runtime=read('runtime_proof.json');loaded=read('loaded_identity.json');opening=read('opening_device_checks.json')
    require(runtime['torch']==c['runtime']['torch'] and runtime['cuda_build']=='12.8' and runtime['capability']==[12,0] and 'sm_120' in runtime['compiled_arches'],'Actual runtime proof mismatch')
    require(runtime['transformers']==c['runtime']['transformers'] and runtime['qwen3_sha256']==c['runtime']['qwen3_source_sha256'] and runtime['bf16_sm120_kernel_passed'] is True,'Runtime proof incomplete')
    require(opening['status']=='PASS' and all(opening[k] is True for k in ('native_no_crop_exact','compressed_multitoken_no_future_leakage','compact_GQA','global_seen_independent_of_retained_length')),'Opening device evidence failed')
    backbone=loaded['backbone_hash_before_gate']
    require(backbone==loaded['backbone_hash_after_gate']==checkpoint['backbone_hash_after_stage'] and len(backbone)==64,'Loaded backbone identity mismatch')
    require(loaded['gate_file_sha256']==c['gate']['sha256'] and loaded['gate_key_count']==144 and loaded['base_never_overlay_mutated'] is True,'Gate identity mismatch')
    require(loaded['cold_load_end_resources']['peak_allocated']>0 and loaded['cold_load_end_resources']['peak_reserved']>0,'Cold load high-water evidence absent')
    require(read('base_local_receipt.json')['revision']==c['base']['revision'],'Pinned base receipt absent')
    results=read('stage_a_results.json')
    require(index['stage-a/stage_a_results.json']['raw_sha256']==checkpoint['results_raw_sha256'],'Stage A result receipt changed')
    require([(r['arm'],r['variant_id']) for r in results]==[(a,r['variant_id']) for a in ('full','no_crop') for r in rows],'Stage A result order/count changed')
    by_id={r['variant_id']:r for r in rows};full={}
    for result in results:
        row=by_id[result['variant_id']];arm=result['arm'];prefix=f"cases/{arm}/{row['variant_id']}/"
        require(result.get('mock_only') is not True and result.get('execution_kind')=='real_authorized_cuda_pilot' and result.get('model_calls',0)>0,'Mock/minimal Stage A result rejected')
        require(result['run_id']==binding['run_id'] and result['canonical_ids_sha256']==row['canonical_ids_sha256'],'Case input/run binding mismatch')
        require(result['eos_reached'] is True and result['cap_hit'] is False and result['generated_ids'][-1]==c['eos_token_id'],'Incomplete generation')
        require(len(result['generated_ids'])<=64 and len(result['trace'])==len(list(chunks(row)))+len(result['generated_ids'])-1==result['model_calls'],'Model call/evidence count mismatch')
        raw_case=read(prefix+'result.json')
        # Native Full case receipt intentionally says parity=false until paired.
        # Only the aggregate flips it after a separately saved paired proof.
        a={k:v for k,v in raw_case.items() if k!='parity_passed'};b={k:v for k,v in result.items() if k!='parity_passed'}
        require(canonical_hash(a)==canonical_hash(b),'Aggregate differs from raw case evidence')
        require(raw_case['parity_passed'] is (arm=='no_crop') and result['parity_passed'] is True,'Raw/aggregate parity state invalid')
        for j,trace in enumerate(result['trace']):
            require(len(trace['kv_append'])==36 and [x['layer'] for x in trace['kv_append']]==list(range(36)),'Per-layer append evidence missing')
            require(all(len(x['k'])==64 and len(x['v'])==64 and x['positions_start']==trace['start'] and x['positions_end']==trace['end'] for x in trace['kv_append']),'Invalid append hashes/positions')
            if j<len(list(chunks(row))):
                chunk=list(chunks(row))[j]
                require((trace['start'],trace['end'],trace['phase'])==(chunk['start'],chunk['end'],chunk['phase']),'Canonical chunk trace changed')
                require(trace['ids_sha256']==canonical_hash(row['canonical_token_ids'][chunk['start']:chunk['end']]),'Actual ingested IDs changed')
                record=index.get('stage-a/'+prefix+f'chunk_{j:04d}_logits.bin.gz')
                require(record is not None and record['metadata']['shape']==[1,1,151936] and record['metadata']['dtype']=='torch.bfloat16' and record['uncompressed_bytes']==303872,'Full native chunk-logit vector absent')
                require(tensor_digests[record['path']]==trace['logits_hash'],'Chunk vector bytes do not match native trace')
            else:
                q=j-len(list(chunks(row)))
                require(trace['phase']=='decode' and trace['start']==row['total_input_tokens']+q and trace['end']==trace['start']+1,'Decode append schedule changed')
                require(trace['ids_sha256']==canonical_hash([result['generated_ids'][q]]),'Decode teacher-forced token changed')
        for j in range(len(result['generated_ids'])):
            record=index.get('stage-a/'+prefix+f'answer_logits_{j:02d}.bin.gz')
            require(record is not None and record['metadata']['shape']==[1,1,151936] and record['metadata']['dtype']=='torch.bfloat16' and record['uncompressed_bytes']==303872,'Complete answer-logit evidence absent')
            require(tensor_digests[record['path']]==result['trace'][len(list(chunks(row)))-1+j]['logits_hash'],'Answer vector bytes do not match sampled-step trace')
        if arm=='full':full[row['variant_id']]=result
        else:
            other=full[row['variant_id']]
            require(result['generated_ids']==other['generated_ids'],'Full/no-crop answer token mismatch')
            for x,y in zip(result['trace'],other['trace']):
                require(all(x[k]==y[k] for k in ('phase','start','end','ids_sha256','kv_append','logits_hash')),'Actual Full/no-crop append/logit parity failed')
            paired=read(f"parity/{row['variant_id']}.json")
            require(paired['run_binding']==binding and paired['canonical_ids_sha256']==row['canonical_ids_sha256'],'Paired parity receipt unbound')
            require(paired['full_raw_result_sha256']==index[f"stage-a/cases/full/{row['variant_id']}/result.json"]['raw_sha256'] and paired['no_crop_raw_result_sha256']==index['stage-a/'+prefix+'result.json']['raw_sha256'],'Paired raw case identity mismatch')
            require(paired['exact_append_and_chunk_logits'] is True and paired['generated_ids_equal'] is True,'Paired parity proof failed')
    return results,VerifiedStageA(binding['run_id'],canonical_hash(results),sha_file(base/'stage_a_checkpoint.json'),index_hash,binding)


def reject_unlisted_checkpoint_files(base,config):
    """Prevent HF resolving a stale unsharded checkpoint or PEFT adapter first."""
    base=Path(base);allowed={r['path'] for r in config['base']['files']}
    unexpected=[]
    for path in base.rglob('*'):
        if not path.is_file():continue
        relative=path.relative_to(base).as_posix()
        weight_like=path.suffix in {'.safetensors','.bin','.pt','.pth','.h5','.msgpack'} or path.name=='adapter_config.json'
        if weight_like and relative not in allowed:unexpected.append(relative)
    if unexpected:raise RuntimeError('UNVERIFIED_CHECKPOINT_FILES: '+', '.join(sorted(unexpected)))
    index=json.loads((base/'model.safetensors.index.json').read_text())
    expected={r['path'] for r in config['base']['files'] if r['path'].endswith('.safetensors')}
    if set(index['weight_map'].values())!=expected:
        raise RuntimeError('PINNED_SHARD_INDEX_MISMATCH')
    return sorted(expected)
