# Tokenizer-only prelaunch review

Parent authorized this separate step after the original source-only report. One tokenizer run only; no Phase B model release.

Verified before run:
- Official pinned tokenizer/config hashes match saved checkpoint receipts
- 77 installed files from Tokenizers 0.23.2, Jinja2 3.1.6 and MarkupSafe 3.0.3 match SHA256 in their installed wheel RECORDs; saved recovery lock binds official wheel URLs and archive hashes. Fresh wheels were not downloaded or independently reread
- Current HF source was inspected only as text. Its active one-user chat rendering uses sandboxed Jinja with trim/lstrip and no required generation-tracker feature in this template; required template branch independently reduces to a literal user wrapper plus assistant prefix
- The source config disables BOS; no EOS addition is specified. Original serialized ByteLevel postprocessor inserts neither. The run will compare true/false add-special-token IDs per call and reject a mismatch
- Unmodified author prepare_prompt function only is extracted by AST; the author module imports are never executed. Its metadata facade returns ordinary Python token-ID lists for the history length check, not tensors. The unchanged function is independently checked against the exact active pure-text formatting branch
- No unknown active dependencies: Tokenizers imports its own native extension/implementations and stdlib; Jinja uses MarkupSafe. Forbidden numerical/runtime/hub imports are blocked, network/process audit events are blocked
- Existing selected IDs, source hash and budget rule stay fixed. Full public records are untouched; source deep copies are rendered with the actual author's boolean/string behavior
- Single-process guard is inside the prepared script: hard 60 CPU-second and 512 MiB address-space limits before package imports, a 60-second alarm, output/disk checks, final ru_maxrss and forbidden-module checks. Address space is more restrictive than the allowed 512 MiB RSS. No extra guard process or subprocess is created
- One new run_01 directory is exclusively created. No automatic retry after a script, resource or admission failure

The script and all source/runtime files are bound by EXECUTION_PINS.json before launch. An initial source-provenance lookup referenced the nonexistent legacy tokenization_utils_fast.py filename; it was corrected to the current tokenization_utils_tokenizers.py and Qwen2 tokenizer source before any tokenizer import. No fallback installation or runtime change occurred.

Not proven before run: exact token lengths/budget, peak resources, imported AutoTokenizer equivalence, model/gate behavior or CPU attention fit. The proposed run establishes only pinned-tokenizer/source-prompt metadata.
