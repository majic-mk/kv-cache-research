"""One-process, one-attempt, pinned tokenizer-only author input preparation."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SITE = ROOT / 'research/reconstructed/runtime_recovery_20261004/.venv/lib/python3.12/site-packages'
OUT = HERE / 'run_01'
OUT.mkdir(exist_ok=False)
START = time.monotonic()
LIMIT = 512 * 1024**2
resource.setrlimit(resource.RLIMIT_CPU, (59, 60))
resource.setrlimit(resource.RLIMIT_AS, (LIMIT, LIMIT))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.dont_write_bytecode = True
sys.path.append(str(SITE))
FORBIDDEN = {'torch', 'transformers', 'numpy', 'scipy', 'safetensors', 'triton', 'tensorflow', 'jax', 'huggingface_hub'}
class BlockImports:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in FORBIDDEN:
            raise ImportError('Forbidden import: ' + fullname)
sys.meta_path.insert(0, BlockImports())
def audit(event, args):
    if event.startswith('socket.') or event in {'subprocess.Popen', 'os.system', 'os.fork', 'os.forkpty', 'os.exec', 'os.posix_spawn'}:
        raise RuntimeError('Forbidden network/process event: ' + event)
sys.addaudithook(audit)
def timeout(signum, frame):
    raise RuntimeError('Resource signal: ' + str(signum))
signal.signal(signal.SIGALRM, timeout)
signal.signal(signal.SIGXCPU, timeout)
signal.alarm(60)
sha = lambda b: hashlib.sha256(b).hexdigest()
def canonical(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
def write_json(name, value):
    path = OUT / name
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')
def checked(path, digest):
    data = path.read_bytes()
    assert sha(data) == digest, str(path)
    return data
def checks():
    assert not (FORBIDDEN & {m.split('.')[0] for m in sys.modules}), 'Forbidden runtime imported'
    usage = resource.getrusage(resource.RUSAGE_SELF)
    assert usage.ru_maxrss * 1024 <= LIMIT, 'RSS cap'
    assert usage.ru_utime + usage.ru_stime < 60, 'CPU cap'
    assert time.monotonic() - START < 60, 'Wall cap'
    assert sum(p.stat().st_size for p in OUT.iterdir() if p.is_file()) <= 8000000, 'Evidence cap'
    v = os.statvfs(HERE)
    assert v.f_bavail * v.f_frsize >= 5000000000, 'Disk reserve'
    return {'wall_seconds': time.monotonic()-START, 'cpu_seconds': usage.ru_utime+usage.ru_stime, 'peak_rss_bytes': usage.ru_maxrss*1024}

def main():
    pins = json.loads((HERE/'EXECUTION_PINS.json').read_text())
    for rel, digest in pins['files'].items():
        checked(ROOT/rel, digest)
    p = json.loads((HERE/'PROTOCOL.json').read_text())
    write_json('START.json', {'status':'STARTED_ONCE', 'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), 'pid':os.getpid(), 'protocol_sha256':sha((HERE/'PROTOCOL.json').read_bytes()), 'guard_limits':p['limits'], 'initial_resources':checks()})
    # All package code files were checked against pinned installed wheel RECORDs before this run.
    # Runtime RECORD hashes and source hashes are included in EXECUTION_PINS.
    import tokenizers
    import jinja2
    from jinja2.sandbox import ImmutableSandboxedEnvironment
    assert tokenizers.__version__ == '0.23.2' and jinja2.__version__ == '3.1.6'
    import importlib.metadata
    assert importlib.metadata.version('MarkupSafe') == '3.0.3'
    checks()
    assets = ROOT/'outputs/revision_cpu_model_assets_20261004'
    tokenizer_path = assets/'tokenizer.json'
    checked(tokenizer_path,p['tokenizer_sha256'])
    tc_raw=checked(assets/'tokenizer_config.json',p['tokenizer_config_sha256'])
    tc=json.loads(tc_raw)
    assert tc['add_bos_token'] is False and not tc.get('add_eos_token',False)
    backend=tokenizers.Tokenizer.from_file(str(tokenizer_path))
    # Verify added-token IDs/flags without adding/remapping any tokens.
    vocab=backend.get_vocab(with_added_tokens=True)
    for k,v in tc['added_tokens_decoder'].items():
        assert vocab[v['content']] == int(k)
    assert backend.padding is None and backend.truncation is None
    assert backend.token_to_id('<|im_start|>')==151644 and backend.token_to_id('<|im_end|>')==151645
    checks()
    source_raw=checked(ROOT/p['source_file'],p['source_sha256'])
    records=json.loads(source_raw)
    source_before=sha(source_raw)
    del source_raw
    by={r['question_id']:r for r in records}
    assert len(records)==len(by)==500
    freeze_path=ROOT/'research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/FREEZE.json'
    freeze=json.loads(checked(freeze_path,p['selection_freeze_sha256']))
    selection=json.loads((ROOT/'research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/SELECTION.json').read_text())
    assert p['selected_ids']==[s['question_id'] for s in selection['selected']]
    author_path=ROOT/'research/reconstructed/revision_sensitive_kv_sources_20261004/trimkv__experiments__longmemeval__generation_utils.py'
    author_raw=checked(author_path,p['author_prompt_source_sha256'])
    author_text=author_raw.decode()
    parsed=ast.parse(author_text)
    functions=[n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name=='prepare_prompt']
    assert len(functions)==1
    node=functions[0]
    span=ast.get_source_segment(author_text,node)
    (OUT/'author_prepare_prompt_span.py.txt').write_text(span+'\n')
    namespace={'json':json}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(author_path),'exec'),namespace)
    prepare_prompt=namespace['prepare_prompt']
    facade_calls=[]
    class TokenMetadataFacade:
        def __call__(self,text,*,max_length=None,truncation=False,return_tensors=None):
            assert type(text) is str and truncation is False, 'Truncation forbidden'
            assert return_tensors=='pt', 'Unknown author call convention'
            ids=backend.encode(text,add_special_tokens=True).ids
            if max_length is not None:
                assert len(ids)<=max_length, 'Author history truncation would activate'
            facade_calls.append({'chars':len(text),'tokens':len(ids),'max_length':max_length,'truncation':truncation,'requested_tensor_format':return_tensors,'actual_transport':'metadata list; no tensor allocated'})
            return {'input_ids':[ids]}
    facade=TokenMetadataFacade()
    env=ImmutableSandboxedEnvironment(trim_blocks=True,lstrip_blocks=True,extensions=['jinja2.ext.loopcontrols'])
    env.filters['tojson']=lambda x,ensure_ascii=False,indent=None,separators=None,sort_keys=False: json.dumps(x,ensure_ascii=ensure_ascii,indent=indent,separators=separators,sort_keys=sort_keys)
    assert '{% generation' not in tc['chat_template'] and 'strftime_now' not in tc['chat_template'], 'Unknown template extension'
    template=env.from_string(tc['chat_template'])
    (OUT/'official_chat_template.jinja').write_text(tc['chat_template'])
    results=[]
    for qid in p['selected_ids']:
        record=by[qid]
        original_hash=sha(canonical(record))
        # Bind complete source record to the earlier jq -cS canonical receipt (includes LF).
        receipt=(ROOT/'research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/SELECTED_CANONICAL_RECORD_SHA256.tsv').read_text().splitlines()
        expected=dict(line.split('\t') for line in receipt)[qid]
        assert sha(canonical(record)+b'\n')==expected
        assert len(record['haystack_sessions'])==len(record['haystack_dates'])==len(record['haystack_session_ids'])
        assert len(record['haystack_sessions'])<=1000, 'Author topk truncation'
        assert all('Current Date:' not in turn['content'] for ss in record['haystack_sessions'] for turn in ss)
        assert 'Current Date:' not in record['question']
        working=copy.deepcopy(record)
        prompt=prepare_prompt(working,'orig-session',1000,True=='true','json',True=='true',tokenizer=facade,tokenizer_backend='huggingface',max_retrieval_length=129272,merge_key_expansion_into_value='none')
        # Independent pure-text formatter for the exact active author's no-CoT/all-role path.
        sessions=[]
        for date,ss in zip(record['haystack_dates'],record['haystack_sessions']):
            cleaned=copy.deepcopy(ss)
            for turn in cleaned:
                if isinstance(turn,dict): turn.pop('has_answer',None)
            sessions.append((date,cleaned))
        sessions.sort(key=lambda x:x[0])
        history=''.join('\n### Session {}:\nSession Date: {}\nSession Content:\n{}\n'.format(i+1,date,'\n'+json.dumps(ss)) for i,(date,ss) in enumerate(sessions))
        independent='I will give you several history chats between you and a user. Please answer the question based on the relevant chat history.\n\n\nHistory Chats:\n\n{}\n\nCurrent Date: {}\nQuestion: {}\nAnswer:'.format(history,record['question_date'],record['question'])
        assert prompt==independent, 'Author prompt differs from independent formatter'
        rendered=template.render(messages=[{'role':'user','content':prompt}],tools=None,add_generation_prompt=True,bos_token=tc.get('bos_token'),eos_token=tc.get('eos_token'),pad_token=tc.get('pad_token'))
        assert rendered=='<|im_start|>user\n'+prompt+'<|im_end|>\n<|im_start|>assistant\n', 'Official template differs from direct one-user wrapper'
        parts=rendered.split('Current Date:')
        assert len(parts)==2
        strings=[parts[0],'Current Date:'+parts[1]]
        call_records=[]
        seen=0
        combined=[]
        for index,text in enumerate(strings):
            ids=backend.encode(text,add_special_tokens=True).ids
            assert ids==backend.encode(text,add_special_tokens=False).ids, 'Unexpected added BOS/EOS behavior'
            assert ids
            positions=list(range(seen,seen+len(ids)))
            phase='history' if index==0 else 'question'
            (OUT/f'{qid}.{phase}.txt').write_text(text)
            write_json(f'{qid}.{phase}.ids.json',ids)
            write_json(f'{qid}.{phase}.positions.json',positions)
            call_records.append({'index':index,'phase':phase,'tokens':len(ids),'start':seen,'end':seen+len(ids),'text_sha256':sha(text.encode()),'ids_sha256':sha(canonical(ids)),'positions_sha256':sha(canonical(positions)),'add_special_tokens':True})
            seen+=len(ids)
            combined+=ids
        assert sha(canonical(record))==original_hash, 'Raw source mutation'
        (OUT/f'{qid}.prompt.txt').write_text(prompt)
        (OUT/f'{qid}.chat.txt').write_text(rendered)
        write_json(f'{qid}.ids.json',combined)
        joined_ids=backend.encode(rendered,add_special_tokens=True).ids
        results.append({'question_id':qid,'source_record_sha256':original_hash,'source_record_jq_LF_sha256':expected,'prompt_sha256':sha(prompt.encode()),'chat_sha256':sha(rendered.encode()),'calls':call_records,'total_tokens':seen,'combined_ids_sha256':sha(canonical(combined)),'independent_formatter_exact':True,'single_user_wrapper_exact':True,'split_tokenization_matches_joined':combined==joined_ids,'joined_token_count':len(joined_ids),'history_tokens':call_records[0]['tokens'],'question_tokens':call_records[1]['tokens'],'complete_original_source_preserved':True,'input_cap_pass':seen<=8192})
        checks()
    H=min(r['history_tokens'] for r in results)
    M=min(1024,32*(H//128))
    rejections=[]
    if M<32: rejections.append('M<32')
    for r in results:
        if not r['input_cap_pass']: rejections.append(r['question_id']+': total_input>8192')
        if r['history_tokens']<M+32: rejections.append(r['question_id']+': insufficient history for first prune')
        r['initial_history_prune_trigger']=r['history_tokens']>=M+32
        r['retained_fraction_of_history']=M/r['history_tokens']
        r['full_history_KV_bytes']=147456*r['history_tokens']
        r['maximum_full_input_plus799_KV_bytes']=147456*(r['total_tokens']+799)
    assert sha((ROOT/p['source_file']).read_bytes())==source_before
    checked(tokenizer_path,p['tokenizer_sha256'])
    checked(assets/'tokenizer_config.json',p['tokenizer_config_sha256'])
    resources=checks()
    write_json('RESULT.json',{'status':'TOKENIZER_ONLY_PASS' if not rejections else 'TOKENIZER_ONLY_BLOCKED_FIXED_SELECTION_PRESERVED','records':results,'budget':{'rule':p['budget_rule'],'H_min':H,'M':M,'buffer_size':32,'minimumM_pass':M>=32,'post_prune_KV_bytes':147456*M},'rejections':rejections,'all_selected_denominator':2,'source_function_span_sha256':sha(span.encode()),'official_template_sha256':sha(tc['chat_template'].encode()),'facade_calls':facade_calls,'source_tokenizer_integrity_rechecked':True,'resources':resources,'imports':sorted(sys.modules),'torch_imported':False,'transformers_imported':False,'models_loaded':0,'gate_payload_reads':0,'model_calls':0,'network_actions':0,'phase_B_released':False,'limitation':'Direct pinned Tokenizers and official Jinja template source-equivalence only; AutoTokenizer was not imported/executed. Model/attention memory admission remains separate.'})
    print(json.dumps({'status':'PASS' if not rejections else 'BLOCKED','lengths':[{k:r[k] for k in ['question_id','history_tokens','question_tokens','total_tokens','split_tokenization_matches_joined']} for r in results],'M':M,'buffer':32,'resources':resources,'rejections':rejections},indent=2))

try:
    main()
except BaseException as exc:
    usage=resource.getrusage(resource.RUSAGE_SELF)
    try:
        write_json('FAILURE.json',{'status':'FAILED_SINGLE_ATTEMPT_NO_RETRY','type':type(exc).__name__,'error':str(exc),'wall_seconds':time.monotonic()-START,'cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_rss_bytes':usage.ru_maxrss*1024,'imports':sorted(sys.modules),'phase_B_released':False})
    finally:
        raise
finally:
    signal.alarm(0)
