# Fixed public author inputs: tokenizer-only preparation complete

The single separately authorized tokenizer-only run passed. No Torch, Transformers, NumPy, trained gate, model or GPU was imported or executed. No download, install or paid call occurred. Phase B remains blocked on the separate adapter/attention/head/physical-memory gates and actual-model authorization.

## Frozen result

- **edced276:** original dense history6,476 tokens, final date/question/assistant-prefix50 tokens; total6,526. Original positions history[0,6476), question[6476,6526)
- **19b5f2b3:** original dense history3,959 tokens, final date/question/assistant-prefix41 tokens; total4,000. Positions history[0,3959), question[3959,4000)
- Frozen rule gives **M=960, buffer32**. Both histories exceed the992-row trigger, so each has a genuine initial prune. Their question calls also exceed the32-row slack after the history prune:1010 and1001 rows before another global prune to960
- Retained history fractions are14.82% and24.25%, respectively. Same absolute M, not equal fractional compression
- Neither input exceeds8192 tokens. No author topk/history truncation occurs. All source records, questions, dates and roles remain complete. No candidate replacement or competence filter was used
- Each split string was tokenized independently, as the author runner does. In these two cases only, concatenated split IDs also happen to equal one-shot IDs. That observed equality is not a general permission to change call boundaries

`INPUT_CONTRACT.json` binds the exact IDs, positions, call boundaries, source hashes, integer M and result hash. `run_01/` contains complete original prompt/chat/split strings, token-ID and absolute-position arrays, the official template and the unchanged author function span. This is a new artifact; the original source-only preparation/freeze and all older runs remain untouched.

## Fidelity and provenance checks

The author shell's literal effective defaults were preserved: all history roles, non-CoT prompt caused by comparing booleanTrue to string'true', but800 greedy selections in the future decode loop. The unchanged `prepare_prompt` function was extracted by AST without importing its module. A direct Tokenizers metadata facade supplied only its history length check; no PyTorch tensor was created. A separate pure-text formatter matched the function output exactly.

The exact official checkpoint Jinja template was rendered in a sandbox and compared with the direct one-user chat wrapper; output matched. Its active branch needs no assistant-generation tracking extension. No BOS/EOS additions occur for this checkpoint; per-call add_special_tokens=True andFalse IDs were explicitly equal. No AutoTokenizer/Transformers object was imported, so this is source-based/direct-backend fidelity, not a separately executed AutoTokenizer comparison.

Before launch, official tokenizer/config hashes matched saved checkpoint receipts. All77 hash-bearing installed files for Tokenizers0.23.2, Jinja2 3.1.6 and MarkupSafe3.0.3 matched their wheel RECORDs. Saved recovery lockfiles bind their official wheel URLs/archive hashes; no fresh wheel acquisition occurred. `EXECUTION_PINS.json` froze97 source/runtime/input files before the one run, and the script checked them before dependency imports. Source/tokenizer/config integrity was checked again at the end.

- Raw tokenizer SHA256: aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4
- Tokenizer config SHA256: a62ff0a2472a0fa1b8eaabcb57c59b58afa42a22831dc141400b6e0cf2b65ce3
- Official template text SHA256:64f85b198065d0fba2a81f37e10ed68161ce2c19a754c7100e67e0ca2ee9c326
- Unchanged function span SHA256:e9c24675e3a474cc7ff138599b022a56423bd5eb6ffeaae284b064fc78c834a7
- Result SHA256:d3ab28628d7991ca56de197b085ad38610edbc8e46f44b4b7aa81cfbee25b161

## Resources and limits

Observed near completion: **0.792153 CPU seconds**,0.759873 seconds elapsed, **195,809,280 bytes peakRSS**. Exec returned terminal exit0 after0.765285 seconds. The in-process guard set hard60CPU-second and512MiB address-space limits, a60-second wall alarm, import/network/process creation blocks, an8MB evidence cap and5GB disk reserve. Address space is intentionally more restrictive than the permitted512MiB RSS. No extra watchdog process or automatic retry was used.

The saved resource record precedes final result serialization by a small amount; it is not an exact post-exit CPU sample. Hard limits remained in force. Exec completion confirms the process returned; a PID number observed from a later isolated tool command is not a cross-command process identity. No unrelated PID was terminated.

## What this resolves, and what it does not

The tokenizer and budget blockers are resolved without touching the original selection. Logical raw Full-history KV is954,925,056 and583,778,304bytes; post-prune raw KV atM960 is141,557,760bytes. These are **shape-based logical bytes**, excluding gates/IDs, weights, attention/MLP/head buffers, old/new gather coexistence and allocator effects. They are not measured model-memory peaks.

For later execution, preserve either the original materialized full-history head or explicitly declare/prove a last-token/chunked-head adaptation. CPU SDPA/tiled dense attention must preserve original history/question/decode policy boundaries. None of those implementations or model numerical checks occurred here. The source-faithful baseline, engineering resource admission, actual quality and all paper-level conclusions remain separate.
