"""Exact, lazily loaded author-method reference for the frozen Phase A route.

Importing this module, or calling ``verify_sources()``, uses only the standard
library. Only a separately authorized numerical worker may call
``load_author_classes()`` or ``make_author_cache()``. The complete author package
is never imported. The two raw classes returned by the loader retain every
original method body; callers of those raw classes must restrict themselves to
the explicitly audited update/compress/gate tests. They are NOT a supported HF
generation cache. Use the checked wrapper factory for reference call sequences.
"""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PROTOCOL_RELATIVE = "research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/PHASE_A_PROTOCOL.json"
PROTOCOL_SHA256 = "1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f"
SOURCE_COMMIT = "49d2a2951ba12e6431a3986b418ee791b209d7c2"
_EXPECTED = {
    "TrimKVCache": {
        "filename": "trimkv_cache_utils.py",
        "source_sha256": "bb3013d5ff53a8264218b48bafa513c608ad3919d2c6d4172fb248a8b656cae5",
        "span_sha256": "6815beaef692ed88bb3deacd6b30f73c503d4f0e849b7e7db4f3e3d63b4e8015",
    },
    "RetentionGate": {
        "filename": "trimkv_modeling_qwen3.py",
        "source_sha256": "9fdec3ee6e28177e6805715df41663d30f6662cb600cbee6f401a6c51dc7486c",
        "span_sha256": "71ba60d206b37279c3c0f8bce6558fcef70160d420b67f7b400d7ff928160ed6",
    },
}


class SourceIntegrityError(RuntimeError):
    """Pinned original, full snapshot, span, or receipt changed."""


class UnsupportedAuthorPath(RuntimeError):
    """A path outside the selected static, unpadded, batch-one CPU route."""


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _require(condition, message):
    if not condition:
        raise SourceIntegrityError(message)


def _class_span(data, name, filename):
    """Find exact AST UTF-8 byte coordinates without compiling or importing."""
    tree = ast.parse(data, filename=filename)
    classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == name]
    _require(len(classes) == 1, f"Expected exactly one top-level {name}")
    node = classes[0]
    _require(not node.decorator_list, f"Unexpected decorator on {name}")
    lines = data.splitlines(keepends=True)
    start = sum(map(len, lines[:node.lineno - 1])) + node.col_offset
    end = sum(map(len, lines[:node.end_lineno - 1])) + node.end_col_offset
    return data[start:end], {
        "start_line": node.lineno,
        "start_col_utf8_bytes": node.col_offset,
        "end_line": node.end_lineno,
        "end_col_utf8_bytes": node.end_col_offset,
        "start_byte": start,
        "end_byte_exclusive": end,
        "methods": [child.name for child in node.body if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))],
    }


def verify_sources():
    """Verify all original/snapshot/span/protocol bytes; return a fresh receipt.

    This is source inspection only. It does not import torch or transformers,
    instantiate models, execute class bodies, or run numerical tests.
    """
    protocol_bytes = (ROOT / PROTOCOL_RELATIVE).read_bytes()
    _require(_sha256(protocol_bytes) == PROTOCOL_SHA256, "Frozen Phase A protocol hash mismatch")
    receipt = json.loads((HERE / "EXTRACTION_RECEIPT.json").read_text(encoding="utf-8"))
    _require(receipt["source_commit"] == SOURCE_COMMIT, "Receipt commit mismatch")
    _require(receipt["protocol_path"] == PROTOCOL_RELATIVE, "Receipt protocol path mismatch")
    _require(receipt["protocol_sha256"] == PROTOCOL_SHA256, "Receipt protocol hash mismatch")
    entries = receipt["classes"]
    _require(len(entries) == len(_EXPECTED), "Unexpected source receipt class count")
    _require({entry["class"] for entry in entries} == set(_EXPECTED), "Unexpected source receipt classes")
    for entry in entries:
        name = entry["class"]
        expected = _EXPECTED[name]
        relative = "research/reconstructed/revision_baseline_contracts_20261004/sources/" + expected["filename"]
        full_snapshot = "snapshots/" + expected["filename"]
        span_snapshot = "snapshots/" + name + ".exact.py"
        _require(entry["original_path"] == relative, f"{name}: original path mismatch")
        _require(entry["full_snapshot"] == full_snapshot, f"{name}: full snapshot path mismatch")
        _require(entry["span_snapshot"] == span_snapshot, f"{name}: span path mismatch")
        original = (ROOT / relative).read_bytes()
        archived = (HERE / full_snapshot).read_bytes()
        _require(_sha256(original) == expected["source_sha256"], f"{name}: original hash mismatch")
        _require(original == archived, f"{name}: full snapshot differs from pinned original")
        span, coordinates = _class_span(original, name, relative)
        saved_span = (HERE / span_snapshot).read_bytes()
        _require(span == saved_span, f"{name}: archived class bytes differ from exact original span")
        _require(_sha256(span) == expected["span_sha256"], f"{name}: span hash mismatch")
        for key, value in coordinates.items():
            _require(entry[key] == value, f"{name}: {key} receipt mismatch")
        for key, value in {"source_sha256": expected["source_sha256"], "span_sha256": expected["span_sha256"],
                           "source_bytes": len(original), "span_bytes": len(span)}.items():
            _require(entry[key] == value, f"{name}: {key} receipt mismatch")
    return receipt


def _reject_compute_log_G(*args, **kwargs):
    # This is an explicit unsupported-route guard, never a numerical stand-in.
    raise UnsupportedAuthorPath("lookahead_steps != 1 is outside the frozen Phase A route")


def load_author_classes():
    """Load exact author classes using real installed dependencies, lazily.

    This call starts numerical-runtime imports and therefore belongs only inside
    the authorized guarded numerical worker. Missing dependencies propagate;
    there are no fallback modules or fakes. No source body is patched. The raw
    cache class has known unsupported inherited and historical helper methods;
    returning it permits explicit source/ABI tests, not general generation use.
    """
    receipt = verify_sources()  # Must precede numerical imports and class exec.
    import typing
    import torch
    from torch import nn
    from torch.nn import functional as F
    from transformers.activations import ACT2FN
    from transformers.cache_utils import DynamicCache

    namespace = {
        "__name__": __name__ + ".exact_author_spans",
        "__builtins__": __builtins__,
        "torch": torch,
        "nn": nn,
        "F": F,
        "DynamicCache": DynamicCache,
        "ACT2FN": ACT2FN,
        "Any": typing.Any,
        "Dict": typing.Dict,
        "Iterable": typing.Iterable,
        "List": typing.List,
        "Optional": typing.Optional,
        "Tuple": typing.Tuple,
        "compute_log_G": _reject_compute_log_G,
    }
    for entry in receipt["classes"]:
        path = HERE / entry["span_snapshot"]
        data = path.read_bytes()
        # Recheck the bytes actually compiled, rather than trusting a prior read.
        _require(_sha256(data) == _EXPECTED[entry["class"]]["span_sha256"], "Span changed before execution")
        exec(compile(data, str(path), "exec", dont_inherit=True), namespace, namespace)
    return namespace["TrimKVCache"], namespace["RetentionGate"]


class AuthorCacheReference:
    """Narrow owner of an unchanged author cache, with fail-closed entrypoints.

    Update layers in order, starting at zero, then call compress exactly once
    after the complete model call. The first complete call establishes layer
    count. Tensor state is exposed for evidence inspection; consumers must not
    mutate it. Current-HF generation and legacy mask/batch helpers are rejected.
    """

    __slots__ = ("_cache", "_torch", "_call_layers", "_call_tokens", "_call_start", "_layer_count", "_budget")
    _STATE_ATTRIBUTES = frozenset({
        "key_cache", "value_cache", "retention_weights", "kv_positions",
        "_seen_tokens", "memory_size", "buffer_size", "strategy",
        "lookahead_steps", "sliding_window_size", "do_compress", "device",
    })

    def __init__(self, raw_cache, torch_module):
        self._cache = raw_cache
        self._torch = torch_module
        self._call_layers = 0
        self._call_tokens = None
        self._call_start = None
        self._layer_count = None
        self._budget = raw_cache.memory_size
        self._validate_route()

    def __getattr__(self, name):
        if name in self._STATE_ATTRIBUTES:
            return getattr(self._cache, name)
        raise UnsupportedAuthorPath(f"Author reference API {name!r} is outside the audited method surface")

    def _validate_route(self):
        raw = self._cache
        if (raw.strategy != "fixed_budget" or raw.lookahead_steps != 1 or raw.sliding_window_size != 0
                or raw.buffer_size != 32 or raw.memory_size != self._budget
                or raw.do_compress != (self._budget is not None)
                or str(raw.device) != "cpu" or raw.attention_mask is not None):
            raise UnsupportedAuthorPath("Only fixed_budget/lookahead1/buffer32/sliding0/unpadded CPU is supported")

    def __len__(self):
        return len(self._cache)

    def __getitem__(self, layer_idx):
        return self._cache[layer_idx]

    def __iter__(self):
        return iter(self._cache)

    def get_seq_length(self):
        return self._cache.get_seq_length()

    def get_cache_length(self, layer_idx=0):
        return self._cache.get_cache_length(layer_idx)

    def get_total_cached_tokens(self, num_key_value_heads=None):
        return self._cache.get_total_cached_tokens(num_key_value_heads)

    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        self._validate_route()
        torch = self._torch
        if type(layer_idx) is not int or layer_idx != self._call_layers:
            raise UnsupportedAuthorPath("Author reference requires consecutive layer updates beginning at zero")
        if self._layer_count is not None and layer_idx >= self._layer_count:
            raise UnsupportedAuthorPath("Layer count cannot change after the first complete call")
        if not isinstance(cache_kwargs, dict):
            raise UnsupportedAuthorPath("Explicit retention_weights and original cache_position are required")
        if set(cache_kwargs) - {"cache_position", "retention_weights", "attention_mask"}:
            raise UnsupportedAuthorPath("Unexpected author cache metadata")
        if cache_kwargs.get("attention_mask") is not None:
            raise UnsupportedAuthorPath("Padded, packed, or externally masked reference updates are unsupported")
        gates = cache_kwargs.get("retention_weights")
        positions = cache_kwargs.get("cache_position")
        tensors = (key_states, value_states, gates, positions)
        if not all(isinstance(tensor, torch.Tensor) for tensor in tensors):
            raise UnsupportedAuthorPath("K, V, gates, and explicit original positions must all be tensors")
        if any(tensor.device.type != "cpu" or tensor.requires_grad for tensor in tensors):
            raise UnsupportedAuthorPath("Only CPU inference tensors without gradients are supported")
        if (key_states.ndim != 4 or key_states.shape[0] != 1 or key_states.shape != value_states.shape
                or key_states.dtype != value_states.dtype or key_states.dtype not in (torch.float32, torch.bfloat16)):
            raise UnsupportedAuthorPath("K/V must be matching batch-one FP32 or BF16 [1,H,Q,D] tensors")
        _, heads, tokens, dim = key_states.shape
        if min(heads, tokens, dim) <= 0 or gates.shape != (1, heads, tokens):
            raise UnsupportedAuthorPath("Positive dense K/V dimensions and gates [1,H,Q] are required")
        if gates.dtype not in (torch.float32, torch.bfloat16) or positions.dtype != torch.int64:
            raise UnsupportedAuthorPath("Gate dtype must be FP32/BF16 and original positions must be int64")
        if not all(bool(torch.isfinite(tensor).all().item()) for tensor in (key_states, value_states, gates)):
            raise UnsupportedAuthorPath("Reference input arrays must be finite")
        if layer_idx == 0:
            call_start = self._cache.get_seq_length()
        else:
            call_start = self._call_start
            if tokens != self._call_tokens:
                raise UnsupportedAuthorPath("Every layer must append the same call length")
        expected_positions = list(range(call_start, call_start + tokens))
        if positions.ndim == 1:
            valid_positions = positions.shape == (tokens,) and positions.tolist() == expected_positions
        elif positions.ndim == 3:
            valid_positions = positions.shape == (1, heads, tokens) and all(row == expected_positions for row in positions.tolist()[0])
        else:
            valid_positions = False
        if not valid_positions:
            raise UnsupportedAuthorPath("New positions must be the shared original absolute call interval")
        if layer_idx < len(self._cache):
            old = self._cache.key_cache[layer_idx]
            if old.shape[1] != heads or old.shape[3] != dim or old.dtype != key_states.dtype:
                raise UnsupportedAuthorPath("Per-layer shape and dtype cannot change across calls")
        result = self._cache.update(key_states, value_states, layer_idx, cache_kwargs)
        if layer_idx == 0:
            self._call_start = call_start
            self._call_tokens = tokens
        self._call_layers += 1
        return result  # The original five-value return is intentionally retained.

    def compress(self):
        self._validate_route()
        if self._call_layers == 0:
            raise UnsupportedAuthorPath("Compression must occur once after a nonempty complete call")
        if self._call_layers != len(self._cache):
            raise UnsupportedAuthorPath("Every existing layer must finish before the global compression sweep")
        if self._layer_count is not None and self._call_layers != self._layer_count:
            raise UnsupportedAuthorPath("Incomplete model call before compression")
        self._cache.compress()
        self._layer_count = self._call_layers
        self._call_layers = 0
        self._call_tokens = None
        self._call_start = None


def make_author_cache(memory_size, buffer_size=32):
    """Create the narrow author reference (``None`` budget means no crop).

    Nonbaseline buffer128 controls must use the raw class explicitly and be
    labeled as negatives; the supported wrapper never silently admits them.
    """
    if memory_size is not None and (type(memory_size) is not int or memory_size <= 0):
        raise UnsupportedAuthorPath("memory_size must be a positive integer or None for no-crop control")
    if type(buffer_size) is not int or buffer_size != 32:
        raise UnsupportedAuthorPath("The frozen reference buffer is exactly 32")
    TrimKVCache, _ = load_author_classes()
    import torch
    raw = TrimKVCache(memory_size=memory_size, buffer_size=buffer_size, strategy="fixed_budget",
                      lookahead_steps=1, sliding_window_size=0, device="cpu")
    return AuthorCacheReference(raw, torch)
