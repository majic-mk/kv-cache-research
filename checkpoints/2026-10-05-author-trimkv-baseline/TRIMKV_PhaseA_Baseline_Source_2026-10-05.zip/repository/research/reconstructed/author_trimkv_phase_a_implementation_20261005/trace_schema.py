"""Streaming, bounded synthetic evidence; no runtime imports at module scope."""
import gzip
import json
import io
import math
import time
from contextlib import contextmanager


class CappedBinaryWriter:
    def __init__(self, stream, limit):
        self.stream, self.limit, self.used = stream, limit, 0
    def write(self, data):
        if self.used + len(data) > self.limit:
            raise OSError('Compressed trace evidence allowance exhausted')
        count = self.stream.write(data)
        self.used += count
        return count
    def flush(self):
        self.stream.flush()
    def tell(self):
        return self.used


class Trace:
    def __init__(self, output):
        self.path = output / 'trace.jsonl.gz'
        self.raw = self.path.open('xb')
        self.bounded = CappedBinaryWriter(self.raw, 24000000)
        self.stream = io.TextIOWrapper(gzip.GzipFile(fileobj=self.bounded, mode='wb', compresslevel=1), encoding='utf-8')
        self.times = {}
        self.logical_bytes = {}
        self.records = 0
        self.negative_verdicts = {}

    def pack(self, value):
        if hasattr(value, 'detach'):
            data = value.detach().cpu()
            finite = bool(data.isfinite().all().item())
            if not finite:
                raise AssertionError('Non-finite evidence tensor')
            return {'dtype': str(data.dtype), 'shape': list(data.shape),
                    'finite': finite, 'values': data.tolist()}
        if isinstance(value, dict):
            return {str(k): self.pack(v) for k, v in value.items()}
        if isinstance(value, (tuple, list)):
            return [self.pack(v) for v in value]
        if isinstance(value, float) and not math.isfinite(value):
            return str(value)
        return value

    def emit(self, event, **data):
        start = time.perf_counter()
        record = {'event': event, **self.pack(data)}
        self.stream.write(json.dumps(record, separators=(',', ':'), allow_nan=False) + '\n')
        self.stream.flush()
        self.records += 1
        self.times['evidence'] = self.times.get('evidence', 0.0) + time.perf_counter() - start

    @contextmanager
    def timed(self, name, logical_bytes=0):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.times[name] = self.times.get(name, 0.0) + time.perf_counter() - start
            self.logical_bytes[name] = self.logical_bytes.get(name, 0) + int(logical_bytes)

    def negative(self, name, detected, **detail):
        self.negative_verdicts[name] = bool(detected)
        self.emit('negative_control', name=name, detected=bool(detected), **detail)
        if not detected:
            raise AssertionError('Non-discriminating negative control: ' + name)

    def close(self):
        try:
            self.stream.close()
        finally:
            self.raw.close()


def tensor_bytes(tensor):
    return tensor.numel() * tensor.element_size()


def storage_ledger(tensors):
    unique = {}
    for tensor in tensors:
        storage = tensor.untyped_storage()
        unique[storage.data_ptr()] = storage.nbytes()
    return {'logical_bytes': sum(tensor_bytes(t) for t in tensors),
            'unique_storage_bytes': sum(unique.values()), 'unique_storages': len(unique)}


def gate_logical_bytes(gate, inputs):
    # Estimated explicit tensor reads/writes, not physical memory-bus traffic.
    tokens = inputs.numel() // inputs.shape[-1]
    element = inputs.element_size()
    middle = tokens * gate.linear1.out_features * element
    output = tokens * gate.linear2.out_features * element
    return tensor_bytes(inputs) + sum(tensor_bytes(p) for p in gate.parameters()) + 4 * middle + 4 * output


def attention_logical_bytes(query, key, value, mask, groups):
    # Q/K/V reads, GQA expand/materialize, scores+softmax, mask and output.
    scores = query.shape[0] * query.shape[1] * query.shape[-2] * key.shape[-2]
    output = query.numel() * query.element_size()
    return (tensor_bytes(query) + tensor_bytes(key) + tensor_bytes(value)
            + 2 * groups * (tensor_bytes(key) + tensor_bytes(value))
            + (tensor_bytes(mask) if mask is not None else 0)
            + scores * (4 * query.element_size() + 8) + output)
