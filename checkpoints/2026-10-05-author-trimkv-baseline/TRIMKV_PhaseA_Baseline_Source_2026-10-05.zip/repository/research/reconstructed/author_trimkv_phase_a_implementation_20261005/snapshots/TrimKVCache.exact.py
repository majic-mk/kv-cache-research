class TrimKVCache(DynamicCache):
    def __init__(
        self,
        max_seq_len: int = None,
        memory_size: Optional[int] = None,
        buffer_size: int = 1,
        sliding_window_size: int = 0,
        strategy: str = 'fixed_budget',
        lookahead_steps: int = 1,
        device: str = "cuda",
        **kwargs,
    ) -> None:
        self.max_seq_len = max_seq_len
        self.memory_size = memory_size
        self.buffer_size = buffer_size
        self.strategy = strategy
        assert strategy in ['fixed_budget'], "Only 'fix_budget' strategy are supported"
        self.sliding_window_size = sliding_window_size
        self.do_compress = (self.memory_size is not None)

        self.lookahead_steps = lookahead_steps

        self._seen_tokens = 0
        self.key_cache: List[torch.Tensor] = []
        self.value_cache: List[torch.Tensor] = []
        self.retention_weights: List[torch.Tensor] = []
        self.kv_positions: List[torch.Tensor] = []
        self.attention_mask = None
        self.device = device
        self.offset = torch.tensor(0, dtype=torch.int64)
        self.block_mask = None
        
        # log peak cached tokens and full memory
        self.peak_cached_tokens = None
        self.layers = []

    def __getitem__(self, layer_idx: int) -> List[Tuple[torch.Tensor]]:
        if layer_idx < len(self):
            return (self.key_cache[layer_idx], self.value_cache[layer_idx], self.retention_weights[layer_idx], self.kv_positions[layer_idx])
        else:
            raise KeyError(f"Cache only has {len(self)} layers, attempted to access layer with index {layer_idx}")

    def __iter__(self):
        for layer_idx in range(len(self)):
            yield (self.key_cache[layer_idx], self.value_cache[layer_idx], self.retention_weights[layer_idx], self.kv_positions[layer_idx])

    def __len__(self):
        return len(self.key_cache)

    def get_seq_length(self) -> int:
        return self._seen_tokens

    def get_mask_sizes(self, cache_position: torch.Tensor, layer_idx: int = 0) -> tuple[int, int]:
        """Return the length and offset of the cache, used to generate the attention mask"""
        query_length = cache_position.shape[0]
        cached_length = self.get_cache_length()

        kv_offset = max(self._seen_tokens - cached_length + 1, 0)
        kv_length = cached_length + query_length

        return kv_length, kv_offset

    def get_cache_length(self, layer_idx: int = 0) -> int:
        """Returns the sequence length of the cache for the given layer."""
        if layer_idx >= len(self.key_cache):
            return 0
        return self.key_cache[layer_idx].shape[-2]

    def get_total_cached_tokens(self, num_key_value_heads: Optional[int] = None) -> int:
        if num_key_value_heads is None:
            num_key_value_heads = self.key_cache[0].shape[1] if self.key_cache else 0

        return sum(self.get_cache_length(layer_idx) * num_key_value_heads for layer_idx in range(len(self)))

    def update(
        self,
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        layer_idx: int,
        cache_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        cache_position = cache_kwargs.get("cache_position")
        retention_weights = cache_kwargs.get("retention_weights")
        attention_mask = cache_kwargs.get("attention_mask", None)
        # Update the cache
        if key_states is not None:
            bsz, num_heads, seq_len, dim = key_states.shape
            assert bsz == 1 or (attention_mask is None or attention_mask.dim() == 2), "Batch size greater than 1 is only supported when attention_mask is provided with shape (B, S) or None"
            self.attention_mask = attention_mask
            # Update the number of seen tokens
            if layer_idx == 0:
                self._seen_tokens += seq_len

            cache_positions = cache_position[None, None, :].expand_as(retention_weights) if cache_position.dim() == 1 else cache_position

            if len(self.key_cache) <= layer_idx:
                # There may be skipped layers, fill them with empty lists
                for _ in range(len(self.key_cache), layer_idx):
                    self.key_cache.append(torch.tensor([]))
                    self.value_cache.append(torch.tensor([]))
                    self.retention_weights.append(torch.tensor([]))
                    self.kv_positions.append(torch.tensor([]))

                self.key_cache.append(key_states)
                self.value_cache.append(value_states)
                self.retention_weights.append(retention_weights)
                self.kv_positions.append(cache_positions)
            elif (
                not self.key_cache[layer_idx].numel()  # prefers not t.numel() to len(t) == 0 to export the model
            ):  # fills previously skipped layers; checking for tensor causes errors
                self.key_cache[layer_idx] = key_states
                self.value_cache[layer_idx] = value_states
                self.retention_weights[layer_idx] = retention_weights
                self.kv_positions[layer_idx] = cache_positions
            else:
                self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=-2)
                self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=-2)
                self.retention_weights[layer_idx] = torch.cat([self.retention_weights[layer_idx], retention_weights], dim=-1)
                self.kv_positions[layer_idx] = torch.cat([self.kv_positions[layer_idx], cache_positions], dim=-1)

        return self.key_cache[layer_idx], self.value_cache[layer_idx], self.retention_weights[layer_idx], self.kv_positions[layer_idx], {}

    def batch_select_indices(self, indices: torch.Tensor):
        """Only keep the `indices` in the batch dimension of the cache. Used in contrastive search."""
        for layer_idx in range(len(self)):
            self.key_cache[layer_idx] = self.key_cache[layer_idx][indices, ...]
            self.value_cache[layer_idx] = self.value_cache[layer_idx][indices, ...]
            self.retention_weights[layer_idx] = self.retention_weights[layer_idx][indices, ...]
            self.kv_positions[layer_idx] = self.kv_positions[layer_idx][indices, ...]

    def batch_split(self, full_batch_size: int, split_size: int) -> List["DynamicCache"]:
        """Split the current instance into a list of `DynamicCache` by the batch size. This will be used by
        `_split_model_inputs()` in `generation.utils`"""
        out = []
        for i in range(0, full_batch_size, split_size):
            current_split = TrimKVCache(device=self.device)
            current_split._seen_tokens = self._seen_tokens
            current_split.key_cache = [tensor[i : i + split_size] for tensor in self.key_cache]
            current_split.value_cache = [tensor[i : i + split_size] for tensor in self.value_cache]
            current_split.retention_weights = [tensor[i : i + split_size] for tensor in self.retention_weights]
            current_split.kv_positions = [tensor[i : i + split_size] for tensor in self.kv_positions]
            out.append(current_split)
        return out

    def compress(self):
        if not self.do_compress:
            return

        assert len(self.key_cache) > 0 and self.key_cache[0].numel() > 0, "Cache is empty, cannot compress"
        num_layers = len(self.key_cache)
        memory_size = self.memory_size
        buffer_size = self.buffer_size

        # layer wise compression
        for layer_idx in range(num_layers):
            if memory_size + buffer_size <= self.get_cache_length(layer_idx):
                key_states = self.key_cache[layer_idx]
                value_states = self.value_cache[layer_idx]
                kv_positions = self.kv_positions[layer_idx]
                retention_weights = self.retention_weights[layer_idx]
                
                log_beta = retention_weights.to(torch.float32)
                q_idx = self.get_seq_length() + 1
                if self.lookahead_steps == 1:
                    scores = (log_beta * (q_idx - kv_positions))
                else:
                    scores = compute_log_G(
                        log_beta,
                        q_idx,
                        kv_positions,
                        n=self.lookahead_steps,
                    )


                if self.sliding_window_size > 0:
                    scores[:, :, -self.sliding_window_size:] = float('inf')

                if self.attention_mask is not None:
                    # set the scores of the masked positions to -inf
                    mask = self.attention_mask[:, None, :key_states.shape[-2]]
                    scores = scores.masked_fill(~mask, float('-inf'))

                # get top-k (memory size) indices with highest alpha values to keep
                # top_k_indices = torch.topk(log_alpha, memory_size, dim=-1).indices
                top_k_indices = torch.topk(scores, memory_size, dim=-1).indices
                # sort the top-k indices to maintain order
                top_k_indices, _ = torch.sort(top_k_indices, dim=-1)

                # gather the top-k key and value states to the first position, using gather
                self.key_cache[layer_idx] = key_states.gather(-2, top_k_indices.unsqueeze(-1).expand(-1, -1, -1, key_states.shape[-1]))
                self.value_cache[layer_idx] = value_states.gather(-2, top_k_indices.unsqueeze(-1).expand(-1, -1, -1, value_states.shape[-1]))
                self.retention_weights[layer_idx] = self.retention_weights[layer_idx].gather(-1, top_k_indices)
                self.kv_positions[layer_idx] = kv_positions.gather(-1, top_k_indices)
        
    def log(self, layer_idx: int = None):
        logs = {}
        if layer_idx is None:
            for layer_idx in range(len(self.key_cache)):
                logs[layer_idx] = {
                    "seen_tokens": self.get_seq_length(),
                    "kv_positions": self.kv_positions[layer_idx].detach().cpu(),
                }
        else:
            logs["seen_tokens"] = self.get_seq_length()
            logs["kv_positions"] = self.kv_positions[layer_idx].detach().cpu()
        return logs

    def copy_to_device(self, device: str):
        new_cache = TrimKVCache(
            memory_size=self.memory_size,
            buffer_size=self.buffer_size,
            sliding_window_size=self.sliding_window_size,
        )

        new_cache._seen_tokens = self._seen_tokens
        new_cache.offset = self.offset.to(device)
        new_cache.block_mask = self.block_mask.to(device) if self.block_mask is not None else None
        new_cache.key_cache = [tensor.to(device) for tensor in self.key_cache]
        new_cache.value_cache = [tensor.to(device) for tensor in self.value_cache]
        new_cache.retention_weights = [tensor.to(device) for tensor in self.retention_weights]
        new_cache.kv_positions = [tensor.to(device) for tensor in self.kv_positions]
        return new_cache