"""Restricted independent static cache and current-HF Qwen3 CPU integration.

This is a tiny synthetic port. No pretrained loader or generation API is exposed.
Only finish_call() prunes, after every decoder and final RMSNorm has completed.
"""
from contextlib import nullcontext
import torch
from torch import nn
from torch.nn import functional as F
from trace_schema import tensor_bytes, storage_ledger, gate_logical_bytes, attention_logical_bytes


DEFAULT_ROUTE = dict(cache_class='TrimKVCache', strategy='fixed_budget', lookahead_steps=1,
                     buffer_size=32, sliding_window_size=0, batch=1, padding=False,
                     packing=False, training=False, dropout=0.0, gate='rg',
                     rope='default', theta=5000000, position_policy='original_absolute',
                     schedule='global_post_call')


def validate_route(**changes):
    route = dict(DEFAULT_ROUTE)
    unknown = set(changes) - set(route)
    if unknown:
        raise ValueError('Unknown route fields: ' + str(sorted(unknown)))
    route.update(changes)
    if route != DEFAULT_ROUTE:
        raise ValueError('Unsupported route: ' + str(changes))
    return route


class StaticCacheAdapter:
    """Independent state; metadata seam supplies gate and original IDs.

    get_query_offset/get_mask_sizes describe compact physical mask coordinates.
    They never define RoPE IDs. Explicit absolute-ID masks are constructed per
    layer/head and passed as 4D current-HF masks, because retained IDs may differ.
    """
    is_compileable = False
    is_sliding = [False, False]

    def __init__(self, memory_size=8, layers=2, trace=None, **route):
        validate_route(**route)
        if memory_size is not None and (type(memory_size) is not int or memory_size <= 0):
            raise ValueError('Positive integer budget required')
        if layers != 2:
            raise ValueError('Phase A has exactly two layers')
        self.memory_size, self.num_layers, self.trace = memory_size, layers, trace
        self.buffer_size = 32
        self.key_cache, self.value_cache = [], []
        self.retention_weights, self.kv_positions = [], []
        self.seen_tokens = 0
        self.active = None
        self.pending = {}
        self.updated = []
        self.call_count, self.prune_count = 0, 0
        self.final_normalized = False
        self.events = []

    def get_seq_length(self, layer_idx=0):
        return 0 if layer_idx >= len(self.key_cache) else self.key_cache[layer_idx].shape[-2]

    def get_query_offset(self, layer_idx=0):
        return self.get_seq_length(layer_idx)

    def get_mask_sizes(self, query_length: int, layer_idx=0):
        if type(query_length) is not int or query_length <= 0:
            raise ValueError('Current HF requires an integer query length')
        return self.get_seq_length(layer_idx) + query_length, 0

    def begin_call(self, positions):
        if self.active is not None:
            raise RuntimeError('Previous reference call has not finished')
        if positions is None or positions.dtype != torch.int64 or positions.ndim != 1:
            raise ValueError('Explicit original int64 positions required')
        if not 1 <= positions.numel() <= 96 or self.seen_tokens + positions.numel() > 256:
            raise ValueError('Synthetic token admission exceeded')
        expected = torch.arange(self.seen_tokens, self.seen_tokens + positions.numel(), dtype=torch.int64)
        if positions.device.type != 'cpu' or not torch.equal(positions, expected):
            raise ValueError('Positions must be original contiguous call IDs')
        self.active = positions
        self.updated, self.pending = [], {}
        self.final_normalized = False
        self.call_count += 1

    def set_metadata(self, layer_idx, gates, positions):
        if self.active is None or not torch.equal(positions, self.active):
            raise ValueError('Missing or changed original positions')
        if gates is None or gates.ndim != 3 or gates.shape[0] != 1 or gates.shape[-1] != positions.numel():
            raise ValueError('Missing or malformed retention gates')
        if layer_idx in self.pending or layer_idx in self.updated:
            raise RuntimeError('Metadata already supplied')
        self.pending[layer_idx] = (gates, positions)

    def update(self, key_states, value_states, layer_idx):
        if self.active is None or layer_idx not in self.pending:
            raise ValueError('Gate/position seam is mandatory')
        if layer_idx != len(self.updated):
            raise ValueError('One ordered append per layer required')
        gates, positions = self.pending.pop(layer_idx)
        if key_states.shape != value_states.shape or key_states.ndim != 4:
            raise ValueError('Paired K/V shape mismatch')
        b, h, q, d = key_states.shape
        if b != 1 or h not in (2, 8) or d not in (8, 128) or gates.shape != (b, h, q):
            raise ValueError('Unsupported synthetic tensor shape')
        if key_states.device.type != 'cpu' or value_states.device.type != 'cpu' or gates.device.type != 'cpu':
            raise ValueError('CPU only')
        if key_states.dtype not in (torch.float32, torch.bfloat16) or value_states.dtype != key_states.dtype or gates.dtype != key_states.dtype:
            raise ValueError('Source cache dtypes must agree')
        cache_positions = positions[None, None, :].expand_as(gates)
        new_bytes = sum(tensor_bytes(t) for t in (key_states,value_states,gates,cache_positions))
        previous_bytes = (sum(tensor_bytes(arr[layer_idx]) for arr in (self.key_cache,self.value_cache,self.retention_weights,self.kv_positions))
                          if layer_idx < len(self.key_cache) else 0)
        append_bytes = 2*(previous_bytes+new_bytes) if previous_bytes else new_bytes
        timer = self.trace.timed('append', append_bytes) if self.trace else nullcontext()
        with timer:
            if layer_idx == 0:
                self.seen_tokens += q
            if layer_idx == len(self.key_cache):
                self.key_cache.append(key_states)
                self.value_cache.append(value_states)
                self.retention_weights.append(gates)
                self.kv_positions.append(cache_positions)
            else:
                self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=-2)
                self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=-2)
                self.retention_weights[layer_idx] = torch.cat([self.retention_weights[layer_idx], gates], dim=-1)
                self.kv_positions[layer_idx] = torch.cat([self.kv_positions[layer_idx], cache_positions], dim=-1)
        self.updated.append(layer_idx)
        return self.key_cache[layer_idx], self.value_cache[layer_idx]

    def mark_final_normalized(self):
        if self.updated != list(range(self.num_layers)):
            raise RuntimeError('All layers must finish before final norm/prune')
        self.final_normalized = True

    def finish_call(self):
        if self.active is None or not self.final_normalized or self.pending:
            raise RuntimeError('Prune only after all layers and final norm')
        event = {'call': self.call_count, 'seen': self.seen_tokens, 'layers': []}
        for layer_idx in range(self.num_layers):
            size = self.get_seq_length(layer_idx)
            record = {'layer': layer_idx, 'seen': self.seen_tokens, 'before': size,
                      'pruned': self.memory_size is not None and size >= self.memory_size + self.buffer_size}
            if record['pruned']:
                old = [self.key_cache[layer_idx], self.value_cache[layer_idx],
                       self.retention_weights[layer_idx], self.kv_positions[layer_idx]]
                timer = self.trace.timed('score', tensor_bytes(old[2]) + 2*tensor_bytes(old[3]) + 8*old[2].numel()) if self.trace else nullcontext()
                with timer:
                    scores = old[2].to(torch.float32) * (self.seen_tokens + 1 - old[3])
                timer = self.trace.timed('topk', tensor_bytes(scores) + scores.shape[0]*scores.shape[1]*self.memory_size*12) if self.trace else nullcontext()
                with timer:
                    selected = torch.topk(scores, self.memory_size, dim=-1).indices
                timer = self.trace.timed('sort', 3*tensor_bytes(selected)) if self.trace else nullcontext()
                with timer:
                    selected, _ = torch.sort(selected, dim=-1)
                timer = self.trace.timed('gather', sum(tensor_bytes(t) for t in old) + int(sum(tensor_bytes(t) for t in old)*self.memory_size/size) + tensor_bytes(selected)) if self.trace else nullcontext()
                with timer:
                    self.key_cache[layer_idx] = old[0].gather(-2, selected.unsqueeze(-1).expand(-1, -1, -1, old[0].shape[-1]))
                    self.value_cache[layer_idx] = old[1].gather(-2, selected.unsqueeze(-1).expand(-1, -1, -1, old[1].shape[-1]))
                    self.retention_weights[layer_idx] = old[2].gather(-1, selected)
                    self.kv_positions[layer_idx] = old[3].gather(-1, selected)
                new = [self.key_cache[layer_idx], self.value_cache[layer_idx], self.retention_weights[layer_idx], self.kv_positions[layer_idx]]
                ranked = scores.sort(dim=-1, descending=True).values
                margins = ranked[..., self.memory_size-1] - ranked[..., self.memory_size]
                if self.trace:
                    self.trace.emit('adapter_prune', call=self.call_count, layer=layer_idx,
                                    seen=self.seen_tokens, old=old, new=new, scores=scores,
                                    selected_physical=selected, margins=margins,
                                    coexistence=storage_ledger(old + new), retained=storage_ledger(new))
                self.prune_count += 1
            record['after'] = self.get_seq_length(layer_idx)
            record['ordered_ids'] = self.kv_positions[layer_idx].tolist()
            event['layers'].append(record)
        self.events.append(event)
        if self.trace:
            self.trace.emit('global_post_call', **event)
        self.active = None
        return event


def absolute_causal_mask(old_positions, new_positions, q_heads, dtype):
    """Per-query/head visibility before append; no top-left causal alignment."""
    if old_positions is None:
        kv_heads = q_heads // 2
        keys = new_positions[None, None, :].expand(1, kv_heads, -1)
    else:
        keys = torch.cat((old_positions, new_positions[None, None, :].expand(1, old_positions.shape[1], -1)), dim=-1)
    visible = keys[:, :, None, :] <= new_positions[None, None, :, None]
    visible = visible.repeat_interleave(q_heads // keys.shape[1], dim=1)
    mask = torch.zeros(visible.shape, dtype=dtype)
    return mask.masked_fill(~visible, torch.finfo(dtype).min), visible


def gate_forward(gate, normalized_hidden):
    # Independent integration expression, with precisely the source operation order.
    out = gate.linear1(normalized_hidden)
    out = gate.act_fn(out)
    out = gate.linear2(out)
    out = out + gate.bias
    return F.logsigmoid(out)


def tiled_attention(module, query, key, value, mask, tile=7):
    from transformers.models.qwen3.modeling_qwen3 import eager_attention_forward
    pieces = []
    for lo in range(0, query.shape[-2], tile):
        hi = min(lo + tile, query.shape[-2])
        piece, _ = eager_attention_forward(module, query[:, :, lo:hi], key, value,
                                          mask[:, :, lo:hi], scaling=module.scaling, dropout=0.0)
        pieces.append(piece)
    return torch.cat(pieces, dim=1)


class TinyPort(nn.Module):
    """Current native decoder is used on adapter path; manual author route reference.

    A scoped input-layernorm hook provides normalized hidden state to the gate,
    then native Qwen3Attention invokes the ordinary two-value cache update.
    """
    def __init__(self, source_gate_class):
        super().__init__()
        from transformers.models.qwen3.configuration_qwen3 import Qwen3Config
        from transformers.models.qwen3.modeling_qwen3 import Qwen3DecoderLayer, Qwen3RMSNorm, Qwen3RotaryEmbedding
        self.config = Qwen3Config(vocab_size=97, hidden_size=32, intermediate_size=64,
                                 num_hidden_layers=2, num_attention_heads=4, num_key_value_heads=2,
                                 head_dim=8, max_position_embeddings=262144,
                                 rope_parameters={'rope_type': 'default', 'rope_theta': 5000000},
                                 attention_dropout=0.0, attention_bias=False, use_sliding_window=False)
        self.config._attn_implementation = 'eager'
        self.config.retention_gate_intermediate_size = 16
        self.config.retention_gate_bias_init = 0.0
        self.embed = nn.Embedding(97, 32)
        self.layers = nn.ModuleList([Qwen3DecoderLayer(self.config, i) for i in range(2)])
        self.gates = nn.ModuleList([source_gate_class(self.config) for _ in range(2)])
        self.norm = Qwen3RMSNorm(32, eps=1e-6)
        self.rotary = Qwen3RotaryEmbedding(self.config)
        self.head = nn.Linear(32, 97, bias=False)
        self.head.weight = self.embed.weight
        if sum(p.numel() for p in self.parameters()) >= 100000:
            raise ValueError('Tiny parameter cap exceeded')
        self.eval()

    def forward_call(self, token_ids, cache, *, reference=False, native_full=False,
                     trace=None, stale_gate_inputs=None, raw_gate=False, rebase_rope=False):
        from transformers.models.qwen3.modeling_qwen3 import apply_rotary_pos_emb, eager_attention_forward
        from transformers.masking_utils import create_causal_mask
        if self.training or any(module.training for module in self.modules()):
            raise ValueError('Tiny integration admits eval only')
        if self.config.attention_dropout != 0.0 or any(layer.self_attn.attention_dropout != 0.0 for layer in self.layers):
            raise ValueError('Tiny integration admits zero dropout only')
        if self.config.rope_parameters != {'rope_type': 'default', 'rope_theta': 5000000}:
            raise ValueError('Tiny integration requires fixed original default RoPE')
        if token_ids.ndim != 2 or token_ids.shape[0] != 1 or token_ids.dtype != torch.int64:
            raise ValueError('Tiny integration requires unpadded batch-one token IDs')
        qlen = token_ids.shape[1]
        seen = cache._seen_tokens if reference else cache.seen_tokens
        if seen + qlen > 192:
            raise ValueError('Tiny total-token cap exceeded')
        positions = torch.arange(seen, seen + qlen, dtype=torch.int64)
        if not reference:
            cache.begin_call(positions)
        hidden = self.embed(token_ids)
        rope_positions = positions
        if rebase_rope:
            resident = cache.get_cache_length(0) if reference else cache.get_seq_length(0)
            rope_positions = torch.arange(resident, resident + qlen, dtype=torch.int64)
        cos_sin = self.rotary(hidden, rope_positions[None, :])
        normalized_inputs, gate_outputs, layer_outputs = [], [], []
        for idx, (layer, gate) in enumerate(zip(self.layers, self.gates)):
            old = cache.kv_positions[idx] if idx < len(cache.kv_positions) else None
            mask_rows = (0 if old is None else old.shape[-1]) + qlen
            mask_bytes = 4 * qlen * mask_rows * (hidden.element_size() + 1) + positions.numel()*8 + (0 if old is None else tensor_bytes(old))
            timer = trace.timed('mask', mask_bytes) if trace else nullcontext()
            with timer:
                mask, visible = absolute_causal_mask(old, positions, 4, hidden.dtype)
            if reference:
                residual = hidden
                z = layer.input_layernorm(hidden)
                normalized_inputs.append(z.detach().clone())
                gate_input = stale_gate_inputs[idx] if stale_gate_inputs is not None else (hidden if raw_gate else z)
                timer = trace.timed('gate', gate_logical_bytes(gate, gate_input)) if trace else nullcontext()
                with timer:
                    gates = gate(gate_input).transpose(1, 2)
                attn = layer.self_attn
                shape = (*z.shape[:-1], -1, 8)
                query = attn.q_norm(attn.q_proj(z).view(shape)).transpose(1, 2)
                key = attn.k_norm(attn.k_proj(z).view(shape)).transpose(1, 2)
                value = attn.v_proj(z).view(shape).transpose(1, 2)
                query, key = apply_rotary_pos_emb(query, key, *cos_sin)
                key, value, _, _, _ = cache.update(key, value, idx, {'cache_position': positions, 'retention_weights': gates, 'attention_mask': None})
                timer = trace.timed('attention', attention_logical_bytes(query, key, value, mask, attn.num_key_value_groups)) if trace else nullcontext()
                with timer:
                    out, _ = eager_attention_forward(attn, query, key, value, mask, scaling=attn.scaling, dropout=0.0)
                hidden = residual + attn.o_proj(out.reshape(*z.shape[:-1], -1).contiguous())
                hidden = hidden + layer.mlp(layer.post_attention_layernorm(hidden))
            else:
                def hook(module, args, z, layer_idx=idx, source_gate=gate, raw=hidden):
                    normalized_inputs.append(z.detach().clone())
                    gate_input = stale_gate_inputs[layer_idx] if stale_gate_inputs is not None else (raw if raw_gate else z)
                    timer = trace.timed('gate', gate_logical_bytes(source_gate, gate_input)) if trace else nullcontext()
                    with timer:
                        g = gate_forward(source_gate, gate_input).transpose(1, 2)
                    cache.set_metadata(layer_idx, g, positions)
                    gate_outputs.append(g.detach().clone())
                handle = layer.input_layernorm.register_forward_hook(hook)
                # Passing the prepared per-head 4D mask uses the current mask ABI unchanged.
                current_mask = create_causal_mask(self.config, inputs_embeds=hidden, attention_mask=mask,
                                                 past_key_values=cache, position_ids=positions[None, :], layer_idx=idx)
                try:
                    decoder_bytes = tensor_bytes(hidden)*8 + tensor_bytes(current_mask) + sum(tensor_bytes(p) for p in layer.parameters())
                    decoder_bytes += 2*4*qlen*mask_rows*hidden.element_size()
                    timer = trace.timed('attention_and_decoder', decoder_bytes) if trace else nullcontext()
                    with timer:
                        hidden = layer(hidden, attention_mask=current_mask, position_ids=positions[None, :],
                                       past_key_values=cache, use_cache=True, position_embeddings=cos_sin)
                finally:
                    handle.remove()
                if not isinstance(hidden, torch.Tensor):
                    raise TypeError('Current decoder must return Tensor')
                gates = gate_outputs[-1]
            if reference:
                gate_outputs.append(gates.detach().clone())
            layer_outputs.append(hidden.detach().clone())
            if trace:
                trace.emit('tiny_layer', reference=reference, layer=idx, seen_before=seen,
                           positions=positions, normalized_input=normalized_inputs[-1], gate=gates,
                           visibility=visible, output=hidden)
        hidden = self.norm(hidden)
        if reference:
            cache.compress()
        else:
            cache.mark_final_normalized()
            cache.finish_call()
        logits = self.head(hidden)
        last = self.head(hidden[:, -1:, :])
        if trace:
            trace.emit('tiny_post_norm_prune_then_head', reference=reference, positions=positions,
                       final_hidden=hidden, logits=logits, last_head=last)
        return {'logits': logits, 'last_logits': last, 'normalized_inputs': normalized_inputs,
                'gates': gate_outputs, 'layer_outputs': layer_outputs, 'positions': positions}

    def forward_native_full(self, token_ids, cache, positions):
        """Unmodified current native decoders with ordinary DynamicCache; no gate seam."""
        from transformers.masking_utils import create_causal_mask
        hidden = self.embed(token_ids)
        cos_sin = self.rotary(hidden, positions[None, :])
        mask = create_causal_mask(self.config, inputs_embeds=hidden, attention_mask=None,
                                  past_key_values=cache, position_ids=positions[None, :])
        for layer in self.layers:
            hidden = layer(hidden, attention_mask=mask, position_ids=positions[None, :],
                           past_key_values=cache, use_cache=True, position_embeddings=cos_sin)
            if not isinstance(hidden, torch.Tensor):
                raise TypeError('Current decoder must return Tensor')
        return self.head(self.norm(hidden))
