"""Independent list/scalar oracle for margin-separated author cache fixtures.

No numerical package is imported. Binary32 conversion and multiplication are
rounded explicitly using struct; selection uses Python scalar comparisons.
Ties across the top-M boundary are deliberately not assigned a stable-ID rule:
the caller must compare those cases against the same source torch.topk backend.
These functions are implementations only until the guarded Phase A is approved.
"""

from __future__ import annotations

import math
import struct


class ScalarTieError(ValueError):
    """The scalar oracle cannot certify backend-dependent top-k membership."""

    def __init__(self, message, scores, margins, tied_heads):
        super().__init__(message)
        self.scores = scores
        self.margins = margins
        self.tied_heads = tied_heads


def f32(value):
    """Round a finite scalar to IEEE-754 binary32, returning a Python float."""
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("Scalar oracle accepts only finite values")
    try:
        rounded = struct.unpack("=f", struct.pack("=f", value))[0]
    except OverflowError as exc:
        raise ValueError("Scalar value overflows binary32") from exc
    if not math.isfinite(rounded):
        raise ValueError("Scalar value overflows binary32")
    return rounded


def _head_rows(gates, positions):
    if not isinstance(gates, list) or not gates or not isinstance(positions, list) or len(gates) != len(positions):
        raise ValueError("gates and positions must be nonempty equally sized head lists")
    lengths = []
    for head_gates, head_positions in zip(gates, positions):
        if not isinstance(head_gates, list) or not isinstance(head_positions, list) or not head_gates:
            raise ValueError("Each head must contain nonempty scalar lists")
        if len(head_gates) != len(head_positions):
            raise ValueError("Gate and position row counts must match per head")
        if any(type(position) is not int for position in head_positions):
            raise ValueError("Original position IDs must be Python integers")
        if any(left >= right for left, right in zip(head_positions, head_positions[1:])):
            raise ValueError("Original positions must be strictly increasing within each head")
        lengths.append(len(head_gates))
    if len(set(lengths)) != 1:
        raise ValueError("The static source route requires the same resident row count per head")
    return lengths[0]


def scalar_keep(gates, positions, seen, budget, age_shift=1):
    """Return FP32 scores, sorted physical keep indices, and per-head margins.

    Inputs omit the source route's singleton batch dimension: [head][row].
    ``seen`` is the total number of tokens after the complete call, and baseline
    score is f32(f32(gate) * f32(seen + 1 - original_position)). ``age_shift``
    exists for the explicit wrong-age negative control; it defaults to 1.
    The margin is selected-lowest minus rejected-highest in binary64, after
    each score was separately rounded to binary32. For budget == row count,
    the margin is None because there is no rejected row.
    """
    rows = _head_rows(gates, positions)
    if type(seen) is not int or seen <= 0 or type(age_shift) is not int:
        raise ValueError("seen must be a positive integer and age_shift an integer")
    if type(budget) is not int or not 1 <= budget <= rows:
        raise ValueError("budget must be an integer between one and the resident row count")
    all_scores, all_indices, margins, tied_heads = [], [], [], []
    for head_idx, (head_gates, head_positions) in enumerate(zip(gates, positions)):
        scores = []
        for gate, position in zip(head_gates, head_positions):
            if not 0 <= position < seen:
                raise ValueError("Each original position must already belong to the seen prefix")
            age = seen + age_shift - position
            if age <= 0:
                raise ValueError("The scalar score age must be positive")
            scores.append(f32(f32(gate) * f32(age)))
        ranked = sorted(range(rows), key=lambda index: scores[index], reverse=True)
        margin = None if budget == rows else scores[ranked[budget - 1]] - scores[ranked[budget]]
        if margin == 0.0:
            tied_heads.append(head_idx)
        all_scores.append(scores)
        all_indices.append(sorted(ranked[:budget]))
        margins.append(margin)
    if tied_heads:
        raise ScalarTieError("Top-M boundary tie requires unchanged source torch.topk on the same backend",
                             all_scores, margins, tied_heads)
    return {"scores": all_scores, "indices": all_indices, "margins": margins,
            "age_shift": age_shift, "seen": seen, "budget": budget}


def scalar_gather(keys, values, gates, positions, indices):
    """Independently gather paired [head][row][dim] K/V and [head][row] metadata.

    ``indices`` are per-head ascending physical indices, normally produced by
    scalar_keep. K/V row lists are copied to avoid accidental input mutation.
    """
    rows = _head_rows(gates, positions)
    heads = len(gates)
    if (not isinstance(keys, list) or not isinstance(values, list) or not isinstance(indices, list)
            or len(keys) != heads or len(values) != heads or len(indices) != heads):
        raise ValueError("K/V, metadata, and indices must have matching head counts")
    out_keys, out_values, out_gates, out_positions = [], [], [], []
    kept_count = None
    for head in range(heads):
        if len(keys[head]) != rows or len(values[head]) != rows:
            raise ValueError("Paired K/V and metadata must have identical resident row counts")
        keep = indices[head]
        if not isinstance(keep, list) or not keep or any(type(index) is not int or not 0 <= index < rows for index in keep):
            raise ValueError("Keep indices must be nonempty in-range integer lists")
        if any(left >= right for left, right in zip(keep, keep[1:])):
            raise ValueError("Keep indices must be unique and sorted in ascending physical order")
        if kept_count is None:
            kept_count = len(keep)
        elif len(keep) != kept_count:
            raise ValueError("The static source route keeps equal row counts for every head")
        widths = set()
        for key_row, value_row in zip(keys[head], values[head]):
            if not isinstance(key_row, list) or not isinstance(value_row, list) or not key_row or len(key_row) != len(value_row):
                raise ValueError("K/V rows must be nonempty paired vector lists")
            widths.add(len(key_row))
        if len(widths) != 1:
            raise ValueError("K/V vector widths must stay fixed within each head")
        out_keys.append([list(keys[head][index]) for index in keep])
        out_values.append([list(values[head][index]) for index in keep])
        out_gates.append([gates[head][index] for index in keep])
        out_positions.append([positions[head][index] for index in keep])
    return {"keys": out_keys, "values": out_values, "gates": out_gates, "positions": out_positions}
