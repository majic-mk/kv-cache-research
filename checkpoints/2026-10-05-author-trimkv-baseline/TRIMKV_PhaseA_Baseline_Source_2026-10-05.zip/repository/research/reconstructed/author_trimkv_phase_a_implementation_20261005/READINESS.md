# Static TRIM-KV Phase A: implementation for independent review

Status: SOURCE IMPLEMENTED; NUMERICAL IMPORTS, EXECUTION AND TESTS NOT RUN. Preparing these files is not approval to execute. The parent must independently review the final manifest and separately authorize the one guarded attempt.

## Implemented scope

- source_reference.py preserves the full original TrimKVCache and RetentionGate class byte spans. Both full original files, exact spans and byte/line/hash receipts are archived. The classes load lazily into a controlled namespace with real installed CPU dependencies; no author package, Triton or training module is imported. The lookahead helper is an explicit rejecting guard, never a fake numerical implementation. The strict reference wrapper rejects inherited/legacy paths; raw classes are exposed only for explicit source/ABI tests
- author_static_adapter.py owns independent K/V/gate/original-ID state, shares the layer-0 total-seen clock, requires one ordered append per layer, and runs the sole global compression sweep after all layers and final RMSNorm. CPU attention masks are per-head explicit absolute-ID masks. They never enter the author cache's unrelated 2D padding-mask field, which remains None
- The adapter's current-HF query offsets and mask sizes describe compact physical mask coordinates; original absolute IDs are a separate mandatory RoPE/retention input. Tests include unequal layer lengths. The tiny adapter calls current native Qwen3DecoderLayer with a scoped normalized-hidden gate hook and two-value cache update. The source-semantics reference manually integrates unchanged author cache/gate bodies with the same current CPU primitives. The gate-free Full control uses current native decoders and DynamicCache
- scalar_oracle.py independently rounds scalar score products to FP32, ranks separated cases and gathers paired nested lists. It rejects boundary ties rather than inventing tie membership. Explicit exact and near-tie cases compare author and adapter using the same pinned native torch.topk
- test_author_semantics.py contains all eight protocol groups, FP32/BF16 separately. It includes actual wrong-clock and buffer128 cache transitions, source age discrimination, current-token eviction, early-pruned current-attention output discrimination, extra history-boundary and history-only-freeze negatives, stale upper-layer gate inputs, raw/K/V gate and RoPE-rebase negatives, unsupported-route/actual model-entrypoint negatives, unequal-layer mask ABI, GQA/top-left-mask negatives, query tiling and last-only head controls
- trace_schema.py streams small synthetic arrays, ordered IDs, FP32 scores, cutoff margins, event timing, continuous error metrics, operation timings, modeled logical tensor reads/writes (including both gate matrices) and storage coexistence into compressed JSONL. No trained tensors, tokenizer or benchmark payload are used
- run_phase_a_guard.py is a stdlib, fail-closed supervisor. It checks the supplied manifest SHA256, every pinned input, the existing runtime interpreter, explicit execution flag and globally exclusive persistent attempt claim. It never deletes prior data or automatically retries

## Unchanged source and protocol pins

Author commit: 49d2a2951ba12e6431a3986b418ee791b209d7c2

Frozen Phase A protocol: 1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f

Full cache source: bb3013d5ff53a8264218b48bafa513c608ad3919d2c6d4172fb248a8b656cae5

Exact complete cache class, original lines 55–276: 6815beaef692ed88bb3deacd6b30f73c503d4f0e849b7e7db4f3e3d63b4e8015

Full model source: 9fdec3ee6e28177e6805715df41663d30f6662cb600cbee6f401a6c51dc7486c

Exact complete gate class, original lines 134–173: 71ba60d206b37279c3c0f8bce6558fcef70160d420b67f7b400d7ff928160ed6

The manifest pins the implementation, original/snapshot spans, exact preparation and replay-contract text, selected current-HF sources, runtime version/package metadata and interpreter bytes. It is not a complete transitive operating-system or numerical shared-library supply-chain attestation.

## Resource admission and intended output

The intended single output is /tmp/trimkv_phase_a_author_parity_20261005_attempt1, which must be absent. At source preparation /tmp was a separate tmpfs with approximately 5.095 GB free. The workspace was only about 5.011 GB free and cannot reserve the whole evidence allowance while preserving the 5 GB floor. No files were deleted, relocated or recompressed to make space.

Recheck actual values at the authorized launch. Output admission requires at least 5,032,000,000 free bytes, preserving the 5,000,000,000-byte floor after the entire 32,000,000-byte evidence allowance. The source filesystem also retains its 5 GB floor. The guard identifies tmpfs backing, reserves the evidence allowance in host-memory admission and monitors actual MemAvailable, which includes tmpfs use. A fresh directory on another filesystem is a material output-binding change for the parent's review.

- One attempt only; failed or partial attempts remain closed
- 120 seconds guard wall, 90 seconds child CPU hard limit, 5 seconds guard CPU hard limit, 100 seconds aggregate budget
- One intra-op and one inter-op numerical thread, environment thread pools fixed to one
- 1 GiB sampled guard-plus-child-tree RSS, 25 ms target sampling, actual sample gaps disclosed
- Host start floor 3 GB plus tmpfs evidence reserve; continuing 1.5 GB availability floor
- 5 GB disk floor, 32 MB total new evidence, persistent attempt claim included
- Child starts only after a pipe barrier confirms the parent's 5-second hard CPU limit is armed; this handles Linux inherited-hard-limit constraints
- Only the newly created child process group is cleaned up; final /proc identity scan must prove it absent
- The audit hook rejects network, subprocess/fork/process escape, ambiguous/trained tensor-file reads, and writes outside the output. Offline environment variables alone are not a network sandbox

RSS is a sampled abort threshold, not a kernel-hard memory reservation. Cooperative pre-write output partitions enforce at most 24 MB compressed child trace + 2 MB child result + 6 MB total guard evidence, including its persistent claim and reserved terminal receipt. The child audit whitelist permits only its two bounded evidence files; any runtime dependency trying to write a scratch/cache file fails closed. This is not a kernel whole-tree filesystem quota. Per-process OS VmHWM, wait4 maximum RSS and sampled PSS/anonymous/file RSS supplement the observations. A short peak can fall between samples. Kernel CPU limits, child parent-death handling and fail-closed final receipts reduce but do not eliminate host-failure risks. A missing final cleanup receipt is failure, never a pass.

## Acceptance and stopping

Exact source dtype, finite flags, ordered IDs, clocks, append/prune events, cache gathers and bytewise identical-primitives outputs are required. Reordered same-call CPU attention/head comparisons use the original prospective tolerances: FP32 atol 2e-6 / rtol 2e-5; BF16 atol 0.03125 / rtol 0.02. Every negative fixture must actually discriminate. Cost byte counts are explicitly modeled tensor touches/working-set estimates, not measured DRAM traffic; nested decoder/gate/cache totals overlap and must not be summed as exclusive costs. All cutoff margins are recorded; an unintended scalar-boundary tie fails rather than silently weakening the oracle.

Any first semantic error, unsupported dependency, resource stop or guard/cleanup problem terminates the only attempt, preserving partials. No tolerance adjustment, automatic retry, numerical fixture search or second run is authorized by these files. Independent source review and separate authorization are required for a fix/retest.

Both numerical result.json status PASS and successful guard_receipt.json with all cleanup identities absent are required. The latter alone only reports resource supervision. A pass would establish restricted static cache semantics and a tiny current-ABI CPU port, not whole author-program execution, FA2 equivalence, trained 4B accuracy, long-history memory fit, throughput, novelty or publication evidence. Phase B/tokenization/4B execution is not part of this code path.

## Checklist before a parent-approved launch

1. Read the independent review against the exact manifest hash, and resolve every blocking source issue before freezing a replacement manifest
2. Confirm explicit approval for this one synthetic numerical attempt and its exact output path
3. Confirm ATTEMPT_CLAIM.json and the intended output are absent; never remove an existing claim to retry
4. Recheck resource admission, tmpfs backing and current available memory/free disk
5. Use the exact existing .venv/bin/python command in INTENDED_LAUNCH.txt, with the independently reviewed manifest hash
6. Do not import the numerical modules or run pytest, compile/import-based smoke checks, models, tokenizers or gate payloads outside the guard
7. Inspect semantic result, all negative verdicts, resource/HWM/CPU ledger and cleanup proof before making any pass statement

The only preparation validation performed is independent stdlib AST parsing, byte-span extraction and SHA256/source-text inspection. STATIC_VALIDATION.json records those checks. It is not a numerical test report.
