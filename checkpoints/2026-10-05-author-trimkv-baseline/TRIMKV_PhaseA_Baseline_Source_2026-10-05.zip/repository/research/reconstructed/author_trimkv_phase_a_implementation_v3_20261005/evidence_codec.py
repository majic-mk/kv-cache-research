"""Stdlib-only lossless content-addressed typed-row evidence, wire version3.

No numerical packages, pickle, eval, code execution or third-party dependency.
A footer commits serialization inventory only; semantic/guard PASS is separate.
"""
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import struct

MAGIC=b'TKV3ROW\0'
FRAME=struct.Struct('<cQ32s')
CHUNK=struct.Struct('<I32s')
MAX_FRAME=131072
MAX_TENSOR_BYTES=1048576
FOOTER_RESERVE=4096
WIDTHS={'f32':4,'bf16':2,'i64':8,'bool':1}
EXPECTED_EVENTS={'source_receipt':1,'continuous_error':272,'cache_before':80,'cache_after':80,
                 'scalar_scores':28,'native_topk':28,'adapter_prune':44,'global_post_call':216,
                 'negative_control':59,'unequal_layer_api':1,'full_shape_gate':2,'tiny_schedule':2,
                 'tiny_layer':536,'tiny_post_norm_prune_then_head':268,'attention_arrays':4}


class CodecError(ValueError):
    pass


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')


def product(shape):
    result=1
    for value in shape:
        if type(value) is not int or not 0<=value<=1048576:
            raise CodecError('Invalid shape dimension')
        result*=value
    return result


def layout(dtype,shape):
    if dtype not in WIDTHS or not isinstance(shape,list) or len(shape)>8:
        raise CodecError('Unsupported dtype/shape')
    elements=product(shape)
    nbytes=elements*WIDTHS[dtype]
    if nbytes>MAX_TENSOR_BYTES:
        raise CodecError('Tensor exceeds frozen source/shape admission')
    row_bytes=(shape[-1] if shape else 1)*WIDTHS[dtype]
    rows=product(shape[:-1]) if shape else 1
    return nbytes,row_bytes,rows


def finite_bits(dtype,raw):
    if len(raw)%WIDTHS[dtype]:
        raise CodecError('Raw byte length is not dtype aligned')
    if dtype=='f32':
        return all((item[0]&0x7f800000)!=0x7f800000 for item in struct.iter_unpack('<I',raw))
    if dtype=='bf16':
        return all((item[0]&0x7f80)!=0x7f80 for item in struct.iter_unpack('<H',raw))
    if dtype=='bool':
        if any(value not in (0,1) for value in raw):
            raise CodecError('Invalid boolean byte representation')
    return True


def tensor_content_header(dtype,shape,finite):
    return canonical({'dtype':dtype,'shape':shape,'finite':finite})+b'\0'


class Writer:
    def __init__(self,path,limit=23000000,expected_events=None):
        self.path=Path(path)
        self.limit=limit
        self.stream=self.path.open('xb')
        self.used=0
        self.stream_hash=hashlib.sha256()
        self.chunks=[]
        self.chunk_by_digest={}
        self.tensors=[]
        self.tensor_by_digest={}
        self.event_counts={}
        self.events=0
        self.expected_events=dict(EXPECTED_EVENTS if expected_events is None else expected_events)
        self.failed=False
        self.closed=False
        self._commit(MAGIC)

    def _commit(self,data,terminal=False):
        ceiling=self.limit if terminal else self.limit-FOOTER_RESERVE
        if self.used+len(data)>ceiling:
            self.failed=True
            raise OSError('Lossless evidence frame does not fit23MB partition')
        try:
            count=self.stream.write(data)
            self.stream.flush()
            if count!=len(data):
                raise OSError('Partial evidence frame write')
        except BaseException:
            self.failed=True
            raise
        self.used+=len(data)
        self.stream_hash.update(data)

    def _frame(self,kind,payload,terminal=False):
        if len(payload)>MAX_FRAME:
            self.failed=True
            raise CodecError('Evidence frame exceeds frozen maximum')
        data=FRAME.pack(kind,len(payload),hashlib.sha256(kind+payload).digest())+payload
        self._commit(data,terminal=terminal)

    def add_tensor(self,dtype,shape,raw,finite=None):
        """Preserve contiguous logical order and every raw bit, including signed zero."""
        shape=list(shape)
        raw=bytes(raw)
        nbytes,row_bytes,rows=layout(dtype,shape)
        if len(raw)!=nbytes:
            raise CodecError('Tensor byte length disagrees with dtype/shape')
        if finite is None:
            finite=finite_bits(dtype,raw)
        if type(finite) is not bool:
            raise CodecError('Finite flag must be boolean')
        content=hashlib.sha256(tensor_content_header(dtype,shape,finite)+raw).hexdigest()
        row_ids=[]
        for index in range(rows):
            row=raw[index*row_bytes:(index+1)*row_bytes]
            digest=hashlib.sha256(row).digest()
            previous=self.chunk_by_digest.get(digest)
            if previous is not None:
                if self.chunks[previous]!=row:
                    raise CodecError('SHA256 row collision: unequal bytes are never reused')
                row_ids.append(previous)
            else:
                identifier=len(self.chunks)
                if identifier>=100000:
                    raise CodecError('Unique chunk count exceeds source-bound ID width')
                self._frame(b'C',CHUNK.pack(identifier,digest)+row)
                self.chunks.append(row)
                self.chunk_by_digest[digest]=identifier
                row_ids.append(identifier)
        descriptor={'dtype':dtype,'shape':shape,'nbytes':nbytes,'row_bytes':row_bytes,
                    'row_ids':row_ids,'raw_sha256':hashlib.sha256(raw).hexdigest(),
                    'content_sha256':content,'finite':finite}
        previous=self.tensor_by_digest.get(content)
        if previous is not None:
            if self.tensors[previous]!=descriptor:
                raise CodecError('SHA256 tensor collision: unequal descriptors are never reused')
            return {'$tensor':previous}
        identifier=len(self.tensors)
        if identifier>=10000:
            raise CodecError('Tensor count exceeds source-bound ID width')
        self._frame(b'T',canonical({'id':identifier,**descriptor}))
        self.tensors.append(descriptor)
        self.tensor_by_digest[content]=identifier
        return {'$tensor':identifier}

    def emit(self,record):
        if not isinstance(record,dict) or not isinstance(record.get('event'),str):
            raise CodecError('Event records require a string event name')
        try:
            self._frame(b'E',canonical(record))
        except BaseException:
            self.failed=True
            raise
        name=record['event']
        self.events+=1
        self.event_counts[name]=self.event_counts.get(name,0)+1

    def close(self):
        if self.closed:
            return
        self.closed=True
        footer={'events':self.events,'event_counts':self.event_counts,'tensors':len(self.tensors),
                'chunks':len(self.chunks),'inventory_complete':self.event_counts==self.expected_events,
                'expected_events':self.expected_events,'serialization_failed':self.failed,
                'preceding_sha256':self.stream_hash.hexdigest(),
                'semantic_acceptance':'requires independent result.json PASS and accepted guard/cleanup receipts'}
        try:
            self._frame(b'F',canonical(footer),terminal=True)
        finally:
            self.stream.close()


@dataclass(frozen=True)
class TypedArray:
    dtype: str
    shape: tuple
    finite: bool
    raw: bytes

    def python_values(self):
        """Optional value view; raw remains the authority for NaN payloads and zero signs."""
        if self.dtype=='f32':
            return [value[0] for value in struct.iter_unpack('<f',self.raw)]
        if self.dtype=='bf16':
            return [struct.unpack('<f',struct.pack('<I',word[0]<<16))[0] for word in struct.iter_unpack('<H',self.raw)]
        if self.dtype=='i64':
            return [value[0] for value in struct.iter_unpack('<q',self.raw)]
        return [bool(value) for value in self.raw]


class Reader:
    def __init__(self,path,expected_events=None):
        self.path=Path(path)
        self.expected_events=dict(EXPECTED_EVENTS if expected_events is None else expected_events)
        self.chunks=[]
        self.tensors=[]
        self.chunk_hashes={}
        self.tensor_hashes={}
        self.event_counts={}
        self.events=0
        self.footer=None
        self.partial_error=None
        self.bytes_read=0
        self.frames_read=0

    def _raw_parts(self,desc):
        for identifier in desc['row_ids']:
            yield self.chunks[identifier]

    def _tensor(self,desc):
        expected={'id','dtype','shape','nbytes','row_bytes','row_ids','raw_sha256','content_sha256','finite'}
        if not isinstance(desc,dict) or set(desc)!=expected or type(desc['id']) is not int or desc['id']!=len(self.tensors):
            raise CodecError('Tensor descriptor fields/order invalid')
        nbytes,row_bytes,rows=layout(desc['dtype'],desc['shape'])
        if desc['nbytes']!=nbytes or desc['row_bytes']!=row_bytes or type(desc['finite']) is not bool:
            raise CodecError('Tensor length/finite metadata mismatch')
        ids=desc['row_ids']
        if not isinstance(ids,list) or len(ids)!=rows or any(type(i) is not int or not 0<=i<len(self.chunks) for i in ids):
            raise CodecError('Unknown chunk reference or wrong logical row count')
        raw_hash=hashlib.sha256()
        content_hash=hashlib.sha256(tensor_content_header(desc['dtype'],desc['shape'],desc['finite']))
        actual_finite=True
        for row in self._raw_parts(desc):
            if len(row)!=row_bytes:
                raise CodecError('Chunk byte length disagrees with tensor logical row')
            raw_hash.update(row);content_hash.update(row)
            actual_finite &= finite_bits(desc['dtype'],row)
        if actual_finite!=desc['finite']:
            raise CodecError('Finite flag disagrees with raw bits')
        if raw_hash.hexdigest()!=desc['raw_sha256'] or content_hash.hexdigest()!=desc['content_sha256']:
            raise CodecError('Full reconstructed tensor hash mismatch')
        previous=self.tensor_hashes.get(desc['content_sha256'])
        if previous is not None:
            comparable={k:v for k,v in desc.items() if k!='id'}
            old={k:v for k,v in self.tensors[previous].items() if k!='id'}
            if old!=comparable:
                raise CodecError('Tensor hash collision detected')
            raise CodecError('Duplicate tensor descriptor must use its existing ID')
        self.tensor_hashes[desc['content_sha256']]=desc['id']
        self.tensors.append(desc)

    def _refs(self,value,reconstruct):
        if isinstance(value,dict):
            if set(value)=={'$tensor'}:
                identifier=value['$tensor']
                if type(identifier) is not int or not 0<=identifier<len(self.tensors):
                    raise CodecError('Unknown tensor reference')
                if not reconstruct:
                    return value
                desc=self.tensors[identifier]
                return TypedArray(desc['dtype'],tuple(desc['shape']),desc['finite'],b''.join(self._raw_parts(desc)))
            return {k:self._refs(v,reconstruct) for k,v in value.items()}
        if isinstance(value,list):
            return [self._refs(v,reconstruct) for v in value]
        return value

    def records(self,*,require_complete=True,reconstruct=False,allow_prefix=False):
        """Yield complete verified events. Prefix recovery is explicit and never a pass."""
        digest=hashlib.sha256()
        try:
            with self.path.open('rb') as stream:
                magic=stream.read(len(MAGIC))
                if magic!=MAGIC:
                    raise CodecError('Wrong magic/version/endian contract')
                digest.update(magic);self.bytes_read=len(magic)
                while True:
                    header=stream.read(FRAME.size)
                    if not header:
                        break
                    if len(header)!=FRAME.size:
                        raise CodecError('Truncated frame header')
                    kind,length,checksum=FRAME.unpack(header)
                    if kind not in (b'C',b'T',b'E',b'F') or length>MAX_FRAME:
                        raise CodecError('Unknown frame or oversized frame length')
                    payload=stream.read(length)
                    if len(payload)!=length:
                        raise CodecError('Truncated frame payload')
                    if hashlib.sha256(kind+payload).digest()!=checksum:
                        raise CodecError('Frame checksum mismatch')
                    if self.footer is not None:
                        raise CodecError('Trailing frames after footer')
                    if kind==b'C':
                        if len(payload)<CHUNK.size:
                            raise CodecError('Truncated chunk header')
                        identifier,raw_hash=CHUNK.unpack(payload[:CHUNK.size]);raw=payload[CHUNK.size:]
                        if identifier!=len(self.chunks) or hashlib.sha256(raw).digest()!=raw_hash:
                            raise CodecError('Chunk ID/hash mismatch')
                        if raw_hash in self.chunk_hashes:
                            previous=self.chunks[self.chunk_hashes[raw_hash]]
                            if previous!=raw:
                                raise CodecError('Row hash collision detected')
                            raise CodecError('Duplicate row must use its existing ID')
                        self.chunk_hashes[raw_hash]=identifier;self.chunks.append(raw)
                    elif kind==b'T':
                        self._tensor(json.loads(payload))
                    elif kind==b'E':
                        event=json.loads(payload)
                        if not isinstance(event,dict) or not isinstance(event.get('event'),str):
                            raise CodecError('Malformed event record')
                        event=self._refs(event,reconstruct)
                        self.events+=1;name=event['event']
                        self.event_counts[name]=self.event_counts.get(name,0)+1
                        yield event
                    else:
                        footer=json.loads(payload)
                        if (footer.get('preceding_sha256')!=digest.hexdigest() or footer.get('events')!=self.events
                                or footer.get('event_counts')!=self.event_counts or footer.get('chunks')!=len(self.chunks)
                                or footer.get('tensors')!=len(self.tensors)):
                            raise CodecError('Footer inventory/stream hash mismatch')
                        if footer.get('expected_events')!=self.expected_events:
                            raise CodecError('Footer expected inventory differs from independently supplied contract')
                        if footer.get('inventory_complete')!=(self.event_counts==self.expected_events):
                            raise CodecError('Footer completion flag mismatch')
                        self.footer=footer
                    digest.update(header+payload)
                    self.bytes_read+=len(header)+len(payload);self.frames_read+=1
                if self.footer is None:
                    raise CodecError('Missing committed footer')
                if require_complete and (self.footer.get('serialization_failed') or not self.footer.get('inventory_complete')):
                    raise CodecError('Only a partial serialization inventory was committed')
        except (CodecError,ValueError,UnicodeError) as exc:
            self.partial_error=type(exc).__name__+': '+str(exc)
            if not allow_prefix:
                raise

    def verify(self,require_complete=True):
        for _ in self.records(require_complete=require_complete):
            pass
        return {'verified':True,'inventory_complete':self.footer['inventory_complete'],
                'events':self.events,'event_counts':self.event_counts,'tensors':len(self.tensors),
                'chunks':len(self.chunks),'bytes':self.bytes_read,'frames':self.frames_read,
                'semantic_acceptance':'not established by codec verification'}
