# Lossless trace v3: complete-suite source/shape bound

Status: **source-only preparation; no numerical test, runtime import, or rerun performed for this bound**. This is an evidence-size argument, not a numerical parity result, runtime result, or permission to execute the suite.

The fixed v2 numerical suite and adapter are unchanged. The calculation covers the entire successful route, not the previously reached prefix. The agreed v3 format uses uncompressed raw tensor rows, content-addressed row and tensor descriptors, and lossless JSON for the original event metadata and scalar oracles. It does not omit arrays, round values, alter cases, or depend on compression ratios.

## Result and scope

**Complete trace upper bound: 14,741,864 bytes < 23,000,000 bytes.**

The trace partition has **8,258,136 bytes of headroom**. The overall allocation remains 32,000,000 bytes: trace 23,000,000; result 2,000,000; import scratch 1,000,000; guard 6,000,000. This argument does not transfer unused space between partitions.

The bound assumes the documented framing below and the pinned source files. It bounds completed-suite evidence if the fixed suite executes successfully. A failed run emits a prefix; frame admission must preserve a valid completed prefix and reserve the footer. This calculation neither establishes that the numerical assertions pass nor establishes CPU/RSS compliance.

## Pinned source inspected

All paths below are relative to `research/reconstructed/author_trimkv_phase_a_implementation_v2_20261005/`.

| File | SHA-256 |
|---|---|
| `test_author_semantics.py` | `314fc0840c02011b4a626f83ff4943b45d41a4d5be057d4ec66d275d4e942d18` |
| `author_static_adapter.py` | `a566664113273de992f35d010e13ca2c75ead13479e4dc0afa3619de463b309a` |
| `scalar_oracle.py` | `b7f4671bd40d8ae09f6934beb200b09f1c73fb8d8fbd4e535b7becd433a8c9f6` |
| `source_reference.py` | `138849d7ce37c60af9025f666a9f9a17d9420d94a6dcdcd5a5b607eae40d3477` |

The original source reference's `TrimKVCache.update` appends K/V with `cat` along the token dimension; its `compress` gathers whole K/V rows. The adapter does the same. Those operations preserve each row's bytes. The retained membership may differ arbitrarily for purposes of the size proof: only a subset of already appended rows can be retained.

Only source text, standard-library JSON/hash operations, and integer shape/control-flow arithmetic were used. No numerical package was imported, no fixture tensor or model output was generated, and no test module was imported or executed.

## Framing charged

- File magic: 8 bytes
- Every frame: `<cQ32s>`, a 41-byte type/length/SHA-256 header
- C frame: `<I32s>` chunk ID/raw-row digest, then raw row bytes. Fixed overhead is 36 + 41 = **77 bytes per unique row**
- T frame: canonical JSON with `id`, short-code `dtype`, `shape`, `row_bytes`, `nbytes`, `row_ids`, `raw_sha256`, `content_sha256`, and `finite`. Charge **512 fixed payload bytes + 41 header bytes**, plus **6 bytes per row ID**
- E frame: canonical JSON preserving every original event field; each tensor is replaced by `{"$tensor": integerID}`. Charge **2,048 structural payload bytes + 41 header bytes per event**, **32 bytes per tensor appearance**, and the separate scalar-list allowance below
- Source receipt: an additional 4,096 bytes beyond its ordinary event allowance
- F frame: reserve 4,096 payload bytes plus its 41-byte header

There are at most 26,306 unique rows, so every chunk ID is at most five decimal digits. Six bytes per row reference include a delimiter; brackets and field names are in the fixed T allowance. At most 5,648 tensors means four-digit tensor IDs; `{"$tensor":5648}` is far below the charged 32 bytes. Rank is at most four; dimensions are at most 2,560; row bytes at most 10,240; tensor bytes at most 393,216. The two 64-character tensor hashes, these scalar fields, brackets, and keys fit within the 512-byte fixed T allowance without using tensor-content deduplication.

## Complete control-flow census

For a schedule, start resident length `n=0`; on each call set `n += q`; prune exactly when `n >= M+32`, then set `n=M`. This recurrence depends only on source schedules and shapes, not numerical scores or selected membership.

Each cache fixture runs both layers. The table shows per-run sums before multiplying by the indicated number of dtype instances. `prune_n` sums pre-prune lengths and `prune_m` sums retained lengths across global sweeps.

| Fixture | Calls | Sum before n | Sum after n | Sweeps | Sum prune n | Sum prune M | Instances |
|---|---:|---:|---:|---:|---:|---:|---:|
| threshold M=8: 39,1 | 2 | 79 | 47 | 1 | 40 | 8 | 2 |
| threshold M=32: 63,1 | 2 | 127 | 95 | 1 | 64 | 32 | 2 |
| two_events: 40, then 32 Q1 | 33 | 824 | 760 | 2 | 80 | 16 | 2 |
| oversized: 96 | 1 | 96 | 8 | 1 | 96 | 8 | 2 |
| age discriminator: 40 | 1 | 40 | 8 | 1 | 40 | 8 | 2 |
| gapped membership: 40,32 | 2 | 80 | 16 | 2 | 80 | 16 | 1 |
| **Weighted cache_run total** | **80** | **2,412** | **1,852** | **14** | **720** | **160** | |

Exact/near ties add two FP32 calls, each of pre-prune length 40 and post-prune length 8; each has two layer-prune records and one global record. They have no `cache_before`, `cache_after`, scalar-score, or native-topk records.

Tiny integration is `[64,3]+[1]*65`: **67 calls and 132 input tokens per dtype/path**. There are exactly two traced paths (reference and adapter) and two dtypes. Dense/native/no-crop/stale/frozen/rebased controls and the extra-history-boundary forwards have no trace argument; the no-crop adapter also has no trace field. They are still executed by the unchanged test but do not generate evidence arrays. Per dtype/path, sum of pre-prune length is 1,655, sum of post-prune length is 1,535, and three sweeps have total pre-prune length 144 and retained length 24. Only the traced adapter emits prune/global records. Visibility elements per layer/path sum to `sum(4*q*n)=22,836`.

| Event kind | Complete count |
|---|---:|
| source_receipt | 1 |
| cache_before | 80 |
| cache_after | 80 |
| scalar_scores | 28 |
| native_topk | 28 |
| adapter_prune | 44 |
| global_post_call | 216 |
| tiny_schedule | 2 |
| tiny_layer | 536 |
| tiny_post_norm_prune_then_head | 268 |
| continuous_error | 272 |
| unequal_layer_api | 1 |
| full_shape_gate | 2 |
| negative_control | 59 |
| attention_arrays | 4 |
| **Total E frames** | **1,621** |

The 44 layer-prune records are 28 cache-run + 4 tie + 12 tiny records. The 216 global records are 80 cache-run + 2 tie + 134 tiny-adapter records. The 272 error records are 268 tiny comparisons + 4 A7 comparisons. Negative controls are 8 age/membership, 1 buffer128, 13 route, 3 bad-adapter, 2 raw-author ABI, 1 upper-layer timing, 3 model guard, 6 checked-reference API, 6 gate, 8 tiny, and 8 A7 controls.

## Tensor, row, and raw-appearance census

A last-dimension row for shape `(d0,...,dk)` has `product(d0,...,d{k-1})` rows and `dk*element_size` bytes. A one-dimensional tensor has one row. The census charges every tensor appearance and every row reference; it does **not** assume whole-tensor deduplication or equality between reference and adapter results.

A cache layer contributes K/V `(1,H,n,D)`, gate `(1,H,n)`, and IDs `(1,H,n)`. A prune record has those four tensors both before and after, scores `(1,H,n)` FP32, selected indices `(1,H,M)` int64, and margins `(1,H)` FP32: eleven tensor appearances. The native-topk record has its three corresponding tensors.

| Trace source | Tensor appearances | Row references | Raw appearance bytes | Cache-fixture K/V rows | Cache-fixture K/V bytes |
|---|---:|---:|---:|---:|---:|
| cache_before | 640 | 79,744 | 30,392,128 | 77,184 | 29,966,336 |
| cache_after | 640 | 61,824 | 23,149,120 | 59,264 | 22,822,912 |
| native_topk | 84 | 476 | 67,456 | 0 | 0 |
| cache-run adapter_prune | 308 | 29,532 | 11,430,528 | 28,160 | 11,206,656 |
| wrong_global_clock negative arrays | 4 | 32 | 2,048 | 0 | 0 |
| early_prune_current_attention negative arrays | 4 | 32 | 12,288 | 0 | 0 |
| full_shape_gate | 6 | 12 | 61,536 | 0 | 0 |
| tiny_schedule | 2 | 2 | 2,112 | 0 | 0 |
| tiny_layer | 2,680 | 7,944 | 400,224 | 0 | 0 |
| tiny_post_norm_prune_then_head | 1,072 | 1,592 | 286,548 | 0 | 0 |
| tiny adapter_prune | 132 | 2,844 | 85,536 | 0 | 0 |
| A7 attention_arrays | 32 | 540 | 12,016 | 0 | 0 |
| tie adapter_prune | 44 | 3,268 | 1,598,592 | 3,072 | 1,572,864 |
| **Total** | **5,648** | **187,842** | **67,500,132** | **167,680** | **65,568,768** |

Important inclusions:

- A5 records both full-shaped `(1,2,2560)` input/normalized tensors and `(1,2,8)` gate output, in both dtypes. Gate parameters themselves are never passed to a trace emission in the fixed source
- Each tiny layer records positions, normalized input `(1,q,32)`, gate `(1,2,q)`, visibility `(1,4,q,n)`, and output `(1,q,32)` for both paths and both dtypes
- Each tiny post record includes positions, final hidden `(1,q,32)`, full logits `(1,q,97)`, and last-only head `(1,1,97)`
- A7 has four dtype/qlen combinations (`q=1,11`), with all eight tensors per record: Q, K, V, current/old IDs, visibility, dense output, tiled output. No untraced wrong-output tensors are silently added to or removed from the event inventory
- All typed cache metadata, top-k scores, IDs, margins, tiny K/V, and numerical model outputs are charged as entirely distinct rows
- Scalar gathered K/V lists are used in assertions but are not passed to `trace.emit`; scalar score oracles are passed and are retained in the JSON allowance below

## The only deduplication premise used

For cache-only fixtures, `inputs(start, qlen, layer, dtype, style)` constructs a K row from absolute ID, head, dimension, layer, and dtype. The V row is a fixed function of that K row and dtype. `style='age'` changes only gates. Exact/near-tie changes also change only gates. Every recorded cache-only input has absolute ID in `[0,95]`, eight heads, two layers, and D=128. Cloning, concatenation along tokens, and gathering whole rows preserve those row bytes.

Consequently all appearances of cache-only K/V are drawn from at most

`96 IDs * 8 heads * 2 layers * 2 K/V kinds * 2 dtypes = 6,144 rows`.

Their total raw bytes are at most

`96 * 8 * 2 * 2 * 128 * (4 FP32 bytes + 2 BF16 bytes) = 2,359,296 bytes`.

This bound allows every such row to differ, including rows that happen to coincide across head/layer/dtype. It does not infer values from expected results, rely on lucky SHA compression, or assume the tiny model reproduces any numerical value. SHA-256 is the content-addressing/checking mechanism; a sound lossless implementation must fail closed on a detected digest/length inconsistency rather than merge inconsistent content.

Charge every other row occurrence as unique:

- Non-fixture rows: `187,842 - 167,680 = 20,162`
- Non-fixture raw bytes: `67,500,132 - 65,568,768 = 1,931,364`
- **Unique chunks <= 20,162 + 6,144 = 26,306**
- **Unique raw chunk bytes <= 1,931,364 + 2,359,296 = 4,290,660**

## Lossless JSON metadata allowance

The only large non-tensor nested numerical lists emitted are scalar-oracle lists and `global_post_call.layers[].ordered_ids`. They are retained losslessly as JSON.

- Oracle scores: `2 layers * 8 heads * sum(prune_n=720) = 11,520` floats
- Oracle margins: `28 layer events * 8 = 224` floats
- Oracle selected indices: `2 layers * 8 heads * sum(prune_M=160) = 2,560` integers
- Global ordered IDs: `1,852*2*8 + 2*8*2*8 + 1,535*2 dtypes*2 layers*2 heads = 42,168` integers

Charge **32 bytes per finite Python float including delimiter** and **4 bytes per integer including delimiter** (all these integers are nonnegative and below 132). Float and integer leaves therefore cost at most

`(11,520+224)*32 + (2,560+42,168)*4 = 554,720 bytes`.

A further 45,280 bytes for their nested-list punctuation is available inside the **600,000-byte allowance**. Even charging four punctuation bytes for every list/container uses less than 14,000 bytes: oracle list counts are 10 score lists + 10 index lists + 1 margin list per layer event; global ordered IDs contain two layer tensors per event, each with 1 batch wrapper plus outer wrapper plus H head lists. This ample remainder also absorbs conservative separator counting.

For other E payload structure, inspect the fixed emission sites and the constructed global record: excluding the receipt, charged tensor references, and the above large lists, each record has less than 512 ASCII key/string characters, at most 32 scalar numeric/boolean leaves, and less than 256 punctuation bytes. At 32 bytes per leaf this is below 2,048 bytes. The one special short schedule list has only 67 values (64, 3, and sixty-five 1s), under 256 bytes, also fitting its 2,048-byte event allowance. Runtime timers live in the result or Trace counters and are not a per-operation stream of additional events. The receipt file is 2,482 bytes before removing formatting whitespace, so its additional 4,096-byte allowance is conservative.

## Full framed-file upper bound

| Component | Bound in bytes |
|---|---:|
| Unique raw chunk payload | 4,290,660 |
| C overhead: 26,306 * 77 | 2,025,562 |
| T fixed payload: 5,648 * 512 | 2,891,776 |
| T row IDs: 187,842 * 6 | 1,127,052 |
| T headers: 5,648 * 41 | 231,568 |
| E structural payload: 1,621 * 2,048 | 3,319,808 |
| E tensor references: 5,648 * 32 | 180,736 |
| E scalar nested lists | 600,000 |
| Extra source receipt | 4,096 |
| E headers: 1,621 * 41 | 66,461 |
| File magic | 8 |
| Footer payload reserve | 4,096 |
| Footer header | 41 |
| **Total** | **14,741,864** |
| **Trace partition** | **23,000,000** |
| **Remaining headroom** | **8,258,136** |

Before any frame bytes are written, its complete encoded length and checksum must be available and the full frame plus required footer reserve admitted against the cap. If cap admission rejects a frame, previously completed frames must remain readable. Footer completion is a separate property from numerical PASS: the footer must distinguish a finalized evidence prefix from the full expected 1,621-event inventory.

## Implementation source cross-check

Source inspection of the prepared v3 `evidence_codec.py` and `trace_schema.py` confirms the charged 8-byte magic, 41-byte frame header, 36-byte chunk metadata, canonical JSON descriptor fields, integer tensor references, raw contiguous CPU byte extraction, and no compression. SHA-256 row reuse is additionally guarded by exact byte comparison; whole-tensor reuse compares the complete descriptor. Four numerical/core files listed above compare byte-for-byte equal between v2 and v3.

All per-frame payload admissions also fit the source shapes: C payload <= 10,240 + 36 = 10,276 bytes; T payload <= 512 + 768*6 = 5,120 bytes; every E payload < 32,768 bytes. For the largest scalar-score E, even combining independent maximum lengths gives 768 score floats, 8 margin floats, 256 index integers, their bounded punctuation, and the 2,048-byte structure allowance, below 32,768 bytes. The largest ordered-ID event has at most 1,008 three-digit IDs. These are all below the implementation's 131,072-byte payload limit.

The implementation reserves 4,096 total bytes for the terminal frame. A standard-library JSON encoding of the source-defined footer schema with all full-inventory count bounds and longest boolean spelling is 946 payload bytes, 987 including its header, so that reservation suffices. The full-file bound above deliberately charges an even larger 4,096-byte footer payload plus header. This cross-check did not import the codec or trace modules and did not execute numerical code.
