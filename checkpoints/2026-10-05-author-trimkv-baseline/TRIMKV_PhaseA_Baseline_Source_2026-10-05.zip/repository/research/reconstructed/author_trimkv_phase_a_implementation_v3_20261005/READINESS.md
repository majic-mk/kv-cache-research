# Phase A v3: lossless, bounded evidence serialization

Status: full Phase A numerical run NOT RUN under v3. The separately approved stdlib-only codec check passed. Main-suite execution still requires the independent final source review, this version's final manifest hash, live resource admission and separate parent authorization.

## What failed before, and what changes here

Attempt1 is preserved at /tmp/trimkv_phase_a_author_parity_20261005_attempt1. Native import failed because its two-file write whitelist blocked tempfile. No semantic fixture group completed. Attempt2 is preserved at /tmp/trimkv_phase_a_author_parity_20261005_attempt2. The narrow import fix succeeded, but repeated floating-point JSON array dumps exhausted the23MB compressed trace allowance during the initial FP32 cache sequence, around seen70. A rejected compressed write had already advanced the gzip state, leaving only a readable prefix. This was an evidence-volume failure, not a completed method result. Neither stopped attempt is a pass, and neither is reopened.

V3 changes only evidence encoding/decoding and the guard's versioned output/CPU accounting. The complete test_author_semantics.py, author_static_adapter.py, source_reference.py and scalar_oracle.py files are byte-identical to frozen v2. Original author cache/gate spans, source policy, fixture arrays, schedules, negative controls, FP32/BF16 cases, numerical tolerances and resource maxima are unchanged. No array or event is omitted; no value is rounded; no case is reduced; no cap is raised.

The serializer's snapshot/byte-copy behavior is independent of attention/cache math. A live contiguous CPU tensor's exact buffer bytes are copied with ctypes.string_at while the tensor is held, after original finite checking, dtype/shape/size admission and little-endian checks. No float-text conversion, NumPy dependency, model import or numerical calculation is added by the codec itself. Native tensor extraction is source-reviewed only; the separate codec check intentionally imported no Torch.

## Complete-suite space proof before a new main run

The unchanged successful suite emits1,621 events,5,648 tensor fields and187,842 logical row references. Naively materialized tensor occurrences contain67,500,132 raw bytes before JSON formatting. Overlapping cache states repeatedly contain the same originating K/V rows.

The independent conservative proof does NOT assume equal values across separately constructed fixtures and does NOT rely on compression:

- Unique raw row bytes at most12,075,620
- At most44,418 unique chunks, with77 framing/hash bytes each
- At most5,648 tensor descriptors, with512 fixed payload bytes +41 frame bytes each
- At most187,842 row IDs, at most6 JSON bytes each
- At most1,600,000 bytes for all event JSON and event framing
-8-byte header and4,096-byte footer reservation plus41-byte footer header
- Complete trace at most21,350,347 bytes; headroom1,649,653 bytes under the unchanged23,000,000-byte trace partition

See the pinned independent FINAL_SOURCE_BOUND.md and SOURCE_BOUND_REVIEW.md under author_trimkv_phase_a_trace_bound_review_20261005_1345. EVIDENCE_BOUND.md/SOURCE_BOUND.json also give a tighter14,741,864-byte proof using source-provable equal cache rows across fixtures. The looser independent bound alone suffices for admission. Both bounds count descriptors, references, scalar/oracle arrays, metadata, frame hashes and footer, not just raw row data.

## Version3 wire contract

trace.tkv3 begins with8-byte magic TKV3ROW followed by NUL. All integers in binary framing and tensor bytes use explicit little endian. Supported source tensor dtypes are FP32, BF16, int64 and bool.

Every complete frame is built before admission. Header is little-endian type byte, uint64 payload length and32-byte SHA256(type+payload), totaling41 bytes. The frame is checked against the fixed file budget before it is written. A stopped writer leaves all preceding complete frames valid and reserves room for a failure footer.

- C: uint32 chunk ID,32-byte raw-row SHA256, then exact raw last-axis row bytes. Identical rows reuse the existing integer ID. Unequal bytes with an equal hash are rejected
- T: canonical JSON tensor descriptor: ID, dtype, shape, row byte width, total bytes, ordered row IDs, raw-array SHA256, dtype/shape/finite-bound content SHA256 and finite flag. Repeated tensors reuse their ID; hash collisions with unequal descriptors are rejected
- E: complete original event payload with tensor fields replaced by typed tensor references. Nested scalar/list values remain lossless JSON, including scalar negative zero. All fields and event order remain present
- F: stream-prefix hash, frame inventories, event counts and completion/failure flags. The expected1,621-event inventory is independently frozen in code, never trusted from the file's own claim

Reader reconstructs each tensor's exact dtype/shape/order/raw bits and verifies chunk, descriptor and full-array hashes plus finite flags. It can stream events without storing all reconstructed copies. Explicit prefix recovery exposes only complete verified events and records why completion failed. A valid codec footer or complete event inventory does not establish semantic/resource success by itself.

reconstruct_evidence.py performs codec verification only and never aggregates unrelated run receipts into a pass. Parent acceptance separately binds the exact reviewed manifest/output, semantic result, all eight groups and59 negative controls, guard resource receipt, owned-process disappearance and empty owned scratch.

## Separate serializer-only check already completed

Frozen check manifest715dffdff733c0b808e12d0c76dcc7fdcbfd46209a959e877262fc8b80e12a3b was independently reviewed and separately authorized. Output /tmp/trimkv_phase_a_serializer_check_20261005 is preserved; result SHA25626d39d256baf592e02fbe0ed339d10e1b1e84c4005c815784d788fc136d02cd0.

All28 checks passed with exit0: exact FP32/BF16 special bit patterns and signed zero, int64 extremes/bool, empty/scalar shapes, strided Python-memoryview logical order, overlapping row/repeated tensor reuse, nested scalar/list fields, frame/chunk/tensor hash and reference/shape/dtype/finite/order corruption, truncated headers/payload/footer, trailing bytes, trusted inventory, explicit partial recovery, injected collision-map guards and cap-safe committed frames. No Torch, Transformers, NumPy, model or main Phase A fixture was imported/run.

Observed processCPU0.078223s, wall0.030249s, OS maxRSS14,417,920 bytes,18 files and62,219 bytes. Limits were15 seconds wall,5 seconds process CPU hard,128MiB address-space hard,24 files each at most64KiB. This is a codec correctness result, not a static-cache parity result.

## Unchanged main resource envelope and next output

Intended fresh output: /tmp/trimkv_phase_a_author_parity_20261005_attempt3. No v3 claim/output existed when frozen. Original attempts remain untouched.

-120 seconds wall;90 seconds child CPU hard;5 seconds guard CPU hard;100 seconds cumulative CPU gate
-1 GiB sampled guard+child-tree RSS,25ms target, actual gaps and OS high-water marks disclosed
-One intra-op and one inter-op thread
-3GB starting host availability plus tmpfs evidence reserve;1.5GB continuing floor after remaining unwritten reserve
-Output filesystem start free at least5,032,000,000 bytes;5GB continuing floor and source-filesystem floor
-Same32MB cooperative output partitions:23MB trace,2MB result,1MB owned native-import scratch,6MB guard including receipt reserve
-One new, separately authorized v3 numerical attempt at most; first failure stops, partials preserved, no automatic retry

Failed attemptCPU is conservatively12.501416 seconds. Measured codecCPU brings measured prior work to12.579639 seconds. To cover post-receipt interpreter work conservatively, v3 charges the codec check's full5-second hard allowance, reserving17.501416 seconds against the cumulative100-second gate before any new main run. Measured and reserved values are reported distinctly.

The reviewed v2 scratch policy remains unchanged except the exact trace filename. Native import may create only its one4-byte probe, one owned directory and exact2,355-byte generated source under an import-only64KiB soft file cap. Scratch writes seal before fixtures; native cleanup can touch only its owned paths. Final guard acceptance requires checked-empty scratch and all owned process identities absent. No installed numerical methods or dependencies are patched.

RSS is sampled, not a hard kernel memory reservation. Cooperative write limits are not a kernel whole-tree quota. Kernel CPU/file-size limits, source/audit admission, per-frame pre-write bounds and terminal receipts are complementary safeguards. No result here establishes trained4B quality, long-history fit, whole author-program execution, FA2 equivalence, throughput or novelty. Phase B remains excluded.

## Parent launch checklist

1. Verify final independent review and exact frozen v3 manifest hash
2. Obtain separate approval for the single numerical command in INTENDED_LAUNCH.txt; the codec-only approval is insufficient
3. Recheck fresh v3 output/claim, original failed receipts, codec receipt, all source pins, CPU reservation and current memory/disk headroom
4. Run only the exact existing-runtime guarded command, with no imports or tests outside it
5. Inspect semantic result, all required groups/negative controls, complete typed trace, resource/HWM/CPU ledger, owned-process absence and empty scratch before any restricted parity-pass statement
