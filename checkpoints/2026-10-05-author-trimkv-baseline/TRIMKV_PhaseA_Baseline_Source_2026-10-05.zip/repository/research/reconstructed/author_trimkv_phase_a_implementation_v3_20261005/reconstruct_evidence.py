#!/usr/bin/env python3
"""Read/verify a v3 evidence stream without importing numerical libraries.

Default requires the exact complete source inventory, not just a valid prefix.
--prefix explicitly recovers only complete verified events from stopped output.
Codec verification alone never establishes semantic or resource success.
"""
import argparse
import hashlib
import json
from pathlib import Path
from evidence_codec import Reader,TypedArray


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace')
    parser.add_argument('--prefix',action='store_true')
    parser.add_argument('--tensor',type=int,help='Print lossless raw hex and dtype/shape for one tensor ID')
    args=parser.parse_args()
    reader=Reader(args.trace)
    for _ in reader.records(require_complete=not args.prefix,allow_prefix=args.prefix):
        pass
    summary={'trace_sha256':hashlib.sha256(Path(args.trace).read_bytes()).hexdigest(),
             'verified_complete_serialization':reader.footer is not None and reader.partial_error is None
                 and reader.footer['inventory_complete'] and not reader.footer['serialization_failed'],
             'event_counts':reader.event_counts,'events':reader.events,'tensors':len(reader.tensors),
             'chunks':len(reader.chunks),'partial_error':reader.partial_error,
             'semantic_acceptance':'Not determined by this tool; parent must bind result and guard receipts to the reviewed manifest and exact output'}
    if args.tensor is not None:
        if not 0<=args.tensor<len(reader.tensors):
            raise SystemExit('Tensor ID is outside this verified stream')
        desc=reader.tensors[args.tensor]
        array=TypedArray(desc['dtype'],tuple(desc['shape']),desc['finite'],b''.join(reader._raw_parts(desc)))
        summary['tensor']={'descriptor':desc,'raw_hex':array.raw.hex()}
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
