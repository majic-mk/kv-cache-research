"""Narrow import-only native-runtime scratch admission; no numerical imports.

No installed function/module is patched. The native tempfile/instantiator code
runs unchanged. A temporary kernel per-file soft limit and bounded path counts
reserve scratch bytes before each creation, then writes are sealed before tests.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import sys

HERE = Path(__file__).resolve().parent
PER_FILE_BYTES = 65536
SCRATCH_BYTES = 1000000
PROBE_PATTERN = re.compile(r'[a-z0-9_]{8}\Z')
DIRECTORY_PATTERN = re.compile(r'tmp[a-z0-9_]{8}\Z')
GENERATED_NAME = '_remote_module_non_scriptable.py'
_POLICY = None


class ScratchPolicy:
    def __init__(self, output):
        self.output = Path(output).resolve(strict=True)
        self.scratch = (self.output / 'scratch').resolve(strict=True)
        if self.scratch.is_symlink() or not self.scratch.is_dir() or list(self.scratch.iterdir()):
            raise RuntimeError('Scratch must be a new empty owned directory')
        if stat.S_IMODE(self.scratch.stat().st_mode) != 0o700:
            raise RuntimeError('Owned scratch must have mode0700')
        if any(os.environ.get(name) != str(self.scratch) for name in ('TMPDIR','TEMP','TMP','PHASE_A_SCRATCH')):
            raise RuntimeError('All native temporary destinations must be the owned scratch')
        self.provenance = json.loads((HERE/'SCRATCH_PROVENANCE.json').read_text())
        self.sources = {}
        for name in ('tempfile','shutil','instantiator','remote_module','template'):
            row = self.provenance[name]
            path = Path(row['path']).resolve(strict=True)
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != row['sha256'] or data != (HERE/row['snapshot']).read_bytes():
                raise RuntimeError('Native scratch source pin changed: '+name)
            self.sources[name] = str(path)
        row = self.provenance['expected_generated']
        self.expected_generated = (HERE/row['snapshot']).read_bytes()
        if len(self.expected_generated) != row['bytes'] or hashlib.sha256(self.expected_generated).hexdigest() != row['sha256']:
            raise RuntimeError('Expected generated-source pin mismatch')
        if len(self.expected_generated) > PER_FILE_BYTES:
            raise RuntimeError('Generated source exceeds import-only per-file cap')
        self.original_fsize = resource.getrlimit(resource.RLIMIT_FSIZE)
        soft, hard = self.original_fsize
        if soft < 23000000 or hard < soft:
            raise RuntimeError('Inherited file limits cannot support unchanged evidence partition')
        # Only lower soft. Restoring it never raises the inherited hard limit.
        resource.setrlimit(resource.RLIMIT_FSIZE, (PER_FILE_BYTES, hard))
        self.import_phase = True
        self.probe = None
        self.probe_deleted = False
        self.directory = None
        self.directory_identity = None
        self.generated = None
        self.generated_verified = False
        self.generated_deleted = False
        self.directory_deleted = False
        self.reserved_bytes = 0
        self.actual_write_bytes = 0
        self.events = []
        self._checking_read = False
        sys.addaudithook(self.audit)

    def _at(self, source, function=None):
        frame = sys._getframe(1)
        count = 0
        while frame is not None and count < 96:
            if frame.f_code.co_filename == self.sources[source] and (function is None or frame.f_code.co_name == function):
                return True
            frame = frame.f_back
            count += 1
        return False

    def _reserve(self, what, path, amount):
        if self.reserved_bytes + amount > SCRATCH_BYTES:
            raise PermissionError('Owned scratch lifetime reservation exceeds1MB')
        self.reserved_bytes += amount
        self.events.append({'operation':what,'path':str(path),'reserved_bytes':amount})

    def _path(self, name, dir_fd=None):
        if not isinstance(name,(str,bytes,os.PathLike)):
            raise PermissionError('Unsupported filesystem target')
        path = Path(os.fsdecode(name))
        if dir_fd not in (None,-1):
            if path.is_absolute() or path.name != str(path):
                raise PermissionError('Relative cleanup must use a single owned basename')
            fd_path = Path(os.readlink('/proc/self/fd/'+str(dir_fd))).resolve(strict=True)
            if self.directory is None or fd_path != self.directory:
                raise PermissionError('Cleanup dir_fd is not the owned native temporary directory')
            info = os.fstat(dir_fd)
            actual = self.directory.stat()
            if not stat.S_ISDIR(info.st_mode) or (info.st_dev,info.st_ino)!=(actual.st_dev,actual.st_ino):
                raise PermissionError('Cleanup directory identity mismatch')
            path = fd_path/path
        if path.is_symlink():
            raise PermissionError('Symlinked filesystem targets are forbidden')
        return path.resolve()

    def _read_exact(self, path, expected):
        self._checking_read = True
        try:
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > PER_FILE_BYTES:
                raise PermissionError('Unexpected owned scratch file type/size')
            data = path.read_bytes()
            if data != expected:
                raise PermissionError('Native scratch bytes differ from source-audited expectation')
            return info.st_size
        finally:
            self._checking_read = False

    def _owned_directory(self):
        if self.directory is None or not self.directory.is_dir() or self.directory.is_symlink():
            raise PermissionError('Missing owned native temporary directory')
        info = self.directory.stat()
        identity = (info.st_dev,info.st_ino)
        if self.directory_identity is None:
            self.directory_identity = identity
        if identity != self.directory_identity or stat.S_IMODE(info.st_mode)!=0o700:
            raise PermissionError('Owned directory identity/permissions changed')

    def audit(self,event,args):
        if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.fork','os.forkpty',
                'os.posix_spawn','os.posix_spawnp','os.setsid','os.setpgid','pty.spawn'}:
            raise PermissionError('Phase A forbids network/subprocess/process escape: '+event)
        if event == 'resource.setrlimit':
            if args[0] != resource.RLIMIT_FSIZE or tuple(args[1]) != self.original_fsize or self.import_phase:
                raise PermissionError('Unexpected resource-limit mutation')
            return
        if event in {'os.rename','os.link','os.symlink','os.chmod','os.chown','os.utime','os.truncate'}:
            raise PermissionError('Unneeded filesystem mutation forbidden: '+event)
        if event == 'open' and isinstance(args[0],(str,bytes)):
            path = self._path(args[0])
            mode = args[1] or ''
            flags = args[2] if len(args)>2 else 0
            writing = any(c in str(mode) for c in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing:
                if path in {self.output/'trace.tkv3',self.output/'result.json'}:
                    return
                if not self.import_phase or not path.is_relative_to(self.scratch):
                    raise PermissionError('Only bounded evidence and import-only owned scratch writes allowed')
                if (self.probe is None and path.parent==self.scratch and PROBE_PATTERN.fullmatch(path.name)
                        and self._at('tempfile','_get_default_tempdir')):
                    required=os.O_CREAT|os.O_EXCL
                    if (flags&required)!=required or (flags&os.O_ACCMODE)!=os.O_RDWR or path.exists():
                        raise PermissionError('Temporary probe must be fresh exclusive read/write creation')
                    self._reserve('exclusive_tempfile_probe',path,PER_FILE_BYTES)
                    self.probe=path
                    return
                if (self.generated is None and self.directory is not None and path==self.directory/GENERATED_NAME
                        and self._at('instantiator','_write') and not path.exists()):
                    self._owned_directory()
                    if not self.probe_deleted or str(mode)!='w':
                        raise PermissionError('Unexpected generated source write mode/order')
                    self._reserve('native_generated_source',path,PER_FILE_BYTES)
                    self.generated=path
                    return
                raise PermissionError('Scratch write is not a bounded pinned native call site: '+str(path))
            if path.suffix.lower() in {'.safetensors','.pt','.pth','.ckpt','.bin','.gguf','.ggml'}:
                raise PermissionError('Trained or ambiguous tensor payload read forbidden: '+str(path))
            if not self._checking_read and self.generated is not None and path==self.generated and path.exists():
                size=self._read_exact(path,self.expected_generated)
                if not self.generated_verified:
                    self.actual_write_bytes += size
                    self.generated_verified=True
                    self.events.append({'operation':'generated_bytes_verified_before_import','bytes':size,
                                        'sha256':hashlib.sha256(self.expected_generated).hexdigest()})
            return
        if event == 'os.mkdir':
            path=self._path(args[0],args[2] if len(args)>2 else None)
            if (not self.import_phase or self.directory is not None or path.parent!=self.scratch
                    or not DIRECTORY_PATTERN.fullmatch(path.name) or args[1]!=0o700 or path.exists()
                    or not self.probe_deleted or not self._at('tempfile','mkdtemp') or not self._at('instantiator','<module>')):
                raise PermissionError('Only one pinned native TemporaryDirectory is permitted')
            self._reserve('native_temporary_directory',path,4096)
            self.directory=path
            return
        if event == 'os.remove':
            path=self._path(args[0],args[1] if len(args)>1 else None)
            if path==self.probe and not self.probe_deleted and self._at('tempfile','_get_default_tempdir'):
                size=self._read_exact(path,b'blat')
                self.actual_write_bytes += size
                self.probe_deleted=True
                self.events.append({'operation':'owned_probe_unlinked','bytes':size})
                return
            if (path==self.generated and not self.generated_deleted and self._at('shutil')
                    and (self._at('tempfile','cleanup') or self._at('tempfile','_cleanup') or self._at('tempfile','_rmtree'))):
                self._owned_directory()
                self._read_exact(path,self.expected_generated)
                self.generated_deleted=True
                self.events.append({'operation':'owned_generated_source_unlinked'})
                return
            raise PermissionError('Deletion outside created owned scratch is forbidden')
        if event == 'os.rmdir':
            path=self._path(args[0],args[1] if len(args)>1 else None)
            if (path!=self.directory or self.directory_deleted or not self._at('shutil')
                    or not (self._at('tempfile','cleanup') or self._at('tempfile','_cleanup') or self._at('tempfile','_rmtree'))):
                raise PermissionError('Only native cleanup of its own new directory is permitted')
            self._owned_directory()
            if list(path.iterdir()):
                raise PermissionError('Native cleanup directory must already be empty')
            self.directory_deleted=True
            self.events.append({'operation':'owned_native_directory_removed'})
            return
        if event == 'shutil.rmtree':
            path=self._path(args[0],args[1] if len(args)>1 else None)
            if path!=self.directory or not (self._at('tempfile','cleanup') or self._at('tempfile','_cleanup') or self._at('tempfile','_rmtree')):
                raise PermissionError('Only installed tempfile cleanup of its owned directory is permitted')

    def seal(self):
        if not self.import_phase:
            raise RuntimeError('Scratch was already sealed')
        self._owned_directory()
        if not self.probe_deleted or self.generated is None:
            raise RuntimeError('Expected native scratch operations were not observed')
        self._read_exact(self.generated,self.expected_generated)
        if not self.generated_verified:
            raise RuntimeError('Generated source was not byte-verified before import')
        for fd in Path('/proc/self/fd').iterdir():
            try:
                name=os.readlink(fd)
                path=Path(name.removesuffix(' (deleted)')).resolve()
                if not path.is_relative_to(self.scratch):
                    continue
                fields=(Path('/proc/self/fdinfo')/fd.name).read_text().splitlines()
                flags=int(next(line.split()[1] for line in fields if line.startswith('flags:')),8)
                if flags&os.O_ACCMODE in (os.O_WRONLY,os.O_RDWR):
                    raise RuntimeError('Writable scratch descriptor survived native imports')
            except FileNotFoundError:
                continue
        for path in self.scratch.rglob('*'):
            if path not in {self.directory,self.generated} or path.is_symlink():
                raise RuntimeError('Unexpected native scratch entry')
        if resource.getrlimit(resource.RLIMIT_FSIZE)!=(PER_FILE_BYTES,self.original_fsize[1]):
            raise RuntimeError('Import-only kernel file cap changed unexpectedly')
        self.import_phase=False
        resource.setrlimit(resource.RLIMIT_FSIZE,self.original_fsize)
        if resource.getrlimit(resource.RLIMIT_FSIZE)!=self.original_fsize:
            raise RuntimeError('Original file soft limit not restored')
        self.events.append({'operation':'scratch_writes_sealed','restored_soft':self.original_fsize[0],
                            'unchanged_hard':self.original_fsize[1],'writable_scratch_fds':0})

    def snapshot(self):
        return {'import_phase':self.import_phase,'owned_scratch':str(self.scratch),
                'per_file_import_kernel_cap':PER_FILE_BYTES,'lifetime_reserved_bytes':self.reserved_bytes,
                'actual_source_verified_write_bytes':self.actual_write_bytes,'scratch_partition_bytes':SCRATCH_BYTES,
                'inherited_fsize':list(self.original_fsize),'probe_deleted':self.probe_deleted,
                'generated_verified_before_import':self.generated_verified,'generated_deleted':self.generated_deleted,
                'native_directory_deleted':self.directory_deleted,'events':list(self.events),
                'cleanup_note':'This result snapshot precedes interpreter atexit. Guard terminal scratch scan records remaining entries.'}


def install_policy(output):
    global _POLICY
    if _POLICY is not None:
        raise RuntimeError('Scratch policy already installed')
    _POLICY=ScratchPolicy(output)


def seal_scratch():
    if _POLICY is None:
        raise RuntimeError('Scratch policy not installed')
    _POLICY.seal()


def scratch_snapshot():
    return {'installed':False} if _POLICY is None else _POLICY.snapshot()
