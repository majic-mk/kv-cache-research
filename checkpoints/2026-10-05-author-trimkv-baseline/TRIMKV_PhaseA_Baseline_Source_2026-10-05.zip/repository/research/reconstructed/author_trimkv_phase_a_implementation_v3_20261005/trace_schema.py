"""Lossless typed-row evidence; numerical fixture callers remain unchanged."""
import ctypes
import math
import sys
import time
from contextlib import contextmanager
from evidence_codec import Writer, layout

DTYPES={'torch.float32':'f32','torch.bfloat16':'bf16','torch.int64':'i64','torch.bool':'bool'}


class Trace:
    def __init__(self,output):
        if sys.byteorder!='little':
            raise RuntimeError('Frozen native CPU wire representation requires little endian')
        self.path=output/'trace.tkv3'
        self.writer=Writer(self.path,limit=23000000)
        self.times={}
        self.logical_bytes={}
        self.records=0
        self.negative_verdicts={}

    def pack(self,value):
        if hasattr(value,'detach'):
            data=value.detach().cpu()
            finite=bool(data.isfinite().all().item())
            if not finite:
                raise AssertionError('Non-finite evidence tensor')
            dtype=DTYPES.get(str(data.dtype))
            if dtype is None:
                raise TypeError('Unadmitted source tensor dtype')
            contiguous=data.contiguous()
            count=contiguous.numel()*contiguous.element_size()
            admitted,_,_=layout(dtype,list(data.shape))
            if contiguous.device.type!='cpu' or count!=admitted:
                raise ValueError('Only admitted contiguous CPU tensor bytes may be read')
            # Read only this live, owned contiguous CPU tensor buffer. No
            # numerical conversion or float-text round trip is performed.
            raw=ctypes.string_at(contiguous.data_ptr(),count) if count else b''
            return self.writer.add_tensor(dtype,list(data.shape),raw,finite=finite)
        if isinstance(value,dict):
            return {str(k):self.pack(v) for k,v in value.items()}
        if isinstance(value,(tuple,list)):
            return [self.pack(v) for v in value]
        if isinstance(value,float) and not math.isfinite(value):
            return str(value)
        return value

    def emit(self,event,**data):
        start=time.perf_counter()
        try:
            self.writer.emit({'event':event,**self.pack(data)})
        except BaseException:
            self.writer.failed=True
            raise
        self.records+=1
        self.times['evidence']=self.times.get('evidence',0.0)+time.perf_counter()-start

    @contextmanager
    def timed(self,name,logical_bytes=0):
        start=time.perf_counter()
        try:
            yield
        finally:
            self.times[name]=self.times.get(name,0.0)+time.perf_counter()-start
            self.logical_bytes[name]=self.logical_bytes.get(name,0)+int(logical_bytes)

    def negative(self,name,detected,**detail):
        self.negative_verdicts[name]=bool(detected)
        self.emit('negative_control',name=name,detected=bool(detected),**detail)
        if not detected:
            raise AssertionError('Non-discriminating negative control: '+name)

    def close(self):
        self.writer.close()


def tensor_bytes(tensor):
    return tensor.numel() * tensor.element_size()


def storage_ledger(tensors):
    unique = {}
    for tensor in tensors:
        storage = tensor.untyped_storage()
        unique[storage.data_ptr()] = storage.nbytes()
    return {'logical_bytes': sum(tensor_bytes(t) for t in tensors),
            'unique_storage_bytes': sum(unique.values()), 'unique_storages': len(unique)}


def gate_logical_bytes(gate, inputs):
    # Estimated explicit tensor reads/writes, not physical memory-bus traffic.
    tokens = inputs.numel() // inputs.shape[-1]
    element = inputs.element_size()
    middle = tokens * gate.linear1.out_features * element
    output = tokens * gate.linear2.out_features * element
    return tensor_bytes(inputs) + sum(tensor_bytes(p) for p in gate.parameters()) + 4 * middle + 4 * output


def attention_logical_bytes(query, key, value, mask, groups):
    # Q/K/V reads, GQA expand/materialize, scores+softmax, mask and output.
    scores = query.shape[0] * query.shape[1] * query.shape[-2] * key.shape[-2]
    output = query.numel() * query.element_size()
    return (tensor_bytes(query) + tensor_bytes(key) + tensor_bytes(value)
            + 2 * groups * (tensor_bytes(key) + tensor_bytes(value))
            + (tensor_bytes(mask) if mask is not None else 0)
            + scores * (4 * query.element_size() + 8) + output)
