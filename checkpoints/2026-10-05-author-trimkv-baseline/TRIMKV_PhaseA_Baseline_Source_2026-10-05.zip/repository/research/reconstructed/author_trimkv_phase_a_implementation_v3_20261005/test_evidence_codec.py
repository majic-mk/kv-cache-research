#!/usr/bin/env python3
"""Separately approved, stdlib-only wire-format check. Never runs model fixtures."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import struct
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
CHECK_OUTPUT=Path('/tmp/trimkv_phase_a_serializer_check_20261005')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-codec-check-approved',action='store_true',required=True)
    parser.add_argument('--manifest-sha256',required=True)
    args=parser.parse_args()
    raw=(HERE/'CODEC_CHECK_MANIFEST.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=args.manifest_sha256:
        raise SystemExit('Separately approved serializer source manifest mismatch')
    manifest=json.loads(raw)
    for row in manifest['files']:
        path=HERE/row['name']
        if path.parent!=HERE or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise SystemExit('Serializer check source pin mismatch')
    if os.path.lexists(CHECK_OUTPUT):
        raise SystemExit('Serializer check output already exists; no retry')
    CHECK_OUTPUT.mkdir(mode=0o700)
    started=time.monotonic();initial_cpu=resource.getrusage(resource.RUSAGE_SELF)
    resource.setrlimit(resource.RLIMIT_CPU,(4,5))
    resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
    resource.setrlimit(resource.RLIMIT_FSIZE,(65536,65536))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    def timeout(*_):
        raise TimeoutError('Serializer-only15-second wall bound')
    signal.signal(signal.SIGALRM,timeout);signal.signal(signal.SIGXCPU,timeout)
    signal.setitimer(signal.ITIMER_REAL,15)
    sys.dont_write_bytecode=True
    admitted=set()
    def audit(event,values):
        if event=='import' and str(values[0]).split('.')[0] in {'torch','transformers','numpy'}:
            raise PermissionError('Serializer-only test cannot import numerical libraries')
        if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.fork','os.posix_spawn','os.posix_spawnp','os.forkpty'}:
            raise PermissionError('Serializer-only test forbids network and subprocesses')
        if event=='open' and isinstance(values[0],(str,bytes)):
            path=Path(os.fsdecode(values[0])).resolve();mode=values[1] or '';flags=values[2]
            writing=any(c in str(mode) for c in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing:
                if path.parent!=CHECK_OUTPUT or path.is_symlink():
                    raise PermissionError('Only new serializer check files may be written')
                if path not in admitted:
                    if path.exists() or len(admitted)>=24:
                        raise PermissionError('Serializer file count/exclusive admission exceeded')
                    admitted.add(path)
        if event in {'os.remove','os.rmdir','os.rename','os.link','os.symlink','os.mkdir'}:
            raise PermissionError('Serializer check preserves all existing/new evidence')
    sys.addaudithook(audit)
    result={'status':'RUNNING','scope':'stdlib serializer only, no model/numerical imports','checks':[]}
    try:
        from evidence_codec import Writer,Reader,CodecError,MAGIC,FRAME,CHUNK,canonical,tensor_content_header
        expected={'probe':2}
        path=CHECK_OUTPUT/'roundtrip.tkv3'
        writer=Writer(path,limit=65536,expected_events=expected)
        f32=struct.pack('<8I',0,0x80000000,0x7f800000,0xff800000,0x7fc12345,0x7f812345,1,0x7f7fffff)
        bf16=struct.pack('<8H',0,0x8000,0x7f80,0xff80,0x7fc1,0x7f81,1,0x7f7f)
        integer=struct.pack('<4q',-9223372036854775808,-1,0,9223372036854775807)
        booleans=bytes((0,1,1,0))
        specs=[('f32',[2,4],f32),('bf16',[2,4],bf16),('i64',[2,2],integer),('bool',[2,2],booleans)]
        refs=[writer.add_tensor(*spec) for spec in specs]
        duplicate=writer.add_tensor(*specs[0]);assert duplicate==refs[0]
        cache_a=writer.add_tensor('i64',[2,2],struct.pack('<4q',0,1,2,3))
        cache_b=writer.add_tensor('i64',[2,2],struct.pack('<4q',2,3,4,5))
        assert writer.tensors[cache_a['$tensor']]['row_ids'][1]==writer.tensors[cache_b['$tensor']]['row_ids'][0]
        # A noncontiguous Python memoryview supplies logical byte order. This
        # tests wire ordering only, not a native Torch extraction bridge.
        backing=bytes((0,99,1,99,1,99,0,99))
        logical=memoryview(backing)[::2].tobytes()
        strided=writer.add_tensor('bool',[2,2],logical)
        scalar=writer.add_tensor('f32',[],struct.pack('<I',0x80000000))
        empty=writer.add_tensor('i64',[0,2],b'')
        nested={'number':1.25,'negative_zero':-0.0,'int':9007199254740993,'list':[True,None,'literal']}
        writer.emit({'event':'probe','arrays':refs,'cache_a':cache_a,'cache_b':cache_b,'nested':nested})
        writer.emit({'event':'probe','again':duplicate,'strided':strided,'scalar':scalar,'empty':empty})
        writer.close()
        reader=Reader(path,expected_events=expected);events=list(reader.records(reconstruct=True))
        assert len(events)==2 and reader.footer['inventory_complete']
        for array,(dtype,shape,raw_bits) in zip(events[0]['arrays'],specs):
            assert array.dtype==dtype and array.shape==tuple(shape) and array.raw==raw_bits
        assert events[0]['arrays'][0].finite is False and events[0]['arrays'][1].finite is False
        assert events[1]['strided'].raw==logical and events[1]['scalar'].raw==struct.pack('<I',0x80000000)
        assert events[1]['empty'].raw==b'' and events[1]['empty'].shape==(0,2)
        assert events[0]['nested']==nested and struct.pack('<d',events[0]['nested']['negative_zero'])==struct.pack('<d',-0.0)
        result['checks'].extend(['exact_f32_special_bits','exact_bf16_special_bits','int64_extremes','bool_bytes',
                                'signed_zero_scalar_and_json','empty_shape','strided_logical_order',
                                'overlapping_row_reuse','repeated_tensor_reuse','nested_scalars_lists','complete_footer'])
        wire=path.read_bytes()
        frames=[];position=len(MAGIC)
        while position<len(wire):
            kind,length,digest=FRAME.unpack(wire[position:position+FRAME.size]);payload=wire[position+FRAME.size:position+FRAME.size+length]
            frames.append((position,kind,payload));position+=FRAME.size+length
        def mutate(kind,fn):
            position,_,payload=next(row for row in frames if row[1]==kind)
            new=fn(payload)
            original_size=FRAME.size+len(payload)
            framed=FRAME.pack(kind,len(new),hashlib.sha256(kind+new).digest())+new
            return wire[:position]+framed+wire[position+original_size:]
        def json_change(payload,fn):
            value=json.loads(payload);fn(value);return canonical(value)
        def reject(name,data):
            target=CHECK_OUTPUT/(name+'.tkv3');target.write_bytes(data)
            rejected=False
            try: Reader(target,expected_events=expected).verify()
            except (CodecError,ValueError,UnicodeError): rejected=True
            assert rejected,name
            result['checks'].append(name)
        first_chunk=next(row for row in frames if row[1]==b'C')[0]
        flipped=bytearray(wire);flipped[first_chunk+FRAME.size+CHUNK.size]^=1
        reject('frame_checksum_corruption',bytes(flipped))
        reject('chunk_hash_corruption',mutate(b'C',lambda p:p[:4]+bytes(32)+p[36:]))
        reject('unknown_row_reference',mutate(b'T',lambda p:json_change(p,lambda d:d['row_ids'].__setitem__(0,99999))))
        reject('wrong_tensor_length',mutate(b'T',lambda p:json_change(p,lambda d:d.__setitem__('nbytes',d['nbytes']+1))))
        reject('wrong_dtype',mutate(b'T',lambda p:json_change(p,lambda d:d.__setitem__('dtype','i64'))))
        reject('wrong_finite_flag',mutate(b'T',lambda p:json_change(p,lambda d:d.__setitem__('finite',True))))
        reject('wrong_row_order',mutate(b'T',lambda p:json_change(p,lambda d:d['row_ids'].reverse())))
        reject('unknown_tensor_reference',mutate(b'E',lambda p:json_change(p,lambda d:d['arrays'].__setitem__(0,{'$tensor':9999}))))
        reject('wrong_expected_inventory',mutate(b'F',lambda p:json_change(p,lambda d:d.__setitem__('expected_events',{'probe':1}))))
        footer_offset=next(row[0] for row in frames if row[1]==b'F')
        reject('missing_footer',wire[:footer_offset])
        reject('truncated_frame_header',wire[:footer_offset+7])
        reject('truncated_frame_payload',wire[:-5])
        reject('trailing_bytes',wire+b'extra')
        prefix=Reader(CHECK_OUTPUT/'missing_footer.tkv3',expected_events=expected)
        recovered=list(prefix.records(allow_prefix=True))
        assert len(recovered)==2 and prefix.footer is None and prefix.partial_error
        result['checks'].append('prefix_is_explicitly_incomplete')
        collision=Writer(CHECK_OUTPUT/'collision.tkv3',limit=65536,expected_events={})
        collision.add_tensor('i64',[1],struct.pack('<q',1))
        two=struct.pack('<q',2);collision.chunk_by_digest[hashlib.sha256(two).digest()]=0
        caught=False
        try: collision.add_tensor('i64',[1],two)
        except CodecError: caught=True
        assert caught;collision.failed=True;collision.close()
        result['checks'].append('row_collision_is_not_aliased')
        collision_t=Writer(CHECK_OUTPUT/'tensor_collision.tkv3',limit=65536,expected_events={})
        collision_t.add_tensor('i64',[1],struct.pack('<q',1))
        digest=hashlib.sha256(tensor_content_header('i64',[1],True)+two).hexdigest()
        collision_t.tensor_by_digest[digest]=0;caught=False
        try: collision_t.add_tensor('i64',[1],two)
        except CodecError: caught=True
        assert caught;collision_t.failed=True;collision_t.close()
        result['checks'].append('tensor_collision_is_not_aliased')
        capped=Writer(CHECK_OUTPUT/'capped.tkv3',limit=5000,expected_events={'probe':1})
        capped.add_tensor('i64',[1],struct.pack('<q',1));caught=False
        try: capped.emit({'event':'probe','text':'x'*2000})
        except OSError: caught=True
        assert caught;capped.close()
        assert (CHECK_OUTPUT/'capped.tkv3').stat().st_size<=5000
        partial=Reader(CHECK_OUTPUT/'capped.tkv3',expected_events={'probe':1});list(partial.records(require_complete=False))
        assert partial.footer['serialization_failed'] and not partial.footer['inventory_complete']
        result['checks'].append('cap_preserves_committed_prefix_and_failure_footer')
        result.update(status='PASS',wire_bytes=len(wire),chunk_count=len(reader.chunks),tensor_count=len(reader.tensors),
                      limitation='Native Torch buffer extraction remains source-reviewed only; no Torch or model was imported')
    except BaseException as exc:
        result.update(status='FAIL',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
    finally:
        usage=resource.getrusage(resource.RUSAGE_SELF)
        result.update(wall_seconds=time.monotonic()-started,total_process_cpu_seconds=usage.ru_utime+usage.ru_stime,
                      os_maxrss_bytes=usage.ru_maxrss*1024,files_admitted=len(admitted),
                      logical_output_before_receipt=sum(p.stat().st_size for p in CHECK_OUTPUT.iterdir() if p.is_file()),
                      pid=os.getpid(),no_subprocess=True)
        payload=(json.dumps(result,indent=2)+'\n').encode()
        if len(payload)>65536:raise RuntimeError('Serializer receipt too large')
        (CHECK_OUTPUT/'result.json').write_bytes(payload)
        signal.setitimer(signal.ITIMER_REAL,0)
    print(json.dumps({'status':result['status'],'output':str(CHECK_OUTPUT),'cpu':result['total_process_cpu_seconds']}))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
