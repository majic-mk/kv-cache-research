# Independent additive pre-execution review: Phase A v4 canonical byte helper

2026-10-05 UTC. **PASS FOR RESTRICTED STATIC READINESS. No remaining blocking source defect was found in this frozen v4 candidate. The separately approved helper check passed, but main v4 has not run and this review grants no execution authorization.**

Implementation: `research/reconstructed/author_trimkv_phase_a_implementation_v4_20261005`

Manifest SHA256: `173a928ab6c852a705a0a71738f98cec3c197f8a8a9831b1c05a2d16a6ba2150`

Guard SHA256: `0a23c0a1a3df68e8cc5b94524e7f8bf8fe738fa2107895261b46dece2754ccee`

Canonical helper SHA256: `78cff3212ab721b9d04a0bf8e12ef7a6979e8071760575f4594953b38ce56799`

Intended output: `/tmp/trimkv_phase_a_author_parity_20261005_attempt4`

## Failure cause independently established

Attempt3 stopped in the strict comparison helper at the first Q1 closed-loop gate comparison. The saved exception is `self.stride(-1) must be 1 to view Float as Byte ... got 2`, from `.contiguous().view(torch.uint8)`. Its result is FAIL. No cache/attention mismatch was reported before that stop; this is not a claim that the remaining suite passed.

Failure result SHA256: `37700324288141271cc60659e4d17ed759971a30443b9b2d2f7d85faff6c5bec`

Guard receipt SHA256: `dc9916c4c3149363a58be01985488c2dd61d6be4147328e2b21fea86cc32af38`

Partial trace SHA256: `4e8d09f4d76a4e1b1ea406b3462f12abc5d3e44d507fec00733e3d3f9763fbe7`

The guard recorded5.125458s wall,6.091053s aggregate CPU and382,103,552-byte sampled guard-plus-tree RSS. Its later component fields support a conservative own-attempt CPU charge of6.091149s. Process identities were absent and scratch was checked empty. The bounded partial trace is preserved; the separately recorded read-only verification identifies406 events and explicitly says its full inventory is incomplete.

The source cause is unambiguous. Installed `torch/include/c10/core/Contiguity.h::_compute_contiguous` skips strides on size-one dimensions. Installed `_tensor_docs.py` says `.contiguous()` returns the same tensor when already contiguous, while dtype reinterpretation independently requires a positive tensor rank and `stride(-1)==1`. Therefore a `[1,2,1]` gate view may be logically contiguous yet retain last-axis stride2. Calling `.contiguous()` does not satisfy the byte-view precondition. Both installed sources and their explanatory provenance are pinned in v4.

## Narrow helper fix and serializer seam

`canonical_element_bytes` admits only strided CPU tensors of the existing FP32/BF16/int64/bool types, rejecting lazy conjugate/negative views outside this route. It allocates a fresh1D owner with the source dtype and element count, makes a destination view with the source shape, and copies the source's detached logical elements into that same-dtype destination. It asserts owner rank1, stride1 and storage offset0, then byte-views only the canonical1D owner.

There is no dtype conversion, floating arithmetic, quantization, tolerance or value normalization in the helper. The source shape-view copy retains logical element order across transposes, slices and offsets; the fresh owner's layout independently satisfies the byte-view constraints. Scalars and empty tensors are still represented through a1D owner. The returned byte tensor retains ownership of the copied storage.

The main runner changes exactly two things: one helper import and the byte operands of the existing `torch.equal` predicate. The original shape check, dtype check, strict bitwise comparison, finite checks, error labels and continuous tolerances remain unchanged. An independent whole-file textual transformation proved that no other main-runner text changed.

The serializer now uses the same canonical byte owner before `ctypes.string_at`, while retaining the original input dtype/shape and finite metadata. The byte count is checked against the existing codec layout admission. It reads only the bounded live owned CPU byte interval; no float-text conversion occurs. An AST comparison proved that the rest of the trace module is unchanged apart from the helper import and this `pack` branch.

The older serializer's raw contiguous byte-span did not itself require a dtype-view last stride; singleton strides do not introduce holes in an otherwise contiguous physical element range. Sharing the canonical seam nevertheless removes the duplicated layout assumption and makes comparison and serialization use the same now-tested logical-byte extraction. Codec reconstruction is still checked against independent expected bytes, so sharing the helper does not make the test self-referential.

Canonicalization adds explicit temporary copy work. Its time and live memory remain inside existing guard accounting. Existing logical-byte metrics are modeled/overlapping working-set estimates, not a claim to enumerate every validation-copy memory transaction or measure DRAM traffic.

## Separately approved helper-only evidence

Approved helper-check manifest SHA256: `bdb599f17928446146186321729435af1ec6a5e851c99d220f08becbdc9973b6`

PASS receipt: `/tmp/trimkv_phase_a_bitwise_check_20261005/result.json`

Receipt SHA256: `8c4b9a5d43bc4ad99e8802be36a2b57012d600f768b97adec9489e81abc1af47`

The reviewer statically checked the exact frozen proposal before the parent's separate approval, but did not run it. The saved receipt reports24 literal-bit/layout cases and18 finite production-serializer reconstructions passing, with both old FP32 and BF16 singleton exceptions reproduced first. The owner reported exit0. All four checked source pins, including helper and trace bridge, are unchanged in final v4.

Expected bytes were derived independently from literal FP32/BF16 integer bit words and explicitly enumerated logical storage-index order. Coverage includes singleton stride2, true transpose, strided slices, nonzero offsets, scalar/empty/offset-singleton views, signed zeros, subnormal/max-finite/special payload bits, int64 extremes and bool. Every nonempty case checks rejection of an altered bit. The helper's fresh allocation, rank1, stride1, offset0 and expected byte count are asserted. Nonfinite serializer rejection remains enforced; unsupported lazy-negative input is rejected.

For finite cases the production `Trace` path writes typed evidence, and the unchanged codec reconstructs its bytes for comparison with the independent literal expectations. The helper trace is deliberately a partial main-suite inventory; the check does not mislabel its18 events as a completed Phase A run.

Observed resources:1.097837s process CPU,1.064411s wall,226,304,000-byte OS high-water RSS and one intra/inter-op thread. The check used no Transformers, model, author cache/gate fixture or trained payload. Its separate limits were15s wall,8s CPU,512MiB observed high-water RSS and512KiB aggregate output. High-water checks are retrospective, not a kernel-hard RSS reservation.

The earlier28-check stdlib codec PASS remains pinned and its codec bytes are unchanged. Together these checks support the serializer and canonical byte seam; they are not the full numerical gate.

## Frozen source identity and unchanged suite

After the owner explicitly froze v4, independent validation checked:

- All172 repository manifest entries and both exact read-only stdlib pins
- All three prior failed-run receipts, codec-check receipt and helper-check receipt
- Every implementation Python source with stdlib AST parsing; all such sources are pinned
- All41 v1,74 v2 and118 v3 manifest entries remain unchanged
- Adapter, source reference, scalar oracle, codec, scratch policy and complete exact author cache/gate spans remain byte-identical to v3
- Main runner differs only by the explicit import and canonical byte predicate, with no case, array, schedule, seed, threshold, gate, clock, position, mask, feedback or tolerance change
- The helper and production trace source remain byte-identical to the separately approved successful helper check

The original source-semantics/ABI review remains applicable to unchanged policy code: original absolute positions, shared N, age N+1-p, buffer32, paired head-wise gathers and post-global-call pruning; genuine current-HF closed-loop integration; fixed positive/negative fixtures; exact branch acceptance; prospective FP32/BF16 attention/head tolerances. This helper change neither relaxes those requirements nor replaces them with a codec check.

## Complete trace bound still applies

The v3 independent source bound remains **21,350,347 bytes**, leaving **1,649,653 bytes** below the unchanged23MB trace partition. Its1,621 events,5,648 tensor occurrences and187,842 row references are unchanged. No extra helper tensor is emitted. The existing dtype/shape/value payloads and codec framing are unchanged; canonical copies preserve exact logical element bits, and immutable K/V row content still supports the same row-origin deduplication proof.

This bound requires neither compression nor equality across independent fixtures. The full derivation remains at `research/reconstructed/author_trimkv_phase_a_trace_bound_review_20261005_1345/FINAL_SOURCE_BOUND.md`, SHA256 `527ddf3b63b4f1ef24f92c4a05fd4653f0f6b03c29c7fa2744f976514f18d6ab`. The v4 diff/shape review reconciles its prior source pins with the helper-only changes. Byte feasibility still does not prove CPU, RSS or numerical success.

## Resource, provenance and cumulative CPU gate

The guard's resource literals and manifest remain identical to governing protocol SHA256 `1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f`: one separately admitted attempt;120s wall;90s child hard CPU;5s guard hard CPU;100s cumulative aggregate CPU;1GiB sampled guard-plus-tree RSS;25ms target samples; one numerical thread;3GB starting/1.5GB continuing host headroom;5GB disk floor;32MB output; no GPU/network/install/trained payload/paid action.

Output partitions remain23MB trace +2MB result +1MB scratch +6MB guard. The v2-owned scratch allowlist/seal/terminal-empty checks, v3 framing/completeness safeguards, inherited-hard-limit start barrier, parent-death protection and owned-process cleanup proof are preserved. Every earlier claim and artifact stays intact.

The new cumulative precharge is **33.592565s**:

- Three failed main attempts' own conservative charges:18.592565s, without summing cumulative fields twice
- Full approved codec-check CPU cap:5s
- Full approved helper-check CPU cap:8s
- Conservative post-v3 read-only verification allowance:2s

Tracked measured CPU is separately20.751745s. The2s read-only allowance is explicitly a conservative charged reserve, not a claimed kernel limit. The guard pins the provenance record, both actual PASS receipts and their approved source manifests, and checks helper counts/threads/version/error absence/RSS/output/time bounds before admission. It does not reuse a prior authorization.

Recheck actual output free space≥5,032,000,000 bytes, source/claim free space≥5GB+4KB and tmpfs host start availability≥3,032,000,000 bytes. Continuing headroom still reserves unwritten/unallocated tmpfs allowance against1.5GB. No existing data may be removed to gain admission. Resource observations remain sampled/high-water supplemented; short peaks and hard-host failures cannot be ruled out by static review.

## Parent gate and acceptance

The v4 claim/output were absent at review and main v4 is unrun. The helper-only and codec-only approvals do not authorize it. The parent must establish a separate exact main-run grant, recheck frozen pins and live resources, and use only the command bound to this manifest/output.

Require launcher exit0; semantic PASS for all original groups/negative controls; accepted same-run resource receipt and absent owned processes; sealed scratch and checked-empty terminal scratch; and exhaustive codec verification through the final marker against the trusted1,621-event inventory. Trace, result and guard must belong to the same admitted output/manifest. Neither helper success nor valid partial evidence is a numerical pass.

Any first import, helper, numerical, negative-control, resource, serialization or cleanup failure closes that attempt, preserving partials. No automatic retry, looser tolerance, omitted array/case, larger cap, alternate output or runtime patch follows from this review.

Reviewer operations were file/receipt reads, hashing, stdlib AST/text checks and source metadata arithmetic only. No reviewer target import, helper test, model, tensor operation or numerical fixture was executed. No trained payload, installation, network, GPU or provider action occurred. No full author-program, FA2, trained4B quality, long-prefill fit, throughput, novelty or Phase B claim is established.

## Additive artifacts

`STATIC_CHECKS.json` records independent final checks; `REVIEWED_MANIFEST.json` is the exact frozen manifest; `MAIN_TEST_DIFF.patch` proves the two runner edits; `TRACE_BRIDGE_DIFF.patch` records the inspected extraction change; `PRIOR_ARTIFACT_PINS.json` preserves earlier output identities. `BITWISE_CHECK_REVIEW.json` retains the separate helper-only gate. `VERDICT.json` and `SHA256SUMS` pin this final additive review. No v1–v3 review was overwritten.
