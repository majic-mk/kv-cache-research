#!/usr/bin/env python3
"""Source-only preparation of the one-attempt, Linux/stdlib Phase A supervisor.

Merely preparing this file does not authorize executing it. Execution requires a
separate approval, its explicit CLI flag, and the separately reviewed manifest
hash. This module never imports numerical packages. Do not use this launcher for
syntax checking: use an external stdlib ast.parse on its source instead.

RSS, host availability and disk ceilings are sampled abort thresholds, not kernel
reservations. Evidence is cooperatively partitioned before each write: child
trace23MB/result2MB, owned import scratch1MB, all guard outputs6MB. RLIMIT_CPU
and RLIMIT_FSIZE are kernel-enforced per-process limits. The frozen child must additionally deny
network, subprocesses, checkpoint reads and out-of-output writes before importing
numerical packages. Offline environment variables alone are not a sandbox.
"""

from __future__ import annotations

import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import secrets
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent
REPO = Path(__file__).resolve().parents[3]
MANIFEST = HERE / "frozen_manifest.json"
CLAIM = HERE / "ATTEMPT_CLAIM.json"
RUNNER = HERE / "test_author_semantics.py"
PROTOCOL_REL = "research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/PHASE_A_PROTOCOL.json"
RUNTIME_REL = "research/reconstructed/runtime_recovery_20261004/.venv/bin/python"
INTENDED_OUTPUT = "/tmp/trimkv_phase_a_author_parity_20261005_attempt2"
READONLY_EXTERNAL_FILES = frozenset({
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/tempfile.py",
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/shutil.py",
})
PRIOR_RECEIPT_PATH = "/tmp/trimkv_phase_a_author_parity_20261005_attempt1/guard_receipt.json"
PRIOR_RECEIPT_SHA256 = "b706d98d04936cfd632dc28e154f49910a3d80ba006db21f58e8b50cc008adb0"
PRIOR_AGGREGATE_CPU_SECONDS = 3.611184
OUTPUT_PARTITIONS = {"child_compressed_trace": 23000000, "child_result": 2000000,
                     "owned_scratch": 1000000, "all_guard_evidence": 6000000}
SCRATCH_IMPORT_FILE_SOFT_LIMIT = 65536
SCRATCH_MAX_FILES_CREATED = 2
SCRATCH_MAX_DIRECTORIES_CREATED = 1
REFERENCE_REL = {
    "reference_cache_sha256": "research/reconstructed/revision_baseline_contracts_20261004/sources/trimkv_cache_utils.py",
    "reference_model_sha256": "research/reconstructed/revision_baseline_contracts_20261004/sources/trimkv_modeling_qwen3.py",
}
LIMITS = {
    "attempts": 1,
    "guarded_wall_seconds": 120,
    "child_cpu_hard_seconds": 90,
    "guard_cpu_hard_seconds": 5,
    "combined_cpu_budget_seconds": 100,
    "process_tree_rss_bytes": 1073741824,
    "rss_sample_interval_seconds": 0.025,
    "start_host_available_bytes": 3000000000,
    "minimum_host_available_bytes": 1500000000,
    "free_disk_floor_bytes": 5000000000,
    "new_evidence_bytes": 32000000,
    "intraop_threads": 1,
    "interop_threads": 1,
    "gpu": False,
    "network": False,
    "installs": False,
    "trained_checkpoint_reads_bytes": 0,
    "paid_calls": 0,
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
TICKS = os.sysconf("SC_CLK_TCK")
PAGE_SIZE = os.sysconf("SC_PAGE_SIZE")
RESERVE_BYTES = 256000
GUARD_EVIDENCE_BYTES = OUTPUT_PARTITIONS["all_guard_evidence"]
MAX_MANIFEST_BYTES = 2000000
_active_pgid: int | None = None
_interrupted: str | None = None
_parent_pid = os.getpid()


class GuardStop(RuntimeError):
    """A fail-closed preflight or monitored resource stop."""


class GuardEvidenceBudget:
    """Charge every guard payload before writing; no overshoot and no retry.

    The child has separately enforced 23MB trace, 2MB result and 1MB owned
    scratch partitions. Scratch permits only pinned native import call sites,
    with two exclusive fresh files capped at 64KiB apiece during imports.
    All other child file writes are prohibited by its audit policy.
    Counting replacement receipts again is deliberately conservative.
    """

    def __init__(self) -> None:
        self.charged_bytes = 0

    def write(self, stream: object, payload: bytes, *, terminal: bool = False) -> None:
        ceiling = GUARD_EVIDENCE_BYTES if terminal else GUARD_EVIDENCE_BYTES - RESERVE_BYTES
        if self.charged_bytes + len(payload) > ceiling:
            raise GuardStop("guard_6000000_byte_partition_exhausted; payload dropped before write")
        self.charged_bytes += len(payload)
        view = memoryview(payload)
        while view:
            written = stream.write(view)
            if not written:
                raise OSError("guard evidence write made no progress")
            view = view[written:]

    def write_file(self, path: Path, payload: bytes, *, terminal: bool = False,
                   replace: bool = False) -> None:
        with path.open("wb" if replace else "xb") as stream:
            self.write(stream, payload, terminal=terminal)


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def compact(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def relative(path: Path) -> str:
    return path.relative_to(REPO).as_posix()


def cpu_self() -> float:
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return usage.ru_utime + usage.ru_stime


def host_available() -> int:
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    raise GuardStop("Linux MemAvailable is unavailable; cannot certify host headroom")


def filesystem_for(path: Path) -> dict:
    """Resolve the most-specific Linux mount, including decoded bind mounts."""
    target = path.resolve(strict=True)
    matches = []
    def unescape(value: str) -> str:
        return re.sub(r"\\([0-7]{3})", lambda match: chr(int(match.group(1), 8)), value)
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        before, separator, after = line.partition(" - ")
        if not separator:
            raise GuardStop("malformed Linux mountinfo")
        fields, filesystem = before.split(), after.split()
        mountpoint = Path(unescape(fields[4]))
        if target.is_relative_to(mountpoint):
            matches.append({"mount_id": int(fields[0]), "device_major_minor": fields[2],
                            "mount_point": str(mountpoint), "mount_root": unescape(fields[3]),
                            "filesystem_type": filesystem[0], "source": unescape(filesystem[1]),
                            "in_memory": filesystem[0] in {"tmpfs", "ramfs"}})
    if not matches:
        raise GuardStop("cannot establish output/source filesystem backing from mountinfo")
    return max(matches, key=lambda row: len(Path(row["mount_point"]).parts))


def signal_stop(number: int, _frame: object) -> None:
    global _interrupted
    _interrupted = "signal_" + signal.Signals(number).name
    if number == signal.SIGXCPU:
        # Apply the 5s hard cap even if the 4s soft signal arrives during the
        # source-only inheritance window, before a child has been started.
        resource.setrlimit(resource.RLIMIT_CPU, (4, LIMITS["guard_cpu_hard_seconds"]))
    # The child was launched in its own new session. Never signal the caller's
    # process group or use a name-based/global process kill.
    if _active_pgid is not None:
        try:
            os.killpg(_active_pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def arm_guard_limits(start_monotonic: float) -> None:
    for number in (signal.SIGINT, signal.SIGTERM, signal.SIGXCPU, signal.SIGALRM):
        signal.signal(number, signal_stop)
    # Linux children cannot raise an inherited hard limit. Keep hard=90 only
    # during stdlib preflight/fork, with a 4s soft-stop, then immediately lower
    # the parent's cumulative hard limit to 5s before opening the child's start
    # barrier. The numerical runner must consume PHASE_A_START_FD first.
    resource.setrlimit(resource.RLIMIT_CPU, (4, LIMITS["child_cpu_hard_seconds"]))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (LIMITS["new_evidence_bytes"],) * 2)
    remaining = LIMITS["guarded_wall_seconds"] - (time.monotonic() - start_monotonic)
    if remaining <= 0:
        raise GuardStop("guard_wall_exhausted_before_preflight")
    signal.setitimer(signal.ITIMER_REAL, remaining)


def child_limits() -> None:
    # Popen's start_new_session creates the only group this guard may kill.
    # Linux parent-death protection prevents the sole allowed child surviving a
    # guard hard CPU kill. Audit policy must prohibit creating grandchildren.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
        os._exit(125)
    if os.getppid() != _parent_pid:
        os._exit(125)
    resource.setrlimit(resource.RLIMIT_CPU, (LIMITS["child_cpu_hard_seconds"],) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (LIMITS["new_evidence_bytes"] - RESERVE_BYTES,) * 2)
    signal.setitimer(signal.ITIMER_REAL, 0)


def checkpoint_name(path: Path) -> bool:
    return path.suffix.lower() in {".safetensors", ".bin", ".pt", ".pth", ".ckpt", ".gguf", ".ggml"}


def verify_readonly_external_files(manifest: dict) -> dict:
    """Allow only the two exact pinned stdlib audit-callsite sources."""
    rows = manifest.get("readonly_external_files")
    if not isinstance(rows, list) or len(rows) != len(READONLY_EXTERNAL_FILES):
        raise GuardStop("manifest must pin exactly tempfile.py and shutil.py as readonly external sources")
    verified = {}
    for row in rows:
        if not isinstance(row, dict):
            raise GuardStop("invalid readonly external source entry")
        name, expected = row.get("path"), row.get("sha256")
        if (name not in READONLY_EXTERNAL_FILES or name in verified or
                not isinstance(expected, str) or not HEX64.fullmatch(expected)):
            raise GuardStop("unrecognized, duplicate or unhashed readonly external source")
        path = Path(name)
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or path.resolve(strict=True) != path or
                info.st_size > MAX_MANIFEST_BYTES):
            raise GuardStop("readonly external source must be exact, regular, nonsymlinked and bounded")
        actual = sha256(path)
        if actual != expected:
            raise GuardStop("readonly external source hash mismatch: " + name)
        verified[name] = {"sha256": actual, "bytes": info.st_size, "access": "read_only"}
        if _interrupted:
            raise GuardStop(_interrupted)
    if set(verified) != READONLY_EXTERNAL_FILES:
        raise GuardStop("missing pinned readonly external source")
    return verified


def verify_prior_attempt(manifest: dict) -> dict:
    """Charge the frozen failed attempt without reopening its execution gate."""
    expected = {"guard_receipt_path": PRIOR_RECEIPT_PATH, "sha256": PRIOR_RECEIPT_SHA256}
    if manifest.get("prior_attempt") != expected:
        raise GuardStop("manifest prior_attempt must identify only the exact pinned v1 guard receipt")
    path = Path(PRIOR_RECEIPT_PATH)
    info = path.lstat()
    if (not stat.S_ISREG(info.st_mode) or path.resolve(strict=True) != path or
            info.st_size > MAX_MANIFEST_BYTES):
        raise GuardStop("prior guard receipt must be exact, regular, nonsymlinked and bounded")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PRIOR_RECEIPT_SHA256:
        raise GuardStop("prior guard receipt differs from its separately pinned hash")
    receipt = json.loads(raw)
    if (not isinstance(receipt, dict) or receipt.get("limits") != LIMITS or
            receipt.get("attempts_launched") != 1 or receipt.get("status") != "STOPPED_OR_FAILED" or
            receipt.get("output") != str(path.parent)):
        raise GuardStop("prior receipt does not describe the frozen failed single attempt")
    values = {}
    for key in ("aggregate_cpu_seconds_final", "guard_cpu_seconds", "child_wait4_cpu_seconds"):
        value = receipt.get(key)
        if type(value) not in (int, float) or not 0 <= value < float("inf"):
            raise GuardStop("invalid prior CPU receipt component: " + key)
        values[key] = value
    prior = max(values["aggregate_cpu_seconds_final"],
                values["guard_cpu_seconds"] + values["child_wait4_cpu_seconds"])
    if abs(prior - PRIOR_AGGREGATE_CPU_SECONDS) > 1e-12:
        raise GuardStop("pinned prior receipt CPU total differs from reviewed 3.611184 seconds")
    return {**expected, "bytes": info.st_size, "components": values,
            "conservative_aggregate_cpu_seconds": prior,
            "accounting": "max(aggregate_cpu_seconds_final, guard_cpu_seconds + child_wait4_cpu_seconds)",
            "prior_evidence_and_claim_preserved": True}


def verify_manifest(expected_hash: str) -> dict:
    if not HEX64.fullmatch(expected_hash):
        raise GuardStop("--manifest-sha256 must be exactly 64 lowercase hexadecimal characters")
    if not MANIFEST.is_file() or MANIFEST.is_symlink():
        raise GuardStop("missing or symlinked frozen_manifest.json")
    if MANIFEST.stat().st_size > MAX_MANIFEST_BYTES:
        raise GuardStop("manifest exceeds bounded stdlib preflight size")
    if sha256(MANIFEST) != expected_hash:
        raise GuardStop("frozen manifest SHA256 differs from separately approved hash")
    manifest = json.loads(MANIFEST.read_text())
    if not isinstance(manifest, dict) or manifest.get("runtime_python") != RUNTIME_REL:
        raise GuardStop("manifest does not pin the existing prepared runtime interpreter")
    if manifest.get("intended_output") != INTENDED_OUTPUT:
        raise GuardStop("manifest does not pin the separately reviewed /tmp output destination")
    if manifest.get("resource_maxima") != LIMITS:
        raise GuardStop("manifest resource maxima differ from the unchanged reviewed limits")
    if manifest.get("output_partitions_bytes") != OUTPUT_PARTITIONS:
        raise GuardStop("manifest output partitions differ from reviewed 23MB/2MB/1MB/6MB")
    if sum(OUTPUT_PARTITIONS.values()) != LIMITS["new_evidence_bytes"]:
        raise GuardStop("output partitions do not sum to unchanged 32MB ceiling")
    if SCRATCH_MAX_FILES_CREATED * SCRATCH_IMPORT_FILE_SOFT_LIMIT > OUTPUT_PARTITIONS["owned_scratch"]:
        raise GuardStop("scratch creation-count/file-cap product exceeds owned scratch allowance")
    readonly_external = verify_readonly_external_files(manifest)
    prior_attempt = verify_prior_attempt(manifest)
    rows = manifest.get("files")
    if not isinstance(rows, list) or not rows:
        raise GuardStop("manifest requires a nonempty files list")
    verified = {}
    for row in rows:
        if not isinstance(row, dict):
            raise GuardStop("invalid manifest entry")
        name, expected = row.get("path"), row.get("sha256")
        if not isinstance(name, str) or not isinstance(expected, str) or not HEX64.fullmatch(expected):
            raise GuardStop("manifest entries require path and lowercase sha256 strings")
        path_part = Path(name)
        if path_part.is_absolute() or ".." in path_part.parts or name != path_part.as_posix():
            raise GuardStop("manifest paths must be canonical repository-relative paths")
        if name in verified or name == relative(MANIFEST):
            raise GuardStop("duplicate entry or manifest self-inclusion")
        path = REPO / path_part
        resolved = path.resolve(strict=True)
        if name != RUNTIME_REL and not resolved.is_relative_to(REPO):
            raise GuardStop("manifest source resolves outside repository: " + name)
        if not resolved.is_file() or checkpoint_name(path):
            raise GuardStop("manifest entry is nonregular or a prohibited checkpoint: " + name)
        actual = sha256(path)
        if actual != expected:
            raise GuardStop("frozen input SHA256 mismatch: " + name)
        verified[name] = {"sha256": actual, "bytes": path.stat().st_size}
        if _interrupted:
            raise GuardStop(_interrupted)
    required = {relative(Path(__file__).resolve()), relative(RUNNER), PROTOCOL_REL, RUNTIME_REL}
    required.update(REFERENCE_REL.values())
    # Every implementation Python source currently present must be frozen;
    # keeping source files out of the manifest must not silently exempt them.
    required.update(relative(path) for path in HERE.rglob("*.py") if path.is_file())
    missing = sorted(required - set(verified))
    if missing:
        raise GuardStop("required files absent from manifest: " + ", ".join(missing))
    protocol = json.loads((REPO / PROTOCOL_REL).read_text())
    if protocol.get("resource_maxima") != LIMITS:
        raise GuardStop("protocol resource maxima differ from the exact reviewed guard limits")
    for key, name in REFERENCE_REL.items():
        if verified[name]["sha256"] != protocol.get(key):
            raise GuardStop("author reference source differs from protocol: " + key)
    runtime = REPO / RUNTIME_REL
    if not os.access(runtime, os.X_OK):
        raise GuardStop("existing runtime interpreter is not executable")
    if Path(sys.executable).resolve() != runtime.resolve():
        raise GuardStop("invoke this guard with the existing prepared .venv/bin/python")
    return {"manifest_sha256": expected_hash, "runtime_python": RUNTIME_REL,
            "intended_output": manifest["intended_output"],
            "runtime_python_resolved": str(runtime.resolve()), "files": verified,
            "readonly_external_files": readonly_external, "prior_attempt": prior_attempt,
            "output_partitions_bytes": OUTPUT_PARTITIONS}


def process_row(pid: int) -> dict | None:
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
        fields = raw[raw.rfind(")") + 2:].split()
        row = {"pid": pid, "state": fields[0], "ppid": int(fields[1]),
               "pgrp": int(fields[2]), "session": int(fields[3]),
               "cpu_seconds": (int(fields[11]) + int(fields[12])) / TICKS,
               "start_ticks": int(fields[19]), "rss_bytes": int(fields[21]) * PAGE_SIZE}
        status = {}
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            key, _, value = line.partition(":")
            if key in {"VmRSS", "VmHWM", "RssAnon", "RssFile", "RssShmem"}:
                status[key] = int(value.split()[0]) * 1024
        row.update({"rss_bytes": status.get("VmRSS", row["rss_bytes"]),
                    "os_hwm_bytes": status.get("VmHWM"),
                    "anonymous_rss_bytes": status.get("RssAnon"),
                    "file_rss_bytes": status.get("RssFile"),
                    "shmem_rss_bytes": status.get("RssShmem")})
        try:
            pss = {}
            for line in Path(f"/proc/{pid}/smaps_rollup").read_text().splitlines():
                key, _, value = line.partition(":")
                if key in {"Pss", "Pss_Anon", "Pss_File", "Pss_Shmem"}:
                    pss[key] = int(value.split()[0]) * 1024
            row["pss_bytes"] = pss.get("Pss")
            row["pss_anon_bytes"] = pss.get("Pss_Anon")
            row["pss_file_bytes"] = pss.get("Pss_File")
            row["pss_shmem_bytes"] = pss.get("Pss_Shmem")
            row["pss_unavailable"] = False
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            row["pss_bytes"] = None
            row["pss_unavailable"] = True
        return row
    except (FileNotFoundError, ProcessLookupError):
        return None


def process_table() -> dict[int, dict]:
    table = {}
    for entry in Path("/proc").iterdir():
        if entry.name.isdecimal():
            # Read stat first; expensive memory details are read only for the
            # monitored tree, not for unrelated processes on the host.
            try:
                raw = (entry / "stat").read_text()
                fields = raw[raw.rfind(")") + 2:].split()
                table[int(entry.name)] = {"ppid": int(fields[1]), "pgrp": int(fields[2]),
                                          "start_ticks": int(fields[19]), "state": fields[0]}
            except (FileNotFoundError, ProcessLookupError):
                pass
    return table


def sample_tree(pgid: int, known: dict) -> tuple[list[dict], list[int]]:
    table = process_table()
    selected = {pid for pid, row in table.items() if row["pgrp"] == pgid}
    selected.update(pid for pid, row in table.items() if (pid, row["start_ticks"]) in known)
    changed = True
    while changed:
        new = {pid for pid, row in table.items() if row["ppid"] in selected} - selected
        selected.update(new)
        changed = bool(new)
    rows = []
    for pid in sorted(selected):
        row = process_row(pid)
        if row is not None:
            identity = (pid, row["start_ticks"])
            old = known.get(identity, {})
            known[identity] = {"pid": pid, "start_ticks": row["start_ticks"],
                               "max_cpu_seconds": max(old.get("max_cpu_seconds", 0), row["cpu_seconds"]),
                               "max_sampled_rss_bytes": max(old.get("max_sampled_rss_bytes", 0), row["rss_bytes"]),
                               "max_observed_os_hwm_bytes": max(old.get("max_observed_os_hwm_bytes", 0), row.get("os_hwm_bytes") or 0)}
            rows.append(row)
    return rows, [row["pid"] for row in rows if row["pgrp"] != pgid]


def evidence_accounting(output: Path) -> dict:
    """Sample every output allocation; scratch is part of, never extra to, 32MB.

    Import-created scratch files may disappear between directory enumeration and
    lstat. Their strict creation count and 64KiB per-file kernel limit are also
    enforced by the frozen child, so an unobserved short-lived probe is bounded.
    Allocated directory blocks are charged as well as regular-file blocks.
    """
    claim_info = CLAIM.stat() if CLAIM.exists() else None
    claim_bytes = claim_info.st_size if claim_info else 0
    claim_allocated = claim_info.st_blocks * 512 if claim_info else 0
    root_info = output.lstat()
    if not stat.S_ISDIR(root_info.st_mode):
        raise GuardStop("owned output root is no longer a nonsymlink directory")
    scratch = output / "scratch"
    scratch_info = scratch.lstat()
    if not stat.S_ISDIR(scratch_info.st_mode) or stat.S_IMODE(scratch_info.st_mode) != 0o700:
        raise GuardStop("owned scratch root must remain a mode-0700 nonsymlink directory")
    parts = {name: {"logical_bytes": 0, "allocated_bytes": 0}
             for name in OUTPUT_PARTITIONS}
    parts["all_guard_evidence"]["logical_bytes"] = claim_bytes
    parts["all_guard_evidence"]["allocated_bytes"] = claim_allocated + root_info.st_blocks * 512
    scratch_files = 0
    scratch_directories = 0
    output_bytes = 0
    output_allocated = root_info.st_blocks * 512
    for base, directories, files in os.walk(output, followlinks=False):
        for name in directories + files:
            path = Path(base) / name
            try:
                info = path.lstat()
            except FileNotFoundError:
                if path.is_relative_to(scratch):
                    continue  # Expected native probe unlink or tmpdir cleanup.
                raise
            if stat.S_ISLNK(info.st_mode):
                raise GuardStop("output contains a symlink: " + str(path))
            is_scratch = path.is_relative_to(scratch)
            partition = ("owned_scratch" if is_scratch else
                         "child_compressed_trace" if path == output / "trace.jsonl.gz" else
                         "child_result" if path == output / "result.json" else "all_guard_evidence")
            if stat.S_ISREG(info.st_mode):
                if info.st_nlink != 1:
                    raise GuardStop("output contains a hardlinked file")
                output_bytes += info.st_size
                parts[partition]["logical_bytes"] += info.st_size
                if is_scratch:
                    scratch_files += 1
                    if info.st_size > SCRATCH_IMPORT_FILE_SOFT_LIMIT:
                        raise GuardStop("owned_scratch_file_exceeds_import_65536_byte_cap")
            elif stat.S_ISDIR(info.st_mode):
                if is_scratch and path != scratch:
                    scratch_directories += 1
            else:
                raise GuardStop("output contains a nonregular file")
            allocated = info.st_blocks * 512
            output_allocated += allocated
            parts[partition]["allocated_bytes"] += allocated
    for name, usage in parts.items():
        ceiling = OUTPUT_PARTITIONS[name]
        if usage["logical_bytes"] > ceiling or usage["allocated_bytes"] > ceiling:
            raise GuardStop("output_partition_exceeded_logical_or_allocated:" + name)
    if scratch_files > SCRATCH_MAX_FILES_CREATED or scratch_directories > SCRATCH_MAX_DIRECTORIES_CREATED:
        raise GuardStop("owned_scratch_observed_file_or_directory_count_exceeded")
    total_logical = claim_bytes + output_bytes
    total_allocated = claim_allocated + output_allocated
    if max(total_logical, total_allocated) > LIMITS["new_evidence_bytes"]:
        raise GuardStop("new_evidence_total_logical_or_allocated_bytes_exceeded")
    return {"total_logical_bytes": total_logical, "total_allocated_bytes": total_allocated,
            "total_accounted_bytes": max(total_logical, total_allocated),
            "output_logical_bytes": output_bytes, "output_allocated_bytes": output_allocated,
            "claim_logical_bytes": claim_bytes, "claim_allocated_bytes": claim_allocated,
            "scratch_logical_bytes": parts["owned_scratch"]["logical_bytes"],
            "scratch_allocated_bytes": parts["owned_scratch"]["allocated_bytes"],
            "scratch_observed_files": scratch_files, "scratch_observed_directories": scratch_directories,
            "partitions": parts}


def inspect_terminal_scratch(output: Path) -> dict:
    """Verify native atexit cleanup without deleting or following leftovers.

    A zero child exit does not prove successful atexit cleanup: an exception may
    have been reported as unraisable. Success requires the owned root alone.
    Failed attempts retain all remaining evidence for separate review.
    """
    scratch = output / "scratch"
    info = scratch.lstat()
    if not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o700:
        raise GuardStop("terminal_owned_scratch_root_missing_or_not_mode_0700_directory")
    leftovers = []
    def fail_walk(error: OSError) -> None:
        raise error
    for base, directories, files in os.walk(scratch, followlinks=False, onerror=fail_walk):
        for name in sorted(directories + files):
            path = Path(base) / name
            entry = path.lstat()
            kind = ("file" if stat.S_ISREG(entry.st_mode) else
                    "directory" if stat.S_ISDIR(entry.st_mode) else
                    "symlink" if stat.S_ISLNK(entry.st_mode) else "other")
            leftovers.append({"path_relative_to_scratch": path.relative_to(scratch).as_posix(),
                              "kind": kind, "logical_bytes": entry.st_size,
                              "allocated_bytes": entry.st_blocks * 512})
            if len(leftovers) >= 64:
                return {"checked": True, "empty": False, "entries_complete": False,
                        "leftovers": leftovers, "stop_reason": "terminal_scratch_listing_cap",
                        "evidence_preserved_without_deletion": True}
    return {"checked": True, "empty": not leftovers, "entries_complete": True,
            "leftovers": leftovers, "root_mode": "0700",
            "root_allocated_bytes": info.st_blocks * 512,
            "evidence_preserved_without_deletion": True}


def evidence_bytes(output: Path) -> int:
    return evidence_accounting(output)["total_accounted_bytes"]


def child_environment(output: Path, token: str, manifest_hash: str) -> dict[str, str]:
    env = os.environ.copy()
    for name in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "LD_PRELOAD", "LD_AUDIT"):
        env.pop(name, None)
    for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
                 "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS", "PHASE_A_INTRAOP_THREADS", "PHASE_A_INTEROP_THREADS"):
        env[name] = "1"
    env.update({"OMP_DYNAMIC": "FALSE", "MKL_DYNAMIC": "FALSE", "CUDA_VISIBLE_DEVICES": "",
                "HIP_VISIBLE_DEVICES": "", "ROCR_VISIBLE_DEVICES": "", "NVIDIA_VISIBLE_DEVICES": "void",
                "PYTHONHASHSEED": "20261005", "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1",
                "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
                "HF_HUB_DISABLE_TELEMETRY": "1", "DO_NOT_TRACK": "1", "TOKENIZERS_PARALLELISM": "false",
                "PHASE_A_GUARD_TOKEN": token, "PHASE_A_MANIFEST_SHA256": manifest_hash,
                "PHASE_A_OUTPUT": str(output), "PHASE_A_NO_SUBPROCESS": "1",
                "TMPDIR": str(output / "scratch"), "TEMP": str(output / "scratch"), "TMP": str(output / "scratch"),
                "PHASE_A_SCRATCH": str(output / "scratch"),
                "XDG_CACHE_HOME": str(output / "cache"),
                "HF_HOME": str(output / "cache" / "huggingface"), "TORCH_HOME": str(output / "cache")})
    return env


def reap_direct(child: subprocess.Popen, nohang: bool) -> tuple[int, object] | None:
    global _active_pgid
    pid, status, usage = os.wait4(child.pid, os.WNOHANG if nohang else 0)
    if pid == 0:
        return None
    child.returncode = os.waitstatus_to_exitcode(status)
    # Once the leader is reaped its PID can be reused; the asynchronous signal
    # handler must no longer target that numeric PGID without a fresh identity
    # check. Synchronous cleanup below verifies all observed identities.
    _active_pgid = None
    return child.returncode, usage


def cleanup_group(child: subprocess.Popen | None, known: dict, already_reaped: bool, deadline: float) -> dict:
    global _active_pgid
    if child is None:
        return {"scope": "no_child_launched", "all_absent": True, "remaining": []}
    pgid = child.pid
    table = process_table()
    members = [pid for pid, row in table.items() if row["pgrp"] == pgid]
    identity_collision = (pgid in table and known and
                          (pgid, table[pgid]["start_ticks"]) not in known)
    if members and not identity_collision:
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    _active_pgid = None
    usage = None
    # No retry or relaunch. This bounded wait verifies disappearance after the
    # one cleanup signal; surviving/reparented zombies are reported as failures.
    cleanup_start = time.monotonic()
    remaining = []
    while True:
        if not already_reaped:
            result = reap_direct(child, True)
            if result is not None:
                _, usage = result
                already_reaped = True
        table = process_table()
        remaining = [{"pid": pid, **row} for pid, row in table.items()
                     if row["pgrp"] == pgid or (pid, row["start_ticks"]) in known]
        if not remaining or time.monotonic() - cleanup_start >= 0.5 or time.monotonic() >= deadline:
            break
        time.sleep(0.01)
    result = {"scope": "only_new_child_process_group", "pgid": pgid,
              "kill_signal": "SIGKILL" if members and not identity_collision else None,
              "all_absent": not remaining, "remaining": remaining,
              "pid_identity_collision_refused_signal": identity_collision,
              "checked_utc": utc_now(), "proof": "fresh /proc scan of group and all observed PID/start-time identities"}
    if usage is not None:
        result["direct_child_final_cpu_seconds"] = usage.ru_utime + usage.ru_stime
        result["direct_child_wait4_maxrss_bytes"] = usage.ru_maxrss * 1024
    return result


def main(argv: list[str] | None = None) -> int:
    global _active_pgid
    start = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute-phase-a-approved", action="store_true", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--output", required=True, help="fresh absent directory; its parent must already exist")
    args = parser.parse_args(argv)
    if not args.execute_phase_a_approved:
        parser.error("explicit separately approved execution flag is required")
    output = None
    child = None
    known = {}
    selector = selectors.DefaultSelector()
    guard_evidence = GuardEvidenceBudget()
    streams = []
    reaped = False
    child_cpu = 0.0
    child_hwm = 0
    peak_tree_rss = 0
    peak_combined_rss = 0
    samples = 0
    max_sample_gap = 0.0
    last_sample = None
    stop = None
    hashes = None
    prior_cpu = PRIOR_AGGREGATE_CPU_SECONDS
    initial_available = None
    min_available = None
    min_disk = None
    min_source_disk = None
    output_filesystem = None
    source_filesystem = None
    initial_tmpfs_reserve = 0
    cleanup = {"all_absent": True, "scope": "no_child_launched", "remaining": []}
    try:
        if not sys.platform.startswith("linux") or not Path("/proc/self/stat").is_file():
            raise GuardStop("Linux /proc and resource limits are required")
        arm_guard_limits(start)
        if os.path.lexists(CLAIM):
            raise GuardStop("one Phase A attempt was already claimed; no automatic or manual retry under this frozen manifest")
        requested = Path(args.output).expanduser()
        if not requested.is_absolute():
            requested = Path.cwd() / requested
        parent = requested.parent.resolve(strict=True)
        candidate = parent / requested.name
        if requested.name in {"", ".", ".."} or os.path.lexists(candidate):
            raise GuardStop("--output must name a fresh absent path")
        if not parent.is_dir():
            raise GuardStop("output parent is not an existing directory")
        hashes = verify_manifest(args.manifest_sha256)
        prior_cpu = hashes["prior_attempt"]["conservative_aggregate_cpu_seconds"]
        if prior_cpu + cpu_self() >= LIMITS["combined_cpu_budget_seconds"]:
            raise GuardStop("prior_plus_preflight_cpu_exhausted_cumulative_100s_budget")
        if str(candidate) != hashes["intended_output"]:
            raise GuardStop("--output does not match frozen manifest intended_output")
        output_filesystem = filesystem_for(parent)
        source_filesystem = filesystem_for(HERE)
        initial_tmpfs_reserve = (LIMITS["new_evidence_bytes"] if output_filesystem["in_memory"]
                                 else 4096 if source_filesystem["in_memory"] else 0)
        initial_available = host_available()
        min_available = initial_available
        if initial_available < LIMITS["start_host_available_bytes"] + initial_tmpfs_reserve:
            raise GuardStop("host available memory is below 3000000000 bytes plus the explicit tmpfs evidence reserve")
        min_disk = shutil.disk_usage(parent).free
        if min_disk < LIMITS["free_disk_floor_bytes"] + LIMITS["new_evidence_bytes"]:
            raise GuardStop("output filesystem requires 5032000000 free bytes: 5GB floor plus full 32MB evidence allowance")
        min_source_disk = shutil.disk_usage(HERE).free
        if min_source_disk < LIMITS["free_disk_floor_bytes"] + 4096:
            raise GuardStop("source filesystem lacks 5GB floor plus one-attempt claim allowance")
        if _interrupted:
            raise GuardStop(_interrupted)
        claim = {"status": "ONE_ATTEMPT_CLAIMED_NO_RETRY", "claimed_utc": utc_now(),
                 "manifest_sha256": args.manifest_sha256, "output": str(candidate),
                 "guard_pid": os.getpid(), "execution_requires_separate_approval": True,
                 "prior_attempt_receipt_sha256": PRIOR_RECEIPT_SHA256,
                 "prior_aggregate_cpu_seconds": prior_cpu}
        # O_EXCL is the persistent one-attempt gate. Never remove this claim.
        with CLAIM.open("xb") as stream:
            guard_evidence.write(stream, compact(claim))
            stream.flush()
            os.fsync(stream.fileno())
        candidate.mkdir(mode=0o700)
        output = candidate
        (output / "scratch").mkdir(mode=0o700)
        (output / "cache").mkdir(mode=0o700)
        guard_evidence.write_file(output / "verified_inputs.json", compact(hashes))
        sample_stream = (output / "resource_samples.jsonl").open("xb", buffering=0)
        streams.append(sample_stream)
        stdout_stream = (output / "child_stdout.log").open("xb", buffering=0)
        stderr_stream = (output / "child_stderr.log").open("xb", buffering=0)
        streams.extend([stdout_stream, stderr_stream])
        token = secrets.token_hex(32)
        start_read, start_write = os.pipe()
        env = child_environment(output, token, args.manifest_sha256)
        env["PHASE_A_START_FD"] = str(start_read)
        try:
            child = subprocess.Popen([str(REPO / RUNTIME_REL), "-B", str(RUNNER), "--output", str(output),
                                      "--guard-token", token], cwd=REPO, env=env,
                                     stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     start_new_session=True, preexec_fn=child_limits,
                                     pass_fds=(start_read,), close_fds=True)
            _active_pgid = child.pid
            resource.setrlimit(resource.RLIMIT_CPU, (4, LIMITS["guard_cpu_hard_seconds"]))
            if _interrupted or cpu_self() >= 4.0:
                raise GuardStop(_interrupted or "guard_preflight_cpu_exhausted")
            initial_rows, escaped = sample_tree(child.pid, known)
            if escaped or not any(row["pid"] == child.pid for row in initial_rows):
                raise GuardStop("cannot identify isolated child at start barrier")
            os.write(start_write, b"G")
        finally:
            os.close(start_read)
            os.close(start_write)
        for source, destination in ((child.stdout, stdout_stream), (child.stderr, stderr_stream)):
            os.set_blocking(source.fileno(), False)
            selector.register(source, selectors.EVENT_READ, destination)
        next_sample = time.monotonic()
        while True:
            now = time.monotonic()
            if _interrupted:
                raise GuardStop(_interrupted)
            if now - start >= LIMITS["guarded_wall_seconds"]:
                raise GuardStop("guarded_wall_seconds")
            if now >= next_sample:
                gap = 0.0 if last_sample is None else now - last_sample
                max_sample_gap = max(max_sample_gap, gap)
                last_sample = now
                rows, escaped = sample_tree(child.pid, known)
                own = process_row(os.getpid())
                if own is None:
                    raise GuardStop("guard process accounting unavailable")
                tree_rss = sum(row["rss_bytes"] for row in rows)
                combined_rss = tree_rss + own["rss_bytes"]
                peak_tree_rss = max(peak_tree_rss, tree_rss)
                peak_combined_rss = max(peak_combined_rss, combined_rss)
                available = host_available()
                min_available = min(min_available, available)
                disk_free = shutil.disk_usage(output).free
                min_disk = min(min_disk, disk_free)
                source_disk_free = shutil.disk_usage(HERE).free
                min_source_disk = min(min_source_disk, source_disk_free)
                aggregate_cpu = cpu_self() + sum(row["max_cpu_seconds"] for row in known.values())
                cumulative_cpu = prior_cpu + aggregate_cpu
                evidence = evidence_accounting(output)
                used = evidence["total_accounted_bytes"]
                tmpfs_logical = ((evidence["output_logical_bytes"] if output_filesystem["in_memory"] else 0)
                                  + (evidence["claim_logical_bytes"] if source_filesystem["in_memory"] else 0))
                tmpfs_allocated = ((evidence["output_allocated_bytes"] if output_filesystem["in_memory"] else 0)
                                    + (evidence["claim_allocated_bytes"] if source_filesystem["in_memory"] else 0))
                # MemAvailable already reflects materialized tmpfs pages. Only
                # reserve the still-unwritten allowance; never charge the same
                # allocated pages against MemAvailable a second time.
                remaining_tmpfs_reserve = (max(0, LIMITS["new_evidence_bytes"] - evidence["output_allocated_bytes"])
                                           if output_filesystem["in_memory"] else 0)
                record = {"wall_seconds": now - start, "sample_gap_seconds": gap,
                          "processes": rows, "guard": own, "tree_rss_bytes": tree_rss,
                          "combined_guard_and_tree_rss_bytes": combined_rss,
                          "observed_aggregate_cpu_seconds": aggregate_cpu,
                          "prior_aggregate_cpu_seconds": prior_cpu,
                          "observed_cumulative_aggregate_cpu_seconds": cumulative_cpu,
                          "host_available_bytes": available, "disk_free_bytes": disk_free,
                          "source_filesystem_disk_free_bytes": source_disk_free,
                          "evidence_bytes_before_sample": used, "evidence_storage": evidence,
                          "tmpfs_evidence_logical_bytes": tmpfs_logical,
                          "tmpfs_evidence_allocated_bytes": tmpfs_allocated,
                          "remaining_unwritten_tmpfs_reserve_bytes": remaining_tmpfs_reserve,
                          "host_available_after_unwritten_tmpfs_reserve_bytes": available - remaining_tmpfs_reserve}
                payload = compact(record)
                if used + len(payload) >= LIMITS["new_evidence_bytes"] - RESERVE_BYTES:
                    raise GuardStop("new_evidence_bytes_with_receipt_reserve")
                guard_evidence.write(sample_stream, payload)
                samples += 1
                if escaped:
                    raise GuardStop("descendant_escaped_owned_process_group:" + repr(escaped))
                if any(row["pid"] != child.pid for row in rows):
                    raise GuardStop("unexpected_child_subprocess: frozen Phase A must remain single-process")
                # Count the guard as well: this is stricter than a child-tree-only ceiling.
                if combined_rss > LIMITS["process_tree_rss_bytes"]:
                    raise GuardStop("sampled_process_tree_rss_bytes_including_guard")
                if available - remaining_tmpfs_reserve < LIMITS["minimum_host_available_bytes"]:
                    raise GuardStop("minimum_host_available_bytes_after_unwritten_tmpfs_reserve")
                if min(disk_free, source_disk_free) < LIMITS["free_disk_floor_bytes"]:
                    raise GuardStop("free_disk_floor_bytes")
                if cumulative_cpu > LIMITS["combined_cpu_budget_seconds"]:
                    raise GuardStop("cumulative_combined_cpu_budget_seconds_including_prior_attempt")
                if cpu_self() >= 4.0:
                    raise GuardStop("guard_cpu_soft_stop_before_5s_hard_limit")
                next_sample = now + LIMITS["rss_sample_interval_seconds"]
            result = reap_direct(child, True)
            if result is not None:
                _, usage = result
                reaped = True
                child_cpu = usage.ru_utime + usage.ru_stime
                child_hwm = usage.ru_maxrss * 1024
                break
            timeout = max(0.0, min(next_sample - time.monotonic(), LIMITS["rss_sample_interval_seconds"]))
            for key, _events in selector.select(timeout):
                data = os.read(key.fileobj.fileno(), 65536)
                if not data:
                    selector.unregister(key.fileobj)
                    continue
                if evidence_bytes(output) + len(data) >= LIMITS["new_evidence_bytes"] - RESERVE_BYTES:
                    raise GuardStop("child_logs_exhausted_evidence_budget")
                guard_evidence.write(key.data, data)
        if child.returncode != 0:
            raise GuardStop("child_exit_" + str(child.returncode))
    except BaseException as error:
        stop = type(error).__name__ + ": " + str(error)
    finally:
        # Also hard-cap terminal handling if preflight failed before the fork.
        resource.setrlimit(resource.RLIMIT_CPU, (4, LIMITS["guard_cpu_hard_seconds"]))
        try:
            cleanup = cleanup_group(child, known, reaped, start + LIMITS["guarded_wall_seconds"])
            child_cpu = max(child_cpu, cleanup.get("direct_child_final_cpu_seconds", 0))
            child_hwm = max(child_hwm, cleanup.get("direct_child_wait4_maxrss_bytes", 0))
        except BaseException as error:
            cleanup = {"scope": "only_new_child_process_group", "all_absent": False,
                       "error": type(error).__name__ + ": " + str(error)}
            stop = stop or "cleanup_unverified"
        # After cleanup the remaining pipe bytes are finite. Keep diagnostics if
        # they fit, without spending the reserved terminal-receipt allowance.
        for key in list(selector.get_map().values()):
            try:
                while True:
                    data = os.read(key.fileobj.fileno(), 65536)
                    if not data:
                        break
                    if output is not None and evidence_bytes(output) + len(data) < LIMITS["new_evidence_bytes"] - RESERVE_BYTES:
                        guard_evidence.write(key.data, data)
                    else:
                        stop = stop or "final_child_logs_exceed_evidence_allowance"
                        break
            except (OSError, GuardStop) as error:
                stop = stop or "final_log_drain:" + str(error)
        selector.close()
        for stream in streams:
            stream.close()
        if child is not None:
            for pipe in (child.stdout, child.stderr):
                if pipe is not None:
                    pipe.close()
        if _interrupted:
            stop = stop or _interrupted
        if not cleanup.get("all_absent"):
            stop = stop or "cleanup_did_not_prove_process_group_absent"
        terminal_scratch = {"checked": False, "empty": None, "leftovers": [],
                            "reason": "owned_output_not_created"}
        if output is not None:
            try:
                terminal_scratch = inspect_terminal_scratch(output)
                terminal_scratch["owned_process_cleanup_all_absent"] = cleanup.get("all_absent", False)
                if not terminal_scratch["empty"]:
                    stop = stop or "terminal_owned_scratch_not_empty"
            except BaseException as error:
                terminal_scratch = {"checked": False, "empty": None, "leftovers": [],
                                    "inspection_error": type(error).__name__ + ": " + str(error),
                                    "evidence_preserved_without_deletion": True,
                                    "owned_process_cleanup_all_absent": cleanup.get("all_absent", False)}
                stop = stop or "terminal_owned_scratch_inspection_failed"
        combined_cpu = cpu_self() + max(child_cpu, sum(row["max_cpu_seconds"] for row in known.values()))
        cumulative_cpu = prior_cpu + combined_cpu
        if cumulative_cpu > LIMITS["combined_cpu_budget_seconds"]:
            stop = stop or "final_cumulative_combined_cpu_budget_seconds_including_prior_attempt"
        if child_hwm > LIMITS["process_tree_rss_bytes"]:
            stop = stop or "kernel_child_high_water_rss_exceeded_1GiB_between_samples"
        if time.monotonic() - start > LIMITS["guarded_wall_seconds"]:
            stop = stop or "final_guarded_wall_seconds"
        try:
            final_available = host_available()
            min_available = final_available if min_available is None else min(min_available, final_available)
            if final_available < LIMITS["minimum_host_available_bytes"]:
                stop = stop or "final_minimum_host_available_bytes"
            if output is not None:
                final_disk = shutil.disk_usage(output).free
                min_disk = final_disk if min_disk is None else min(min_disk, final_disk)
                if final_disk < LIMITS["free_disk_floor_bytes"]:
                    stop = stop or "final_free_disk_floor_bytes"
            final_source_disk = shutil.disk_usage(HERE).free
            min_source_disk = final_source_disk if min_source_disk is None else min(min_source_disk, final_source_disk)
            if final_source_disk < LIMITS["free_disk_floor_bytes"]:
                stop = stop or "final_source_filesystem_disk_floor_bytes"
        except BaseException as error:
            stop = stop or "final_resource_accounting_failed:" + str(error)
        receipt = {"status": "STOPPED_OR_FAILED" if stop else "CHILD_COMPLETED_WITHIN_OBSERVED_LIMITS",
                   "stop_reason": stop, "recorded_utc": utc_now(), "attempts_launched": int(child is not None),
                   "manifest_sha256": args.manifest_sha256, "output": str(output) if output else None,
                   "limits": LIMITS, "child_returncode": child.returncode if child else None,
                   "cooperative_output_partition_bytes": OUTPUT_PARTITIONS,
                   "owned_scratch": {"path": str(output / "scratch") if output else None,
                                     "mode": "0700", "partition_bytes": OUTPUT_PARTITIONS["owned_scratch"],
                                     "import_file_soft_limit_bytes": SCRATCH_IMPORT_FILE_SOFT_LIMIT,
                                     "maximum_files_created": SCRATCH_MAX_FILES_CREATED,
                                     "maximum_directories_created": SCRATCH_MAX_DIRECTORIES_CREATED,
                                     "native_import_only": True,
                                     "closure_and_sealing_required_in_child_receipt": True},
                   "terminal_owned_scratch": terminal_scratch,
                   "success_requires_empty_owned_scratch_after_child_cleanup": True,
                   "prior_attempt": hashes["prior_attempt"] if hashes else None,
                   "prior_aggregate_cpu_seconds": prior_cpu,
                   "cumulative_aggregate_cpu_seconds_final": cumulative_cpu,
                   "guard_evidence_bytes_charged_before_receipt": guard_evidence.charged_bytes,
                   "guard_wall_seconds": time.monotonic() - start, "guard_cpu_seconds": cpu_self(),
                   "guard_wait4_self_maxrss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                   "child_wait4_cpu_seconds": child_cpu, "aggregate_cpu_seconds_final": combined_cpu,
                   "child_wait4_maxrss_bytes": child_hwm, "peak_sampled_child_tree_rss_bytes": peak_tree_rss,
                   "peak_sampled_guard_plus_tree_rss_bytes": peak_combined_rss,
                   "sample_count": samples, "maximum_observed_sample_gap_seconds": max_sample_gap,
                   "start_host_available_bytes": initial_available, "minimum_observed_host_available_bytes": min_available,
                   "minimum_observed_disk_free_bytes": min_disk, "process_high_water_marks": list(known.values()),
                   "minimum_observed_source_filesystem_disk_free_bytes": min_source_disk,
                   "output_filesystem": output_filesystem, "source_filesystem": source_filesystem,
                   "initial_tmpfs_evidence_reserve_bytes": initial_tmpfs_reserve,
                   "tmpfs_accounting_policy": "Reserve the full 32MB evidence allowance at admission for tmpfs output, including the owned 1MB scratch partition; record logical and allocated bytes including directory blocks; MemAvailable already charges allocated tmpfs pages, so ongoing headroom subtracts only the unallocated allowance",
                   "cleanup": cleanup,
                   "limitations": ["RSS/PSS/host/disk sampled at a 25ms target; actual maximum gap is disclosed; brief peaks can escape samples",
                                    "Aggregate32MB evidence uses frozen partitions: child trace23MB, result2MB, owned import scratch1MB, guard6MB including a256KB receipt reserve; logical and allocated ceilings are sampled, no kernel filesystem quota is claimed",
                                    "Guard preflight uses 4s soft/90s hard only to preserve child inheritance, then parent cumulative hard limit becomes 5s before the child start barrier is released",
                                    "Linux PR_SET_PDEATHSIG kills the direct child if guard dies; child audit must forbid subprocess creation",
                                    "Linux VmHWM per observed process and wait4 ru_maxrss for direct child supplement sampled RSS; summed per-process HWMs are not a simultaneous tree peak",
                                    "Kernel CPU limits apply per process; unexpected descendants stop the run; sampled aggregate accounting alone cannot observe a process born and exited between samples",
                                    "The cumulative100s CPU gate includes the pinned prior failed attempt at conservative3.611184s; per-attempt child90s and guard5s hard limits are unchanged",
                                    "Native import scratch permits one probe and one generated source file in one owned temporary directory, each at most65536bytes under temporary RLIMIT_FSIZE soft cap; the child audits exact pinned call sites, closes writable FDs, seals scratch writes, and restores the original soft cap",
                                    "Child audit policy and frozen-source review enforce no network, installs, trained checkpoint reads or subprocesses; this supervisor alone is not an OS sandbox",
                                    "Successful launcher exit additionally requires empty owned scratch after native child atexit and owned-process cleanup; leftover paths are recorded and preserved, never silently deleted",
                                    "Successful launcher exit is only resource-supervision evidence; the separate numerical receipt determines semantic acceptance",
                                    "Hard SIGKILL, host failure or a kernel hard-limit kill of the guard can prevent final receipt; absence of a successful receipt is failure"]}
        if output is not None:
            try:
                terminal_storage = evidence_accounting(output)
                current_bytes = terminal_storage["total_accounted_bytes"]
                receipt["new_evidence_bytes_before_receipt"] = current_bytes
                receipt["final_evidence_storage_before_receipt"] = terminal_storage
                receipt["final_tmpfs_evidence_allocated_bytes_before_receipt"] = (
                    (terminal_storage["output_allocated_bytes"] if output_filesystem["in_memory"] else 0)
                    + (terminal_storage["claim_allocated_bytes"] if source_filesystem["in_memory"] else 0))
                payload = compact(receipt)
                # Reserve block-rounded allocation for this final guard file.
                receipt_allocation = ((len(payload) + 4095) // 4096) * 4096
                if current_bytes + receipt_allocation > LIMITS["new_evidence_bytes"]:
                    receipt["status"] = "STOPPED_OR_FAILED"
                    receipt["stop_reason"] = receipt["stop_reason"] or "evidence_ceiling_exceeded"
                    stop = receipt["stop_reason"]
                    # Do not delete evidence to make an over-budget run pass.
                    raise GuardStop("no room for terminal receipt under evidence ceiling")
                with (output / "guard_receipt.json").open("xb") as stream:
                    guard_evidence.write(stream, payload, terminal=True)
                    stream.flush()
                    os.fsync(stream.fileno())
                if _interrupted or time.monotonic() - start > LIMITS["guarded_wall_seconds"]:
                    stop = stop or _interrupted or "terminal_receipt_exceeded_guarded_wall_seconds"
                    receipt["status"] = "STOPPED_OR_FAILED"
                    receipt["stop_reason"] = stop
                    # A signal during terminal IO must never leave a success
                    # receipt. This is the guard's own newly created file.
                    replacement = compact(receipt)
                    old_size = (output / "guard_receipt.json").stat().st_size
                    if evidence_bytes(output) - old_size + len(replacement) <= LIMITS["new_evidence_bytes"]:
                        guard_evidence.write_file(output / "guard_receipt.json", replacement, terminal=True, replace=True)
            except BaseException as error:
                stop = stop or "terminal_receipt_write_failed:" + str(error)
                receipt["status"] = "STOPPED_OR_FAILED"
                receipt["stop_reason"] = stop
        signal.setitimer(signal.ITIMER_REAL, 0)
        # Never print the guard token or the entire inherited environment.
        guard_evidence.write(sys.stdout.buffer, compact({"status": receipt["status"], "stop_reason": receipt["stop_reason"],
                                                       "output": receipt["output"], "cleanup_all_absent": cleanup.get("all_absent")}), terminal=True)
    return 1 if stop else 0


if __name__ == "__main__":
    raise SystemExit(main())
