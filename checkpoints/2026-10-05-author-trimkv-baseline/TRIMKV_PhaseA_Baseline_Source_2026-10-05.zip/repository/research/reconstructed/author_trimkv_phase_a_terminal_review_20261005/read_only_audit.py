"""Root-authorized bounded read-only audit of finalized Phase A v4 evidence.

No Torch/model/fixture execution. The only imported target is the pinned,
stdlib-only evidence decoder. Output is a new independent audit receipt.
"""
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time

ROOT=Path('/workspace/scratch/a95be92193c8/kv_recovery_20261004_h7Ob9Y/restored/kv-cache-research')
IMPL=ROOT/'research/reconstructed/author_trimkv_phase_a_implementation_v4_20261005'
OUTPUT=Path('/tmp/trimkv_phase_a_author_parity_20261005_attempt4')
HERE=Path(__file__).resolve().parent
RECEIPT=HERE/'INDEPENDENT_AUDIT.json'
MANIFEST_HASH='173a928ab6c852a705a0a71738f98cec3c197f8a8a9831b1c05a2d16a6ba2150'
CODEC_HASH='03ff37ede9adb969eadc11c59ac5ac9e3aa3b96912b8c8656de1feca0f596d69'
PINS={'result.json':'e6818865f68cd616928b90d038a13e5640f214283b6671346b65964caf8a0520',
      'guard_receipt.json':'8d41ca213f57a18454e93b01b920792923f4101cd5a7f873d0e14c6a37828571',
      'trace.tkv3':'5434e0f4d5240db16a53f301ba5570c9ad05eb05b1f27cf17e8c54c457a20acd'}


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def main():
    if RECEIPT.exists():
        raise SystemExit('Independent audit receipt already exists; no overwrite')
    started=time.monotonic()
    resource.setrlimit(resource.RLIMIT_CPU,(7,8))
    resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
    resource.setrlimit(resource.RLIMIT_FSIZE,(1048576,1048576))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    def timeout(*_):
        raise TimeoutError('Read-only audit exceeded15s wall or7s soft CPU')
    signal.signal(signal.SIGALRM,timeout)
    signal.signal(signal.SIGXCPU,timeout)
    signal.setitimer(signal.ITIMER_REAL,15)
    sys.dont_write_bytecode=True
    def audit(event,args):
        if event=='import' and str(args[0]).split('.')[0] in {'torch','transformers','numpy','trimkv'}:
            raise PermissionError('Numerical/model imports are outside this audit')
        if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp'}:
            raise PermissionError('Audit is read-only and offline')
        if event=='open' and isinstance(args[0],(str,bytes)):
            path=Path(os.fsdecode(args[0])).resolve()
            mode=args[1] or '';flags=args[2]
            writing=any(c in str(mode) for c in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing and path!=RECEIPT:
                raise PermissionError('Only the new independent receipt may be written')
            if not writing and path.suffix.lower() in {'.safetensors','.pt','.pth','.ckpt','.bin','.gguf','.ggml'}:
                raise PermissionError('No trained/ambiguous tensor payload reads')
        if event in {'os.remove','os.rmdir','os.mkdir','os.rename','os.link','os.symlink','os.chmod','os.chown','os.utime','os.truncate'}:
            raise PermissionError('Existing evidence must remain untouched')
    sys.addaudithook(audit)
    receipt={'status':'RUNNING','scope':'bounded stdlib read-only evidence/source audit; no numerical rerun',
             'bounds':{'wall_seconds':15,'cpu_hard_seconds':8,'address_space_bytes':268435456,'new_receipt_bytes':1048576}}
    try:
        assert sha(IMPL/'frozen_manifest.json')==MANIFEST_HASH
        manifest=read_json(IMPL/'frozen_manifest.json')
        assert manifest['intended_output']==str(OUTPUT)
        for row in manifest['files']+manifest['readonly_external_files']:
            path=Path(row['path']);path=path if path.is_absolute() else ROOT/path
            assert sha(path)==row['sha256'],str(path)
            if 'bytes' in row:
                assert path.stat().st_size==row['bytes'],str(path)
        for row in manifest['prior_attempts']:
            assert sha(Path(row['guard_receipt_path']))==row['sha256']
        for key in ('serializer_check','helper_check'):
            assert sha(Path(manifest[key]['result_path']))==manifest[key]['sha256']
        for name,digest in PINS.items():
            assert sha(OUTPUT/name)==digest,name
        result=read_json(OUTPUT/'result.json');guard=read_json(OUTPUT/'guard_receipt.json')
        verified=read_json(OUTPUT/'verified_inputs.json');claim=read_json(IMPL/'ATTEMPT_CLAIM.json')
        protocol=read_json(ROOT/'research/reconstructed/author_trimkv_cpu_reproduction_prep_20261005/PHASE_A_PROTOCOL.json')
        assert guard['manifest_sha256']==verified['manifest_sha256']==claim['manifest_sha256']==MANIFEST_HASH
        assert guard['output']==verified['intended_output']==claim['output']==str(OUTPUT)
        assert guard['limits']==manifest['resource_maxima']==protocol['resource_maxima']
        assert set(verified['files'])=={row['path'] for row in manifest['files']}
        for row in manifest['files']:
            assert verified['files'][row['path']]['sha256']==row['sha256']
        groups={'A1_source_oracle','A2_boundaries','A3_age_and_membership','A4_call_boundaries',
                'A5_gate_and_positions','A6_closed_loop_cpu','A7_bounded_attention','A8_fail_closed_abi'}
        assert result['status']=='PASS' and len(result['groups'])==8 and set(result['groups'])==groups
        assert len(result['negative_controls'])==59 and all(value is True for value in result['negative_controls'].values())
        assert len(result['continuous_errors'])==272 and result['records']==1621
        assert 'error' not in result and 'trace_close_error' not in result
        assert guard['status']=='CHILD_COMPLETED_WITHIN_OBSERVED_LIMITS' and guard['stop_reason'] is None
        assert guard['child_returncode']==0 and guard['attempts_launched']==1
        assert guard['cleanup']['all_absent'] is True and not guard['cleanup']['remaining']
        assert guard['terminal_owned_scratch']['checked'] is True and guard['terminal_owned_scratch']['empty'] is True
        assert not list((OUTPUT/'scratch').iterdir())
        assert result['native_import_scratch']['owned_scratch']==str(OUTPUT/'scratch')
        assert result['native_import_scratch']['import_phase'] is False
        assert result['native_import_scratch']['generated_verified_before_import'] is True
        assert any(e['operation']=='scratch_writes_sealed' and e['writable_scratch_fds']==0 for e in result['native_import_scratch']['events'])
        assert (OUTPUT/'child_stdout.log').stat().st_size==(OUTPUT/'child_stderr.log').stat().st_size==0

        assert sha(IMPL/'evidence_codec.py')==CODEC_HASH
        sys.path.insert(0,str(IMPL))
        from evidence_codec import Reader,EXPECTED_EVENTS
        reader=Reader(OUTPUT/'trace.tkv3')
        negatives={};errors=[];source=None;schedules=[]
        for event in reader.records(require_complete=True,reconstruct=False):
            kind=event['event']
            if kind=='negative_control':
                assert event['name'] not in negatives and event['detected'] is True
                negatives[event['name']]=event['detected']
            elif kind=='continuous_error':
                record={k:v for k,v in event.items() if k!='event'}
                expected=(2e-6,2e-5) if record['dtype']=='torch.float32' else (0.03125,0.02)
                assert record['dtype'] in {'torch.float32','torch.bfloat16'}
                assert (record['atol'],record['rtol'])==expected
                assert all(math.isfinite(record[k]) for k in ('max','rms','max_relative'))
                errors.append(record)
            elif kind=='source_receipt':
                assert source is None;source=event
            elif kind=='tiny_schedule':
                assert event['calls']==[64,3]+[1]*65 and event['seed']==20261005 and event['parameters']<100000
                schedules.append(event['dtype'])
        assert reader.event_counts==EXPECTED_EVENTS and reader.events==1621
        assert reader.footer['inventory_complete'] is True and reader.footer['serialization_failed'] is False
        assert reader.partial_error is None and reader.bytes_read==(OUTPUT/'trace.tkv3').stat().st_size
        assert negatives==result['negative_controls'] and errors==result['continuous_errors']
        assert source['receipt']==read_json(IMPL/'EXTRACTION_RECEIPT.json')
        assert source['runtime']=={'torch':'2.9.1+cpu','transformers':'5.19.0.dev0','intraop':1,'interop':1}
        assert sorted(schedules)==['torch.bfloat16','torch.float32']
        assert all(d['finite'] is True for d in reader.tensors)
        error_summary={}
        for dtype in ('torch.float32','torch.bfloat16'):
            rows=[e for e in errors if e['dtype']==dtype]
            error_summary[dtype]={'count':len(rows),'maximum_absolute_error':max(e['max'] for e in rows),
                                  'maximum_reported_rms_error':max(e['rms'] for e in rows),
                                  'maximum_reported_relative_error':max(e['max_relative'] for e in rows)}

        samples=[]
        with (OUTPUT/'resource_samples.jsonl').open() as stream:
            for line in stream:
                row=json.loads(line)
                assert row['combined_guard_and_tree_rss_bytes']<=1073741824
                assert row['host_available_after_unwritten_tmpfs_reserve_bytes']>=1500000000
                assert row['disk_free_bytes']>=5000000000 and row['source_filesystem_disk_free_bytes']>=5000000000
                assert row['observed_cumulative_aggregate_cpu_seconds']<=100
                assert row['evidence_storage']['total_accounted_bytes']<=32000000
                assert len(row['processes'])<=1
                assert all(p['pid']==guard['cleanup']['pgid'] and p['pgrp']==guard['cleanup']['pgid'] for p in row['processes'])
                samples.append(row)
        assert len(samples)==guard['sample_count']==261
        assert max(r['combined_guard_and_tree_rss_bytes'] for r in samples)==guard['peak_sampled_guard_plus_tree_rss_bytes']
        assert guard['guard_wall_seconds']<=120 and guard['guard_cpu_seconds']<=5 and guard['child_wait4_cpu_seconds']<=90
        assert guard['cumulative_aggregate_cpu_seconds_final']<=100
        assert guard['start_host_available_bytes']>=3032000000
        assert guard['child_wait4_maxrss_bytes']+guard['guard_wait4_self_maxrss_bytes']<=1073741824
        files=[]
        for path in sorted(OUTPUT.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                files.append({'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'allocated_bytes':path.stat().st_blocks*512})
        output_logical=sum(r['bytes'] for r in files)+(IMPL/'ATTEMPT_CLAIM.json').stat().st_size
        assert output_logical<=32000000
        prior_review=ROOT/'research/reconstructed/author_trimkv_phase_a_preexecution_review_v4_20261005/PRIOR_ARTIFACT_PINS.json'
        old_artifacts=read_json(prior_review)
        for row in old_artifacts:
            assert sha(Path(row['path']))==row['sha256'],row['path']
        assert not any(name.split('.')[0] in {'torch','transformers','numpy','trimkv'} for name in sys.modules)
        for name,digest in PINS.items():
            assert sha(OUTPUT/name)==digest
        receipt.update(status='PASS_RESTRICTED_PHASE_A_TERMINAL_AUDIT',manifest_sha256=MANIFEST_HASH,
                       source_pins_verified=len(manifest['files']),readonly_stdlib_pins_verified=len(manifest['readonly_external_files']),
                       same_run_output_binding=True,groups=result['groups'],negative_controls_verified=59,
                       continuous_errors_verified=272,error_summary=error_summary,
                       trace={'bytes':reader.bytes_read,'sha256':PINS['trace.tkv3'],'events':reader.events,
                              'event_counts':reader.event_counts,'tensors':len(reader.tensors),'chunks':len(reader.chunks),
                              'frames':reader.frames_read,'inventory_complete':True,'all_array_hashes_and_finite_flags_verified':True},
                       resources={'guard_wall_seconds':guard['guard_wall_seconds'],'own_cpu_seconds':guard['aggregate_cpu_seconds_final'],
                                  'conservative_cumulative_cpu_seconds':guard['cumulative_aggregate_cpu_seconds_final'],
                                  'peak_sampled_guard_plus_child_rss_bytes':guard['peak_sampled_guard_plus_tree_rss_bytes'],
                                  'summed_guard_child_os_hwm_upper_bound_bytes':guard['child_wait4_maxrss_bytes']+guard['guard_wait4_self_maxrss_bytes'],
                                  'samples_verified':len(samples),'maximum_sample_gap_seconds':guard['maximum_observed_sample_gap_seconds'],
                                  'final_logical_output_including_claim_bytes':output_logical},
                       cleanup={'owned_processes_absent':True,'terminal_scratch_checked_empty':True,'live_scratch_empty':True},
                       previous_artifacts_preserved=len(old_artifacts),output_files=files,
                       numerical_reruns=0,numerical_library_imports=0,
                       limitation='Synthetic restricted author-method/current-ABI CPU port only; no trained4B, full author loader, FA2, real long-prefill admission or PhaseB grant')
    except BaseException as exc:
        receipt.update(status='AUDIT_FAILED',error=type(exc).__name__+': '+str(exc))
        raise
    finally:
        usage=resource.getrusage(resource.RUSAGE_SELF)
        receipt['audit_resources']={'wall_seconds':time.monotonic()-started,'total_process_cpu_seconds':usage.ru_utime+usage.ru_stime,
                                    'os_maxrss_bytes':usage.ru_maxrss*1024,'separate_from_main_run':True}
        with RECEIPT.open('x') as stream:
            json.dump(receipt,stream,indent=2);stream.write('\n')
        signal.setitimer(signal.ITIMER_REAL,0)
    print(json.dumps({'status':receipt['status'],'trace':receipt['trace'],'audit_resources':receipt['audit_resources']}))


if __name__=='__main__':
    main()
