# Independent pre-execution review: static TRIM-KV Phase A

Date: 2026-10-05 UTC

## Verdict

**PASS FOR RESTRICTED STATIC READINESS. No remaining blocking source defect was found in the frozen Phase A path. This review authorizes no execution and establishes no numerical result.**

Reviewed implementation: `research/reconstructed/author_trimkv_phase_a_implementation_20261005`.

Frozen manifest SHA256: `fda89abdd8c147ffd6f50e03d5e880995fe7dffd178bc3c64d9109fa286fd8f8`.

Governing Phase A protocol SHA256: `1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f`.

Intended output: `/tmp/trimkv_phase_a_author_parity_20261005_attempt1`.

The implementation owner explicitly froze this candidate before the final review. All 41 manifest files were independently rehashed and size-checked. All 10 implementation/snapshot Python files were parsed with an external standard-library-only AST check. Full author class spans were independently re-extracted from the original source and compared byte-for-byte with the archived spans. The guard's literal resource dictionary equals both the governing protocol and manifest. The attempt claim and intended output were absent when inspected; those observations must be repeated at admission.

The only reviewer operations were source/document reads, hashes, standard-library parsing and creation of this separate review packet. No prepared module, numerical runtime, model or tokenizer was imported. No numerical fixture, tensor operation, target script, guard, test, trained checkpoint, installation, network, GPU or provider action was performed. Preparation-time syntax validation is not a test run.

## Provenance and reference independence

- Author commit: `49d2a2951ba12e6431a3986b418ee791b209d7c2`
- Complete original cache file: `bb3013d5ff53a8264218b48bafa513c608ad3919d2c6d4172fb248a8b656cae5`
- Complete `TrimKVCache` class, original lines 55–276: `6815beaef692ed88bb3deacd6b30f73c503d4f0e849b7e7db4f3e3d63b4e8015`, 11,084 bytes
- Complete original model file: `9fdec3ee6e28177e6805715df41663d30f6662cb600cbee6f401a6c51dc7486c`
- Complete `RetentionGate` class, original lines 134–173: `71ba60d206b37279c3c0f8bce6558fcef70160d420b67f7b400d7ff928160ed6`, 1,802 bytes

`source_reference.py` verifies protocol, originals, full snapshots, exact spans, extraction coordinates and method lists. Its numerical loader rechecks the compiled span bytes and binds actual Torch, current DynamicCache, nn, functional, typing and ACT2FN dependencies. It does not import the author package or unused Triton/training modules. The unsupported lookahead helper raises rather than substituting numerical behavior.

The reference's cache update/compress and gate methods are unchanged author bodies. The adapter owns independent cache lists and its own append/selection/gather code. The scalar oracle separately rounds scalar products to binary32, ranks by Python comparisons and gathers nested lists; it refuses cutoff ties rather than inventing a tie-break policy. The strict reference wrapper rejects inherited/legacy generation and batching helpers. Raw author classes are used only in the explicitly visible narrow fixtures, including deliberate wrong-policy controls.

The manual tiny reference is source-semantics integration using current CPU Qwen3 primitives. It is not an executed original Transformers 4.57.1 model loader. The adapter path genuinely invokes current Qwen3DecoderLayer and Qwen3Attention, rather than comparing two copies of its manual forward. The gate-free Full control uses native decoders and DynamicCache. These distinctions are correctly documented.

## Cache and model semantics

The final source preserves the required static route: fixed budget, lookahead1, buffer32, sliding protection0, batch1, eval, explicit original int64 positions, rg gate and fixed default RoPE.

In `author_static_adapter.py`, the original contiguous call interval is fixed before appends. Only layer0 advances the shared total-seen count. Each layer appends paired K/V/gates/IDs in order. Attention receives retained old rows plus every current row under a per-head absolute-position causal mask. Per-layer compact mask coordinates are separate from absolute RoPE and score IDs.

The only normal compression hook runs after every layer and final RMSNorm, before the head. It checks `R >= M+32`, evaluates FP32 stored-gate scores using `N+1-p`, applies native per-head topk, sorts physical indices, and gathers K, V, gates and IDs together. Cached rotated keys are never rebased or rerotated. No sink/recent protection or history-only freeze is introduced. Oversized original calls remain whole; no tile-level compression exists.

The normalized-hidden hook sits on each actual native input RMSNorm. Its output feeds the gate, then native attention's ordinary two-value update uses the supplied metadata. The reference independently invokes the exact source gate on the same input-normalized hidden state. Native Q/K head norms and default RoPE precede append. Lower-layer outputs feed the actual next native decoder and its gate, so the path is closed-loop. The original cache's padding mask remains None; current-HF 4D causal masks are not mistakenly passed into its unrelated padding-mask field.

The tiny model is two layers, hidden32, four query/two KV heads, head dimension8, MLP64, vocabulary97 and gate intermediate16. Its parameter cap is checked, and its reference schedule is history64, complete question3, then 65 single-token decode calls. The separate full-shaped gate uses synthetic 2560→512→8 weights and two tokens only. No trained payload loader is present on the executed path.

## Fixture and acceptance review

All eight frozen groups have source-level implementations and failure assertions. Their empirical success remains unestablished until a separately admitted run.

- **A1/A2:** Both FP32 and BF16 compare author, adapter and separated scalar selection/gather fixtures. Budgets8 and32 cover M+31 then M+32. Q40 plus32 single-token calls asserts two global events, each sweeping both layers. Q96 tests one oversized call. Bytewise cache comparisons occur before and after pruning
- **A3:** The fixed age fixture distinguishes the selected older row from newest-row retention under N+1-p versus N-p. An actual author cache with a deliberately incorrect shared clock must choose different IDs. An actual buffer128 author cache differs from buffer32. Head differences, absolute-ID gaps, paired gathers and ascending order are checked. Exact and near-score ties compare the same pinned backend's native topk membership
- **A4:** The complete history/question/decode schedule is preserved. Actual extra history boundaries and history-only compression freeze must differ. Correct current attention is compared against an explicitly early-pruned current-attention control, including a newest row that is visible before its eviction
- **A5:** Full-shaped exact source/adapter gate equality, raw-hidden discrimination and K/V-shaped wrong-input rejection are included. Fixed default RoPE is used before append, and retained-length rebasing is an actual wrong-path control
- **A6:** Exact author/adapter cache, gate, layer-output and logit comparisons are made on closed-loop native layers in each dtype. Full/native versus gate-loaded no-crop is checked. A stale all-dense upper-layer gate-input control must differ
- **A7:** Current eager attention is compared with query-tiled current eager attention at Q1 and Q11, with GQA, per-head past-position holes and explicit original query positions. All tiles share unchanged K/V; the tiled function cannot prune. Wrong top-left masks and alternating rather than contiguous GQA mapping must differ. Last-token-only head output is compared with the final row of full logits
- **A8:** The current mask signature, absent global default-RoPE registry constructor, actual model-local default constructor, source five-value versus adapter two-value update, and native decoder Tensor return are checked. A partially updated two-layer cache explicitly has lengths40 and0, so always-reading-layer0 cannot satisfy the API assertion. Route rejection and actual model-entrypoint rejection cover training, dropout and changed RoPE; missing metadata, premature compression and legacy author APIs also fail closed

The final exact comparator checks contiguous byte views as well as shape, dtype and finite values. Thus signed-zero or other bit-level differences are not silently accepted as identical primitives. Reordered attention/head checks retain the original prospective tolerances: FP32 atol2e-6/rtol2e-5, BF16 atol0.03125/rtol0.02. Norm tolerances never excuse changed cache IDs or event branches. Error records contain maximum, RMS and relative errors. Cutoff margins accompany baseline prunes; unintended scalar-cutoff ties fail immediately. Every declared negative verdict is required to be true; no fixture-search loop, tolerance adjustment or automatic retry is present.

The scalar and random-model fixtures have not been numerically evaluated during this review. In particular, positive margins and BF16 negative discrimination must still be established by the admitted attempt. A non-discriminating fixture is a failure, not grounds to weaken the gate.

## Resource guard review

Reviewed guard SHA256: `20536ff47cb1f1f8579cea1c5ba930b77f623cda781f892651709b5cca453a84`.

The stdlib guard checks the caller-supplied manifest hash, all pinned files, source/protocol identities, existing runtime interpreter and exact intended output. It requires a fresh absent output and creates an exclusive persistent attempt claim. It never removes the claim or earlier evidence. Any repair/retest requires new independent review and separate authorization.

The resource constants are unchanged: one attempt;120s guarded wall;90s child hard CPU;5s guard hard CPU;100s aggregate CPU;1GiB sampled guard-plus-child-tree RSS;25ms target sampling;3GB start and1.5GB continuing host availability;5GB disk floor;32MB new evidence; one intra-op and inter-op thread; no GPU, network, installs, trained-checkpoint reads or paid calls.

The inherited hard-CPU-limit problem is explicitly handled. Preflight temporarily permits a90s inherited hard limit with a4s soft-stop. The child establishes its own90s limit in preexec, enters a new session and installs parent-death SIGKILL. Its numerical imports remain blocked on a pipe. The parent lowers its own cumulative hard limit to5s before releasing that pipe. The SIGXCPU handler also lowers the parent hard cap if the preflight soft stop is reached. A child cannot receive an accidentally inherited5s hard limit and then attempt to raise it.

Process accounting uses PID/start-time identities, per-process CPU, sampled RSS/PSS/anonymous/file/shmem memory, observed VmHWM and direct-child wait4 CPU/high-water RSS. The guard counts its own RSS too, rejects unexpected descendants and checks final CPU/wall/high-water results. Cleanup signals only the newly created owned process group, rejects PID identity collisions, and performs a bounded fresh /proc absence check. Missing or unsuccessful cleanup evidence is failure. No name-based or global process kill is used.

Network/process-creation/payload/file-mutation restrictions are a reviewed child audit hook plus the frozen code and offline/single-thread environment, not a claimed OS sandbox. The hook precedes numerical imports. Existing CPU runtime imports may still encounter an unsupported dependency or forbidden scratch write; that must stop the one attempt rather than trigger an install or workaround.

### Output and tmpfs admission

The output filesystem must have at least5,032,000,000 free bytes at launch, retaining5GB after the entire32MB logical evidence allowance. The implementation/claim filesystem separately needs5GB+4KB and keeps its5GB continuing floor. The intended /tmp placement therefore addresses the full evidence reservation, not permission to exhaust or delete source-filesystem data. Earlier live observations are not substituted for fresh admission values.

Longest-prefix mountinfo lookup establishes filesystem backing. Tmpfs output adds the full32MB to the3GB host-memory start requirement. Samples record both logical and allocated evidence bytes. Actual MemAvailable already reflects materialized tmpfs pages; ongoing admission subtracts only the remaining unwritten allowance before applying the1.5GB floor, avoiding double charging.

Evidence is cooperatively limited before writes to24MB compressed child trace,2MB child result and6MB total guard output, including the claim and a256KB terminal reserve. The child audit whitelist permits only its two bounded evidence files. All guard payloads, including logs, samples, receipts and the terminal summary, pass through its charge-before-write budget. This prevents the aggregate overshoot that a per-file RLIMIT_FSIZE and periodic size scan alone would allow. It is not a kernel filesystem quota. Output, source disk and actual host headroom remain monitored without silently reducing the frozen limits.

RSS/host/disk sampling can miss short peaks; this is explicitly disclosed, with actual sampling gaps and OS high-water evidence required. The guard cannot guarantee a terminal receipt after hard SIGKILL or host failure. Such an outcome is a failed/censored attempt and cannot become a semantic pass.

## Evidence and scope caveats

The compressed trace records baseline fixture arrays, ordered IDs, source dtypes/finite flags, gates, FP32 scores, cutoff margins, event boundaries, visibility, outputs, numerical error metrics, and negative verdicts. Storage ledgers distinguish logical tensor bytes, unique backing storage, and old/new gather coexistence. Named operation timings and modeled byte estimates include gate matrices/intermediates. These byte figures are explicitly overlapping modeled tensor touches/working sets, not measured memory-bus traffic, and must not be summed as exclusive costs or used for throughput claims.

Runtime pins include selected HF/Torch source, package/version metadata and interpreter bytes. They do not constitute a complete transitive shared-library/OS supply-chain attestation. CPU eager/query-tiled parity cannot establish FlashAttention2 parity. The implementation does not certify inherited HF generation, a full native author loader, trained gate behavior, 4B quality, long-prefill fit, performance, novelty or Phase B readiness.

## Required parent decision and stopping rule

Before any launch, the parent must independently establish authorization, verify this exact manifest remains unchanged, recheck the absent claim/output and live disk/tmpfs/memory admission, and use the exact existing-runtime command in `INTENDED_LAUNCH.txt`. No numerical module import or auxiliary smoke run is covered by this review.

After the single attempt, require all three: successful launcher exit, semantic `result.json` PASS with all required groups/negative verdicts, and a successful guard receipt proving resource acceptance and owned cleanup. Review trace completeness and observed sample gaps. On the first semantic failure, unsupported dependency, resource stop, missing receipt or cleanup uncertainty, keep partials and stop. No fix/retry, looser tolerance, changed output, alternate filesystem or lowered floor is implicitly authorized.

## Review artifacts

- `STATIC_CHECKS.json`: independent hash, size, AST, span and literal-limit results
- `REVIEWED_MANIFEST.json`: exact reviewed manifest bytes
- `REVIEWED_SOURCE_PINS.tsv`: all41 verified file identities
- `VERDICT.json`: machine-readable scope, pins, caveats and admission conditions
- `SHA256SUMS`: this separate review packet's hashes

Pre-freeze feedback resulted in stronger actual wrong-policy controls, real integration-entry rejection, unequal-layer ABI discrimination, explicit cost-byte definitions, tmpfs admission and pre-write aggregate output partitions. The verdict above applies only to the final frozen candidate, not to any moving preliminary draft.
