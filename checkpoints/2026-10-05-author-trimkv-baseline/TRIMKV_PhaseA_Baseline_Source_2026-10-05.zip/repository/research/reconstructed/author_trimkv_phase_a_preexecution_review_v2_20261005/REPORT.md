# Independent additive pre-execution review: Phase A v2 scratch compatibility

2026-10-05 UTC. **PASS FOR RESTRICTED STATIC READINESS. No remaining blocking source issue was found in this frozen v2 candidate. This report authorizes no execution and establishes no numerical pass.**

Implementation: `research/reconstructed/author_trimkv_phase_a_implementation_v2_20261005`

Manifest SHA256: `d9eb3cff4ccc48f9a4d212710b80de192dd7dd24add99940f7708907043ff10e`

Guard SHA256: `cd2c31ffa64a90de216ae41458b8ac4d7498f1e71e71dd1fab8d246e76eae236`

Scratch policy SHA256: `e5eeb7f6758ecc0e62835dec9dc6082048d9399d34b9e52735477412538e683e`

Intended new output: `/tmp/trimkv_phase_a_author_parity_20261005_attempt2`

This is a separate additive review. The v1 review, frozen v1 source, persistent attempt1 claim and all failed-attempt artifacts remain intact. The original v1 static review did not establish import or numerical success; its later authorized attempt supplies the compatibility evidence below. V1 remains a failed attempt, not a retrospective pass.

## Independently verified failure and required native operations

The saved v1 `result.json` is FAIL, with a native Qwen3/Transformers import traceback ending in `tempfile._get_default_tempdir`. The two-file-only audit whitelist rejected the directory usability probe. The failure occurred before `Trace(...)`, author-class loading, tiny-model construction or the eight semantic fixture groups. Torch runtime initialization had begun; this is not a claim that no numerical package was imported in attempt1.

The saved guard receipt is STOPPED_OR_FAILED with child exit1 and owned process cleanup `all_absent=true`. Its recorded wall time is3.662628660997143s, aggregate CPU3.611057s and sampled guard-plus-tree RSS269,008,896 bytes. The slightly later guard and child CPU fields support the conservative3.611184s carried into v2's cumulative CPU gate.

Failure evidence pins:

- result.json: `acbb16858388cb45b03779411dddb417f5e59306aa3e1a79ffa90b8e732906db`
- guard_receipt.json: `b706d98d04936cfd632dc28e154f49910a3d80ba006db21f58e8b50cc008adb0`
- v1 attempt claim: `d283031c2cad781ad67f2a1bbe46ca59fcdcad588da6ad5da1c53720c75f891a`

Independent source inspection confirms the precise compatibility requirement:

1. Installed Python3.12 `tempfile._get_default_tempdir` exclusively opens a randomized eight-character direct child of TMPDIR, writes literal `b'blat'`, closes it and unlinks it
2. Installed Torch `distributed/nn/jit/instantiator.py` creates a `TemporaryDirectory` at module import. Native `mkdtemp` creates a mode0700 `tmp<eight characters>` directory
3. Installed `distributed/nn/api/remote_module.py` immediately calls `instantiate_non_scriptable_remote_module_template`. The instantiator writes `_remote_module_non_scriptable.py` in its owned directory and imports that generated source
4. Installed tempfile/shutil later clean up only that directory and file. Python3.12's fd-safe rmtree uses basename-relative `os.unlink(..., dir_fd=...)`; the real directory FD must be resolved and checked rather than interpreting the basename relative to repository cwd

The reviewer independently extracted only AST string literals and formatting arguments from the installed template/instantiator source, reconstructed the expected text and compared it with the frozen snapshot. It is2,355 bytes with SHA256 `8205b16956fb264841ecd8644784a0d157f87df79b17c16825dc1163433ce5d8`. The generated module was parsed, not executed or imported. Its CUDA/RPC-related functions are definitions; these native import operations do not call them, and no GPU/network use is admitted.

## Narrow scratch admission

`scratch_policy.py` permits the native operations above without modifying installed tempfile, shutil, Torch, Transformers or numerical methods.

- The guard creates a fresh mode0700 scratch root inside the new output and binds TMPDIR, TEMP, TMP and PHASE_A_SCRATCH to it
- The policy verifies the source hashes and exact snapshots for installed tempfile, shutil, instantiator, remote_module and template before numerical imports
- It allows one randomized fresh exclusive probe, one correctly named native directory and one exactly named generated source file, only from the corresponding pinned source call sites. Fallback writes to /tmp, /var/tmp, cwd, cache directories or arbitrary scratch descendants remain denied
- Each of the two lifetime file creations is reserved at65,536 bytes before creation; the native directory reserves4,096 more. A1MB scratch partition exceeds this bounded reservation. Deleting a probe does not replenish or reopen its one-file admission
- During import the process soft RLIMIT_FSIZE is lowered to65,536 bytes. Its inherited hard limit is unchanged. Unexpected resource-limit mutations are denied
- The probe's four bytes are checked before its own unlink. Generated source bytes are checked exactly before their import read. Neither renaming/linking nor arbitrary deletion/permission mutation is permitted
- Before fixtures begin, the policy verifies the expected remaining file/directory, checks there are no writable scratch descriptors, seals scratch writes and only then restores the original soft file-size limit. Later unknown scratch writes still fail
- Native cleanup permits only the already tracked created objects. Relative cleanup verifies the directory FD's resolved path, type, device and inode. Existing source files, old output, evidence files and unrelated temporary data cannot be deleted through this allowlist

The guard adds a fresh terminal scratch scan after child exit and owned-process cleanup. A successful launcher now requires the scratch root to be empty. This catches unraisable atexit cleanup errors even if the child exits zero. Leftover entries are described and preserved; the guard does not remove them to manufacture a pass. The child result explicitly says its scratch snapshot precedes atexit, so that earlier snapshot is not substituted for terminal evidence.

This remains a cooperative, source-reviewed audit policy, not an OS security sandbox. Static review cannot guarantee that every later runtime import will need only these operations. Any additional dependency/write behavior must fail closed and stop the separately authorized attempt, without broader write permission or automatic retry.

## Numerical semantics and v1 preservation

The final v2 owner explicitly froze the candidate before this review completed. Independent checks verified all74 repository manifest entries, both exact read-only external stdlib pins and the prior guard receipt. All41 original v1 manifest pins were also rechecked unchanged. Every v2 Python source/snapshot was AST-parsed without importing it.

The adapter, scalar oracle, source reference and complete exact author cache/gate spans are byte-identical to v1. The complete numerical fixture/result-computation region of the test runner is byte-identical, SHA256 `f420d731d179dc1f6e26bd9f365e29cc892be1e21620258a76615fe42661e3d4`. Independently normalizing only the new scratch imports, sealing call and result scratch receipt makes the entire `main` AST identical to v1. The trace module changes only its compressed-file partition from24MB to23MB.

Thus the original eight groups, fixed arrays, call schedules, negative controls, exact branches, bitwise comparisons, FP32/BF16 tolerances, numerical threading and stopping conditions are unchanged. The v1 detailed source-semantics review remains applicable to those unchanged bytes. This compatibility fix does not loosen a failed numerical comparison, select a new fixture or introduce trained payloads.

## Unchanged total resource envelope

Protocol SHA256 remains `1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f`. The guard and manifest resource dictionaries independently compare equal to it: one separately admitted attempt;120s wall;90s child hard CPU;5s guard hard CPU;100s aggregate CPU;1GiB sampled guard-plus-tree RSS;25ms sample target; one numerical thread;3GB starting and1.5GB continuing host headroom;5GB disk floor;32MB output; no GPU/network/install/trained payload/paid action.

V2 additionally charges the frozen attempt1's conservative3.611184s CPU against the same cumulative100s ceiling. It preserves the parent/child hard-limit inheritance barrier, isolated child group, parent-death handling, high-water/CPU accounting and owned-process cleanup proof from v1.

The explicit new output allocation is23MB compressed trace +2MB result +1MB owned import scratch +6MB total guard output =32MB. This is a visible repartition of the existing total, not an added allowance or unreported lowered global limit. The scratch file cap and lifetime creation counts bound even a probe too short-lived for a sample. Guard accounting now includes logical/allocated scratch bytes and directory blocks, and checks per-partition and total ceilings. Pre-write child and guard evidence limits remain in place; no kernel filesystem quota is claimed.

Admission still requires5,032,000,000 output-filesystem free bytes and a separate5GB+4KB source/claim floor. For tmpfs output, the3GB host start floor adds the full32MB reserve. Ongoing host headroom reserves the still-unallocated output allowance while actual MemAvailable already reflects allocated tmpfs pages. No prior files are deleted, moved or recompressed to obtain admission. Live values must be rechecked at launch; historical observations are insufficient.

RSS, disk, host and allocated-space observations remain sampled. Actual gaps/high-water values and terminal accounting must be inspected; no short-peak or hard-host-failure guarantee is inferred. Guard failure or missing cleanup evidence cannot become a pass.

## Required parent gate

This review covers only frozen manifest `d9eb3cff4ccc48f9a4d212710b80de192dd7dd24add99940f7708907043ff10e`. The v2 claim and intended output were absent at review; recheck them and all live resource floors. V1 authorization does not authorize v2. Only the parent can admit the new guarded command after establishing separate authorization.

Require launcher exit0, semantic result PASS with all eight groups and every declared negative detected, a successful resource/owned-process cleanup receipt, and terminal scratch `checked=true`, `empty=true`. Also verify the child's import scratch receipt confirms sealing, restored soft limit and no writable scratch FDs. Any first import, semantic, resource, scratch-cleanup or process-cleanup failure stops the attempt and preserves partials. No additional run, tolerance change, runtime patch, installation or broadened scratch permission follows automatically.

No v2 target module, test, numerical runtime, model, tensor or generated source was executed by this review. No trained payload, network, GPU or provider action occurred. The outcome is source readiness for separate admission, not author-program reproduction, FA2 parity, trained4B quality, long-prefill fit, performance, novelty or Phase B readiness.

## Additive evidence

`STATIC_CHECKS.json` records independent pins, v1 preservation, main-AST equality, numerical-region identity, generated-source reconstruction and protocol/partition checks. `REVIEWED_MANIFEST.json` retains exact v2 manifest bytes. `V1_FAILURE_EVIDENCE_PINS.json` records all saved attempt1 regular-file hashes plus its claim. `VERDICT.json` records the scoped verdict and conditions; `SHA256SUMS` pins this separate review packet. No v1 review artifact was overwritten.
