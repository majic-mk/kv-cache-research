#!/usr/bin/env python3
"""Separately approved tiny CPU layout/byte test; no Transformers or models."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import struct
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
OUTPUT=Path('/tmp/trimkv_phase_a_bitwise_check_20261005')
LIMITS={'attempts':1,'wall_seconds':15,'process_cpu_hard_seconds':8,
        'maximum_observed_rss_bytes':536870912,'file_size_hard_bytes':65536,
        'max_files':8,'maximum_output_bytes':524288,'intraop_threads':1,'interop_threads':1}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-bitwise-check-approved',action='store_true',required=True)
    parser.add_argument('--manifest-sha256',required=True)
    args=parser.parse_args()
    raw=(HERE/'BITWISE_CHECK_MANIFEST.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=args.manifest_sha256:
        raise SystemExit('Helper check manifest differs from separate approval')
    manifest=json.loads(raw)
    for row in manifest['files']:
        path=HERE/row['name']
        if path.parent!=HERE or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise SystemExit('Helper source pin mismatch')
    if manifest['resource_limits']!=LIMITS or os.path.lexists(OUTPUT):
        raise SystemExit('Helper resource contract changed or output already exists')
    for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        os.environ[key]='1'
    os.environ.update(CUDA_VISIBLE_DEVICES='',HIP_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1')
    OUTPUT.mkdir(mode=0o700)
    started=time.monotonic()
    resource.setrlimit(resource.RLIMIT_CPU,(7,8));resource.setrlimit(resource.RLIMIT_FSIZE,(65536,65536))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    def timeout(*_):raise TimeoutError('Helper-only time/CPU bound')
    signal.signal(signal.SIGALRM,timeout);signal.signal(signal.SIGXCPU,timeout);signal.setitimer(signal.ITIMER_REAL,15)
    sys.dont_write_bytecode=True
    admitted=set()
    def audit(event,values):
        if event=='import' and str(values[0]).split('.')[0] in {'transformers','trimkv'}:
            raise PermissionError('Helper check cannot import models or author package')
        if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp'}:
            raise PermissionError('Helper check forbids network/subprocesses')
        if event=='open' and isinstance(values[0],(str,bytes)):
            path=Path(os.fsdecode(values[0])).resolve();mode=values[1] or '';flags=values[2]
            writing=any(c in str(mode) for c in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing:
                if path.parent!=OUTPUT or path.is_symlink():raise PermissionError('Only owned helper evidence writes')
                if path not in admitted:
                    if path.exists() or len(admitted)>=8:raise PermissionError('Helper file count/exclusive creation bound')
                    admitted.add(path)
            elif path.suffix.lower() in {'.safetensors','.pt','.pth','.ckpt','.bin','.gguf'}:
                raise PermissionError('No tensor/model payload reads')
        if event in {'os.remove','os.rmdir','os.rename','os.link','os.symlink','os.mkdir'}:
            raise PermissionError('Helper check preserves all prior/new evidence')
    sys.addaudithook(audit)
    result={'status':'RUNNING','scope':'Torch CPU tensor layout and bitwise helper only; no Transformers, models or payloads',
            'manifest_sha256':args.manifest_sha256,'resource_limits':LIMITS,'checks':[],'cases':[]}
    trace=None;peak=0
    def rss_check():
        nonlocal peak
        hwm=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;peak=max(peak,hwm)
        if peak>LIMITS['maximum_observed_rss_bytes']:raise MemoryError('Helper OS high-water RSS limit exceeded')
    try:
        import torch
        if torch.__version__!='2.9.1+cpu':raise RuntimeError('Unpinned Torch runtime')
        torch.set_num_threads(1);torch.set_num_interop_threads(1)
        result['torch_version']=torch.__version__
        result['intraop_threads']=torch.get_num_threads();result['interop_threads']=torch.get_num_interop_threads();rss_check()
        from bitwise_bytes import canonical_element_bytes
        from trace_schema import Trace
        from evidence_codec import Reader
        trace=Trace(OUTPUT)
        serializer_expected={};old_failures=0
        def copied_bytes(tensor):
            canonical=canonical_element_bytes(tensor)
            assert canonical.dtype==torch.uint8 and canonical.ndim==1 and canonical.stride()==(1,) and canonical.storage_offset()==0
            assert canonical.numel()==tensor.numel()*tensor.element_size()
            if tensor.numel():assert canonical.data_ptr()!=tensor.data_ptr()
            return ctypes.string_at(canonical.data_ptr(),canonical.numel()) if canonical.numel() else b''
        def case(name,source,expected,finite=True):
            actual=copied_bytes(source);assert actual==expected,name
            if expected:
                altered=bytearray(expected);altered[0]^=1
                assert actual!=bytes(altered),name+' altered-bit rejection'
                altered_storage=torch.tensor(list(altered),dtype=torch.uint8).view(source.dtype).reshape(source.shape)
                assert not torch.equal(canonical_element_bytes(source),canonical_element_bytes(altered_storage))
            if finite:
                trace.emit('helper_array',name=name,array=source)
                serializer_expected[name]=expected
            else:
                rejected=False
                try:trace.pack(source)
                except AssertionError:rejected=True
                assert rejected,'nonfinite serializer contract must remain enforced'
            result['cases'].append({'name':name,'dtype':str(source.dtype),'shape':list(source.shape),
                                    'strides':list(source.stride()),'storage_offset':source.storage_offset(),
                                    'raw_hex':expected.hex(),'byte_sha256':hashlib.sha256(expected).hexdigest(),
                                    'finite':finite,'fresh_canonical_owner':True,'altered_bit_rejected':bool(expected)})
            rss_check()
        with torch.inference_mode():
            for dtype,width,integer_dtype,fmt,words in [
                (torch.float32,32,torch.int32,'I',[0,0x80000000,0x3f800000,0xbf800000,1,0x7f7fffff,0x7f800000,0xff800000,0x7fc12345,0x7f812345,0x40000000,0xc0000000,0x00800000,0x80800000,0x3f000000,0xbf000000]),
                (torch.bfloat16,16,torch.int16,'H',[0,0x8000,0x3f80,0xbf80,1,0x7f7f,0x7f80,0xff80,0x7fc1,0x7f81,0x4000,0xc000,0x0080,0x8080,0x3f00,0xbf00])]:
                signed=[w if w<(1<<(width-1)) else w-(1<<width) for w in words]
                base=torch.tensor(signed,dtype=integer_dtype).view(dtype)
                matrix=base.reshape(4,4)
                pack=lambda indices:struct.pack('<'+fmt*len(indices),*(words[i] for i in indices))
                singleton=base[:2].reshape(1,1,2).transpose(1,2)
                assert singleton.shape==(1,2,1) and singleton.stride(-1)==2 and singleton.is_contiguous()
                rejected=False
                try:singleton.contiguous().view(torch.uint8)
                except RuntimeError:rejected=True
                assert rejected;old_failures+=1
                case(str(dtype)+'/singleton_stride2',singleton,pack([0,1]))
                case(str(dtype)+'/transpose_special',matrix.transpose(0,1),pack([r*4+c for c in range(4) for r in range(4)]),finite=False)
                case(str(dtype)+'/strided_slice_special',matrix[:,::2],pack([r*4+c for r in range(4) for c in (0,2)]),finite=False)
                case(str(dtype)+'/offset_special',base[3:9],pack(list(range(3,9))),finite=False)
                case(str(dtype)+'/scalar_signed_zero',base[1],pack([1]))
                case(str(dtype)+'/empty',base[2:2],b'')
                case(str(dtype)+'/singleton_offset_stride2',base.as_strided((1,),(2,),3),pack([3]))
                # Independently specified finite words exercise serializer extraction
                # through transpose, strided slices and nonzero offsets as well.
                finite_words=[words[i] for i in (0,1,2,3,4,5,10,11,12,13,14,15,2,3,0,1)]
                finite_signed=[w if w<(1<<(width-1)) else w-(1<<width) for w in finite_words]
                finite_base=torch.tensor(finite_signed,dtype=integer_dtype).view(dtype);finite_matrix=finite_base.reshape(4,4)
                fp=lambda indices:struct.pack('<'+fmt*len(indices),*(finite_words[i] for i in indices))
                case(str(dtype)+'/finite_transpose',finite_matrix.transpose(0,1),fp([r*4+c for c in range(4) for r in range(4)]))
                case(str(dtype)+'/finite_slice',finite_matrix[:,::2],fp([r*4+c for r in range(4) for c in (0,2)]))
                case(str(dtype)+'/finite_offset',finite_base[3:9],fp(list(range(3,9))))
            integers=[-9223372036854775808,-1,0,9223372036854775807]
            integer=torch.tensor(integers,dtype=torch.int64).reshape(2,2)
            case('int64/transpose',integer.transpose(0,1),struct.pack('<4q',*(integers[i] for i in (0,2,1,3))))
            case('int64/empty',integer[:0],b'')
            boolean=torch.tensor([[False,True],[True,False]],dtype=torch.bool)
            case('bool/transpose',boolean.transpose(0,1),bytes((0,1,1,0)))
            case('bool/empty',boolean[:0],b'')
            lazy=torch._neg_view(torch.tensor([1.0],dtype=torch.float32));rejected=False
            try:canonical_element_bytes(lazy)
            except ValueError:rejected=True
            assert rejected
            result['checks'].append('lazy_negative_view_rejected')
        trace.close();trace=None
        reader=Reader(OUTPUT/'trace.tkv3')
        checked=0
        for event in reader.records(require_complete=False,reconstruct=True):
            array=event['array'];assert array.raw==serializer_expected[event['name']]
            checked+=1
        assert checked==len(serializer_expected) and reader.footer['inventory_complete'] is False
        result['checks'].extend(['original_singleton_bug_reproduced_in_both_dtypes','same_dtype_fresh_1d_storage_stride1',
                                'independent_expected_bits_all_layouts','finite_signed_zero_and_special_payload_bits',
                                'every_nonempty_case_rejects_altered_bit','serializer_seam_matches_expected_bits',
                                'nonfinite_serializer_rejection_unchanged','scalar_and_empty_layouts','int64_and_bool'])
        result.update(status='PASS',cases_checked=len(result['cases']),serializer_cases_checked=checked,
                      original_helper_failures_observed=old_failures,limitations=['No model/cache/gate fixture or Transformers import',
                      'RSS ceiling checked using OS high-water marks after import and each tiny case; not a kernel-hard RSS cap'])
    except BaseException as exc:
        result.update(status='FAIL',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
    finally:
        if trace is not None:
            try:trace.close()
            except BaseException as exc:result['trace_close_error']=str(exc)
        usage=resource.getrusage(resource.RUSAGE_SELF)
        result.update(wall_seconds=time.monotonic()-started,total_process_cpu_seconds=usage.ru_utime+usage.ru_stime,
                      os_maxrss_bytes=usage.ru_maxrss*1024,no_subprocess=True,pid=os.getpid(),
                      logical_output_before_receipt=sum(p.stat().st_size for p in OUTPUT.iterdir() if p.is_file()))
        payload=(json.dumps(result,indent=2)+'\n').encode()
        if len(payload)>65536:raise RuntimeError('Helper receipt too large')
        (OUTPUT/'result.json').write_bytes(payload);signal.setitimer(signal.ITIMER_REAL,0)
    print(json.dumps({'status':result['status'],'output':str(OUTPUT),'cpu':result['total_process_cpu_seconds']}))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
