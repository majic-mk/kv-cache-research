# Phase A v4: canonical logical-byte comparison

Status: v4 main suite NOT RUN. The separately approved24-case native helper check passed; final v4 source review and separate single-run authorization are still required. All earlier failed attempts and their claims/evidence remain untouched.

## Narrow correction

V3 stopped at its first Q1 closed-loop gate comparison. PyTorch regards size-one dimensions as contiguous regardless of their strides, while reinterpretation with view(torch.uint8) separately requires last stride1. Thus .contiguous() did not change a legal singleton last stride2, and the test helper raised before comparing values. This was a test-infrastructure error, not a reported baseline mismatch or a completed parity result.

bitwise_bytes.py now allocates a fresh one-dimensional CPU owner with the input's unchanged dtype, copies into a shape-view of that owner, asserts owner stride1/offset0, and byte-views only the one-dimensional owner. The same canonical storage seam supplies serializer raw bytes. No dtype conversion or floating-point arithmetic occurs in this helper. Logical order and every bit are preserved, including signed zero. Unsupported non-CPU/non-strided/dtype and lazy negative/conjugate inputs reject explicitly.

The full author_static_adapter.py, source_reference.py, scalar_oracle.py, evidence_codec.py and scratch_policy.py are byte-identical to v3. test_author_semantics.py changes only an import and the failing byte-comparison expression. Existing shape/dtype/finite checks, exact-byte requirement, fixture arrays, seeds, schedules, case IDs, negative controls, tolerances, cache/gate calculations and resource maxima are unchanged. LAYOUT_CHANGE_PROOF.json verifies that exact source diff. LAYOUT_PROVENANCE.json pins the installed contiguity implementation and dtype-view documentation.

## Native helper check already passed

Approved manifest: bdb599f17928446146186321729435af1ec6a5e851c99d220f08becbdc9973b6

Preserved output: /tmp/trimkv_phase_a_bitwise_check_20261005

Result SHA256: 8c4b9a5d43bc4ad99e8802be36a2b57012d600f768b97adec9489e81abc1af47

The single approved check exited0. All24 FP32/BF16/int64/bool layouts matched independently constructed literal storage-index bytes: singleton stride2, true transposes/strided slices, nonzero offsets, scalars and empty tensors. It reproduced the original singleton exception in FP32 and BF16, preserved signed zeros and special payload bits, rejected altered bits and lazy-negative views, and reconstructed18 finite cases through the actual serializer seam. Nonfinite serializer rejection remains unchanged. No Transformers, models, cache/gate fixture or checkpoint payload was used.

Observed CPU1.097837s, wall1.064411s, OS maxRSS226,304,000B, threads1/1;2 files/22,880B. Limits:15s wall,8s process CPU hard,512MiB OS high-water checks after import/each tiny case,8 files×64KiB. RSS checking was not a kernel-hard memory cap. This helper success does not establish complete Phase A parity.

## Evidence and prior attempts

The lossless v3 codec and its previously passed28-case stdlib check remain unchanged. The same1,621-event inventory,5,648 tensor fields and187,842 row references apply. The independent compression-free full-suite bound remains21,350,347B under the unchanged23MB trace partition. Canonical copying changes neither serialized logical bytes nor their shapes/counts. See pinned v3 bounds and decoder source; no arrays/events are omitted or rounded.

Attempt3's valid partial trace is preserved at /tmp/trimkv_phase_a_author_parity_20261005_attempt3/trace.tkv3, SHA2564e8d09f4d76a4e1b1ea406b3462f12abc5d3e44d507fec00733e3d3f9763fbe7. Its406 complete events/693 tensor descriptors/6,172 chunks were losslessly verified; complete inventory is false. Trace size3,136,951B. Result SHA37700324288141271cc60659e4d17ed759971a30443b9b2d2f7d85faff6c5bec; guard SHAdc9916c4c3149363a58be01985488c2dd61d6be4147328e2b21fea86cc32af38. Owned processes were absent and scratch checked empty. The earlier import and JSON-volume failures likewise remain failed, preserved attempts.

## Resource accounting and intended output

Fresh intended output: /tmp/trimkv_phase_a_author_parity_20261005_attempt4

Unchanged main limits:120s wall,90s child CPU hard,5s guard CPU hard,100s cumulative CPU gate,1GiB sampled guard+tree RSS,25ms sampling target, one intra/inter-op thread,3GB host start plus tmpfs reserve/1.5GB continuing floor,5GB disk floor, and32MB total evidence partitions23/2/1/6 MB. No limits or numerical tolerances were raised. Resource admission is rechecked at launch.

Three failed main attempts conservatively used18.592565 CPU seconds. Observed codec/helper checks add0.078223+1.097837; read-only partial-trace verification reported0.983120, yielding20.751745 tracked measured seconds. For admission, v4 instead charges full auxiliary allowances:5s codec,8s helper,2s post-v3 verification, giving33.592565 prior seconds against the unchanged100s cumulative gate. The2s verification allowance is a conservative accounting reserve, not an observed kernel limit. Measured and reserved values are separately disclosed and pinned.

A v4 main pass requires the exact reviewed manifest/output, semantic PASS for all eight groups and59 negative controls, exhaustive same-run lossless decoding of all1,621 events, resource acceptance, checked-empty owned scratch and proof all owned process identities are absent. A codec/helper PASS alone is insufficient. First main failure stops without mutation or automatic retry. No full author loader, trained4B, tokenizer, FA2, quality, speed, long-history fit or novelty claim is authorized. Phase B remains excluded.

## Parent checklist

1. Verify final independent v4 report and exact manifest hash
2. Separately authorize the one main command in INTENDED_LAUNCH.txt; helper approvals do not authorize it
3. Recheck fresh attempt4 output/claim, all previous receipts/source pins and live memory/disk/CPU admission
4. Run only that unchanged guarded command
5. Bind semantic, full trace, guard/resource and cleanup receipts to this exact attempt before any restricted static-parity conclusion
