"""Canonical same-dtype logical bytes for exact comparisons and evidence.

The source may be contiguous while a singleton last-axis stride is not1. Always
allocate a fresh one-dimensional owner; never dtype-view the source layout.
"""
import torch

SUPPORTED=(torch.float32,torch.bfloat16,torch.int64,torch.bool)


def canonical_element_bytes(tensor):
    if not isinstance(tensor,torch.Tensor) or tensor.device.type!='cpu' or tensor.layout!=torch.strided:
        raise ValueError('Only strided CPU tensors are supported')
    if tensor.dtype not in SUPPORTED:
        raise ValueError('Unsupported source dtype for exact element bytes')
    if tensor.is_conj() or tensor.is_neg():
        raise ValueError('Lazy conjugate/negative views are outside this checked route')
    owned=torch.empty((tensor.numel(),),dtype=tensor.dtype,device='cpu')
    # Copy values without casting or arithmetic, into the canonical owner's
    # shape-view. TensorIterator preserves the source's logical element order.
    owned.view(tensor.shape).copy_(tensor.detach())
    if owned.ndim!=1 or owned.stride()!=(1,) or owned.storage_offset()!=0:
        raise RuntimeError('New one-dimensional storage was not canonical')
    return owned.view(torch.uint8)
