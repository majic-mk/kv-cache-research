#!/usr/bin/env python3
"""One guarded synthetic attempt. Never import this module to inspect its source."""
import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
import time
import traceback


def admit():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--guard-token', required=True)
    args = parser.parse_args()
    token = os.environ.pop('PHASE_A_GUARD_TOKEN', '')
    if not token or args.guard_token != token:
        raise SystemExit('Only the separately authorized one-run guard may launch this worker')
    output = Path(args.output).resolve(strict=True)
    start_fd_text = os.environ.pop('PHASE_A_START_FD', '')
    if not start_fd_text.isdigit():
        raise SystemExit('Missing parent CPU-limit start barrier')
    start_fd = int(start_fd_text)
    try:
        if os.read(start_fd, 1) != b'G':
            raise SystemExit('Parent did not release the numerical start barrier')
    finally:
        os.close(start_fd)
    sys.dont_write_bytecode = True
    from scratch_policy import install_policy
    install_policy(output)
    return output


def main():
    output = admit()
    started = time.perf_counter()
    result = {'status': 'RUNNING', 'scope': 'synthetic CPU only; no FA2 or trained-model claim'}
    trace = None
    try:
        # All numerical/model imports occur only after token admission.
        import torch
        import transformers
        if torch.__version__ != '2.9.1+cpu' or transformers.__version__ != '5.19.0.dev0':
            raise RuntimeError('Runtime version mismatch')
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        torch.manual_seed(20261005)
        torch.use_deterministic_algorithms(True)
        from trace_schema import Trace, tensor_bytes, attention_logical_bytes
        from source_reference import verify_sources, load_author_classes, make_author_cache, UnsupportedAuthorPath
        from scalar_oracle import scalar_keep, scalar_gather
        from author_static_adapter import (StaticCacheAdapter, TinyPort, validate_route,
                                            absolute_causal_mask, gate_forward, tiled_attention)
        from transformers.cache_utils import DynamicCache
        from transformers.models.qwen3.modeling_qwen3 import eager_attention_forward
        from scratch_policy import seal_scratch
        seal_scratch()
        trace = Trace(output)
        trace.emit('source_receipt', receipt=verify_sources(), runtime={'torch': torch.__version__, 'transformers': transformers.__version__,
                    'intraop': torch.get_num_threads(), 'interop': torch.get_num_interop_threads()})
        AuthorCache, AuthorGate = load_author_classes()
        from bitwise_bytes import canonical_element_bytes
        cache_attrs = ('key_cache', 'value_cache', 'retention_weights', 'kv_positions')
        groups = []
        errors = []

        def exact(a, b, label):
            with trace.timed('check', tensor_bytes(a)+tensor_bytes(b)):
                if a.shape != b.shape or a.dtype != b.dtype or not torch.equal(canonical_element_bytes(a), canonical_element_bytes(b)):
                    raise AssertionError('Exact mismatch: ' + label)
                if not torch.isfinite(a).all() or not torch.isfinite(b).all():
                    raise AssertionError('Nonfinite: ' + label)

        def close(a, b, label):
            with trace.timed('check', tensor_bytes(a)+tensor_bytes(b)):
                if a.shape != b.shape or a.dtype != b.dtype or not torch.isfinite(a).all() or not torch.isfinite(b).all():
                    raise AssertionError('Shape/dtype/finite mismatch: ' + label)
                atol, rtol = (2e-6, 2e-5) if a.dtype == torch.float32 else (0.03125, 0.02)
                diff = a.float() - b.float()
                record = {'label': label, 'dtype': str(a.dtype), 'max': diff.abs().max().item(),
                          'rms': diff.square().mean().sqrt().item(),
                          'max_relative': (diff.abs() / b.float().abs().clamp_min(1e-12)).max().item(),
                          'atol': atol, 'rtol': rtol}
                errors.append(record)
                trace.emit('continuous_error', **record)
                if not torch.allclose(a, b, atol=atol, rtol=rtol):
                    raise AssertionError('Continuous tolerance failed: ' + label)

        def same_cache(ref, adapter, label):
            if ref._seen_tokens != adapter.seen_tokens:
                raise AssertionError('Global seen clock mismatch')
            for name in cache_attrs:
                if len(getattr(ref, name)) != len(getattr(adapter, name)):
                    raise AssertionError('Cache layer count mismatch')
                for layer, (a, b) in enumerate(zip(getattr(ref, name), getattr(adapter, name))):
                    exact(a, b, label + '/' + name + '/' + str(layer))

        def inputs(start, qlen, layer, dtype, style='regular'):
            p = torch.arange(start, start+qlen, dtype=torch.int64)
            h = torch.arange(8, dtype=torch.float32)[None, :, None]
            ids = p[None, None, :].float()
            dims = torch.arange(128, dtype=torch.float32)[None, None, None, :]
            key = (ids[..., None] + h[..., None] / 16 + dims / 1024 + layer / 8).to(dtype)
            value = (-key.float() - 0.25).to(dtype)
            # A deterministic head/layer-specific, well-separated score construction.
            ranks = 1 + ((ids * 7 + h * 11 + layer * 3) % 251)
            gates = (-ranks / (257-ids)).to(dtype)
            if style == 'age':
                gates.fill_(-10)
                for j, pos in enumerate(p.tolist()):
                    if pos < 7:
                        gates[..., j] = -0.0001
                    if pos == 7:
                        gates[..., j] = -0.1
                    if pos == 39:
                        gates[..., j] = -1.8
            return key, value, gates, p

        def cache_run(schedule, dtype, budget=8, style='regular', scalar=True, tag='cache'):
            ref = AuthorCache(memory_size=budget, buffer_size=32, device='cpu')
            adapter = StaticCacheAdapter(memory_size=budget, trace=trace)
            seen = 0
            events = []
            for call, qlen in enumerate(schedule):
                positions = torch.arange(seen, seen+qlen, dtype=torch.int64)
                adapter.begin_call(positions)
                for layer in range(2):
                    k, v, gates, p = inputs(seen, qlen, layer, dtype, style)
                    returned = ref.update(k.clone(), v.clone(), layer, {'cache_position': p, 'retention_weights': gates.clone(), 'attention_mask': None})
                    if len(returned) != 5:
                        raise AssertionError('Author update arity changed')
                    adapter.set_metadata(layer, gates.clone(), p)
                    native = adapter.update(k.clone(), v.clone(), layer)
                    if len(native) != 2:
                        raise AssertionError('Current adapter update arity changed')
                    exact(returned[0], native[0], 'appended K')
                    exact(returned[1], native[1], 'appended V')
                seen += qlen
                same_cache(ref, adapter, 'before prune')
                before = [[getattr(ref, a)[l].clone() for a in cache_attrs] for l in range(2)]
                trace.emit('cache_before', tag=tag, dtype=str(dtype), call=call, seen=seen, arrays=before)
                expected = []
                for layer in range(2):
                    k, v, gates, pos = before[layer]
                    if k.shape[-2] >= budget + 32:
                        score = gates.float() * (seen + 1 - pos)
                        native_indices = score.topk(budget, dim=-1).indices.sort(dim=-1).values
                        ranked = score.sort(dim=-1, descending=True).values
                        margin = ranked[..., budget-1] - ranked[..., budget]
                        if scalar:
                            # Scalar oracle admits only separated cutoffs; exact/near ties use native below.
                            oracle = scalar_keep(gates[0].tolist(), pos[0].tolist(), seen, budget)
                            indices = torch.tensor(oracle['indices'], dtype=torch.int64)[None]
                            exact(indices, native_indices, 'scalar native keep')
                            expected.append(scalar_gather(k[0].tolist(), v[0].tolist(), gates[0].tolist(), pos[0].tolist(), oracle['indices']))
                            trace.emit('scalar_scores', tag=tag, call=call, layer=layer, oracle=oracle)
                        else:
                            expected.append(None)
                        trace.emit('native_topk', tag=tag, call=call, layer=layer, scores=score, margins=margin, indices=native_indices)
                    else:
                        expected.append(None)
                ref.compress()
                adapter.mark_final_normalized()
                event = adapter.finish_call()
                events.append(event)
                same_cache(ref, adapter, 'after prune')
                for layer, oracle in enumerate(expected):
                    if oracle is not None:
                        # Oracle uses pure nested-list gather, independent of Tensor.gather.
                        for name, key in zip(cache_attrs, ('keys', 'values', 'gates', 'positions')):
                            actual = getattr(ref, name)[layer][0].tolist()
                            if actual != oracle[key]:
                                raise AssertionError('Scalar paired gather mismatch: ' + name)
                trace.emit('cache_after', tag=tag, call=call, seen=seen,
                           arrays=[[getattr(ref, a)[l] for a in cache_attrs] for l in range(2)])
            return ref, adapter, events

        with torch.inference_mode():
            # A1/A2: source methods, independent scalar oracle, threshold and cadence.
            for dtype in (torch.float32, torch.bfloat16):
                for budget in (8, 32):
                    _, _, events = cache_run([budget+31, 1], dtype, budget, tag='threshold')
                    if events[0]['layers'][0]['pruned'] or not events[1]['layers'][0]['pruned']:
                        raise AssertionError('M+31/M+32 threshold mismatch')
                ref, adapter, events = cache_run([40] + [1]*32, dtype, tag='two_events')
                if adapter.prune_count != 4:
                    raise AssertionError('Expected exactly two global events, two layers each')
                cache_run([96], dtype, tag='oversized_one_call')
            groups.extend(['A1_source_oracle', 'A2_boundaries'])

            # A3: a mathematically separated fixture distinguishes newest age 2 from 1.
            for dtype in (torch.float32, torch.bfloat16):
                ref, _, _ = cache_run([40], dtype, style='age', tag='age_discriminator')
                k, v, gates, pos = inputs(0, 40, 0, dtype, 'age')
                good = scalar_keep(gates[0].tolist(), pos[None, :].expand(8,-1).tolist(), 40, 8)
                wrong = scalar_keep(gates[0].tolist(), pos[None, :].expand(8,-1).tolist(), 40, 8, age_shift=0)
                trace.negative('wrong_age_' + str(dtype), good['indices'] != wrong['indices'])
                trace.negative('protected_recent_' + str(dtype), 39 not in ref.kv_positions[0][0,0].tolist() and 7 in ref.kv_positions[0][0,0].tolist())
                # Execute an actual wrong-clock source transition, rather than
                # merely showing that its score formula differs.
                wrong_clock = AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                for layer in range(2):
                    wk,wv,wg,wp=inputs(0,40,layer,dtype,'age')
                    wrong_clock.update(wk,wv,layer,{'cache_position':wp,'retention_weights':wg,'attention_mask':None})
                wrong_clock._seen_tokens = 39  # Deliberately one call-token behind.
                wrong_clock.compress()
                trace.negative('wrong_global_clock_'+str(dtype),
                               not torch.equal(ref.kv_positions[1],wrong_clock.kv_positions[1]),
                               correct_ids=ref.kv_positions[1],wrong_ids=wrong_clock.kv_positions[1])
                # Deliberately prune before the current attention. The newest row
                # is visible in the correct pre-prune attention even when evicted.
                from types import SimpleNamespace
                attn=SimpleNamespace(num_key_value_groups=1,scaling=128**-0.5,training=False)
                query=torch.zeros(1,8,1,128,dtype=dtype)
                full_output,_=eager_attention_forward(attn,query,k,v,None,scaling=attn.scaling,dropout=0.0)
                early_output,_=eager_attention_forward(attn,query,ref.key_cache[0],ref.value_cache[0],None,scaling=attn.scaling,dropout=0.0)
                trace.negative('early_prune_current_attention_'+str(dtype),not torch.equal(full_output,early_output),
                               pre_prune_output=full_output,early_pruned_output=early_output,newest_visible_before=True)
            ref, adapter, _ = cache_run([40, 32], torch.float32, tag='gapped_head_membership')
            positions = ref.kv_positions[0][0]
            if torch.equal(positions[0], positions[1]) or not bool(((positions[:,1:] - positions[:,:-1]) > 1).any()):
                raise AssertionError('Head differences/absolute gaps fixture missing')
            buffer128 = AuthorCache(memory_size=8, buffer_size=128, device='cpu')
            for layer in range(2):
                k,v,g,p=inputs(0,72,layer,torch.float32)
                buffer128.update(k,v,layer,{'cache_position':p,'retention_weights':g,'attention_mask':None})
            buffer128.compress()
            trace.negative('buffer128', adapter.prune_count > 0 and buffer128.get_cache_length(0)==72
                           and not torch.equal(ref.kv_positions[0],buffer128.kv_positions[0]))
            # Native tie membership is checked exactly, without a stable-ID invention.
            for near in (False, True):
                ref = AuthorCache(memory_size=8, buffer_size=32, device='cpu')
                adapter = StaticCacheAdapter(memory_size=8, trace=trace)
                p = torch.arange(40, dtype=torch.int64)
                adapter.begin_call(p)
                for layer in range(2):
                    k,v,g,_ = inputs(0,40,layer,torch.float32)
                    g = torch.zeros_like(g)  # exact all-score tie
                    if near:
                        g[..., 0] = -torch.finfo(torch.float32).tiny
                    ref.update(k,v,layer,{'cache_position':p,'retention_weights':g,'attention_mask':None})
                    adapter.set_metadata(layer,g,p); adapter.update(k,v,layer)
                ref.compress(); adapter.mark_final_normalized(); adapter.finish_call()
                same_cache(ref,adapter,'same-backend exact/near ties')
            groups.append('A3_age_and_membership')

            # A8 guardrails are exercised before tiny integration to reject unsupported paths.
            from transformers.masking_utils import create_causal_mask
            from transformers.modeling_rope_utils import ROPE_INIT_FUNCTIONS
            sig = inspect.signature(create_causal_mask)
            if 'inputs_embeds' not in sig.parameters or 'input_embeds' in sig.parameters or 'cache_position' in sig.parameters:
                raise AssertionError('Current mask signature drift')
            if 'default' in ROPE_INIT_FUNCTIONS:
                raise AssertionError('Default RoPE registry assumption changed')
            invalid = [('cache_class','DynamicBudgetTrimKVCache'),('cache_class','PagedTrimKVCache'),
                       ('training',True),('dropout',0.1),('batch',2),('padding',True),('packing',True),
                       ('gate','rg10'),('rope','dynamic'),('lookahead_steps',2),('buffer_size',128),
                       ('position_policy','compact'),('schedule','history_only')]
            for key,val in invalid:
                rejected = False
                try: validate_route(**{key:val})
                except ValueError: rejected = True
                trace.negative('reject_' + key + '_' + str(val), rejected)
            bad = StaticCacheAdapter()
            for name, action in [('missing_positions', lambda: bad.begin_call(None)),
                                 ('missing_gates', lambda: bad.update(torch.zeros(1,2,1,8),torch.zeros(1,2,1,8),0)),
                                 ('premature_prune',lambda:bad.finish_call())]:
                rejected=False
                try: action()
                except (ValueError,RuntimeError): rejected=True
                trace.negative(name,rejected)
            raw = AuthorCache(memory_size=8,buffer_size=32,device='cpu')
            for name,action in [('author_integer_mask_abi',lambda:raw.get_mask_sizes(1,0)),
                                ('author_layer_seq_abi',lambda:raw.get_seq_length(layer_idx=0))]:
                rejected=False
                try: action()
                except (TypeError,AttributeError): rejected=True
                trace.negative(name,rejected)
            early = StaticCacheAdapter()
            p=torch.arange(40,dtype=torch.int64)
            early.begin_call(p)
            k,v,g,_=inputs(0,40,0,torch.float32)
            early.set_metadata(0,g,p); early.update(k,v,0)
            rejected=False
            try: early.mark_final_normalized()
            except RuntimeError: rejected=True
            trace.negative('prune_before_upper_layer',rejected)
            if early.get_seq_length(0)!=40 or early.get_seq_length(1)!=0 or early.get_query_offset(1)!=0 or early.get_mask_sizes(3,1)!=(3,0):
                raise AssertionError('Per-layer API must not read only layer zero')
            trace.emit('unequal_layer_api',lengths=[early.get_seq_length(i) for i in range(2)],
                       query_offsets=[early.get_query_offset(i) for i in range(2)],
                       mask_sizes=[early.get_mask_sizes(3,i) for i in range(2)])
            guard_model=TinyPort(AuthorGate).eval()
            for name,mutate,restore in [
                ('actual_training',lambda:guard_model.train(),lambda:guard_model.eval()),
                ('actual_dropout',lambda:setattr(guard_model.layers[0].self_attn,'attention_dropout',0.1),lambda:setattr(guard_model.layers[0].self_attn,'attention_dropout',0.0)),
                ('actual_dynamic_rope',lambda:setattr(guard_model.config,'rope_parameters',{'rope_type':'dynamic','rope_theta':5000000}),lambda:setattr(guard_model.config,'rope_parameters',{'rope_type':'default','rope_theta':5000000}))]:
                mutate(); rejected=False
                try: guard_model.forward_call(torch.zeros(1,1,dtype=torch.int64),StaticCacheAdapter())
                except ValueError: rejected=True
                finally: restore()
                trace.negative(name,rejected)
            del guard_model
            checked_reference=make_author_cache(8)
            for name in ('batch_split','batch_select_indices','copy_to_device','get_mask_sizes','get_query_offset','reorder_cache'):
                rejected=False
                try: getattr(checked_reference,name)
                except UnsupportedAuthorPath: rejected=True
                trace.negative('unsupported_reference_api_'+name,rejected)
            groups.append('A8_fail_closed_abi')

            # A5: source gate body, normalization, shape, and native Q/K/RoPE seam.
            from types import SimpleNamespace
            big_config=SimpleNamespace(hidden_size=2560,retention_gate_intermediate_size=512,
                        num_key_value_heads=8,hidden_act='silu',initializer_range=0.02,retention_gate_bias_init=0.0)
            for dtype in (torch.float32,torch.bfloat16):
                gate=AuthorGate(big_config).to(dtype).eval()
                x=torch.linspace(-3,3,2*2560).reshape(1,2,2560).to(dtype)
                from transformers.models.qwen3.modeling_qwen3 import Qwen3RMSNorm
                z=Qwen3RMSNorm(2560,eps=1e-6).to(dtype)(x)
                exact(gate(z),gate_forward(gate,z),'full-shaped source gate')
                if gate.linear1.weight.shape != (512,2560) or gate.linear2.weight.shape != (8,512) or gate.bias.shape != (8,):
                    raise AssertionError('Full gate shapes')
                trace.emit('full_shape_gate',dtype=str(dtype),input=x,normalized=z,gate=gate(z))
                trace.negative('raw_hidden_gate_'+str(dtype),not torch.equal(gate(x),gate(z)))
                for wrongdim in (1024,128):
                    rejected=False
                    try: gate(torch.zeros(1,2,wrongdim,dtype=dtype))
                    except RuntimeError: rejected=True
                    trace.negative('kv_gate_dimension_'+str(wrongdim)+'_'+str(dtype),rejected)
                del gate,x,z
            groups.append('A5_gate_and_positions')

            # A4/A6: full closed loop history 64, complete question 3, then 65 Q1 calls.
            # The synthetic parameters are amplified to make stale upper-layer gates
            # and wrong boundary/RoPE negatives discriminating in both dtypes.
            for dtype in (torch.float32,torch.bfloat16):
                torch.manual_seed(20261005)
                model=TinyPort(AuthorGate).to(dtype).eval()
                for gate in model.gates:
                    gate.linear1.weight.mul_(8); gate.linear2.weight.mul_(8)
                ref=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                adapter=StaticCacheAdapter(memory_size=8,trace=trace)
                full_ref=AuthorCache(memory_size=None,buffer_size=32,device='cpu')
                no_crop=StaticCacheAdapter(memory_size=None)
                native=DynamicCache(config=model.config)
                stale=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                freeze=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                rebase=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                schedule=[64,3]+[1]*65
                all_ids=(torch.arange(sum(schedule))*17+5).remainder(97)[None,:]
                trace.emit('tiny_schedule',dtype=str(dtype),seed=20261005,
                           calls=schedule,token_ids=all_ids,parameters=sum(p.numel() for p in model.parameters()))
                cursor=0; stale_detected=False; rope_detected=False; freeze_detected=False
                for call,qlen in enumerate(schedule):
                    tokens=all_ids[:,cursor:cursor+qlen]
                    native_logits=model.forward_native_full(tokens,native,torch.arange(cursor,cursor+qlen,dtype=torch.int64))
                    full=model.forward_call(tokens,full_ref,reference=True)
                    nocrop=model.forward_call(tokens,no_crop)
                    exact(full['logits'],nocrop['logits'],'source gate-loaded no-crop')
                    close(native_logits,nocrop['logits'],'native Full vs gate-loaded no-crop')
                    a=model.forward_call(tokens,ref,reference=True,trace=trace)
                    b=model.forward_call(tokens,adapter,trace=trace)
                    same_cache(ref,adapter,'closed-loop cache')
                    exact(a['logits'],b['logits'],'closed-loop logits same primitives')
                    for l in range(2):
                        exact(a['gates'][l],b['gates'][l],'closed-loop layer gate')
                        exact(a['layer_outputs'][l],b['layer_outputs'][l],'closed-loop layer output')
                    close(a['logits'][:,-1:,:],a['last_logits'],'full-head last row vs last-only head')
                    wrong=model.forward_call(tokens,stale,reference=True,stale_gate_inputs=full['normalized_inputs'])
                    wrong_rope=model.forward_call(tokens,rebase,reference=True,rebase_rope=True)
                    if call>0:
                        freeze.do_compress=False
                    wrong_freeze=model.forward_call(tokens,freeze,reference=True)
                    if call>0:
                        stale_detected |= not torch.equal(a['gates'][1],wrong['gates'][1])
                        rope_detected |= not torch.equal(a['logits'],wrong_rope['logits'])
                    freeze_detected |= any(not torch.equal(ref.kv_positions[l],freeze.kv_positions[l]) for l in range(2))
                    cursor += qlen
                trace.negative('stale_all_dense_upper_gate_'+str(dtype),stale_detected)
                trace.negative('retained_length_rope_'+str(dtype),rope_detected)
                trace.negative('history_only_freeze_'+str(dtype),freeze_detected)
                if adapter.prune_count != 6:
                    raise AssertionError('History and two decode global sweeps expected')
                # Split history is a deliberately different policy, never an optimization.
                dense_ref=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                split_ref=AuthorCache(memory_size=8,buffer_size=32,device='cpu')
                dense=model.forward_call(all_ids[:,:64],dense_ref,reference=True)
                model.forward_call(all_ids[:,:40],split_ref,reference=True)
                split=model.forward_call(all_ids[:,40:64],split_ref,reference=True)
                trace.negative('extra_history_boundary_'+str(dtype),
                               not torch.equal(dense_ref.kv_positions[0],split_ref.kv_positions[0])
                               or not torch.equal(dense['logits'][:,-1],split['logits'][:,-1]))
                # Current compact offset API remains per-layer; absolute IDs are separate.
                if adapter.get_query_offset(0)!=adapter.get_seq_length(0) or adapter.get_mask_sizes(1,1)!=(adapter.get_seq_length(1)+1,0):
                    raise AssertionError('Per-layer current mask API')
                del model,ref,adapter,full_ref,no_crop,native,stale,freeze,rebase
            groups.extend(['A4_call_boundaries','A6_closed_loop_cpu'])

            # A7: dense/tiled attention with GQA and old absolute-position holes.
            for dtype in (torch.float32,torch.bfloat16):
                for qlen in (1,11):
                    module=SimpleNamespace(num_key_value_groups=2,scaling=8**-0.5,training=False)
                    old=torch.tensor([[[0,3,9],[1,4,8]]],dtype=torch.int64)
                    positions=torch.arange(10,10+qlen,dtype=torch.int64)
                    mask,visible=absolute_causal_mask(old,positions,4,dtype)
                    query=torch.randn(1,4,qlen,8).to(dtype)
                    key=torch.randn(1,2,3+qlen,8).to(dtype)
                    value=torch.randn_like(key)
                    with trace.timed('attention', attention_logical_bytes(query,key,value,mask,2)):
                        dense,_=eager_attention_forward(module,query,key,value,mask,scaling=module.scaling,dropout=0.0)
                    with trace.timed('attention_tiled', sum(attention_logical_bytes(query[:,:,lo:lo+3],key,value,mask[:,:,lo:lo+3],2) for lo in range(0,qlen,3))):
                        tiled=tiled_attention(module,query,key,value,mask,tile=3)
                    close(dense,tiled,'query tiled '+str(qlen))
                    if not bool(visible[...,0,:3].all()) or not bool(visible[:,:,-1,:].all()):
                        raise AssertionError('Current/old causal visibility')
                    wrong_visible=torch.arange(3+qlen)[None,None,None,:] <= torch.arange(qlen)[None,None,:,None]
                    wrong_mask=torch.zeros_like(mask).masked_fill(~wrong_visible,torch.finfo(dtype).min)
                    wrong,_=eager_attention_forward(module,query,key,value,wrong_mask,scaling=module.scaling,dropout=0.0)
                    trace.negative('top_left_mask_'+str(dtype)+'_'+str(qlen),not torch.equal(dense,wrong))
                    # Wrong alternating KV-head assignment differs from native contiguous repeat.
                    wrong_key=key.repeat(1,2,1,1); wrong_value=value.repeat(1,2,1,1)
                    wrong_module=SimpleNamespace(num_key_value_groups=1,scaling=module.scaling,training=False)
                    wrong_gqa,_=eager_attention_forward(wrong_module,query,wrong_key,wrong_value,mask,scaling=module.scaling,dropout=0.0)
                    trace.negative('wrong_gqa_'+str(dtype)+'_'+str(qlen),not torch.equal(dense,wrong_gqa))
                    trace.emit('attention_arrays',dtype=str(dtype),query=query,key=key,value=value,
                               positions=positions,old_positions=old,visibility=visible,dense=dense,tiled=tiled)
            groups.append('A7_bounded_attention')

        result.update(status='PASS',groups=groups,negative_controls=trace.negative_verdicts,
                      continuous_errors=errors,operation_seconds=trace.times,
                      logical_bytes=trace.logical_bytes,records=trace.records,
                      logical_bytes_definition='Modeled tensor reads/writes or working-set touches, including gate parameters and major intermediates; not measured DRAM traffic. Nested decoder/gate/cache totals overlap and must not be summed as exclusive costs.',
                      wall_seconds=time.perf_counter()-started,
                      limitations=['Sampled RSS is not a hard kernel memory cap',
                                   'Current CPU port only; no FlashAttention2 parity',
                                   'No trained checkpoint, tokenizer, 4B quality or long-prefill-fit claim',
                                   'Native topk ties are pinned-backend only'])
    except BaseException as exc:
        result.update(status='FAIL',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc(),
                      wall_seconds=time.perf_counter()-started)
        raise
    finally:
        if trace is not None:
            try:
                trace.close()
            except BaseException as exc:
                result.update(status='FAIL',trace_close_error=str(exc))
        from scratch_policy import scratch_snapshot
        result['native_import_scratch'] = scratch_snapshot()
        payload=(json.dumps(result,indent=2)+'\n').encode()
        if len(payload)>2000000:
            payload=json.dumps({'status':'FAIL','error':'2MB result evidence partition exceeded'}).encode()
        with (output/'result.json').open('xb') as stream:
            stream.write(payload)


if __name__ == '__main__':
    main()
