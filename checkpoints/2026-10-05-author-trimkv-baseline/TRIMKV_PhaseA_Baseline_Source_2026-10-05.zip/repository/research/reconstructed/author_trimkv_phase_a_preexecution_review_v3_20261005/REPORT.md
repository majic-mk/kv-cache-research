# Independent additive pre-execution review: Phase A v3 lossless evidence

2026-10-05 UTC. **PASS FOR RESTRICTED STATIC READINESS. No remaining blocking source defect was found in the frozen v3 candidate. The complete unchanged suite has a conservative21,350,347-byte trace bound, below its existing23,000,000-byte partition. This review authorizes no main execution and establishes no numerical pass.**

Implementation: `research/reconstructed/author_trimkv_phase_a_implementation_v3_20261005`

Manifest SHA256: `a31b342b699e50d8b215c2c66bc20b84846385cd190a980d1b640f420a5f77ae`

Guard SHA256: `d46ee46dc164ae9e41956b1a9caff87ed0723abf60cfcfc8a2080a025e7f840f`

Codec SHA256: `03ff37ede9adb969eadc11c59ac5ac9e3aa3b96912b8c8656de1feca0f596d69`

Intended output: `/tmp/trimkv_phase_a_author_parity_20261005_attempt3`

The owner explicitly froze this candidate before final review. Independent checks rehashed all118 repository entries, both exact read-only stdlib pins, both prior failed-run receipts and the separately approved codec-check receipt. Every implementation Python file is pinned and was AST-parsed without importing it. The v1 and v2 manifests'41 and74 file pins were independently rechecked unchanged. Their claims and output artifacts remain preserved; this report does not overwrite either earlier review.

## Failure evidence and scope of the fix

Attempt2 failed with `OSError: Compressed trace evidence allowance exhausted` in the existing JSON/gzip serializer, during `cache_before` in the early `two_events` fixture. Its trace stopped at22,767,783 bytes because the next compressed write did not fit the23MB cap. The saved error is an evidence-cap failure, not a reported numerical mismatch. It does not establish that the unexecuted remainder of the suite passed.

The v2 native-import scratch fix worked: the exact2,355-byte generated Torch module was verified, scratch writes were sealed with no writable scratch descriptors, terminal scratch was checked empty, and owned process cleanup proved all identities absent. Attempt2 remains FAIL. Its own guard CPU evidence is conservatively8.890232s; v1's corresponding charge is3.611184s.

V3 changes only the evidence representation and associated filename, verification, provenance and accounting. The full numerical test runner, adapter, source reference and scalar oracle are byte-identical to frozen v2. Both complete exact author class spans are unchanged. The only scratch-policy difference is the allowed trace filename changing from `trace.jsonl.gz` to `trace.tkv3`. No arrays, states, cases, negative controls, call boundaries, gates, score rules, dtype comparisons or tolerances were removed or weakened.

The earlier detailed source-semantics/ABI reviews remain applicable to those unchanged bytes. They still establish source readiness only, not original author-loader execution, trained-gate quality, FA2 parity or a numerical result.

## Lossless wire format and reconstruction review

The new stream stores typed raw rows with content-addressed reuse instead of repeatedly rendering complete cached arrays as decimal JSON. No compression ratio is assumed.

- Eight-byte versioned magic; explicit little-endian representation
- Every frame has a41-byte `<cQ32s>` header containing type, payload length and SHA256 of type plus payload
- C frames store an integer row ID, raw-row SHA256 and exact bytes; fixed C overhead is77 bytes including framing
- T frames store dtype, shape, row width, total bytes, ordered row IDs, raw-array and typed-content hashes, and the finite flag
- E frames preserve each original event dictionary and all its fields, replacing tensor occurrences with typed tensor references
- F commits preceding-stream hash, frame inventories, exact event counts and serialization status. It does not claim semantic or resource acceptance

The writer compares actual bytes or full descriptors before reusing a matching hash. A collision cannot silently alias unequal data. Ordered row IDs retain logical tensor order even when physical cache membership has gaps. Dtype/shape remain explicit, including FP32, BF16, int64 and bool. Ordinary Python scalar/list/dictionary fields remain lossless JSON; no decimal precision is reduced. Signed zero and floating special-bit patterns are retained in raw tensor bytes.

`Trace.pack` checks the live tensor's finite flag, CPU placement, admitted dtype and shape/byte length. It holds a contiguous owned CPU tensor while copying exactly its bounded storage interval with `ctypes.string_at`. The representation is little endian and the process rejects another byte order. No installed numerical function is patched, and no float-text conversion mediates the tensor bytes. This native Tensor-to-byte bridge was inspected statically; the separate codec test did not execute it.

The stdlib reader checks frame lengths/checksums, sequential IDs, chunk bytes/hashes, row counts/lengths, reconstructed raw-array/content hashes, dtype/shape and finite flags. It reconstructs a `TypedArray` containing exact raw bytes and original logical shape. Optional Python value views are secondary to raw bits. The decoder uses no pickle, eval, numerical library or model import.

Completion is anchored to the reader's independently supplied expected inventory, defaulting to the frozen full-suite map. It does not trust a file's self-declared expected count. Truncated or corrupted streams fail normal verification. Explicit prefix mode can recover complete verified E frames but cannot report full completion. Consumers must exhaust verification through the footer; reading an initial event is not complete-file acceptance.

The standalone reconstruction tool is codec-only. An early draft's unbound aggregation of arbitrary result/guard receipts was removed. The parent must separately bind the exact trace, result, guard receipt, output directory and reviewed manifest before accepting a run.

## Complete-suite source bound

An additional independent source-only inventory was performed without generating tensors, importing targets or executing the serializer. Its detailed derivation is pinned at:

`research/reconstructed/author_trimkv_phase_a_trace_bound_review_20261005_1345/FINAL_SOURCE_BOUND.md`

SHA256: `527ddf3b63b4f1ef24f92c4a05fd4653f0f6b03c29c7fa2744f976514f18d6ab`

The adjacent `SOURCE_BOUND_REVIEW.md` supplies every loop, schedule, shape, dtype, event count and variable scalar/list count. Original and snapshot copies of the final bound are included in the v3 pins.

Full successful-suite inventory:

- 1,621 original E records
- 5,648 tensor-field occurrences; no descriptor reuse is needed for this upper bound
- 187,842 ordered last-axis row references
- 67,500,132 raw tensor-occurrence bytes before deduplication
- At most26,944 immutable originating cache K/V row chunks, totaling10,208,768 bytes
- All other tensor rows pessimistically distinct:17,474 chunks and1,866,852 bytes
- Therefore at most44,418 chunks and12,075,620 raw row bytes

The origin-row argument uses only the source-visible fact that cache append, clone, concatenation and gather copy K/V rows without changing their values. It does not depend on equality between separate fixtures, different model routes, numerically close values, favorable random data, stable top-k membership, or compression. All non-cache-K/V rows are charged independently even if the codec happens to reuse them.

Exact conservative wire accounting:

| Component | Bytes |
|---|---:|
| Raw row payload |12,075,620|
| 44,418 C chunks ×77 fixed bytes |3,420,186|
| 5,648 T descriptors ×512 fixed JSON bytes |2,891,776|
| 5,648 T frame headers ×41 |231,568|
| 187,842 row IDs ×6 |1,127,052|
| All E frames, tensor refs, scalars and lists |1,600,000|
| Magic |8|
| Footer payload reserve and header |4,137|
| **TOTAL** |**21,350,347**|

This leaves **1,649,653 bytes** under the unchanged23MB trace allowance.

The fixed JSON bounds were checked against actual field schemas. T fixed metadata is at most282 bytes, safely below512. Row IDs require at most5 decimal digits and tensor IDs at most4. Every ordinary E schema's fixed portion, including its41-byte frame, is at most375 bytes, below its512-byte allocation. The E allowance separately accounts for every tensor reference,11,744 scalar-oracle float entries,2,560 scalar keep indices,42,168 ordered position IDs, nested-list punctuation, schedules and source receipt. Traceback/error strings belong to the separately capped result file, not an unbounded E category.

Maximum source shapes are rank4, dimension2,560, row width10,240 bytes, raw tensor393,216 bytes and at most768 rows per tensor. Their descriptors and row/event frames fit the codec's131,072-byte frame and1MiB tensor admissions. The exact15 event counts sum to1,621 and are unchanged. Every fail-fast prefix is no larger than this complete path. The owner's tighter14,741,864-byte estimate uses more cross-fixture sharing; this review relies on the more conservative21,350,347-byte proof.

The proof establishes byte feasibility, not runtime duration, RSS or numerical parity.

## Separately authorized serializer-only check

The parent conditionally authorized one bounded stdlib-only codec check after its own pinned source review. This reviewer inspected but did not execute it. The approved manifest SHA256 is `715dffdff733c0b808e12d0c76dcc7fdcbfd46209a959e877262fc8b80e12a3b`; the checked codec bytes are identical to final v3.

The saved receipt at `/tmp/trimkv_phase_a_serializer_check_20261005/result.json` has SHA256 `26d39d256baf592e02fbe0ed339d10e1b1e84c4005c815784d788fc136d02cd0` and reports PASS for28 checks. Those cover FP32/BF16 special raw patterns and signed zeros, int64 extremes, bool, empty/scalar shapes, Python-memoryview strided logical order, repeated tensors/shared rows, nested JSON, checksum/length/dtype/finite/reference/order corruption, truncated headers/payload/footer, trailing data, explicit prefix recovery, injected collision-map guards and pre-write cap behavior. The owner reported exit0. Saved resource evidence records0.078223s process CPU and14,417,920-byte OS maximum RSS.

This is byte-codec evidence only. It imported no Torch/Transformers/NumPy, created no model and ran none of the Phase A numerical fixtures. Native Tensor extraction remains source-reviewed until the separately admitted main path exercises it. Prior check files are retained; no second check was run by this reviewer.

## Guard and cumulative resource review

The guard's resource literals and manifest still equal governing protocol SHA256 `1f935fe10da6f6812e1b07278bbf60a4498ec2449efac0b953d10193ac5d221f`. No global ceiling was raised:120s guarded wall,90s child hard CPU,5s guard hard CPU,100s cumulative aggregate CPU,1GiB sampled guard-plus-tree RSS,25ms target samples, one numerical thread,3GB start/1.5GB continuing host headroom,5GB disk floor and32MB total output.

The output partitions remain23MB trace +2MB result +1MB owned scratch +6MB guard. The historical manifest key `child_compressed_trace` now labels the uncompressed typed-row file; it does not imply compression or change its byte cap.

The guard pins both failed-attempt receipts and charges each attempt's own conservative CPU once, avoiding double counting v2's cumulative field. It also pins the serializer check's PASS receipt, exact approved check manifest and unchanged checker/codec source. Because the measured codec receipt precedes its final receipt write/interpreter exit, the guard conservatively charges the entire approved5s CPU cap for that check. The resulting precharge is17.501416s; the measured earlier-work sum12.579639s is reported separately. The unchanged100s gate applies to that precharge plus the new guard/child work.

The v2 scratch admission/seal/owned-only cleanup contract is unchanged except for the trace filename. Parent/child CPU-limit inheritance uses the same start barrier. Process identity accounting, parent-death handling, kernel per-process limits, sample/high-water evidence, output accounting and terminal checked-empty scratch requirement remain in place. One new persistent v3 claim admits at most one separately authorized main run; neither prior claim is removed or reused.

Live output admission still needs5,032,000,000 free bytes, the source/claim filesystem its separate5GB+4KB floor, and tmpfs startup host availability at least3,032,000,000 bytes. Remaining unwritten/unallocated tmpfs allowance is charged against continuing1.5GB headroom. Old outputs, the codec check, source files and receipts cannot be deleted to satisfy admission. Sampled RSS/host/disk limits and cooperative file budgets are not kernel whole-tree memory/filesystem quotas; actual gaps and high-water evidence must be inspected.

## Parent admission and terminal acceptance

Main v3 has not run as of this review. Its claim/output were absent when inspected. Recheck all pins, absent paths, live memory/tmpfs/disk floors and separate authorization. The codec-only approval does not authorize a main Phase A retry.

For the one exact candidate command, require all of the following before any numerical pass statement:

1. Launcher exit0 and semantic `result.json` PASS for all original eight groups and all declared negative controls
2. Guard receipt bound to this manifest and exact output, accepting the unchanged resource envelope and proving owned processes absent
3. Child scratch receipt confirms sealing/restored soft limit/no writable scratch FDs; terminal scratch is checked empty
4. Complete codec verification through the F marker against the frozen1,621-event map, with no serialization failure, corruption or missing payload
5. Result, trace and guard provenance belong to the same admitted run; codec validity alone is insufficient

The first import, numerical, negative-control, resource, serialization or cleanup failure stops the attempt, retaining partials. No automatic retry, runtime patch, new fixture, omitted state, precision reduction, looser tolerance, larger cap or different output is authorized by this review.

Review operations were source/receipt reads, hashing, AST/text parsing and arithmetic on source-declared byte counts. No reviewer or source-bound worker executed a target module, serializer, decoder, numerical fixture, model or tensor operation. No trained payload, installation, network, GPU or provider action occurred. No full-author-program, FA2, trained4B quality, long-prefill fit, throughput, novelty or Phase B claim follows.

## Additive review artifacts

`STATIC_CHECKS.json` contains final pin/AST/core-identity/limit/inventory/bound checks. `REVIEWED_MANIFEST.json` is the exact v3 manifest. `PRIOR_ARTIFACT_PINS.json` records preserved attempt1, attempt2 and codec-check file hashes. `CODEC_CHECK_REVIEW.json` retains the earlier separate codec-only static gate. `VERDICT.json` records this final scoped verdict; `SHA256SUMS` pins the additive packet.
