# Hybrid attention/recurrent-cache source screen

Date: 2026-10-05 UTC  
Decision: **NO-GO for GPU spending or a publication claim.** One narrower causal question remains worth an inexpensive falsification only if numerical work is subsequently authorized. It has not passed a practical-value/novelty gate.

## Scope and verification boundary

This is a source-only comparison of three bottlenecks. No model, tensor, numerical experiment, installation, GPU/provider action, remote write, or public release was performed. Existing Qwen3.5-2B-derived assets were not opened. Public papers, public configs and pinned official/author source were inspected. Publication novelty and SCI acceptance are not guaranteed.

The public-source frontier was checked through this date, including September 2026 work. A paper's reported performance is not a measurement reproduced here. Absence of a located author repository is not evidence that no repository exists.

## Result in one paragraph

Hybrid state really creates coupled dependencies: a reusable boundary needs compatible full-attention KV and recurrent state; a GDN checkpoint includes a convolution history as well as the matrix state; lossy attention output changes the *inputs and coefficients* of later recurrence. However, checkpoint placement/eviction/repair is already addressed directly, not merely by generic checkpointing; idle-state and active-state compression have recent dedicated methods and official serving support; and exploiting the third dependency requires a repair mechanism that beats keeping precision fixed, calibrated FP8, and ordinary full-tail replay. No such mechanism is established by this screen. The recommended outcome is to avoid another adaptation-only project and not spend the CNY100 GPU allowance on these candidates yet.

## 1. Checkpoint/KV coverage and repair cost

**Real bottleneck.** A full-attention cache hit is downward-closed in token position. A recurrent checkpoint is usable only at its own boundary. Losing an attention interval can invalidate a far later recurrent checkpoint for ordinary prefix lookup, despite most cache bytes surviving. This is complementary storage, not independent object value.

**What the code actually does.**

- vLLM, pinned at `51eeb0c58f77f845e6170a71ee894de9f465c0ca`: `HybridKVCacheCoordinator.find_longest_cache_hit` (lines 846–981) repeatedly shrinks the candidate until all groups agree. Lines 898–905 exploit downward closure for full attention. Lines 974–977 detect the lag of sparse-retention groups. It is incorrect to model this as the minimum of arbitrary independent hit counts without checking actual boundary compatibility.
- `MambaManager` at the same pin (lines 1455 onward) explicitly has align-mode positional instability, tracked checkpoint boundaries, and special state-block management. A generic token cache simulator misses these constraints.
- SGLang's current Mamba component has moved into `unified_cache/components/mamba.py`; the previously cited `mamba_radix_cache.py` is absent at the inspected current pin. The component only needs the matched terminal Mamba state but full attention needs the prefix, and copies the matched Mamba state into the active request slot (lines 128–214).
- Sparse Prefix Caching's author implementation, `checkpoint_cache.py`, explicitly restores both convolution and matrix states. `prefill_from_checkpoint` says and implements full-model tail replay: cached attention K/V does not supply the query-dependent attention outputs needed as inputs to downstream layers. It clips a usable recurrent checkpoint to KV coverage. The README distinguishes synthetic timing from actual single-layer-group measurements.

**Closest work and strongest controls.**

1. [Marconi, MLSys 2025](https://proceedings.mlsys.org/paper_files/paper/2025/hash/7c180af017258d239bac6248d1eb26ac-Abstract-Conference.html): hybrid-specific admission/eviction, with the exact-match recurrent-state issue.
2. [Sparse Prefix Caching, 2605.05219v1](https://arxiv.org/html/2605.05219v1): exact sparse checkpoints; balanced and distribution-aware placement; a DP already covers the elementary placement problem. Its [author code](https://github.com/arabel1a/sparse-prefix-caching/tree/d3050d44ed9d878c396cf3fcf632d63743ffed5b) represents conv state and full-model replay requirements.
3. [vLLM RFC #57111, opened September 16](https://github.com/vllm-project/vllm/issues/57111): specifically couples checkpoint-aware eviction with segmented repair of missing FA intervals, reuse of the resident suffix, and a compatible later checkpoint. It also accounts for native scheduling/admission and temporary references. This is a proposal, not a claim that the complete RFC is merged.
4. [SuffixReplay, 2609.33477v1](https://arxiv.org/html/2609.33477v1): sparse group-entry anchors, bounded replay and separately placed anchor sidecars already attack the storage/reconstruction/pipeline coupling without dense checkpoints. It is approximate, so exact-checkpoint results must not be compared without quality control.
5. [HYPIC, 2607.01299v1](https://arxiv.org/html/2607.01299v1) and [LinearKV, 2608.11231v1](https://arxiv.org/html/2608.11231v1) eliminate a supposed open gap in position-independent hybrid reuse; they are not proposed here as a new domain migration.

**Gate.** NO-GO. Better checkpoint spacing, checkpoint-aware eviction, skipping a repaired gap, or a basic joint-memory DP would collide directly with these sources. A useful implementation could still exist, but this screen did not find an uncovered constraint with a defensible payoff over these controls.

## 2. Recurrent-state bytes and repeated quantization

**Real bottleneck.** The matrix state is constant in context but is read/updated/written each decode step and replicated over active requests and cached checkpoints. Its capacity competes with exact-attention KV. Compression of an idle snapshot and compression on every active update are different problems.

**Source-derived size sanity check, not a benchmark.** The public [Qwen3.5-4B config](https://huggingface.co/Qwen/Qwen3.5-4B/raw/main/config.json) specifies 32 layers, every fourth full attention, 32 linear value heads, 128-by-128 per-head states and FP32 SSM storage. Matrix-state storage is therefore 24 × 32 × 128 × 128 × 4 bytes = 48 MiB per request/checkpoint, excluding convolution, metadata and alignment. BF16 full-attention KV is 8 × 2 × 4 × 256 × 2 bytes = 32 KiB/token. These are representation counts, not allocated HBM or speed estimates. At batch one, the recurrent matrix alone is not an enormous fraction of a 5090-class memory budget; checkpoint count or concurrency must make the task consequential.

**Existing mechanisms.**

- [DASC, 2608.30386v1](https://arxiv.org/html/2608.30386v1) already selects long-retention units for checkpoint storage, uses ragged layouts, and offers omitted-unit zero filling or suffix refresh.
- [DAMP, 2608.27513v1](https://arxiv.org/html/2608.27513v1) already uses quantization error and persistence for active-state mixed precision, with a packed fused update path. Its headline state-memory and latency profile is a high-batch serving regime; transferring the headline to one small-model/one-GPU experiment is unjustified.
- [Low-Bit Recurrent States, 2609.30950v1](https://arxiv.org/html/2609.30950v1) already connects state error to readout/observability weighting and rate–distortion allocation, considers write-back frequency, and states that teacher forcing does not eliminate cross-layer noise propagation.
- The pinned official SGLang `mamba_checkpoint_pool.py` implements `--enable-int8-mamba-checkpoint`. It keeps idle radix-owned matrix snapshots in INT8, keeps conv windows at native dtype, then dequantizes once into a native active-state slot on a hit. `MambaComponent` commits compressed checkpoints. Thus “compress idle snapshots, avoid repeated active rounding” is already a real serving implementation, not a proposed contribution.
- [Why Gated DeltaNet Survives 4-Bit Quantization, 2609.04098v1](https://arxiv.org/html/2609.04098v1) is a strong counter-control to generic “recurrence inevitably amplifies error.” It studies projection quantization and calibrated FP8 attention-cache scales; it does **not** establish that arbitrary active-state INT4 is safe.

**Gate.** NO-GO. A precision allocator must beat native idle INT8, DASC/DAMP-style selectors, the newer Gramian baseline, and an equally budgeted joint allocator. Changing the target to Qwen3.5 or 5090 is insufficient. No uncovered mechanism is established.

## 3. Attention-cache restoration leaves downstream recurrent repair debt

This is the most specific remaining *question*, but not a recommended method.

**Exact source dependency.** In the pinned Qwen3.5 reference:
- Attention appends K/V and computes its output at lines 781–808.
- Residual/MLP composition at lines 877–906 becomes the next layer's input.
- GDN projects that input into q/k/v, output gate and the a/b gates (lines 559–565), updates a width-four convolution state, then derives beta and log decay (lines 568–613).
- Lines 618–648 read and write the recurrent matrix. Lines 475–485 implement decay followed by the key-directed delta update.
- The serving implementation also separately stores conv and SSM state in `self.kv_cache[0]` and `self.kv_cache[1]` and commits prefill final state (vLLM GDN source, lines 1300–1308 and 1527–1528).

For one head, using the source's key-by-value orientation:
`S_t = A_t S_(t-1) + B_t`, with
`A_t = alpha_t (I - beta_t k_t k_t^T)` and
`B_t = beta_t k_t v_t^T`.

If an upstream attention cache is lossy, later GDN inputs change, so both A and B change. With identical teacher-forced tokens, an exact identity is:
`Delta S_t = A_t Delta S_(t-1) + Delta A_t S_(t-1) + Delta A_t Delta S_(t-1) + Delta B_t`.

This differs from the fixed-input recurrence `Delta S_t = A_t Delta S_(t-1) + R_t` used to isolate state write-back quantization. Restoring an old exact KV page only changes future reads; it does not automatically undo already-updated conv/state or already-appended upper-layer K/V.

**Possible constrained idea.** Before escalating cache precision or restoring a high-value page, measure whether downstream persistent representations need a short, dependency-aware repair. A method would have to select an affected suffix and layer set, account for conv halos and upper-layer KV, and achieve a quality/cost frontier unavailable to plain precision allocation or plain replay. Mere dirty-bit provenance, scalar error scores, or fixed periodic replay are not enough.

**Why it does not pass now.**
1. The dependency is real, but a standard fixed-precision run avoids a precision-restoration transition entirely.
2. Calibrated FP8 or a stronger static mixed-precision allocation could remove the useful failure regime.
3. Recomputing just the recurrent matrix is not exact: upstream hidden-state inputs and subsequent upper FA K/V may already differ. Exact correction generally follows the causal dependency cone, approaching full-tail replay.
4. Ordinary full-attention models also retain errors in newly written higher-layer KV. A convincing result must isolate the *incremental* recurrent cost, rather than relabel ordinary autoregressive/cache error persistence.
5. The newest Gramian paper already flags the exogenous-input limitation. “Account for cross-layer noise” alone is not a novelty claim.
6. No source demonstrates that a narrow repair wins on trained small hybrids. Source inspection cannot establish frequency, output-quality impact, short repair horizon or runtime advantage.

### Tiny CPU falsifier design, NOT RUN

Purpose: reject an alleged cheap repair mechanism before loading any model. It cannot prove real-model usefulness.

Use plain scalar/list arithmetic for an explicitly specified two-dimensional hybrid chain: FA0 -> GDN1 (including a width-four convolution) -> FA2 -> GDN3. Fixed token embeddings, fixed small projections, normalized keys, sigmoid beta and negative log-decay follow the reference ordering. Keep tokens identical; do not allow sampling to create the effect.

Run reference and perturbed paths, injecting one bounded error into an FA0 historical V read for a short interval. At a declared step restore that FA0 entry exactly. Compare:
A. restore that page only
B. additionally restore conv histories only
C. additionally restore recurrent matrices only
D. additionally restore upper FA K/V only
E. restore all affected persistent objects (positive control)
F. standard full-tail replay from the last clean boundary (exact control)
G. equal-cost contiguous suffix replay
H. a pure-FA depth-matched control and a GDN input-clamped control
I. best static precision/retention allocation on this finite toy, enumerated exhaustively

Record later output difference and literal dependency/operation counts; do not turn Python wall-clock into a GPU-performance claim. Include a case in which the state impulse contracts quickly and an orthogonal-key case in which its readout persists. Vary perturbation sign and location; one adversarial sequence does not establish prevalence.

Pre-registered kill criteria:
- If E and F cannot reproduce the reference to a declared floating-point tolerance, the harness/intervention is wrong: stop.
- If A's residual is wholly explained by upper FA K/V, with no recurrent-specific increment under H, kill the hybrid mechanism.
- If fixed precision, calibrated scaling, or I removes the relevant error under an equal storage allowance, kill the repair proposal.
- If G matches the proposed repair at equal operation/storage budget, kill the extra mechanism.
- If accuracy restoration requires replay of essentially the entire affected suffix/layer cone, the claimed cheap repair is false.
- If the effect exists only under a deliberately switched cache precision with no actual target workflow requiring switching, kill the application case.
- Even if the toy passes, do not buy GPU time yet: it establishes possibility only. A separate authorized small-model CPU intervention and source-implementability gate must establish a non-artificial regime and narrow repair cost.

## Implementation and literature audit limits

Three official source pins were retrieved via GitHub's read-only API and source files were actually read. SGLang's current source is substantially newer than older blog paths. No claim is made that the latest DASC, DAMP, SuffixReplay, LinearKV or HYPIC algorithm was reproduced or found merged upstream; paper algorithm descriptions and real serving baseline code are kept distinct.

The May sparse-prefix author code was inspected and pinned. Its older Transformers monkey patch addresses a prefill initial-state limitation that the current pinned reference no longer has; porting that patch now would not establish an improvement.

## Recommendation to the project

Archive this as a negative source gate. Keep the CNY100 GPU budget unused. If a later task genuinely needs mid-run restoration of exact attention entries after lossy processing, reopen only bottleneck 3 with the stated falsifiers and all strong controls. Otherwise switch to a different substantive research constraint rather than renaming hybrid checkpointing, active/idle compression, or generic joint allocation.

