# Independent complete-suite bound against the v3 binary layout

SOURCE ONLY. Static file reads, SHA-256, AST/text inspection and byte-count arithmetic only. No target imports, numerical runtimes, tensors, models, tests, serializers or decoder runs. No trained payloads, network/provider/GPU actions, installation, implementation edits or deletion. This is an evidence-size review, not numerical acceptance or execution authorization.

## Finding

The complete unchanged frozen numerical suite fits the existing **23,000,000-byte trace partition** under the inspected v3 layout with a conservative, compression-independent upper bound of **21,350,347 bytes**, leaving **1,649,653 bytes** of headroom.

This independent proof deliberately does **not** rely on identical K/V values across separate fixtures, deterministic input-formula deduplication across calls/runs, reference-versus-adapter route equality, descriptor deduplication, favorable random data, or compression. It needs only source-visible immutability of K/V rows after creation and exact-byte row interning. All other tensor rows are charged as unique.

Full event, loop, shape/dtype, tensor occurrence and scalar-list inventory is in the adjacent `SOURCE_BOUND_REVIEW.md`. That preliminary report's conditional layout budget is superseded by this report's inspected-layout calculation.

## Source pins checked

Within `research/reconstructed/author_trimkv_phase_a_implementation_v3_20261005`:

- `test_author_semantics.py`: SHA-256 `314fc0840c02011b4a626f83ff4943b45d41a4d5be057d4ec66d275d4e942d18`; full file byte-identical to reviewed frozen v2
- `author_static_adapter.py`: SHA-256 `a566664113273de992f35d010e13ca2c75ead13479e4dc0afa3619de463b309a`; full file byte-identical to reviewed frozen v2
- `trace_schema.py`: SHA-256 `cf4e9888eeb9d3429a9207ad730af2df6bf84674b92d692806aa788a8e63554a`
- `evidence_codec.py`: SHA-256 `03ff37ede9adb969eadc11c59ac5ac9e3aa3b96912b8c8656de1feca0f596d69`

These are the inspected source snapshots, not a promise that a later manifest or edit has the same hashes. Reconcile later changes before launch.

## Complete count and wire-byte calculation

- Original E records:1,621
- Tensor-field occurrences / maximum T records:5,648
- Last-axis row references across all tensor occurrences:187,842
- Cache K/V origin chunks:26,944; origin raw bytes:10,208,768
- All other tensor rows, charged as unique:17,474; raw bytes:1,866,852
- Maximum C chunks:44,418
- Maximum unique raw bytes:12,075,620

| Component | Conservative bytes |
|---|---:|
| Unique raw row payload | 12,075,620 |
| C frames:44,418*(41 frame +36 chunk metadata) | 3,420,186 |
| T fixed JSON:5,648*512 | 2,891,776 |
| T frame headers:5,648*41 | 231,568 |
| T ordered row IDs:187,842*6 | 1,127,052 |
| All E frames, references, scalars and lists | 1,600,000 |
| Magic | 8 |
| F payload reserve | 4,096 |
| F frame header | 41 |
| **TOTAL** | **21,350,347** |

The codec's actual layouts are explicit little endian:8-byte magic,41-byte `<cQ32s>` frame header, and36-byte `<I32s>` C metadata. Raw row bytes are not base64 or compressed. E frames directly serialize original event dictionaries; no extra record wrapper exists. Tensor references are `{"$tensor":ID}`.

## T descriptor bounds and frame admission

At most44,418 unique chunks implies zero-based row IDs0..44,417, hence at most5 decimal digits. Charging6 bytes per reference covers its digits and comma, even the final reference. At most5,648 tensors implies IDs0..5,647, at most4 digits. References `{"$tensor":5647}` are only16 bytes; the E proof reserves32.

Source-declared shape maxima:

- Rank at most4
- Each dimension at most2,560
- At most768 last-axis rows in a tensor
- Raw row width at most10,240 bytes (2,560 FP32 values)
- Raw tensor byte length at most393,216 (big K or V `[1,8,96,128]` FP32)
- Short dtype codes are f32,bf16,i64,bool, at most4 characters
- Raw/content SHA-256 are each64 hexadecimal characters
- Finite flag needs at most5 characters

Exact key/syntax counting gives a conservative **282-byte fixed JSON descriptor**, including empty row-ID brackets but excluding their entries. Calculation:82 bytes of quoted keys;181 bytes for maximized scalar/hash/shape values;19 bytes of dictionary braces, colons and commas. The shape is overbounded by four4-digit dimensions. Thus the chosen512-byte reserve is safe. The actual maximum source descriptor frame is bounded by512+768*6+41=5,161 bytes.

The largest C payload is36+10,240=10,276 bytes. The largest scalar_scores E payload is below27,000 bytes even using32 bytes for each score/margin float. Every other source E payload is smaller. F payload is below2,048 bytes by two15-entry count maps plus fixed scalar/hash/acceptance fields; the proof reserves4,096 payload bytes plus41 frame bytes. These source shapes fit the codec's131,072-byte MAX_FRAME and1,048,576-byte MAX_TENSOR_BYTES admissions.

## E fixed-field proof

For each schema, count dictionary/list punctuation and key bytes directly. Charge no bytes for a tensor-reference value in this fixed subtotal, because every reference is charged32 bytes separately. Likewise, exclude the full variable numeric list value where it is separately charged below. Keep surrounding fields, nested dictionaries, fixed arrays and their punctuation in the fixed subtotal. Strings are ASCII source literals; generous dynamic-string caps are label64, tag32, negative name96, and dtype14 characters. Continuous-error float scalars are charged32 bytes each. call/seen/before/after receive3 digits; layer1 digit; seed8; parameters5. Each storage-ledger byte scalar receives10 digits and storage count2 digits, far above the source shapes.

| Ordinary event schema | Fixed JSON upper | Including41-byte E frame |
|---|---:|---:|
| continuous_error | 334 | 375 |
| cache_before | 135 | 176 |
| cache_after | 109 | 150 |
| scalar_scores | 167 | 208 |
| native_topk | 117 | 158 |
| adapter_prune | 316 | 357 |
| global_post_call | 217 | 258 |
| negative_control | 252 | 293 |
| unequal_layer_api | 71 | 112 |
| full_shape_gate | 83 | 124 |
| tiny_schedule | 107 | 148 |
| tiny_layer | 133 | 174 |
| tiny_post_norm_prune_then_head | 112 | 153 |
| attention_arrays | 140 | 181 |

The negative_control fixed bound includes all optional field names together, although no actual record has all of them. Every ordinary event is therefore below the512-byte allowance **including framing**, before separately charged refs/lists. source_receipt is handled separately: its frozen receipt is2,482 ASCII bytes including whitespace; fixed runtime/version fields and framing fit under4,096.

Complete E allowance, with no omitted category:

1. 1,620 ordinary records*512 =829,440
2. source_receipt including runtime/framing =4,096
3. 5,648 tensor refs*32 =180,736
4. 11,520 oracle score floats +224 oracle margins, each*32 =375,808
5. 2,560 oracle keep indices*4 =10,240
6. Oracle list brackets/inter-head commas =2,048 (actual bracket count1,064 plus392 head separators)
7. 42,168 global ordered-position IDs*4 =168,672
8. 216 global ordered-ID nested-list structure reserves*128 =27,648
9. Two67-entry tiny schedules plus unequal API integer lists and their structure =512

Total **1,599,200**, rounded up to **1,600,000 bytes**.

Every oracle index is0..95; every global ordered ID is0..131, so4 bytes including separator is conservative. The32-byte float allowance exceeds any finite Python float JSON spelling and the short strings used by the frozen pack behavior for a nonfinite scalar. Ordinary fixed scalar numeric fields were already charged in their per-event subtotal. No variable traceback/exception string is an E event: those belong to separately capped result.json. The per-value delimiter allowance overcounts final elements, and the list-structure reserves intentionally retain slack; double counting is conservative.

## Scope and remaining gates

The owner independently derived the same1,621-event /5,648-tensor /187,842-reference inventory, with a tighter14,741,864-byte bound using source-proven reuse across separate deterministic cache fixtures. This independent21,350,347-byte proof avoids needing that stronger cross-run reuse fact.

The bound is for the complete pinned fixture path, and every fail-fast prefix is no larger. It does not prove semantics, numerical parity, runtime duration, RSS, correctness of all decoder checks, or guard cleanup. It does not authorize imports or a numerical attempt. Any source/schema change requires reconciliation, and eventual acceptance still requires the separately authorized numerical result plus accepted resource/cleanup evidence.
