# Complete-suite source-only trace inventory and conditional v3 bound

Status: SOURCE-ONLY DIMENSION/COUNT REVIEW. No target module, Torch, Transformers, model, test, or serializer was imported or executed. No trained payload was read. Only static source reads, SHA-256, stdlib AST parsing, and arithmetic over declared shapes/schedules were used. This is not numerical validation or launch authorization.

Reviewed frozen v2 source directory: `research/reconstructed/author_trimkv_phase_a_implementation_v2_20261005`.

Pins:
- `test_author_semantics.py`: 30,514 bytes; SHA-256 `314fc0840c02011b4a626f83ff4943b45d41a4d5be057d4ec66d275d4e942d18`
- `author_static_adapter.py`: 21,125 bytes; SHA-256 `a566664113273de992f35d010e13ca2c75ead13479e4dc0afa3619de463b309a`
- `trace_schema.py`: 4,252 bytes; SHA-256 `dfc92f7e6edd37e6967c7bf132cbf4d2a68c920614bb7add8859a978981892ba`

## Result

The unchanged numerical suite has at most **1,621 original event records**, **5,648 tensor-field occurrences**, and **187,842 last-axis row references**. Storing every occurrence as raw values would require **67,500,132 raw tensor bytes**, before any format overhead, so raw whole-tensor serialization alone does not meet the 23,000,000-byte partition.

Lossless exact last-axis row deduplication changes the provable complete-suite bound to:

- Cache K/V unique origin rows: at most **26,944 chunks / 10,208,768 bytes**
- Every other tensor row, pessimistically treated as unique: at most **17,474 chunks / 1,866,852 bytes**
- Total: at most **44,418 unique chunks / 12,075,620 raw bytes**
- Original event JSON, including finite scalar/list payload and tensor references: at most **1,600,000 bytes**, under the schema caps below

This bound does not use a compression ratio, observed numerical tensor values, equality between separate fixture runs, equality between different model routes, or tensor-descriptor deduplication.

The binary C/T/E/F design described by the owner fits if its source enforces the following conservative wire-size caps:

1. C chunk fixed overhead, including frame header/hash/ID: at most 128 bytes per unique chunk
2. T tensor descriptor fixed overhead, including frame header/hash/dtype/shape/tensor hashes: at most 384 bytes, plus at most 7 bytes for each ordered row ID
3. E event representation uses at most 32 bytes per tensor reference, with ordinary fixed fields plus event framing at most 512 bytes; the receipt uses at most 4,096 bytes; variable lists are charged separately below
4. File header and final commit combined: at most 2,048 bytes

The resulting complete bound is:

`12,075,620 + 44,418*128 + 5,648*384 + 187,842*7 + 1,600,000 + 2,048 = 22,846,898 bytes`

This leaves **153,102 bytes** below 23,000,000. With at most 96 C overhead bytes, the bound is **21,425,522 bytes**, leaving 1,574,478 bytes.

**Pending source gate:** the v3 schema was not yet frozen when this report was written. Its actual frame/descriptor/ref layouts must satisfy the caps, and the exact v3 numerical-region hashes must match the frozen suite. Merely checking output against a 23 MB cap is not a proof of complete-suite fit. A schema exceeding these conservative caps may still fit after a tighter source derivation, but is not certified by this report.

## All original event counts

| Event | Maximum | Source occurrence / explanation |
|---|---:|---|
| source_receipt | 1 | test line 63 |
| continuous_error | 272 | test line 88: 2 checks*67 tiny calls*2 dtypes +4 A7 comparisons |
| cache_before | 80 | test line 144; all cache_run calls |
| scalar_scores | 28 | test line 159; 14 cache_run prune sweeps*2 layers |
| native_topk | 28 | test line 162; same sweeps |
| cache_after | 80 | test line 177 |
| negative_control | 59 | expanded below |
| unequal_layer_api | 1 | test line 293 |
| full_shape_gate | 2 | test line 327 |
| tiny_schedule | 2 | test line 355 |
| attention_arrays | 4 | test line 429 |
| adapter_prune | 44 | adapter line 166: 32 big-cache layer prunes +12 tiny layer prunes |
| global_post_call | 216 | adapter line 176: 80 cache_run +2 ties +134 tiny adapter calls |
| tiny_layer | 536 | adapter line 325: 67 calls*2 dtypes*2 traced routes*2 layers |
| tiny_post_norm_prune_then_head | 268 | adapter line 337: 67*2*2 |
| TOTAL | 1,621 | |

`timed()` accumulates counters only and emits no event. The untraced Full/no-crop/native/stale/rebased/freeze/split-history routes do not add tensor events. Failed guards stop before their body emits. Terminal result.json, timing/error summaries, scratch audit, and guard receipts belong to their separately capped partitions, not this trace. A fail-fast prefix cannot exceed the full successful path's count/shape bounds.

Negative-control counts: age/wrong-clock/early-current-attention 8; buffer128 1; invalid routes 13; missing seam/premature prune 3; raw author ABI 2; upper-layer prune 1; actual model guards 3; unsupported reference APIs 6; full gate guards 6; closed-loop controls 8; A7 mask/GQA 8. Four negative records carry tensors: two wrong-global-clock records, each with correct/wrong ID arrays; two early-prune attention records, each with full/early output arrays. The other 55 have no tensor payload.

## Shape and dtype inventory

Let f be the run's FP32 or BF16 dtype; scalar sizes are FP32=4, BF16=2, int64=8, bool=1 byte. All tensors have singleton batch where shown.

- Big cache arrays, cache_before/cache_after and adapter old/new: K,V `[1,8,N,128]` f; gates `[1,8,N]` f; positions `[1,8,N]` int64. N is at most96; budget M is8 or32. Each cache_before/after contains two layers.
- Tiny adapter old/new: K,V `[1,2,N,8]` f; gates `[1,2,N]` f; positions `[1,2,N]` int64. N is at most64; M=8.
- Prune/native selection arrays: scores `[1,H,N]` FP32, selected indices `[1,H,M]` int64, margins `[1,H]` FP32; H=8 for big,2 for tiny.
- tiny_layer: positions `[Q]` int64; normalized input/output `[1,Q,32]` f; gate `[1,2,Q]` f; visibility `[1,4,Q,N]` bool. Schedule `[64,3]+[1]*65`, sum132 tokens,67 calls; N is current retained rows plusQ.
- tiny_post_norm_prune_then_head: positions `[Q]` int64; hidden `[1,Q,32]` f; logits `[1,Q,97]` f; last-head `[1,1,97]` f.
- tiny_schedule: token IDs `[1,132]` int64; calls is a 67-element ordinary integer list.
- full_shape_gate: input/normalized `[1,2,2560]` f; gate `[1,2,8]` f.
- wrong-global-clock detail: two `[1,8,8]` int64 tensors per dtype.
- early-prune-current-attention detail: two `[1,1,8,128]` f tensors per dtype.
- A7 attention_arrays, Q in1,11: query `[1,4,Q,8]` f; key/value `[1,2,3+Q,8]` f; positions `[Q]` int64; old positions `[1,2,3]` int64; visibility `[1,4,Q,3+Q]` bool; dense/tiled `[1,Q,4,8]` f. Masks themselves are not emitted.
- global_post_call ordered_ids are ordinary nested Python integer lists `[2 layers][1,H,N_after]`, not tensor fields.
- scalar_scores oracle contains scores `[8,N]` Python floats, indices `[8,M]` Python ints, margins `[8]` Python floats, plus three scalar ints; scalar_gather K/V lists are used for checks but are not emitted.

The largest single last-axis row has2,560 FP32 values=10,240 bytes. The largest ordinary dimension is2,560; tensor rank is at most4. Runtime external ABI/shape correctness still requires the eventual guarded numerical checks; this report derives shapes from the frozen source/configuration and intended pinned ABI.

## Cache schedule arithmetic

For each call, `before=resident+Q`; `pruned=(before >= M+32)`; `after=M if pruned else before`; next resident=after. This is integer size arithmetic, not evaluation of the numerical fixtures.

| Fixture, once per dtype unless stated | Calls | New tokens | Sum before | Sum after | Prune sweeps | Sum prune-before | Sum prune-after | Stored row-axis lengths across cache snapshots+prune old/new |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| threshold M8 [39,1] | 2 | 40 | 79 | 47 | 1 | 40 | 8 | 174 |
| threshold M32 [63,1] | 2 | 64 | 127 | 95 | 1 | 64 | 32 | 318 |
| two_events [40]+[1]*32 | 33 | 72 | 824 | 760 | 2 | 80 | 16 | 1,680 |
| oversized [96] | 1 | 96 | 96 | 8 | 1 | 96 | 8 | 208 |
| age [40] | 1 | 40 | 40 | 8 | 1 | 40 | 8 | 96 |
| gapped [40,32], FP32 only | 2 | 72 | 80 | 16 | 2 | 80 | 16 | 192 |
| exact tie [40], FP32 only | 1 | 40 | 40 | 8 | 1 | 40 | 8 | 48 |
| near tie [40], FP32 only | 1 | 40 | 40 | 8 | 1 | 40 | 8 | 48 |

Tie rows have only adapter old/new events, no cache_before/cache_after. FP32 totals: 464 new tokens,2,764 stored row-axis lengths,43 global calls,10 prune sweeps. BF16 totals:312 new tokens,2,476 lengths,39 global calls,6 prune sweeps. Of FP32's10 sweeps,8 belong to cache_run and2 are tie cases.

The conservative K/V origin bound is `(464*4+312*2)*2 layers*8 heads*2 K/V*128 = 10,158,080 bytes`, with `(464+312)*2*8*2 = 24,832` origin chunks. This deliberately does not reuse identical data across independent cache_run fixtures, even though their input formulas often coincide.

Tiny, per dtype:132 new tokens,67 calls,sum before1,655,sum after1,535,3 prune sweeps,sum prune-before144,sum prune-after24,sum Q*N5,709. Counting every newly produced adapter K/V row, even those never reached by a prune event, gives `132*(4+2)*2 layers*2 heads*2 K/V*8 = 50,688 bytes` and `132*2 dtypes*2*2*2 = 2,112` chunks.

The row-origin invariant is source-visible: cache append/clone/concatenate/gather only copy existing K/V values; neither source nor adapter mutates a K/V row in place after creation. Exact-byte chunk interning therefore needs one chunk per originating dtype/head/layer/K-or-V row at most. This is not an assumption about numerical closeness, stable top-k membership, or float serialization roundoff.

## Every tensor-field occurrence

| Event | Tensor fields | Row references | Raw bytes without dedup | Cache-K/V row refs | Cache-K/V raw bytes |
|---|---:|---:|---:|---:|---:|
| adapter_prune | 484 | 35,644 | 13,114,656 | 33,920 | 12,844,032 |
| attention_arrays | 32 | 540 | 12,016 | 0 | 0 |
| cache_after | 640 | 61,824 | 23,149,120 | 59,264 | 22,822,912 |
| cache_before | 640 | 79,744 | 30,392,128 | 77,184 | 29,966,336 |
| full_shape_gate | 6 | 12 | 61,536 | 0 | 0 |
| native_topk | 84 | 476 | 67,456 | 0 | 0 |
| negative_control | 8 | 64 | 14,336 | 0 | 0 |
| tiny_layer | 2,680 | 7,944 | 400,224 | 0 | 0 |
| tiny_post_norm_prune_then_head | 1,072 | 1,592 | 286,548 | 0 | 0 |
| tiny_schedule | 2 | 2 | 2,112 | 0 | 0 |
| TOTAL | 5,648 | 187,842 | 67,500,132 | 170,368 | 65,633,280 |

All non-cache-K/V tensors combined:

| Dtype | Fields | Rows | Bytes |
|---|---:|---:|---:|
| BF16 | 1,413 | 3,956 | 272,444 |
| bool | 540 | 4,320 | 183,952 |
| FP32 | 1,581 | 4,724 | 667,224 |
| int64 | 1,298 | 4,474 | 743,232 |
| TOTAL | 4,832 | 17,474 | 1,866,852 |

## Non-tensor scalar/list/metadata allowance

The following bounds cover all event fields, while preserving ordinary Python scalar/list values exactly:

- Ordinary fixed keys/scalars and E-frame overhead:1,620*512=829,440 bytes
- source_receipt:4,096 bytes. Its frozen input JSON is2,482 bytes including whitespace; runtime version strings and fixed runtime count fields fit comfortably in this larger reserve
- Tensor references:5,648*32=180,736 bytes
- Scalar oracle scores:11,520 Python floats; oracle margins:224 Python floats. Reserve32 bytes per value including delimiter:11,744*32=375,808 bytes
- Scalar oracle indices:2,560 ints, each in0..95. Reserve4 bytes including delimiter:10,240 bytes
- Scalar oracle nested brackets:2,048 bytes (greater than28*38=1,064 actual bracket characters)
- Global ordered IDs:15,200 FP32 big +14,688 BF16 big +12,280 tiny =42,168 ints. Each in0..131; four bytes including delimiter:168,672 bytes
- Global nested-list bracket reserve:216*128=27,648 bytes
- Tiny schedule lists plus unequal API lists:512 bytes

Sum:**1,599,200 bytes**, rounded up to**1,600,000**.

Python float representations, including the existing serializer's short nonfinite strings if reached by a scalar error calculation, fit within31 characters plus a delimiter. Model parameters are constrained below100,000; seed is fixed20261005; seen/call/budget and storage-ledger counts are bounded by the declared shapes. Arbitrary exception traceback/error strings are written to result.json and are not an unbounded trace-event category.

This ordinary E-field budget is independent of C/T format bytes. For the schema gate, the caps on fixed event/framing size and32-byte references must be confirmed against its actual source.
