# Compressed-reuse cost frontier: three narrow candidates, none promoted

Date: 2026-10-05 UTC. Source-only admission screen. No installation, model/tensor download, author-code execution, numerical test, GPU/provider action, external write, or spending occurred.

## Decision

**No main direction and no backup are admitted from this screen.** Three concrete mechanisms were examined:

1. Keep compressed keys canonical and postpone positional relocation until attention: directly overlaps MiniPIC/MEPIC; inspected MiniPIC code already combines FP8 loading with fused positional rotation
2. Select repair targets using the error of the actual post-repair representation: a real interaction, but “remove quantization noise” is generally the wrong objective, and no specified mechanism yet distinguishes itself from the simple controls below
3. Piggyback reusable learned-cache extraction on the first live prefill: implementable in a restricted case, but ordinary computation sharing already follows from C²KV's original-token invariance; arbitrary non-prefix inputs invalidate the shared-computation premise

These are rejections of these precise proposals, not an exhaustive proof that compressed reuse has no research opportunities. A baseline integration or source bug fix is not enough to reopen them. None justifies spending the CNY100 budget.

Existing local transition, deployment-cost, query-drift, alternative-gap and new-direction reports were read to avoid reopening closed work. The screen does not propose generic admission/eviction, hysteresis, variable paging, mean-V correction, a correctness framework, or the old multi-source project.

## 1. Immutable compressed keys with attention-time relocation

### Problem and exact proposed delta

A repeated document may be used at different offsets by concurrent requests. A naive implementation loads and dequantizes canonical keys, rotates every key into its requested position, and writes a request-specific dense cache. This destroys some of the memory/lifetime benefit of reusable compression.

The proposed implementation would keep one immutable, position-free compressed K payload per span. The attention kernel would dequantize only its current tile and apply request-local RoPE before consuming it, without materializing a relocated cache. Values need no RoPE relocation. This is a representation/execution change, rather than a better cache-admission score.

A variant stores canonical position-bearing keys and shifts the query once per span using the RoPE relative-position identity. That variant must merge per-span softmax statistics and pay span metadata, kernel scheduling and reduction costs; it is not a new algebraic identity.

### Closest primary work and actual author code

[MiniPIC, June 2026](https://arxiv.org/html/2606.13126v1) already separates physical KV storage from request positions, keeps unrotated keys, and fuses RoPE into paged attention. It cites [MEPIC, December 2025](https://arxiv.org/html/2512.16822v1), which already combines shared position-free blocks with selective request-specific recomputation. MiniPIC's paper links IBM's author fork and starting commit.

Verified author pin: [IBM/vllm, 6631ff34489612db6823b1ae3369c83eb6241853](https://github.com/IBM/vllm/tree/6631ff34489612db6823b1ae3369c83eb6241853), commit date 2026-02-24. This is the paper-linked source anchor, not a claim to have resolved or tested the latest compatible release.

The [attention kernel](https://github.com/IBM/vllm/blob/6631ff34489612db6823b1ae3369c83eb6241853/vllm/v1/attention/ops/triton_unified_attention.py#L286-L340) loads K halves from paged storage, contains FP8 scale/dequantization branches, and applies the FUSE_ROPE transformation in tile-local variables. The [following dot products](https://github.com/IBM/vllm/blob/6631ff34489612db6823b1ae3369c83eb6241853/vllm/v1/attention/ops/triton_unified_attention.py#L393-L396) consume those rotated values. The inspected path does not write a relocated K cache.

**Scope caveat:** source coexistence of FP8 and FUSE_ROPE branches is not proof that every combined configuration passes numerical tests or is enabled by every model/backend. It is nevertheless decisive prior implementation against claiming that storage quantization plus attention-time relocation is an absent mechanism.

### Strongest simple control and falsifier

The proper control is MiniPIC's position-free paged representation, including its available FP8 path, rather than a repeatedly materialized dense cache. A 4-bit unpacking port must beat this control after equal-quality/total-byte accounting; changing the bit width alone is not a scientific distinction.

The smallest later CPU falsifier, if a genuinely different kernel proposal appears, is one saved real K/Q tile from a competent RoPE model reused at two offsets. Compare canonical quantize-once plus local dequantize/rotation against the same canonical representation in the reference MiniPIC operation order. Count physical cache copies separately from transient tile values. Do not compare against an unnecessarily re-quantized key baseline or claim bitwise identity under changed rounding.

Kill immediately if the only difference is fusing an existing dequantize/rotate sequence, if savings disappear against position-free storage, or if concurrent readers still require separate whole-cache payloads. No such test is presently warranted because the core mechanism is already occupied.

### Lifetime economics and GPU feasibility

Canonical sharing reduces physical duplicate cache copies; it does not remove per-read dequantization/rotation. Hoisting a representation conversion once for a hot item is ordinary materialization caching with setup cost. A one-card 3–8B proof is conceivable, but a new 4-bit backend and Blackwell compatibility would require work and measurement. No 5090 performance or memory fit was verified here.

**Disposition: reject; no CPU/GPU experiment admitted.**

## 2. Repair scoring under lossy storage, with the output representation fixed

### Problem and exact proposed delta

Suppose a document's stored value is Q(v₀), while the fresh value in the current context is v₁. The apparent repair discrepancy mixes changed context and storage error. A tempting proposal subtracts storage error before choosing the rows to recompute.

The only defensible candidate is narrower: **score each available repair action by the residual it leaves in the representation that will actually serve the request**, including any required requantization, physical page rewrite and scale update. This is not automatically a new method; it is first a correctly specified objective.

### Actual baselines and a misleading shortcut to avoid

[CacheBlend, EuroSys 2025](https://www.microsoft.com/en-us/research/uploads/prod/2024/09/eurosys25-final999.pdf), has original author code at [YaoJiayi/CacheBlend, 55ad02675939f783a38d579393527d218a7fd581](https://github.com/YaoJiayi/CacheBlend/tree/55ad02675939f783a38d579393527d218a7fd581), dated 2024-12-31. In this source:

- [llama.py, 300–303](https://github.com/YaoJiayi/CacheBlend/blob/55ad02675939f783a38d579393527d218a7fd581/vllm_blend/vllm/model_executor/models/llama.py#L300-L303) configures a check layer and recomputation ratio
- [xformers.py, 204–217](https://github.com/YaoJiayi/CacheBlend/blob/55ad02675939f783a38d579393527d218a7fd581/vllm_blend/vllm/attention/backends/xformers.py#L204-L217) ranks squared differences between fresh and stored values
- [xformers.py, 240–245](https://github.com/YaoJiayi/CacheBlend/blob/55ad02675939f783a38d579393527d218a7fd581/vllm_blend/vllm/attention/backends/xformers.py#L240-L245) patches selected old K/V rows with fresh dense rows

The 2026 [KVBoost paper](https://arxiv.org/html/2608.21362v1) links [pythongiant/kvboost](https://github.com/pythongiant/kvboost/tree/87fe5e31f076105a43f8be8e368047c4fe595499), pinned here at 87fe5e31f076105a43f8be8e368047c4fe595499, dated 2026-07-22. Its [manager](https://github.com/pythongiant/kvboost/blob/87fe5e31f076105a43f8be8e368047c4fe595499/src/kvboost/cache_manager.py#L228-L280) dequantizes on retrieval. However, its inspected [dense repair implementation](https://github.com/pythongiant/kvboost/blob/87fe5e31f076105a43f8be8e368047c4fe595499/src/kvboost/cacheblend.py#L127-L161) first forwards the full cached prefix, then selects and patches rows. That path cannot be used as evidence of cheap sparse recomputation. A separate sparse module exists and was not audited in this pass; no whole-project claim is made.

A second source caveat: the [KVBoost quantizer](https://github.com/pythongiant/kvboost/blob/87fe5e31f076105a43f8be8e368047c4fe595499/src/kvboost/kv_quantize.py#L82-L95) reduces K over the last dimension and V over the token dimension despite its per-channel-K/per-token-V labels. With the declared [B,H,T,D] layout those statistics do not implement the named KIVI axis convention. Do not adopt it as a faithful KIVI reference.

### The critical distinction: nuisance noise versus actual repair benefit

This is an elementary action-contract derivation, not a new result or an experiment. Let δ = v₁ − v₀ and e₀ = Q(v₀) − v₀.

- The existing stored-state error is v₁ − Q(v₀) = δ − e₀
- If repair writes v₁ in FP16/BF16 and serves that row without re-encoding, it removes BOTH components. Subtracting e₀ from the score can discard genuinely valuable repairs
- If repair must write Q(v₁), define e₁ = Q(v₁) − v₁. Under the deliberately simple per-row squared-error objective, potential improvement is ||δ − e₀||² − ||e₁||²
- If group scales change, other rows in that group may change as well. A row-only score no longer describes the executed action
- Neither row energy nor change magnitude establishes answer quality; attention weighting, query changes and downstream propagation still matter

Thus common-quantization comparison is a useful control, not a magic unbiased estimator. The appropriate target can be total error, post-requantization residual, or contextual mismatch only, depending on what the repaired cache will actually contain.

[AgentKVShift](https://arxiv.org/html/2607.21604v1#S4.SS5) already explicitly studies composing reuse repair with low-bit storage and treats average quantization error as part of the correctable residual. Its author implementation was not verified here, so it is an overlap constraint, not a reproduced baseline. [RelaxKV, September 2026](https://arxiv.org/html/2609.33503v1), already makes repair targets and the attention context used to recompute them a joint design problem. No author code link was verified in that paper either.

### Strongest simple controls

Keep one declared immutable canonical cache plus request-local repairs. Charge all persistent score metadata and transient dense tensors.

1. Original CacheBlend discrepancy, with fresh dense repaired rows
2. Same scorer with repaired rows quantized under the declared serving rule
3. Score after applying the same quantizer/scales to both candidate states
4. Preserve only the original check-layer score tensors at FP16/BF16; include their bytes in the equal-budget comparison
5. Compute the repair mask before compressing the stored state, when that mask is actually available without future-query leakage
6. Ordinary direct action-value score at the check layer, using the resulting quantized candidate and fixed scales
7. Fixed seam/first-block repair at matched executed work, plus full recomputation and no repair

A cheap exact probe is not permitted to read full fresh later-layer states that selective repair would never compute. Earlier compressed layers also change the probe trajectory; preserving one score tensor does not make a full-precision counterfactual free.

### Smallest real-signal CPU falsifier

No fixture was run. If a concrete algorithm survives the source screen, use **saved genuine per-layer states for the same document under two context orders**, with at least one exact-prefix/no-context-change pair. Start with one check layer, the following repaired layer, four 256–512-token documents and two queries per document. A saved artifact must actually contain these paired states; single-prefix value-rounding tensors or random arrays do not qualify. If unavailable, a separately authorized bounded model acquisition is required before claiming real signal.

Freeze one bit width, group size, recomputation ratio and both repair-output contracts (dense or same-format requantized). Replay the actual selected-row operation on CPU and compare every control above at equal bytes and actual rewritten elements. First measure action-specific residual reduction and work; only a later causally re-executed model continuation can establish answer benefit.

Kill if direct action-value scoring or exact check-layer metadata closes the gap, if “noise removal” helps only when compared with the wrong output contract, if the result is just correcting mislabeled quantizer axes, or if necessary fresh states cost a full prefill. Mask-ranking changes alone are insufficient. No distinct mechanism or evidence of an advantage over these controls was established; the controls were specified, not run.

### GPU feasibility

Small-model quality checks could fit a single 5090 in principle; the original 2024 CacheBlend fork is not a verified Blackwell-ready engine. A production latency claim needs a current sparse-repair integration and all conversion/page-write work charged. The misleading dense KVBoost path must not be ported and relabeled as the method.

**Disposition: reject as currently specified; no main or backup.**

## 3. First-miss prefill that also emits a reusable compressed representation

### Problem and exact proposed delta

Offline compression is not free when documents have short lifetimes or few hits. The proposed system would serve the first miss with ordinary exact prefill while also executing a learned compressor's auxiliary-token branch from the same layer inputs, producing a compressed cache for future requests. It would avoid a second base-model pass, rather than merely choosing which documents to admit.

### Closest work and actual author code

[C²KV, KDD 2026](https://arxiv.org/html/2607.17715v1) introduces a frozen-base-model sidecar with compression tokens and a mask that prevents original tokens from attending to them. Its published TTFT accounting excludes offline extraction and query/system prefill; online/incremental extraction is listed as future work. Those timing boundaries motivate an end-to-end ledger but do not themselves establish a new algorithm.

Author pin: [s7a9/C2KV, 832ccd9c985055a95c1e219383e043bb005a1b36](https://github.com/s7a9/C2KV/tree/832ccd9c985055a95c1e219383e043bb005a1b36), dated 2026-08-17.

- [Qwen3 forward_with_gist, 277–334](https://github.com/s7a9/C2KV/blob/832ccd9c985055a95c1e219383e043bb005a1b36/python/models/qwen3/modeling_qwen3.py#L277-L334) already computes original-token and gist QKV in one layer path and keeps gist K/V before RoPE
- [gist_utils.py, 138–145](https://github.com/s7a9/C2KV/blob/832ccd9c985055a95c1e219383e043bb005a1b36/python/models/gist_utils.py#L138-L145) builds the original/original and gist blocks while leaving original-to-gist entries masked
- [generate_gist, 517–573](https://github.com/s7a9/C2KV/blob/832ccd9c985055a95c1e219383e043bb005a1b36/python/models/qwen3/modeling_qwen3.py#L517-L573) exposes gist-only cached output despite traversing the combined states
- [expr_c2kv.py, 92–106 and 130–151](https://github.com/s7a9/C2KV/blob/832ccd9c985055a95c1e219383e043bb005a1b36/python/inference/expr_c2kv.py#L92-L151) performs extraction outside the recorded blend/generate regions and separately exercises a host-to-device copy

These observations establish source structure and timing scope, not executed equivalence or a measured overhead.

### Strongest control, and the hidden dependency that blocks the broad claim

For a canonical document-only first prefill, exposing its already computed original K/V alongside gist K/V is ordinary output retention/common-computation sharing. Compare against exactly that baseline, not “full prefill plus a completely separate extractor.”

For a live RAG request, the same original document tokens often attend to a system prompt or prior documents. Their deeper hidden states are then different from the independently encoded document inputs required by a composable cache. C²KV's invariance says original-token states match the base model under the **same original-token context**, not that states are invariant to preceding documents. A changed attention mask or second branch is required. Retaining every layer's request hidden states does not repair this semantic mismatch and adds a large lifetime cost.

This gives two cases:

- Restricted identical-context piggybacking: useful engineering, already implied by source dataflow
- Arbitrary-context piggybacking: needs a new correct representation/training contract or extra computation, neither supplied here

“Run extraction only after enough hits” reduces to ordinary setup-cost admission and does not solve this dependency.

### Smallest real-signal CPU falsifier and kill condition

Before any new model run, map one canonical-document and one preceded-document call through the pinned mask/QKV dataflow. Identify exactly which intermediate states both consumers may share. A later real-signal check needs a saved real model's layer-1 and layer-2 inputs for these two cases and the intended trained extractor; a random sidecar cannot establish learned-cache quality.

Compare dual-output extraction against separate extraction under identical inputs, then compare piggybacked request-conditioned extraction against genuine canonical extraction under different prefixes. Charge auxiliary QKV/attention/MLP work, any second branch, retained hidden states, first-miss latency and compressed-cache build. Kill if the only success is output retention, if later-layer inputs differ and no repair exists, or if exact-first-request preservation is silently replaced with block-isolated attention.

A trained 3–4B sidecar could plausibly support a single-card experiment. Training a new composable representation and a concurrent serving implementation is not justified by this source-only negative screen, and was not shown feasible within the budget.

**Disposition: reject; no GPU release.**

## Required economic baseline for any successor

Track one lifetime from creation through its last use or eviction. For item j, include construction B_j, transfer D_ij, representation conversion X_ij, repair R_ij, ordinary query/decode C_ij, and disposal/space interference where applicable. Compare the same request trace and quality contract:

    Total = sum_j B_j + sum_i (D_i + X_i + R_i + C_i)

This is accounting, not the proposed contribution. A request-independent compressed prefix and an exact prefix BOTH receive their legitimate one-time construction amortization. Already resident exact prefixes do not pay full recomputation per hit. A codec's transmission bytes do not establish decode footprint, and a compressed store that expands every hit does not provide resident compressed attention.

[KVCodec, SIGCOMM 2026](https://arxiv.org/html/2602.09725v3), already treats transfer, decode, restoration and interference as a pipeline, including frame-wise restoration. Its lossless H.265 mode follows an initial quantization step; “lossless video” is not bit-exact original floating-point KV. No author-code repository was verified in the bounded search, so it is not presented as an executable baseline. It further rules out treating pipeline overlap or codec conversion accounting alone as a new proposal.

For a one-time extra build cost ΔB and genuine per-hit improvement s_i over the strongest feasible baseline, compression has a compute break-even only when sum_i s_i exceeds ΔB before the cache's useful life ends. Fixed conversion retention, ordinary cost-aware admission and hysteresis are baseline controls, not candidate names.

## Verification boundary

Four author repository commits were resolved through the read-only GitHub connector, and relevant source files were fetched at those immutable pins. The web corpus and some current branch pages have inconsistent freshness, so pinned connector responses, rather than indexed branch-head snippets, determine the code claims. Paper/source correspondence and runtime support were not assumed beyond what is explicitly stated above. Supplementary papers without verified author code are marked as such. The accompanying SOURCE_INDEX.json lists inspected pins and file/line ranges.

No test result, speedup, observed quality gain, novelty assurance, or publication claim is made.
