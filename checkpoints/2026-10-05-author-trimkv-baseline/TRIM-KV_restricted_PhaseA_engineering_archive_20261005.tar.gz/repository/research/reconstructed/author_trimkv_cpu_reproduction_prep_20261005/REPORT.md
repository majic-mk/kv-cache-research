# Prepare the released TRIM-KV baseline before inventing another method

2026-10-05 UTC. **Source-only preparation. No numerical execution, runtime/tokenizer import, model construction, weight/gate payload load, download, installation or GPU action occurred. No executable adapter has been implemented or released by this packet.**

## Decision

Use the released **static TRIM-KV gate matched to Qwen3-4B-Instruct-2507**, first as an exact author-cache semantics reference, then conditionally as a small trained-model CPU-port baseline. Do not switch to the available hybrid 2B model: that would remove the checkpoint/gate match. The useful deliverable is a faithful baseline and an evaluation starting point, not a new method or a paper result.

The next bounded numerical task, if separately authorized, is **Phase A: at most 120 seconds wall / 100 seconds total CPU / 1 GiB sampled process-tree RSS**, with synthetic tensors and a tiny random model only. It must compare unchanged author cache/gate method bodies with a narrowly specified current-runtime adapter, preserve every original call boundary, and detect deliberate policy errors. It must not load the trained gate or the 4B model.

Only after that gate passes should a separate Phase B be considered. Two unmodified public Oracle records are now fixed: **edced276** and **19b5f2b3**. Their selection used ID hashes and negative source-family exclusions, not answers, support labels, question difficulty, or Full-model correctness. The exact token counts, integer cache budget, CPU attention implementation and original-dense-prefill memory admission are still unresolved. No actual-model launch is ready.

## Pinned source and assets

- Author code: [ngocbh/trimkv, 49d2a2951ba12e6431a3986b418ee791b209d7c2](https://github.com/ngocbh/trimkv/tree/49d2a2951ba12e6431a3986b418ee791b209d7c2)
- Base: [Qwen/Qwen3-4B-Instruct-2507, cdbee75f17c01a7cc42f958dc650907174af0554](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507/tree/cdbee75f17c01a7cc42f958dc650907174af0554)
- Static gate: [ngocbh/TrimKV-Qwen3-4B-Instruct-2507, 89112809f83d05c3058eadcab4104abde5721b81](https://huggingface.co/ngocbh/TrimKV-Qwen3-4B-Instruct-2507/tree/89112809f83d05c3058eadcab4104abde5721b81)
- Public benchmark: [LongMemEval cleaned Oracle, 98d7416c24c778c2fee6e6f3006e7a073259d48f](https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned/blob/98d7416c24c778c2fee6e6f3006e7a073259d48f/longmemeval_oracle.json)
- Source requirements: Torch 2.8.0 and Transformers 4.57.1. The existing recovered CPU runtime is Torch 2.9.1+cpu and Transformers 5.19.0.dev0 at 02d8fb9784e8f14a1251e4c992cd82a5762417c6. Version/source evidence is inherited from saved verification, not a fresh import

The existing public Oracle file was rehashed in this preparation: **15,388,478 bytes**, SHA256 **821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c**, 500 distinct IDs. The static gate's saved prior verification reports 144 keys, 47,352,096 BF16 parameters and 94,704,192 tensor bytes; file SHA256 **a43e83cbd2612924a722206f15777f36d1457fa8dadb7dbe5761d6f54c01037a**. That payload was not reread here. Three base-shard identity checks must be repeated before any later load.

This report uses existing pinned source snapshots. `SOURCE_MANIFEST.tsv` identifies them. It does not claim to have run the author package or verified a different/latest version.

## Released command and literal effective behavior

The [released example shell](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/scripts/run_trimkv.sh#L8-L28), absent environment overrides, expands to:

```sh
python ./run_longmemeval.py --dataset longmemeval_s \
  --model_path ngocbh/TrimKV-Qwen3-4B-Instruct-2507 \
  --method trimkv --download_from huggingface --n_samples 1 --kv_budget 32768
```

This is the reference command, **not a runnable CPU command**. It neither pins a model revision nor supplies `useronly`, `cot`, `buffer_size`, or `gen_length`. Our reproducibility wrapper must pin already-acquired revisions without inheriting mutable `main`.

Literal Python/default flow is important:

- `Config.useronly=True` and `Config.cot=True` are booleans. The runner passes `config.useronly=='true'` and `config.cot=='true'` to `prepare_prompt`. Both comparisons are false with the example shell defaults. Thus this route includes assistant turns and uses the **non-CoT prompt**
- The separate generation-length branch tests truthiness of `config.cot`, so it selects **800** steps despite the non-CoT prompt
- Active `decode()` always selects greedy argmax. Exposed `do_sample=True`, temperature0.6 and top_p0.95 are not used on this path
- It checks EOS or final iteration **before** appending the selected token. There are at most800 selections and799 emitted/fed tokens. Record the final non-emitted decision and why it stopped
- `retriever_type=orig-session`, `topk_context=1000`, `history_format=json`, `con=False`, no key-expansion merge, max_model_len131072, effective max_retrieval_length129272
- The benchmark source Oracle records remain untouched. The author's rendering sorts sessions by dates and removes `has_answer` from rendered dictionaries. Perform that on a deep copy so the raw source cannot be mutated
- The prompt is placed in one user chat-template message. The resulting string is split at `Current Date:` into history and final question/date/assistant-prefix strings. Each string is **tokenized independently**, then forwarded separately. Do not assume concatenated tokenization gives the same IDs

The two selected public records have no extra `Current Date:` literal in their history or question; their source session dates are already sorted. This was a text/metadata check, not a prompt/tokenizer run. We must not silently repair the boolean/string behavior to a different prompt profile. A corrected intended-profile experiment would be another explicit configuration.

Source: [runner defaults, generation and rendering](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/run_longmemeval.py#L29-L305), [prompt preparation](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/generation_utils.py#L129-L374).

## Exact static policy that Phase A must reproduce

1. The loader creates `TrimKVCache(memory_size=config.kv_budget, buffer_size=config.buffer_size, device='cuda')`. The runner default buffer is **32**, not the gate metadata's128. Effective strategy is fixed_budget, lookahead1 and sliding protection0. The runner's exposed lookahead is not forwarded. `compress_strategy='alpha'` and `model.is_compressing` do not replace this actual policy
2. The gate `rg` reads each layer's **input-RMS-normalized full hidden vector**, before QKV attention. It computes Linear2560→512 with bias, SiLU, Linear512→8 without bias, separate8-vector bias, then log-sigmoid. Gates are stored once per newly appended row/head
3. Q/K normalization and split-half RoPE precede cache append. Head dimension is128; hidden2560 divided by query-head count32 is not the head dimension. Original rotated keys are gathered unchanged
4. Append K/V/log_beta/absolute IDs before attention. The unchanged source advances `_seen_tokens` only in layer0; all layers use the same positions computed before that call
5. In the selected inference route, retention gates do not multiply attention logits. The standard FA2 wrapper discards retention/position arguments; training retention attention is a different contract
6. Complete the entire current call through all decoder layers and final RMSNorm, then invoke the **global compression sweep**, then compute LM logits. Apply this after the history call, the complete final-question call and every decode call. There is no history-only/query freeze and no within-call pruning
7. For each layer with resident length **R>=M+32**, compute FP32 `log_beta*(N+1-original_position)`, with N the total seen tokens after this call. The newest Q1 row has age2, not1. Select M separately per KV head via native torch.topk, sort selected physical indices ascending, gather K/V/gates/IDs together
8. Buffer32 is slack, not protected recency. No sink/recent guarantee exists; even the newest row can be removed. Per-head keep sets may differ. Source topk has no promised stable tie membership across backends

An oversized dense history is attended in full, followed by one pruning event. Turning it into128-token online calls changes the policy even if the final prompt string is unchanged. Similarly, replacing original absolute IDs with compact offsets changes RoPE and scores. The old S0/history-only adaptation is not acceptable here.

Sources: [cache](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/cache_utils.py#L55-L247), [gate/attention](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L134-L345), [global post-call prune](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L712-L727), [inference dispatch](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/attn/__init__.py#L18-L35).

## What existing work already established, and what it did not

- `revision_native_reference_20261004`: tiny current-HF no-crop/native equality, compact per-head causal masks, age/selection/gather tests and synthetic-gate routing. It explicitly did **not execute author classes**; its default freezes selection at query/decode. Reuse its proven small primitives and knowledge, not its policy default or closed launch guard
- `revision_cpu_native_trim_comparison_20261004`: 392/392 synthetic native-operator outputs matched with/without process-local malloc_trim. Sampled peaks were approximately1.978GB versus1.091GB. This is allocator engineering, not TRIM-KV cache compression or author-runner parity
- `revision_cpu_trim_validation`: old constructed Full run completed819.2s wall and peaked3.857GB but hit its64-token output cap without EOS
- `revision_cpu_author_budget_calibration`: unchanged constructed Full completed natural EOS after162 selections,1323.2s wall,3.759GB sampled peak, and1.767TB logical decoder reads. The complete answer failed its predeclared semantic gate. That entire pilot remains closed
- `revision_cpu_full_only` and terminal audits: preserve the earlier time/RSS stops. No new preparation converts those into passes
- `revision_cpu_file_pager`: tiny bounded weight-paging/native checks and later real-model evidence exist. Its original chunked attention/head choices and approximate2.1GiB precedent do not prove the **original dense-history call** fits
- `trimkv_layer_replay_contract_20261005`: source-only legality/ABI audit. It did not establish native numerical parity, and this baseline plan does not launch its layer-major research schedule
- `runtime_recovery`: verified existing CPU versions/source, not author4.57.1/CUDA/FA2 equivalence

Thus the missing work is a small **actual author-method oracle plus exact reference-call integration**, not another broad synthetic operator benchmark, model-recovery exercise or repeat of the old constructed answer.

## Phase A: smallest missing native-author gate

`PHASE_A_PROTOCOL.json` specifies eight groups. New execution would use exact source-span extraction of the full author `TrimKVCache` and `RetentionGate` classes, keeping their method bodies unchanged and hashing them. Only used CPU dependencies are bound. This avoids importing unrelated Triton/training modules. It is an isolated **author-method execution**, not a claim that the whole author loader ran unchanged.

Reference and adapter must be independent enough to expose an error: the reference uses unchanged source cache methods with synthetic arrays; a scalar age/topk/gather oracle checks margin-separated cases; the current-HF adapter produces closed-loop tiny layer outputs. A trivial comparison of an adapter against itself is insufficient.

Minimal coverage:

- Threshold M+31/M+32, oversized calls, actual buffer32, shared global clock and two prune events
- A discriminating newest-age2 fixture, per-head differences, original-ID gaps, exact paired gathers and current-token eviction
- One dense history call, a complete question call and Q1 decode; deliberate128-style extra boundaries/early pruning must be detected
- Correct normalized-hidden gate, Q/K norms and fixed RoPE; wrong raw-hidden gate and retained-length position negatives
- Closed-loop two-layer tiny Full/no-crop/author-TRIM paths, showing upper-layer gates depend on compressed lower-layer outputs
- Query-tiled versus dense same-call CPU attention, mask alignment and GQA mapping, plus last-row-of-full-head versus last-token-only head
- Explicit current ABI failures and unsupported-route rejection

Cache fixture maximum:2layers,8KV heads,D128,256total tokens. Tiny model maximum:2layers, hidden32,4query/2KV heads,D8,vocab97,<100k parameters,192tokens. One synthetic full-shaped gate check uses2tokens; no trained payload is needed. FP32/BF16 cases are distinct. Exact event/keep/gather equality is mandatory; numerical output tolerance cannot excuse a changed policy branch. All negative controls must actually detect their error.

Cost ceilings: one attempt,120s wall,90s child CPU plus5s guard hard limits and100s aggregate CPU allowance,1GiB sampled process-tree RSS,25ms sampling,32MB evidence,1CPU thread,3GB starting/1.5GB continuing available memory,5GB disk reserve. No automatic retry. Guard failure is fail-closed and cleanup must prove the owned process group absent. Sampled RSS is not a hard kernel memory cap; record OS high-water marks and disclose this limitation.

### Minimal new modules needed later

These are implementation responsibilities, **not existing runnable files**:

1. `source_reference.py`: verified source-span loader and immutable direct author cache/gate reference; import allowlist and unsupported-path rejection
2. `author_static_adapter.py`: normalized-hidden gate seam, two-value native cache interface, explicit original positions/per-layer lengths and one global post-call prune hook; independent cache state; default fixed RoPE/current mask ABI
3. `test_author_semantics.py`: fixed arrays, tiny closed-loop positives, deliberate negative variants, exact comparisons and tiny attention/head tests
4. `run_phase_a_guard.py`: one-attempt guard, fresh output directory, resource/sample/CPU accounting and cleanup
5. `trace_schema.py` or a small common module: fixed event, storage and cost records with no retained tensor history beyond small PhaseA arrays

No need to build five baseline policies, a general scheduler, a training framework or a new paper method. Preserve old files and guards; use a new directory and source manifest.

## Current runtime ABI is a real admission issue

The released author integration is not drop-in compatible with recovered5.19:

- `create_causal_mask(input_embeds=..., cache_position=...)` versus current `inputs_embeds` and no cache_position
- Current masks call `get_query_offset(layer_idx)` and `get_mask_sizes(query_length:int, layer_idx)`; author cache expects a position tensor and `.shape`, and its get_seq_length accepts no layer argument
- Current attention expects `update(K,V,layer)` returning two tensors; author update requires gate/position metadata and returns five objects. A cache-only class substitution cannot inject gate inputs
- Current Qwen3/default RoPE is model-local and config.rope_parameters-based; the global registry no longer has the default constructor the author code indexes
- Current decoder returns a tensor; author decoder returns a tuple
- Author loader requires CUDA/BF16/FA2 and imports unused training/Triton routes; recovered CPU runtime has no Triton

Do not invent an unavailable-symbol blocker: current source does retain the deprecated SlidingWindowCache alias. Do not install/downgrade packages to avoid writing the narrow adapter unless separately authorized. Exact current source links/hashes are in the existing replay-contract manifest.

## Public source-only selection, fixed before outcomes

Selection freeze SHA256: **0f2485635a96e726c0b684727a6b064f9d4c1662f4579724f93b876a507c1451**. The freeze was written before ranking. `TIMING_NOTE.json` corrects its manually entered planned timestamp to observed filesystem chronology while preserving original freeze bytes.

All500 IDs were ranked by SHA256 of `author-trimkv-cpu-original-oracle-v1|question_id`. Exclude the24 conservative old-source IDs and their transitive shared-session components, then choose first two distinct remaining components. The former source-only shared-history edge ledger is used solely as a negative overlap index, never its27-case semantic eligibility or model results. The public raw file was rehashed; all edge endpoints belong to its500 IDs. Direct selected-to-all24-excluded checks found no shared session ID or exact role/content session. This is mechanical source-disjointness, not a proof of statistical independence or all possible semantic overlap.

| Frozen ID | Source index | Sessions / turns | Raw history characters | Component |
|---|---:|---:|---:|---|
| edced276 |106|2 /18|25,703|edced276, edced276_abs|
|19b5f2b3|332|1 /12|14,938|19b5f2b3,19b5f2b3_abs|

Record hashes use `jq -cS` canonical JSON including its single LF, documented separately. No questions, histories or answers are rewritten, abbreviated, supplemented or competence-filtered. The two selected types happened to be multi-session and single-session-user; types were inspected only after the choice. Old constructed record families603deb26/b01defab and all development exclusions remain excluded.

Oracle is an official public author benchmark split containing only evidence sessions. It is **not** noisy LongMemEval-S or M, which the TRIM example targets. Calling this two-record Oracle smoke a reproduction of the TRIM paper's LongMemEval score would be false.

## Prospective budget, no silent no-op compression

After a separately allowed tokenizer-only preparation, let H be the smaller of the two original history-call token lengths. Freeze:

**M = min(1024, 32 × floor(H /128)); buffer32**

This retains approximately one quarter of the shorter history, capped at1024. It is relevant to memory-limited behavior and guarantees a history pruning event only when the explicit admission assertions pass. Require M>=32 and each original history has at leastM+32 tokens. Reject M=0, any insufficient history, any source truncation or input>8192 tokens; **never clamp, replace the sample or invent a new budget**. All selected records remain in the reporting denominator even if the stage is blocked.

The rule is already frozen; its exact integer M and tokenized compression ratio are not known because no tokenizer was imported. This is a declared altered-budget CPU smoke, not the author shell32768 setting. The checkpoint's trained budget1024 and metadata buffer128 do not override the runtime rule.

## Phase B is separate, conditional, and may be resource-censored

The four proposed arms are first record Full→TRIM, second record TRIM→Full. Both arms use the same pinned backbone/dtype/pager/CPU attention, same original history/question/decode boundaries and800-selection stopping semantics. Full has no eviction or gate computation; TRIM pays its extra gates, metadata and pruning. Wrong Full answers stay in the denominator and do **not** prevent the compressed arm. Technical/resource failure does stop remaining work and records every missing arm explicitly.

A complete two-record run would support only a tiny **trained static-TRIM CPU-port baseline**. Answers should be reviewed blinded to method using the released task-specific LongMemEval rubric; disagreements and all raw answers are retained. Without running the official judge, call the result manually adjudicated subset accuracy, not the author's automated score. No extra local judge model or paid evaluator is included.

### Dense-history memory blocker

BF16 raw KV uses **147,456 bytes per token** across36layers and8KV heads. At an8192-token history this is1,207,959,552bytes of KV before the global prune. M1024 retains150,994,944KV bytes afterward, plus gates/IDs and buffer growth. Gate parameters themselves add94,704,192bytes. Initial peak is shared with the Full route and is not bounded by M.

Naive eager attention at8192tokens has a32-head BF16 score tensor of4GiB **alone**, before FP32 softmax, probabilities, repeated K/V, activations, cache, gate and model state. The default full-history LM head would also produce about2.49GB of BF16 logits. Therefore the previous small-chunk pager memory result cannot admit this path.

A candidate CPU port must use bounded query tiling **inside the same original dense attention call**, never pruning between tiles, and last-token-only LM-head computation for discarded historical logits. Both preserve the relevant mathematical dependency graph but can change numerical kernel reductions and performance relative to CUDA FA2. They must pass PhaseA tiny tests, receive a new input-specific memory forecast and be disclosed. This preparation neither implements nor proves the long-call port fits.

### Hard proposed ceilings and complete accounting

PhaseB proposal: one attempt;4sequential arms; at most900s wall/3000s childCPU per arm and3600s model wall/12000s childCPU total;180s finalization reserve;4GiB sampled process-tree RSS;6GB starting/1.5GB continuing available memory;5GB free disk reserve;1.6GB evidence;4TB cumulative logical weight-read cap;4CPU threads; no GPU, installs, downloads or paid calls. These are prospective ceilings, not authority or a completion forecast.

The author800-step bound allows801forwards per arm,3204across4arms, over23TB of logical decoder reads at7,266,631,680bytes per forward. The **separate4TB/time ceilings intentionally dominate** that worst case. A stopped arm is resource-censored; it must not be reported as a shorter author budget or silently continued. An input-specific forecast and explicit later authorization are required before loading anything. PhaseB is not automatically released by PhaseA success.

Report startup/hash/pager costs, every gate, score, topk, sort, append, K/V/gate/ID gather/copy, mask/attention, decode, heap trim if used, evidence serialization/hash and guard costs. Separate nested timers from disjoint totals. Log logical bytes and physical I/O counters separately: repeated reads may hit the OS page cache and are not cold storage bandwidth. Count actual unique backing storage, simultaneous old/new append/prune tensors and transient full-prefill KV, not just M×token bytes. Measure process-tree RSS/PSS and OS high-water marks, host available memory, anonymous/file residency where available, and physical peak before/during/after compression. Sampled peaks can miss brief excursions; do not claim a strict memory cap if no cgroup is available.

## Honest stopping point

Prepared here: exact source contract, effective released command caveats, fixed original public selection and mechanical overlap check, prospective budget rule, PhaseA and PhaseB protocols, required modules, costs and blockers. Checked only text/JSON/hash metadata. Nothing numerical passed in this new packet.

Next useful action is implementing/reviewing only the small PhaseA adapter gate if authorized. Do not rerun closed Full gates, resurrect prior rejected methods, start a4B generation, construct a replacement benchmark, claim novelty or write a paper contribution from this baseline preparation.

### Two future CPU implementation paths, both still blocked

1. **Preserve the author's materialized full-history LM head.** This retains the original output-head work and vocabulary-output footprint for an operator-faithfulness investigation. Budget its complete allocation, preserve it in measurements, and admit it only in a separately sufficient resource envelope. It is not required to fit the current proposal. Even this CPU path would not establish CUDA FA2 peak memory or speed.
2. **Declare an explicit CPU memory adaptation.** Compute only consumed last-token logits, or chunk the full head while preserving the required outputs, with a separate full-head/last-row or chunked-head parity proof. Use CPU SDPA or query-tiled dense causal attention only after a separate masking, GQA, numerical and call-boundary proof. No prune may occur between internal attention/head tiles. Reproducing the policy does not make this adaptation the author's exact materialized execution footprint.

Phase B's current proposal describes the second path. Neither path is implemented or released. They are ordinary engineering adaptations, not new research contributions. If the corresponding proof or physical-memory admission fails, keep Phase B blocked; do not swap paths silently or expand resources automatically.
