# Static TRIM-KV: layer-major replay source contract

Date: 2026-10-05 UTC. Status: **source-only, conditionally compatible after an explicit adapter; native numerical parity untested**.

## Judgment

The pinned static `TrimKVCache` route can support block layer-major teacher forcing with batched tokenwise dense operations. Its learned gate reads the current layer's normalized input, and its eviction decisions do not depend on that layer's attention output, output projection, MLP, or upper-layer output. The globally invoked compression sweep is mathematically a product of layer-local transitions **provided the reference logical clock and original call boundaries are supplied explicitly**. Calling the unmodified shared cache/hook while moving one layer ahead across a block is incorrect.

This is a less compelling general replay stress case than attention-dependent TOVA: default static TRIM only evicts after 32 appended decode tokens following a prune, so ordinary event-aligned causal blocks are legal. Furthermore, all within-layer keep schedules can be computed from batched gates before attention, admitting an explicitly masked block-attention control. Neither speedup nor native compatibility follows from the previous TOVA synthetic checks.

No models, author modules, tensor payloads, datasets, or numerical tests were loaded or executed. No installation or old file change was made. New files are confined to this directory. Two optional web opens of pinned GitHub pages returned cache misses; the evidence below comes from existing local pinned author/source snapshots and fresh text/hash inspection.

## Pins and actual route

- Author source: `ngocbh/trimkv` commit `49d2a2951ba12e6431a3986b418ee791b209d7c2`
- Static gate metadata: `ngocbh/TrimKV-Qwen3-4B-Instruct-2507`, revision `89112809f83d05c3058eadcab4104abde5721b81`
- Base checkpoint: `Qwen/Qwen3-4B-Instruct-2507`, revision `cdbee75f17c01a7cc42f958dc650907174af0554`; identity supplied by the task and consistent with local source metadata, not rechecked against weight payloads here
- Author requirements: Transformers `4.57.1`, Torch `2.8.0` ([requirements](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/requirements.txt))
- Current recovered runtime: Transformers `5.19.0.dev0`, commit `02d8fb9784e8f14a1251e4c992cd82a5762417c6`; recorded installed Torch `2.9.1+cpu`. No runtime imports were made in this audit

The released LongMemEval loader creates **`TrimKVCache(memory_size=config.kv_budget, buffer_size=config.buffer_size, device="cuda")`**, rather than DynamicBudget/Paged cache. It forces BF16 and permits only FlashAttention2. Cache constructor defaults supply `strategy="fixed_budget"`, `lookahead_steps=1`, `sliding_window_size=0`. Although the runner exposes a lookahead option, that argument is not forwarded by this cache creator. Config strings such as `compress_strategy="alpha"` do not replace this actual cache policy. [Loader lines 87–140](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/load_model.py#L87-L140)

The checkpoint config's `buffer_size=128` is not the released runner's effective cache buffer: runner default is **32**. The example shell defaults `kv_budget=32768`; running the Python entrypoint with no budget instead resolves to `max_model_len`. An experiment must pin its actual M and buffer separately from model metadata. The loader's `model.config.compress_memory=config.update_kv` does not guard the static model's final `compress()` call; actual cache `do_compress` is set by whether its memory budget is non-null. [Runner defaults](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/run_longmemeval.py#L58-L69), [budget fallback](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/run_longmemeval.py#L206-L212), [shell](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/scripts/run_trimkv.sh#L8-L28), [gate config](https://huggingface.co/ngocbh/TrimKV-Qwen3-4B-Instruct-2507/blob/89112809f83d05c3058eadcab4104abde5721b81/config.json)

## Exact static semantics

### Gate and Qwen3 data dependencies

For layer l and token i, let z be `input_layernorm(hidden_states)`:

- Q = q_norm(q_proj(z)), K = k_norm(k_proj(z)), V = v_proj(z), then split-half RoPE on Q/K
- `log_beta = logsigmoid(linear2(silu(linear1(z))) + bias)`
- `linear1` maps the **full normalized hidden vector** 2560→512 with bias; `linear2` maps 512→8 without bias; a separate 8-vector bias follows. The class docstring's suggestion of separate head-vector linear layers is not its implemented computation
- Gate output is per KV head, transposed to [batch,8,tokens], stored once with each K/V row. The gate does not run again on old cached tokens
- For this checkpoint: 36 layers; 32 query heads; 8 KV heads; head dimension **128**; Q/O inner width4096, K/V inner width1024; hidden width2560; MLP9728; SiLU; RMS epsilon1e-6; tied LM embedding/head weights. Do not derive head dimension as 2560/32=80

The gate branch is `rg`; layer tying is conditional on `rg10`, so does not apply. All gate and Q/K/V work can be batched once the correctly compressed lower-layer block output is available. O projection, residual operations, post-attention RMSNorm and SwiGLU can be deferred and batched without affecting this layer's subsequent eviction decisions. All later layers still consume the resulting closed-loop hidden states; an all-dense hidden-state trace is not equivalent. [Gate and attention lines 134–173, 217–345](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L134-L345), [decoder](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L353-L401), [base config](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507/blob/cdbee75f17c01a7cc42f958dc650907174af0554/config.json)

### Inference attention, append, time and prune

1. Append current call's already-rotated K, V, log_beta and absolute `cache_position` IDs before attention. Increment `_seen_tokens` by query length **only in layer0**
2. Attend to retained old rows plus this call's new rows, with causal visibility within the call. Evaluation selects `_attn_implementation="flash_attention_2"`; its wrapper discards `retention_weights` and `kv_positions`, so retention does **not** multiply attention scores during this route. Training `rg_attn_flex` and `rg_attn_eager` are different contracts
3. After all decoder layers and final RMSNorm, the model invokes cache `compress()`; LM logits are computed afterward. The sweep's placement is global, but each static layer selection reads only that layer's rows and a common clock/mask/config
4. At each layer, prune iff retained row count R is **at least M+buffer**. Compute `q_idx = seen_after_call + 1`; cast stored log_beta to float32; score each row/head as `log_beta * (q_idx - original_position)`
5. Apply optional sliding-window protection to the last physical slots, and optional padding mask. Both are outside the minimum supported unpadded/no-window contract
6. Select M highest scores **independently per KV head** using native `torch.topk`; sort the selected physical indices ascending; gather K, V, log_beta and absolute positions in that order

The literal age for newest token p=N−1 at a Q=1 event is **N+1−p=2**, not1. Preserve this implementation detail; it can change ranking because gates differ. The buffer is growth slack between prune events, not a recency-protection guarantee. In the released default there are no protected sinks or recent tokens, and even the newest row may be selected out. After pruning to M, Q=1 events recur after buffer more appends. There is no separate per-layer decode counter or hidden-state buffer in the source; derive event phase from retained length, not token index modulo32. [Cache lines 55–175, 199–247](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/cache_utils.py#L55-L247), [attention dispatch wrapper](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/attn/__init__.py#L18-L35), [post-model prune](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L712-L727)

### Prefill and positions

Prefill is not TOVA's protected dense-prefix initialization. The runner makes separate calls for earlier prompt pieces, then a complete final question/prompt call, followed by Q=1 decode. It may split the prepared prompt at `Current Date:` into history and final question pieces. **Every one of these forwards ends with the same static compression sweep**, if capacity is reached. There is no within-call prune, even if a prefill is much longer than M+buffer. An oversized prefill can therefore have a large transient cache and is pruned directly to M once at its end. Changing the prefill call partition changes the reference policy. `model.is_compressing` is assigned by this runner but is not consulted by the inspected static model. [Runner prefill/decode](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/run_longmemeval.py#L109-L203), [prompt split](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/experiments/longmemeval/run_longmemeval.py#L279-L299)

Default positions are computed once before each model forward from total seen tokens, not retained cache length, and shared across layers. RoPE configuration is fixed default, theta5,000,000, max positions262,144, with no scaling. Cached rotated keys are gathered but never renumbered or re-RoPE'd; per-head retained absolute IDs can differ. Keep token count, absolute positions, compact slots and layer progress distinct. The source's pre-update `offset` differs for layer0 versus later layers because only layer0 advances `_seen_tokens`; this is not the gate/score clock and must not be repurposed as one. The selected standard attention route does not use retention/position tensors to alter its logits. Dynamic/scaled RoPE and padding require separate validation. [Position/RoPE setup](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L404-L435), [forward positions](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/models/qwen3/modeling_trimkv_qwen3.py#L618-L652)

## Why a clock-aware split is legal, and where it is not

For each original call/event e, its token range and N_e (total tokens after the call) are fixed by the teacher-forcing schedule. Static `compress()` is a sequence of disjoint layer transitions C_l(S_l,N_e). Move C_l immediately after that layer's attention for event e: it does not change any current attention output or upper-layer input, and cannot affect another layer's state. Carry N_e explicitly, because physical execution no longer keeps all layers at the same token. No upper-layer data is required. The source's shared `_seen_tokens` and `attention_mask` are container organization, not proof of a mathematical cross-layer scoring dependency in the restricted route.

Do not use the live layer0 clock for layer1 replay; it would be ahead. Do not run global `compress()` during layer0 replay; it would prune other layers at the wrong phase. At an outer block boundary all layer logical clocks must agree. No globally ordered RNG is relevant in deterministic evaluation; training/dropout is excluded.

In contrast, `DynamicBudgetTrimKVCache` concatenates scores across layers/heads and globally chooses recipients of a pooled memory budget. Its fixed-budget decisions require other layers' current gates and create a real inter-layer dependency. Paged pooled-budget compression also combines layers/heads. Reject both types in this first adapter rather than inferring locality from the shared base class or the word "static" in a checkpoint label. [DynamicBudget global selection](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/cache_utils.py#L404-L451), [paged selection](https://github.com/ngocbh/trimkv/blob/49d2a2951ba12e6431a3986b418ee791b209d7c2/src/trimkv/cache_utils.py#L897-L963)

## Minimum adapter surface

The companion `ADAPTER_CONTRACT.json` is a specification, not executable code.

1. `validate_route(metadata, runtime, execution_mode)`: exact static cache, rg gate, eval, batch1/unpadded, fixed budget, no sliding protection, lookahead1, fixed default RoPE; reject unsupported variants and unknown dependencies
2. `initialize_prefix(prefix_calls)`: preserve original tokenization/IDs, positions, all prefix call boundaries, dense causal attention inside each call and post-call pruning. Return ordered per-layer/head K/V/log_beta/positions plus seen counts and event history
3. `project_block(layer, correct_input_hidden, absolute_positions)`: input RMSNorm, Q/K/V, per-head Q/K norm, fixed RoPE and gate computation; expose intermediate outputs for parity
4. `append_and_attend(layer_state, token_or_legal_interval)`: chronological visibility; append before attention. A dense projection block is never itself an eviction event
5. `finish_reference_call(layer_state, seen_after_call)`: exactly one capacity check per original call; source age formula, float32 scoring, topk then index sort, paired gathers; no side effects on another layer
6. `finish_layer_block(residual_inputs, attention_outputs)`: O/residual/post-norm/MLP/residual, then hand corrected outputs to next layer
7. `export_trace()/commit_block()`: ordered IDs, K/V/gates, scores, event clocks, threshold/selection decisions, attention and final outputs; synchronize layer clocks and account for retained/scratch storage separately

To integrate with HF rather than bypass its monolithic forward, also supply explicit per-layer cache lengths/query offsets, compatibility signatures and masks. The plain current Qwen3 cache callback supplies neither normalized hidden states for gates nor retention metadata, and expects two outputs; changing just a cache class is insufficient.

## Strongest legal controls

- Token-major Q=1 with identical primitives and source policy, plus layer-major Q=1 without dense hoisting
- **Maximal ordinary event-aligned attention blocks**: starting from resident length R<M+buffer, the next block may contain up to M+buffer−R forced tokens and prune at its end, provided no earlier original event is crossed. After prune, that interval is buffer (32 in the runner). Gate/attention representations do not change for old rows between these events. Initial prefill remains at its original call boundaries
- **Static-gate schedule plus masked block attention**: after batching layer input gates, replay all selection decisions before doing attention; construct each query/head's pre-prune visibility over the union of entering cache plus block tokens, then evaluate attention with those masks. This is a source-derived legal alternative, not an observed implementation or measured fast path. It can need extra live K/V/mask storage and a different kernel. It is valid only if masks preserve irreversible eviction and same-event self-visibility
- An ordinary chunk crossing an eviction event with only end-of-chunk pruning must fail on a constructed negative fixture. A chunk ending exactly at the event must match mathematically

TRIM has two extra learned dense gate matrices per layer, so operation accounting must include them; do not carry over the TOVA seven-matrix count unchanged. Charge gate evaluations, selection/sorting, K/V/gate/ID gathers, replay/mask overhead and additional activation storage. No timing claim is made.

## Transformers 5.19 source compatibility

Native Qwen3 still has the matching Q/K normalization, projection shapes, split-half RoPE, RMSNorm and SwiGLU structure, which supports a source-level adaptation. The author program itself is **not a drop-in 5.19 runner**:

- Author model passes `input_embeds` and `cache_position` to `create_causal_mask`; current function takes `inputs_embeds` and no `cache_position`
- Current mask preprocessing calls `get_query_offset(layer_idx)` and `get_mask_sizes(query_length:int, layer_idx)`; author's method expects a position tensor and reads `.shape`. The inherited current `get_query_offset` calls `get_seq_length(layer_idx=...)`, but author's override accepts no layer argument
- Current native Qwen3 attention calls `update(K,V,layer)` and unpacks two tensors. Author cache expects `cache_kwargs` containing gates/positions and returns five objects. Current cache APIs organize `layers`; author's separate list state and empty `layers=[]` need explicit adaptation
- Current default RoPE initialization is model-local and reads `config.rope_parameters`; `ROPE_INIT_FUNCTIONS` no longer contains `"default"`. Author constructor directly indexes that mapping for its default configuration. Config conversion and default RoPE initialization must be checked, not silently assumed
- Current decoder returns a hidden-state tensor; author's decoder returns a tuple including optional attention/gate fields. Scheduling wrappers must target the actual interface
- Current source does include `SlidingWindowCache = StaticCache` as a deprecated alias; absence of that symbol is **not** a verified blocker. Avoid generic version-mismatch guesses
- The released author loader requests CUDA/BF16/FlashAttention2 and imports training/Triton paths. The recovered runtime is CPU and records no installed Triton; this audit did not attempt native import or execution. A CPU attention port would establish port parity only, not FlashAttention2 kernel parity

Pinned current source: [Qwen3](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/models/qwen3/modeling_qwen3.py#L85-L320), [mask ABI](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/masking_utils.py#L763-L878), [cache ABI](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/cache_utils.py#L1578-L1613), [RoPE registry](https://github.com/huggingface/transformers/blob/02d8fb9784e8f14a1251e4c992cd82a5762417c6/src/transformers/modeling_rope_utils.py#L668-L675). Installed source hashes and archive comparisons are recorded alongside this report.

## Minimum parity cases before an adapter claim

1. Gate input fixture: full normalized hidden state versus raw hidden/K/V; verify per-layer8-head output and exact source gate parameter shapes
2. Cache lengths M+buffer−1, M+buffer and M+buffer+1; no early prune, exact boundary prune, single prune after an oversized call; verify post-size M
3. Explicit age fixture with differing gates where N+1−p and N−p yield different keep sets; check every layer gets the same event N despite layer-major execution
4. Current-token eviction and a retained older row; show buffer32 is not last32-token protection. Buffer128 is a separate configuration
5. Per-head/layer distinct keep sets, ascending physical-index gather order, gaps in absolute IDs and unrecomputed rotated keys
6. Dense prefix below capacity; oversized one-call prefix; two prefix calls with identical concatenated IDs; preserve each separately and exhibit possible split-versus-unsplit divergence
7. Blocks1, below32, exactly32, crossing32, multiple events, and block boundaries one token before/after an event; preserved layer progress/event phase
8. Crossed-event ordinary chunk negative control; event-aligned and precomputed-mask positive controls with same mathematical primitives
9. FP64/FP32 port comparison first, then intended BF16 gates/activations with FP32 score arithmetic when separately authorized. Compare numerical errors and discrete topk decisions independently; batching may change decisions near ties
10. Exact and near ties: native torch.topk has no source-defined stable tie refinement; sorting chosen indices afterward does not settle membership. Pin native backend behavior or qualify tie parity, rather than inventing a stable-ID guarantee
11. Closed-loop lower-layer compression changes upper-layer gates; a dense-trace replay must diverge on a constructed fixture
12. Rejection cases: DynamicBudget/Paged pooled allocation, training/dropout, unsupported gate, dynamic RoPE, padded/packed batches, changed prefix boundaries, absent positions, upper-layer feedback. Any eventual expansion requires new parity cases
13. ABI-level source/native tests: mask arguments, get_query_offset, cache return arity/metadata, decoder return type and default RoPE mapping. These are specified, not executed here

Compare event-by-event ordered absolute IDs, cache values, stored gates, FP32 scores, retained lengths, append/prune timing, seen counts, attention visibility/output, layer outputs and logits. A small logit norm difference alone cannot excuse a policy branch change.

## Remaining unknowns / limits

No checkpoint values or gate payload were inspected here; no model numerical parity, actual author-runner execution, FlashAttention2 parity, throughput, memory peak, accuracy, or publication-level novelty was established. The source does not define deterministic membership for score ties. Padded-mask behavior, global-budget variants, non-default lookahead and RoPE, training semantics, generation sampling and multi-batch state changes remain outside the minimal contract. Independent per-layer scores support legality; they do not establish any advantage over event-aligned or precomputed-mask alternatives.

Event-aligned and masked-block equivalence above is mathematical/source-level. Actual FlashAttention causal alignment/version and floating-point reduction behavior must be pinned and tested before kernel-parity claims; the author requirements inspected here do not fix a FlashAttention package version. Eleven author/config text files matched their existing acquisition receipts; six current Transformers files matched the official pinned source archive. These are provenance checks, not numerical tests.
