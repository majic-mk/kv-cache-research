#!/usr/bin/env python3
"""Archival byte processing only. Does not import project or numerical code."""
import csv, datetime, gzip, hashlib, io, json, math, os, pathlib, re, resource, sys, tarfile, time
ROOT=pathlib.Path('/workspace/scratch/a95be92193c8/kv_recovery_20261004_h7Ob9Y/restored/kv-cache-research')
BASE=pathlib.Path('/tmp/trimkv_baseline_archive_20261005')
FLOOR=5_000_000_000
RESERVE=16_000_000
R='research/reconstructed/'
files={}
def include(p,arc=None):
 p=pathlib.Path(p)
 if not p.is_file() or p.is_symlink(): raise RuntimeError(f'Not a regular file: {p}')
 if arc is None:arc='repository/'+str(p.relative_to(ROOT))
 if arc in files and files[arc]!=str(p):raise RuntimeError('duplicate name')
 files[arc]=str(p)
def tree(p,prefix=None):
 p=pathlib.Path(p)
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:
   include(f, (prefix+'/'+str(f.relative_to(p))) if prefix else None)
for p in sorted((ROOT/R).glob('author_trimkv*')):
 if p.is_dir() and not p.name.startswith('author_trimkv_phase_b'):tree(p)
for d in ['trimkv_layer_replay_contract_20261005','reuse_cost_frontier_screen_20261005']:
 tree(ROOT/R/d)
for f in ['research/hybrid_cache_source_screen_20261005.md','research/hybrid_cache_source_screen_20261005_sources.json','records/cost_ledger.csv',R+'revision_serving_holdout_v1_20261004/exclusion_audit.json']:
 include(ROOT/f)
for i in range(1,5):
 p=pathlib.Path(f'/tmp/trimkv_phase_a_author_parity_20261005_attempt{i}');tree(p,'attempts/'+p.name)
for n in ['trimkv_phase_a_serializer_check_20261005','trimkv_phase_a_bitwise_check_20261005']:
 tree(pathlib.Path('/tmp')/n,'checks/'+n)
# Only the small source files cited by the preparation manifest. Dataset, model,
# tokenizer blobs and installed packages are pinned externally, not copied.
source_tsv=ROOT/R/'author_trimkv_cpu_reproduction_prep_20261005/SOURCE_MANIFEST.tsv'
for row in csv.DictReader(source_tsv.open(),delimiter='\t'):
 rel=row['relative_local_path']
 if '/.venv/' not in rel and not rel.endswith('longmemeval_oracle.json'):include(ROOT/rel)
for rel in [R+'revision_baseline_contracts_20261004/pins_and_licenses.json',R+'revision_baseline_contracts_20261004/source_receipts.json',R+'revision_baseline_contracts_20261004/sources/trimkv_LICENSE',R+'revision_baseline_contracts_20261004/sources/qwen_LICENSE',R+'revision_sensitive_kv_sources_20261004/longmemeval__LICENSE']:
 include(ROOT/rel)
rt=ROOT/R/'runtime_recovery_20261004'
for n in ['requirements.dependencies.txt','requirements.cpython312-linux_x86_64.lock','requirements.actual.freeze.txt','provenance.json','README.md','installation_commands.sh','cpu_python.sh','verify_recovered_runtime.py','logs/recovery_verification.json']:
 include(rt/n)
sp=rt/'.venv/lib/python3.12/site-packages'
for n,p in [('Torch-2.9.1-THIRD-PARTY-LICENSES.txt',sp/'torch-2.9.1+cpu.dist-info/licenses/LICENSE'),('Transformers-5.19.0.dev0-LICENSE.txt',sp/'transformers-5.19.0.dev0.dist-info/licenses/LICENSE'),('Jinja2-3.1.6-LICENSE.txt',sp/'jinja2-3.1.6.dist-info/licenses/LICENSE.txt'),('MarkupSafe-3.0.3-LICENSE.txt',sp/'markupsafe-3.0.3.dist-info/licenses/LICENSE.txt'),('CPython-3.12.14-LICENSE.txt',pathlib.Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/LICENSE.txt'))]:
 include(p,'licenses/'+n)
# Exact pinned small layout-reference sources, not an installed runtime tree.
for n in ['torch/include/c10/core/Contiguity.h','torch/_tensor_docs.py']:
 include(sp/n,'reference_sources/'+n)
# Preserve both original-identity and post-run cache anomaly evidence.
include(ROOT/R/'author_trimkv_phase_a_implementation_v3_20261005/__pycache__/evidence_codec.cpython-312.pyc')
include(ROOT/R/'author_trimkv_phase_a_implementation_v4_20261005/__pycache__/evidence_codec.cpython-312.pyc')
# Optional terminal-audit output outside the repository is supplied explicitly.
for extra in sys.argv[2:]:
 p=pathlib.Path(extra)
 if p.is_dir():tree(p,'terminal_audit/'+p.name)
 else:include(p,'terminal_audit/'+p.name)

def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
def memavail():
 for l in pathlib.Path('/proc/meminfo').read_text().splitlines():
  if l.startswith('MemAvailable:'):return int(l.split()[1])*1024
entries=[]
for a,p in sorted(files.items()):
 if any(x in a.lower() for x in ['.safetensors','.whl','.pdf','.git/','.venv/','security/']):raise RuntimeError('Excluded payload: '+a)
 st=pathlib.Path(p).stat();entries.append({'archive_path':a,'source_path':p,'size_bytes':st.st_size,'sha256':sha(p),'mtime_ns':st.st_mtime_ns,'mode':st.st_mode & 0o777})
raw=sum(e['size_bytes'] for e in entries)
# PAX header overhead is bounded generously by four 512-byte blocks per file.
# Plus 4 MB metadata allowance; gzip worst-case expansion allowance is 1% + 64 KiB.
tar_bound=sum(2048+512*math.ceil(e['size_bytes']/512) for e in entries)+4_000_000+10240
gzip_bound=math.ceil(tar_bound*1.01)+65536
plan={'source_files':len(entries),'source_logical_bytes':raw,'tar_bound_bytes':tar_bound,'gzip_worst_case_bound_bytes':gzip_bound,'floor_bytes':FLOOR,'later_phase_b_reserved_bytes':RESERVE,'workspace_free_bytes':free(ROOT),'tmp_free_bytes':free('/tmp'),'host_available_bytes':memavail(),'source_inventory':entries}
(BASE/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({k:v for k,v in plan.items() if k!='source_inventory'}))
if sys.argv[1]=='plan':sys.exit(0)
if sys.argv[1]!='build':raise RuntimeError('Expected plan/build')
# Final build requires terminal audit confirmation provided by the independent reviewer.
ready=BASE/'AUDIT_READY.json'
assert ready.exists(),'Waiting for independent terminal audit'
audit=json.loads(ready.read_text())
assert audit['terminal_audit_final'] is True
assert free(ROOT)>=FLOOR
assert free('/tmp')-gzip_bound>=FLOOR+RESERVE
assert memavail()-gzip_bound>1_500_000_000
extra={}
def meta(n,v):extra[n]=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
# Consolidated dependency inventory retains original signed manifest evidence.
external=[]
for version in ['','_v2','_v3','_v4']:
 p=ROOT/R/f'author_trimkv_phase_a_implementation{version}_20261005/frozen_manifest.json'
 j=json.loads(p.read_text())
 for e in j.get('files',[])+j.get('readonly_external_files',[]):
  path=e['path'];apath=path if path.startswith('/') else str(ROOT/path)
  if apath not in files.values():external.append({'referenced_by':str(p.relative_to(ROOT)),'path':path,'sha256':e['sha256'],'bytes':e.get('bytes'),'bundle_status':'PINNED_EXTERNAL_NOT_BUNDLED','verification_note':'Hash preserved from original frozen manifest; archive process did not load or rehash external binary payloads'})
meta('EXTERNAL_DEPENDENCIES.json',{'scope':'Dependencies only; no automatic download/install or execution authorized','entries':external,'runtime_package_urls_and_archive_hashes':'repository/'+R+'runtime_recovery_20261004/provenance.json','tokenizer_and_dataset_pins':'repository/'+R+'author_trimkv_tokenizer_prep_20261005/EXECUTION_PINS.json','source_urls_and_hashes':'repository/'+R+'author_trimkv_cpu_reproduction_prep_20261005/SOURCE_MANIFEST.tsv','raw_dataset_bundled':False,'trained_weights_or_gates_bundled':False,'runtime_installation_bundled':False})
completion=json.loads((ROOT/R/'author_trimkv_phase_a_completion_20261005/VERIFIED_COMPLETION.json').read_text())
meta('COST_AND_RESOURCE_ACCOUNTING.json',{'money':{'new_gpu_rentals_or_paid_services_in_this_phase':False,'project_cumulative_amount':None,'currency':'CNY','historical_autodl_fees':'unknown_pending_invoice_attribution','authorized_rental_total_limit_cny':100,'initialization_ledger_zero_is_not_project_total':True,'historical_context_library_file_id':'libfile_d296e06df8a48191aa86f96d9597ef66','historical_context_version':1,'scoped_receipts_not_present_here':['/workspace/shared/kv_autodl_operator_20261004.json','/workspace/shared/kv_autodl_scoped_statement_20261004.json']},'cpu_scope':'Recorded gate/check receipt accounting, not a bill or complete project CPU total','main_guard_resources':completion['resources'],'implementer_final_readonly_decode_cpu_seconds':completion['codec_verification']['cpu_seconds_read_only_verification'],'terminal_independent_audit':audit,'archival_work':'Byte hashing/compression/Library transfer verification only. Archive processing CPU is separate from the frozen Phase A numerical gate; no new numerical run.'})
meta('ARCHIVE_SCOPE.json',{'classification':'PRIVATE_ENGINEERING_BASELINE_PROVENANCE_NOT_PAPER_RESULT','freeze_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_implementation_confirmed':True,'independent_terminal_audit':audit,'archive_process_modified_originals':False,'prior_failed_attempts_preserved':True,'numerical_arrays':'Every original attempt/check file is retained byte-for-byte; v2 incomplete gzip remains incomplete and is not claimed as a completed dataset','source_only_rejected_topic_reports':['reuse_cost_frontier_screen_20261005','research/hybrid_cache_source_screen_20261005.md'],'excluded':['trained checkpoint/model/gate binary payloads','runtime installations and wheel archives','full copyrighted papers','unnecessary full upstream repositories','Git history/security branch','secrets','new Phase B work after this freeze'],'postrun_bytecode_note':'The saved v4 evidence_codec pyc may differ from its frozen pre-execution pin; the explicit independent terminal audit adjudicates this. The archived current-byte hash must not be mistaken for the original expected pin.','reference_source_policy':'Exact class/function spans and small source files used by immutable manifests are preserved with their full-source hashes, URLs and licenses. No upstream repository snapshot is bundled.'})
summary=(BASE/'SUMMARY_AND_RESTORE.md').read_bytes();extra['SUMMARY_AND_RESTORE.md']=summary
extra['VERIFY_ARCHIVE.py']=(BASE/'verify_archive.py').read_bytes()
# This archive builder is retained for forensic reproducibility, not auto-executed.
extra['ARCHIVE_BUILDER.py']=pathlib.Path(__file__).read_bytes()
for n,b in extra.items():entries.append({'archive_path':n,'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'kind':'archive_metadata'})
manifest={'format_version':1,'hash_algorithm':'SHA256','classification':'private engineering provenance','files':entries,'self_hash_note':'This manifest does not include its own hash. The final archive/Library verification receipt pins the complete archive bytes and this manifest hash.'}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();extra['MANIFEST.json']=manifest_bytes
extra['SHA256SUMS']=(''.join(f"{e['sha256']}  {e['archive_path']}\n" for e in entries)).encode()
assert sum(map(len,extra.values()))<4_000_000
out=BASE/'TRIM-KV_restricted_PhaseA_engineering_archive_20261005.tar.gz'
assert not out.exists(),'Never overwrite an archive'
started=time.process_time();min_free=free('/tmp');min_mem=memavail()
class GuardedWriter:
 def __init__(self,f):self.f=f;self.n=0
 def write(self,b):
  global min_free,min_mem
  fr=free('/tmp');mm=memavail();min_free=min(min_free,fr);min_mem=min(min_mem,mm)
  assert fr-len(b)>=FLOOR+RESERVE,'Disk floor/reservation reached'
  assert mm>1_500_000_000,'Host memory floor reached'
  self.n+=len(b);assert self.n<=gzip_bound,'Source-derived archive bound exceeded'
  return self.f.write(b)
 def flush(self):return self.f.flush()
with out.open('xb') as rawout:
 with gzip.GzipFile(filename='',mode='wb',fileobj=GuardedWriter(rawout),compresslevel=6,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
   for a,p in sorted(files.items()):
    e=next(x for x in entries if x['archive_path']==a)
    st=pathlib.Path(p).stat();assert st.st_size==e['size_bytes'] and st.st_mtime_ns==e['mtime_ns'],'Source changed after freeze'
    ti=tf.gettarinfo(p,arcname=a);ti.uid=ti.gid=0;ti.uname=ti.gname='';ti.mtime=0;ti.pax_headers={}
    with open(p,'rb') as f:tf.addfile(ti,f)
   for a,b in sorted(extra.items()):
    ti=tarfile.TarInfo(a);ti.size=len(b);ti.mode=0o644;ti.mtime=0;tf.addfile(ti,io.BytesIO(b))
# Verify source hashes after streaming to detect mutation without re-running code.
assert all(sha(p)==next(e['sha256'] for e in entries if e['archive_path']==a) for a,p in files.items())
receipt={'archive_path':str(out),'size_bytes':out.stat().st_size,'sha256':sha(out),'manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'member_count':len(files)+len(extra),'source_file_count':len(files),'source_logical_bytes':raw,'archive_cpu_seconds':time.process_time()-started,'minimum_observed_tmp_free_bytes':min_free,'minimum_observed_host_available_bytes':min_mem,'workspace_free_after_bytes':free(ROOT),'tmp_free_after_bytes':free('/tmp'),'later_phase_b_reserve_bytes':RESERVE,'source_files_unchanged_post_stream':True,'compression':'gzip lossless over tar; all inner files unchanged','no_numerical_import_or_run':True}
(BASE/'ARCHIVE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
export=BASE/'metadata';export.mkdir(exist_ok=True)
for name in ['MANIFEST.json','EXTERNAL_DEPENDENCIES.json','COST_AND_RESOURCE_ACCOUNTING.json','ARCHIVE_SCOPE.json','SUMMARY_AND_RESTORE.md']:
 assert free('/tmp')-len(extra[name])>=FLOOR+RESERVE
 (export/name).write_bytes(extra[name])
print(json.dumps(receipt))
