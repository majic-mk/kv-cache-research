#!/usr/bin/env python3
"""Verify archived bytes with stdlib only, without executing archived code.
Usage: python3 VERIFY_ARCHIVE.py ARCHIVE.tar.gz [EXPECTED_SHA256]
The deliberately incomplete attempt2 trace.jsonl.gz is treated as opaque bytes.
"""
import hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(sys.argv[1]);h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(262144),b''):h.update(b)
archive_hash=h.hexdigest()
if len(sys.argv)>2:assert archive_hash==sys.argv[2], 'Archive SHA256 mismatch'
manifest=None
with tarfile.open(p,'r|gz') as t:
 for member in t:
  if member.name=='MANIFEST.json':
   manifest_raw=t.extractfile(member).read();manifest=json.loads(manifest_raw);break
assert manifest is not None,'Missing manifest'
expected={e['archive_path']:e for e in manifest['files']}
assert len(expected)==len(manifest['files']),'Duplicate manifest paths'
seen=set();checked=0;logical=0
with tarfile.open(p,'r|gz') as t:
 for m in t:
  assert m.name not in seen,'Duplicate member';seen.add(m.name)
  assert m.isfile(),'Non-regular member rejected'
  assert not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts,'Unsafe member path'
  f=t.extractfile(m);h=hashlib.sha256();size=0
  for b in iter(lambda:f.read(262144),b''):h.update(b);size+=len(b)
  assert size==m.size
  if m.name in expected:
   e=expected[m.name];assert size==e['size_bytes'] and h.hexdigest()==e['sha256'],m.name
   checked+=1;logical+=size
  else:assert m.name in ['MANIFEST.json','SHA256SUMS'],'Unlisted member'
assert set(expected)<=seen,'Missing files'
assert len(seen)==len(expected)+2,'Unexpected members'
print(json.dumps({'status':'EXACT_ARCHIVE_AND_MEMBER_HASH_PASS','archive_path':str(p),'archive_bytes':p.stat().st_size,'archive_sha256':archive_hash,'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'members':len(seen),'hashed_manifest_members':checked,'hashed_member_logical_bytes':logical,'attempt2_inner_gzip':'preserved byte-for-byte, not repaired or treated as complete','archived_code_executed':False,'files_extracted':False},indent=2))
