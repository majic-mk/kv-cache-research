# TRIM-KV restricted Phase A: private engineering archive / 受限 Phase A 工程归档

## 中文摘要

这是已完成的受限基线工程门禁及其完整失败历史，不是论文结果、新方法结果、真实长上下文性能或训练模型质量结果。v4 在 2026-10-05 单次获准执行后通过 8 组检查、59 个负对照；同次执行的 1,621 个事件、1,949 个张量描述符、9,705 个唯一数据块已完成无损解码核验。独立终审以“受限通过，明确披露运行后派生字节码例外”结案，171/172 个仓库文件符合原始哈希，唯一例外详见下文；原始报告、核验输出与精确哈希均保留。

保留全部四次真实尝试：v1 原生导入触及 tempfile 写入白名单而失败；v2 JSON 证据量超限，原始 gzip 不完整；v3 可解码的 406 事件前缀保留，但在单元素维度 stride 的 dtype-view 辅助函数处失败；v4 在窄范围、独立审阅的布局修复后通过。未修复、删改或隐藏旧日志，v2 内层 gzip 的原始损坏状态也按字节保存。所有实际写出的数组和日志都可恢复；不存在的尾部数据不能恢复，也没有补造。

单独的 tokenizer-only 准备保存了两条已冻结的公开 Oracle 输入、原始文本、完整 token ID 与绝对位置数组：edced276 的 history/question 长度为 6476/50，19b5f2b3 为 3959/41；M=960，buffer=32。该准备没有执行 Torch、Transformers 或训练模型。不要把这些冻结输入当作 v4 合成门禁的真实模型评测结果。

本轮仅进行了现有云端 CPU 检查、代码与资料归档，未发起新的 GPU 租赁或其他付费服务操作。历史 AutoDL 启动失败实例的费用尚未完成账单归属核对，项目累计金额未知；初始化账本中的 ¥0 不能代表累计支出为零。授权租赁总上限仍为人民币 100 元。

新加入的 reuse_cost_frontier_screen_20261005 以及 hybrid_cache_source_screen_20261005 仍是“仅资料/源码筛选，候选被拒绝”的报告，没有被重标为实验。没有运行训练模型、Phase B、GPU 或新的数值实验。

## English summary and limits

This is private engineering provenance for a restricted baseline gate. It is not a paper result. The unchanged author cache/gate class bodies, an independent adapter/scalar oracle, synthetic FP32/BF16 fixtures, and a tiny two-layer current-HF CPU integration were checked. The successful v4 run passed eight groups and 59 negative controls. Final independent status: PASS_RESTRICTED_PHASE_A_WITH_DISCLOSED_POSTRUN_CACHE_EXCEPTION. The complete lossless trace has 1,621 events. Prior failures and partial artifacts remain original, separately identified evidence.

The result does not establish trained 4B accuracy, full author-program execution, long-prefill memory fit, FA2 equivalence, cross-backend top-k tie behavior, throughput, research novelty, or publication readiness. RSS was sampled with OS high-water supplements; there was no hard kernel process-tree RSS reservation. Gate timing includes verification overhead and is not a performance benchmark. Frozen files may retain prospective pre-execution status strings; later completion/terminal audit receipts provide the actual outcome without mutating earlier manifests.

## Disclosed post-run bytecode exception / 运行后字节码例外

The terminal review identified one derived cache file rewritten after the successful run: v4/__pycache__/evidence_codec.cpython-312.pyc changed at 14:43:27 UTC, after the main run completed at 14:40:49 UTC. Its frozen expected SHA256 was 2378944d3a76fa0f5b3eae296b5a0ce2a233302a6ae6e3c125778c0b54d1a55b; the observed post-run SHA256 is 02945da0a1b2c4cad3b0bddfbb3739e637b7eba0d82b5739d0c2283355b11af4. Exact bytes matching the original pin survive in the v3 cache path. Both are preserved, without overwriting either. The independent static inspection found all 27 code objects equivalent except recorded source filenames, with a changed timestamp header. See the terminal audit and provenance addendum for the complete qualification. The source/output hashes and this derived-bytecode exception must be distinguished; this archive does not claim every original path remained byte-identical.

终审发现一次运行后生成字节码变化，两个状态均保存，并明确记录预冻结哈希与当前哈希。未通过覆盖当前文件来“消除”异常；原始源码、门禁输出以及运行后派生缓存必须分别理解。

## Exact versions and primary bindings

- Author TRIM-KV source: ngocbh/trimkv commit 49d2a2951ba12e6431a3986b418ee791b209d7c2
- Author interface reference: Transformers 4.57.1 commit 8cb5963cc22174954e7dca2c0a3320b7dc2f4edc, not the executed current-HF runtime
- Executed CPU runtime: CPython 3.12.14; Torch 2.9.1+cpu; Transformers 5.19.0.dev0 from commit 02d8fb9784e8f14a1251e4c992cd82a5762417c6
- Tokenizer-only preparation: Tokenizers 0.23.2, Jinja2 3.1.6, MarkupSafe 3.0.3
- Base-model metadata pin, not bundled payload: Qwen/Qwen3-4B-Instruct-2507 revision cdbee75f17c01a7cc42f958dc650907174af0554
- Static-gate metadata pin, not bundled payload: ngocbh/TrimKV-Qwen3-4B-Instruct-2507 revision 89112809f83d05c3058eadcab4104abde5721b81
- Public dataset revision: xiaowu0162/longmemeval-cleaned 98d7416c24c778c2fee6e6f3006e7a073259d48f; raw Oracle file SHA256 821a2034d219ab45846873dd14c14f12cfe7776e73527a483f9dac095d38620c
- v1 frozen manifest: fda89abdd8c147ffd6f50e03d5e880995fe7dffd178bc3c64d9109fa286fd8f8
- v2 frozen manifest: d9eb3cff4ccc48f9a4d212710b80de192dd7dd24add99940f7708907043ff10e
- v3 frozen manifest: a31b342b699e50d8b215c2c66bc20b84846385cd190a980d1b640f420a5f77ae
- v4 frozen manifest: 173a928ab6c852a705a0a71738f98cec3c197f8a8a9831b1c05a2d16a6ba2150
- v4 trace SHA256: 5434e0f4d5240db16a53f301ba5570c9ad05eb05b1f27cf17e8c54c457a20acd
- Exact TrimKVCache span: original lines 55–276, bytes [1726,12810), SHA256 6815beaef692ed88bb3deacd6b30f73c503d4f0e849b7e7db4f3e3d63b4e8015
- Exact RetentionGate span: original lines 134–173, bytes [5045,6847), SHA256 71ba60d206b37279c3c0f8bce6558fcef70160d420b67f7b400d7ff928160ed6

All pins above are complemented by original manifests, URLs, extraction receipts and licenses. MANIFEST.json hashes every retained source/output file and new archive metadata, excluding its own self-hash. The separate final Library receipt pins the whole archive and manifest. No full upstream repository or copyrighted paper is bundled. Small upstream source snapshots required to preserve immutable provenance are retained. Reusable model, gate, tokenizer and runtime assets are pinned, not copied.

## Restoration map / 恢复索引

1. First verify the archive SHA256 against its Library verification receipt. Run VERIFY_ARCHIVE.py with a normal Python 3 standard library and the archive path to verify every member. This performs byte hashing only; it never imports the archived project or numerical libraries. The invalid inner attempt2 gzip is deliberately opaque to this verifier.
2. Extract only into a new empty directory with enough capacity; do not overwrite a working checkout. repository/ retains the original relative repository paths. attempts/ contains the complete original /tmp/trimkv_phase_a_author_parity_20261005_attempt1 through attempt4 files. checks/ contains the original serializer and bitwise-helper checks, including deliberate corrupt fixtures used as negative controls. Empty scratch state is evidenced in original guard receipts; empty filesystem directories are not meaningful numerical output.
3. Start with repository/research/reconstructed/author_trimkv_phase_a_completion_20261005/REPORT.md and VERIFIED_COMPLETION.json, then the independent terminal audit included in this snapshot. Earlier implementation/readiness and preexecution-review folders retain their chronological context. ARCHIVE_SCOPE.json names finalization/audit evidence.
4. Preparation is in author_trimkv_cpu_reproduction_prep_20261005; tokenizer-only frozen strings/IDs/positions/contracts are in author_trimkv_tokenizer_prep_20261005; the exact adapter/replay contract is in trimkv_layer_replay_contract_20261005. These all live under repository/research/reconstructed/.
5. Each author_trimkv_phase_a_implementation[_v2/_v3/_v4]_20261005 directory contains its source, manifest, exact reference spans, test definitions, launch record and claim. The corresponding author_trimkv_phase_a_preexecution_review* folders contain the independent prelaunch reviews. The source-bound review, codec and bitwise-check provenance are retained separately.
6. To inspect already generated v3/v4 evidence, use the saved stdlib-only evidence_codec.py/reconstruct_evidence.py under the respective implementation version. Read the CLI source first. Preserve the trusted expected inventory from SOURCE_BOUND.json; a valid partial v3 trace is not full-suite success. Decoding must be separately resource-admitted if performed later. This archive creation performed no new numerical execution.
7. Source/runtime/tokenizer paths in original manifests intentionally remain unchanged, including absolute paths. External dependencies are listed in EXTERNAL_DEPENDENCIES.json and original lock/provenance files. Do not silently rewrite frozen manifests to make them portable. Any future rerun requires deliberate external-asset restoration, hash verification, path/admission review, and separate execution authorization. No downloader/installer or trained run executes automatically from this archive.
8. Read COST_AND_RESOURCE_ACCOUNTING.json for cost distinctions. The v4 guard charged cumulative CPU 41.769319 s against the 100 s gate, while recorded measured-check accounting was 28.928499 s; the implementer's final read-only decode added 0.905617 s separately. The three independent read-only audit processes reported 2.293522 s total CPU. Independent audit and archival byte-processing costs are separate, not silently included in the old frozen number. These are CPU bookkeeping values, not currency charges or a complete project resource bill.

## Preservation and privacy

Private Library delivery only. No external sharing or GitHub write was performed. No model/gate weights, runtime installation, secrets, security branch, full copyrighted papers, or unrelated later Phase B work are included. The complete public frozen inputs and all materialized numerical arrays from every included actual/partial attempt remain recoverable exactly. The archive process did not change or delete original files; the separately disclosed prior post-run bytecode mutation is retained as provenance evidence.
